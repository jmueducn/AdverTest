package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                                                                                public void testComputeGershgorinCircles_TypicalCase() throws Exception {
                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                    double[] main = {1.0, 2.0, 3.0};
                                                                                                                                                                                    double[] secondary = {0.5, 1.5};
                                                                                                                                                                                    double splitTolerance = 1.0e-6;
                                                                                                                                                                                    
                                                                                                                                                                                    // Create instance
                                                                                                                                                                                    EigenDecompositionImpl eigenDecomposition = 
                                                                                                                                                                                        new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get work array via reflection
                                                                                                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                    workField.setAccessible(true);
                                                                                                                                                                                    double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                    
                                                                                                                                                                                    // Invoke the method under test
                                                                                                                                                                                    Method computeMethod = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                                                                    computeMethod.invoke(eigenDecomposition);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get spectra fields via reflection
                                                                                                                                                                                    Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                    lowerSpectraField.setAccessible(true);
                                                                                                                                                                                    double lowerSpectra = (double) lowerSpectraField.get(eigenDecomposition);
                                                                                                                                                                                    
                                                                                                                                                                                    Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                    upperSpectraField.setAccessible(true);
                                                                                                                                                                                    double upperSpectra = (double) upperSpectraField.get(eigenDecomposition);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify lower and upper spectra
                                                                                                                                                                                    assertEquals(0.0, lowerSpectra, 1e-10);
                                                                                                                                                                                    assertEquals(4.5, upperSpectra, 1e-10);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify work array contents
                                                                                                                                                                                    final int m = main.length;
                                                                                                                                                                                    assertEquals(0.0, work[4*m + 0], 1e-10);   // lower[0] = 1.0 - (0 + 0.5)
                                                                                                                                                                                    assertEquals(2.0, work[5*m + 0], 1e-10);   // upper[0] = 1.0 + (0 + 0.5)
                                                                                                                                                                                    assertEquals(0.0, work[4*m + 1], 1e-10);   // lower[1] = 2.0 - (0.5 + 1.5)
                                                                                                                                                                                    assertEquals(4.0, work[5*m + 1], 1e-10);   // upper[1] = 2.0 + (0.5 + 1.5)
                                                                                                                                                                                    assertEquals(1.5, work[4*m + 2], 1e-10);   // lower[2] = 3.0 - 1.5
                                                                                                                                                                                    assertEquals(4.5, work[5*m + 2], 1e-10);   // upper[2] = 3.0 + 1.5
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify minPivot calculation
                                                                                                                                                                                    Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                    minPivotField.setAccessible(true);
                                                                                                                                                                                    double minPivot = (double) minPivotField.get(eigenDecomposition);
                                                                                                                                                                                    double expectedMinPivot = Double.MIN_VALUE * Math.max(1.0, 1.5 * 1.5);
                                                                                                                                                                                    assertEquals(expectedMinPivot, minPivot, 1e-10);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testProcessGeneralBlock_DiagonalMatrix() throws Exception {
                                                                                                                                                                                    // Setup a diagonal matrix (sumOffDiag == 0)
                                                                                                                                                                                    int n = 3;
                                                                                                                                                                                    double[] main = new double[n];
                                                                                                                                                                                    double[] secondary = new double[n - 1]; // All zeros for diagonal matrix
                                                                                                                                                                                    double splitTolerance = 1.0e-6;
                                                                                                                                                                                    
                                                                                                                                                                                    // Create decomposition instance
                                                                                                                                                                                    EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up work array through reflection since it's private
                                                                                                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                    workField.setAccessible(true);
                                                                                                                                                                                    double[] work = new double[4 * n];
                                                                                                                                                                                    work[2] = 0;  // e1
                                                                                                                                                                                    work[6] = 0;  // e2
                                                                                                                                                                                    workField.set(decomposition, work);
                                                                                                                                                                                    
                                                                                                                                                                                    // Store initial state to verify it doesn't change
                                                                                                                                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                    dMinField.setAccessible(true);
                                                                                                                                                                                    double initialDMin = dMinField.getDouble(decomposition);
                                                                                                                                                                                    
                                                                                                                                                                                    Field sigmaField = EigenDecompositionImpl.class.getDeclaredField("sigma");
                                                                                                                                                                                    sigmaField.setAccessible(true);
                                                                                                                                                                                    double initialSigma = sigmaField.getDouble(decomposition);
                                                                                                                                                                                    
                                                                                                                                                                                    // Call method
                                                                                                                                                                                    Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                    processGeneralBlock.setAccessible(true);
                                                                                                                                                                                    processGeneralBlock.invoke(decomposition, n);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify no changes were made to class variables
                                                                                                                                                                                    assertEquals(initialDMin, dMinField.getDouble(decomposition), 0.0);
                                                                                                                                                                                    assertEquals(initialSigma, sigmaField.getDouble(decomposition), 0.0);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                            public void testProcessGeneralBlock_SplitDetection() throws Exception {
                                                                                                                                                                                // Setup decomposition with dummy data
                                                                                                                                                                                double[] main = new double[6];
                                                                                                                                                                                double[] secondary = new double[5];
                                                                                                                                                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, 1.0e-10);
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to access private work array
                                                                                                                                                                                java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Setup a matrix that should trigger split detection
                                                                                                                                                                                int n = 6;
                                                                                                                                                                                double[] work = new double[4 * n];
                                                                                                                                                                                // Main diagonal elements
                                                                                                                                                                                work[0] = 10; work[4] = 8; work[8] = 6; work[12] = 4; work[16] = 2; work[20] = 1;
                                                                                                                                                                                // Off-diagonal elements with some very small values to trigger splits
                                                                                                                                                                                work[2] = 1e-10; work[6] = 1; work[10] = 1; work[14] = 1e-12; work[18] = 1;
                                                                                                                                                                                
                                                                                                                                                                                // Set the work array via reflection
                                                                                                                                                                                workField.set(decomposition, work);
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to access private method
                                                                                                                                                                                java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                                method.invoke(decomposition, n);
                                                                                                                                                                                
                                                                                                                                                                                // Verify that splits were processed by checking pingPong changes
                                                                                                                                                                                java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                                int pingPong = (Integer) pingPongField.get(decomposition);
                                                                                                                                                                                assertTrue(pingPong == 0 || pingPong == 1);
                                                                                                                                                                                
                                                                                                                                                                                // Verify dMin was set
                                                                                                                                                                                java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                dMinField.setAccessible(true);
                                                                                                                                                                                double dMin = (Double) dMinField.get(decomposition);
                                                                                                                                                                                assertTrue(dMin <= 0);
                                                                                                                                                                            }

 @Test
                                                                                                                                                                            public void testProcessGeneralBlock_WithNegativeOffDiagonal() throws Exception {
                                                                                                                                                                                // Test with negative off-diagonal elements
                                                                                                                                                                                int n = 3;
                                                                                                                                                                                double[] work = new double[4 * n];
                                                                                                                                                                                // Main diagonal
                                                                                                                                                                                work[0] = 2; work[4] = 2; work[8] = 2;
                                                                                                                                                                                // Off-diagonal with negative value
                                                                                                                                                                                work[2] = -0.5; work[6] = 0.5;
                                                                                                                                                                                
                                                                                                                                                                                // Create decomposition with dummy data
                                                                                                                                                                                double[] main = new double[n];
                                                                                                                                                                                double[] secondary = new double[n-1];
                                                                                                                                                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                                
                                                                                                                                                                                // Set work array using reflection
                                                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                workField.set(decomposition, work);
                                                                                                                                                                                
                                                                                                                                                                                // Invoke the method
                                                                                                                                                                                Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                processGeneralBlock.setAccessible(true);
                                                                                                                                                                                processGeneralBlock.invoke(decomposition, n);
                                                                                                                                                                                
                                                                                                                                                                                // Verify processing occurred using reflection
                                                                                                                                                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                tauField.setAccessible(true);
                                                                                                                                                                                double tau = tauField.getDouble(decomposition);
                                                                                                                                                                                
                                                                                                                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                dMinField.setAccessible(true);
                                                                                                                                                                                double dMin = dMinField.getDouble(decomposition);
                                                                                                                                                                                
                                                                                                                                                                                assertNotEquals(0, tau);
                                                                                                                                                                                assertTrue(dMin <= 0);
                                                                                                                                                                            }

 @Test
                                                                                                                                                                        public void testComputeShiftIncrement_EarlyReturnCases() throws Exception {
                                                                                                                                                                            // Create eigen decomposition with dummy data
                                                                                                                                                                            double[] main = new double[10];
                                                                                                                                                                            double[] secondary = new double[9];
                                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to access private fields
                                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                            
                                                                                                                                                                            Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                                            dMinField.setDouble(eigenDecomposition, 10.0);
                                                                                                                                                                            
                                                                                                                                                                            Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                            dNField.setAccessible(true);
                                                                                                                                                                            dNField.setDouble(eigenDecomposition, 10.0);
                                                                                                                                                                            
                                                                                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                                            pingPongField.setInt(eigenDecomposition, 0);
                                                                                                                                                                            
                                                                                                                                                                            Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                            endField.setAccessible(true);
                                                                                                                                                                            endField.setInt(eigenDecomposition, 10);
                                                                                                                                                                            
                                                                                                                                                                            // Set up work array
                                                                                                                                                                            int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                            work[nn - 5] = 8.0;
                                                                                                                                                                            work[nn - 7] = 4.0;
                                                                                                                                                                            
                                                                                                                                                                            // Store initial values
                                                                                                                                                                            double initialTau = 5.0;
                                                                                                                                                                            int initialTType = 5;
                                                                                                                                                                            
                                                                                                                                                                            Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                                            tauField.setDouble(eigenDecomposition, initialTau);
                                                                                                                                                                            
                                                                                                                                                                            Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                                                                            tTypeField.setInt(eigenDecomposition, initialTType);
                                                                                                                                                                            
                                                                                                                                                                            // Execute
                                                                                                                                                                            Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                            computeShiftIncrement.setAccessible(true);
                                                                                                                                                                            computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Verify no change
                                                                                                                                                                            assertEquals(initialTau, tauField.getDouble(eigenDecomposition), 0.0);
                                                                                                                                                                            assertEquals(initialTType, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testComputeGershgorinCircles_SingleElementMatrix() {
                                                                                                                                                                            // Setup for 1x1 matrix
                                                                                                                                                                            double[] main = new double[]{5.0};
                                                                                                                                                                            double[] secondary = new double[0];
                                                                                                                                                                            double[] work = new double[6 * main.length];
                                                                                                                                                                            
                                                                                                                                                                            // Create eigen decomposition instance
                                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-10);
                                                                                                                                                                            
                                                                                                                                                                            try {
                                                                                                                                                                                // Set private fields
                                                                                                                                                                                java.lang.reflect.Field mainField = EigenDecompositionImpl.class.getDeclaredField("main");
                                                                                                                                                                                mainField.setAccessible(true);
                                                                                                                                                                                mainField.set(eigenDecomposition, main);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field secondaryField = EigenDecompositionImpl.class.getDeclaredField("secondary");
                                                                                                                                                                                secondaryField.setAccessible(true);
                                                                                                                                                                                secondaryField.set(eigenDecomposition, secondary);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                workField.set(eigenDecomposition, work);
                                                                                                                                                                                
                                                                                                                                                                                // Invoke private method
                                                                                                                                                                                java.lang.reflect.Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                // Get private fields for verification
                                                                                                                                                                                java.lang.reflect.Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                lowerSpectraField.setAccessible(true);
                                                                                                                                                                                double lowerSpectra = lowerSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                upperSpectraField.setAccessible(true);
                                                                                                                                                                                double upperSpectra = upperSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                minPivotField.setAccessible(true);
                                                                                                                                                                                double minPivot = minPivotField.getDouble(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                // Verify results for 1x1 matrix
                                                                                                                                                                                assertEquals(5.0, lowerSpectra, 1e-10);
                                                                                                                                                                                assertEquals(5.0, upperSpectra, 1e-10);
                                                                                                                                                                                assertEquals(5.0, work[4], 1e-10);  // lower[0]
                                                                                                                                                                                assertEquals(5.0, work[5], 1e-10);  // upper[0]
                                                                                                                                                                                
                                                                                                                                                                                // minPivot should be SAFE_MIN since eMax is 0
                                                                                                                                                                                assertEquals(MathUtils.SAFE_MIN, minPivot, 1e-10);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set up or verify test due to reflection error: " + e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testComputeGershgorinCircles_NegativeValues() {
                                                                                                                                                                            // Setup with negative values
                                                                                                                                                                            double[] main = new double[]{-1.0, -2.0, -3.0};
                                                                                                                                                                            double[] secondary = new double[]{-0.5, -1.5};
                                                                                                                                                                            double[] work = new double[6 * main.length];
                                                                                                                                                                            
                                                                                                                                                                            // Create eigen decomposition instance with default split tolerance
                                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                            
                                                                                                                                                                            try {
                                                                                                                                                                                // Set private fields using reflection
                                                                                                                                                                                java.lang.reflect.Field mainField = EigenDecompositionImpl.class.getDeclaredField("main");
                                                                                                                                                                                mainField.setAccessible(true);
                                                                                                                                                                                mainField.set(eigenDecomposition, main);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field secondaryField = EigenDecompositionImpl.class.getDeclaredField("secondary");
                                                                                                                                                                                secondaryField.setAccessible(true);
                                                                                                                                                                                secondaryField.set(eigenDecomposition, secondary);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                workField.set(eigenDecomposition, work);
                                                                                                                                                                                
                                                                                                                                                                                // Invoke private method using reflection
                                                                                                                                                                                java.lang.reflect.Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                // Access private fields using reflection
                                                                                                                                                                                java.lang.reflect.Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                lowerSpectraField.setAccessible(true);
                                                                                                                                                                                double lowerSpectra = lowerSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                upperSpectraField.setAccessible(true);
                                                                                                                                                                                double upperSpectra = upperSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                // Verify results (absolute values are used for secondary elements)
                                                                                                                                                                                assertEquals(-4.5, lowerSpectra, 1e-10);
                                                                                                                                                                                assertEquals(0.0, upperSpectra, 1e-10);
                                                                                                                                                                                
                                                                                                                                                                                final int m = main.length;
                                                                                                                                                                                assertEquals(-1.5, work[4*m + 0], 1e-10);  // lower[0] = -1.0 - (0 + 0.5)
                                                                                                                                                                                assertEquals(-0.5, work[5*m + 0], 1e-10);  // upper[0] = -1.0 + (0 + 0.5)
                                                                                                                                                                                assertEquals(-4.0, work[4*m + 1], 1e-10);  // lower[1] = -2.0 - (0.5 + 1.5)
                                                                                                                                                                                assertEquals(0.0, work[5*m + 1], 1e-10);  // upper[1] = -2.0 + (0.5 + 1.5)
                                                                                                                                                                                assertEquals(-4.5, work[4*m + 2], 1e-10);  // lower[2] = -3.0 - 1.5
                                                                                                                                                                                assertEquals(-1.5, work[5*m + 2], 1e-10);  // upper[2] = -3.0 + 1.5
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set up or verify test due to reflection error: " + e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testComputeGershgorinCircles_ZeroSecondaryElements() {
                                                                                                                                                                            // Setup with zero secondary elements
                                                                                                                                                                            double[] main = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                            double[] secondary = new double[]{0.0, 0.0};
                                                                                                                                                                            double[] work = new double[6 * main.length];
                                                                                                                                                                            
                                                                                                                                                                            // Create eigen decomposition with dummy values first
                                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(
                                                                                                                                                                                new double[]{0.0, 0.0, 0.0}, 
                                                                                                                                                                                new double[]{0.0, 0.0}, 
                                                                                                                                                                                1.0e-12);
                                                                                                                                                                            
                                                                                                                                                                            try {
                                                                                                                                                                                // Set main, secondary and work fields
                                                                                                                                                                                java.lang.reflect.Field mainField = EigenDecompositionImpl.class.getDeclaredField("main");
                                                                                                                                                                                mainField.setAccessible(true);
                                                                                                                                                                                mainField.set(eigenDecomposition, main);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field secondaryField = EigenDecompositionImpl.class.getDeclaredField("secondary");
                                                                                                                                                                                secondaryField.setAccessible(true);
                                                                                                                                                                                secondaryField.set(eigenDecomposition, secondary);
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                workField.set(eigenDecomposition, work);
                                                                                                                                                                                
                                                                                                                                                                                // Invoke the private method
                                                                                                                                                                                java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                                method.invoke(eigenDecomposition);
                                                                                                                                                                                
                                                                                                                                                                                // Verify results - circles should collapse to points
                                                                                                                                                                                Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                lowerSpectraField.setAccessible(true);
                                                                                                                                                                                assertEquals(1.0, (Double)lowerSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                
                                                                                                                                                                                Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                upperSpectraField.setAccessible(true);
                                                                                                                                                                                assertEquals(3.0, (Double)upperSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                
                                                                                                                                                                                final int m = main.length;
                                                                                                                                                                                assertEquals(1.0, work[4*m + 0], 1e-10);  // lower[0] = upper[0] = 1.0
                                                                                                                                                                                assertEquals(1.0, work[5*m + 0], 1e-10);
                                                                                                                                                                                assertEquals(2.0, work[4*m + 1], 1e-10);  // lower[1] = upper[1] = 2.0
                                                                                                                                                                                assertEquals(2.0, work[5*m + 1], 1e-10);
                                                                                                                                                                                assertEquals(3.0, work[4*m + 2], 1e-10);  // lower[2] = upper[2] = 3.0
                                                                                                                                                                                assertEquals(3.0, work[5*m + 2], 1e-10);
                                                                                                                                                                                
                                                                                                                                                                                // minPivot should be SAFE_MIN since eMax is 0
                                                                                                                                                                                Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                minPivotField.setAccessible(true);
                                                                                                                                                                                assertEquals(MathUtils.SAFE_MIN, (Double)minPivotField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set up or verify test due to reflection error: " + e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testProcessGeneralBlock_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                            // Setup a non-diagonal matrix
                                                                                                                                                                            int n = 4;
                                                                                                                                                                            double[] work = new double[4 * n];
                                                                                                                                                                            // Main diagonal elements
                                                                                                                                                                            work[0] = 4; work[4] = 3; work[8] = 2; work[12] = 1;
                                                                                                                                                                            // Off-diagonal elements
                                                                                                                                                                            work[2] = 1; work[6] = 1; work[10] = 1;
                                                                                                                                                                            
                                                                                                                                                                            // Create decomposition with dummy arrays
                                                                                                                                                                            double[] main = new double[n];
                                                                                                                                                                            double[] secondary = new double[n-1];
                                                                                                                                                                            EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                            
                                                                                                                                                                            // Set work array using reflection
                                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            workField.set(decomposition, work);
                                                                                                                                                                            
                                                                                                                                                                            // Get and invoke private processGeneralBlock method using reflection
                                                                                                                                                                            Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                            processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                            processGeneralBlockMethod.invoke(decomposition, n);
                                                                                                                                                                            
                                                                                                                                                                            // Verify some internal state changes using reflection
                                                                                                                                                                            Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                                            double dMin = dMinField.getDouble(decomposition);
                                                                                                                                                                            assertTrue(dMin <= 0); // dMin should be set to a non-positive value
                                                                                                                                                                            
                                                                                                                                                                            Field sigmaField = EigenDecompositionImpl.class.getDeclaredField("sigma");
                                                                                                                                                                            sigmaField.setAccessible(true);
                                                                                                                                                                            double sigma = sigmaField.getDouble(decomposition);
                                                                                                                                                                            assertTrue(sigma >= 0); // sigma should be set to a non-negative value
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testProcessGeneralBlock_MaxIterationsExceeded() throws Exception {
                                                                                                                                                                            // Initialize decomposition object
                                                                                                                                                                            double[] main = new double[5];
                                                                                                                                                                            double[] secondary = new double[4];
                                                                                                                                                                            EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, 1.0e-10);
                                                                                                                                                                            
                                                                                                                                                                            // Setup a matrix that will require many iterations
                                                                                                                                                                            int n = 5;
                                                                                                                                                                            double[] work = new double[4 * n];
                                                                                                                                                                            // Main diagonal elements
                                                                                                                                                                            work[0] = 1; work[4] = 1; work[8] = 1; work[12] = 1; work[16] = 1;
                                                                                                                                                                            // Off-diagonal elements set to values that won't converge quickly
                                                                                                                                                                            work[2] = 0.9; work[6] = 0.9; work[10] = 0.9; work[14] = 0.9;
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set the work array since it's likely private
                                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            workField.set(decomposition, work);
                                                                                                                                                                            
                                                                                                                                                                            // Get the private method via reflection
                                                                                                                                                                            Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                            processGeneralBlock.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Expect exception
                                                                                                                                                                            try {
                                                                                                                                                                                processGeneralBlock.invoke(decomposition, n);
                                                                                                                                                                                fail("Expected InvalidMatrixException");
                                                                                                                                                                            } catch (InvocationTargetException e) {
                                                                                                                                                                                Throwable cause = e.getCause();
                                                                                                                                                                                assertTrue(cause instanceof InvalidMatrixException);
                                                                                                                                                                                assertTrue(cause.getMessage().contains("maximal number of iterations exceeded"));
                                                                                                                                                                            }
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testProcessGeneralBlock_SingleElement() throws Exception {
                                                                                                                                                                            // Edge case: n = 1 (single element matrix)
                                                                                                                                                                            int n = 1;
                                                                                                                                                                            double[] work = new double[4 * n];
                                                                                                                                                                            work[0] = 5; // Only diagonal element
                                                                                                                                                                            
                                                                                                                                                                            // Create decomposition with dummy data
                                                                                                                                                                            EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1}, new double[]{0}, 1.0);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set private work field
                                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            workField.set(decomposition, work);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to access and invoke private processGeneralBlock method
                                                                                                                                                                            Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                            processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                            processGeneralBlockMethod.invoke(decomposition, n);
                                                                                                                                                                            
                                                                                                                                                                            // Should process without errors
                                                                                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                                            assertEquals(0, pingPongField.getInt(decomposition));
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testComputeShiftIncrement_NegativeDMin() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            double[] main = {1.0, 2.0, 3.0};
                                                                                                                                                                            double[] secondary = {0.5, 0.5};
                                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-10);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set private fields
                                                                                                                                                                            Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                                            dMinField.set(eigenDecomposition, -5.0);
                                                                                                                                                                            
                                                                                                                                                                            Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                                                                            tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                            
                                                                                                                                                                            Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                                            tauField.set(eigenDecomposition, 0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Execute
                                                                                                                                                                            Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                            computeShiftIncrement.setAccessible(true);
                                                                                                                                                                            computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            org.junit.Assert.assertEquals(5.0, ((Double)tauField.get(eigenDecomposition)).doubleValue(), 0.0);
                                                                                                                                                                            org.junit.Assert.assertEquals(-1, ((Integer)tTypeField.get(eigenDecomposition)).intValue());
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testComputeShiftIncrement_Case() throws Exception {
                                                                                                                                                                            // Create instance with dummy parameters
                                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Set private fields using reflection
                                                                                                                                                                            Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                                            dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                                            
                                                                                                                                                                            Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                            dN2Field.setAccessible(true);
                                                                                                                                                                            dN2Field.set(eigenDecomposition, 10.0);
                                                                                                                                                                            
                                                                                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                                            pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                            
                                                                                                                                                                            Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                            endField.setAccessible(true);
                                                                                                                                                                            endField.set(eigenDecomposition, 10);
                                                                                                                                                                            
                                                                                                                                                                            // Setup work array
                                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            double[] work = new double[100]; // Large enough size
                                                                                                                                                                            workField.set(eigenDecomposition, work);
                                                                                                                                                                            
                                                                                                                                                                            int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                            int np = nn - 2 * 0;
                                                                                                                                                                            work[np - 2] = 5.0;
                                                                                                                                                                            work[np - 6] = 5.0;
                                                                                                                                                                            work[np - 8] = 4.0; // <= b2
                                                                                                                                                                            work[np - 4] = 4.0; // <= b1
                                                                                                                                                                            
                                                                                                                                                                            // Get and invoke private method using reflection
                                                                                                                                                                            Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                            computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                            computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                                                                            assertEquals(-5, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                            
                                                                                                                                                                            Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                                            assertTrue((Double)tauField.get(eigenDecomposition) > 0.0);
                                                                                                                                                                        }

 @Test
                                                                                                                                                            public void testComputeShiftIncrement_Case1() throws Exception {
                                                                                                                                                                // Create instance with dummy parameters
                                                                                                                                                                EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                
                                                                                                                                                                // Set private fields using reflection
                                                                                                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                dMinField.setAccessible(true);
                                                                                                                                                                dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                                
                                                                                                                                                                Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                dN2Field.setAccessible(true);
                                                                                                                                                                dN2Field.set(eigenDecomposition, 10.0);
                                                                                                                                                                
                                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                
                                                                                                                                                                Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                endField.setAccessible(true);
                                                                                                                                                                endField.set(eigenDecomposition, 10);
                                                                                                                                                                
                                                                                                                                                                // Setup work array
                                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                double[] work = new double[100]; // Large enough size
                                                                                                                                                                workField.set(eigenDecomposition, work);
                                                                                                                                                                
                                                                                                                                                                int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                int np = nn - 2 * 0;
                                                                                                                                                                work[np - 2] = 5.0;
                                                                                                                                                                work[np - 6] = 5.0;
                                                                                                                                                                work[np - 8] = 4.0; // <= b2
                                                                                                                                                                work[np - 4] = 4.0; // <= b1
                                                                                                                                                                
                                                                                                                                                                // Get and invoke private method using reflection
                                                                                                                                                                Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                    "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                tTypeField.setAccessible(true);
                                                                                                                                                                assertEquals(-5, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                
                                                                                                                                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                tauField.setAccessible(true);
                                                                                                                                                                assertTrue((Double)tauField.get(eigenDecomposition) > 0.0);
                                                                                                                                                            }

 @Test
                                                                                                                                                            public void testComputeShiftIncrement_Case2() {
                                                                                                                                                                // Initialize eigenDecomposition with required parameters
                                                                                                                                                                double[] main = new double[0];
                                                                                                                                                                double[] secondary = new double[0];
                                                                                                                                                                EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access private fields if needed
                                                                                                                                                                try {
                                                                                                                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                    dMinField.setAccessible(true);
                                                                                                                                                                    dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                                    
                                                                                                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                    pingPongField.setAccessible(true);
                                                                                                                                                                    pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                    
                                                                                                                                                                    Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                    endField.setAccessible(true);
                                                                                                                                                                    endField.set(eigenDecomposition, 10);
                                                                                                                                                                    
                                                                                                                                                                    // Get and invoke the private computeShiftIncrement method
                                                                                                                                                                    Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                        "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                    computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                    computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    fail("Failed to set private fields or invoke method via reflection");
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                try {
                                                                                                                                                                    Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                    tTypeField.setAccessible(true);
                                                                                                                                                                    assertEquals(-12, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                    
                                                                                                                                                                    Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                    tauField.setAccessible(true);
                                                                                                                                                                    assertEquals(0.0, tauField.getDouble(eigenDecomposition), 0.0);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    fail("Failed to verify private fields via reflection");
                                                                                                                                                                }
                                                                                                                                                            }

 @Test
                                                                                                                                                        public void testComputeShiftIncrement_Case3() throws Exception {
                                                                                                                                                            // Create instance with dummy parameters
                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                            
                                                                                                                                                            // Set private fields using reflection
                                                                                                                                                            Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                            dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                            
                                                                                                                                                            Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                            dN2Field.setAccessible(true);
                                                                                                                                                            dN2Field.set(eigenDecomposition, 10.0);
                                                                                                                                                            
                                                                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                            pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                            
                                                                                                                                                            Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                            endField.setAccessible(true);
                                                                                                                                                            endField.set(eigenDecomposition, 10);
                                                                                                                                                            
                                                                                                                                                            // Setup work array
                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                            double[] work = new double[100]; // Large enough size
                                                                                                                                                            workField.set(eigenDecomposition, work);
                                                                                                                                                            
                                                                                                                                                            int nn = 4 * 10 + 0 - 1;
                                                                                                                                                            int np = nn - 2 * 0;
                                                                                                                                                            work[np - 2] = 5.0;
                                                                                                                                                            work[np - 6] = 5.0;
                                                                                                                                                            work[np - 8] = 4.0; // <= b2
                                                                                                                                                            work[np - 4] = 4.0; // <= b1
                                                                                                                                                            
                                                                                                                                                            // Get and invoke private method using reflection
                                                                                                                                                            Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                            computeShiftIncrement.setAccessible(true);
                                                                                                                                                            computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                                                            assertEquals(-5, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                            
                                                                                                                                                            Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                            assertTrue((Double)tauField.get(eigenDecomposition) > 0.0);
                                                                                                                                                        }

 @Test
                                                                                                                                                        public void testComputeShiftIncrement_Case4() {
                                                                                                                                                            // Initialize eigenDecomposition with required parameters
                                                                                                                                                            double[] main = new double[0];
                                                                                                                                                            double[] secondary = new double[0];
                                                                                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private fields if needed
                                                                                                                                                            try {
                                                                                                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                dMinField.setAccessible(true);
                                                                                                                                                                dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                                
                                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                
                                                                                                                                                                Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                endField.setAccessible(true);
                                                                                                                                                                endField.set(eigenDecomposition, 10);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access and invoke private method
                                                                                                                                                                Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                    "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to set private fields or invoke private method via reflection");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            try {
                                                                                                                                                                Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                tTypeField.setAccessible(true);
                                                                                                                                                                assertEquals(-12, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                
                                                                                                                                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                tauField.setAccessible(true);
                                                                                                                                                                assertEquals(0.0, tauField.getDouble(eigenDecomposition), 0.0);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to verify private fields via reflection");
                                                                                                                                                            }
                                                                                                                                                        }

 @Test
                                                                                                                                                    public void testComputeShiftIncrement_Case5() {
                                                                                                                                                        // Initialize eigenDecomposition with required parameters
                                                                                                                                                        double[] main = new double[0];
                                                                                                                                                        double[] secondary = new double[0];
                                                                                                                                                        EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access private fields if needed
                                                                                                                                                        try {
                                                                                                                                                            Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                            dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                            
                                                                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                            pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                            
                                                                                                                                                            Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                            endField.setAccessible(true);
                                                                                                                                                            endField.set(eigenDecomposition, 10);
                                                                                                                                                            
                                                                                                                                                            // Get and invoke the private method
                                                                                                                                                            Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                            computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                            computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Failed to set private fields or invoke private method via reflection");
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        try {
                                                                                                                                                            Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                                                            assertEquals(-12, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                            
                                                                                                                                                            Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                            assertEquals(0.0, tauField.getDouble(eigenDecomposition), 0.0);
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Failed to verify private fields via reflection");
                                                                                                                                                        }
                                                                                                                                                    }

 @Test
                                                                                                                                                public void testComputeShiftIncrement_Case6() {
                                                                                                                                                    // Initialize eigenDecomposition with required parameters
                                                                                                                                                    double[] main = new double[0];
                                                                                                                                                    double[] secondary = new double[0];
                                                                                                                                                    EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access private fields if needed
                                                                                                                                                    try {
                                                                                                                                                        Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                        dMinField.setAccessible(true);
                                                                                                                                                        dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                        
                                                                                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                        pingPongField.setAccessible(true);
                                                                                                                                                        pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                        
                                                                                                                                                        Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                        endField.setAccessible(true);
                                                                                                                                                        endField.set(eigenDecomposition, 10);
                                                                                                                                                        
                                                                                                                                                        // Get and invoke the private method
                                                                                                                                                        Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                            "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                        computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                        computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Failed to set private fields or invoke private method via reflection");
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    try {
                                                                                                                                                        Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                        tTypeField.setAccessible(true);
                                                                                                                                                        assertEquals(-12, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                        
                                                                                                                                                        Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                        tauField.setAccessible(true);
                                                                                                                                                        assertEquals(0.0, tauField.getDouble(eigenDecomposition), 0.0);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Failed to verify private fields via reflection");
                                                                                                                                                    }
                                                                                                                                                }

 @Test
                                                                                                                                            public void testComputeShiftIncrementWithZeroDMin() {
                                                                                                                                                // Setup
                                                                                                                                                EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                
                                                                                                                                                // Use reflection to set private fields since they're not accessible directly
                                                                                                                                                try {
                                                                                                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                    dMinField.setAccessible(true);
                                                                                                                                                    dMinField.set(eigenDecomposition, 0.0);
                                                                                                                                                    
                                                                                                                                                    Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                    tTypeField.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                    tauField.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Call the method
                                                                                                                                                    Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                        "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                    computeShiftIncrement.setAccessible(true);
                                                                                                                                                    computeShiftIncrement.invoke(eigenDecomposition, 0, 0, 0);
                                                                                                                                                    
                                                                                                                                                    // Verify the results
                                                                                                                                                    assertEquals("tType should be -1 when dMin is 0.0", 
                                                                                                                                                        -1, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                    assertEquals("tau should be 0.0 when dMin is 0.0", 
                                                                                                                                                        0.0, tauField.getDouble(eigenDecomposition), 0.0001);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to test computeShiftIncrement due to reflection issues: " + e.getMessage());
                                                                                                                                                }
                                                                                                                                            }

 @Test
                                                                                                                                           public void testComputeShiftIncrementDetectsSqrtMutation() {
                                                                                                                                               // Setup test data that will trigger the case where b1 is calculated
                                                                                                                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[]{0.5}, 1.0e-6);
                                                                                                                                               
                                                                                                                                               // Set up work array with values that will show difference between sqrt and non-sqrt
                                                                                                                                               // Using reflection to access private fields since the method is private
                                                                                                                                               try {
                                                                                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                   workField.setAccessible(true);
                                                                                                                                                   double[] work = new double[20];
                                                                                                                                                   // Set values that will show the difference (4 and 9 chosen because sqrt(4)*sqrt(9)=6 vs 4*9=36)
                                                                                                                                                   work[4] = 4.0;  // nn-3 when nn=7 (4*1 + 1 -1 = 4)
                                                                                                                                                   work[2] = 9.0;  // nn-5 when nn=7
                                                                                                                                                   workField.set(eigen, work);
                                                                                                                                                   
                                                                                                                                                   Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                   dMinField.setAccessible(true);
                                                                                                                                                   dMinField.set(eigen, 1.0);
                                                                                                                                                   
                                                                                                                                                   Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                   dNField.setAccessible(true);
                                                                                                                                                   dNField.set(eigen, 1.0);
                                                                                                                                                   
                                                                                                                                                   Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                   dN1Field.setAccessible(true);
                                                                                                                                                   dN1Field.set(eigen, 1.0);
                                                                                                                                                   
                                                                                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                                   pingPongField.set(eigen, 1);
                                                                                                                                                   
                                                                                                                                                   // Get the method via reflection
                                                                                                                                                   Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                       int.class, int.class, int.class);
                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                   
                                                                                                                                                   // Invoke the method (start=0, end=1, deflated=0)
                                                                                                                                                   method.invoke(eigen, 0, 1, 0);
                                                                                                                                                   
                                                                                                                                                   // Get the tau value
                                                                                                                                                   Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                   tauField.setAccessible(true);
                                                                                                                                                   double tau = tauField.getDouble(eigen);
                                                                                                                                                   
                                                                                                                                                   // Verify the tau value is calculated correctly with sqrt
                                                                                                                                                   // The exact expected value depends on the full calculation, but we know it should
                                                                                                                                                   // be based on b1=6 (sqrt(4)*sqrt(9)) not 36 (4*9)
                                                                                                                                                   // For these values, original calculation should give tau ≈ 0.5
                                                                                                                                                   // while mutated version would give a much larger value
                                                                                                                                                   assertEquals(0.5, tau, 0.1);
                                                                                                                                                   
                                                                                                                                               } catch (Exception e) {
                                                                                                                                                   fail("Failed to test private method via reflection: " + e.getMessage());
                                                                                                                                               }
                                                                                                                                           }

 @Test
                                                                                                                                         public void testComputeShiftIncrement_Gap1Calculation() throws Exception {
                                                                                                                                             // Setup test case where 0 < gap2 <= b2 to detect the mutant
                                                                                                                                             EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{0.0}, new double[]{0.0}, 1.0);
                                                                                                                                             
                                                                                                                                             // Use reflection to access private fields
                                                                                                                                             Class<?> clazz = decomposition.getClass();
                                                                                                                                             
                                                                                                                                             // Set up the case where dMin == dN && dMin1 == dN1 (case 2/3)
                                                                                                                                             Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                             dMinField.setAccessible(true);
                                                                                                                                             dMinField.set(decomposition, 1.0);
                                                                                                                                             
                                                                                                                                             Field dNField = clazz.getDeclaredField("dN");
                                                                                                                                             dNField.setAccessible(true);
                                                                                                                                             dNField.set(decomposition, 1.0);
                                                                                                                                             
                                                                                                                                             Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                             dMin1Field.setAccessible(true);
                                                                                                                                             dMin1Field.set(decomposition, 1.0);
                                                                                                                                             
                                                                                                                                             Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                                                             dN1Field.setAccessible(true);
                                                                                                                                             dN1Field.set(decomposition, 1.0);
                                                                                                                                             
                                                                                                                                             Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                             dMin2Field.setAccessible(true);
                                                                                                                                             dMin2Field.set(decomposition, 4.0); // gap2 = 4.0 - 2.0 - 1.0 = 1.0
                                                                                                                                             
                                                                                                                                             // Setup work array values to create scenario where 0 < gap2 <= b2
                                                                                                                                             Field workField = clazz.getDeclaredField("work");
                                                                                                                                             workField.setAccessible(true);
                                                                                                                                             double[] work = new double[20]; // large enough array
                                                                                                                                             work[0] = 1.0; // nn-3 (0)
                                                                                                                                             work[2] = 1.0; // nn-5 (2)
                                                                                                                                             work[4] = 1.0; // nn-7 (4)
                                                                                                                                             work[6] = 1.0; // nn-9 (6)
                                                                                                                                             workField.set(decomposition, work);
                                                                                                                                             
                                                                                                                                             // Call the private method using reflection
                                                                                                                                             Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                             computeShiftIncrement.setAccessible(true);
                                                                                                                                             computeShiftIncrement.invoke(decomposition, 0, 1, 0); // start=0, end=1, deflated=0
                                                                                                                                             
                                                                                                                                             // Verify the tType is set correctly
                                                                                                                                             Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                             tTypeField.setAccessible(true);
                                                                                                                                             int tType = (int) tTypeField.get(decomposition);
                                                                                                                                             
                                                                                                                                             assertTrue("Test should detect mutant by verifying correct code path", 
                                                                                                                                                        tType == -2 || tType == -3);
                                                                                                                                         }

 @Test
                                                                                                                                     public void testComputeShiftIncrement_MutantDetection() {
                                                                                                                                         // Setup test data to hit the specific case with mutated code
                                                                                                                                         EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                         
                                                                                                                                         // Use reflection to set private fields since we need specific conditions
                                                                                                                                         try {
                                                                                                                                             Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                             dMinField.setAccessible(true);
                                                                                                                                             dMinField.set(decomposition, 3.0);  // Set dMin to 3.0
                                                                                                                                             
                                                                                                                                             Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                             dNField.setAccessible(true);
                                                                                                                                             dNField.set(decomposition, 3.0);    // Set dN to same as dMin
                                                                                                                                             
                                                                                                                                             Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                             dMin1Field.setAccessible(true);
                                                                                                                                             dMin1Field.set(decomposition, 2.0);
                                                                                                                                             
                                                                                                                                             Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                             dN1Field.setAccessible(true);
                                                                                                                                             dN1Field.set(decomposition, 2.0);   // Set dMin1 == dN1
                                                                                                                                             
                                                                                                                                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                             workField.setAccessible(true);
                                                                                                                                             double[] work = new double[20];
                                                                                                                                             // Setup work array values to ensure we take the desired path
                                                                                                                                             work[16] = 1.0;  // nn-3 (nn=4*end + pingPong -1, assuming end=4, pingPong=0)
                                                                                                                                             work[14] = 1.0;  // nn-5
                                                                                                                                             work[12] = 1.0;  // nn-7
                                                                                                                                             work[10] = 1.0;  // nn-9
                                                                                                                                             workField.set(decomposition, work);
                                                                                                                                             
                                                                                                                                             Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                             endField.setAccessible(true);
                                                                                                                                             endField.set(decomposition, 4);
                                                                                                                                             
                                                                                                                                             // Call the method with deflated=0 to hit case 0
                                                                                                                                             Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                 int.class, int.class, int.class);
                                                                                                                                             method.setAccessible(true);
                                                                                                                                             method.invoke(decomposition, 0, 4, 0);
                                                                                                                                             
                                                                                                                                             // Verify tau value - this is where the mutant would fail
                                                                                                                                             Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                             tauField.setAccessible(true);
                                                                                                                                             double tau = tauField.getDouble(decomposition);
                                                                                                                                             
                                                                                                                                             // Original code would give 0.333*3.0=0.999, mutant gives 0.5*3.0=1.5
                                                                                                                                             // We set s to be between these values (1.0) to detect the difference
                                                                                                                                             assertEquals(1.0, tau, 1e-10);  // Should be max(s, 0.333*dMin) = max(1.0, 0.999) = 1.0
                                                                                                                                             // Mutant would give max(1.0, 1.5) = 1.5 which would fail this assertion
                                                                                                                                             
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                         }
                                                                                                                                     }

 @Test
                                                                                                                                   public void testComputeShiftIncrement_DetectMutant_WorkElementsEqual() throws Exception {
                                                                                                                                       // Setup test case for case 4 where work[nn-5] equals work[nn-7]
                                                                                                                                       EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 1.0}, new double[]{1.0}, 1.0e-10);
                                                                                                                                       
                                                                                                                                       // Use reflection to access private fields
                                                                                                                                       Class<?> clazz = decomposition.getClass();
                                                                                                                                       Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                       dMinField.setAccessible(true);
                                                                                                                                       Field dNField = clazz.getDeclaredField("dN");
                                                                                                                                       dNField.setAccessible(true);
                                                                                                                                       Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                       dMin1Field.setAccessible(true);
                                                                                                                                       Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                       Field workField = clazz.getDeclaredField("work");
                                                                                                                                       workField.setAccessible(true);
                                                                                                                                       Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                       tTypeField.setAccessible(true);
                                                                                                                                       Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                       tauField.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Set up the state for case 4
                                                                                                                                       dMinField.setDouble(decomposition, 1.0);
                                                                                                                                       dNField.setDouble(decomposition, 1.0);
                                                                                                                                       dMin1Field.setDouble(decomposition, 2.0); // different from dN1 to avoid other cases
                                                                                                                                       int end = 10;
                                                                                                                                       pingPongField.setInt(decomposition, 0);
                                                                                                                                       int deflated = 0;
                                                                                                                                       
                                                                                                                                       // Create work array where work[nn-5] equals work[nn-7]
                                                                                                                                       int nn = 4 * end + (Integer)pingPongField.get(decomposition) - 1; // nn = 39
                                                                                                                                       double[] work = new double[40]; // work indices up to 39
                                                                                                                                       work[nn - 5] = 2.0; // work[34]
                                                                                                                                       work[nn - 7] = 2.0; // work[32]
                                                                                                                                       
                                                                                                                                       // Set other required work elements
                                                                                                                                       work[nn - 3] = 1.0;
                                                                                                                                       work[nn - 9] = 1.0;
                                                                                                                                       workField.set(decomposition, work);
                                                                                                                                       
                                                                                                                                       // Call the private method using reflection
                                                                                                                                       Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                       computeShiftIncrement.setAccessible(true);
                                                                                                                                       computeShiftIncrement.invoke(decomposition, 0, 10, 0);
                                                                                                                                       
                                                                                                                                       // Verify the method didn't return early (would happen with mutant)
                                                                                                                                       // In original code, it should continue and set tType to -4
                                                                                                                                       assertEquals(-4, tTypeField.getInt(decomposition));
                                                                                                                                       
                                                                                                                                       // Additional verification that calculations continued
                                                                                                                                       assertNotEquals(0.0, tauField.getDouble(decomposition));
                                                                                                                                   }

 @Test
                                                                                                                               public void testComputeShiftIncrementDetectsMutantInLoopCondition() {
                                                                                                                                   // Setup test case where one condition is true and other is false
                                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 2, 3}, new double[]{0.5, 0.6}, 1.0e-12);
                                                                                                                                   
                                                                                                                                   // Use reflection to set private fields needed for the test
                                                                                                                                   try {
                                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                       workField.setAccessible(true);
                                                                                                                                       double[] work = new double[100];
                                                                                                                                       
                                                                                                                                       // Setup values that will make 100*Math.max(b2,b1) < a2 true but cnst1 < a2 false
                                                                                                                                       // cnst1 is 0.563, so we need a2 between 0.563 and whatever makes 100*max(b2,b1) < a2
                                                                                                                                       work[87] = 0.01;  // nn-13 when pingPong=0, end=20
                                                                                                                                       work[85] = 0.01;  // nn-15
                                                                                                                                       work[83] = 0.01;  // nn-17
                                                                                                                                       
                                                                                                                                       workField.set(eigen, work);
                                                                                                                                       
                                                                                                                                       Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                       dMinField.setAccessible(true);
                                                                                                                                       dMinField.set(eigen, 1.0);
                                                                                                                                       
                                                                                                                                       Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                       dNField.setAccessible(true);
                                                                                                                                       dNField.set(eigen, 1.0);
                                                                                                                                       
                                                                                                                                       Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                       dN1Field.setAccessible(true);
                                                                                                                                       dN1Field.set(eigen, 1.0);
                                                                                                                                       
                                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                       pingPongField.set(eigen, 0);
                                                                                                                                       
                                                                                                                                       // Call the method - case 4 will be executed
                                                                                                                                       Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                           int.class, int.class, int.class);
                                                                                                                                       method.setAccessible(true);
                                                                                                                                       method.invoke(eigen, 0, 20, 0);
                                                                                                                                       
                                                                                                                                       // Verify results - mutant would behave differently
                                                                                                                                       Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                       tauField.setAccessible(true);
                                                                                                                                       double tau = tauField.getDouble(eigen);
                                                                                                                                       
                                                                                                                                       Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                       tTypeField.setAccessible(true);
                                                                                                                                       int tType = tTypeField.getInt(eigen);
                                                                                                                                       
                                                                                                                                       // Original would break loop earlier and get different tau/tType
                                                                                                                                       assertTrue("Mutant not detected - tau value incorrect", tau > 0);
                                                                                                                                       assertEquals("Mutant not detected - tType value incorrect", -4, tType);
                                                                                                                                       
                                                                                                                                   } catch (Exception e) {
                                                                                                                                       fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                   }
                                                                                                                               }

 @Test
                                                                                                                              public void testComputeShiftIncrementCase4DetectsMutant() {
                                                                                                                                  // Setup test data for case 4 (tType = -4)
                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                  
                                                                                                                                  // Use reflection to set private fields since we need to test a private method
                                                                                                                                  try {
                                                                                                                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                      dMinField.setAccessible(true);
                                                                                                                                      dMinField.set(eigen, 1.0); // dMin > 0
                                                                                                                                      
                                                                                                                                      Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                      dNField.setAccessible(true);
                                                                                                                                      dNField.set(eigen, 1.0); // dMin == dN
                                                                                                                                      
                                                                                                                                      Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                      dMin1Field.setAccessible(true);
                                                                                                                                      dMin1Field.set(eigen, 2.0); // dMin1 != dN1
                                                                                                                                      
                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                      workField.setAccessible(true);
                                                                                                                                      double[] work = new double[20];
                                                                                                                                      // Setup work array values to trigger the specific path
                                                                                                                                      work[11] = 1.0; // nn-9 (when nn=20)
                                                                                                                                      work[13] = 2.0; // nn-7
                                                                                                                                      work[15] = 1.5; // nn-5
                                                                                                                                      workField.set(eigen, work);
                                                                                                                                      
                                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                      pingPongField.set(eigen, 0);
                                                                                                                                      
                                                                                                                                      Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                      endField.setAccessible(true);
                                                                                                                                      endField.set(eigen, 5); // nn = 4*5 + 0 - 1 = 19
                                                                                                                                      
                                                                                                                                      // Invoke the method
                                                                                                                                      Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                          int.class, int.class, int.class);
                                                                                                                                      method.setAccessible(true);
                                                                                                                                      method.invoke(eigen, 0, 5, 0); // deflated = 0
                                                                                                                                      
                                                                                                                                      // Verify results
                                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                      double tau = tauField.getDouble(eigen);
                                                                                                                                      
                                                                                                                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                      int tType = tTypeField.getInt(eigen);
                                                                                                                                      
                                                                                                                                      // The mutation would affect tau calculation
                                                                                                                                      // Original tau should be approximately 0.25 (case 4)
                                                                                                                                      // With mutation, it would be different
                                                                                                                                      assertEquals(-4, tType);
                                                                                                                                      assertEquals(0.25, tau, 0.01); // Verify against expected value
                                                                                                                                      
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed due to reflection exception: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

 @Test
                                                                                                                        public void testComputeShiftIncrementDetectsMutantInCase5Condition() throws Exception {
                                                                                                                            // Setup test case for deflated=0, dMin=dN2 (case 5)
                                                                                                                            // where work[np-8] > b2 is true but work[np-4] > b1 is false
                                                                                                                            
                                                                                                                            // Create instance and set required fields
                                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                            
                                                                                                                            // Get field references via reflection
                                                                                                                            Class<?> clazz = eigen.getClass();
                                                                                                                            Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                            dMinField.setAccessible(true);
                                                                                                                            Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                            dN2Field.setAccessible(true);
                                                                                                                            Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                            Field workField = clazz.getDeclaredField("work");
                                                                                                                            workField.setAccessible(true);
                                                                                                                            Field tauField = clazz.getDeclaredField("tau");
                                                                                                                            tauField.setAccessible(true);
                                                                                                                            Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                            
                                                                                                                            // Set deflated=0 (first case in switch)
                                                                                                                            int deflated = 0;
                                                                                                                            
                                                                                                                            // Set dMin = dN2 to trigger case 5
                                                                                                                            dMinField.setDouble(eigen, 5.0);
                                                                                                                            dN2Field.setDouble(eigen, 5.0);
                                                                                                                            
                                                                                                                            // Set pingPong and end to calculate np
                                                                                                                            pingPongField.setInt(eigen, 1);
                                                                                                                            int end = 10;
                                                                                                                            int nn = 4 * end + (Integer)pingPongField.get(eigen) - 1; // nn = 40
                                                                                                                            
                                                                                                                            // Create work array with specific values
                                                                                                                            double[] work = new double[nn];
                                                                                                                            workField.set(eigen, work);
                                                                                                                            
                                                                                                                            // np = nn - 2*pingPong = 40 - 2 = 38
                                                                                                                            // Set b1 = work[np-2] = work[36]
                                                                                                                            // Set b2 = work[np-6] = work[32]
                                                                                                                            work[36] = 10.0; // b1
                                                                                                                            work[32] = 10.0; // b2
                                                                                                                            
                                                                                                                            // Set work[np-8] (work[30]) > b2 (10.0)
                                                                                                                            work[30] = 11.0;
                                                                                                                            
                                                                                                                            // Set work[np-4] (work[34]) <= b1 (10.0)
                                                                                                                            work[34] = 9.0;
                                                                                                                            
                                                                                                                            // Set initial tau to detect if method returns early
                                                                                                                            tauField.setDouble(eigen, -1.0);
                                                                                                                            
                                                                                                                            // Call private method via reflection
                                                                                                                            Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                            computeShiftIncrement.setAccessible(true);
                                                                                                                            computeShiftIncrement.invoke(eigen, 0, end, deflated);
                                                                                                                            
                                                                                                                            // Verify - original would return early (tau remains -1), mutant would continue and modify tau
                                                                                                                            // Since we want to detect the mutant, we assert that tau is still -1 (original behavior)
                                                                                                                            assertEquals("Tau should remain unchanged as original code should return early", 
                                                                                                                                        -1.0, (Double)tauField.get(eigen), 0.0001);
                                                                                                                            
                                                                                                                            // Also verify tType remains unchanged (wasn't set in this path)
                                                                                                                            assertEquals("tType should remain unchanged", 
                                                                                                                                        0, (Integer)tTypeField.get(eigen), 0);
                                                                                                                        }

 @Test
                                                                                                       public void testComputeShiftIncrementCase6WithTypeMinus() {
                                                                                                           // Setup test conditions to reach case 6 with tType == -6
                                                                                                           EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                                                                                                               new double[]{1.0, 2.0, 3.0},  // main diagonal
                                                                                                               new double[]{0.5, 0.5},       // secondary diagonal
                                                                                                               1.0e-10                       // split tolerance
                                                                                                           );
                                                                                                           
                                                                                                           try {
                                                                                                               // Set required fields to reach the target case using reflection
                                                                                                               Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                               dMinField.setAccessible(true);
                                                                                                               dMinField.set(decomposition, 1.0);  // Must be positive to avoid early return
                                                                                                               
                                                                                                               Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                               tTypeField.setAccessible(true);
                                                                                                               tTypeField.setInt(decomposition, -6);  // Force case 6 with tType == -6
                                                                                                               
                                                                                                               Field gField = EigenDecompositionImpl.class.getDeclaredField("g");
                                                                                                               gField.setAccessible(true);
                                                                                                               gField.setDouble(decomposition, 0.5);  // Initialize g to known value
                                                                                                               
                                                                                                               // Calculate expected value based on original behavior
                                                                                                               double expectedG = 0.5 + 0.333 * (1 - 0.5);  // Original g += operation
                                                                                                               double expectedTau = expectedG * (Double)dMinField.get(decomposition);
                                                                                                               
                                                                                                               // Use reflection to access private method
                                                                                                               Method method = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                   "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                               method.setAccessible(true);
                                                                                                               method.invoke(decomposition, 0, 2, 0);  // start=0, end=2, deflated=0
                                                                                                               
                                                                                                               // Verify g was updated correctly
                                                                                                               org.junit.Assert.assertEquals("g should be increased by 0.333*(1-g)", 
                                                                                                                   expectedG, (Double)gField.get(decomposition), 1.0e-10);
                                                                                                               
                                                                                                               // Verify tau was calculated correctly
                                                                                                               Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                               tauField.setAccessible(true);
                                                                                                               org.junit.Assert.assertEquals("tau should be g*dMin", 
                                                                                                                   expectedTau, (Double)tauField.get(decomposition), 1.0e-10);
                                                                                                               
                                                                                                               // Verify tType remains -6
                                                                                                               org.junit.Assert.assertEquals("tType should remain -6", 
                                                                                                                   -6, tTypeField.getInt(decomposition));
                                                                                                                   
                                                                                                           } catch (Exception e) {
                                                                                                               org.junit.Assert.fail("Failed to access or invoke computeShiftIncrement: " + e.getMessage());
                                                                                                           }
                                                                                                       }

 @Test
                                                                                                  public void testComputeShiftIncrementDetectsSqrtMutation1() throws Exception {
                                                                                                      // Setup test case for case 7 where the mutation occurs
                                                                                                      EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                                                                                                          new double[]{1.0, 2.0, 3.0, 4.0}, 
                                                                                                          new double[]{0.5, 1.5, 2.5}, 
                                                                                                          0.0);
                                                                                                      
                                                                                                      // Use reflection to set private fields
                                                                                                      Class<?> clazz = decomposition.getClass();
                                                                                                      
                                                                                                      // Set up the state to trigger case 7
                                                                                                      Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                      dMin1Field.setAccessible(true);
                                                                                                      dMin1Field.set(decomposition, 1.0);
                                                                                                      
                                                                                                      Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                      dMin2Field.setAccessible(true);
                                                                                                      dMin2Field.set(decomposition, 1.0);
                                                                                                      
                                                                                                      Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                      dN1Field.setAccessible(true);
                                                                                                      dN1Field.set(decomposition, 1.0);
                                                                                                      
                                                                                                      Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                      dN2Field.setAccessible(true);
                                                                                                      dN2Field.set(decomposition, 1.0);
                                                                                                      
                                                                                                      Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                      pingPongField.setAccessible(true);
                                                                                                      pingPongField.set(decomposition, 0);
                                                                                                      
                                                                                                      // Create work array with values that will trigger the b2 calculation
                                                                                                      Field workField = clazz.getDeclaredField("work");
                                                                                                      workField.setAccessible(true);
                                                                                                      double[] work = new double[4 * 4 + 0 - 1]; // nn = 4*end + pingPong - 1 = 15
                                                                                                      work[15 - 5] = 4.0; // work[nn-5]
                                                                                                      work[15 - 7] = 2.0; // work[nn-7]
                                                                                                      workField.set(decomposition, work);
                                                                                                      
                                                                                                      // Calculate expected values
                                                                                                      double expectedB1 = 4.0 / 2.0; // work[nn-5]/work[nn-7]
                                                                                                      double expectedB2 = expectedB1;
                                                                                                      // Original would do: b2 = Math.sqrt(cnst3 * b2)
                                                                                                      double expectedOriginalB2 = Math.sqrt(1.05 * expectedB2);
                                                                                                      double expectedA2 = 1.0 / (1 + expectedOriginalB2 * expectedOriginalB2);
                                                                                                      double expectedGap2 = 0.5 * 1.0 - expectedA2;
                                                                                                      double expectedTau;
                                                                                                      if (expectedGap2 > 0.0 && expectedGap2 > expectedOriginalB2 * expectedA2) {
                                                                                                          expectedTau = Math.max(0.333 * 1.0, 
                                                                                                              expectedA2 * (1 - 1.010 * expectedA2 * (expectedOriginalB2 / expectedGap2) * expectedOriginalB2));
                                                                                                      } else {
                                                                                                          expectedTau = Math.max(0.333 * 1.0, expectedA2 * (1 - 1.010 * expectedOriginalB2));
                                                                                                      }
                                                                                                      
                                                                                                      // Call the private method using reflection
                                                                                                      Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                      computeShiftIncrement.setAccessible(true);
                                                                                                      computeShiftIncrement.invoke(decomposition, 0, 4, 1);
                                                                                                      
                                                                                                      // Verify the results using reflection
                                                                                                      Field tauField = clazz.getDeclaredField("tau");
                                                                                                      tauField.setAccessible(true);
                                                                                                      double actualTau = (Double)tauField.get(decomposition);
                                                                                                      
                                                                                                      Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                      tTypeField.setAccessible(true);
                                                                                                      int actualTType = (Integer)tTypeField.get(decomposition);
                                                                                                      
                                                                                                      assertEquals("Tau should match expected calculation with sqrt", 
                                                                                                                  expectedTau, actualTau, 1e-10);
                                                                                                      assertEquals("Type should be -7 for this case", 
                                                                                                                  -7, actualTType);
                                                                                                  }

 @Test
                                                                                             public void testComputeShiftIncrementDetectsMutatedCondition() throws Exception {
                                                                                                 // Setup test case where dMin2 != dN2 but 2*work[nn-5] < work[nn-7]
                                                                                                 EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                 
                                                                                                 // Helper method to set private fields
                                                                                                 Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                 dMin2Field.setAccessible(true);
                                                                                                 dMin2Field.set(decomposition, 1.0);
                                                                                                 
                                                                                                 Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                 dN2Field.setAccessible(true);
                                                                                                 dN2Field.set(decomposition, 2.0); // dMin2 != dN2
                                                                                                 
                                                                                                 Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                 deflatedField.setAccessible(true);
                                                                                                 deflatedField.set(decomposition, 2); // case 2 in switch
                                                                                                 
                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                 pingPongField.setAccessible(true);
                                                                                                 pingPongField.set(decomposition, 0);
                                                                                                 
                                                                                                 Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                 endField.setAccessible(true);
                                                                                                 endField.set(decomposition, 10); // nn = 4*10 + 0 - 1 = 39
                                                                                                 
                                                                                                 Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                 startField.setAccessible(true);
                                                                                                 startField.set(decomposition, 0);
                                                                                                 
                                                                                                 // Setup work array where 2*work[34] < work[32]
                                                                                                 double[] work = new double[40];
                                                                                                 work[34] = 5.0; // nn-5 = 34
                                                                                                 work[32] = 11.0; // nn-7 = 32 (2*5 < 11 is true)
                                                                                                 
                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                 workField.setAccessible(true);
                                                                                                 workField.set(decomposition, work);
                                                                                                 
                                                                                                 // Call the private method via reflection
                                                                                                 Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                     "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                 computeShiftIncrement.invoke(decomposition, 0, 10, 2);
                                                                                                 
                                                                                                 // Verify tType is -11 (would be -10 if mutant was active)
                                                                                                 Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                 tTypeField.setAccessible(true);
                                                                                                 assertEquals(-11, tTypeField.getInt(decomposition));
                                                                                             }

 @Test
                                                                                         public void testComputeShiftIncrement_DefaultCase() {
                                                                                             // Setup test data to trigger default case (deflated > 2)
                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1.0}, new double[]{0.5}, 1.0e-10);
                                                                                             
                                                                                             // Use reflection to set private fields needed for the test
                                                                                             try {
                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                 workField.setAccessible(true);
                                                                                                 workField.set(eigen, new double[100]); // large enough work array
                                                                                                 
                                                                                                 Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                 deflatedField.setAccessible(true);
                                                                                                 deflatedField.setInt(eigen, 3); // force default case
                                                                                                 
                                                                                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                 dMinField.setAccessible(true);
                                                                                                 dMinField.setDouble(eigen, 1.0); // arbitrary value
                                                                                                 
                                                                                                 Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                 tTypeField.setAccessible(true);
                                                                                                 tTypeField.setInt(eigen, -12); // matches default case
                                                                                                 
                                                                                                 // Call the method
                                                                                                 Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                     "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                 computeShiftIncrement.invoke(eigen, 0, 10, 3); // start=0, end=10, deflated=3
                                                                                                 
                                                                                                 // Verify tau was set to 0.0 (original behavior)
                                                                                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                 tauField.setAccessible(true);
                                                                                                 double tau = tauField.getDouble(eigen);
                                                                                                 
                                                                                                 assertEquals(0.0, tau, 1.0e-15); // This will fail if mutant is present (tau=1.0)
                                                                                                 
                                                                                             } catch (Exception e) {
                                                                                                 fail("Failed to test computeShiftIncrement due to reflection issues: " + e.getMessage());
                                                                                             }
                                                                                         }

 @Test
                                                                                        public void testComputeShiftIncrementWithZeroDMin1() {
                                                                                            // Setup test object and required state
                                                                                            EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{1.0}, new double[]{1.0}, 1.0e-6);
                                                                                            
                                                                                            // Use reflection to set private fields since we need to test a private method
                                                                                            try {
                                                                                                // Set dMin to 0.0 which is the boundary case
                                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                dMinField.setAccessible(true);
                                                                                                dMinField.set(eigenDecomposition, 0.0);
                                                                                                
                                                                                                // Set other required fields to avoid NPEs
                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                workField.setAccessible(true);
                                                                                                workField.set(eigenDecomposition, new double[100]);
                                                                                                
                                                                                                Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                endField.setAccessible(true);
                                                                                                endField.set(eigenDecomposition, 10);
                                                                                                
                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                pingPongField.setAccessible(true);
                                                                                                pingPongField.set(eigenDecomposition, 0);
                                                                                                
                                                                                                // Get the method to test
                                                                                                Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                    "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                computeShiftIncrement.setAccessible(true);
                                                                                                
                                                                                                // Invoke the method
                                                                                                computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                
                                                                                                // Verify results
                                                                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                tauField.setAccessible(true);
                                                                                                double tau = tauField.getDouble(eigenDecomposition);
                                                                                                
                                                                                                Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                tTypeField.setAccessible(true);
                                                                                                int tType = tTypeField.getInt(eigenDecomposition);
                                                                                                
                                                                                                // Original code should set tau to -dMin (0.0) and tType to -1
                                                                                                assertEquals("tau should be 0.0 when dMin is 0.0", 0.0, tau, 1.0e-12);
                                                                                                assertEquals("tType should be -1 when dMin is 0.0", -1, tType);
                                                                                                
                                                                                            } catch (Exception e) {
                                                                                                fail("Exception during test: " + e.getMessage());
                                                                                            }
                                                                                        }

 @Test
                                                                                      public void testComputeShiftIncrementDetectsSqrtMutation2() throws Exception {
                                                                                          // Setup
                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                          
                                                                                          // Set values that will make the mutation obvious
                                                                                          // Using values where product is much larger than product of square roots
                                                                                          double val1 = 16.0; // sqrt(16)=4
                                                                                          double val2 = 25.0; // sqrt(25)=5
                                                                                          // Original: 4*5=20, Mutated: 16*25=400
                                                                                          
                                                                                          // Set up work array to trigger the right case
                                                                                          int nn = 4 * 10 + 0 - 1; // end=10, pingPong=0
                                                                                          double[] work = new double[nn + 1];
                                                                                          work[nn - 3] = val1;
                                                                                          work[nn - 5] = val2;
                                                                                          work[nn - 7] = 1.0; // dummy values for other required elements
                                                                                          work[nn - 9] = 1.0;
                                                                                          
                                                                                          // Use reflection to set private fields
                                                                                          Class<?> clazz = eigen.getClass();
                                                                                          
                                                                                          // Set work array
                                                                                          Field workField = clazz.getDeclaredField("work");
                                                                                          workField.setAccessible(true);
                                                                                          workField.set(eigen, work);
                                                                                          
                                                                                          // Set other required fields
                                                                                          Field dMinField = clazz.getDeclaredField("dMin");
                                                                                          dMinField.setAccessible(true);
                                                                                          dMinField.set(eigen, 1.0);
                                                                                          
                                                                                          Field dNField = clazz.getDeclaredField("dN");
                                                                                          dNField.setAccessible(true);
                                                                                          dNField.set(eigen, 1.0);
                                                                                          
                                                                                          Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                          dN1Field.setAccessible(true);
                                                                                          dN1Field.set(eigen, 1.0);
                                                                                          
                                                                                          Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                          dMin1Field.setAccessible(true);
                                                                                          dMin1Field.set(eigen, 1.0);
                                                                                          
                                                                                          Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                          dMin2Field.setAccessible(true);
                                                                                          dMin2Field.set(eigen, 1.0);
                                                                                          
                                                                                          Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                          pingPongField.setAccessible(true);
                                                                                          pingPongField.set(eigen, 0);
                                                                                          
                                                                                          // Execute private method
                                                                                          Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                          computeShiftIncrement.setAccessible(true);
                                                                                          computeShiftIncrement.invoke(eigen, 0, 10, 0); // start=0, end=10, deflated=0
                                                                                          
                                                                                          // Verify results using reflection
                                                                                          Field tauField = clazz.getDeclaredField("tau");
                                                                                          tauField.setAccessible(true);
                                                                                          double tau = (Double) tauField.get(eigen);
                                                                                          assertEquals(0.5, tau, 0.0001);
                                                                                          
                                                                                          Field tTypeField = clazz.getDeclaredField("tType");
                                                                                          tTypeField.setAccessible(true);
                                                                                          int tType = (Integer) tTypeField.get(eigen);
                                                                                          assertEquals(-2, tType);
                                                                                      }

 @Test
                                                                                 public void testComputeShiftIncrementDetectsMutant() {
                                                                                     // Setup test case where gap2 > 0.0 but gap2 <= b2
                                                                                     // This will expose the && vs || mutation
                                                                                     EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                                                                                         new double[] {1.0, 2.0, 3.0, 4.0}, 
                                                                                         new double[] {0.5, 1.5, 2.5}, 
                                                                                         0.0);
                                                                                     
                                                                                     // Set up conditions for case 2/3 where dMin == dN && dMin1 == dN1
                                                                                     // Using reflection to set private fields since they're needed for the computation
                                                                                     try {
                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                         workField.setAccessible(true);
                                                                                         double[] work = new double[100];
                                                                                         
                                                                                         // Setup values so that:
                                                                                         // - dMin == dN (case 2/3)
                                                                                         // - gap2 > 0.0 but gap2 <= b2
                                                                                         // - a2 - dN - (b1 + b2) will be different from a2 - dN - (b2/gap2)*b2
                                                                                         work[0] = 1.0;  // dMin
                                                                                         work[1] = 1.0;  // dN
                                                                                         work[2] = 1.0;  // dMin1
                                                                                         work[3] = 1.0;  // dN1
                                                                                         work[4] = 2.0;  // dMin2
                                                                                         
                                                                                         // Values for nn-3 to nn-9 (positions 96 to 90 in 100-element array)
                                                                                         // Setup so that:
                                                                                         // gap2 = dMin2 - a2 - dMin2*0.25 > 0.0
                                                                                         // but gap2 <= b2
                                                                                         work[90] = 1.0;  // work[nn-9] - affects b2 calculation
                                                                                         work[92] = 1.0;  // work[nn-7] - affects b2 and a2
                                                                                         work[94] = 1.0;  // work[nn-5] - affects b1
                                                                                         work[96] = 1.0;  // work[nn-3] - affects b1
                                                                                         
                                                                                         workField.set(decomposition, work);
                                                                                         
                                                                                         Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                         dMinField.setAccessible(true);
                                                                                         dMinField.set(decomposition, 1.0);
                                                                                         
                                                                                         Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                         dNField.setAccessible(true);
                                                                                         dNField.set(decomposition, 1.0);
                                                                                         
                                                                                         Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                         dMin1Field.setAccessible(true);
                                                                                         dMin1Field.set(decomposition, 1.0);
                                                                                         
                                                                                         Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                         dN1Field.setAccessible(true);
                                                                                         dN1Field.set(decomposition, 1.0);
                                                                                         
                                                                                         Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                         dMin2Field.setAccessible(true);
                                                                                         dMin2Field.set(decomposition, 2.0);
                                                                                         
                                                                                         Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                         endField.setAccessible(true);
                                                                                         endField.setInt(decomposition, 25);  // nn = 4*25 + 0 - 1 = 99
                                                                                         
                                                                                         // Call the method
                                                                                         Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                             "computeShiftIncrement", int.class, int.class, int.class);
                                                                                         computeShiftIncrement.setAccessible(true);
                                                                                         computeShiftIncrement.invoke(decomposition, 0, 25, 0);
                                                                                         
                                                                                         // Verify results
                                                                                         Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                         tauField.setAccessible(true);
                                                                                         double tau = tauField.getDouble(decomposition);
                                                                                         
                                                                                         Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                         tTypeField.setAccessible(true);
                                                                                         int tType = tTypeField.getInt(decomposition);
                                                                                         
                                                                                         // With original code, should get one value
                                                                                         // With mutant, will get different value because it takes different branch
                                                                                         // We know original should take else branch (b1 + b2)
                                                                                         // So we can assert expected tau based on that path
                                                                                         double expectedTau = Math.max(1.0 - (1.0 / (2.0 - 1.0 - (1.0 + 1.0))) * 1.0, 0.5 * 1.0);
                                                                                         assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                                         assertEquals("tType should be -2 for this case", -2, tType);
                                                                                         
                                                                                     } catch (Exception e) {
                                                                                         fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                     }
                                                                                 }

 @Test
                                                                            public void testComputeShiftIncrementDetectsMutantInCase() throws Exception {
                                                                                // Setup test data to trigger case 3 where the mutation occurs
                                                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0, 3.0}, new double[]{0.5, 1.5}, 1.0e-6);
                                                                                
                                                                                // Helper method to set private fields
                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                dMinField.setAccessible(true);
                                                                                dMinField.set(decomposition, 3.0);
                                                                                
                                                                                Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                dNField.setAccessible(true);
                                                                                dNField.set(decomposition, 3.0);
                                                                                
                                                                                Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                dMin1Field.setAccessible(true);
                                                                                dMin1Field.set(decomposition, 3.0);
                                                                                
                                                                                Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                dN1Field.setAccessible(true);
                                                                                dN1Field.set(decomposition, 3.0);
                                                                                
                                                                                Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                endField.setAccessible(true);
                                                                                endField.setInt(decomposition, 10);
                                                                                
                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                pingPongField.setAccessible(true);
                                                                                pingPongField.setInt(decomposition, 0);
                                                                                
                                                                                Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                deflatedField.setAccessible(true);
                                                                                deflatedField.setInt(decomposition, 0);
                                                                                
                                                                                // Setup work array to control the conditions
                                                                                double[] work = new double[4 * 10 + 0 - 1]; // nn = 4*end + pingPong - 1
                                                                                work[work.length - 3] = 1.0; // work[nn-3]
                                                                                work[work.length - 5] = 1.0; // work[nn-5]
                                                                                work[work.length - 7] = 1.0; // work[nn-7]
                                                                                work[work.length - 9] = 1.0; // work[nn-9]
                                                                                
                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                workField.setAccessible(true);
                                                                                workField.set(decomposition, work);
                                                                                
                                                                                // Call the private method via reflection
                                                                                Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                computeShiftIncrementMethod.setAccessible(true);
                                                                                computeShiftIncrementMethod.invoke(decomposition, 0, 10, 0);
                                                                                
                                                                                // Verify tau is calculated correctly (should be 0.333 * dMin = 1.0)
                                                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                tauField.setAccessible(true);
                                                                                double tau = tauField.getDouble(decomposition);
                                                                                assertEquals(1.0, tau, 1.0e-12);
                                                                                
                                                                                // Also verify tType is set correctly
                                                                                Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                tTypeField.setAccessible(true);
                                                                                int tType = tTypeField.getInt(decomposition);
                                                                                assertEquals(-3, tType);
                                                                            }

 @Test
                                                                        public void testComputeShiftIncrementDetectsMutantInLoopCondition1() {
                                                                            // Setup test case where one condition is true and the other is false
                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 2, 3}, new double[]{0.5, 1.5}, 1.0e-6);
                                                                            
                                                                            // Use reflection to access private fields needed for the test
                                                                            try {
                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                workField.setAccessible(true);
                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                dMinField.setAccessible(true);
                                                                                Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                dNField.setAccessible(true);
                                                                                Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                dN1Field.setAccessible(true);
                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                pingPongField.setAccessible(true);
                                                                                
                                                                                // Setup values that will trigger the specific case with our target condition
                                                                                double[] work = new double[100];
                                                                                // Setup work array values to create the scenario where:
                                                                                // 100*Math.max(b2,b1) < a2 is false (let's say b2=0.1, b1=0.1, a2=5)
                                                                                // cnst1 < a2 is true (cnst1=0.563, a2=5)
                                                                                work[0] = 0.1; // work[nn-9] / work[nn-11] = b2
                                                                                work[1] = 0.1; // work[i4] / work[i4-2] = b2
                                                                                work[2] = 0.1; // work[i4] / work[i4-2] = b2
                                                                                work[3] = 0.1; // work[i4] / work[i4-2] = b2
                                                                                
                                                                                workField.set(eigen, work);
                                                                                dMinField.set(eigen, 1.0); // dMin
                                                                                dNField.set(eigen, 1.0); // dN
                                                                                dN1Field.set(eigen, 1.0); // dN1
                                                                                pingPongField.set(eigen, 0); // pingPong
                                                                                
                                                                                // Call the method with parameters that will take the case 4 path
                                                                                Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                    "computeShiftIncrement", int.class, int.class, int.class);
                                                                                computeShiftIncrement.setAccessible(true);
                                                                                computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                
                                                                                // Verify the results - in original code, loop should break after first iteration
                                                                                // In mutated code, it would continue
                                                                                Field a2Field = EigenDecompositionImpl.class.getDeclaredField("a2");
                                                                                a2Field.setAccessible(true);
                                                                                double finalA2 = a2Field.getDouble(eigen);
                                                                                
                                                                                // Original would break after first iteration (a2 = initial + b2 = 0.1 + 0.1 = 0.2)
                                                                                // Mutated would continue until other conditions are met
                                                                                assertTrue("Mutant not detected - loop condition behavior changed", 
                                                                                    Math.abs(finalA2 - 0.2) < 1.0e-6);
                                                                                
                                                                            } catch (Exception e) {
                                                                                fail("Test failed due to reflection exception: " + e.getMessage());
                                                                            }
                                                                        }

 @Test
                                                                      public void testComputeShiftIncrementCase4DetectsMutant1() throws Exception {
                                                                          // Setup test data for case 4 where dMin == dN
                                                                          EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                                                                              new double[]{}, new double[]{}, 0.0);
                                                                          
                                                                          // Helper method to set private fields via reflection
                                                                          java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                          dMinField.setAccessible(true);
                                                                          dMinField.set(decomposition, 1.0);
                                                                          
                                                                          java.lang.reflect.Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                          dNField.setAccessible(true);
                                                                          dNField.set(decomposition, 1.0);
                                                                          
                                                                          java.lang.reflect.Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                          dN1Field.setAccessible(true);
                                                                          dN1Field.set(decomposition, 2.0); // Different from dMin to avoid other cases
                                                                          
                                                                          java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                          pingPongField.setAccessible(true);
                                                                          pingPongField.setInt(decomposition, 0);
                                                                          
                                                                          java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                          endField.setAccessible(true);
                                                                          endField.setInt(decomposition, 3); // Enough to reach nn-9
                                                                          
                                                                          java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                          deflatedField.setAccessible(true);
                                                                          deflatedField.setInt(decomposition, 0);
                                                                          
                                                                          // Setup work array to trigger the specific path
                                                                          double[] work = new double[4 * 3 + 0 - 1 + 1]; // nn = 4*end + pingPong -1, +1 for 0-based
                                                                          work[work.length - 3] = 1.0; // work[nn-3]
                                                                          work[work.length - 5] = 1.0; // work[nn-5]
                                                                          work[work.length - 7] = 0.5; // work[nn-7] - must be > work[nn-5] to trigger return
                                                                          work[work.length - 9] = 1.0; // work[nn-9]
                                                                          
                                                                          java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                          workField.setAccessible(true);
                                                                          workField.set(decomposition, work);
                                                                          
                                                                          // Call the private method via reflection
                                                                          java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                              "computeShiftIncrement", int.class, int.class, int.class);
                                                                          method.setAccessible(true);
                                                                          method.invoke(decomposition, 0, 3, 0);
                                                                          
                                                                          // Verify results
                                                                          java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                          tauField.setAccessible(true);
                                                                          double tau = tauField.getDouble(decomposition);
                                                                          
                                                                          java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                          tTypeField.setAccessible(true);
                                                                          int tType = tTypeField.getInt(decomposition);
                                                                          
                                                                          // Verify tType is correct for case 4
                                                                          assertEquals(-4, tType);
                                                                          
                                                                          // Verify tau is calculated with the correct a2 value
                                                                          assertTrue("Tau should be calculated with correct a2 value", 
                                                                                     tau != 0.25 * 1.0); // 0.25*dMin would be the wrong value
                                                                      }

 @Test
                                                                 public void testComputeShiftIncrement_Case5_DetectMutant() throws Exception {
                                                                     // Setup test case for case 5 (dMin == dN2)
                                                                     EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0, 3.0}, new double[]{1.0, 2.0}, 1.0e-6);
                                                                     
                                                                     // Use reflection to access private fields
                                                                     Class<?> clazz = decomposition.getClass();
                                                                     
                                                                     // Set required field values to reach case 5
                                                                     Field dMinField = clazz.getDeclaredField("dMin");
                                                                     dMinField.setAccessible(true);
                                                                     dMinField.setDouble(decomposition, 1.0);
                                                                     
                                                                     Field dN2Field = clazz.getDeclaredField("dN2");
                                                                     dN2Field.setAccessible(true);
                                                                     dN2Field.setDouble(decomposition, 1.0);  // dMin == dN2
                                                                     
                                                                     Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                     pingPongField.setAccessible(true);
                                                                     pingPongField.setInt(decomposition, 0); // simplify calculations
                                                                     
                                                                     Field endField = clazz.getDeclaredField("end");
                                                                     endField.setAccessible(true);
                                                                     endField.setInt(decomposition, 10);     // arbitrary end index
                                                                     
                                                                     // Create work array with values that will make only one condition true
                                                                     int np = 4 * 10 + 0 - 1 - 2 * 0; // end=10, pingPong=0
                                                                     double[] work = new double[np + 10]; // ensure array is large enough
                                                                     
                                                                     // Set values so that work[np-8] > b2 is true, work[np-4] > b1 is false
                                                                     work[np - 2] = 1.0; // b1
                                                                     work[np - 6] = 1.0; // b2
                                                                     work[np - 8] = 2.0; // > b2 (true)
                                                                     work[np - 4] = 0.5; // <= b1 (false)
                                                                     
                                                                     Field workField = clazz.getDeclaredField("work");
                                                                     workField.setAccessible(true);
                                                                     workField.set(decomposition, work);
                                                                     
                                                                     // Call the method using reflection
                                                                     Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                     computeShiftIncrement.setAccessible(true);
                                                                     computeShiftIncrement.invoke(decomposition, 0, 10, 0);
                                                                     
                                                                     // Verify the method didn't return early (should have set tau and tType)
                                                                     Field tTypeField = clazz.getDeclaredField("tType");
                                                                     tTypeField.setAccessible(true);
                                                                     assertEquals(-5, tTypeField.getInt(decomposition));
                                                                     
                                                                     Field tauField = clazz.getDeclaredField("tau");
                                                                     tauField.setAccessible(true);
                                                                     assertTrue(tauField.getDouble(decomposition) > 0); // tau should be set to some positive value
                                                                     
                                                                     // Now test the opposite case where the other condition is true
                                                                     work[np - 8] = 0.5; // <= b2 (false)
                                                                     work[np - 4] = 2.0; // > b1 (true)
                                                                     workField.set(decomposition, work);
                                                                     
                                                                     // Call the method again
                                                                     computeShiftIncrement.invoke(decomposition, 0, 10, 0);
                                                                     
                                                                     // Verify the method didn't return early
                                                                     assertEquals(-5, tTypeField.getInt(decomposition));
                                                                     assertTrue(tauField.getDouble(decomposition) > 0);
                                                                 }

 @Test
                                                        public void testComputeShiftIncrementDetectsSqrtMutation3() throws Exception {
                                                            // Setup test case for deflated=1 (case 7/8)
                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                            
                                                            // Use reflection to access private fields
                                                            Class<?> clazz = eigen.getClass();
                                                            Field deflatedField = clazz.getDeclaredField("deflated");
                                                            deflatedField.setAccessible(true);
                                                            Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                            dMin1Field.setAccessible(true);
                                                            Field dN1Field = clazz.getDeclaredField("dN1");
                                                            dN1Field.setAccessible(true);
                                                            Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                            dMin2Field.setAccessible(true);
                                                            Field dN2Field = clazz.getDeclaredField("dN2");
                                                            dN2Field.setAccessible(true);
                                                            Field workField = clazz.getDeclaredField("work");
                                                            workField.setAccessible(true);
                                                            Field pingPongField = clazz.getDeclaredField("pingPong");
                                                            pingPongField.setAccessible(true);
                                                            Field tauField = clazz.getDeclaredField("tau");
                                                            tauField.setAccessible(true);
                                                            Field tTypeField = clazz.getDeclaredField("tType");
                                                            tTypeField.setAccessible(true);
                                                            
                                                            // Set required field values to enter case 7/8
                                                            deflatedField.setInt(eigen, 1);
                                                            dMin1Field.setDouble(eigen, 5.0);
                                                            dN1Field.setDouble(eigen, 5.0);
                                                            dMin2Field.setDouble(eigen, 4.0);
                                                            dN2Field.setDouble(eigen, 4.0);
                                                            
                                                            // Configure work array to trigger the path where b2 is calculated
                                                            int nn = 4 * 10 + 0 - 1; // end=10, pingPong=0
                                                            double[] work = new double[nn + 1];
                                                            work[nn - 5] = 4.0; // b1 numerator
                                                            work[nn - 7] = 8.0; // b1 denominator (b1 will be 0.5)
                                                            workField.set(eigen, work);
                                                            
                                                            // Set other required fields
                                                            pingPongField.setInt(eigen, 0);
                                                            
                                                            // Call the method via reflection
                                                            Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                            computeShiftIncrement.setAccessible(true);
                                                            computeShiftIncrement.invoke(eigen, 0, 10, 1);
                                                            
                                                            // Calculate expected value with sqrt operation
                                                            double expectedB2 = 0.5; // initial b1 value
                                                            double sumB2 = 0.5; // since we only have one iteration in this setup
                                                            double expectedProcessedB2 = Math.sqrt(1.05 * sumB2); // cnst3=1.05
                                                            double expectedA2 = 5.0 / (1 + expectedProcessedB2 * expectedProcessedB2);
                                                            double expectedTau = Math.max(0.333 * 5.0, expectedA2 * (1 - 1.010 * expectedProcessedB2));
                                                            
                                                            // Verify tau is calculated correctly (would be different if sqrt was missing)
                                                            org.junit.Assert.assertEquals(expectedTau, (Double)tauField.get(eigen), 1e-10);
                                                            
                                                            // Also verify tType is set correctly
                                                            org.junit.Assert.assertEquals(-8, (int)tTypeField.get(eigen));
                                                        }

 @Test
                                                   public void testComputeShiftIncrementDetectsMutantCase() throws Exception {
                                                       // Setup test data where dMin2 == dN2 but 2*work[nn-5] >= work[nn-7]
                                                       EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                       
                                                       // Reflection helper to set private fields
                                                       Class<?> clazz = decomposition.getClass();
                                                       
                                                       // Set required fields through reflection since they're private
                                                       Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                       dMin2Field.setAccessible(true);
                                                       dMin2Field.set(decomposition, 1.0);
                                                       
                                                       Field dN2Field = clazz.getDeclaredField("dN2");
                                                       dN2Field.setAccessible(true);
                                                       dN2Field.set(decomposition, 1.0); // dMin2 == dN2
                                                       
                                                       Field deflatedField = clazz.getDeclaredField("deflated");
                                                       deflatedField.setAccessible(true);
                                                       deflatedField.set(decomposition, 2); // case 2 in switch
                                                       
                                                       Field endField = clazz.getDeclaredField("end");
                                                       endField.setAccessible(true);
                                                       endField.set(decomposition, 10); // arbitrary end index
                                                       
                                                       Field pingPongField = clazz.getDeclaredField("pingPong");
                                                       pingPongField.setAccessible(true);
                                                       pingPongField.set(decomposition, 0); // simplifies nn calculation
                                                       
                                                       // Calculate nn = 4*end + pingPong - 1 = 4*10 + 0 - 1 = 39
                                                       // Setup work array where 2*work[34] >= work[32]
                                                       double[] work = new double[40];
                                                       work[34] = 5.0; // work[nn-5] = work[39-5] = work[34]
                                                       work[32] = 9.0; // work[nn-7] = work[39-7] = work[32]
                                                       // 2*5.0 = 10.0 which is NOT < 9.0 (false condition)
                                                       
                                                       Field workField = clazz.getDeclaredField("work");
                                                       workField.setAccessible(true);
                                                       workField.set(decomposition, work);
                                                       
                                                       // Set initial tType to something different than expected
                                                       Field tTypeField = clazz.getDeclaredField("tType");
                                                       tTypeField.setAccessible(true);
                                                       tTypeField.set(decomposition, 0);
                                                       
                                                       // Call the private method via reflection
                                                       Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                       computeShiftIncrement.setAccessible(true);
                                                       computeShiftIncrement.invoke(decomposition, 0, 10, 2);
                                                       
                                                       // Verify tType should NOT be -10 (case 10) with original code
                                                       // With mutant, it would be -10 because first condition is true
                                                       int tType = (int) tTypeField.get(decomposition);
                                                       assertNotEquals("Mutant detected: tType should not be -10 when only dMin2==dN2 is true", 
                                                                      -10, tType);
                                                   }

 @Test
                                              public void testComputeShiftIncrement_DefaultCase1() throws Exception {
                                                  // Setup test data to trigger default case (deflated > 2)
                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(
                                                      new double[] {1.0, 2.0, 3.0},  // main diagonal
                                                      new double[] {0.5, 0.7},       // secondary diagonal
                                                      0.0                             // splitTolerance
                                                  );
                                                  
                                                  // Get class and declare fields to access
                                                  Class<?> clazz = eigenDecomposition.getClass();
                                                  
                                                  // Set required fields to ensure we hit the default case
                                                  Field deflatedField = clazz.getDeclaredField("deflated");
                                                  deflatedField.setAccessible(true);
                                                  deflatedField.setInt(eigenDecomposition, 3);  // > 2 to trigger default case
                                                  
                                                  Field dMinField = clazz.getDeclaredField("dMin");
                                                  dMinField.setAccessible(true);
                                                  dMinField.setDouble(eigenDecomposition, 1.0);
                                                  
                                                  Field dNField = clazz.getDeclaredField("dN");
                                                  dNField.setAccessible(true);
                                                  dNField.setDouble(eigenDecomposition, 2.0);
                                                  
                                                  Field dN1Field = clazz.getDeclaredField("dN1");
                                                  dN1Field.setAccessible(true);
                                                  dN1Field.setDouble(eigenDecomposition, 3.0);
                                                  
                                                  Field dN2Field = clazz.getDeclaredField("dN2");
                                                  dN2Field.setAccessible(true);
                                                  dN2Field.setDouble(eigenDecomposition, 4.0);
                                                  
                                                  Field workField = clazz.getDeclaredField("work");
                                                  workField.setAccessible(true);
                                                  workField.set(eigenDecomposition, new double[20]);  // large enough array
                                                  
                                                  // Call the private method
                                                  Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                  computeShiftIncrement.setAccessible(true);
                                                  computeShiftIncrement.invoke(eigenDecomposition, 0, 4, 3);
                                                  
                                                  // Verify tau is set to 0.0 (original behavior)
                                                  Field tauField = clazz.getDeclaredField("tau");
                                                  tauField.setAccessible(true);
                                                  assertEquals(0.0, tauField.getDouble(eigenDecomposition), 0.0001);
                                                  
                                                  // Also verify tType is set correctly
                                                  Field tTypeField = clazz.getDeclaredField("tType");
                                                  tTypeField.setAccessible(true);
                                                  assertEquals(-12, tTypeField.getInt(eigenDecomposition));
                                              }

 @Test
                                          public void testComputeShiftIncrementWithZeroDMin2() {
                                              // Setup test object and required state
                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{1.0}, new double[]{0.0}, 1.0e-6);
                                              
                                              // Use reflection to access private fields since we need to test a private method
                                              try {
                                                  // Set dMin to 0.0 which is the boundary case
                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                  dMinField.setAccessible(true);
                                                  dMinField.set(eigenDecomposition, 0.0);
                                                  
                                                  // Set other required fields
                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                  workField.setAccessible(true);
                                                  workField.set(eigenDecomposition, new double[100]); // arbitrary size
                                                  
                                                  Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                  endField.setAccessible(true);
                                                  endField.set(eigenDecomposition, 10); // arbitrary value
                                                  
                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                  pingPongField.setAccessible(true);
                                                  pingPongField.set(eigenDecomposition, 0); // arbitrary value
                                                  
                                                  // Get the method to test
                                                  Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                  computeShiftIncrement.setAccessible(true);
                                                  
                                                  // Invoke the method
                                                  computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0); // arbitrary start, end, deflated
                                                  
                                                  // Verify results
                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                  tauField.setAccessible(true);
                                                  double tau = tauField.getDouble(eigenDecomposition);
                                                  
                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                  tTypeField.setAccessible(true);
                                                  int tType = tTypeField.getInt(eigenDecomposition);
                                                  
                                                  // Original behavior: should enter the first block and set tau to 0.0 and tType to -1
                                                  assertEquals("tau should be 0.0 when dMin is 0.0", 0.0, tau, 1.0e-12);
                                                  assertEquals("tType should be -1 when dMin is 0.0", -1, tType);
                                                  
                                              } catch (Exception e) {
                                                  fail("Exception during test: " + e.getMessage());
                                              }
                                          }

 @Test
                                         public void testComputeShiftIncrementDetectsSqrtMutation4() {
                                             // Setup test data that will trigger the case where b1 is calculated
                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 2, 3}, new double[]{4, 5}, 0.0);
                                             
                                             // Use reflection to access private fields since we need to set them up
                                             try {
                                                 // Set fields to trigger case 0 with dMin == dN
                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                 workField.setAccessible(true);
                                                 double[] work = new double[20];
                                                 // Set values at positions that will be used in calculation (nn-3, nn-5, etc.)
                                                 work[15] = 4.0;  // work[nn-5] when nn=20 (4*4 + 3 -1)
                                                 work[17] = 9.0;  // work[nn-3]
                                                 workField.set(eigen, work);
                                                 
                                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                 dMinField.setAccessible(true);
                                                 dMinField.set(eigen, 1.0);
                                                 
                                                 Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                 dNField.setAccessible(true);
                                                 dNField.set(eigen, 1.0);
                                                 
                                                 Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                 dN1Field.setAccessible(true);
                                                 dN1Field.set(eigen, 2.0);
                                                 
                                                 Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                 dMin1Field.setAccessible(true);
                                                 dMin1Field.set(eigen, 2.0);
                                                 
                                                 Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                 endField.setAccessible(true);
                                                 endField.set(eigen, 4);
                                                 
                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                 pingPongField.setAccessible(true);
                                                 pingPongField.set(eigen, 3);
                                                 
                                                 // Call the method
                                                 Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                     int.class, int.class, int.class);
                                                 method.setAccessible(true);
                                                 method.invoke(eigen, 0, 4, 0);
                                                 
                                                 // Verify results
                                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                 tauField.setAccessible(true);
                                                 double tau = tauField.getDouble(eigen);
                                                 
                                                 // Calculate expected b1 value (sqrt(4)*sqrt(9) = 2*3 = 6)
                                                 // Mutated version would be 4*9=36
                                                 // This difference should propagate to tau calculation
                                                 assertTrue("Tau value should reflect correct b1 calculation", 
                                                     tau > 0.5 && tau < 1.0); // Exact value depends on full calculation
                                                 
                                             } catch (Exception e) {
                                                 fail("Test failed due to reflection exception: " + e.getMessage());
                                             }
                                         }

 @Test
                                   public void testComputeShiftIncrementDetectsMutant1() {
                                       // Setup test case where gap2 > 0.0 but gap2 <= b2
                                       // This should make original use b1+b2 but mutant would use (b2/gap2)*b2
                                       
                                       // Create test instance
                                       double[] main = new double[20];
                                       double[] secondary = new double[20];
                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                       
                                       // Helper method to set private fields
                                       try {
                                           Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                           dMinField.setAccessible(true);
                                           dMinField.set(eigen, 1.0);
                                           
                                           Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                           dNField.setAccessible(true);
                                           dNField.set(eigen, 0.5);
                                           
                                           Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                           dN1Field.setAccessible(true);
                                           dN1Field.set(eigen, 0.5);
                                           
                                           Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                           dMin1Field.setAccessible(true);
                                           dMin1Field.set(eigen, 0.5);
                                           
                                           Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                           dMin2Field.setAccessible(true);
                                           dMin2Field.set(eigen, 2.0);
                                           
                                           Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                           dN2Field.setAccessible(true);
                                           dN2Field.set(eigen, 2.0);
                                           
                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                           pingPongField.setAccessible(true);
                                           pingPongField.set(eigen, 0);
                                           
                                           Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                           deflatedField.setAccessible(true);
                                           deflatedField.set(eigen, 0);
                                           
                                           // Setup work array values to create the scenario
                                           double[] work = new double[20];
                                           // nn = 4*end + pingPong - 1 = 4*5 + 0 - 1 = 19 (assuming end=5)
                                           // We need:
                                           // gap2 = dMin2 - a2 - dMin2*0.25 = 2.0 - a2 - 0.5 = 1.5 - a2
                                           // a2 = work[nn-7] + work[nn-5] = work[12] + work[14]
                                           // b1 = sqrt(work[16])*sqrt(work[14])
                                           // b2 = sqrt(work[12])*sqrt(work[10])
                                           
                                           // Set values to make:
                                           // gap2 > 0.0 (let's say 0.6)
                                           // gap2 <= b2 (let's say b2 = 0.7)
                                           // So a2 = 1.5 - 0.6 = 0.9
                                           work[12] = 0.4; // work[nn-7]
                                           work[14] = 0.5; // work[nn-5]
                                           work[16] = 0.1; // work[nn-3]
                                           work[10] = 0.49; // work[nn-9]
                                           
                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                           workField.setAccessible(true);
                                           workField.set(eigen, work);
                                           
                                           // Call the private method using reflection
                                           Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                               "computeShiftIncrement", int.class, int.class, int.class);
                                           computeShiftIncrement.setAccessible(true);
                                           computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                           
                                           // Get the tau value using reflection
                                           Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                           tauField.setAccessible(true);
                                           double tau = (Double)tauField.get(eigen);
                                           
                                           // Calculate expected values
                                           double b1 = Math.sqrt(work[16]) * Math.sqrt(work[14]);
                                           double b2 = Math.sqrt(work[12]) * Math.sqrt(work[10]);
                                           double a2 = work[12] + work[14];
                                           double gap2 = 1.5 - a2; // Should be 0.6 based on our setup
                                           double gap1 = a2 - 0.5 - ((gap2 > 0.0 && gap2 > b2) ? (b2 / gap2) * b2 : (b1 + b2));
                                           double expectedTau = 0.0;
                                           if (gap1 > 0.0 && gap1 > b1) {
                                               expectedTau = Math.max(0.5 - (b1 / gap1) * b1, 0.5 * 1.0);
                                           } else {
                                               double s = 0.0;
                                               if (0.5 > b1) {
                                                   s = 0.5 - b1;
                                               }
                                               if (a2 > (b1 + b2)) {
                                                   s = Math.min(s, a2 - (b1 + b2));
                                               }
                                               expectedTau = Math.max(s, 0.333 * 1.0);
                                           }
                                           assertEquals(expectedTau, tau, 1.0e-10);
                                       } catch (Exception e) {
                                           fail("Reflection failed: " + e.getMessage());
                                       }
                                   }

 @Test
                              public void testComputeShiftIncrementDetectsMutant2() {
                                  // Setup test conditions to reach the mutated code
                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                  
                                  // Use reflection to set private fields since they're needed for the computation
                                  try {
                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                      dMinField.setAccessible(true);
                                      dMinField.set(eigen, 3.0);  // dMin = 3.0
                                      
                                      Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                      dNField.setAccessible(true);
                                      dNField.set(eigen, 3.0);    // dN = 3.0
                                      
                                      Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                      dMin1Field.setAccessible(true);
                                      dMin1Field.set(eigen, 1.0); // dMin1 = 1.0
                                      
                                      Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                      dN1Field.setAccessible(true);
                                      dN1Field.set(eigen, 1.0);   // dN1 = 1.0
                                      
                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                      workField.setAccessible(true);
                                      // Setup work array to ensure we take the desired path
                                      double[] work = new double[20];
                                      work[16] = 1.0;  // nn-3 when end=4, pingPong=1 (nn=4*4+1-1=16)
                                      work[14] = 1.0;  // nn-5
                                      work[12] = 1.0;  // nn-7
                                      work[10] = 1.0;  // nn-9
                                      workField.set(eigen, work);
                                      
                                      Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                      endField.setAccessible(true);
                                      endField.set(eigen, 4);
                                      
                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                      pingPongField.setAccessible(true);
                                      pingPongField.set(eigen, 1);
                                      
                                      // Call the method - deflated=0 to enter case 0
                                      Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                          int.class, int.class, int.class);
                                      method.setAccessible(true);
                                      method.invoke(eigen, 0, 4, 0);
                                      
                                      // Verify tau value
                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                      tauField.setAccessible(true);
                                      double tau = tauField.getDouble(eigen);
                                      
                                      // Original code would give max(0.8, 0.333*3) = max(0.8, 0.999) = 0.999
                                      // Mutant would give max(0.8, 0.5*3) = max(0.8, 1.5) = 1.5
                                      // We expect 0.999 (from original code)
                                      assertEquals(0.999, tau, 0.001);
                                      
                                      // Also verify tType is set correctly
                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                      tTypeField.setAccessible(true);
                                      int tType = tTypeField.getInt(eigen);
                                      assertEquals(-3, tType);
                                      
                                  } catch (Exception e) {
                                      fail("Failed due to reflection exception: " + e.getMessage());
                                  }
                              }

 @Test
                          public void testComputeShiftIncrementDetectsMutantInLoopCondition2() {
                              // Setup test case where 100*max(b2,b1) < a2 is true but cnst1 < a2 is false
                              // This will make original code break but mutant continue
                              
                              // Create test instance
                              double[] main = new double[20];
                              double[] secondary = new double[20];
                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                              
                              // Set required fields through reflection since they're private
                              try {
                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                  workField.setAccessible(true);
                                  double[] work = new double[20];
                                  
                                  // Setup values to enter case 4 where the mutant exists
                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                  dMinField.setAccessible(true);
                                  dMinField.set(eigen, 1.0); // dMin = dN
                                  
                                  Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                  dNField.setAccessible(true);
                                  dNField.set(eigen, 1.0);
                                  
                                  Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                  dN1Field.setAccessible(true);
                                  dN1Field.set(eigen, 2.0); // dMin1 != dN1
                                  
                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                  pingPongField.setAccessible(true);
                                  pingPongField.set(eigen, 0);
                                  
                                  // Setup work array values
                                  work[11] = 0.5; // work[nn-5] / work[nn-7] will be 0.5
                                  work[9] = 1.0;  // work[nn-7]
                                  work[7] = 0.5;  // work[nn-9]
                                  
                                  workField.set(eigen, work);
                                  
                                  // Setup initial a2 and b2 values
                                  Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                  startField.setAccessible(true);
                                  startField.set(eigen, 0);
                                  
                                  Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                  endField.setAccessible(true);
                                  endField.set(eigen, 4);
                                  
                                  // Call the method - case 4 with deflated = 0
                                  Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                      int.class, int.class, int.class);
                                  method.setAccessible(true);
                                  method.invoke(eigen, 0, 4, 0);
                                  
                                  // Verify the tau value - mutant would produce different value
                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                  tauField.setAccessible(true);
                                  double tau = tauField.getDouble(eigen);
                                  
                                  // The exact expected value depends on the original behavior,
                                  // but we know mutant would behave differently in this case
                                  assertTrue("Mutant not detected - tau value incorrect", 
                                      tau == 0.25 || tau == 0.0); // 0.25 is expected for original
                                  
                              } catch (Exception e) {
                                  fail("Test failed due to reflection exception: " + e.getMessage());
                              }
                          }

 @Test
                         public void testComputeShiftIncrementCase4DetectsMutant2() {
                             // Setup test data to trigger case 4
                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                             
                             // Use reflection to set private fields since we need specific conditions
                             try {
                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                 dMinField.setAccessible(true);
                                 dMinField.set(eigen, 1.0); // dMin > 0
                                 
                                 Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                 dNField.setAccessible(true);
                                 dNField.set(eigen, 1.0); // dMin == dN
                                 
                                 Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                 dN1Field.setAccessible(true);
                                 dN1Field.set(eigen, 2.0); // dMin1 != dN1
                                 
                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                 workField.setAccessible(true);
                                 double[] work = new double[20];
                                 // Set values to ensure we take the dMin == dN branch
                                 work[11] = 1.0; // nn-9 when nn=20 (4*4 + 3 -1)
                                 work[13] = 2.0; // nn-7
                                 work[15] = 1.0; // nn-5
                                 work[17] = 0.5; // nn-3
                                 workField.set(eigen, work);
                                 
                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                 pingPongField.setAccessible(true);
                                 pingPongField.set(eigen, 0);
                                 
                                 Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                 endField.setAccessible(true);
                                 endField.set(eigen, 4);
                                 
                                 // Call the method with deflated=0 to reach case 4
                                 Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                     int.class, int.class, int.class);
                                 method.setAccessible(true);
                                 method.invoke(eigen, 0, 4, 0);
                                 
                                 // Verify the results
                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                 tauField.setAccessible(true);
                                 double tau = tauField.getDouble(eigen);
                                 
                                 // The original code would multiply a2 by 1.05 (cnst3)
                                 // The mutant would multiply by 0.563 (cnst1)
                                 // We expect tau to be in a specific range based on correct scaling
                                 assertTrue("Tau value should reflect correct cnst3 scaling", 
                                     tau > 0.1 && tau < 0.5); // Adjust bounds based on exact expected values
                                 
                                 Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                 tTypeField.setAccessible(true);
                                 int tType = tTypeField.getInt(eigen);
                                 assertEquals("tType should be -4 for this case", -4, tType);
                                 
                             } catch (Exception e) {
                                 fail("Test failed due to reflection exception: " + e.getMessage());
                             }
                         }

 @Test
                       public void testComputeShiftIncrementCase5DetectsMutant() throws Exception {
                           // Setup test case for case 5 (tType = -5)
                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                           
                           // Use reflection to set private fields
                           Class<?> clazz = eigen.getClass();
                           
                           // Set required fields to enter case 5
                           Field dMinField = clazz.getDeclaredField("dMin");
                           dMinField.setAccessible(true);
                           dMinField.set(eigen, 1.0);
                           
                           Field dN2Field = clazz.getDeclaredField("dN2");
                           dN2Field.setAccessible(true);
                           dN2Field.set(eigen, 1.0);
                           
                           Field dMin2Field = clazz.getDeclaredField("dMin2");
                           dMin2Field.setAccessible(true);
                           dMin2Field.set(eigen, 1.0);
                           
                           Field deflatedField = clazz.getDeclaredField("deflated");
                           deflatedField.setAccessible(true);
                           deflatedField.set(eigen, 0);
                           
                           Field endField = clazz.getDeclaredField("end");
                           endField.setAccessible(true);
                           endField.set(eigen, 10);
                           
                           Field pingPongField = clazz.getDeclaredField("pingPong");
                           pingPongField.setAccessible(true);
                           pingPongField.set(eigen, 0);
                           
                           Field tTypeField = clazz.getDeclaredField("tType");
                           tTypeField.setAccessible(true);
                           tTypeField.set(eigen, 0);
                           
                           // Create work array with specific values to trigger the condition
                           // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*10 + 0 - 1 - 0 = 39
                           // So np-8 = 31, np-4 = 35, np-2 = 37, np-6 = 33
                           double[] work = new double[40];
                           work[31] = 2.0;  // work[np-8] > b2 (b2 will be 1.0)
                           work[35] = 0.5;  // work[np-4] < b1 (b1 will be 1.0)
                           work[33] = 1.0;  // b2
                           work[37] = 1.0;  // b1
                           
                           // Set other required work array values
                           work[39-13] = 1.0;  // work[nn-13]
                           work[39-15] = 1.0;  // work[nn-15]
                           
                           // Set the work array
                           Field workField = clazz.getDeclaredField("work");
                           workField.setAccessible(true);
                           workField.set(eigen, work);
                           
                           // Call the private method using reflection
                           Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                           computeShiftIncrement.setAccessible(true);
                           computeShiftIncrement.invoke(eigen, 0, 10, 0);
                           
                           // Get tau value using reflection
                           Field tauField = clazz.getDeclaredField("tau");
                           tauField.setAccessible(true);
                           double tau = (Double)tauField.get(eigen);
                           
                           // In original code, the method would return early because work[np-8] > b2 is true
                           // So tau would remain 0.0 (default value)
                           // In mutated code, it would continue and set tau to some value
                           // So we assert that tau is 0.0 to detect the mutant
                           assertEquals(0.0, tau, 0.0001);
                           
                           // Also verify tType was set to -5
                           int tType = (Integer)tTypeField.get(eigen);
                           assertEquals(-5, tType);
                       }

 @Test
                  public void testComputeShiftIncrementDetectsSqrtMutation5() throws Exception {
                      // Setup for case 7/8 (deflated=1, dMin1=dN1, dMin2=dN2)
                      EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                          new double[]{1.0, 2.0, 3.0},  // main diagonal
                          new double[]{0.5, 0.7},       // secondary diagonal
                          1.0e-6                        // splitTolerance
                      );
                      
                      // Helper method to set private fields
                      Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                      dMin1Field.setAccessible(true);
                      dMin1Field.setDouble(decomposition, 0.5);
                      
                      Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                      dN1Field.setAccessible(true);
                      dN1Field.setDouble(decomposition, 0.5);
                      
                      Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                      dMin2Field.setAccessible(true);
                      dMin2Field.setDouble(decomposition, 0.6);
                      
                      Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                      dN2Field.setAccessible(true);
                      dN2Field.setDouble(decomposition, 0.6);
                      
                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                      pingPongField.setAccessible(true);
                      pingPongField.setInt(decomposition, 0);
                      
                      Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                      endField.setAccessible(true);
                      endField.setInt(decomposition, 3);
                      
                      // Setup work array to trigger case 7/8
                      double[] work = new double[13]; // 4*end + 1 = 13
                      work[6] = 1.0;  // work[nn-7] when nn=4*end + pingPong -1 = 11
                      work[8] = 2.0;  // work[nn-5]
                      
                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                      workField.setAccessible(true);
                      workField.set(decomposition, work);
                      
                      // Call the method with deflated=1 to trigger case 7/8
                      Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                          "computeShiftIncrement", int.class, int.class, int.class);
                      computeShiftIncrement.setAccessible(true);
                      computeShiftIncrement.invoke(decomposition, 0, 3, 1);
                      
                      // Get the results
                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                      tauField.setAccessible(true);
                      double tau = tauField.getDouble(decomposition);
                      
                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                      tTypeField.setAccessible(true);
                      int tType = tTypeField.getInt(decomposition);
                      
                      // Verify the results
                      // Expected calculation path:
                      // b1 = work[8]/work[6] = 2.0/1.0 = 2.0
                      // b2 = b1 = 2.0
                      // Original code would do: b2 = sqrt(cnst3 * b2) = sqrt(1.05 * 2.0) ≈ 1.449
                      // Mutant would do: b2 = cnst3 * b2 = 1.05 * 2.0 = 2.1
                      // This affects subsequent calculations of a2 and tau
                      
                      // Calculate expected tau value with proper sqrt
                      double expectedB2 = Math.sqrt(1.05 * 2.0);
                      double expectedA2 = 0.5 / (1 + expectedB2 * expectedB2);
                      double expectedTau = Math.max(0.333 * 0.5, 
                          expectedA2 * (1 - 1.010 * expectedB2));
                      
                      assertEquals("tType should indicate case 8", -8, tType);
                      assertEquals("tau should match expected calculation", 
                          expectedTau, tau, 1.0e-10);
                  }

 @Test
     public void testComputeShiftIncrementDetectsMutant3() throws Exception {
         // Setup test case where:
         // - deflated = 2 (case 2)
         // - dMin2 != dN2
         // - 2 * work[nn-5] < work[nn-7]
         
         // Create test instance
         double[] main = new double[10];
         double[] secondary = new double[9];
         EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 1.0e-12);
         
         // Set required fields through reflection
         java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
         deflatedField.setAccessible(true);
         deflatedField.set(eigen, 2);
         
         java.lang.reflect.Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
         dMin2Field.setAccessible(true);
         dMin2Field.set(eigen, 1.0);
         
         java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
         dN2Field.setAccessible(true);
         dN2Field.set(eigen, 2.0); // dMin2 != dN2
         
         java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
         pingPongField.setAccessible(true);
         pingPongField.set(eigen, 0);
         
         java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
         endField.setAccessible(true);
         endField.set(eigen, 10);
         
         // Setup work array to satisfy 2*work[nn-5] < work[nn-7]
         // nn = 4*end + pingPong - 1 = 4*10 + 0 - 1 = 39
         // So we need 2*work[34] < work[32]
         double[] work = new double[40];
         work[34] = 1.0; // work[nn-5]
         work[32] = 3.0; // work[nn-7] (3 > 2*1)
         
         java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
         workField.setAccessible(true);
         workField.set(eigen, work);
         
         // Call the private method using reflection
         Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
             "computeShiftIncrement", int.class, int.class, int.class);
         computeShiftIncrement.setAccessible(true);
         computeShiftIncrement.invoke(eigen, 0, 10, 2);
         
         // Verify tType should be -11 (case 11) in original code
         // Mutant would set it to -10 (case 10)
         java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
         tTypeField.setAccessible(true);
         assertEquals("Mutant not detected", -11, tTypeField.get(eigen));
     }

 @Test
 public void testComputeShiftIncrement_DefaultCase_MoreThanTwoDeflated() {
     // Setup test object and required state
     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[]{0.5}, 1.0e-12);
     
     // Set required fields through reflection since they're private
     try {
         Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
         dMinField.setAccessible(true);
         dMinField.set(eigen, 1.0);
         
         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
         workField.setAccessible(true);
         workField.set(eigen, new double[100]); // large enough array
         
         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
         pingPongField.setAccessible(true);
         pingPongField.set(eigen, 0);
         
         Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
         tTypeField.setAccessible(true);
         
         Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
             "computeShiftIncrement", int.class, int.class, int.class);
         computeShiftIncrement.setAccessible(true);
         
         // Call with deflated > 2 to trigger default case
         computeShiftIncrement.invoke(eigen, 0, 10, 3);
         
         // Verify tau is 0.0 (would be 1.0 with mutation)
         Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
         tauField.setAccessible(true);
         double tau = tauField.getDouble(eigen);
         assertEquals(0.0, tau, 1.0e-12);
         
         // Verify tType is set correctly
         int tType = tTypeField.getInt(eigen);
         assertEquals(-12, tType);
         
     } catch (Exception e) {
         fail("Failed to test computeShiftIncrement due to reflection error: " + e.getMessage());
     }
 }

}
