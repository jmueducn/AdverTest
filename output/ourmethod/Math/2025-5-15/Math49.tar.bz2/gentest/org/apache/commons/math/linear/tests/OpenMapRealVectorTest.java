package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
import org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                             public void testEbeDivide_WithSparseVectors() {
                                                                                                 OpenMapRealVector sparse1 = new OpenMapRealVector(5);
                                                                                                 sparse1.setEntry(1, 4.0);
                                                                                                 sparse1.setEntry(3, 8.0);
                                                                                                 
                                                                                                 OpenMapRealVector sparse2 = new OpenMapRealVector(5);
                                                                                                 sparse2.setEntry(1, 2.0);
                                                                                                 sparse2.setEntry(3, 4.0);
                                                                                                 
                                                                                                 OpenMapRealVector result = sparse1.ebeDivide(sparse2);
                                                                                                 
                                                                                                 assertEquals(5, result.getDimension());
                                                                                                 assertEquals(0.0, result.getEntry(0), 0.0001);
                                                                                                 assertEquals(2.0, result.getEntry(1), 0.0001);
                                                                                                 assertEquals(0.0, result.getEntry(2), 0.0001);
                                                                                                 assertEquals(2.0, result.getEntry(3), 0.0001);
                                                                                                 assertEquals(0.0, result.getEntry(4), 0.0001);
                                                                                             }

    @Test
                                                                                             public void testEbeDivide_TypicalValues() {
                                                                                                 // Setup
                                                                                                 double[] originalValues = {4.0, 9.0, 16.0};
                                                                                                 double[] divisorValues = {2.0, 3.0, 4.0};
                                                                                                 double[] expectedValues = {2.0, 3.0, 4.0};
                                                                                                 
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(originalValues);
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeDivide(divisorValues);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(originalValues.length, result.getDimension());
                                                                                                 for (int i = 0; i < expectedValues.length; i++) {
                                                                                                     assertEquals(expectedValues[i], result.getEntry(i), 0.0001);
                                                                                                 }
                                                                                             }

    @Test
                                                                                             public void testEbeDivide_WithZeroValues() {
                                                                                                 // Setup
                                                                                                 double[] originalValues = {4.0, 0.0, 16.0};
                                                                                                 double[] divisorValues = {2.0, 1.0, 4.0};
                                                                                                 double[] expectedValues = {2.0, 0.0, 4.0};
                                                                                                 
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(originalValues);
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeDivide(divisorValues);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(originalValues.length, result.getDimension());
                                                                                                 for (int i = 0; i < expectedValues.length; i++) {
                                                                                                     assertEquals(expectedValues[i], result.getEntry(i), 0.0001);
                                                                                                 }
                                                                                             }

    @Test
                                                                                             public void testEbeDivide_EmptyVectors() {
                                                                                                 // Setup
                                                                                                 double[] originalValues = {};
                                                                                                 double[] divisorValues = {};
                                                                                                 
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(originalValues);
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeDivide(divisorValues);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(0, result.getDimension());
                                                                                             }

    @Test
                                                                                             public void testEbeDivide_WithNegativeNumbers() {
                                                                                                 // Setup
                                                                                                 double[] originalValues = {-4.0, 9.0, -16.0};
                                                                                                 double[] divisorValues = {2.0, -3.0, 4.0};
                                                                                                 double[] expectedValues = {-2.0, -3.0, -4.0};
                                                                                                 
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(originalValues);
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeDivide(divisorValues);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(originalValues.length, result.getDimension());
                                                                                                 for (int i = 0; i < expectedValues.length; i++) {
                                                                                                     assertEquals(expectedValues[i], result.getEntry(i), 0.0001);
                                                                                                 }
                                                                                             }

    @Test
                                                                                             public void testEbeDivide_DivideByZero() {
                                                                                                 // Setup
                                                                                                 double[] originalValues = {4.0, 9.0, 16.0};
                                                                                                 double[] divisorValues = {2.0, 0.0, 4.0};
                                                                                                 
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(originalValues);
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeDivide(divisorValues);
                                                                                                 
                                                                                                 // Verify behavior (should be infinity or throw exception depending on implementation)
                                                                                                 // This test might need adjustment based on actual implementation behavior
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0001);
                                                                                             }

    @Test
                                                                                             public void testEbeDivide_SparseVector() {
                                                                                                 // Setup - create a sparse vector with only some entries set
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(3);
                                                                                                 vector.setEntry(0, 4.0);
                                                                                                 vector.setEntry(2, 16.0); // index 1 is default (0.0)
                                                                                                 
                                                                                                 double[] divisorValues = {2.0, 3.0, 4.0};
                                                                                                 double[] expectedValues = {2.0, 0.0, 4.0};
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeDivide(divisorValues);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(3, result.getDimension());
                                                                                                 for (int i = 0; i < expectedValues.length; i++) {
                                                                                                     assertEquals(expectedValues[i], result.getEntry(i), 0.0001);
                                                                                                 }
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_TypicalValues() {
                                                                                                 // Setup first vector (3, 0, 2.5)
                                                                                                 OpenMapRealVector vector1 = new OpenMapRealVector(3);
                                                                                                 vector1.setEntry(0, 3.0);
                                                                                                 vector1.setEntry(2, 2.5);
                                                                                                 
                                                                                                 // Setup second vector (2, 4, 1.5)
                                                                                                 OpenMapRealVector vector2 = new OpenMapRealVector(3);
                                                                                                 vector2.setEntry(0, 2.0);
                                                                                                 vector2.setEntry(1, 4.0);
                                                                                                 vector2.setEntry(2, 1.5);
                                                                                                 
                                                                                                 // Multiply and verify
                                                                                                 OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                                                                 assertEquals(6.0, result.getEntry(0), 0.0001);  // 3 * 2
                                                                                                 assertEquals(0.0, result.getEntry(1), 0.0001);  // 0 * 4
                                                                                                 assertEquals(3.75, result.getEntry(2), 0.0001); // 2.5 * 1.5
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_WithZeroValues() {
                                                                                                 // Setup first vector (0, 5, 0)
                                                                                                 OpenMapRealVector vector1 = new OpenMapRealVector(3);
                                                                                                 vector1.setEntry(1, 5.0);
                                                                                                 
                                                                                                 // Setup second vector (10, 0, 3)
                                                                                                 OpenMapRealVector vector2 = new OpenMapRealVector(3);
                                                                                                 vector2.setEntry(0, 10.0);
                                                                                                 vector2.setEntry(2, 3.0);
                                                                                                 
                                                                                                 // Multiply and verify
                                                                                                 OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                                                                 assertEquals(0.0, result.getEntry(0), 0.0001);  // 0 * 10
                                                                                                 assertEquals(0.0, result.getEntry(1), 0.0001);  // 5 * 0
                                                                                                 assertEquals(0.0, result.getEntry(2), 0.0001);  // 0 * 3
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_WithDefaultValues() {
                                                                                                 // Setup first vector (default values)
                                                                                                 OpenMapRealVector vector1 = new OpenMapRealVector(2);
                                                                                                 
                                                                                                 // Setup second vector (1, 2)
                                                                                                 OpenMapRealVector vector2 = new OpenMapRealVector(2);
                                                                                                 vector2.setEntry(0, 1.0);
                                                                                                 vector2.setEntry(1, 2.0);
                                                                                                 
                                                                                                 // Multiply and verify
                                                                                                 OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                                                                 assertEquals(0.0, result.getEntry(0), 0.0001);  // default * 1
                                                                                                 assertEquals(0.0, result.getEntry(1), 0.0001);  // default * 2
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_DimensionMismatch() {
                                                                                                 OpenMapRealVector vector1 = new OpenMapRealVector(3);
                                                                                                 OpenMapRealVector vector2 = new OpenMapRealVector(4);
                                                                                                 
                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                 vector1.ebeMultiply(vector2);
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_WithExtremeValues() {
                                                                                                 // Setup first vector (MAX_VALUE, MIN_VALUE)
                                                                                                 OpenMapRealVector vector1 = new OpenMapRealVector(2);
                                                                                                 vector1.setEntry(0, Double.MAX_VALUE);
                                                                                                 vector1.setEntry(1, Double.MIN_VALUE);
                                                                                                 
                                                                                                 // Setup second vector (2, 1000)
                                                                                                 OpenMapRealVector vector2 = new OpenMapRealVector(2);
                                                                                                 vector2.setEntry(0, 2.0);
                                                                                                 vector2.setEntry(1, 1000.0);
                                                                                                 
                                                                                                 // Multiply and verify
                                                                                                 OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                                                                 assertEquals(Double.MAX_VALUE * 2, result.getEntry(0), 0.0001);
                                                                                                 assertEquals(Double.MIN_VALUE * 1000, result.getEntry(1), 0.0001);
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_WithNaNValues() {
                                                                                                 // Setup first vector (1, NaN)
                                                                                                 OpenMapRealVector vector1 = new OpenMapRealVector(2);
                                                                                                 vector1.setEntry(0, 1.0);
                                                                                                 vector1.setEntry(1, Double.NaN);
                                                                                                 
                                                                                                 // Setup second vector (NaN, 1)
                                                                                                 OpenMapRealVector vector2 = new OpenMapRealVector(2);
                                                                                                 vector2.setEntry(0, Double.NaN);
                                                                                                 vector2.setEntry(1, 1.0);
                                                                                                 
                                                                                                 // Multiply and verify
                                                                                                 OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                                                                 assertTrue(Double.isNaN(result.getEntry(0)));  // 1 * NaN
                                                                                                 assertTrue(Double.isNaN(result.getEntry(1)));  // NaN * 1
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_WithInfiniteValues() {
                                                                                                 // Setup first vector (POS_INFINITY, NEG_INFINITY)
                                                                                                 OpenMapRealVector vector1 = new OpenMapRealVector(2);
                                                                                                 vector1.setEntry(0, Double.POSITIVE_INFINITY);
                                                                                                 vector1.setEntry(1, Double.NEGATIVE_INFINITY);
                                                                                                 
                                                                                                 // Setup second vector (2, -3)
                                                                                                 OpenMapRealVector vector2 = new OpenMapRealVector(2);
                                                                                                 vector2.setEntry(0, 2.0);
                                                                                                 vector2.setEntry(1, -3.0);
                                                                                                 
                                                                                                 // Multiply and verify
                                                                                                 OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0001);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0001);
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_TypicalCase() {
                                                                                                 // Setup
                                                                                                 double[] values = {1.0, 0.0, 3.0, 0.0, 5.0};
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                                                 double[] multiplier = {2.0, 4.0, 6.0, 8.0, 10.0};
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeMultiply(multiplier);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(5, result.getDimension());
                                                                                                 assertEquals(2.0, result.getEntry(0), 0.0001);  // 1.0 * 2.0
                                                                                                 assertEquals(0.0, result.getEntry(1), 0.0001);  // 0.0 * 4.0 (default value remains)
                                                                                                 assertEquals(18.0, result.getEntry(2), 0.0001); // 3.0 * 6.0
                                                                                                 assertEquals(0.0, result.getEntry(3), 0.0001);  // 0.0 * 8.0 (default value remains)
                                                                                                 assertEquals(50.0, result.getEntry(4), 0.0001);// 5.0 * 10.0
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_EmptyVector() {
                                                                                                 // Setup
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(0);
                                                                                                 double[] multiplier = {};
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeMultiply(multiplier);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(0, result.getDimension());
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_DimensionMismatch1() {
                                                                                                 // Setup
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0});
                                                                                                 double[] multiplier = {1.0};
                                                                                                 
                                                                                                 // Expect exception
                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                 thrown.expectMessage("vector length mismatch");
                                                                                                 
                                                                                                 // Execute
                                                                                                 vector.ebeMultiply(multiplier);
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_WithNegativeValues() {
                                                                                                 // Setup
                                                                                                 double[] values = {-1.0, 0.0, -3.0};
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                                                 double[] multiplier = {2.0, -4.0, 0.5};
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeMultiply(multiplier);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(3, result.getDimension());
                                                                                                 assertEquals(-2.0, result.getEntry(0), 0.0001);  // -1.0 * 2.0
                                                                                                 assertEquals(0.0, result.getEntry(1), 0.0001);   // 0.0 * -4.0 (default value remains)
                                                                                                 assertEquals(-1.5, result.getEntry(2), 0.0001);  // -3.0 * 0.5
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_AllDefaultValues() {
                                                                                                 // Setup
                                                                                                 double[] values = {0.0, 0.0, 0.0};
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                                                 double[] multiplier = {1.0, 2.0, 3.0};
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeMultiply(multiplier);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(3, result.getDimension());
                                                                                                 assertEquals(0.0, result.getEntry(0), 0.0001);
                                                                                                 assertEquals(0.0, result.getEntry(1), 0.0001);
                                                                                                 assertEquals(0.0, result.getEntry(2), 0.0001);
                                                                                                 // Verify sparsity
                                                                                                 assertEquals(1.0, result.getSparsity(), 0.0001); // All entries are default
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_WithZeroMultiplier() {
                                                                                                 // Setup
                                                                                                 double[] values = {1.0, 2.0, 3.0};
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                                                 double[] multiplier = {0.0, 0.0, 0.0};
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeMultiply(multiplier);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertEquals(3, result.getDimension());
                                                                                                 assertEquals(0.0, result.getEntry(0), 0.0001);
                                                                                                 assertEquals(0.0, result.getEntry(1), 0.0001);
                                                                                                 assertEquals(0.0, result.getEntry(2), 0.0001);
                                                                                             }

    @Test
                                                                                             public void testEbeMultiply_OriginalVectorUnchanged() {
                                                                                                 // Setup
                                                                                                 double[] values = {1.0, 2.0, 3.0};
                                                                                                 OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                                                 double[] multiplier = {2.0, 3.0, 4.0};
                                                                                                 
                                                                                                 // Execute
                                                                                                 OpenMapRealVector result = vector.ebeMultiply(multiplier);
                                                                                                 
                                                                                                 // Verify original vector unchanged
                                                                                                 assertEquals(1.0, vector.getEntry(0), 0.0001);
                                                                                                 assertEquals(2.0, vector.getEntry(1), 0.0001);
                                                                                                 assertEquals(3.0, vector.getEntry(2), 0.0001);
                                                                                             }

    @Test
                                                                                     public void testEbeDivide_TypicalValues1() {
                                                                                         // Create test vectors with values that will produce the expected results
                                                                                         double[] data1 = {1.0, 4.0, 1.0};  // numerator values
                                                                                         double[] data2 = {2.0, 2.0, 2.0};  // denominator values
                                                                                         OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                                                         OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                                                         
                                                                                         OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                                                         
                                                                                         assertEquals(3, result.getDimension());
                                                                                         assertEquals(0.5, result.getEntry(0), 0.0001);
                                                                                         assertEquals(2.0, result.getEntry(1), 0.0001);
                                                                                         assertEquals(0.5, result.getEntry(2), 0.0001);
                                                                                     }

    @Test
                                                                                     public void testEbeDivide_WithRealVector() {
                                                                                         // Create vector1 with values [1.0, 2.0, 3.0]
                                                                                         OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                                                                                         
                                                                                         // Create mock vector with values [1.0, 1.0, 1.0]
                                                                                         OpenMapRealVector mockVector = new OpenMapRealVector(new double[]{1.0, 1.0, 1.0});
                                                                                         
                                                                                         OpenMapRealVector result = vector1.ebeDivide(mockVector);
                                                                                         
                                                                                         assertEquals(3, result.getDimension());
                                                                                         assertEquals(1.0, result.getEntry(0), 0.0001);
                                                                                         assertEquals(2.0, result.getEntry(1), 0.0001);
                                                                                         assertEquals(3.0, result.getEntry(2), 0.0001);
                                                                                     }

    @Test
                                                                                     public void testEbeDivide_EmptyVectors1() {
                                                                                         OpenMapRealVector emptyVector1 = new OpenMapRealVector(0);
                                                                                         OpenMapRealVector emptyVector2 = new OpenMapRealVector(0);
                                                                                         OpenMapRealVector result = emptyVector1.ebeDivide(emptyVector2);
                                                                                         assertEquals(0, result.getDimension());
                                                                                     }

    @Test
                                                                                     public void testEbeDivide_DifferentDimensions() {
                                                                                         OpenMapRealVector vector1 = new OpenMapRealVector(3);
                                                                                         OpenMapRealVector differentDimVector = new OpenMapRealVector(5);
                                                                                         
                                                                                         thrown.expect(IllegalArgumentException.class);
                                                                                         thrown.expectMessage("vector length mismatch: 3 != 5");
                                                                                         
                                                                                         vector1.ebeDivide(differentDimVector);
                                                                                     }

    @Test
                                                                                     public void testEbeDivide_ResultIsNewInstance() {
                                                                                         // Create two test vectors
                                                                                         OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                                                                                         OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 2.0, 2.0});
                                                                                         
                                                                                         // Perform element-by-element division
                                                                                         OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                                                         
                                                                                         // Verify result is a new instance and not the same as input vectors
                                                                                         assertNotSame(vector1, result);
                                                                                         assertNotSame(vector2, result);
                                                                                     }

    @Test
                                             public void testEbeDivide_DivideByZero1() {
                                                 OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 1.0, 1.0});
                                                 OpenMapRealVector zeroVector = new OpenMapRealVector(new double[]{1.0, 0.0, 1.0});
                                                 
                                                 try {
                                                     vector1.ebeDivide(zeroVector);
                                                     fail("Expected ArithmeticException");
                                                 } catch (ArithmeticException e) {
                                                     assertEquals("/ by zero", e.getMessage());
                                                 }
                                             }

    @Test
                                             public void testEbeDivide_WithDefaultValues() {
                                                 // Create a vector with some non-zero values
                                                 OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                                                 OpenMapRealVector defaultVector = new OpenMapRealVector(3);
                                                 
                                                 // First verify dimension before exception is thrown
                                                 assertEquals(3, vector1.getDimension());
                                                 assertEquals(3, defaultVector.getDimension());
                                                 
                                                 try {
                                                     // Perform the operation that should throw exception
                                                     vector1.ebeDivide(defaultVector);
                                                     fail("Expected ArithmeticException");
                                                 } catch (ArithmeticException e) {
                                                     assertEquals("/ by zero", e.getMessage());
                                                 }
                                             }

    @Test
         public void testEbeMultiplyWithDifferentDimensionsShouldThrowException1() {
             // Create a vector with dimension 3
             double[] initialValues = {1.0, 2.0, 3.0};
             OpenMapRealVector vector = new OpenMapRealVector(initialValues);
             
             // Create an array with different dimension (2 instead of 3)
             double[] differentDimArray = {1.0, 2.0};
             
             // Expect an exception to be thrown for dimension mismatch
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("vector length mismatch: 3 != 2");
             
             // Perform the operation that should throw
             vector.ebeMultiply(differentDimArray);
         }

    @Test
         public void testEbeMultiplyWithCorrectDimensionsShouldNotThrow() {
             // Create a vector with dimension 3
             double[] initialValues = {1.0, 2.0, 3.0};
             OpenMapRealVector vector = new OpenMapRealVector(initialValues);
             
             // Create an array with matching dimension
             double[] sameDimArray = {2.0, 3.0, 4.0};
             
             // Perform the operation - should not throw
             OpenMapRealVector result = vector.ebeMultiply(sameDimArray);
             
             // Verify the result
             assertEquals(3, result.getDimension());
             assertEquals(2.0, result.getEntry(0), 0.0001);
             assertEquals(6.0, result.getEntry(1), 0.0001);
             assertEquals(12.0, result.getEntry(2), 0.0001);
         }

    @Test(expected = IllegalArgumentException.class)
    public void testEbeMultiplyWithDifferentDimensionsShouldThrowException() {
        // Create first vector with dimension 3
        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
        
        // Create second vector with different dimension (2 instead of 3)
        OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0});
        
        // This should throw IllegalArgumentException for dimension mismatch
        // The mutant version would not throw this exception
        vector1.ebeMultiply(vector2);
    }

    @Test
    public void testEbeMultiplyWithSameDimensionsShouldWork() {
        // Create vectors with same dimension
        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
        OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 3.0, 4.0});
        
        OpenMapRealVector result = vector1.ebeMultiply(vector2);
        
        // Verify the multiplication was correct
        assertEquals(2.0, result.getEntry(0), 0.0001);
        assertEquals(6.0, result.getEntry(1), 0.0001);
        assertEquals(12.0, result.getEntry(2), 0.0001);
    }


}
