package gentest.org.apache.commons.math.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.general.*;
import java.util.Arrays;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.optimization.OptimizationException;
import org.apache.commons.math.optimization.VectorialPointValuePair;
import org.apache.commons.math.util.MathUtils;
 
public class LevenbergMarquardtOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                  public void testDoOptimize_ConvergenceOnFirstIteration() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                                                                                      optimizer.setOrthoTolerance(0.1); // Set loose tolerance for easy convergence
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                                                                      Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                                                                                                                                      solvedColsField.setAccessible(true);
                                                                                                                                                                                                                                      solvedColsField.set(optimizer, 2);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                                                                                                      diagRField.setAccessible(true);
                                                                                                                                                                                                                                      diagRField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                                                                                                      jacNormField.setAccessible(true);
                                                                                                                                                                                                                                      jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                                                                                                      costField.setAccessible(true);
                                                                                                                                                                                                                                      costField.set(optimizer, 1.0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Execute doOptimize() using reflection
                                                                                                                                                                                                                                      Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                      VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                      assertNotNull(result);
                                                                                                                                                                                                                                      // Additional assertions would depend on actual implementation details
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                  public void testDoOptimize_MultipleIterationsUntilConvergence() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                                                                                      optimizer.setCostRelativeTolerance(1e-5);
                                                                                                                                                                                                                                      optimizer.setParRelativeTolerance(1e-5);
                                                                                                                                                                                                                                      optimizer.setOrthoTolerance(1e-5);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                                                                      Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                                                                                                                                      solvedColsField.setAccessible(true);
                                                                                                                                                                                                                                      solvedColsField.set(optimizer, 3);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                                                                                                      diagRField.setAccessible(true);
                                                                                                                                                                                                                                      diagRField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                                                                                                      jacNormField.setAccessible(true);
                                                                                                                                                                                                                                      jacNormField.set(optimizer, new double[]{0.5, 0.5, 0.5});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                                                                                                      costField.setAccessible(true);
                                                                                                                                                                                                                                      costField.set(optimizer, 10.0); // High initial cost that needs reduction
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to call protected doOptimize method
                                                                                                                                                                                                                                      Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                      VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                      assertNotNull(result);
                                                                                                                                                                                                                                      assertTrue(result.getValue()[0] < 10.0); // Cost should have reduced
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                  public void testDoOptimize_TooSmallCostRelativeTolerance() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                                                                                      optimizer.setCostRelativeTolerance(Double.MIN_VALUE);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                                                                      Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                                                                                                                                      solvedColsField.setAccessible(true);
                                                                                                                                                                                                                                      solvedColsField.set(optimizer, 2);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                                                                                                      diagRField.setAccessible(true);
                                                                                                                                                                                                                                      diagRField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                                                                                                      jacNormField.setAccessible(true);
                                                                                                                                                                                                                                      jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                                                                                                      costField.setAccessible(true);
                                                                                                                                                                                                                                      costField.set(optimizer, 1.0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Expect exception
                                                                                                                                                                                                                                      thrown.expect(OptimizationException.class);
                                                                                                                                                                                                                                      thrown.expectMessage("TOO_SMALL_COST_RELATIVE_TOLERANCE");
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to call protected method
                                                                                                                                                                                                                                      Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                      doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                  public void testDoOptimize_TooSmallParametersRelativeTolerance() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                                                                                      optimizer.setParRelativeTolerance(Double.MIN_VALUE);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                                                                      Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                                                                                                                                      solvedColsField.setAccessible(true);
                                                                                                                                                                                                                                      solvedColsField.set(optimizer, 2);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                                                                                                      diagRField.setAccessible(true);
                                                                                                                                                                                                                                      diagRField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                                                                                                      jacNormField.setAccessible(true);
                                                                                                                                                                                                                                      jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                                                                                                      costField.setAccessible(true);
                                                                                                                                                                                                                                      costField.set(optimizer, 1.0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Need to set xNorm through reflection since it's a local variable in doOptimize()
                                                                                                                                                                                                                                      // We'll set the conditions so that delta <= parRelativeTolerance * xNorm will be true
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Expect exception
                                                                                                                                                                                                                                      thrown.expect(OptimizationException.class);
                                                                                                                                                                                                                                      thrown.expectMessage("TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE");
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to call protected method
                                                                                                                                                                                                                                      Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                      doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                  public void testDoOptimize_FirstIterationAdjustments() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                                                                                      optimizer.setInitialStepBoundFactor(100.0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to access private fields
                                                                                                                                                                                                                                      Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                                                                                                                                      solvedColsField.setAccessible(true);
                                                                                                                                                                                                                                      solvedColsField.set(optimizer, 2);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                                                                                                      diagRField.setAccessible(true);
                                                                                                                                                                                                                                      diagRField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                                                                                                      jacNormField.setAccessible(true);
                                                                                                                                                                                                                                      jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                                                                                                      costField.setAccessible(true);
                                                                                                                                                                                                                                      costField.set(optimizer, 1.0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field firstIterationField = LevenbergMarquardtOptimizer.class.getDeclaredField("firstIteration");
                                                                                                                                                                                                                                      firstIterationField.setAccessible(true);
                                                                                                                                                                                                                                      firstIterationField.set(optimizer, true);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field xNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("xNorm");
                                                                                                                                                                                                                                      xNormField.setAccessible(true);
                                                                                                                                                                                                                                      xNormField.set(optimizer, 1.0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Execute using reflection to call protected method
                                                                                                                                                                                                                                      Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                      VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify first iteration adjustments were made
                                                                                                                                                                                                                                      assertNotNull(result);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify delta was adjusted based on initialStepBoundFactor and xNorm
                                                                                                                                                                                                                                      Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                                                                                                                                                                                                                                      deltaField.setAccessible(true);
                                                                                                                                                                                                                                      double delta = (Double) deltaField.get(optimizer);
                                                                                                                                                                                                                                      assertEquals(100.0, delta, 1.0e-12);  // initialStepBoundFactor * xNorm (100.0 * 1.0)
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                      public void testDoOptimize_WithConvergenceChecker() throws Exception {
                                                                                                                                                          // Setup
                                                                                                                                                          org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                                                                              new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                          
                                                                                                                                                          @SuppressWarnings("unchecked")
                                                                                                                                                          // Mock the checker to return true on first check
                                                                                                                                                          java.lang.reflect.Field diagRField = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                          diagRField.setAccessible(true);
                                                                                                                                                          diagRField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                          
                                                                                                                                                          java.lang.reflect.Field jacNormField = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                          jacNormField.setAccessible(true);
                                                                                                                                                          jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                          
                                                                                                                                                          java.lang.reflect.Field costField = org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                          costField.setAccessible(true);
                                                                                                                                                          costField.set(optimizer, 1.0);
                                                                                                                                                          
                                                                                                                                                          // Execute using reflection
                                                                                                                                                          java.lang.reflect.Method doOptimizeMethod = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                          doOptimizeMethod.setAccessible(true);
                                                                                                                                                          
                                                                                                                                                          // Verify
                                                                                                                                                      }

    @Test
                                                                                                                                              public void testDoOptimize_TooSmallOrthogonalityTolerance() throws Exception {
                                                                                                                                                  // Setup
                                                                                                                                                  LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                  optimizer.setOrthoTolerance(Double.MIN_VALUE);
                                                                                                                                                  
                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                  Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                                                  solvedColsField.setAccessible(true);
                                                                                                                                                  solvedColsField.set(optimizer, 2);
                                                                                                                                                  
                                                                                                                                                  Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                  diagRField.setAccessible(true);
                                                                                                                                                  diagRField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                  
                                                                                                                                                  Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                  jacNormField.setAccessible(true);
                                                                                                                                                  jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                  
                                                                                                                                                  Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                  costField.setAccessible(true);
                                                                                                                                                  costField.set(optimizer, 1.0);
                                                                                                                                                  
                                                                                                                                                  // Create subclass to access protected method
                                                                                                                                                  LevenbergMarquardtOptimizer testOptimizer = new LevenbergMarquardtOptimizer() {
                                                                                                                                                      @Override
                                                                                                                                                      protected VectorialPointValuePair doOptimize() throws OptimizationException {
                                                                                                                                                          // Set maxCosine through reflection
                                                                                                                                                          try {
                                                                                                                                                              Field maxCosineField = LevenbergMarquardtOptimizer.class.getDeclaredField("maxCosine");
                                                                                                                                                              maxCosineField.setAccessible(true);
                                                                                                                                                              maxCosineField.set(this, Double.MIN_VALUE);
                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                              throw new RuntimeException(e);
                                                                                                                                                          }
                                                                                                                                                          throw new OptimizationException("TOO_SMALL_ORTHOGONALITY_TOLERANCE");
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                                  
                                                                                                                                                  // Copy configuration to test optimizer
                                                                                                                                                  testOptimizer.setOrthoTolerance(Double.MIN_VALUE);
                                                                                                                                                  
                                                                                                                                                  // Use reflection to copy other fields
                                                                                                                                                  solvedColsField.set(testOptimizer, 2);
                                                                                                                                                  diagRField.set(testOptimizer, new double[]{1.0, 1.0});
                                                                                                                                                  jacNormField.set(testOptimizer, new double[]{1.0, 1.0});
                                                                                                                                                  costField.set(testOptimizer, 1.0);
                                                                                                                                                  
                                                                                                                                                  // Expect exception
                                                                                                                                                  thrown.expect(OptimizationException.class);
                                                                                                                                                  thrown.expectMessage("TOO_SMALL_ORTHOGONALITY_TOLERANCE");
                                                                                                                                                  
                                                                                                                                                  // Execute through reflection
                                                                                                                                                  Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                  doOptimizeMethod.setAccessible(true);
                                                                                                                                                  doOptimizeMethod.invoke(testOptimizer);
                                                                                                                                              }

    @Test
                                                                                                                                 public void testSolvedColsInitialization() throws OptimizationException, FunctionEvaluationException {
                                                                                                                                     // Create test subclass that exposes doOptimize()
                                                                                                                                     class TestOptimizer extends LevenbergMarquardtOptimizer {
                                                                                                                                         public int rows;
                                                                                                                                         public int cols;
                                                                                                                                         
                                                                                                                                         @Override
                                                                                                                                         public VectorialPointValuePair doOptimize() throws FunctionEvaluationException, OptimizationException {
                                                                                                                                             // Setup test data
                                                                                                                                             return super.doOptimize();
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         public VectorialPointValuePair optimize() throws FunctionEvaluationException, OptimizationException {
                                                                                                                                             return doOptimize();
                                                                                                                                         }
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     // Test case where rows > cols
                                                                                                                                     TestOptimizer optimizer1 = new TestOptimizer() {
                                                                                                                                         @Override
                                                                                                                                         public VectorialPointValuePair doOptimize() throws FunctionEvaluationException, OptimizationException {
                                                                                                                                             // Setup test data with 5 rows and 3 columns
                                                                                                                                             rows = 5;
                                                                                                                                             cols = 3;
                                                                                                                                             return super.doOptimize();
                                                                                                                                         }
                                                                                                                                     };
                                                                                                                                     
                                                                                                                                     try {
                                                                                                                                         VectorialPointValuePair result1 = optimizer1.optimize();
                                                                                                                                         assertNotNull(result1); // Verify optimization completes
                                                                                                                                     } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                         fail("Array index out of bounds - solvedCols was likely set incorrectly");
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     // Test case where cols > rows
                                                                                                                                     TestOptimizer optimizer2 = new TestOptimizer() {
                                                                                                                                         @Override
                                                                                                                                         public VectorialPointValuePair doOptimize() throws FunctionEvaluationException, OptimizationException {
                                                                                                                                             // Setup test data with 2 rows and 4 columns
                                                                                                                                             rows = 2;
                                                                                                                                             cols = 4;
                                                                                                                                             return super.doOptimize();
                                                                                                                                         }
                                                                                                                                     };
                                                                                                                                     
                                                                                                                                     try {
                                                                                                                                         VectorialPointValuePair result2 = optimizer2.optimize();
                                                                                                                                         assertNotNull(result2); // Verify optimization completes
                                                                                                                                     } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                         fail("Array index out of bounds - solvedCols was likely set incorrectly");
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     // Test case where rows == cols
                                                                                                                                     TestOptimizer optimizer3 = new TestOptimizer() {
                                                                                                                                         @Override
                                                                                                                                         public VectorialPointValuePair doOptimize() throws FunctionEvaluationException, OptimizationException {
                                                                                                                                             // Setup test data with 3 rows and 3 columns
                                                                                                                                             rows = 3;
                                                                                                                                             cols = 3;
                                                                                                                                             return super.doOptimize();
                                                                                                                                         }
                                                                                                                                     };
                                                                                                                                     
                                                                                                                                     try {
                                                                                                                                         VectorialPointValuePair result3 = optimizer3.optimize();
                                                                                                                                         assertNotNull(result3); // Verify optimization completes
                                                                                                                                     } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                         fail("Array index out of bounds - solvedCols was likely set incorrectly");
                                                                                                                                     }
                                                                                                                                 }

    @Test
                                                                                                                            public void testFirstIterationBehavior() {
                                                                                                                                // Setup
                                                                                                                                LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    // Execute using reflection to access protected method
                                                                                                                                    Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                    doOptimizeMethod.setAccessible(true);
                                                                                                                                    VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                    
                                                                                                                                    // Using reflection to track internal state
                                                                                                                                    java.lang.reflect.Field firstIterationField = LevenbergMarquardtOptimizer.class.getDeclaredField("firstIteration");
                                                                                                                                    firstIterationField.setAccessible(true);
                                                                                                                                    boolean firstIteration = firstIterationField.getBoolean(optimizer);
                                                                                                                                    
                                                                                                                                    // Verify first iteration flag was properly handled
                                                                                                                                    assertFalse("After first iteration, flag should be false", firstIteration);
                                                                                                                                    
                                                                                                                                    // Verify delta was properly adjusted (depends on lmPar)
                                                                                                                                    java.lang.reflect.Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                                                                                                                                    deltaField.setAccessible(true);
                                                                                                                                    double delta = deltaField.getDouble(optimizer);
                                                                                                                                    assertTrue("Delta should be positive", delta > 0);
                                                                                                                                    
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                        public void testLmParInitialization() {
                                                                                                                            // Setup
                                                                                                                            LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                            
                                                                                                                            try {
                                                                                                                                // Use reflection to access protected doOptimize method
                                                                                                                                java.lang.reflect.Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                doOptimizeMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                
                                                                                                                                // Verify lmPar was initialized to 0 (not 1 as in mutant)
                                                                                                                                // Using reflection to access private field for testing purposes
                                                                                                                                java.lang.reflect.Field lmParField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmPar");
                                                                                                                                lmParField.setAccessible(true);
                                                                                                                                double actualLmPar = lmParField.getDouble(optimizer);
                                                                                                                                
                                                                                                                                // Assert initial value is 0 (original behavior)
                                                                                                                                assertEquals("Initial lmPar should be 0", 0.0, actualLmPar, 1e-15);
                                                                                                                                
                                                                                                                                // Additional checks to ensure proper optimization behavior
                                                                                                                                assertNotNull("Optimization result should not be null", result);
                                                                                                                                for (double value : result.getValue()) {
                                                                                                                                    assertTrue("All cost values should be finite", Double.isFinite(value));
                                                                                                                                }
                                                                                                                                
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Exception occurred during test: " + e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                    public void testDoOptimizeWithZeroColumnNorm() {
                                                                                                                        // Setup
                                                                                                                        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                        
                                                                                                                        // Mock or set up test data where one column norm is zero
                                                                                                                        int rows = 3;
                                                                                                                        int cols = 3;
                                                                                                                        double[] point = {1.0, 2.0, 3.0};
                                                                                                                        double[] jacNorm = {1.0, 0.0, 1.0}; // Second column has zero norm
                                                                                                                        
                                                                                                                        // Use reflection to set private fields needed for the test
                                                                                                                        try {
                                                                                                                            Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                            jacNormField.setAccessible(true);
                                                                                                                            jacNormField.set(optimizer, jacNorm);
                                                                                                                            
                                                                                                                            Field rowsField = LevenbergMarquardtOptimizer.class.getDeclaredField("rows");
                                                                                                                            rowsField.setAccessible(true);
                                                                                                                            rowsField.set(optimizer, rows);
                                                                                                                            
                                                                                                                            Field colsField = LevenbergMarquardtOptimizer.class.getDeclaredField("cols");
                                                                                                                            colsField.setAccessible(true);
                                                                                                                            colsField.set(optimizer, cols);
                                                                                                                            
                                                                                                                            Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                                                                                            pointField.setAccessible(true);
                                                                                                                            pointField.set(optimizer, point);
                                                                                                                            
                                                                                                                            // Execute the critical section of doOptimize()
                                                                                                                            Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                            doOptimizeMethod.setAccessible(true);
                                                                                                                            doOptimizeMethod.invoke(optimizer);
                                                                                                                            
                                                                                                                            // Verify that zero norm was handled correctly (replaced with 1.0)
                                                                                                                            Field diagField = LevenbergMarquardtOptimizer.class.getDeclaredField("diag");
                                                                                                                            diagField.setAccessible(true);
                                                                                                                            double[] diag = (double[]) diagField.get(optimizer);
                                                                                                                            
                                                                                                                            // The zero norm (jacNorm[1]) should have been replaced with 1.0
                                                                                                                            assertEquals(1.0, diag[1], 1e-10);
                                                                                                                            
                                                                                                                            // Verify xNorm calculation was correct
                                                                                                                            Field xNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("xNorm");
                                                                                                                            xNormField.setAccessible(true);
                                                                                                                            double xNorm = (double) xNormField.get(optimizer);
                                                                                                                            
                                                                                                                            // Expected xNorm = sqrt( (1.0*1.0)^2 + (1.0*2.0)^2 + (1.0*3.0)^2 )
                                                                                                                            double expectedXNorm = Math.sqrt(1 + 4 + 9);
                                                                                                                            assertEquals(expectedXNorm, xNorm, 1e-10);
                                                                                                                            
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                  public void testDeltaInitializationWhenXNormIsZero() throws Exception {
                                                                                                                      // Setup
                                                                                                                      LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                      optimizer.setInitialStepBoundFactor(100.0); // Set a known value for testing
                                                                                                                      
                                                                                                                      // Use reflection to set private fields needed for the test
                                                                                                                      Field initialStepBoundFactorField = LevenbergMarquardtOptimizer.class.getDeclaredField("initialStepBoundFactor");
                                                                                                                      initialStepBoundFactorField.setAccessible(true);
                                                                                                                      initialStepBoundFactorField.set(optimizer, 100.0);
                                                                                                                      
                                                                                                                      Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                                                                                      pointField.setAccessible(true);
                                                                                                                      double[] zeroPoint = new double[10]; // Array of zeros
                                                                                                                      pointField.set(optimizer, zeroPoint);
                                                                                                                      
                                                                                                                      Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                      jacNormField.setAccessible(true);
                                                                                                                      double[] ones = new double[10];
                                                                                                                      Arrays.fill(ones, 1.0);
                                                                                                                      jacNormField.set(optimizer, ones);
                                                                                                                      
                                                                                                                      // Mock necessary dependencies
                                                                                                                      // (Assuming these would be needed for the method to run)
                                                                                                                      // ...
                                                                                                                      
                                                                                                                      // Execute
                                                                                                                      try {
                                                                                                                          // Use reflection to access protected doOptimize method
                                                                                                                          Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                          doOptimizeMethod.setAccessible(true);
                                                                                                                          doOptimizeMethod.invoke(optimizer);
                                                                                                                      } catch (Exception e) {
                                                                                                                          // We're mainly interested in the delta initialization
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Verify
                                                                                                                      Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                                                                                                                      deltaField.setAccessible(true);
                                                                                                                      double delta = deltaField.getDouble(optimizer);
                                                                                                                      
                                                                                                                      // Original behavior would set delta to initialStepBoundFactor (100.0)
                                                                                                                      // Mutant would set it to 0 (100.0 * 0)
                                                                                                                      assertEquals("Delta should be initialized to initialStepBoundFactor when xNorm is 0", 
                                                                                                                                  100.0, delta, 1e-10);
                                                                                                                  }

    @Test
                                                                                                             public void testConvergenceAtOrthoToleranceBoundary() {
                                                                                                                 // Setup
                                                                                                                 LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                 optimizer.setOrthoTolerance(0.5); // Set a specific tolerance value
                                                                                                                 
                                                                                                                 // Mock or setup the state to force maxCosine to exactly equal orthoTolerance
                                                                                                                 // This requires manipulating the internal state to create the boundary condition
                                                                                                                 // Since many fields are private, we'll use reflection to set them
                                                                                                                 
                                                                                                                 try {
                                                                                                                     // Set solvedCols to a non-zero value
                                                                                                                     Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                     solvedColsField.setAccessible(true);
                                                                                                                     solvedColsField.set(optimizer, 1);
                                                                                                                     
                                                                                                                     // Set cost to non-zero
                                                                                                                     Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                                                                                                                     costField.setAccessible(true);
                                                                                                                     costField.set(optimizer, 1.0);
                                                                                                                     
                                                                                                                     // Setup jacNorm and jacobian to create the boundary condition
                                                                                                                     Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                     jacNormField.setAccessible(true);
                                                                                                                     double[] jacNorm = new double[1];
                                                                                                                     jacNorm[0] = 1.0;
                                                                                                                     jacNormField.set(optimizer, jacNorm);
                                                                                                                     
                                                                                                                     Field jacobianField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacobian");
                                                                                                                     jacobianField.setAccessible(true);
                                                                                                                     double[][] jacobian = new double[1][1];
                                                                                                                     jacobian[0][0] = 0.5; // This will make maxCosine = 0.5 when combined with qtf
                                                                                                                     jacobianField.set(optimizer, jacobian);
                                                                                                                     
                                                                                                                     // Setup permutation array
                                                                                                                     Field permutationField = LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
                                                                                                                     permutationField.setAccessible(true);
                                                                                                                     int[] permutation = new int[1];
                                                                                                                     permutation[0] = 0;
                                                                                                                     permutationField.set(optimizer, permutation);
                                                                                                                     
                                                                                                                     // Setup qtf array to create the boundary condition
                                                                                                                     Field qtfField = LevenbergMarquardtOptimizer.class.getDeclaredField("qtf");
                                                                                                                     qtfField.setAccessible(true);
                                                                                                                     double[] qtf = new double[1];
                                                                                                                     qtf[0] = 0.5; // This will make maxCosine exactly equal orthoTolerance (0.5)
                                                                                                                     qtfField.set(optimizer, qtf);
                                                                                                                     
                                                                                                                 } catch (Exception e) {
                                                                                                                     fail("Failed to setup test via reflection: " + e.getMessage());
                                                                                                                 }
                                                                                                                 
                                                                                                                 // Execute using reflection to call protected method
                                                                                                                 VectorialPointValuePair result = null;
                                                                                                                 try {
                                                                                                                     Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                     doOptimizeMethod.setAccessible(true);
                                                                                                                     result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                 } catch (Exception e) {
                                                                                                                     fail("Failed to invoke doOptimize via reflection: " + e.getMessage());
                                                                                                                 }
                                                                                                                 
                                                                                                                 // Verify - the original should converge (return normally), while mutant would continue iterating
                                                                                                                 assertNotNull("Optimizer should return a result when maxCosine equals orthoTolerance", result);
                                                                                                                 
                                                                                                                 // Additional verification that we actually hit the convergence condition
                                                                                                                 try {
                                                                                                                     Field maxCosineField = LevenbergMarquardtOptimizer.class.getDeclaredField("maxCosine");
                                                                                                                     maxCosineField.setAccessible(true);
                                                                                                                     double maxCosine = (Double)maxCosineField.get(optimizer);
                                                                                                                     assertEquals(0.5, maxCosine, 1e-10);
                                                                                                                 } catch (Exception e) {
                                                                                                                     fail("Verification failed: " + e.getMessage());
                                                                                                                 }
                                                                                                             }

    @Test
                                                                                                        public void testDiagonalScalingBehavior() throws Exception {
                                                                                                            // Setup test with known values that will expose the mutation
                                                                                                            LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                            
                                                                                                            // Use reflection to access private fields for testing
                                                                                                            Field diagField = LevenbergMarquardtOptimizer.class.getDeclaredField("diag");
                                                                                                            Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                            diagField.setAccessible(true);
                                                                                                            jacNormField.setAccessible(true);
                                                                                                            
                                                                                                            // Create test data where diag and jacNorm have different values
                                                                                                            int cols = 3;
                                                                                                            double[] diag = new double[cols];
                                                                                                            double[] jacNorm = new double[cols];
                                                                                                            
                                                                                                            // Set values where diag[j] < jacNorm[j] for some j
                                                                                                            diag[0] = 1.0; jacNorm[0] = 2.0;  // diag < jacNorm
                                                                                                            diag[1] = 3.0; jacNorm[1] = 3.0;  // equal
                                                                                                            diag[2] = 4.0; jacNorm[2] = 2.0;  // diag > jacNorm
                                                                                                            
                                                                                                            // Set these arrays in the optimizer
                                                                                                            diagField.set(optimizer, diag);
                                                                                                            jacNormField.set(optimizer, jacNorm);
                                                                                                            
                                                                                                            // Use reflection to access the protected doOptimize method
                                                                                                            Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                            doOptimizeMethod.setAccessible(true);
                                                                                                            
                                                                                                            // Execute the optimization step that contains the mutated line
                                                                                                            try {
                                                                                                                doOptimizeMethod.invoke(optimizer);
                                                                                                            } catch (Exception e) {
                                                                                                                // We're only interested in the diagonal scaling behavior
                                                                                                            }
                                                                                                            
                                                                                                            // Verify the diagonal was updated correctly (should use Math.max)
                                                                                                            double[] updatedDiag = (double[]) diagField.get(optimizer);
                                                                                                            assertEquals(2.0, updatedDiag[0], 1e-10);  // Should take jacNorm value (max)
                                                                                                            assertEquals(3.0, updatedDiag[1], 1e-10);  // Should stay same
                                                                                                            assertEquals(4.0, updatedDiag[2], 1e-10);  // Should keep diag value (max)
                                                                                                            
                                                                                                            // The mutant would fail this test because:
                                                                                                            // - For index 0, mutant would set to 1.0 (min) instead of 2.0 (max)
                                                                                                            // - For index 2, mutant would set to 2.0 (min) instead of 4.0 (max)
                                                                                                        }

    @Test
                                                                                                   public void testInnerLoopExecutionWithSmallRatio() {
                                                                                                       // Setup test with conditions that would produce small initial ratio
                                                                                                       LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                       
                                                                                                       try {
                                                                                                           // Get initial cost and lmPar using reflection
                                                                                                           Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                           doOptimize.setAccessible(true);
                                                                                                           
                                                                                                           Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                                                                                                           costField.setAccessible(true);
                                                                                                           double initialCost = (double) costField.get(optimizer);
                                                                                                           
                                                                                                           Field lmParField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmPar");
                                                                                                           lmParField.setAccessible(true);
                                                                                                           double initialLmPar = (double) lmParField.get(optimizer);
                                                                                                           
                                                                                                           // Execute optimization
                                                                                                           VectorialPointValuePair result = (VectorialPointValuePair) doOptimize.invoke(optimizer);
                                                                                                           
                                                                                                           // Get final cost
                                                                                                           double finalCost = (double) costField.get(optimizer);
                                                                                                           
                                                                                                           // Verify that optimization made progress
                                                                                                           assertTrue("Optimization should make progress", 
                                                                                                               finalCost < initialCost);
                                                                                                           
                                                                                                           // Verify LM parameter was updated
                                                                                                           double finalLmPar = (double) lmParField.get(optimizer);
                                                                                                           assertNotEquals("LM parameter should be updated", 
                                                                                                               initialLmPar, finalLmPar, 1e-10);
                                                                                                           
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Test failed with exception: " + e.getMessage());
                                                                                                       }
                                                                                                   }

    @Test
                                                                                               public void testCostReductionCalculation() {
                                                                                                   // Setup test with mock data
                                                                                                   LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                   
                                                                                                   // Use reflection to access private fields since we need to set up test conditions
                                                                                                   try {
                                                                                                       // Case 1: current cost is 9% of previous cost (0.1*cost < previousCost)
                                                                                                       Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                                                                                                       costField.setAccessible(true);
                                                                                                       costField.set(optimizer, 9.0);  // current cost
                                                                                                       
                                                                                                       Field previousCostField = LevenbergMarquardtOptimizer.class.getDeclaredField("previousCost");
                                                                                                       previousCostField.setAccessible(true);
                                                                                                       previousCostField.set(optimizer, 100.0);  // previous cost
                                                                                                       
                                                                                                       // This should trigger the cost reduction calculation in original code
                                                                                                       // but not in mutant
                                                                                                       Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                       doOptimize.setAccessible(true);
                                                                                                       VectorialPointValuePair result = (VectorialPointValuePair) doOptimize.invoke(optimizer);
                                                                                                       
                                                                                                       // Verify actRed was calculated (not -1) in original
                                                                                                       // In mutant, this would be -1
                                                                                                       // We can verify this by checking if the optimization progressed
                                                                                                       assertNotEquals(100.0, previousCostField.get(optimizer));
                                                                                                       
                                                                                                       // Case 2: current cost is 11% of previous cost (0.1*cost > previousCost in mutant)
                                                                                                       costField.set(optimizer, 110.0);  // current cost
                                                                                                       previousCostField.set(optimizer, 100.0);  // previous cost
                                                                                                       
                                                                                                       // This should NOT trigger calculation in original but WOULD in mutant
                                                                                                       result = (VectorialPointValuePair) doOptimize.invoke(optimizer);
                                                                                                       
                                                                                                       // Verify actRed was -1 (no calculation) in original
                                                                                                       // In mutant, this would have calculated reduction
                                                                                                       assertEquals(100.0, previousCostField.get(optimizer));
                                                                                                       
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Reflection failed: " + e.getMessage());
                                                                                                   }
                                                                                               }

    @Test
                                                                                         public void testDivisionByZeroWhenPreRedIsZero() throws OptimizationException {
                                                                                             // Create optimizer instance
                                                                                             LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                             
                                                                                             // Setup test to force preRed = 0
                                                                                             // We'll mock the internal state to create conditions where:
                                                                                             // - previousCost is non-zero
                                                                                             // - coeff1 and coeff2 both evaluate to 0
                                                                                             // - lmPar is non-zero
                                                                                             // - lmNorm is non-zero
                                                                                             
                                                                                             // Mock the internal state via reflection (since fields are private)
                                                                                             // This is a simplified approach - in real testing you'd use proper mocking or test hooks
                                                                                             try {
                                                                                                 java.lang.reflect.Field lmParField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmPar");
                                                                                                 lmParField.setAccessible(true);
                                                                                                 lmParField.set(optimizer, 1.0);
                                                                                                 
                                                                                                 java.lang.reflect.Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                 solvedColsField.setAccessible(true);
                                                                                                 solvedColsField.set(optimizer, 1);
                                                                                                 
                                                                                                 // Mock the internal arrays to return 0 for work1 calculations
                                                                                                 // This will make coeff1 = 0
                                                                                                 java.lang.reflect.Field work1Field = LevenbergMarquardtOptimizer.class.getDeclaredField("work1");
                                                                                                 work1Field.setAccessible(true);
                                                                                                 work1Field.set(optimizer, new double[]{0.0});
                                                                                                 
                                                                                                 // Mock previousCost to be non-zero (1.0)
                                                                                                 // This will make pc2 = 1.0 and coeff2 = lmPar * lmNorm^2
                                                                                                 // But we need to make coeff2 = 0, so we need lmNorm = 0
                                                                                                 java.lang.reflect.Field lmNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
                                                                                                 lmNormField.setAccessible(true);
                                                                                                 lmNormField.set(optimizer, new double[]{0.0});
                                                                                                 
                                                                                                 // Use reflection to call the protected method
                                                                                                 java.lang.reflect.Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                 doOptimizeMethod.setAccessible(true);
                                                                                                 doOptimizeMethod.invoke(optimizer);
                                                                                                 
                                                                                             } catch (NoSuchFieldException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                                                                                                 throw new RuntimeException("Test setup failed", e);
                                                                                             }
                                                                                         }

    @Test
                                                                                     public void testStepBoundAdjustmentWithHighCostRatio() {
                                                                                         // Setup test fixture
                                                                                         LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                         
                                                                                         // Use reflection to access private fields since we need to control internal state
                                                                                         try {
                                                                                             // Set initial state where 0.1 * cost > previousCost
                                                                                             Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                                                                                             costField.setAccessible(true);
                                                                                             costField.set(optimizer, 100.0); // current cost
                                                                                             
                                                                                             Field previousCostField = LevenbergMarquardtOptimizer.class.getDeclaredField("previousCost");
                                                                                             previousCostField.setAccessible(true);
                                                                                             previousCostField.set(optimizer, 5.0); // previous cost (0.1 * 100 > 5)
                                                                                             
                                                                                             Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                                                                                             deltaField.setAccessible(true);
                                                                                             deltaField.set(optimizer, 10.0); // initial delta
                                                                                             
                                                                                             Field lmNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmNorm");
                                                                                             lmNormField.setAccessible(true);
                                                                                             lmNormField.set(optimizer, 5.0); // lmNorm value
                                                                                             
                                                                                             Field tmpField = LevenbergMarquardtOptimizer.class.getDeclaredField("tmp");
                                                                                             tmpField.setAccessible(true);
                                                                                             tmpField.set(optimizer, 0.05); // tmp value < 0.1
                                                                                             
                                                                                             // Execute the relevant portion of code
                                                                                             Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                             doOptimize.setAccessible(true);
                                                                                             doOptimize.invoke(optimizer);
                                                                                             
                                                                                             // Verify delta was adjusted correctly
                                                                                             double finalDelta = (Double) deltaField.get(optimizer);
                                                                                             
                                                                                             // In original code: (0.1 * 100 >= 5) is true, so tmp would be set to 0.1
                                                                                             // delta should be 0.1 * min(10, 10*5) = 0.1 * 10 = 1.0
                                                                                             assertEquals(1.0, finalDelta, 1.0e-12);
                                                                                             
                                                                                             // In mutated code: (0.1 * 100 <= 5) is false, so different path would be taken
                                                                                             // This assertion would fail for mutated code
                                                                                         } catch (Exception e) {
                                                                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                         }
                                                                                     }

    @Test
                                                                                   public void testLmParInitialization1() throws Exception {
                                                                                       // Setup
                                                                                       LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                       
                                                                                       // Create test data (simplified for this test case)
                                                                                       // In a real scenario, we would need proper input data
                                                                                       // For this test, we just need to trigger the optimization
                                                                                       
                                                                                       // Execute
                                                                                       try {
                                                                                           // Use reflection to access protected doOptimize method
                                                                                           Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                           doOptimize.setAccessible(true);
                                                                                           doOptimize.invoke(optimizer);
                                                                                       } catch (Exception e) {
                                                                                           // We're only interested in checking the initial lmPar value
                                                                                           // so we can ignore optimization failures for this test
                                                                                       }
                                                                                       
                                                                                       // Verify lmPar was initialized to 0
                                                                                       Field lmParField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmPar");
                                                                                       lmParField.setAccessible(true);
                                                                                       double lmParValue = lmParField.getDouble(optimizer);
                                                                                       
                                                                                       // Assert the initial value is 0 (original behavior)
                                                                                       // This will fail if the mutant (lmPar = 1) is present
                                                                                       assertEquals("Initial lmPar should be 0", 0.0, lmParValue, 1e-15);
                                                                                       
                                                                                       // Additional check: verify it's not 1 (mutant value)
                                                                                       assertNotEquals("Initial lmPar should not be 1", 1.0, lmParValue, 1e-15);
                                                                                   }

    @Test
                                                                              public void testDoOptimizeHandlesZeroColumnNorm() {
                                                                                  // Setup test with one column having zero norm
                                                                                  LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                  
                                                                                  // Mock or create a problem where one column has zero norm
                                                                                  // For simplicity, we'll directly manipulate the jacNorm array through reflection
                                                                                  try {
                                                                                      // Set up test data with one zero norm column
                                                                                      int cols = 3;
                                                                                      int rows = 2;
                                                                                      double[] point = {1.0, 2.0, 3.0};
                                                                                      double[] objective = {0.1, 0.2};
                                                                                      
                                                                                      // Use reflection to set private fields for testing
                                                                                      Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                      jacNormField.setAccessible(true);
                                                                                      double[] jacNorm = new double[cols];
                                                                                      jacNorm[0] = 1.0;  // non-zero norm
                                                                                      jacNorm[1] = 0.0;  // zero norm - this is the case we're testing
                                                                                      jacNorm[2] = 2.0;  // non-zero norm
                                                                                      jacNormField.set(optimizer, jacNorm);
                                                                                      
                                                                                      Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                                                      pointField.setAccessible(true);
                                                                                      pointField.set(optimizer, point);
                                                                                      
                                                                                      Field objectiveField = LevenbergMarquardtOptimizer.class.getDeclaredField("objective");
                                                                                      objectiveField.setAccessible(true);
                                                                                      objectiveField.set(optimizer, objective);
                                                                                      
                                                                                      Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                      solvedColsField.setAccessible(true);
                                                                                      solvedColsField.set(optimizer, cols);
                                                                                      
                                                                                      // Call the protected method using reflection
                                                                                      Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                      VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                      
                                                                                      // Verify the scaling was handled correctly
                                                                                      // The zero norm column (index 1) should be replaced with 1.0
                                                                                      double[] resultPoint = result.getPoint();
                                                                                      double expectedXNorm = Math.sqrt(1.0*1.0*1.0 + 1.0*2.0*2.0 + 2.0*3.0*3.0);
                                                                                      double actualXNorm = 0;
                                                                                      for (int i = 0; i < cols; i++) {
                                                                                          actualXNorm += resultPoint[i] * resultPoint[i];
                                                                                      }
                                                                                      actualXNorm = Math.sqrt(actualXNorm);
                                                                                      
                                                                                      assertEquals(expectedXNorm, actualXNorm, 1e-10);
                                                                                      
                                                                                  } catch (Exception e) {
                                                                                      fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                  }
                                                                              }

    @Test
                                                                         public void testDoOptimizeWithZeroInitialPoint() {
                                                                             // Setup
                                                                             LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                             optimizer.setInitialStepBoundFactor(100.0); // Set a known value for testing
                                                                             
                                                                             // Mock the necessary components to force xNorm=0
                                                                             // We need to ensure all point values are 0 to get xNorm=0
                                                                             // This requires mocking the internal state to return zeros for point array
                                                                             
                                                                             // Using reflection to set internal state for testing
                                                                             try {
                                                                                 Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                                                 pointField.setAccessible(true);
                                                                                 double[] zeroPoint = new double[1]; // size doesn't matter as long as all elements are 0
                                                                                 pointField.set(optimizer, zeroPoint);
                                                                                 
                                                                                 Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                 jacNormField.setAccessible(true);
                                                                                 double[] ones = new double[1];
                                                                                 Arrays.fill(ones, 1.0); // To avoid division by zero in the code
                                                                                 jacNormField.set(optimizer, ones);
                                                                                 
                                                                                 // Execute using reflection to call protected method
                                                                                 Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                 doOptimizeMethod.setAccessible(true);
                                                                                 VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                 
                                                                                 // Verify delta was set correctly (should be initialStepBoundFactor when xNorm=0)
                                                                                 Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                                                                                 deltaField.setAccessible(true);
                                                                                 double delta = deltaField.getDouble(optimizer);
                                                                                 
                                                                                 // Original code would set delta to initialStepBoundFactor (100.0)
                                                                                 // Mutant would set it to 0
                                                                                 assertEquals("Delta should equal initialStepBoundFactor when xNorm=0", 
                                                                                             100.0, delta, 1.0e-10);
                                                                                 
                                                                             } catch (Exception e) {
                                                                                 fail("Test failed due to reflection exception: " + e.getMessage());
                                                                             }
                                                                         }

    @Test
                                                                    public void testConvergenceWhenMaxCosineEqualsTolerance() {
                                                                        // Setup
                                                                        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                        optimizer.setOrthoTolerance(0.5); // Set tolerance to known value
                                                                        
                                                                        // Use reflection to inject test values into private fields
                                                                        try {
                                                                            Field maxCosineField = LevenbergMarquardtOptimizer.class.getDeclaredField("maxCosine");
                                                                            maxCosineField.setAccessible(true);
                                                                            maxCosineField.set(optimizer, 0.5); // Exactly equals tolerance
                                                                            
                                                                            Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                                                                            costField.setAccessible(true);
                                                                            costField.set(optimizer, 1.0); // Non-zero cost
                                                                            
                                                                            // Mock necessary components
                                                                            Field residualsField = LevenbergMarquardtOptimizer.class.getDeclaredField("residuals");
                                                                            residualsField.setAccessible(true);
                                                                            residualsField.set(optimizer, new double[2]);
                                                                            
                                                                            Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                                            pointField.setAccessible(true);
                                                                            pointField.set(optimizer, new double[2]);
                                                                            
                                                                            Field objectiveField = LevenbergMarquardtOptimizer.class.getDeclaredField("objective");
                                                                            objectiveField.setAccessible(true);
                                                                            objectiveField.set(optimizer, new double[2]);
                                                                            
                                                                            // Use reflection to call protected doOptimize method
                                                                            Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                            doOptimizeMethod.setAccessible(true);
                                                                            VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                            
                                                                            // Verify - if the test reaches this point without infinite looping,
                                                                            // it means the original behavior (<=) was preserved.
                                                                            // The mutant (<) would cause the method to continue looping
                                                                            assertNotNull(result);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to setup or execute test via reflection: " + e.getMessage());
                                                                        }
                                                                    }

    @Test
                                                                public void testDiagScalingUpdate() throws Exception {
                                                                    // Setup test data where diag and jacNorm have different values
                                                                    int cols = 3;
                                                                    double[] diag = new double[] {1.0, 2.0, 3.0};
                                                                    double[] jacNorm = new double[] {1.5, 1.0, 3.5};
                                                                    
                                                                    // Create optimizer and set necessary private fields using reflection
                                                                    LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                    
                                                                    // Set private fields needed for the test
                                                                    Field diagField = LevenbergMarquardtOptimizer.class.getDeclaredField("diag");
                                                                    diagField.setAccessible(true);
                                                                    diagField.set(optimizer, diag);
                                                                    
                                                                    Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                    jacNormField.setAccessible(true);
                                                                    jacNormField.set(optimizer, jacNorm);
                                                                    
                                                                    Field colsField = LevenbergMarquardtOptimizer.class.getDeclaredField("cols");
                                                                    colsField.setAccessible(true);
                                                                    colsField.set(optimizer, cols);
                                                                    
                                                                    // Invoke the private method that contains the mutation
                                                                    Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                    doOptimize.setAccessible(true);
                                                                    doOptimize.invoke(optimizer);
                                                                    
                                                                    // Verify diag was updated with max values (original behavior)
                                                                    double[] updatedDiag = (double[]) diagField.get(optimizer);
                                                                    assertEquals(1.5, updatedDiag[0], 1e-15);  // max(1.0, 1.5)
                                                                    assertEquals(2.0, updatedDiag[1], 1e-15);  // max(2.0, 1.0)
                                                                    assertEquals(3.5, updatedDiag[2], 1e-15);  // max(3.0, 3.5)
                                                                    
                                                                    // This test will fail when the mutant is present since it would give:
                                                                    // min(1.0, 1.5) = 1.0
                                                                    // min(2.0, 1.0) = 1.0
                                                                    // min(3.0, 3.5) = 3.0
                                                                }

    @Test
                                                               public void testCostReductionCalculation1() {
                                                                   // Setup test with mock data
                                                                   LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                   
                                                                   // Use reflection to access private fields for testing
                                                                   try {
                                                                       // Set up initial state where previousCost is 100 and current cost is 5 (5 < 10% of 100)
                                                                       Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                                                                       costField.setAccessible(true);
                                                                       costField.set(optimizer, 5.0);
                                                                       
                                                                       Field previousCostField = LevenbergMarquardtOptimizer.class.getDeclaredField("previousCost");
                                                                       previousCostField.setAccessible(true);
                                                                       previousCostField.set(optimizer, 100.0);
                                                                       
                                                                       // This should trigger the actRed calculation in original, but not in mutant
                                                                       Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                       doOptimize.setAccessible(true);
                                                                       
                                                                       // The test will actually fail if the mutant is present because:
                                                                       // Original: actRed will be calculated (value != -1)
                                                                       // Mutant: actRed will remain -1 (condition not met)
                                                                       // We can verify this by checking intermediate state
                                                                       // Since we can't directly observe actRed, we'll verify the optimization result
                                                                       
                                                                       VectorialPointValuePair result = (VectorialPointValuePair) doOptimize.invoke(optimizer);
                                                                       
                                                                       // In original code, with proper actRed calculation, optimization should progress
                                                                       // In mutant code, without proper actRed calculation, optimization may stall
                                                                       // Verify that optimization made progress
                                                                       assertTrue(result.getValue()[0] < 100.0); // Assuming minimization
                                                                       
                                                                       // Additional test case where current cost is 15 (15 > 10% of 100)
                                                                       costField.set(optimizer, 15.0);
                                                                       previousCostField.set(optimizer, 100.0);
                                                                       result = (VectorialPointValuePair) doOptimize.invoke(optimizer);
                                                                       // In original, should not calculate actRed (remain -1)
                                                                       // In mutant, would incorrectly calculate actRed
                                                                       // Verify behavior is correct
                                                                       assertTrue(result.getValue()[0] < 100.0);
                                                                       
                                                                   } catch (Exception e) {
                                                                       fail("Test failed due to reflection exception: " + e.getMessage());
                                                                   }
                                                               }

    @Test
                                                         public void testTerminationConditionWithSingleTrueCondition() {
                                                             // Setup test case where only ratio <= 2.0 is true
                                                             // This should NOT throw exception in original code, but WILL throw in mutant
                                                             
                                                             // Create optimizer instance
                                                             LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                             
                                                             try {
                                                                 // Helper method to set private fields via reflection
                                                                 java.lang.reflect.Field costField = optimizer.getClass().getDeclaredField("cost");
                                                                 costField.setAccessible(true);
                                                                 costField.set(optimizer, 1.0); // Ensures actRed calculation > epsilon
                                                                 
                                                                 java.lang.reflect.Field lmParField = optimizer.getClass().getDeclaredField("lmPar");
                                                                 lmParField.setAccessible(true);
                                                                 lmParField.set(optimizer, 1.0); // Affects preRed calculation
                                                                 
                                                                 java.lang.reflect.Field deltaField = optimizer.getClass().getDeclaredField("delta");
                                                                 deltaField.setAccessible(true);
                                                                 deltaField.set(optimizer, 1.0); // Affects ratio calculation
                                                                 
                                                                 // Get the protected doOptimize method via reflection
                                                                 java.lang.reflect.Method doOptimizeMethod = optimizer.getClass().getDeclaredMethod("doOptimize");
                                                                 doOptimizeMethod.setAccessible(true);
                                                                 
                                                                 // Call the method - should NOT throw exception in original code
                                                                 VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                 
                                                                 // If we get here, the test passes (mutant would have thrown exception)
                                                                 assertNotNull(result);
                                                                 
                                                             } catch (Exception e) {
                                                                 if (e.getCause() instanceof OptimizationException) {
                                                                     // If we get here, the mutant was detected
                                                                     fail("OptimizationException was thrown when it shouldn't have been - mutant detected");
                                                                 } else {
                                                                     // Other reflection-related exceptions
                                                                     fail("Unexpected exception: " + e.getMessage());
                                                                 }
                                                             }
                                                         }

    @Test
                                                    public void testDoOptimize_SolvedColsCalculation() {
                                                        // Setup test with rows < cols
                                                        int rows = 3;
                                                        int cols = 5;
                                                        
                                                        // Create mock objects and set up test data
                                                        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                        
                                                        // Use reflection to access private fields for verification
                                                        try {
                                                            // Create test point and objective arrays
                                                            double[] point = new double[cols];
                                                            double[] objective = new double[rows];
                                                            
                                                            // Set some initial values
                                                            Arrays.fill(point, 1.0);
                                                            Arrays.fill(objective, 0.5);
                                                            
                                                            // Set up the problem using reflection to call protected method
                                                            Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                            doOptimizeMethod.setAccessible(true);
                                                            
                                                            // Set required fields for the optimizer
                                                            Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                            pointField.setAccessible(true);
                                                            pointField.set(optimizer, point);
                                                            
                                                            Field objectiveField = LevenbergMarquardtOptimizer.class.getDeclaredField("objective");
                                                            objectiveField.setAccessible(true);
                                                            objectiveField.set(optimizer, objective);
                                                            
                                                            Field rowsField = LevenbergMarquardtOptimizer.class.getDeclaredField("rows");
                                                            rowsField.setAccessible(true);
                                                            rowsField.set(optimizer, rows);
                                                            
                                                            Field colsField = LevenbergMarquardtOptimizer.class.getDeclaredField("cols");
                                                            colsField.setAccessible(true);
                                                            colsField.set(optimizer, cols);
                                                            
                                                            // Call the optimization
                                                            VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                            
                                                            // Verify solvedCols was set correctly
                                                            Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                            solvedColsField.setAccessible(true);
                                                            int solvedColsValue = (int) solvedColsField.get(optimizer);
                                                            
                                                            // Should be min(rows, cols) = 3
                                                            assertEquals("solvedCols should be min(rows, cols)", 
                                                                        Math.min(rows, cols), solvedColsValue);
                                                            
                                                            // Also verify no array bounds are exceeded
                                                            Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                            diagRField.setAccessible(true);
                                                            double[] diagR = (double[]) diagRField.get(optimizer);
                                                            assertTrue("diagR array should be large enough", 
                                                                      diagR.length >= solvedColsValue);
                                                            
                                                            // Additional verification that optimization completed successfully
                                                            assertNotNull("Optimization should return a result", result);
                                                            assertEquals("Point dimension should match", cols, result.getPoint().length);
                                                            assertEquals("Objective dimension should match", rows, result.getValue().length);
                                                            
                                                        } catch (Exception e) {
                                                            fail("Test failed with exception: " + e.getMessage());
                                                        }
                                                    }

    @Test
                                                public void testDoOptimizeWithZeroColumnNorm1() {
                                                    // Setup test data with zero column norm
                                                    int rows = 3;
                                                    int cols = 3;
                                                    LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                    
                                                    // Use reflection to set private fields needed for the test
                                                    try {
                                                        Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                        jacNormField.setAccessible(true);
                                                        double[] jacNorm = new double[cols];
                                                        jacNorm[0] = 1.0;  // normal value
                                                        jacNorm[1] = 0.0;  // zero value to test mutation
                                                        jacNorm[2] = 2.0;  // normal value
                                                        jacNormField.set(optimizer, jacNorm);
                                                        
                                                        Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                        pointField.setAccessible(true);
                                                        double[] point = new double[cols];
                                                        point[0] = 1.0;
                                                        point[1] = 1.0;
                                                        point[2] = 1.0;
                                                        pointField.set(optimizer, point);
                                                        
                                                        Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                        solvedColsField.setAccessible(true);
                                                        solvedColsField.set(optimizer, cols);
                                                        
                                                        // Mock other dependencies
                                                        Field residualsField = LevenbergMarquardtOptimizer.class.getDeclaredField("residuals");
                                                        residualsField.setAccessible(true);
                                                        residualsField.set(optimizer, new double[rows]);
                                                        
                                                        Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                                                        costField.setAccessible(true);
                                                        costField.set(optimizer, 1.0);
                                                        
                                                        // Call the method (we're testing the first iteration part)
                                                        Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                        doOptimize.setAccessible(true);
                                                        doOptimize.invoke(optimizer);
                                                        
                                                        // Verify the scaling was applied correctly
                                                        double[] updatedPoint = (double[]) pointField.get(optimizer);
                                                        // For jacNorm[1] = 0, it should have been replaced with 1.0 in original code
                                                        // So expected point scaling:
                                                        // point[0] *= 1.0 (jacNorm[0] = 1.0)
                                                        // point[1] *= 1.0 (replaced 0 with 1.0)
                                                        // point[2] *= 2.0 (jacNorm[2] = 2.0)
                                                        assertEquals(1.0, updatedPoint[0], 1e-10);
                                                        assertEquals(1.0, updatedPoint[1], 1e-10);  // This would fail with mutant (would be 0.0)
                                                        assertEquals(2.0, updatedPoint[2], 1e-10);
                                                        
                                                    } catch (Exception e) {
                                                        fail("Test failed due to reflection exception: " + e.getMessage());
                                                    }
                                                }

    @Test
                                              public void testDeltaInitializationWhenXNormIsZero1() {
                                                  // Setup
                                                  LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                  optimizer.setInitialStepBoundFactor(100.0); // Set a known value for testing
                                                  
                                                  // Mock the necessary components to force xNorm = 0
                                                  // (All point values are 0)
                                                  double[] zeroPoint = new double[10]; // array of zeros
                                                  double[] objective = new double[5]; // dummy objective
                                                  
                                                  // Use reflection to set private fields needed for the test
                                                  try {
                                                      Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                                      pointField.setAccessible(true);
                                                      pointField.set(optimizer, zeroPoint);
                                                      
                                                      Field objectiveField = LevenbergMarquardtOptimizer.class.getDeclaredField("objective");
                                                      objectiveField.setAccessible(true);
                                                      objectiveField.set(optimizer, objective);
                                                      
                                                      // Execute using reflection to call protected method
                                                      Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                      doOptimizeMethod.setAccessible(true);
                                                      doOptimizeMethod.invoke(optimizer);
                                                      
                                                      // Verify delta was set correctly (should be initialStepBoundFactor when xNorm=0)
                                                      Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                                                      deltaField.setAccessible(true);
                                                      double delta = deltaField.getDouble(optimizer);
                                                      
                                                      // Original code would set delta to initialStepBoundFactor (100.0)
                                                      // Mutated code would set delta to 0 (100.0 * 0)
                                                      assertEquals("Delta should equal initialStepBoundFactor when xNorm is 0", 
                                                                  100.0, delta, 1e-10);
                                                      
                                                  } catch (Exception e) {
                                                      fail("Test failed due to reflection exception: " + e.getMessage());
                                                  }
                                              }

    @Test
                                         public void testDiagScalingBehavior() throws Exception {
                                             // Setup
                                             LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                             
                                             // Use reflection to access private fields we need to test
                                             Field diagField = LevenbergMarquardtOptimizer.class.getDeclaredField("diag");
                                             Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                             Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                             
                                             diagField.setAccessible(true);
                                             jacNormField.setAccessible(true);
                                             solvedColsField.setAccessible(true);
                                             
                                             // Create test data where diag and jacNorm have different values
                                             int cols = 3;
                                             double[] diag = new double[cols];
                                             double[] jacNorm = new double[cols];
                                             
                                             // Set up test values where diag and jacNorm differ
                                             diag[0] = 1.0;    jacNorm[0] = 2.0;  // jacNorm > diag
                                             diag[1] = 3.0;    jacNorm[1] = 2.0;  // diag > jacNorm
                                             diag[2] = 1.5;    jacNorm[2] = 1.5;  // equal
                                             
                                             // Set the fields in the optimizer
                                             diagField.set(optimizer, diag);
                                             jacNormField.set(optimizer, jacNorm);
                                             solvedColsField.set(optimizer, cols);
                                             
                                             // Use reflection to access the protected doOptimize method
                                             Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                             doOptimizeMethod.setAccessible(true);
                                             
                                             // Run the optimization (we'll just run until the first scaling occurs)
                                             try {
                                                 doOptimizeMethod.invoke(optimizer);
                                             } catch (Exception e) {
                                                 // We expect it might not complete due to mock setup
                                             }
                                             
                                             // Verify the scaling behavior
                                             double[] updatedDiag = (double[]) diagField.get(optimizer);
                                             
                                             // Original behavior: diag should contain max values
                                             assertEquals(2.0, updatedDiag[0], 1e-10);  // max(1.0, 2.0)
                                             assertEquals(3.0, updatedDiag[1], 1e-10);  // max(3.0, 2.0)
                                             assertEquals(1.5, updatedDiag[2], 1e-10);  // max(1.5, 1.5)
                                             
                                             // The mutant would show:
                                             // 1.0 (min(1.0, 2.0))
                                             // 2.0 (min(3.0, 2.0))
                                             // 1.5 (min(1.5, 1.5))
                                             // So our assertions would catch the mutant
                                         }

    @Test
                                    public void testInnerLoopExecutionWithSmallRatio1() {
                                        // Setup test data and mocks
                                        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                        
                                        // Set initial conditions that will produce a small ratio (< 1.0e-4)
                                        optimizer.setInitialStepBoundFactor(100.0);
                                        optimizer.setCostRelativeTolerance(1.0e-10);
                                        optimizer.setParRelativeTolerance(1.0e-10);
                                        optimizer.setOrthoTolerance(1.0e-10);
                                        
                                        try {
                                            // Use reflection to access protected doOptimize method
                                            Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                            doOptimize.setAccessible(true);
                                            VectorialPointValuePair result = (VectorialPointValuePair) doOptimize.invoke(optimizer);
                                            
                                            // Verify that the inner loop executed by checking some side effects
                                            assertNotEquals(0.0, result.getValue()[0], 1.0e-10);
                                            assertNotEquals(0.0, result.getPoint()[0], 1.0e-10);
                                            
                                            // Check iteration count through public method
                                            assertTrue(optimizer.getIterations() > 0);
                                            
                                        } catch (Exception e) {
                                            if (e instanceof InvocationTargetException) {
                                                Throwable cause = ((InvocationTargetException)e).getTargetException();
                                                if (cause instanceof OptimizationException) {
                                                    fail("Optimization failed when it shouldn't have");
                                                }
                                            }
                                            fail("Unexpected exception: " + e.getMessage());
                                        }
                                    }

    @Test
                               public void testFirstIterationStepBoundAdjustment() {
                                   // Setup
                                   LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                   
                                   // Set initial conditions where lmNorm will be smaller than initial delta
                                   // Mock necessary components to control the test environment
                                   // For this test, we need to ensure:
                                   // 1. It's the first iteration (firstIteration = true)
                                   // 2. lmNorm is smaller than initial delta
                                   
                                   // Using reflection to set private fields for testing
                                   try {
                                       Field initialStepBoundFactorField = LevenbergMarquardtOptimizer.class.getDeclaredField("initialStepBoundFactor");
                                       initialStepBoundFactorField.setAccessible(true);
                                       initialStepBoundFactorField.set(optimizer, 100.0); // Large initial step
                                       
                                       Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                                       pointField.setAccessible(true);
                                       pointField.set(optimizer, new double[]{1.0}); // Simple 1D case
                                       
                                       // Mock the behavior to return a small lmNorm
                                       // This would normally come from determineLMParameter()
                                       Field lmDirField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
                                       lmDirField.setAccessible(true);
                                       lmDirField.set(optimizer, new double[]{0.1}); // Small direction
                                       
                                       Field diagField = LevenbergMarquardtOptimizer.class.getDeclaredField("diag");
                                       diagField.setAccessible(true);
                                       diagField.set(optimizer, new double[]{1.0}); // Unit scaling
                                       
                                       // Execute using reflection to call protected method
                                       Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                       doOptimizeMethod.setAccessible(true);
                                       doOptimizeMethod.invoke(optimizer);
                                       
                                       // Verify
                                       Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                                       deltaField.setAccessible(true);
                                       double finalDelta = (double) deltaField.get(optimizer);
                                       
                                       // Expected lmNorm would be sqrt((1.0 * 0.1)^2) = 0.1
                                       // Original code should set delta to min(100, 0.1) = 0.1
                                       // Mutant would set it to max(100, 0.1) = 100
                                       assertEquals(0.1, finalDelta, 1e-10);
                                       
                                   } catch (Exception e) {
                                       fail("Test failed due to reflection exception: " + e.getMessage());
                                   }
                               }

    @Test
              public void testZeroPredictedReduction() throws OptimizationException {
                  // Setup test to force preRed = 0
                  // Mock internal state to create conditions where:
                  // - previousCost is non-zero
                  // - coeff1 and coeff2 both become 0
                  // - actRed is non-zero
                  
                  // Create optimizer instance
                  LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                  
                  try {
                      // Set fields that would lead to preRed = 0 using reflection
                      Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                      costField.setAccessible(true);
                      costField.set(optimizer, 1.0);
                      
                      Field previousCostField = LevenbergMarquardtOptimizer.class.getDeclaredField("previousCost");
                      previousCostField.setAccessible(true);
                      previousCostField.set(optimizer, 1.0);
                      
                      // Create arrays with specific values that would make coeff1 and coeff2 zero
                      double[] work1 = new double[1]; // All zeros
                      double[] diag = new double[1];
                      double[] point = new double[1];
                      double[] qtf = new double[1];
                      
                      Field work1Field = LevenbergMarquardtOptimizer.class.getDeclaredField("work1");
                      work1Field.setAccessible(true);
                      work1Field.set(optimizer, work1);
                      
                      Field diagField = LevenbergMarquardtOptimizer.class.getDeclaredField("diag");
                      diagField.setAccessible(true);
                      diagField.set(optimizer, diag);
                      
                      Field pointField = LevenbergMarquardtOptimizer.class.getDeclaredField("point");
                      pointField.setAccessible(true);
                      pointField.set(optimizer, point);
                      
                      Field qtfField = LevenbergMarquardtOptimizer.class.getDeclaredField("qtf");
                      qtfField.setAccessible(true);
                      qtfField.set(optimizer, qtf);
                      
                      Field lmParField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmPar");
                      lmParField.setAccessible(true);
                      lmParField.set(optimizer, 0.0); // Makes coeff2 zero
                      
                      // Set other required fields
                      Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                      solvedColsField.setAccessible(true);
                      solvedColsField.set(optimizer, 1);
                      
                      Field permutationField = LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
                      permutationField.setAccessible(true);
                      permutationField.set(optimizer, new int[]{0});
                      
                      Field jacobianField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacobian");
                      jacobianField.setAccessible(true);
                      jacobianField.set(optimizer, new double[1][1]);
                      
                      // Access protected doOptimize method via reflection
                      Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                      doOptimize.setAccessible(true);
                      
                      // This should execute without throwing an exception in original code
                      // But would throw ArithmeticException in mutated code
                      doOptimize.invoke(optimizer);
                      
                  } catch (Exception e) {
                      throw new RuntimeException("Test setup failed", e);
                  }
              }

    @Test
         public void testDeltaAdjustmentWithHighCost() {
             // Setup test conditions to trigger the specific branch
             LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
             
             // Use reflection to set private fields needed for the test
             try {
                 Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
                 costField.setAccessible(true);
                 costField.set(optimizer, 100.0); // Set high current cost
                 
                 Field previousCostField = LevenbergMarquardtOptimizer.class.getDeclaredField("previousCost");
                 previousCostField.setAccessible(true);
                 previousCostField.set(optimizer, 1.0); // Set low previous cost (10% of current > previous)
                 
                 Field deltaField = LevenbergMarquardtOptimizer.class.getDeclaredField("delta");
                 deltaField.setAccessible(true);
                 deltaField.set(optimizer, 5.0); // Initial delta
                 
                 Field lmNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmNorm");
                 lmNormField.setAccessible(true);
                 lmNormField.set(optimizer, 1.0); // lmNorm value
                 
                 Field lmParField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmPar");
                 lmParField.setAccessible(true);
                 lmParField.set(optimizer, 0.5); // Initial lmPar
                 
                 // Use reflection to call protected doOptimize() method
                 Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                 doOptimizeMethod.setAccessible(true);
                 doOptimizeMethod.invoke(optimizer);
                 
                 // Verify delta was adjusted correctly (original would use 0.1, mutant would use calculated tmp)
                 double newDelta = (Double) deltaField.get(optimizer);
                 double newLmPar = (Double) lmParField.get(optimizer);
                 
                 // Original would have newDelta = 0.1 * min(5.0, 10.0) = 0.5
                 // and lmPar /= 0.1 → 5.0
                 assertEquals(0.5, newDelta, 1e-10);
                 assertEquals(5.0, newLmPar, 1e-10);
                 
             } catch (Exception e) {
                 fail("Test failed due to reflection exception: " + e.getMessage());
             }
         }

    @Test
    public void testTerminationConditionWithSingleTrueCondition1() throws Exception {
        // Setup
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        
        // Use reflection to set private fields needed for the test
        Field costRelativeToleranceField = LevenbergMarquardtOptimizer.class.getDeclaredField("costRelativeTolerance");
        costRelativeToleranceField.setAccessible(true);
        costRelativeToleranceField.set(optimizer, 1.0e-10);
        
        Field parRelativeToleranceField = LevenbergMarquardtOptimizer.class.getDeclaredField("parRelativeTolerance");
        parRelativeToleranceField.setAccessible(true);
        parRelativeToleranceField.set(optimizer, 1.0e-10);
        
        Field orthoToleranceField = LevenbergMarquardtOptimizer.class.getDeclaredField("orthoTolerance");
        orthoToleranceField.setAccessible(true);
        orthoToleranceField.set(optimizer, 1.0e-10);
        
        // Create test data where only one condition is true (actRed <= epsilon)
        double actRed = 2.0e-16;  // <= epsilon
        double preRed = 1.0;       // > epsilon
        double ratio = 3.0;        // > 2.0
        double xNorm = 1.0;
        
        // Mock the necessary internal state
        Field residualsField = LevenbergMarquardtOptimizer.class.getDeclaredField("residuals");
        residualsField.setAccessible(true);
        residualsField.set(optimizer, new double[1]);
        
        Field costField = LevenbergMarquardtOptimizer.class.getDeclaredField("cost");
        costField.setAccessible(true);
        costField.set(optimizer, 1.0);
        
        // Get the protected doOptimize method via reflection
        Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
        doOptimizeMethod.setAccessible(true);
        
        // Test - should NOT throw exception with original code
        // If mutant is present (using OR), it WILL throw
        try {
            doOptimizeMethod.invoke(optimizer);
            
            // If we get here, mutant was NOT detected (original behavior)
            // We need to verify no exception was thrown when only one condition is true
        } catch (InvocationTargetException e) {
            if (e.getTargetException() instanceof OptimizationException) {
                // This indicates the mutant was detected
                fail("Mutant detected: Exception thrown when only one termination condition was true");
            }
        }
        
        // Additional test case where all conditions are true (should throw)
        actRed = 2.0e-16;
        preRed = 2.0e-16;
        ratio = 1.0;
        try {
            doOptimizeMethod.invoke(optimizer);
            fail("Should have thrown exception when all conditions are true");
        } catch (InvocationTargetException e) {
            if (!(e.getTargetException() instanceof OptimizationException)) {
                fail("Expected OptimizationException but got " + e.getTargetException().getClass());
            }
            // Expected behavior
        }
    }


}
