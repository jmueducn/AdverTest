package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                             public void testAddValue_Comparable_StringValue() {
                                                 Frequency frequency = new Frequency();
                                                 frequency.addValue("test");
                                                 frequency.addValue("test");
                                                 frequency.addValue("another");
                                                 
                                                 assertEquals(2, frequency.getCount("test"));
                                                 assertEquals(1, frequency.getCount("another"));
                                                 assertEquals(0, frequency.getCount("notAdded"));
                                             }

 @Test
                                             public void testAddValue_Comparable_IntegerValue() {
                                                 Frequency frequency = new Frequency();
                                                 frequency.addValue(5);
                                                 frequency.addValue(5);
                                                 frequency.addValue(10);
                                                 
                                                 assertEquals(2, frequency.getCount(5));
                                                 assertEquals(1, frequency.getCount(10));
                                                 assertEquals(0, frequency.getCount(1));
                                             }

 @Test
                                             public void testAddValue_Comparable_LongValue() {
                                                 Frequency frequency = new Frequency();
                                                 frequency.addValue(100L);
                                                 frequency.addValue(100L);
                                                 frequency.addValue(200L);
                                                 
                                                 assertEquals(2, frequency.getCount(100L));
                                                 assertEquals(1, frequency.getCount(200L));
                                                 assertEquals(0, frequency.getCount(300L));
                                             }

 @Test
                                             public void testAddValue_Comparable_CharacterValue() {
                                                 Frequency frequency = new Frequency();
                                                 frequency.addValue('a');
                                                 frequency.addValue('a');
                                                 frequency.addValue('b');
                                                 
                                                 assertEquals(2, frequency.getCount('a'));
                                                 assertEquals(1, frequency.getCount('b'));
                                                 assertEquals(0, frequency.getCount('c'));
                                             }

 @Test
                                             public void testAddValue_Comparable_WithCustomComparator() {
                                                 // Case insensitive string comparison
                                                 Comparator<String> caseInsensitiveComparator = String::compareToIgnoreCase;
                                                 Frequency frequency = new Frequency(caseInsensitiveComparator);
                                                 
                                                 frequency.addValue("Test");
                                                 frequency.addValue("test");
                                                 frequency.addValue("TEST");
                                                 
                                                 assertEquals(3, frequency.getCount("test"));
                                                 assertEquals(0, frequency.getCount("different"));
                                             }

 @Test
                                             public void testAddValue_Comparable_VerifySumFrequency() {
                                                 Frequency frequency = new Frequency();
                                                 assertEquals(0, frequency.getSumFreq());
                                                 
                                                 frequency.addValue("a");
                                                 assertEquals(1, frequency.getSumFreq());
                                                 
                                                 frequency.addValue("a");
                                                 assertEquals(2, frequency.getSumFreq());
                                                 
                                                 frequency.addValue("b");
                                                 assertEquals(3, frequency.getSumFreq());
                                             }

 @Test
                                             public void testAddValue_Comparable_AfterClear() {
                                                 Frequency frequency = new Frequency();
                                                 frequency.addValue("initial");
                                                 frequency.clear();
                                                 
                                                 frequency.addValue("new");
                                                 assertEquals(1, frequency.getCount("new"));
                                                 assertEquals(0, frequency.getCount("initial"));
                                             }

 @Test
                                             public void testAddValue_WithCustomComparator() {
                                                 // Create frequency with case-insensitive string comparator
                                                 Frequency caseInsensitiveFrequency = new Frequency(String.CASE_INSENSITIVE_ORDER);
                                                 
                                                 caseInsensitiveFrequency.addValue("Test");
                                                 caseInsensitiveFrequency.addValue("test");
                                                 caseInsensitiveFrequency.addValue("TEST");
                                                 
                                                 assertEquals(3, caseInsensitiveFrequency.getCount("test"));
                                             }

 @Test
                                             public void testAddValue_MultipleTypesSeparately() {
                                                 Frequency intFrequency = new Frequency();
                                                 intFrequency.addValue(1);
                                                 intFrequency.addValue(1);
                                                 
                                                 Frequency stringFrequency = new Frequency();
                                                 stringFrequency.addValue("a");
                                                 stringFrequency.addValue("a");
                                                 
                                                 assertEquals(2, intFrequency.getCount(1));
                                                 assertEquals(2, stringFrequency.getCount("a"));
                                             }

 @Test
                                             public void testAddValue_WithCustomComparator1() {
                                                 // Test with a custom comparator that treats all values as equal
                                                 Comparator<Long> allEqualComparator = (a, b) -> 0;
                                                 Frequency customFrequency = new Frequency(allEqualComparator);
                                                 
                                                 customFrequency.addValue(1L);
                                                 customFrequency.addValue(2L);
                                                 customFrequency.addValue(3L);
                                                 
                                                 // All values should be treated as the same
                                                 assertEquals(3L, customFrequency.getCount(1L));
                                                 assertEquals(3L, customFrequency.getCount(2L));
                                                 assertEquals(3L, customFrequency.getSumFreq());
                                             }

 @Test
                                             public void testAddValue_WithCustomComparator2() {
                                                 // Create frequency with case-insensitive comparator
                                                 Comparator<String> caseInsensitiveComparator = String::compareToIgnoreCase;
                                                 Frequency customFrequency = new Frequency(caseInsensitiveComparator);
                                                 
                                                 customFrequency.addValue("Test");
                                                 customFrequency.addValue("test");
                                                 
                                                 // Should count as same value due to comparator
                                                 assertEquals(2, customFrequency.getCount("Test"));
                                                 assertEquals(2, customFrequency.getCount("test"));
                                             }

 @Test
                                             public void testAddValue_WithCustomComparator3() {
                                                 // Test with a custom comparator that treats all values as equal
                                                 Frequency customFrequency = new Frequency((o1, o2) -> 0);
                                                 customFrequency.addValue(1L);
                                                 customFrequency.addValue(2L);
                                                 customFrequency.addValue(3L);
                                                 
                                                 // All values should be treated as equal, so count should be 3 for any value
                                                 assertEquals(3, customFrequency.getCount(1L));
                                                 assertEquals(3, customFrequency.getCount(2L));
                                                 assertEquals(3, customFrequency.getCount(3L));
                                             }

 @Test
                                             public void testAddValue_Char_WithCustomComparator() {
                                                 // Test with custom comparator (case insensitive)
                                                 Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                                                     Character.toLowerCase(c1) - Character.toLowerCase(c2);
                                                 Frequency caseInsensitiveFreq = new Frequency(caseInsensitiveComparator);
                                                 
                                                 caseInsensitiveFreq.addValue('A');
                                                 caseInsensitiveFreq.addValue('a');
                                                 assertEquals(2, caseInsensitiveFreq.getCount('A'));
                                                 assertEquals(2, caseInsensitiveFreq.getCount('a'));
                                             }

 @Test
                                     public void testAddValue_Comparable_NullValue() {
                                         Frequency frequency = new Frequency();
                                         try {
                                             frequency.addValue((Comparable<?>)null);
                                             fail("Expected IllegalArgumentException");
                                         } catch (IllegalArgumentException e) {
                                             assertEquals("Value cannot be null", e.getMessage());
                                         }
                                     }

 @Test
                                     public void testAddValue_Comparable_MixedTypes() {
                                         org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                         Frequency frequency = new Frequency();
                                         
                                         exception.expect(ClassCastException.class);
                                         frequency.addValue("string");
                                         frequency.addValue(123);
                                     }

 @Test
                                     public void testAddValue_Integer() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(5);
                                         frequency.addValue(5);
                                         frequency.addValue(10);
                                         
                                         assertEquals(2, frequency.getCount(5));
                                         assertEquals(1, frequency.getCount(10));
                                     }

 @Test
                                     public void testAddValue_Long() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(1000L);
                                         frequency.addValue(1000L);
                                         frequency.addValue(1000L);
                                         
                                         assertEquals(3, frequency.getCount(1000L));
                                     }

 @Test
                                     public void testAddValue_String() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue("test");
                                         frequency.addValue("test");
                                         assertEquals(2, frequency.getCount("test"));
                                     }

 @Test
                                     public void testAddValue_IntegerAsObject() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(Integer.valueOf(7));
                                         frequency.addValue(Integer.valueOf(7));
                                         assertEquals(2, frequency.getCount(7));
                                     }

 @Test
                                     public void testAddValue_NullInput() {
                                         org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                         org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                         
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("Value not comparable to existing values.");
                                         
                                         frequency.addValue(null);
                                     }

 @Test
                                     public void testAddValue_Char() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue('a');
                                         frequency.addValue('a');
                                         frequency.addValue('b');
                                         
                                         assertEquals(2, frequency.getCount('a'));
                                         assertEquals(1, frequency.getCount('b'));
                                     }

 @Test
                                     public void testAddValue_EdgeCases() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(Integer.MAX_VALUE);
                                         frequency.addValue(Integer.MIN_VALUE);
                                         frequency.addValue(Long.MAX_VALUE);
                                         frequency.addValue(Long.MIN_VALUE);
                                         
                                         assertEquals(1, frequency.getCount(Integer.MAX_VALUE));
                                         assertEquals(1, frequency.getCount(Integer.MIN_VALUE));
                                         assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                         assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                     }

 @Test
                                     public void testAddValue_ShouldIncrementCountForNewValue() {
                                         // Initialize frequency object
                                         org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                         
                                         // Test adding a new value
                                         frequency.addValue(5L);
                                         assertEquals(1L, frequency.getCount(5L));
                                         
                                         // Verify sum frequency
                                         assertEquals(1L, frequency.getSumFreq());
                                     }

 @Test
                                     public void testAddValue_ShouldIncrementCountForExistingValue() {
                                         // Create frequency counter
                                         Frequency frequency = new Frequency();
                                         
                                         // Add same value multiple times
                                         frequency.addValue(10L);
                                         frequency.addValue(10L);
                                         frequency.addValue(10L);
                                         
                                         // Verify counts
                                         assertEquals(3L, frequency.getCount(10L));
                                         assertEquals(3L, frequency.getSumFreq());
                                     }

 @Test
                                     public void testAddValue_WithDifferentValues() {
                                         // Initialize frequency object
                                         org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                         
                                         // Test with multiple different values
                                         frequency.addValue(1L);
                                         frequency.addValue(2L);
                                         frequency.addValue(1L);
                                         frequency.addValue(3L);
                                         
                                         assertEquals(2L, frequency.getCount(1L));
                                         assertEquals(1L, frequency.getCount(2L));
                                         assertEquals(1L, frequency.getCount(3L));
                                         assertEquals(4L, frequency.getSumFreq());
                                     }

 @Test
                                     public void testAddValue_WithZero() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(0L);
                                         assertEquals(1L, frequency.getCount(0L));
                                     }

 @Test
                                     public void testAddValue_WithNegativeNumbers() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(-5L);
                                         frequency.addValue(-5L);
                                         frequency.addValue(-10L);
                                         
                                         assertEquals(2L, frequency.getCount(-5L));
                                         assertEquals(1L, frequency.getCount(-10L));
                                     }

 @Test
                                     public void testAddValue_WithMaxLongValue() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(Long.MAX_VALUE);
                                         assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                     }

 @Test
                                     public void testAddValue_WithMinLongValue() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(Long.MIN_VALUE);
                                         assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                     }

 @Test
                                     public void testAddValue_AfterClear() {
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(5L);
                                         frequency.clear();
                                         frequency.addValue(10L);
                                         
                                         assertEquals(0L, frequency.getCount(5L));
                                         assertEquals(1L, frequency.getCount(10L));
                                         assertEquals(1L, frequency.getSumFreq());
                                     }

 @Test
                                     public void testAddValue_MixedWithOtherAddMethods() {
                                         // Create new Frequency instance
                                         Frequency frequency = new Frequency();
                                         
                                         // Test interaction with other addValue methods
                                         frequency.addValue(5);    // int
                                         frequency.addValue(5L);   // long
                                         frequency.addValue(5);    // int
                                         frequency.addValue(new Integer(5)); // Integer
                                         
                                         // All should be treated as the same value
                                         assertEquals(4L, frequency.getCount(5L));
                                     }

 @Test
                                     public void testAddValue_Object() {
                                         // Create Frequency instance
                                         Frequency frequency = new Frequency();
                                         
                                         // Set up exception testing
                                         ExpectedException thrown = ExpectedException.none();
                                         
                                         // Test with String
                                         frequency.addValue("test");
                                         assertEquals(1, frequency.getCount("test"));
                                         
                                         // Test with null
                                         thrown.expect(IllegalArgumentException.class);
                                         frequency.addValue((Object)null);
                                     }

 @Test
                                     public void testAddValue_Comparable() {
                                         // Create a new Frequency instance
                                         Frequency frequency = new Frequency();
                                         
                                         // Test with String (implements Comparable)
                                         frequency.addValue("abc");
                                         assertEquals(1, frequency.getCount("abc"));
                                         
                                         // Test with custom Comparable
                                         Comparable<Integer> comparable = Integer.valueOf(5);
                                         frequency.addValue(comparable);
                                         assertEquals(1, frequency.getCount(Integer.valueOf(5)));
                                     }

 @Test
                                     public void testAddValue_Int() {
                                         // Create new Frequency instance
                                         org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                         
                                         // Test typical values
                                         frequency.addValue(10);
                                         assertEquals(1, frequency.getCount(10));
                                         
                                         frequency.addValue(10); // Add same value again
                                         assertEquals(2, frequency.getCount(10));
                                         
                                         // Test edge cases
                                         frequency.addValue(Integer.MAX_VALUE);
                                         frequency.addValue(Integer.MIN_VALUE);
                                         assertEquals(1, frequency.getCount(Integer.MAX_VALUE));
                                         assertEquals(1, frequency.getCount(Integer.MIN_VALUE));
                                     }

 @Test
                                     public void testAddValue_Integer1() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         ExpectedException thrown = ExpectedException.none();
                                         
                                         // Test with Integer objects
                                         frequency.addValue(Integer.valueOf(5));
                                         assertEquals(1, frequency.getCount(5));
                                         
                                         // Test with null
                                         thrown.expect(IllegalArgumentException.class);
                                         frequency.addValue((Integer)null);
                                     }

 @Test
                                     public void testAddValue_Long1() {
                                         // Initialize frequency object
                                         Frequency frequency = new Frequency();
                                         
                                         // Test typical values
                                         frequency.addValue(100L);
                                         assertEquals(1, frequency.getCount(100L));
                                         
                                         // Test edge cases
                                         frequency.addValue(Long.MAX_VALUE);
                                         frequency.addValue(Long.MIN_VALUE);
                                         assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                         assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                     }

 @Test
                                     public void testAddValue_Char1() {
                                         // Initialize frequency object
                                         Frequency frequency = new Frequency();
                                         
                                         // Test various characters
                                         frequency.addValue('a');
                                         frequency.addValue('A');
                                         frequency.addValue('1');
                                         frequency.addValue(' ');
                                         frequency.addValue('\n');
                                         
                                         assertEquals(1, frequency.getCount('a'));
                                         assertEquals(1, frequency.getCount('A'));
                                         assertEquals(1, frequency.getCount('1'));
                                         assertEquals(1, frequency.getCount(' '));
                                         assertEquals(1, frequency.getCount('\n'));
                                     }

 @Test
                                 public void testAddValue_MixedTypes() {
                                     // Test that different types are treated separately
                                     Frequency frequency = new Frequency();
                                     
                                     frequency.addValue(5);    // int
                                     frequency.addValue(5L);  // long
                                     frequency.addValue('5'); // char
                                     frequency.addValue("5"); // String
                                     
                                     assertEquals(1, frequency.getCount(5));
                                     assertEquals(1, frequency.getCount(5L));
                                     assertEquals(1, frequency.getCount('5'));
                                     assertEquals(1, frequency.getCount("5"));
                                 }

 @Test
                                 public void testAddValue_IncrementsSumFreq() {
                                     Frequency frequency = new Frequency();
                                     long initialSum = frequency.getSumFreq();
                                     
                                     frequency.addValue(1);
                                     assertEquals(initialSum + 1, frequency.getSumFreq());
                                     
                                     frequency.addValue(2);
                                     frequency.addValue(2);
                                     assertEquals(initialSum + 3, frequency.getSumFreq());
                                 }

 @Test
                                 public void testAddValue_NewValue() {
                                     Frequency frequency = new Frequency();
                                     long value = 10L;
                                     // Initial count should be 0
                                     assertEquals(0, frequency.getCount(value));
                                     // Add value
                                     frequency.addValue(value);
                                     // Count should now be 1
                                     assertEquals(1, frequency.getCount(value));
                                 }

 @Test
                                 public void testAddValue_ExistingValue() {
                                     Frequency frequency = new Frequency();
                                     long value = 20L;
                                     // Add value twice
                                     frequency.addValue(value);
                                     frequency.addValue(value);
                                     // Count should be 2
                                     assertEquals(2, frequency.getCount(value));
                                 }

 @Test
                                 public void testAddValue_MinLongValue() {
                                     Frequency frequency = new Frequency();
                                     long value = Long.MIN_VALUE;
                                     frequency.addValue(value);
                                     assertEquals(1, frequency.getCount(value));
                                 }

 @Test
                                 public void testAddValue_MaxLongValue() {
                                     Frequency frequency = new Frequency();
                                     long value = Long.MAX_VALUE;
                                     frequency.addValue(value);
                                     assertEquals(1, frequency.getCount(value));
                                 }

 @Test
                                 public void testAddValue_Zero() {
                                     Frequency frequency = new Frequency();
                                     long value = 0L;
                                     frequency.addValue(value);
                                     assertEquals(1, frequency.getCount(value));
                                 }

 @Test
                                 public void testAddValue_NegativeValue() {
                                     Frequency frequency = new Frequency();
                                     long value = -5L;
                                     frequency.addValue(value);
                                     assertEquals(1, frequency.getCount(value));
                                 }

 @Test
                                 public void testAddValue_MultipleDifferentValues() {
                                     Frequency frequency = new Frequency();
                                     long value1 = 100L;
                                     long value2 = 200L;
                                     long value3 = 100L; // Duplicate of value1
                                     
                                     frequency.addValue(value1);
                                     frequency.addValue(value2);
                                     frequency.addValue(value3);
                                     
                                     assertEquals(2, frequency.getCount(value1));
                                     assertEquals(1, frequency.getCount(value2));
                                 }

 @Test
                                 public void testAddValue_VerifySumFrequency() {
                                     Frequency frequency = new Frequency();
                                     frequency.addValue(1L);
                                     frequency.addValue(2L);
                                     frequency.addValue(1L);
                                     
                                     assertEquals(3, frequency.getSumFreq());
                                 }

 @Test
                                 public void testAddValue_Char_AddsNewCharacter() {
                                     // Test adding a new character
                                     Frequency frequency = new Frequency();
                                     frequency.addValue('a');
                                     assertEquals(1, frequency.getCount('a'));
                                 }

 @Test
                                 public void testAddValue_Char_IncrementsExistingCharacter() {
                                     // Test incrementing count for existing character
                                     Frequency frequency = new Frequency();
                                     frequency.addValue('b');
                                     frequency.addValue('b');
                                     assertEquals(2, frequency.getCount('b'));
                                 }

 @Test
                                 public void testAddValue_Char_WithDifferentCases() {
                                     // Test case sensitivity
                                     Frequency frequency = new Frequency();
                                     frequency.addValue('A');
                                     frequency.addValue('a');
                                     assertEquals(1, frequency.getCount('A'));
                                     assertEquals(1, frequency.getCount('a'));
                                 }

 @Test
                                 public void testAddValue_Char_SpecialCharacters() {
                                     // Test special characters
                                     Frequency frequency = new Frequency();
                                     frequency.addValue('@');
                                     frequency.addValue('$');
                                     frequency.addValue('@');
                                     assertEquals(2, frequency.getCount('@'));
                                     assertEquals(1, frequency.getCount('$'));
                                 }

 @Test
                                 public void testAddValue_Char_NumericCharacters() {
                                     // Test numeric characters
                                     Frequency frequency = new Frequency();
                                     frequency.addValue('0');
                                     frequency.addValue('9');
                                     frequency.addValue('0');
                                     assertEquals(2, frequency.getCount('0'));
                                     assertEquals(1, frequency.getCount('9'));
                                 }

 @Test
                                 public void testAddValue_Char_UnicodeCharacters() {
                                     // Create new Frequency instance
                                     Frequency frequency = new Frequency();
                                     
                                     // Test Unicode characters
                                     frequency.addValue('あ'); // Japanese hiragana
                                     frequency.addValue('α'); // Greek alpha
                                     frequency.addValue('あ');
                                     
                                     assertEquals(2, frequency.getCount('あ'));
                                     assertEquals(1, frequency.getCount('α'));
                                 }

 @Test
                                 public void testAddValue_Char_WhitespaceCharacters() {
                                     // Test whitespace characters
                                     Frequency frequency = new Frequency();
                                     frequency.addValue(' ');
                                     frequency.addValue('\t');
                                     frequency.addValue('\n');
                                     frequency.addValue(' ');
                                     assertEquals(2, frequency.getCount(' '));
                                     assertEquals(1, frequency.getCount('\t'));
                                     assertEquals(1, frequency.getCount('\n'));
                                 }

 @Test
                                 public void testAddValue_Char_EmptyCharacter() {
                                     // Test empty character (though not possible in Java, but testing boundary)
                                     // In Java, char is primitive and can't be null, but we can test '\0'
                                     Frequency frequency = new Frequency();
                                     frequency.addValue('\0');
                                     assertEquals(1, frequency.getCount('\0'));
                                 }

 @Test
                                 public void testAddValue_Char_MultipleAdds() {
                                     // Test multiple adds and verify sum frequency
                                     Frequency frequency = new Frequency();
                                     frequency.addValue('x');
                                     frequency.addValue('y');
                                     frequency.addValue('x');
                                     frequency.addValue('z');
                                     frequency.addValue('x');
                                     assertEquals(3, frequency.getCount('x'));
                                     assertEquals(1, frequency.getCount('y'));
                                     assertEquals(1, frequency.getCount('z'));
                                     assertEquals(5, frequency.getSumFreq());
                                 }

 @Test
                                 public void testAddValue_NonComparableObject() {
                                     Frequency frequency = new Frequency();
                                     class NonComparable {}
                                     
                                     try {
                                         frequency.addValue(new NonComparable());
                                         fail("Expected IllegalArgumentException");
                                     } catch (IllegalArgumentException e) {
                                         assertEquals("Value not comparable to existing values.", e.getMessage());
                                     }
                                 }

 @Test
                             public void testAddValue_MixedTypes1() {
                                 // Test that different types are treated separately
                                 Frequency frequency = new Frequency();
                                 
                                 // Add values of different types
                                 frequency.addValue(5);     // int
                                 frequency.addValue(5L);    // long
                                 frequency.addValue('5');   // char
                                 frequency.addValue("5");   // String
                                 
                                 // Verify counts for each type
                                 assertEquals(1, frequency.getCount(5));    // int version
                                 assertEquals(1, frequency.getCount(5L));   // long version
                                 assertEquals(1, frequency.getCount('5'));  // char version
                                 assertEquals(1, frequency.getCount("5"));  // Object version
                             }

 @Test(expected = ClassCastException.class)
                             public void testAddValueWithNonComparableShouldThrowException() {
                                 Frequency frequency = new Frequency();
                                 Object nonComparable = new Object(); // Object is not Comparable
                                 
                                 // This should throw ClassCastException in original version during cast
                                 // Mutated version might not throw or throw later
                                 frequency.addValue((Comparable<?>) nonComparable);
                             }

 @Test
                             public void testAddValueWithComparableShouldWork() {
                                 Frequency frequency = new Frequency();
                                 Comparable<String> comparable = "test"; // String is Comparable
                                 
                                 // This should work in both original and mutated versions
                                 frequency.addValue((Comparable<?>) comparable);
                                 
                                 // Verify the value was added
                                 assertTrue(frequency.getCount(comparable) > 0);
                             }

 @Test
                         public void testAddValueWithNonComparableObject() {
                             // Create a Frequency instance with custom comparator
                             Comparator<Object> comparator = (o1, o2) -> {
                                 // Simple comparator that doesn't rely on Comparable
                                 return System.identityHashCode(o1) - System.identityHashCode(o2);
                             };
                             Frequency frequency = new Frequency(comparator);
                             
                             // Create a non-Comparable object
                             Object nonComparable = new Object();
                             
                             // Add the value - this should work with original code but fail with mutant
                             frequency.addValue(nonComparable);
                             
                             // Verify the count was incremented
                             assertEquals(1L, frequency.getCount(nonComparable));
                             
                             // Add again to verify increment works
                             frequency.addValue(nonComparable);
                             assertEquals(2L, frequency.getCount(nonComparable));
                         }

 @Test
                             public void testAddValueWithNonComparableObject1() {
                                 // Create a Frequency with custom comparator that handles non-Comparable objects
                                 Frequency freq = new Frequency(new Comparator<Object>() {
                                     @Override
                                     public int compare(Object o1, Object o2) {
                                         // Compare based on toString() to handle non-Comparable objects
                                         return o1.toString().compareTo(o2.toString());
                                     }
                                 });
                                 
                                 // Create a non-Comparable test object
                                 Object nonComparable = new Object() {
                                     @Override
                                     public String toString() {
                                         return "testObject";
                                     }
                                 };
                                 
                                 // This should work in original version due to casting to Comparable<?>
                                 // But would fail in mutated version if TreeMap expects Comparable
                                 freq.addValue(nonComparable);
                                 
                                 // Verify the count was properly recorded
                                 assertEquals(1, freq.getCount(nonComparable));
                             }

 @Test
                             public void testAddValueWithComparableObject() {
                                 Frequency freq = new Frequency();
                                 Long testValue = 123L;
                                 
                                 // This should work in both original and mutated versions
                                 freq.addValue(testValue);
                                 
                                 // Verify the count was properly recorded
                                 assertEquals(1, freq.getCount(testValue));
                             }

 @Test
                             public void testAddValueWithNonComparableObject2() {
                                 // Create a custom non-Comparable object
                                 class NonComparable {
                                     final int value;
                                     NonComparable(int v) { value = v; }
                                 }
                                 
                                 Frequency frequency = new Frequency();
                                 NonComparable nonComparable = new NonComparable(1);
                                 
                                 try {
                                     // This should fail in original code during cast to Comparable
                                     // But would fail differently in mutated code when trying to put in TreeMap
                                     frequency.addValue(nonComparable);
                                     
                                     // If we get here, the test should fail as we expected an exception
                                     fail("Expected ClassCastException");
                                 } catch (ClassCastException e) {
                                     // Verify the exception comes from the cast operation, not TreeMap insertion
                                     assertTrue(e.getMessage().contains("cannot be cast"));
                                 }
                             }

 @Test
                             public void testAddValueWithComparableObject1() {
                                 Frequency frequency = new Frequency();
                                 Long comparableValue = Long.valueOf(123L);
                                 
                                 // This should work in both original and mutated code
                                 frequency.addValue(comparableValue);
                                 
                                 // Verify the value was added
                                 assertEquals(1, frequency.getCount(comparableValue));
                             }

 @Test
                         public void testAddValueCharDetectsMutant() {
                             // Create frequency object
                             Frequency freq = new Frequency();
                             
                             // Add a character value
                             char testChar = 'a';
                             freq.addValue(testChar);
                             
                             // Verify the value was stored as Character object in the table
                             // This would fail if mutant is present (using primitive char)
                             assertTrue(freq.getCount(Character.valueOf(testChar)) > 0);
                             
                             // Verify we can't find it using the primitive (should be stored as object)
                             // This assertion would pass with mutant but fail with original
                             assertEquals(0, freq.getCount(testChar));
                             
                             // Verify count is correct
                             assertEquals(1, freq.getCount(Character.valueOf(testChar)));
                             
                             // Verify sum frequency is correct
                             assertEquals(1, freq.getSumFreq());
                         }

 @Test(expected = IllegalArgumentException.class)
                        public void testAddValueWithNonComparableObject3() {
                            // Create a Frequency instance
                            Frequency frequency = new Frequency();
                            
                            // Create a simple non-Comparable object
                            class NonComparable {}
                            Object nonComparable = new NonComparable();
                            
                            // This should throw IllegalArgumentException in original code
                            // Will throw ClassCastException in mutated code
                            frequency.addValue(nonComparable);
                        }

 @Test
                        public void testAddValueWithComparableObject2() {
                            // Test that comparable objects still work
                            Frequency frequency = new Frequency();
                            String comparable = "test";
                            frequency.addValue(comparable);
                            assertEquals(1L, frequency.getCount(comparable));
                        }

 @Test
                        public void testAddValueWithInteger() {
                            // Test that Integer conversion still works
                            Frequency frequency = new Frequency();
                            Integer value = 5;
                            frequency.addValue(value);
                            assertEquals(1L, frequency.getCount(value));
                        }

 @Test
                    public void testAddValueComparableShouldAddActualValueNotNull() {
                        // Setup
                        Frequency frequency = new Frequency();
                        String testValue = "testValue";
                        
                        // Action
                        frequency.addValue(testValue);
                        
                        // Verification
                        // Original behavior: count of testValue should be 1
                        // Mutant behavior: count of testValue would be 0 (since null was added instead)
                        assertEquals("Count of added value should be 1", 1, frequency.getCount(testValue));
                        
                        // Additional check to ensure null wasn't added
                        assertEquals("Null should not have been added", 0, frequency.getCount(null));
                    }

 @Test
                    public void testAddValueComparableShouldNotPassNull() {
                        // Setup
                        Frequency frequency = new Frequency();
                        String comparableValue = "testValue"; // String is Comparable
                        
                        // Action
                        frequency.addValue(comparableValue);
                        
                        // Verification
                        // Original behavior would count the value, mutant would pass null
                        assertEquals(1L, frequency.getCount(comparableValue));
                        
                        // Additional verification that null wasn't counted
                        assertEquals(0L, frequency.getCount(null));
                        
                        // Verify total count is correct (mutant would have incorrect sum)
                        assertEquals(1L, frequency.getSumFreq());
                    }

 @Test(expected = IllegalArgumentException.class)
                    public void testAddValueNonComparableShouldThrow() {
                        // Setup
                        Frequency frequency = new Frequency();
                        Object nonComparable = new Object(); // Object is not Comparable
                        
                        // Action & Verification
                        frequency.addValue(nonComparable);
                        // Should throw IllegalArgumentException for non-comparable
                    }

 @Test
                    public void testAddValueIntegerConversion() {
                        // Setup
                        Frequency frequency = new Frequency();
                        Integer intValue = 5;
                        
                        // Action
                        frequency.addValue(intValue);
                        
                        // Verification
                        // Should be converted to Long and counted properly
                        assertEquals(1L, frequency.getCount(5L));
                        assertEquals(1L, frequency.getSumFreq());
                    }

 @Test
                    public void testAddValueLongShouldNotAddNull() {
                        // Setup
                        Frequency frequency = new Frequency();
                        Long testValue = 123L;
                        
                        // Action
                        frequency.addValue(testValue);
                        
                        // Verification
                        // Original behavior: count for testValue should be 1
                        assertEquals(1L, frequency.getCount(testValue));
                        // Original behavior: count for null should be 0
                        assertEquals(0L, frequency.getCount(null));
                        
                        // Additional verification to ensure the value was stored correctly
                        // This would fail with the mutant since it would store under null
                        assertEquals(1L, frequency.getSumFreq());
                    }

 @Test
                    public void testAddValueLongDetectsNullMutant() {
                        // Setup
                        Frequency frequency = new Frequency();
                        Long testValue = 123L;
                        
                        // Action
                        frequency.addValue(testValue);
                        
                        // Verification
                        // Verify the value was actually added to freqTable
                        assertTrue("Frequency table should contain the test value", 
                                   frequency.getCount(testValue) > 0);
                        
                        // Verify the count is exactly 1 for a single addition
                        assertEquals("Count should be 1 after one addition", 
                                     1L, frequency.getCount(testValue));
                        
                        // Verify the sum frequency increased
                        assertEquals("Total frequency count should be 1", 
                                     1L, frequency.getSumFreq());
                    }

 @Test
                    public void testAddValueLongShouldNotAddNull1() {
                        // Setup
                        Frequency frequency = new Frequency();
                        Long testValue = 12345L;
                        
                        // Action
                        frequency.addValue(testValue);
                        
                        // Verification
                        // Original code should count the actual value
                        assertEquals("Count for added value should be 1", 1L, frequency.getCount(testValue));
                        // Mutated code would add null instead, so this assertion would fail
                        assertEquals("Count for null should be 0", 0L, frequency.getCount(null));
                    }

 @Test
                        public void testAddValueCharShouldNotAddNull() {
                            // Setup
                            Frequency frequency = new Frequency();
                            char testChar = 'a';
                            
                            // Action
                            frequency.addValue(testChar);
                            
                            // Verification
                            // Original behavior: count for 'a' should be 1
                            assertEquals(1L, frequency.getCount(testChar));
                            
                            // Mutant check: count for null should be 0 (mutant would potentially add null)
                            assertEquals(0L, frequency.getCount(null));
                            
                            // Additional verification that the character was properly added
                            assertEquals(1L, frequency.getSumFreq());
                        }

 @Test
                       public void testAddValueWithIntegerShouldIncreaseCount() {
                           // Setup
                           Frequency frequency = new Frequency();
                           Integer testValue = 42;
                           
                           // Action
                           frequency.addValue(testValue);
                           
                           // Verification
                           // Original behavior: count should be 1
                           // Mutant behavior: count would be 0 (since Integer case is skipped)
                           assertEquals("Count should be 1 after adding an Integer value", 
                                       1L, frequency.getCount(testValue));
                       }

 @Test
                       public void testAddValueWithIntegerShouldBeInFrequencyTable() {
                           // Setup
                           Frequency frequency = new Frequency();
                           Integer testValue = 42;
                           
                           // Action
                           frequency.addValue(testValue);
                           
                           // Verification
                           // Check if the value exists in the frequency table
                           assertTrue("Integer value should be present in frequency table",
                                     frequency.getCount(testValue) > 0);
                       }

 @Test
                       public void testAddValueWithIntegerShouldUseIntegerSpecificHandling() {
                           // Setup
                           Frequency frequency = new Frequency();
                           Integer testValue = 42;
                           
                           // Action
                           frequency.addValue(testValue);
                           
                           // Verification
                           // If the instanceof check works (original), count should be 1
                           // If mutated to false, the value might not be counted or counted differently
                           long count = frequency.getCount(testValue);
                           assertEquals("Integer value should be counted properly", 1, count);
                           
                           // Additional check to ensure it went through Integer path
                           count = frequency.getCount(42); // test int version
                           assertEquals("Should also be counted via int version", 1, count);
                       }

 @Test
                       public void testAddValueIntegerDetectsMutant() {
                           // Setup
                           Frequency frequency = new Frequency();
                           Integer testValue = 5;
                           
                           // Action
                           frequency.addValue(testValue);
                           
                           // Verification
                           // Original code would have added the value (count = 1)
                           // Mutant would not have added it (count = 0)
                           assertEquals("Integer value should be properly added to frequency table", 
                                        1L, frequency.getCount(testValue));
                           
                           // Additional check to verify it was converted to Long
                           assertEquals("Integer value should be converted to Long", 
                                        1L, frequency.getCount(testValue.longValue()));
                       }

 @Test
                       public void testAddValue_ShouldHandleIntegerAndCharacter() {
                           // Create a fresh Frequency object
                           Frequency frequency = new Frequency();
                           
                           // Add test values - both Integer and Character
                           Integer intValue = 42;
                           Character charValue = 'A';
                           
                           // Add values to frequency table
                           frequency.addValue(intValue);
                           frequency.addValue(charValue);
                           
                           // Verify both values were counted correctly
                           assertEquals("Integer value should have count 1", 1, frequency.getCount(intValue));
                           assertEquals("Character value should have count 1", 1, frequency.getCount(charValue));
                           
                           // Additional verification through the frequency table
                           Iterator valuesIterator = frequency.valuesIterator();
                           int count = 0;
                           while (valuesIterator.hasNext()) {
                               valuesIterator.next();
                               count++;
                           }
                           assertEquals("Should have exactly 2 distinct values", 2, count);
                       }

 @Test
                  public void testAddValueIntegerShouldIncrementCount() {
                      // Setup
                      Frequency frequency = new Frequency();
                      Integer testValue = 42;
                      
                      // Initial count should be 0
                      assertEquals(0, frequency.getCount(testValue));
                      
                      // Action - add the integer value
                      frequency.addValue(testValue);
                      
                      // Verification
                      // Original behavior: count should be 1
                      // Mutated behavior: count would remain 0 (or potentially throw exception)
                      assertEquals("Count should increment for Integer value", 1, frequency.getCount(testValue));
                      
                      // We can verify the value was added by checking the count, no need to access internal table
                  }

 @Test
          public void testAddValueWithIntegerDetectsInstanceOfMutant() {
              // Setup
              Frequency frequency = new Frequency();
              Integer testValue = 5;
              
              // Action
              frequency.addValue(testValue);
              
              // Verification
              // Use reflection to access private freqTable field
              try {
                  Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                  freqTableField.setAccessible(true);
                  @SuppressWarnings("unchecked")
                  java.util.Map<java.lang.Object, java.lang.Long> freqTable = (java.util.Map<java.lang.Object, java.lang.Long>) freqTableField.get(frequency);
                  
                  boolean foundAsLong = false;
                  
                  for (java.lang.Object key : freqTable.keySet()) {
                      if (key instanceof java.lang.Long) {
                          foundAsLong = true;
                          assertEquals(1L, freqTable.get(key).longValue());
                          assertEquals(5L, ((java.lang.Long)key).longValue());
                          break;
                      }
                  }
                  
                  assertTrue("Integer value should have been converted to Long", foundAsLong);
                  
                  // Additional check - add same value again and verify count increments
                  frequency.addValue(testValue);
                  for (java.lang.Object key : freqTable.keySet()) {
                      if (key instanceof java.lang.Long) {
                          assertEquals(2L, freqTable.get(key).longValue());
                          break;
                      }
                  }
              } catch (NoSuchFieldException | IllegalAccessException e) {
                  fail("Failed to access freqTable field: " + e.getMessage());
              }
          }

 @Test
      public void testAddValueWithIntegerDetectsInstanceOfMutant1() {
          // Setup
          org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
          Integer testValue = 5;
          
          // Action
          frequency.addValue(testValue);
          
          // Verification
          // Use reflection to access private freqTable field
          try {
              java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
              freqTableField.setAccessible(true);
              @SuppressWarnings("unchecked")
              java.util.Map<java.lang.Object, java.lang.Long> freqTable = (java.util.Map<java.lang.Object, java.lang.Long>) freqTableField.get(frequency);
              
              boolean foundAsLong = false;
              
              for (java.lang.Object key : freqTable.keySet()) {
                  if (key instanceof java.lang.Long) {
                      foundAsLong = true;
                      assertEquals(1L, freqTable.get(key).longValue());
                      assertEquals(5L, ((java.lang.Long)key).longValue());
                      break;
                  }
              }
              
              assertTrue("Integer value should have been converted to Long", foundAsLong);
              
              // Additional check - add same value again and verify count increments
              frequency.addValue(testValue);
              for (java.lang.Object key : freqTable.keySet()) {
                  if (key instanceof java.lang.Long) {
                      assertEquals(2L, freqTable.get(key).longValue());
                      break;
                  }
              }
          } catch (NoSuchFieldException | IllegalAccessException e) {
              fail("Failed to access freqTable field: " + e.getMessage());
          }
      }

 @Test
      public void testAddValueWithIntegerShouldStoreActualValue() {
          // Setup
          Frequency frequency = new Frequency();
          Integer testValue = 42;
          
          // Action
          frequency.addValue(testValue);
          
          // Verification
          // Original behavior: count for 42 should be 1
          assertEquals(1L, frequency.getCount(testValue));
          // Mutant behavior would increment count for 0 instead
          assertEquals(0L, frequency.getCount(0));
          
          // Additional verification that no other values were affected
          assertEquals(0L, frequency.getCount(1));
          assertEquals(0L, frequency.getCount(-1));
      }

 @Test
      public void testAddValueWithMultipleIntegersShouldAccumulateCorrectly() {
          // Setup
          Frequency frequency = new Frequency();
          Integer value1 = 10;
          Integer value2 = 20;
          
          // Action
          frequency.addValue(value1);
          frequency.addValue(value1);
          frequency.addValue(value2);
          
          // Verification
          assertEquals(2L, frequency.getCount(value1));
          assertEquals(1L, frequency.getCount(value2));
          assertEquals(0L, frequency.getCount(0)); // Mutant would have counts here
      }

 @Test
  public void testAddValueIntegerPreservesValue() {
      // Setup
      Frequency frequency = new Frequency();
      Integer testValue = 5;
      
      // Exercise
      frequency.addValue(testValue);
      
      // Verify
      // Original behavior: count for Long.valueOf(5) should be 1
      // Mutant behavior: count for Long.valueOf(0) would be 1
      assertEquals("Count for actual value should be 1", 
                   1, 
                   frequency.getCount(Long.valueOf(testValue.longValue())));
      
      // Additional check to ensure value wasn't counted as 0
      assertEquals("Count for 0 should be 0", 
                   0, 
                   frequency.getCount(Long.valueOf(0)));
  }

 @Test
  public void testAddValueIntegerPreservesValue1() {
      Frequency frequency = new Frequency();
      Integer testValue = 5;  // Non-zero test value
      
      // Add the value multiple times
      frequency.addValue(testValue);
      frequency.addValue(testValue);
      
      // Verify the count for the actual value (should be 2 for original, 0 for mutant)
      assertEquals("Count for actual value should be 2", 2L, frequency.getCount(testValue));
      
      // Verify the count for 0 (should be 0 for original, 2 for mutant)
      assertEquals("Count for 0 should be 0", 0L, frequency.getCount(0));
      
      // Also verify using the long version of getCount
      assertEquals("Long count for actual value should be 2", 2L, frequency.getCount(testValue.longValue()));
      assertEquals("Long count for 0 should be 0", 0L, frequency.getCount(0L));
  }

 @Test
  public void testAddValueIntegerDetectsMutant1() {
      // Setup
      Frequency frequency = new Frequency();
      Integer testValue = 5; // Non-zero test value
      
      // Exercise
      frequency.addValue(testValue);
      
      // Verify
      // Original behavior would have count 1 for the test value
      // Mutant would have count 0 for test value and count 1 for 0
      assertEquals("Original value should have count 1", 1, frequency.getCount(testValue));
      assertEquals("Count for 0 should be 0", 0, frequency.getCount(0));
      
      // Additional verification that the value was properly stored as Long
      assertEquals("Value should be stored as Long equivalent", 1, frequency.getCount(5L));
  }

 @Test
  public void testAddValueIntegerDetectsMutant2() {
      // Create a fresh Frequency object
      Frequency frequency = new Frequency();
      
      // Test with a non-zero Integer value
      Integer testValue = 5;
      frequency.addValue(testValue);
      
      // Verify the count for the correct Long value (should be 1 in original, 0 in mutant)
      assertEquals("Original should count the converted value", 1, frequency.getCount(5L));
      
      // Verify the count for 0L (should be 0 in original, 1 in mutant)
      assertEquals("Original should not count 0L", 0, frequency.getCount(0L));
      
      // Additional test with another non-zero value to be thorough
      Integer testValue2 = 10;
      frequency.addValue(testValue2);
      
      assertEquals("Original should count the second converted value", 1, frequency.getCount(10L));
      assertEquals("Original should still not count 0L", 0, frequency.getCount(0L));
  }

 @Test
  public void testAddValueIntegerDetectsMutant3() {
      // Setup
      Frequency frequency = new Frequency();
      Integer testValue = 5;
      
      // Action - add the test value
      frequency.addValue(testValue);
      
      // Assertions to detect the mutant
      // Original behavior: count for 5 should be 1, count for 0 should be 0
      // Mutant behavior: count for 5 will be 0, count for 0 will be 1
      assertEquals("Count for actual value should be 1", 1L, frequency.getCount(testValue));
      assertEquals("Count for 0 should be 0", 0L, frequency.getCount(0));
      
      // Additional check for sum frequency
      assertEquals("Total frequency sum should be 1", 1L, frequency.getSumFreq());
      
      // Add another value to verify accumulation
      frequency.addValue(10);
      assertEquals("Count for second value should be 1", 1L, frequency.getCount(10));
      assertEquals("Total frequency sum should be 2", 2L, frequency.getSumFreq());
  }

 @Test
     public void testAddValueComparable_ShouldThrowIllegalArgumentExceptionForNonComparable() {
         // Setup
         Frequency frequency = new Frequency();
         frequency.addValue("stringValue"); // Establish String as comparison type
         
         // Expect exception
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Value not comparable to existing values.");
         
         // Test - try to add incompatible type
         frequency.addValue(new Object()); // Object is not comparable to String
     }

 @Test
     public void testAddValueWithNonComparableObject4() {
         // Create a Frequency object with default comparator
         Frequency frequency = new Frequency();
         
         // Create a non-comparable object
         Object nonComparable = new Object();
         
         // Set expectation for original behavior
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Value not comparable to existing values.");
         
         // This will throw exception for original code,
         // but would throw NullPointerException for mutant
         frequency.addValue(nonComparable);
     }

 @Test
     public void testAddValueWithNull() {
         // Create a Frequency object with default comparator
         Frequency frequency = new Frequency();
         
         // Set expectation for NullPointerException
         thrown.expect(NullPointerException.class);
         
         // This should throw NPE in both original and mutant,
         // but helps verify our test setup
         frequency.addValue(null);
     }

 @Test
     public void testAddValueWithNonComparableObjectShouldThrowIllegalArgumentException() {
         // Create a frequency object with natural ordering
         Frequency frequency = new Frequency();
         
         // Create a non-comparable object
         Object nonComparable = new Object() {
             @Override
             public String toString() {
                 return "Non-comparable object";
             }
         };
         
         // Set expectation for the original behavior
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Value not comparable to existing values.");
         
         // This should throw IllegalArgumentException in original code,
         // but would throw NullPointerException in mutated code
         frequency.addValue(nonComparable);
     }

 @Test
     public void testAddValueWithNonComparableShouldThrowIllegalArgumentException() {
         // Create a Frequency object with a custom comparator
         Frequency frequency = new Frequency((o1, o2) -> {
             // This comparator will throw ClassCastException for different types
             if (o1.getClass() != o2.getClass()) {
                 throw new ClassCastException("Different types");
             }
             return ((Comparable)o1).compareTo(o2);
         });
 
         // Add a Long value first to establish the type in the TreeMap
         frequency.addValue(1L);
 
         // Expect IllegalArgumentException when adding incompatible type
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Value not comparable to existing values.");
 
         // Try to add a different type (String) that's not comparable to Long
         frequency.addValue("incompatible");
     }

 @Test
     public void testAddValueWithIncomparableValueShouldThrowIllegalArgumentException() {
         // Create a custom comparator that makes values incomparable
         Comparator<Long> comparator = (o1, o2) -> {
             throw new ClassCastException("Values not comparable");
         };
         
         Frequency frequency = new Frequency(comparator);
         
         // Set expectation for IllegalArgumentException
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Value not comparable to existing values.");
         
         // Try to add a value that will be incomparable
         frequency.addValue(1L);
     }

 @Test
     public void testAddValueCharWithInvalidComparisonShouldThrowIllegalArgumentException() {
         // Create a Frequency instance with a custom comparator that always throws ClassCastException
         Comparator<Character> failingComparator = new Comparator<Character>() {
             @Override
             public int compare(Character o1, Character o2) {
                 throw new ClassCastException("Cannot compare");
             }
         };
         Frequency frequency = new Frequency(failingComparator);
         
         // Set expectation for the original behavior
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Value not comparable to existing values.");
         
         // This should trigger the exception handling path
         frequency.addValue('a');
         
         // The test will fail if:
         // 1. No exception is thrown (mutant removed exception)
         // 2. Wrong exception type is thrown (mutant changed to NullPointerException)
         // 3. Wrong message is present (if message checking was part of the test)
     }

}
