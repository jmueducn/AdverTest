package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Region.Location;
 
public class SubLineTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                            public void testIntersection_NullSubLine_ThrowsException() {
                                                                                                                                // Create a valid SubLine object to test with
                                                                                                                                Vector3D start = new Vector3D(0, 0, 0);
                                                                                                                                Vector3D end = new Vector3D(1, 1, 1);
                                                                                                                                SubLine subLine = new SubLine(start, end);
                                                                                                                                
                                                                                                                                thrown.expect(NullPointerException.class);
                                                                                                                                subLine.intersection(null, true);
                                                                                                                            }

    @Test
                                                                                                                        public void testIntersection_MixedLocations_IncludeEndpointsTrue_ReturnsIntersectionWhenNotOutside() {
                                                                                                                            // Setup mocks
                                                                                                                            Line mockLine = mock(Line.class);
                                                                                                                            IntervalsSet mockIntervalsSet = mock(IntervalsSet.class);
                                                                                                                            SubLine subLine = new SubLine(mockLine, mockIntervalsSet);
                                                                                                                            
                                                                                                                            Line otherLine = mock(Line.class);
                                                                                                                            IntervalsSet otherIntervalsSet = mock(IntervalsSet.class);
                                                                                                                            SubLine otherSubLine = new SubLine(otherLine, otherIntervalsSet);
                                                                                                                            Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                                            
                                                                                                                            // Setup mock behavior
                                                                                                                            when(mockLine.intersection(otherLine)).thenReturn(intersectionPoint);
                                                                                                                            when(mockLine.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                            when(otherLine.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                            
                                                                                                                            // Test various combinations
                                                                                                                            when(mockIntervalsSet.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                            when(otherIntervalsSet.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                                                                                            assertEquals(intersectionPoint, subLine.intersection(otherSubLine, true));
                                                                                                                            
                                                                                                                            when(mockIntervalsSet.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                                                                                            when(otherIntervalsSet.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                            assertEquals(intersectionPoint, subLine.intersection(otherSubLine, true));
                                                                                                                            
                                                                                                                            when(mockIntervalsSet.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                                                                            when(otherIntervalsSet.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                            assertNull(subLine.intersection(otherSubLine, true));
                                                                                                                        }

    @Test
                                                                                                                    public void testIntersection_PointOnBoundary_IncludeEndpointsTrue_ReturnsIntersection() {
                                                                                                                        // Setup mocks
                                                                                                                        org.apache.commons.math3.geometry.euclidean.threed.Line mockLine = 
                                                                                                                            mock(org.apache.commons.math3.geometry.euclidean.threed.Line.class);
                                                                                                                        org.apache.commons.math3.geometry.euclidean.threed.SubLine otherSubLine = 
                                                                                                                            mock(org.apache.commons.math3.geometry.euclidean.threed.SubLine.class);
                                                                                                                        org.apache.commons.math3.geometry.euclidean.threed.Line otherLine = 
                                                                                                                            mock(org.apache.commons.math3.geometry.euclidean.threed.Line.class);
                                                                                                                        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet otherIntervalsSet = 
                                                                                                                            mock(org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet.class);
                                                                                                                        org.apache.commons.math3.geometry.euclidean.threed.Vector3D intersectionPoint = 
                                                                                                                            new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 2, 3);
                                                                                                                        
                                                                                                                        // Create real subLine instance with mocked components
                                                                                                                        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet mockIntervalsSet = 
                                                                                                                            mock(org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet.class);
                                                                                                                        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine = 
                                                                                                                            new org.apache.commons.math3.geometry.euclidean.threed.SubLine(mockLine, mockIntervalsSet);
                                                                                                                        
                                                                                                                        // Mock otherSubLine behavior using reflection
                                                                                                                        try {
                                                                                                                            // Set line field
                                                                                                                            Field lineField = org.apache.commons.math3.geometry.euclidean.threed.SubLine.class
                                                                                                                                .getDeclaredField("line");
                                                                                                                            lineField.setAccessible(true);
                                                                                                                            lineField.set(otherSubLine, otherLine);
                                                                                                                            
                                                                                                                            // Set remainingRegion field
                                                                                                                            Field remainingRegionField = org.apache.commons.math3.geometry.euclidean.threed.SubLine.class
                                                                                                                                .getDeclaredField("remainingRegion");
                                                                                                                            remainingRegionField.setAccessible(true);
                                                                                                                            remainingRegionField.set(otherSubLine, otherIntervalsSet);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to set fields via reflection");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Setup mock behaviors
                                                                                                                        when(mockLine.intersection(otherLine)).thenReturn(intersectionPoint);
                                                                                                                        when(mockLine.toSubSpace(intersectionPoint))
                                                                                                                            .thenReturn(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.5));
                                                                                                                        when(otherLine.toSubSpace(intersectionPoint))
                                                                                                                            .thenReturn(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.5));
                                                                                                                        when(mockIntervalsSet.checkPoint(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class)))
                                                                                                                            .thenReturn(org.apache.commons.math3.geometry.partitioning.Region.Location.BOUNDARY);
                                                                                                                        when(otherIntervalsSet.checkPoint(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class)))
                                                                                                                            .thenReturn(org.apache.commons.math3.geometry.partitioning.Region.Location.BOUNDARY);
                                                                                                                        
                                                                                                                        // Verify behavior
                                                                                                                        assertEquals(intersectionPoint, subLine.intersection(otherSubLine, true));
                                                                                                                        assertNull(subLine.intersection(otherSubLine, false));
                                                                                                                    }

    @Test
                                                                                                            public void testIntersection_LinesDontIntersect_ReturnsNull() {
                                                                                                                // Create mock lines
                                                                                                                Line mockLine = mock(Line.class);
                                                                                                                Line otherLine = mock(Line.class);
                                                                                                                
                                                                                                                // Create mock region (we don't need its actual behavior for this test)
                                                                                                                IntervalsSet mockRegion = mock(IntervalsSet.class);
                                                                                                                
                                                                                                                // Create the subLine being tested
                                                                                                                SubLine subLine = new SubLine(mockLine, mockRegion);
                                                                                                                
                                                                                                                // Create the other subline for testing
                                                                                                                SubLine otherSubLine = new SubLine(otherLine, mockRegion);
                                                                                                                
                                                                                                                // Set up mock behavior - lines don't intersect
                                                                                                                when(mockLine.intersection(otherLine)).thenReturn(null);
                                                                                                                
                                                                                                                // Test both cases (with and without endpoints)
                                                                                                                assertNull(subLine.intersection(otherSubLine, true));
                                                                                                                assertNull(subLine.intersection(otherSubLine, false));
                                                                                                            }

    @Test
                                                                                                        public void testIntersection_PointInsideBothSubLines_ReturnsIntersection() throws Exception {
                                                                                                            // Create mock objects
                                                                                                            Line mockLine = mock(Line.class);
                                                                                                            IntervalsSet mockIntervalsSet = mock(IntervalsSet.class);
                                                                                                            
                                                                                                            // Create real subLine object with mocked components
                                                                                                            SubLine subLine = new SubLine(mockLine, mockIntervalsSet);
                                                                                                            
                                                                                                            // Create other subLine and its components
                                                                                                            SubLine otherSubLine = mock(SubLine.class);
                                                                                                            Line otherLine = mock(Line.class);
                                                                                                            IntervalsSet otherIntervalsSet = mock(IntervalsSet.class);
                                                                                                            
                                                                                                            // Set up intersection point
                                                                                                            Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                            
                                                                                                            // Mock the behavior
                                                                                                            when(mockLine.intersection(otherLine)).thenReturn(intersectionPoint);
                                                                                                            when(mockLine.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                            when(otherLine.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                            when(mockIntervalsSet.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                            
                                                                                                            // Use reflection to set private remainingRegion field of otherSubLine
                                                                                                            Field remainingRegionField = SubLine.class.getDeclaredField("remainingRegion");
                                                                                                            remainingRegionField.setAccessible(true);
                                                                                                            remainingRegionField.set(otherSubLine, otherIntervalsSet);
                                                                                                            
                                                                                                            when(otherIntervalsSet.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                            
                                                                                                            // Verify the results
                                                                                                            assertEquals(intersectionPoint, subLine.intersection(otherSubLine, true));
                                                                                                            assertEquals(intersectionPoint, subLine.intersection(otherSubLine, false));
                                                                                                        }

    @Test
                                                                    public void testIntersection_PointOutsideBothSubLines_ReturnsNull() throws Exception {
                                                                        // Setup mocks
                                                                        org.apache.commons.math3.geometry.euclidean.threed.Line mockLine = 
                                                                            new org.apache.commons.math3.geometry.euclidean.threed.Line(
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 0, 0),
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0));
                                                                        
                                                                        // Create subLine instance using public constructor
                                                                        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine = 
                                                                            new org.apache.commons.math3.geometry.euclidean.threed.SubLine(
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 0, 0),
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0));
                                                                        
                                                                        // Create other subline
                                                                        org.apache.commons.math3.geometry.euclidean.threed.Line otherMockLine = 
                                                                            new org.apache.commons.math3.geometry.euclidean.threed.Line(
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 1, 0),
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 1, 0));
                                                                        
                                                                        org.apache.commons.math3.geometry.euclidean.threed.SubLine otherSubLine = 
                                                                            new org.apache.commons.math3.geometry.euclidean.threed.SubLine(
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 1, 0),
                                                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 1, 0));
                                                                        
                                                                        // Verify intersection is null in both cases
                                                                        assertNull(subLine.intersection(otherSubLine, true));
                                                                        assertNull(subLine.intersection(otherSubLine, false));
                                                                    }

    @Test
                                                                public void testIntersection_NonIntersectingLines_ShouldReturnNull() {
                                                                    // Create two lines that don't intersect
                                                                    Vector3D p1 = new Vector3D(0, 0, 0);
                                                                    Vector3D p2 = new Vector3D(1, 0, 0);
                                                                    Line line1 = new Line(p1, p2);
                                                                    
                                                                    Vector3D p3 = new Vector3D(0, 1, 0);
                                                                    Vector3D p4 = new Vector3D(1, 1, 0);
                                                                    Line line2 = new Line(p3, p4);
                                                                    
                                                                    // Create interval sets covering the entire lines
                                                                    IntervalsSet interval1 = new IntervalsSet(0, 1);
                                                                    IntervalsSet interval2 = new IntervalsSet(0, 1);
                                                                    
                                                                    // Create sub-lines
                                                                    SubLine subLine1 = new SubLine(line1, interval1);
                                                                    SubLine subLine2 = new SubLine(line2, interval2);
                                                                    
                                                                    // Test with includeEndPoints both true and false
                                                                    assertNull("Should return null when lines don't intersect (includeEndPoints=true)", 
                                                                               subLine1.intersection(subLine2, true));
                                                                    assertNull("Should return null when lines don't intersect (includeEndPoints=false)", 
                                                                               subLine1.intersection(subLine2, false));
                                                                    
                                                                    // The mutant would return v1D (non-null) here instead of null
                                                                }

    @Test
                                                               public void testIntersectionWithDifferentRegionChecks() {
                                                                   // Create mock objects
                                                                   Line line1 = mock(Line.class);
                                                                   Line line2 = mock(Line.class);
                                                                   IntervalsSet region1 = mock(IntervalsSet.class);
                                                                   IntervalsSet region2 = mock(IntervalsSet.class);
                                                                   
                                                                   // Create test sub-lines
                                                                   SubLine subLine1 = new SubLine(line1, region1);
                                                                   SubLine subLine2 = new SubLine(line2, region2);
                                                                   
                                                                   // Setup intersection point
                                                                   Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                   when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                   
                                                                   // Setup different location checks
                                                                   when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                   when(region2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                   
                                                                   // Test with includeEndPoints=false (strict check)
                                                                   Vector3D result = subLine1.intersection(subLine2, false);
                                                                   
                                                                   // Assertion - should be null since point is outside second region
                                                                   assertNull("Intersection should be null when point is not in both regions", result);
                                                                   
                                                                   // Test with includeEndPoints=true (lenient check)
                                                                   result = subLine1.intersection(subLine2, true);
                                                                   
                                                                   // Assertion - should still be null since point is outside second region
                                                                   assertNull("Intersection should be null when point is outside second region", result);
                                                               }

    @Test
                                                             public void testIntersectionWithOneInsideOneOutsideWhenEndpointsExcluded() throws Exception {
                                                                 // Create first line and its region (accepting points with x between 0 and 10)
                                                                 Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(10, 0, 0));
                                                                 IntervalsSet region1 = new IntervalsSet(0, 10);
                                                                 SubLine subLine1 = new SubLine(line1, region1);
                                                                 
                                                                 // Create second line (same line) but with different region (accepting points with x between 5 and 15)
                                                                 Line line2 = new Line(new Vector3D(0, 0, 0), new Vector3D(10, 0, 0));
                                                                 IntervalsSet region2 = new IntervalsSet(5, 15);
                                                                 SubLine subLine2 = new SubLine(line2, region2);
                                                                 
                                                                 // Test point at x=4 (inside subLine1's region but outside subLine2's region)
                                                                 Vector3D testPoint = new Vector3D(4, 0, 0);
                                                                 
                                                                 // Create mocks
                                                                 SubLine mockSubLine1 = spy(subLine1);
                                                                 SubLine mockSubLine2 = spy(subLine2);
                                                                 
                                                                 // Mock the intersection check to return our test point
                                                                 when(mockSubLine1.intersection(any(SubLine.class), anyBoolean())).thenReturn(testPoint);
                                                                 
                                                                 // Get remainingRegion fields via reflection
                                                                 Field remainingRegionField = SubLine.class.getDeclaredField("remainingRegion");
                                                                 remainingRegionField.setAccessible(true);
                                                                 
                                                                 IntervalsSet mockRegion1 = spy((IntervalsSet) remainingRegionField.get(mockSubLine1));
                                                                 IntervalsSet mockRegion2 = spy((IntervalsSet) remainingRegionField.get(mockSubLine2));
                                                                 
                                                                 // Set the mocked regions back
                                                                 remainingRegionField.set(mockSubLine1, mockRegion1);
                                                                 remainingRegionField.set(mockSubLine2, mockRegion2);
                                                                 
                                                                 // Mock the location checks
                                                                 when(mockRegion1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                 when(mockRegion2.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                                                 
                                                                 // Test with includeEndPoints = false
                                                                 Vector3D result = mockSubLine1.intersection(mockSubLine2, false);
                                                                 
                                                                 // Original code should return null (both need to be INSIDE)
                                                                 // Mutant would return testPoint (only one needs to be INSIDE)
                                                                 assertNull("Should return null when one point is outside and endpoints are excluded", result);
                                                             }

    @Test
                                                         public void testIntersectionInsideSegmentsWithIncludeEndPointsFalse() {
                                                             // Create two lines that intersect
                                                             Vector3D p1 = new Vector3D(0, 0, 0);
                                                             Vector3D p2 = new Vector3D(2, 2, 0);
                                                             Vector3D p3 = new Vector3D(0, 2, 0);
                                                             Vector3D p4 = new Vector3D(2, 0, 0);
                                                             
                                                             // Create sub-lines that cover the intersection point (1,1,0)
                                                             SubLine subLine1 = new SubLine(p1, p2);
                                                             SubLine subLine2 = new SubLine(p3, p4);
                                                             
                                                             // Expected intersection point
                                                             Vector3D expected = new Vector3D(1, 1, 0);
                                                             
                                                             // Test with includeEndPoints=false - should return the intersection point
                                                             Vector3D result = subLine1.intersection(subLine2, false);
                                                             
                                                             // This assertion will fail with the mutant (which returns null)
                                                             assertEquals(expected, result);
                                                             
                                                             // Additional verification that it's not null
                                                             assertNotNull(result);
                                                         }

    @Test
                                                        public void testIntersection_DifferentRegions_ShouldReturnNull() {
                                                            // Create mock objects
                                                            Line line1 = mock(Line.class);
                                                            Line line2 = mock(Line.class);
                                                            IntervalsSet region1 = mock(IntervalsSet.class);
                                                            IntervalsSet region2 = mock(IntervalsSet.class);
                                                            
                                                            // Create test objects
                                                            SubLine subLine1 = new SubLine(line1, region1);
                                                            SubLine subLine2 = new SubLine(line2, region2);
                                                            
                                                            // Create test intersection point
                                                            Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                            
                                                            // Mock behavior
                                                            when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                            when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                            when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                            
                                                            // Make region1 accept the point but region2 reject it
                                                            when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                            when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                                            
                                                            // Test both includeEndPoints cases
                                                            // Case 1: includeEndPoints = true
                                                            assertNull("Should return null when point is outside subLine2's region", 
                                                                      subLine1.intersection(subLine2, true));
                                                            
                                                            // Case 2: includeEndPoints = false
                                                            assertNull("Should return null when point is outside subLine2's region", 
                                                                      subLine1.intersection(subLine2, false));
                                                            
                                                            // Verify the correct remainingRegion was checked
                                                            verify(region1, times(2)).checkPoint(any(Vector1D.class));
                                                            verify(region2, times(2)).checkPoint(any(Vector1D.class));
                                                        }

    @Test
                                                       public void testIntersectionWithParallelLines() {
                                                           // Create two parallel lines that don't intersect
                                                           Vector3D p1 = new Vector3D(0, 0, 0);
                                                           Vector3D p2 = new Vector3D(1, 0, 0);
                                                           Line line1 = new Line(p1, p2);
                                                           
                                                           Vector3D p3 = new Vector3D(0, 1, 0);
                                                           Vector3D p4 = new Vector3D(1, 1, 0);
                                                           Line line2 = new Line(p3, p4);
                                                           
                                                           // Create interval sets covering the entire lines
                                                           IntervalsSet interval1 = new IntervalsSet(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                           IntervalsSet interval2 = new IntervalsSet(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                           
                                                           // Create sub-lines
                                                           SubLine subLine1 = new SubLine(line1, interval1);
                                                           SubLine subLine2 = new SubLine(line2, interval2);
                                                           
                                                           // Test intersection with both includeEndPoints values
                                                           assertNull("Should return null for parallel lines (includeEndPoints=true)", 
                                                                     subLine1.intersection(subLine2, true));
                                                           assertNull("Should return null for parallel lines (includeEndPoints=false)", 
                                                                     subLine1.intersection(subLine2, false));
                                                       }

    @Test
                                                      public void testIntersection_includeEndPointsFalse_pointInsideBothSubLines() {
                                                          // Setup - create two lines that intersect at (1,1,0)
                                                          Vector3D p1 = new Vector3D(0, 0, 0);
                                                          Vector3D p2 = new Vector3D(2, 2, 0);
                                                          Line line1 = new Line(p1, p2);
                                                          
                                                          Vector3D p3 = new Vector3D(0, 2, 0);
                                                          Vector3D p4 = new Vector3D(2, 0, 0);
                                                          Line line2 = new Line(p3, p4);
                                                          
                                                          // Create regions that include the intersection point (1,1,0)
                                                          IntervalsSet region1 = mock(IntervalsSet.class);
                                                          when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                          
                                                          IntervalsSet region2 = mock(IntervalsSet.class);
                                                          when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                          
                                                          // Create sublines
                                                          SubLine subLine1 = new SubLine(line1, region1);
                                                          SubLine subLine2 = new SubLine(line2, region2);
                                                          
                                                          // Test intersection with includeEndPoints = false
                                                          Vector3D intersection = subLine1.intersection(subLine2, false);
                                                          
                                                          // Verify - should return the intersection point (1,1,0)
                                                          assertNotNull("Intersection point should not be null when point is inside both sublines", intersection);
                                                          assertEquals(1.0, intersection.getX(), 1e-10);
                                                          assertEquals(1.0, intersection.getY(), 1e-10);
                                                          assertEquals(0.0, intersection.getZ(), 1e-10);
                                                      }

    @Test
                                                    public void testIntersectionAllCases() {
                                                        // Setup test objects
                                                        Line line1 = mock(Line.class);
                                                        Line line2 = mock(Line.class);
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        
                                                        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                        Vector1D subspacePoint = new Vector1D(1);
                                                        
                                                        // Case 1: No intersection
                                                        when(line1.intersection(line2)).thenReturn(null);
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        assertNull(subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                        
                                                        // Case 2: Intersection exists but outside both regions
                                                        when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                        when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                        when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                        when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                        when(region2.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                        assertNull(subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                        
                                                        // Case 3: Intersection inside both regions
                                                        when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                        when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                        assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                        assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                        
                                                        // Case 4: Boundary cases with includeEndPoints
                                                        when(region1.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                        when(region2.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                        assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                        
                                                        // Case 5: Mixed locations
                                                        when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                        when(region2.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                        assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                    }

    @Test
                                                    public void testIntersectionWhenLinesDontIntersect() {
                                                        // Setup
                                                        Line line1 = mock(Line.class);
                                                        when(line1.intersection(any(Line.class))).thenReturn(null);
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        
                                                        Line line2 = mock(Line.class);
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // Test both includeEndPoints cases
                                                        assertNull(subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                        
                                                        // Verify interaction
                                                        verify(line1).intersection(line2);
                                                    }

    @Test
                                                    public void testIntersectionWhenPointOutsideRegions() {
                                                        // Setup
                                                        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                        Line line1 = mock(Line.class);
                                                        when(line1.intersection(any(Line.class))).thenReturn(intersectionPoint);
                                                        when(line1.toSubSpace(intersectionPoint)).thenReturn(null); // Simplified
                                                        
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                        
                                                        Line line2 = mock(Line.class);
                                                        when(line2.toSubSpace(intersectionPoint)).thenReturn(null); // Simplified
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        when(region2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                        
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // Test
                                                        assertNull(subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                    }

    @Test
                                                    public void testIntersectionWhenPointInsideRegions() {
                                                        // Setup
                                                        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                        Line line1 = mock(Line.class);
                                                        when(line1.intersection(any(Line.class))).thenReturn(intersectionPoint);
                                                        when(line1.toSubSpace(intersectionPoint)).thenReturn(null); // Simplified
                                                        
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                        
                                                        Line line2 = mock(Line.class);
                                                        when(line2.toSubSpace(intersectionPoint)).thenReturn(null); // Simplified
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                        
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // Test
                                                        assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                        assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                    }

    @Test
                                                    public void testIntersectionAtEndPoints() {
                                                        // Setup
                                                        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                        Line line1 = mock(Line.class);
                                                        when(line1.intersection(any(Line.class))).thenReturn(intersectionPoint);
                                                        when(line1.toSubSpace(intersectionPoint)).thenReturn(null); // Simplified
                                                        
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                        
                                                        Line line2 = mock(Line.class);
                                                        when(line2.toSubSpace(intersectionPoint)).thenReturn(null); // Simplified
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        when(region2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                        
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // Test
                                                        assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                    }

    @Test
                                      public void testIntersectionWithLocationCheck() {
                                          // Create two intersecting lines
                                          Vector3D p1 = new Vector3D(0, 0, 0);
                                          Vector3D p2 = new Vector3D(2, 0, 0);
                                          Vector3D p3 = new Vector3D(1, -1, 0);
                                          Vector3D p4 = new Vector3D(1, 1, 0);
                                          
                                          // Create sub-lines with specific regions
                                          Line line1 = new Line(p1, p2);
                                          Line line2 = new Line(p3, p4);
                                          
                                          // Create intervals that only include part of the lines
                                          Vector3D region1Start = line1.toSpace(new Vector1D(0.25));
                                          Vector3D region1End = line1.toSpace(new Vector1D(1.75));
                                          SubLine subLine1 = new SubLine(region1Start, region1End);
                                          
                                          Vector3D region2Start = line2.toSpace(new Vector1D(0.5));
                                          Vector3D region2End = line2.toSpace(new Vector1D(1.5));
                                          SubLine subLine2 = new SubLine(region2Start, region2End);
                                          
                                          // Test intersection with includeEndPoints=true
                                          Vector3D intersection = subLine1.intersection(subLine2, true);
                                          assertNotNull("Intersection should exist", intersection);
                                          assertEquals(1.0, intersection.getX(), 1e-10);
                                          assertEquals(0.0, intersection.getY(), 1e-10);
                                          assertEquals(0.0, intersection.getZ(), 1e-10);
                                          
                                          // Test intersection with includeEndPoints=false (should still pass)
                                          intersection = subLine1.intersection(subLine2, false);
                                          assertNotNull("Intersection should exist", intersection);
                                          
                                          // Create a case where intersection is at boundary of one sub-line
                                          Vector3D boundaryStart = line1.toSpace(new Vector1D(1.0));
                                          Vector3D boundaryEnd = line1.toSpace(new Vector1D(2.0));
                                          SubLine boundarySubLine = new SubLine(boundaryStart, boundaryEnd);
                                          
                                          // With includeEndPoints=true should return intersection
                                          intersection = boundarySubLine.intersection(subLine2, true);
                                          assertNotNull("Boundary point should be included", intersection);
                                          
                                          // With includeEndPoints=false should return null
                                          intersection = boundarySubLine.intersection(subLine2, false);
                                          assertNull("Boundary point should be excluded", intersection);
                                          
                                          // Create a case where intersection is outside one sub-line
                                          Vector3D outsideStart = line1.toSpace(new Vector1D(1.1));
                                          Vector3D outsideEnd = line1.toSpace(new Vector1D(2.0));
                                          SubLine outsideSubLine = new SubLine(outsideStart, outsideEnd);
                                          
                                          intersection = outsideSubLine.intersection(subLine2, true);
                                          assertNull("Intersection should be outside first sub-line", intersection);
                                      }

    @Test
                                 public void testIntersection_FirstSubLineBoundarySecondInside() {
                                     // Setup test objects
                                     Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(1, 0, 0));
                                     Line line2 = new Line(new Vector3D(0.5, 0, 0), new Vector3D(0.5, 1, 0));
                                     
                                     // Create sub-lines - first sub-line starts at x=0.5 (boundary), second covers entire line
                                     SubLine subLine1 = new SubLine(new Vector3D(0.5, 0, 0), new Vector3D(1.0, 0, 0));
                                     SubLine subLine2 = new SubLine(new Vector3D(0.5, -1000, 0), new Vector3D(0.5, 1000, 0));
                                     
                                     // Test with includeEndPoints = true (should include boundary)
                                     Vector3D intersection = subLine1.intersection(subLine2, true);
                                     assertNotNull("Intersection should not be null when point is on boundary and includeEndPoints=true", intersection);
                                     assertEquals(new Vector3D(0.5, 0, 0), intersection);
                                     
                                     // Test with includeEndPoints = false (should exclude boundary)
                                     intersection = subLine1.intersection(subLine2, false);
                                     assertNull("Intersection should be null when point is on boundary and includeEndPoints=false", intersection);
                                 }

    @Test
                             public void testIntersection_FirstSubLineOutsideSecondInside() {
                                 // Setup test objects
                                 Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(1, 0, 0));
                                 Line line2 = new Line(new Vector3D(0, 0, 0), new Vector3D(0, 1, 0));
                                 
                                 // Create sub-lines directly using start and end points
                                 // First sub-line only covers x > 0.5
                                 SubLine subLine1 = new SubLine(new Vector3D(0.5, 0, 0), new Vector3D(1, 0, 0));
                                 // Second sub-line covers all y (entire line)
                                 SubLine subLine2 = new SubLine(new Vector3D(0, Double.NEGATIVE_INFINITY, 0), 
                                                             new Vector3D(0, Double.POSITIVE_INFINITY, 0));
                                 
                                 // Test with includeEndPoints = true
                                 Vector3D intersection = subLine1.intersection(subLine2, true);
                                 assertNull("Intersection should be null when point is outside first sub-line", intersection);
                                 
                                 // Test with includeEndPoints = false
                                 intersection = subLine1.intersection(subLine2, false);
                                 assertNull("Intersection should be null when point is outside first sub-line", intersection);
                             }

    @Test
                             public void testIntersectionIncludeEndPoints() {
                                 // Setup test objects
                                 Line line1 = mock(Line.class);
                                 Line line2 = mock(Line.class);
                                 IntervalsSet region1 = mock(IntervalsSet.class);
                                 IntervalsSet region2 = mock(IntervalsSet.class);
                                 
                                 // Create intersection point that is exactly on boundary
                                 Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                 
                                 // Mock behavior
                                 when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                 when(line1.toSubSpace(intersectionPoint)).thenReturn(null); // exact value doesn't matter
                                 when(line2.toSubSpace(intersectionPoint)).thenReturn(null); // exact value doesn't matter
                                 
                                 // Mock region checks to return boundary locations
                                 when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                 when(region2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                 
                                 // Create test objects
                                 SubLine subLine1 = new SubLine(line1, region1);
                                 SubLine subLine2 = new SubLine(line2, region2);
                                 
                                 // Test with includeEndPoints=true - should return the point
                                 Vector3D result = subLine1.intersection(subLine2, true);
                                 
                                 // Assert that the point is returned (original behavior)
                                 // Mutated version would return null because it would do INSIDE check
                                 assertNotNull("Intersection point on boundary should be included when includeEndPoints=true", result);
                                 assertEquals(intersectionPoint, result);
                             }

    @Test
                            public void testIntersectionWithIncludeEndPoints() {
                                // Setup test objects
                                Line line1 = mock(Line.class);
                                Line line2 = mock(Line.class);
                                IntervalsSet region1 = mock(IntervalsSet.class);
                                IntervalsSet region2 = mock(IntervalsSet.class);
                                
                                Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                
                                // Mock the checkPoint calls to return INSIDE for both regions
                                when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                
                                // Create test objects
                                SubLine subLine1 = new SubLine(line1, region1);
                                SubLine subLine2 = new SubLine(line2, region2);
                                
                                // Test with includeEndPoints = true
                                Vector3D result = subLine1.intersection(subLine2, true);
                                
                                // Verify the complete method executed by checking the result
                                assertNotNull("Intersection point should not be null", result);
                                assertEquals("Should return the correct intersection point", 
                                            intersectionPoint, result);
                                
                                // Verify the complete method executed by checking mock interactions
                                verify(line1).intersection(line2);
                                verify(region1).checkPoint(any());
                                verify(region2).checkPoint(any());
                            }

    @Test
                            public void testIntersectionWithoutIncludeEndPoints() {
                                // Setup test objects
                                Line line1 = mock(Line.class);
                                Line line2 = mock(Line.class);
                                IntervalsSet region1 = mock(IntervalsSet.class);
                                IntervalsSet region2 = mock(IntervalsSet.class);
                                
                                Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                
                                // Mock the checkPoint calls to return INSIDE for both regions
                                when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                
                                // Create test objects
                                SubLine subLine1 = new SubLine(line1, region1);
                                SubLine subLine2 = new SubLine(line2, region2);
                                
                                // Test with includeEndPoints = false
                                Vector3D result = subLine1.intersection(subLine2, false);
                                
                                // Verify the complete method executed by checking the result
                                assertNotNull("Intersection point should not be null", result);
                                assertEquals("Should return the correct intersection point", 
                                            intersectionPoint, result);
                            }

    @Test
                       public void testIntersectionDetectsMutant() {
                           // Setup test lines and regions
                           Vector3D p1 = new Vector3D(0, 0, 0);
                           Vector3D p2 = new Vector3D(1, 0, 0);
                           Vector3D p3 = new Vector3D(1, 1, 0);
                           
                           Line line1 = new Line(p1, p2);
                           Line line2 = new Line(p1, p3);
                           
                           // Create regions that cover different portions of the lines
                           IntervalsSet region1 = new IntervalsSet(0, 1);
                           IntervalsSet region2 = new IntervalsSet(0, 0.5);
                           
                           SubLine subLine1 = new SubLine(line1, region1);
                           SubLine subLine2 = new SubLine(line2, region2);
                           
                           // Test case 1: Intersection exists and is inside both regions (includeEndPoints=true)
                           Vector3D result1 = subLine1.intersection(subLine2, true);
                           assertEquals(p1, result1);
                           
                           // Test case 2: Intersection exists but is outside second region (includeEndPoints=true)
                           SubLine subLine3 = new SubLine(line2, new IntervalsSet(0.6, 1));
                           Vector3D result2 = subLine1.intersection(subLine3, true);
                           assertNull(result2);
                           
                           // Test case 3: Intersection at endpoint but includeEndPoints=false
                           Vector3D result3 = subLine1.intersection(subLine2, false);
                           assertNull(result3);
                           
                           // Test case 4: No intersection between lines
                           Line parallelLine = new Line(new Vector3D(0, 1, 0), new Vector3D(1, 1, 0));
                           SubLine subLine4 = new SubLine(parallelLine, region1);
                           Vector3D result4 = subLine1.intersection(subLine4, true);
                           assertNull(result4);
                           
                           // Test case 5: Intersection exactly at region boundary (edge case)
                           SubLine subLine5 = new SubLine(line2, new IntervalsSet(0, 0));
                           Vector3D result5 = subLine1.intersection(subLine5, true);
                           assertEquals(p1, result5);
                           Vector3D result6 = subLine1.intersection(subLine5, false);
                           assertNull(result6);
                       }

    @Test
                      public void testIntersectionWithPointLocationChecking() {
                          // Create mock objects
                          Line line1 = mock(Line.class);
                          Line line2 = mock(Line.class);
                          IntervalsSet region1 = mock(IntervalsSet.class);
                          IntervalsSet region2 = mock(IntervalsSet.class);
                          
                          // Create test sub-lines
                          SubLine subLine1 = new SubLine(line1, region1);
                          SubLine subLine2 = new SubLine(line2, region2);
                          
                          // Setup intersection point
                          Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                          when(line1.intersection(line2)).thenReturn(intersectionPoint);
                          
                          // Setup subspace points
                          Vector1D subspacePoint = new Vector1D(0.5);
                          when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                          when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                          
                          // Test case 1: Both points are inside regions (includeEndPoints=false)
                          when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                          when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                          Vector3D result = subLine1.intersection(subLine2, false);
                          assertEquals(intersectionPoint, result);
                          
                          // Test case 2: First point is outside (should return null)
                          when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                          when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                          assertNull(subLine1.intersection(subLine2, false));
                          
                          // Test case 3: Second point is outside (should return null)
                          when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                          when(region2.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                          assertNull(subLine1.intersection(subLine2, false));
                          
                          // Test case 4: Test with includeEndPoints=true
                          when(region1.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                          when(region2.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                          result = subLine1.intersection(subLine2, true);
                          assertEquals(intersectionPoint, result);
                          
                          // Verify interactions
                          verify(line1).intersection(line2);
                          verify(line1).toSubSpace(intersectionPoint);
                          verify(line2).toSubSpace(intersectionPoint);
                          verify(region1, atLeastOnce()).checkPoint(subspacePoint);
                          verify(region2, atLeastOnce()).checkPoint(subspacePoint);
                      }

    @Test
                     public void testIntersection_FirstSubLineRegionCheck() {
                         // Create first line (x-axis from 0 to 10)
                         Vector3D start1 = new Vector3D(0, 0, 0);
                         Vector3D end1 = new Vector3D(10, 0, 0);
                         SubLine subLine1 = new SubLine(start1, end1);
                         
                         // Create second line that intersects at (5,0,0)
                         Vector3D start2 = new Vector3D(5, -5, 0);
                         Vector3D end2 = new Vector3D(5, 5, 0);
                         SubLine subLine2 = new SubLine(start2, end2);
                         
                         // Case 1: Intersection point is within both sub-lines' regions
                         Vector3D intersection1 = subLine1.intersection(subLine2, true);
                         assertEquals(new Vector3D(5, 0, 0), intersection1);
                         
                         // Case 2: Create a sub-line that only covers x-axis from 0 to 4
                         // The intersection at (5,0,0) should be outside this region
                         IntervalsSet intervalSet = new IntervalsSet(0, 4);
                         SubLine subLine3 = new SubLine(new Line(start1, end1), intervalSet);
                         
                         // Should return null since intersection is outside first sub-line's region
                         Vector3D intersection2 = subLine3.intersection(subLine2, true);
                         assertNull(intersection2);
                         
                         // Case 3: Boundary case - intersection is exactly at endpoint (10,0,0)
                         Vector3D start3 = new Vector3D(10, -5, 0);
                         Vector3D end3 = new Vector3D(10, 5, 0);
                         SubLine subLine4 = new SubLine(start3, end3);
                         
                         // With includeEndPoints=true, should return the endpoint
                         Vector3D intersection3 = subLine1.intersection(subLine4, true);
                         assertEquals(new Vector3D(10, 0, 0), intersection3);
                         
                         // With includeEndPoints=false, should return null
                         Vector3D intersection4 = subLine1.intersection(subLine4, false);
                         assertNull(intersection4);
                     }

    @Test
                    public void testIntersectionWithInsidePointsAndIncludeEndPointsFalse() {
                        // Setup test data
                        Vector3D start1 = new Vector3D(0, 0, 0);
                        Vector3D end1 = new Vector3D(2, 0, 0);
                        Vector3D start2 = new Vector3D(1, -1, 0);
                        Vector3D end2 = new Vector3D(1, 1, 0);
                        
                        // Create sub-lines that will intersect at (1,0,0) which is inside both
                        SubLine subLine1 = new SubLine(start1, end1);
                        SubLine subLine2 = new SubLine(start2, end2);
                        
                        // Mock the checkPoint behavior to return INSIDE for both sub-lines
                        IntervalsSet mockRegion1 = mock(IntervalsSet.class);
                        when(mockRegion1.checkPoint(any())).thenReturn(Location.INSIDE);
                        
                        IntervalsSet mockRegion2 = mock(IntervalsSet.class);
                        when(mockRegion2.checkPoint(any())).thenReturn(Location.INSIDE);
                        
                        // Create sub-lines with mocked regions
                        Line line1 = new Line(start1, end1);
                        Line line2 = new Line(start2, end2);
                        SubLine testSubLine1 = new SubLine(line1, mockRegion1);
                        SubLine testSubLine2 = new SubLine(line2, mockRegion2);
                        
                        // Test with includeEndPoints = false
                        Vector3D result = testSubLine1.intersection(testSubLine2, false);
                        
                        // Verify - original should return intersection, mutant will return null
                        Vector3D expectedIntersection = new Vector3D(1, 0, 0);
                        assertEquals("Intersection point should be returned when point is inside both sub-lines", 
                                     expectedIntersection, result);
                    }

    @Test
                       public void testIntersectionAllBranches() {
                           // Setup test objects
                           Line line1 = mock(Line.class);
                           Line line2 = mock(Line.class);
                           IntervalsSet region1 = mock(IntervalsSet.class);
                           IntervalsSet region2 = mock(IntervalsSet.class);
                           Vector3D intersectionPoint = mock(Vector3D.class);
                           
                           // Create sublines
                           SubLine subLine1 = new SubLine(line1, region1);
                           SubLine subLine2 = new SubLine(line2, region2);
                           
                           // Case 1: No intersection
                           when(line1.intersection(line2)).thenReturn(null);
                           assertNull(subLine1.intersection(subLine2, true));
                           assertNull(subLine1.intersection(subLine2, false));
                           
                           // Case 2: Intersection exists but outside both regions
                           when(line1.intersection(line2)).thenReturn(intersectionPoint);
                           when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                           when(region2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                           assertNull(subLine1.intersection(subLine2, true));
                           assertNull(subLine1.intersection(subLine2, false));
                           
                           // Case 3: Intersection inside both regions
                           when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                           when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                           assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                           assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                           
                           // Case 4: Intersection on boundary (includeEndPoints=true)
                           when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                           when(region2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                           assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                           assertNull(subLine1.intersection(subLine2, false));
                           
                           // Case 5: Mixed locations
                           when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                           when(region2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                           assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                           assertNull(subLine1.intersection(subLine2, false));
                       }

    @Test
                  public void testIntersectionLocationChecking() {
                      // Setup two lines that intersect at (1,1,0)
                      Vector3D p1 = new Vector3D(0, 0, 0);
                      Vector3D p2 = new Vector3D(2, 2, 0);
                      Line line1 = new Line(p1, p2);
                      
                      Vector3D p3 = new Vector3D(0, 2, 0);
                      Vector3D p4 = new Vector3D(2, 0, 0);
                      Line line2 = new Line(p3, p4);
                      
                      // Create regions that include/exclude the intersection point
                      IntervalsSet region1 = mock(IntervalsSet.class);
                      IntervalsSet region2 = mock(IntervalsSet.class);
                      
                      // Mock location checks - this verifies the actual location checking behavior
                      when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                      when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                      
                      SubLine subLine1 = new SubLine(line1, region1);
                      SubLine subLine2 = new SubLine(line2, region2);
                      
                      // Test with includeEndPoints = false
                      Vector3D intersection = subLine1.intersection(subLine2, false);
                      assertNotNull(intersection);
                      assertEquals(1.0, intersection.getX(), 1.0e-10);
                      assertEquals(1.0, intersection.getY(), 1.0e-10);
                      
                      // Verify the location checking was performed
                      verify(region1, times(1)).checkPoint(any(Vector1D.class));
                      verify(region2, times(1)).checkPoint(any(Vector1D.class));
                      
                      // Test boundary case
                      when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                      when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                      
                      // With includeEndPoints = true should return the point
                      intersection = subLine1.intersection(subLine2, true);
                      assertNotNull(intersection);
                      
                      // With includeEndPoints = false should return null
                      intersection = subLine1.intersection(subLine2, false);
                      assertNull(intersection);
                  }

    @Test
    public void testIntersectionFirstSubLineOutside() {
        // Setup test data
        Line line1 = mock(Line.class);
        Line line2 = mock(Line.class);
        IntervalsSet region1 = mock(IntervalsSet.class);
        IntervalsSet region2 = mock(IntervalsSet.class);
        Vector3D intersectionPoint = new Vector3D(1, 1, 1);
        
        // Create sublines
        SubLine subLine1 = new SubLine(line1, region1);
        SubLine subLine2 = new SubLine(line2, region2);
        
        // Mock behavior
        when(line1.intersection(line2)).thenReturn(intersectionPoint);
        when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
        when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
        when(region1.checkPoint(any(Vector1D.class)))
            .thenReturn(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE);
        when(region2.checkPoint(any(Vector1D.class)))
            .thenReturn(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE);
        
        // Test both includeEndPoints cases
        assertNull("Should return null when first sub-line is OUTSIDE (includeEndPoints=true)", 
                   subLine1.intersection(subLine2, true));
        assertNull("Should return null when first sub-line is OUTSIDE (includeEndPoints=false)", 
                   subLine1.intersection(subLine2, false));
        
        // Verify the first sub-line check was performed
        verify(region1).checkPoint(any(Vector1D.class));
    }


}
