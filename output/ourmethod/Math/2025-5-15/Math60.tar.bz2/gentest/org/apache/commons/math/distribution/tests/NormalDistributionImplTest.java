package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Erf;
import org.apache.commons.math.util.FastMath;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                 public void testDefaultConstructor() {
                                                                                                                     NormalDistributionImpl defaultDist = new NormalDistributionImpl();
                                                                                                                     assertEquals(0.0, defaultDist.getMean(), 0.0001);
                                                                                                                     assertEquals(1.0, defaultDist.getStandardDeviation(), 0.0001);
                                                                                                                 }

    @Test
                                                                 public void testCumulativeProbability_ValueFarBelowMean() throws org.apache.commons.math.MathException {
                                                                     // More than 40 standard deviations below mean
                                                                     double mean = 0.0;
                                                                     double standardDeviation = 1.0;
                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                                                     double x = mean - 41 * standardDeviation;
                                                                     double result = distribution.cumulativeProbability(x);
                                                                     assertEquals(0.0, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testCumulativeProbability_ValueFarAboveMean() throws org.apache.commons.math.MathException {
                                                                     // More than 40 standard deviations above mean
                                                                     double mean = 0.0;
                                                                     double standardDeviation = 1.0;
                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                                                     double x = mean + 41 * standardDeviation;
                                                                     double result = distribution.cumulativeProbability(x);
                                                                     assertEquals(1.0, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testCumulativeProbability_ValueAtMean() throws org.apache.commons.math.MathException {
                                                                     double mean = 0.0; // Default mean for normal distribution
                                                                     double standardDeviation = 1.0; // Default standard deviation
                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                                                     double x = mean;
                                                                     double result = distribution.cumulativeProbability(x);
                                                                     // Should be exactly 0.5 at the mean
                                                                     assertEquals(0.5, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testCumulativeProbability_ValueOneStdDevBelowMean() throws org.apache.commons.math.MathException {
                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl(0, 1);
                                                                     double mean = distribution.getMean();
                                                                     double std = distribution.getStandardDeviation();
                                                                     double x = mean - std;
                                                                     double result = distribution.cumulativeProbability(x);
                                                                     // Should be approximately 0.158655 for standard normal
                                                                     assertEquals(0.158655, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testCumulativeProbability_ValueOneStdDevAboveMean() throws org.apache.commons.math.MathException {
                                                                     double mean = 0.0;
                                                                     double standardDeviation = 1.0;
                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                                                     double x = mean + standardDeviation;
                                                                     double result = distribution.cumulativeProbability(x);
                                                                     // Should be approximately 0.841345 for standard normal
                                                                     assertEquals(0.841345, result, 0.0001);
                                                                 }

    @Test
                                                                 public void testCumulativeProbability_ValueNearThreshold() throws MathException {
                                                                     // Create a standard normal distribution (mean=0, std=1)
                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl(0, 1);
                                                                     double mean = distribution.getMean();
                                                                     double std = distribution.getStandardDeviation();
                                                                     
                                                                     // Just below 40 standard deviations
                                                                     double x = mean + 39 * std;
                                                                     double result = distribution.cumulativeProbability(x);
                                                                     // Should be very close to 1 but not exactly 1
                                                                     assertTrue(result > 0.999999 && result < 1.0);
                                                                     
                                                                     // Just above -40 standard deviations
                                                                     x = mean - 39 * std;
                                                                     result = distribution.cumulativeProbability(x);
                                                                     // Should be very close to 0 but not exactly 0
                                                                     assertTrue(result > 0.0 && result < 0.000001);
                                                                 }

    @Test
                        public void testCumulativeProbabilityDetectsDeviationCalculationMutant() throws MathException {
                            // Setup with mean=5 (non-zero to expose the mutant)
                            double mean = 5.0;
                            double sd = 1.0;
                            NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                            
                            // Test case 1: x equals mean (should be ~0.5 probability)
                            double x1 = mean;
                            double expected1 = 0.5;
                            double result1 = dist.cumulativeProbability(x1);
                            assertEquals("Probability at mean should be 0.5", 
                                         expected1, result1, 0.0001);
                            
                            // Test case 2: x below mean (should be <0.5 probability)
                            double x2 = mean - sd; // 1 standard deviation below
                            double expected2 = 0.15865525393145707; // known value for -1 sd
                            double result2 = dist.cumulativeProbability(x2);
                            assertEquals("Probability below mean should match expected", 
                                         expected2, result2, 0.0001);
                            
                            // Test case 3: x above mean (should be >0.5 probability)
                            double x3 = mean + sd; // 1 standard deviation above
                            double expected3 = 0.8413447460685429; // known value for +1 sd
                            double result3 = dist.cumulativeProbability(x3);
                            assertEquals("Probability above mean should match expected", 
                                         expected3, result3, 0.0001);
                            
                            // Test case 4: extreme low value (should return 0)
                            double x4 = mean - 41 * sd; // 41 sd below mean
                            double expected4 = 0.0;
                            double result4 = dist.cumulativeProbability(x4);
                            assertEquals("Extreme low value should return 0", 
                                         expected4, result4, 0.0);
                            
                            // Test case 5: extreme high value (should return 1)
                            double x5 = mean + 41 * sd; // 41 sd above mean
                            double expected5 = 1.0;
                            double result5 = dist.cumulativeProbability(x5);
                            assertEquals("Extreme high value should return 1", 
                                         expected5, result5, 0.0);
                        }

    @Test
                   public void testCumulativeProbabilityAt40StandardDeviations() throws Exception {
                       // Setup - create distribution with mean 0 and standard deviation 1
                       double mean = 0.0;
                       double standardDeviation = 1.0;
                       NormalDistribution distribution = new NormalDistributionImpl(mean, standardDeviation);
                       
                       // Test exactly 40 standard deviations above mean
                       double x = mean + 40 * standardDeviation;
                       double result = distribution.cumulativeProbability(x);
                       
                       // Verify it didn't return 1.0 directly (which mutant would do)
                       // The actual value should be very close to 1.0 but not exactly 1.0
                       assertTrue(result < 1.0);
                       assertTrue(result > 0.999999999); // Should be extremely close to 1
                       
                       // Test exactly 40 standard deviations below mean
                       x = mean - 40 * standardDeviation;
                       result = distribution.cumulativeProbability(x);
                       
                       // Verify it didn't return 0.0 directly (which mutant would do)
                       // The actual value should be very close to 0.0 but not exactly 0.0
                       assertTrue(result > 0.0);
                       assertTrue(result < 0.000000001); // Should be extremely close to 0
                   }

    @Test
              public void testCumulativeProbabilityForLargeDeviations() throws MathException {
                  // Setup with mean=0, standard deviation=1 for simplicity
                  double mean = 0;
                  double stdDev = 1;
                  NormalDistributionImpl normalDist = new NormalDistributionImpl(mean, stdDev);
                  
                  // Test value between 30σ and 40σ (35σ)
                  double x1 = 35 * stdDev;
                  double result1 = normalDist.cumulativeProbability(x1);
                  // Original should calculate erf, mutant would return 1.0
                  assertTrue("Should calculate erf value for 35σ", result1 < 1.0);
                  
                  // Test negative value between -40σ and -30σ (-35σ)
                  double x2 = -35 * stdDev;
                  double result2 = normalDist.cumulativeProbability(x2);
                  // Original should calculate erf, mutant would return 0.0
                  assertTrue("Should calculate erf value for -35σ", result2 > 0.0);
                  
                  // Also test exactly at 40σ to verify original behavior
                  double x3 = 40 * stdDev;
                  double result3 = normalDist.cumulativeProbability(x3);
                  assertEquals("Should return 1.0 at exactly 40σ", 1.0, result3, 0.0);
                  
                  // And exactly at -40σ
                  double x4 = -40 * stdDev;
                  double result4 = normalDist.cumulativeProbability(x4);
                  assertEquals("Should return 0.0 at exactly -40σ", 0.0, result4, 0.0);
              }

    @Test
         public void testCumulativeProbabilityAtMeanWithExtremeDeviation() throws org.apache.commons.math.MathException {
             // Set mean to 0 and very small standard deviation (0.001)
             // So that x=0 (dev=0) will have |dev| = 0 > 40*0.001 = 0.04 → false
             // Need to adjust to make |dev| > 40σ true when dev=0
             // Actually, when dev=0, |dev| is never > 40σ (since σ > 0)
             // Therefore need to test case where x is very close to mean but not exactly equal
             
             // Alternative approach: test case where x is exactly mean (dev=0) with standardDeviation=0
             // But constructor prevents σ=0
             
             // Best test case: x slightly below mean (dev=-ε) vs x=mean (dev=0)
             double mean = 10.0;
             double tinySD = 1e-10; // Very small standard deviation
             NormalDistributionImpl dist = new NormalDistributionImpl(mean, tinySD);
             
             // Case 1: x = mean (dev=0)
             // Should go to erf calculation (since 0 not > 40σ)
             double atMean = dist.cumulativeProbability(mean);
             assertEquals(0.5, atMean, 1e-12);
             
             // Case 2: x slightly below mean (dev=-1e-9)
             // With tinySD=1e-10, |dev| = 1e-9 > 40*1e-10 = 4e-9? No, 1e-9 < 4e-9
             // Need to adjust numbers
             double xBelow = mean - 5e-9; // dev = -5e-9
             tinySD = 1e-10; // 40σ = 4e-9
             // |dev| = 5e-9 > 4e-9 → should use extreme case branch
             dist = new NormalDistributionImpl(mean, tinySD);
             double belowResult = dist.cumulativeProbability(xBelow);
             assertEquals(0.0, belowResult, 0.0); // Should be exactly 0.0
             
             // Case 3: x exactly mean would go to erf branch (not extreme)
             // Mutant would incorrectly return 0.0 for x=mean in extreme case
             // But can't create this scenario since |dev|=0 can't be >40σ
             
             // Therefore the mutation can't actually be reached in practice
             // The condition |dev| > 40σ is false when dev=0
             // Thus this is an equivalent mutation - can't be detected by any test case
             // because the mutated code path is unreachable
             
             // However, to demonstrate the principle of what we would test if it were reachable:
             // If we could have dev=0 and |dev|>40σ, we would do:
             /*
             double impossibleSD = 0.0; // Can't do this in practice
             NormalDistributionImpl impossibleDist = new NormalDistributionImpl(mean, impossibleSD);
             double impossibleResult = impossibleDist.cumulativeProbability(mean);
             assertEquals(0.5, impossibleResult, 0.0); // Would catch mutant returning 0.0
             */
         }

    @Test
    public void testCumulativeProbabilityDetectsMultiplicationMutant() throws MathException {
        // Test with small standard deviation (0.1)
        NormalDistributionImpl distSmallSD = new NormalDistributionImpl(0, 0.1);
        
        // Value that's >40*SD (4) but <40+SD (40.1)
        double x1 = 5.0;
        // Original would return 1.0 (since 5 > 4), mutant would calculate normally
        assertEquals(1.0, distSmallSD.cumulativeProbability(x1), 0.0001);
        
        // Test with large standard deviation (10)
        NormalDistributionImpl distLargeSD = new NormalDistributionImpl(0, 10);
        
        // Value that's >40+SD (50) but <40*SD (400)
        double x2 = 100.0;
        // Original would calculate normally, mutant would return 1.0 (since 100 > 50)
        assertNotEquals(1.0, distLargeSD.cumulativeProbability(x2), 0.0001);
        
        // Value that's > both boundaries
        double x3 = 500.0;
        // Both should return 1.0
        assertEquals(1.0, distLargeSD.cumulativeProbability(x3), 0.0001);
        
        // Value that's < both boundaries (negative side)
        double x4 = -500.0;
        // Both should return 0.0
        assertEquals(0.0, distLargeSD.cumulativeProbability(x4), 0.0001);
    }


}
