package gentest.org.apache.commons.math3.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.stat.inference.*;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.stat.ranking.NaNStrategy;
import org.apache.commons.math3.stat.ranking.NaturalRanking;
import org.apache.commons.math3.stat.ranking.TiesStrategy;
import org.apache.commons.math3.util.FastMath;
 
public class MannWhitneyUTestTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
        public void testCalculateAsymptoticPValue_NormalCases() throws Exception {
            MannWhitneyUTest test = new MannWhitneyUTest();
            
            // Get the private method using reflection
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            // Test case 1: Small sample sizes
            double result1 = (double) method.invoke(test, 5.0, 5, 5);
            NormalDistribution nd1 = new NormalDistribution(0, 1);
            double expectedZ1 = (5 - (5*5)/2.0) / Math.sqrt((5*5*(5+5+1))/12.0);
            double expectedP1 = 2 * nd1.cumulativeProbability(expectedZ1);
            assertEquals(expectedP1, result1, 1e-10);
            
            // Test case 2: Larger sample sizes
            double result2 = (double) method.invoke(test, 50.0, 10, 15);
            double expectedZ2 = (50 - (10*15)/2.0) / Math.sqrt((10*15*(10+15+1))/12.0);
            double expectedP2 = 2 * nd1.cumulativeProbability(expectedZ2);
            assertEquals(expectedP2, result2, 1e-10);
            
            // Test case 3: Umin equals expected value (EU)
            double result3 = (double) method.invoke(test, 12.5, 5, 5);
            assertEquals(1.0, result3, 1e-10);  // z=0, cumulativeProbability(0)=0.5, 2*0.5=1.0
        }

    @Test
        public void testCalculateAsymptoticPValue_EdgeCases() throws Exception {
            MannWhitneyUTest test = new MannWhitneyUTest();
            
            // Get the private method using reflection
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            // Test case 1: Minimum possible values (n1=1, n2=1)
            double result1 = (double) method.invoke(test, 0.0, 1, 1);
            NormalDistribution nd = new NormalDistribution(0, 1);
            double expectedZ1 = (0 - 0.5) / Math.sqrt(0.25);
            double expectedP1 = 2 * nd.cumulativeProbability(expectedZ1);
            assertEquals(expectedP1, result1, 1e-10);
            
            // Test case 2: Very large sample sizes (testing for overflow)
            double result2 = (double) method.invoke(test, 500000.0, 1000, 1000);
            double expectedZ2 = (500000 - 500000) / Math.sqrt(1000*1000*2001/12.0);
            double expectedP2 = 2 * nd.cumulativeProbability(expectedZ2);
            assertEquals(expectedP2, result2, 1e-10);
        }

    @Test
        public void testCalculateAsymptoticPValue_ExtremeUmin() throws Exception {
            MannWhitneyUTest test = new MannWhitneyUTest();
            
            // Get the private method using reflection
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            // Test case 1: Umin much smaller than EU
            double result1 = (double) method.invoke(test, 0.0, 10, 10);
            assertTrue(result1 < 0.0001);  // Should be very small p-value
            
            // Test case 2: Umin much larger than EU
            double result2 = (double) method.invoke(test, 100.0, 10, 10);
            assertTrue(result2 < 0.0001);  // Should be very small p-value
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCalculateAsymptoticPValue_InvalidN() {
            MannWhitneyUTest test = new MannWhitneyUTest();
            // Create invalid samples that would lead to n2=0 when processed
            double[] x = new double[]{1.0, 2.0, 3.0};
            double[] y = new double[]{}; // empty array
            test.mannWhitneyUTest(x, y); // This should throw IllegalArgumentException
        }

    @Test(expected = IllegalArgumentException.class)
        public void testCalculateAsymptoticPValue_InvalidN1() {
            MannWhitneyUTest test = new MannWhitneyUTest();
            // Test with invalid input that would trigger the private method
            // This will test the private method indirectly through public API
            test.mannWhitneyUTest(new double[]{1.0, 2.0}, new double[0]);
        }

    @Test
        public void testCalculateAsymptoticPValue_NegativeUmin() throws Exception {
            MannWhitneyUTest test = new MannWhitneyUTest();
            
            // Use reflection to access private method
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            // Invoke the method with test parameters
            method.invoke(test, -1.0, 5, 5);
        }

    @Test
    public void testCalculateAsymptoticPValue_Parameterized() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        double Umin = 10.0;  // test U statistic value
        int n1 = 5;         // size of first sample
        int n2 = 7;         // size of second sample
        double expected = 0.0287202;  // expected p-value for these inputs
        
        // Use reflection to access private method
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        double result = (double) method.invoke(test, Umin, n1, n2);
        
        assertEquals(expected, result, 1e-6);
    }


}
