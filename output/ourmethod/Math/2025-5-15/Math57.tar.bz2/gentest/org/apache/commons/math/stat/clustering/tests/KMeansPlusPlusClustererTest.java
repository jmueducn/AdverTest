package gentest.gentest.org.apache.commons.math.stat.clustering.tests.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import gentest.org.apache.commons.math.stat.clustering.tests.*;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.junit.Assert;
import org.mockito.Mockito;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.clustering;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.Variance;
 
public class KMeansPlusPlusClustererTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                            public void testChooseInitialCenters_VerifyDistanceCalculation() throws Exception {
                                                // Define TestPoint class implementing Clusterable
                                                class TestPoint implements Clusterable<TestPoint> {
                                                    private final double x;
                                                    private final double y;
                                                    
                                                    public TestPoint(double x, double y) {
                                                        this.x = x;
                                                        this.y = y;
                                                    }
                                                    
                                                    @Override
                                                    public double distanceFrom(TestPoint other) {
                                                        double dx = x - other.x;
                                                        double dy = y - other.y;
                                                        return Math.sqrt(dx*dx + dy*dy);
                                                    }
                                                    
                                                    @Override
                                                    public boolean equals(Object obj) {
                                                        if (!(obj instanceof TestPoint)) return false;
                                                        TestPoint other = (TestPoint) obj;
                                                        return x == other.x && y == other.y;
                                                    }
                                                    
                                                    public double[] getPoint() {
                                                        return new double[]{x, y};
                                                    }
                                                    
                                                    @Override
                                                    public TestPoint centroidOf(Collection<TestPoint> points) {
                                                        double sumX = 0;
                                                        double sumY = 0;
                                                        for (TestPoint p : points) {
                                                            sumX += p.x;
                                                            sumY += p.y;
                                                        }
                                                        return new TestPoint(sumX / points.size(), sumY / points.size());
                                                    }
                                                }
                                                
                                                // Setup test data with predictable random behavior
                                                Random mockRandom = mock(Random.class);
                                                when(mockRandom.nextInt(anyInt())).thenReturn(0); // Pick first element first
                                                when(mockRandom.nextDouble()).thenReturn(0.999); // High value to pick last remaining point
                                                
                                                List<TestPoint> points = new ArrayList<>();
                                                TestPoint p1 = new TestPoint(0.0, 0.0); // Origin
                                                TestPoint p2 = new TestPoint(3.0, 4.0); // Distance 5 from origin
                                                TestPoint p3 = new TestPoint(6.0, 8.0); // Distance 10 from origin
                                                points.add(p1);
                                                points.add(p2);
                                                points.add(p3);
                                                
                                                // Create clusterer instance
                                                @SuppressWarnings("unchecked")
                                                KMeansPlusPlusClusterer<TestPoint> clusterer = new KMeansPlusPlusClusterer<>(mockRandom);
                                                
                                                // Use reflection to access private chooseInitialCenters method
                                                Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                    "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                chooseInitialCenters.setAccessible(true);
                                                
                                                @SuppressWarnings("unchecked")
                                                List<Cluster<TestPoint>> clusters = (List<Cluster<TestPoint>>) 
                                                    chooseInitialCenters.invoke(clusterer, points, 2, mockRandom);
                                                
                                                // First center should be p1 (mocked to pick first)
                                                assertEquals(p1, clusters.get(0).getCenter());
                                                
                                                // Second center should be p3 because it has largest distance squared (100 vs 25)
                                                assertEquals(p3, clusters.get(1).getCenter());
                                            }

    @Test
                                    public void testChooseInitialCenters_KEqualsZero() throws Exception {
                                        // Define TestPoint class implementing Clusterable interface correctly
                                        class TestPoint implements Clusterable<TestPoint> {
                                            private final double[] point;
                                            
                                            public TestPoint(double x, double y) {
                                                this.point = new double[] {x, y};
                                            }
                                            
                                            public double[] getPoint() {
                                                return point;
                                            }
                                            
                                            @Override
                                            public TestPoint centroidOf(Collection<TestPoint> points) {
                                                return new TestPoint(0, 0);
                                            }
                                            
                                            @Override
                                            public double distanceFrom(TestPoint other) {
                                                double dx = point[0] - other.point[0];
                                                double dy = point[1] - other.point[1];
                                                return Math.sqrt(dx * dx + dy * dy);
                                            }
                                        }
                                        
                                        // Create test points
                                        Collection<TestPoint> points = new ArrayList<>();
                                        points.add(new TestPoint(1, 1));
                                        points.add(new TestPoint(2, 2));
                                        
                                        Random mockRandom = new Random();
                                        
                                        // Use reflection to access private method
                                        Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                            "chooseInitialCenters", Collection.class, int.class, Random.class);
                                        method.setAccessible(true);
                                        List<?> result = (List<?>) method.invoke(null, points, 0, mockRandom);
                                        
                                        // Verify the result is empty when k=0
                                        assertEquals(0, result.size());
                                    }

    @Test
                                    public void testChooseInitialCenters_VerifyRandomSelection() throws Exception {
                                        // Define simple TestPoint class for testing
                                        class TestPoint {
                                            private final double x;
                                            private final double y;
                                            
                                            public TestPoint(double x, double y) {
                                                this.x = x;
                                                this.y = y;
                                            }
                                            
                                            public double distanceFrom(TestPoint other) {
                                                return Math.sqrt(Math.pow(x - other.x, 2) + Math.pow(y - other.y, 2));
                                            }
                                            
                                            public double[] getPoint() {
                                                return new double[]{x, y};
                                            }
                                            
                                            public TestPoint centroidOf(java.util.Collection<TestPoint> points) {
                                                double sumX = 0;
                                                double sumY = 0;
                                                for (TestPoint p : points) {
                                                    double[] point = p.getPoint();
                                                    sumX += point[0];
                                                    sumY += point[1];
                                                }
                                                return new TestPoint(sumX / points.size(), sumY / points.size());
                                            }
                                            
                                            @Override
                                            public boolean equals(Object obj) {
                                                if (this == obj) return true;
                                                if (!(obj instanceof TestPoint)) return false;
                                                TestPoint other = (TestPoint) obj;
                                                return Double.compare(x, other.x) == 0 && Double.compare(y, other.y) == 0;
                                            }
                                            
                                            @Override
                                            public int hashCode() {
                                                return java.util.Objects.hash(x, y);
                                            }
                                        }
                                        
                                        // Setup test data with predictable random behavior
                                        java.util.List<TestPoint> points = new java.util.ArrayList<>();
                                        TestPoint p1 = new TestPoint(1.0, 1.0);
                                        TestPoint p2 = new TestPoint(2.0, 2.0);
                                        TestPoint p3 = new TestPoint(3.0, 3.0);
                                        points.add(p1);
                                        points.add(p2);
                                        points.add(p3);
                                        
                                        // Mock Random to return predictable values
                                        java.util.Random mockRandom = new java.util.Random() {
                                            @Override
                                            public int nextInt(int bound) {
                                                return 1; // Always return 1 for predictable test
                                            }
                                        };
                                        
                                        // Use reflection to access private method
                                        java.lang.reflect.Method chooseInitialCenters = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                            .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                        chooseInitialCenters.setAccessible(true);
                                        
                                        // Execute using the static method with raw type
                                        @SuppressWarnings("unchecked")
                                        java.util.List<org.apache.commons.math.stat.clustering.Cluster> clusters = 
                                            (java.util.List<org.apache.commons.math.stat.clustering.Cluster>) 
                                            chooseInitialCenters.invoke(null, points, 2, mockRandom);
                                        
                                        // Verify first center is p2 (since we mocked nextInt to return 1)
                                        assertEquals(p2, clusters.get(0).getCenter());
                                        
                                        // Verify second center is either p1 or p3 based on our mock
                                        assertTrue(clusters.get(1).getCenter().equals(p1) || clusters.get(1).getCenter().equals(p3));
                                    }

    @Test
                                public void testChooseInitialCenters_KGreaterThanPointsSize() throws Exception {
                                    // Define a simple TestPoint class for testing that implements Clusterable
                                    class TestPoint implements Clusterable<TestPoint> {
                                        private final double[] points;
                                        
                                        public TestPoint(double x, double y) {
                                            this.points = new double[]{x, y};
                                        }
                                        
                                        public double[] getPoint() {
                                            return points;
                                        }
                                    
                                        @Override
                                        public TestPoint centroidOf(Collection<TestPoint> points) {
                                            double x = 0, y = 0;
                                            for (TestPoint p : points) {
                                                x += p.getPoint()[0];
                                                y += p.getPoint()[1];
                                            }
                                            return new TestPoint(x / points.size(), y / points.size());
                                        }
                                
                                        @Override
                                        public double distanceFrom(TestPoint p) {
                                            double dx = points[0] - p.points[0];
                                            double dy = points[1] - p.points[1];
                                            return Math.sqrt(dx * dx + dy * dy);
                                        }
                                    }
                                    
                                    // Mock dependencies
                                    Random mockRandom = mock(Random.class);
                                    
                                    // Prepare test data
                                    Collection<TestPoint> points = new ArrayList<>();
                                    points.add(new TestPoint(1.0, 1.0));  // Only one point
                                    
                                    // Create clusterer instance
                                    KMeansPlusPlusClusterer<TestPoint> clusterer = new KMeansPlusPlusClusterer<>(mockRandom);
                                    
                                    // Get the private method using reflection
                                    Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                        "chooseInitialCenters", Collection.class, int.class, Random.class);
                                    chooseInitialCenters.setAccessible(true);
                                    
                                    // Expect exception when k > points size
                                    try {
                                        chooseInitialCenters.invoke(clusterer, points, 2, mockRandom);
                                        fail("Expected IllegalArgumentException");
                                    } catch (InvocationTargetException e) {
                                        assertEquals(IllegalArgumentException.class, e.getCause().getClass());
                                    }
                                }

    @Test
                public void testChooseInitialCenters_EmptyPointsCollection() throws Exception {
                    // Define a simple point class for testing that implements Clusterable
                    class TestPoint implements Clusterable<TestPoint> {
                        private final double[] values;
                        public TestPoint(double[] values) { this.values = values; }
                        public double[] getPoint() { return values; }
                        public TestPoint centroidOf(Collection<TestPoint> points) {
                            double[] centroid = new double[values.length];
                            for (TestPoint p : points) {
                                double[] point = p.getPoint();
                                for (int i = 0; i < centroid.length; i++) {
                                    centroid[i] += point[i];
                                }
                            }
                            for (int i = 0; i < centroid.length; i++) {
                                centroid[i] /= points.size();
                            }
                            return new TestPoint(centroid);
                        }
                        public double distanceFrom(TestPoint p) {
                            double sum = 0;
                            double[] otherPoint = p.getPoint();
                            for (int i = 0; i < values.length; i++) {
                                double diff = values[i] - otherPoint[i];
                                sum += diff * diff;
                            }
                            return Math.sqrt(sum);
                        }
                    }
                    
                    Random mockRandom = mock(Random.class);
                    @SuppressWarnings("unchecked")
                    KMeansPlusPlusClusterer<TestPoint> clusterer = new KMeansPlusPlusClusterer<TestPoint>(mockRandom);
                    
                    // Use reflection to access the private static method
                    Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                        "chooseInitialCenters", Collection.class, int.class, Random.class);
                    chooseInitialCenters.setAccessible(true);
                    
                    // Create empty list with proper generic type
                    Collection<TestPoint> emptyList = new ArrayList<TestPoint>();
                    
                    // Invoke the method with empty list
                    @SuppressWarnings("unchecked")
                    List<Cluster<TestPoint>> result = (List<Cluster<TestPoint>>) 
                        chooseInitialCenters.invoke(clusterer, emptyList, 1, mockRandom);
                    
                    // Verify the result is empty
                    assertTrue(result.isEmpty());
                }

}
