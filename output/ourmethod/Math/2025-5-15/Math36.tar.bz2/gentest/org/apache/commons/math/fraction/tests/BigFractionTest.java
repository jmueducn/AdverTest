package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.ArithmeticUtils;
 
public class BigFractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                            public void testDoubleValue_NormalFractions() {
                                                // Test simple fractions
                                                BigFraction half = new BigFraction(1, 2);
                                                assertEquals(0.5, half.doubleValue(), 0.0);
                                        
                                                BigFraction third = new BigFraction(1, 3);
                                                assertEquals(0.3333333333333333, third.doubleValue(), 0.0);
                                        
                                                BigFraction negative = new BigFraction(-3, 4);
                                                assertEquals(-0.75, negative.doubleValue(), 0.0);
                                        
                                                // Test whole numbers
                                                BigFraction five = new BigFraction(5, 1);
                                                assertEquals(5.0, five.doubleValue(), 0.0);
                                        
                                                // Test zero
                                                BigFraction zero = new BigFraction(0, 1);
                                                assertEquals(0.0, zero.doubleValue(), 0.0);
                                            }

 @Test
                                            public void testDoubleValue_LargeNumbers() {
                                                // Test with numbers that are large but still fit in double range
                                                BigFraction large = new BigFraction(1234567890L, 987654321L);
                                                assertEquals(1.25000001125, large.doubleValue(), 0.00000000001);
                                        
                                                // Test with very large numbers that require shifting
                                                BigInteger hugeNum = BigInteger.TEN.pow(1000);
                                                BigInteger hugeDen = BigInteger.TEN.pow(999);
                                                BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                                assertEquals(10.0, hugeFraction.doubleValue(), 0.0);
                                            }

 @Test
                                            public void testDoubleValue_ExtremeNumbers() {
                                                // Test with extremely large numbers that would normally overflow
                                                BigInteger maxLong = BigInteger.valueOf(Long.MAX_VALUE);
                                                BigFraction atLimit = new BigFraction(maxLong.multiply(maxLong), maxLong);
                                                assertEquals(Long.MAX_VALUE, atLimit.doubleValue(), 0.0);
                                        
                                                // Test with numbers beyond Double.MAX_VALUE
                                                BigInteger beyondDouble = BigInteger.TEN.pow(400);
                                                BigFraction beyondFraction = new BigFraction(beyondDouble, BigInteger.ONE);
                                                assertEquals(Double.POSITIVE_INFINITY, beyondFraction.doubleValue(), 0.0);
                                        
                                                BigInteger tinyDenominator = BigInteger.TEN.pow(400);
                                                BigFraction tinyFraction = new BigFraction(BigInteger.ONE, tinyDenominator);
                                                assertEquals(0.0, tinyFraction.doubleValue(), 0.0);
                                            }

 @Test
                                            public void testDoubleValue_EdgeCases() {
                                                // Test with numerator = 0
                                                BigFraction zeroNumerator = new BigFraction(0, 12345);
                                                assertEquals(0.0, zeroNumerator.doubleValue(), 0.0);
                                        
                                                // Test with denominator = 1
                                                BigFraction denomOne = new BigFraction(42, 1);
                                                assertEquals(42.0, denomOne.doubleValue(), 0.0);
                                        
                                                // Test with equal numerator and denominator
                                                BigFraction equalParts = new BigFraction(7, 7);
                                                assertEquals(1.0, equalParts.doubleValue(), 0.0);
                                            }

 @Test
                                            public void testDoubleValue_Constants() {
                                                // Test class constants
                                                assertEquals(1.0, BigFraction.ONE.doubleValue(), 0.0);
                                                assertEquals(0.0, BigFraction.ZERO.doubleValue(), 0.0);
                                                assertEquals(-1.0, BigFraction.MINUS_ONE.doubleValue(), 0.0);
                                                assertEquals(0.5, BigFraction.ONE_HALF.doubleValue(), 0.0);
                                                assertEquals(0.25, BigFraction.ONE_QUARTER.doubleValue(), 0.0);
                                                assertEquals(0.3333333333333333, BigFraction.ONE_THIRD.doubleValue(), 0.0);
                                            }

 @Test
                                            public void testDoubleValue_ReducedFractions() {
                                                // Test fractions that should be reduced
                                                BigFraction reducible = new BigFraction(2, 4);
                                                assertEquals(0.5, reducible.doubleValue(), 0.0);
                                        
                                                BigFraction largeReducible = new BigFraction(123456, 987648);
                                                assertEquals(0.12500025396825396, largeReducible.doubleValue(), 0.00000000000001);
                                            }

 @Test
                                            public void testFloatValue_NormalFractions() {
                                                // Test simple fractions that fit within float range
                                                BigFraction half = new BigFraction(1, 2);
                                                assertEquals(0.5f, half.floatValue(), 0.000001f);
                                        
                                                BigFraction third = new BigFraction(1, 3);
                                                assertEquals(0.333333f, third.floatValue(), 0.000001f);
                                        
                                                BigFraction quarter = new BigFraction(1, 4);
                                                assertEquals(0.25f, quarter.floatValue(), 0.000001f);
                                        
                                                BigFraction negative = new BigFraction(-3, 4);
                                                assertEquals(-0.75f, negative.floatValue(), 0.000001f);
                                            }

 @Test
                                            public void testFloatValue_WholeNumbers() {
                                                // Test whole number conversions
                                                BigFraction five = new BigFraction(5, 1);
                                                assertEquals(5.0f, five.floatValue(), 0.000001f);
                                        
                                                BigFraction zero = new BigFraction(0, 1);
                                                assertEquals(0.0f, zero.floatValue(), 0.000001f);
                                        
                                                BigFraction large = new BigFraction(123456789, 1);
                                                assertEquals(123456789.0f, large.floatValue(), 0.000001f);
                                            }

 @Test
                                            public void testFloatValue_LargeNumbers() {
                                                // Test numbers that would normally overflow float range
                                                BigInteger hugeNum = BigInteger.TEN.pow(50);
                                                BigInteger hugeDen = BigInteger.TEN.pow(49);
                                                
                                                // This should trigger the shift-right logic in the method
                                                BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                                assertEquals(10.0f, hugeFraction.floatValue(), 0.000001f);
                                            }

 @Test
                                            public void testFloatValue_ExtremelyLargeNumbers() {
                                                // Test with extremely large numbers that need shifting
                                                BigInteger maxNum = BigInteger.valueOf(2).pow(200);
                                                BigInteger maxDen = BigInteger.valueOf(2).pow(200);
                                                
                                                BigFraction maxFraction = new BigFraction(maxNum, maxDen);
                                                assertEquals(1.0f, maxFraction.floatValue(), 0.000001f);
                                            }

 @Test
                                            public void testFloatValue_ZeroNumerator() {
                                                // Test with zero numerator
                                                BigFraction zero = new BigFraction(0, 12345);
                                                assertEquals(0.0f, zero.floatValue(), 0.000001f);
                                            }

 @Test
                                            public void testFloatValue_EquivalentFractions() {
                                                // Test that equivalent fractions produce same float value
                                                BigFraction half1 = new BigFraction(1, 2);
                                                BigFraction half2 = new BigFraction(2, 4);
                                                BigFraction half3 = new BigFraction(50, 100);
                                                
                                                assertEquals(half1.floatValue(), half2.floatValue(), 0.000001f);
                                                assertEquals(half1.floatValue(), half3.floatValue(), 0.000001f);
                                            }

 @Test
                                            public void testFloatValue_PredefinedConstants() {
                                                // Test the predefined constants in the class
                                                assertEquals(1.0f, BigFraction.ONE.floatValue(), 0.000001f);
                                                assertEquals(0.0f, BigFraction.ZERO.floatValue(), 0.000001f);
                                                assertEquals(-1.0f, BigFraction.MINUS_ONE.floatValue(), 0.000001f);
                                                assertEquals(0.5f, BigFraction.ONE_HALF.floatValue(), 0.000001f);
                                                assertEquals(0.25f, BigFraction.ONE_QUARTER.floatValue(), 0.000001f);
                                            }

 @Test
                                    public void testFloatValue_EdgeCases() {
                                        // Test edge cases and boundary conditions
                                        BigFraction minValue = new BigFraction(1, Integer.MAX_VALUE);
                                        assertEquals(1.0f/Integer.MAX_VALUE, minValue.floatValue(), 0.000001f);
                                        
                                        BigFraction maxRatio = new BigFraction(Float.MAX_VALUE, 1);
                                        assertEquals(Float.MAX_VALUE, maxRatio.floatValue(), 0.000001f);
                                        
                                        // Use long constructor since Float.MAX_VALUE is too large for int
                                        BigFraction minRatio = new BigFraction(1L, (long)Float.MAX_VALUE);
                                        assertEquals(1.0f/Float.MAX_VALUE, minRatio.floatValue(), 0.000001f);
                                    }

 @Test
                                    public void testFloatValueWithLargeNumbers() {
                                        // Create numerator and denominator that are too large for direct float division
                                        BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                                        BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                                        
                                        BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                        
                                        // The original implementation should return a finite float value
                                        // because it will detect NaN and perform shifting
                                        float result = fraction.floatValue();
                                        
                                        // Assert that the result is a finite number (not NaN)
                                        assertFalse("Result should not be NaN", Float.isNaN(result));
                                        
                                        // Additionally verify the result is within expected float range
                                        assertTrue("Result should be finite", Float.isFinite(result));
                                        assertTrue("Result should be between 0 and 1", result > 0 && result < 1);
                                    }

 @Test
                                   public void testFloatValueWithLargeNumbers1() {
                                       // Create numerator and denominator that are too large for float representation
                                       // Using values that will overflow float but not be infinite
                                       BigInteger hugeNum = new BigInteger("123456789012345678901234567890");
                                       BigInteger hugeDen = new BigInteger("98765432109876543210987654321");
                                       
                                       BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                       
                                       // Original behavior: Should handle overflow by shifting and return finite value
                                       // Mutant behavior: Will return NaN because it doesn't handle overflow case
                                       float result = fraction.floatValue();
                                       
                                       // Verify result is finite (not NaN and not infinite)
                                       assertFalse("Result should not be NaN", Float.isNaN(result));
                                       assertFalse("Result should not be infinite", Float.isInfinite(result));
                                       
                                       // Additional check that the value is approximately correct
                                       // We know exact division would be ~1.25, so verify it's close
                                       assertEquals(1.25f, result, 0.01f);
                                   }

 @Test
                                  public void testFloatValueWithNormalNumbers() {
                                      // Create a fraction with normal numbers that should produce finite result
                                      BigFraction fraction = new BigFraction(1, 3);
                                      
                                      float result = fraction.floatValue();
                                      
                                      // Verify the result is finite and correct
                                      assertFalse("Result should be finite (not NaN)", Float.isNaN(result));
                                      assertTrue("Result should be finite", Float.isFinite(result));
                                      
                                      // The mutant would unnecessarily run the adjustment code for finite results
                                      // We can verify the adjustment wasn't needed by checking the value is correct
                                      assertEquals(1f/3f, result, 0.0001f);
                                  }

 @Test
                             public void testFloatValueWithLargeNumbers2() {
                                 // Create a fraction with very large numbers that would cause NaN in float division
                                 StringBuilder numBuilder = new StringBuilder();
                                 StringBuilder denBuilder = new StringBuilder();
                                 for (int i = 0; i < 1000; i++) {
                                     numBuilder.append("1");
                                     denBuilder.append("2");
                                 }
                                 BigInteger hugeNum = new BigInteger(numBuilder.toString());
                                 BigInteger hugeDen = new BigInteger(denBuilder.toString());
                                 BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                 
                                 // The original code would adjust and return a finite value
                                 // The mutant would skip adjustment and return NaN
                                 float result = fraction.floatValue();
                                 
                                 // Verify the result is finite (adjusted properly)
                                 assertFalse("Result should be finite (not NaN)", Float.isNaN(result));
                                 assertTrue("Result should be finite", Float.isFinite(result));
                             }

 @Test
                         public void testFloatValueWithLargeNumbers3() {
                             // Create a fraction with very large numerator and denominator
                             // These values are chosen to be large enough to cause float overflow when divided directly
                             BigInteger hugeNum = new BigInteger("123456789012345678901234567890");
                             BigInteger hugeDen = new BigInteger("987654321098765432109876543210");
                             BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                             
                             // Call the method under test
                             float result = fraction.floatValue();
                             
                             // Verify the result is a valid float (not NaN)
                             // This assertion would fail with the mutant since it wouldn't perform the shift
                             assertFalse("Result should not be NaN", Float.isNaN(result));
                             
                             // Additional verification that the result is approximately correct
                             // We know that after shifting, the result should be roughly 0.125
                             assertEquals(0.125f, result, 0.001f);
                         }

 @Test
                        public void testFloatValueWithLargeNumbersOfDifferentBitLengths() {
                            // Create numbers with different bit lengths that would overflow float
                            BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890"); // ~130 bits
                            BigInteger largeDen = new BigInteger("12345678901234567890"); // ~64 bits
                            
                            // Create fraction - direct division would be NaN
                            BigFraction fraction = new BigFraction(hugeNum, largeDen);
                            
                            // Calculate expected shift using correct max() approach
                            int expectedShift = Math.max(hugeNum.bitLength(), largeDen.bitLength()) - Float.MAX_EXPONENT;
                            float expected = hugeNum.shiftRight(expectedShift).floatValue() / 
                                            largeDen.shiftRight(expectedShift).floatValue();
                            
                            // Test the actual floatValue()
                            float actual = fraction.floatValue();
                            
                            // Verify we got a valid float result (not NaN)
                            assertFalse("Result should not be NaN", Float.isNaN(actual));
                            
                            // Verify the result matches what we expect from correct scaling
                            assertEquals("Float value should match expected scaled result", 
                                        expected, actual, 0.0001f);
                            
                            // Additional check - verify the shift was sufficient by checking bit lengths
                            int actualShift = Math.max(hugeNum.bitLength(), largeDen.bitLength()) - Float.MAX_EXPONENT;
                            assertTrue("Shift should be sufficient to prevent overflow",
                                      hugeNum.shiftRight(actualShift).bitLength() <= Float.MAX_EXPONENT &&
                                      largeDen.shiftRight(actualShift).bitLength() <= Float.MAX_EXPONENT);
                        }

 @Test
                           public void testFloatValueWithLargeNumbers4() {
                               // Create numerator and denominator with bit lengths that will trigger the shift logic
                               // We need values where bitLength > Float.MAX_EXPONENT (127)
                               BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // bitLength = 201
                               BigInteger hugeDen = BigInteger.valueOf(3).pow(100);  // bitLength ~= 159
                               
                               BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                               
                               // Calculate expected value using the correct shift amount
                               int correctShift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                               float expected = hugeNum.shiftRight(correctShift).floatValue() / 
                                                hugeDen.shiftRight(correctShift).floatValue();
                               
                               // The mutant would use incorrectShift = Math.max(...) + Float.MAX_EXPONENT
                               // which would be much larger, causing either:
                               // 1. Different (incorrect) float value due to excessive shifting
                               // 2. Division by zero if shifted to zero
                               float actual = fraction.floatValue();
                               
                               // Verify the result is finite and matches expected calculation
                               assertFalse("Result should not be NaN", Float.isNaN(actual));
                               assertFalse("Result should not be infinite", Float.isInfinite(actual));
                               assertEquals("Float value should match expected calculation", 
                                           expected, actual, 0.0001f);
                           }

 @Test
                      public void testFloatValueCatchesMaxToMinExponentMutant() {
                          // Create a very large BigFraction that will require scaling
                          BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                          BigInteger hugeDen = new BigInteger("987654321098765432109876543210");
                          BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                          
                          // Calculate expected shift with correct MAX_EXPONENT
                          int maxBitLength = Math.max(hugeNum.bitLength(), hugeDen.bitLength());
                          int expectedShift = maxBitLength - Float.MAX_EXPONENT;
                          
                          // Calculate what shift the mutant would use
                          int mutantShift = maxBitLength - Float.MIN_EXPONENT; // Note: MIN_EXPONENT is negative
                          
                          // Verify the mutant would produce a different (wrong) result
                          // The mutant's shift would be (maxBitLength + 126) instead of (maxBitLength - 127)
                          assertNotEquals("Mutant shift should differ from correct shift", 
                                         expectedShift, mutantShift);
                          
                          // Get the actual float value
                          float result = fraction.floatValue();
                          
                          // Verify the result is not zero (mutant might shift too much and get zero)
                          assertNotEquals("Result should not be zero", 0.0f, result, 0.0f);
                          
                          // Verify the result is finite and reasonable
                          assertTrue("Result should be finite", Float.isFinite(result));
                          assertTrue("Result should be positive", result > 0.0f);
                          
                          // Verify the result matches manual calculation with correct shift
                          BigInteger shiftedNum = hugeNum.shiftRight(expectedShift);
                          BigInteger shiftedDen = hugeDen.shiftRight(expectedShift);
                          float expected = shiftedNum.floatValue() / shiftedDen.floatValue();
                          assertEquals("Result should match manual calculation", 
                                      expected, result, Math.ulp(expected));
                      }

 @Test
                         public void testFloatValueWithLargeNumbers5() {
                             // Create numbers large enough to trigger the NaN case
                             BigInteger hugeNum = BigInteger.TEN.pow(1000);
                             BigInteger hugeDen = BigInteger.TEN.pow(999);
                             
                             // Create fraction - this will need to use scaling
                             BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                             
                             // Calculate expected shift (original behavior)
                             int expectedShift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                             BigInteger scaledNum = hugeNum.shiftRight(expectedShift);
                             BigInteger scaledDen = hugeDen.shiftRight(expectedShift);
                             float expected = scaledNum.floatValue() / scaledDen.floatValue();
                             
                             // Test the actual value
                             float actual = fraction.floatValue();
                             
                             // The mutant would produce either:
                             // 1. A completely different value (due to wrong shift)
                             // 2. 0.0 (if shifted all bits out)
                             // 3. Infinity (if shift was negative due to overflow)
                             assertEquals("Float value should be properly scaled", expected, actual, 0.0001f);
                             
                             // Additional check that result is finite and non-zero
                             assertFalse("Result should be finite", Float.isInfinite(actual));
                             assertFalse("Result should not be zero", actual == 0.0f);
                             assertFalse("Result should not be NaN", Float.isNaN(actual));
                         }

 @Test
                        public void testFloatValueWithLargeNumbers6() {
                            // Create numbers large enough to cause NaN in initial division
                            BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
                            BigInteger hugeDen = BigInteger.valueOf(3).pow(200);  // 3^200
                            
                            // Create BigFraction with these values
                            BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                            
                            // Calculate expected value by doing the division with scaled-down values
                            int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                            float expected = hugeNum.shiftRight(shift).floatValue() / 
                                             hugeDen.shiftRight(shift).floatValue();
                            
                            // The mutant would multiply instead of divide, so we can verify:
                            float actual = fraction.floatValue();
                            
                            // Assert the result is the expected division result (not multiplication)
                            assertEquals(expected, actual, 0.0001f);
                            
                            // Additional check to ensure we're not getting the multiplication result
                            float wrongResult = hugeNum.shiftRight(shift).floatValue() * 
                                              hugeDen.shiftRight(shift).floatValue();
                            assertNotEquals(wrongResult, actual, 0.0001f);
                        }

 @Test
                       public void testFloatValueWithLargeNumbersDetectsDivisionMutant() {
                           // Create numbers large enough to cause overflow in float division
                           BigInteger hugeNum = new BigInteger("123456789012345678901234567890");
                           BigInteger hugeDen = new BigInteger("987654321098765432109876543210");
                           
                           // Create BigFraction with these values
                           BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                           
                           // Calculate expected value by doing the division manually
                           int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                           float expected = hugeNum.shiftRight(shift).floatValue() / hugeDen.shiftRight(shift).floatValue();
                           
                           // Calculate what the mutant would produce (addition instead of division)
                           float mutantValue = hugeNum.shiftRight(shift).floatValue() + hugeDen.shiftRight(shift).floatValue();
                           
                           // Get actual value
                           float actual = fraction.floatValue();
                           
                           // Verify the actual value matches the expected division result
                           // and does NOT match what the mutant would produce
                           assertEquals(expected, actual, 0.0001f);
                           assertNotEquals(mutantValue, actual, 0.0001f);
                       }

 @Test
                  public void testFloatValueWithLargeNumbers7() {
                      // Create numbers that will overflow float division but work when shifted
                      BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
                      BigInteger hugeDen = BigInteger.valueOf(3).pow(200);  // 3^200
                      
                      BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                      
                      // Calculate expected result using the shift approach
                      int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                      float expected = hugeNum.shiftRight(shift).floatValue() / hugeDen.shiftRight(shift).floatValue();
                      
                      // The actual result should match our expected calculation
                      float actual = fraction.floatValue();
                      
                      // This will catch the mutant because:
                      // Original code: returns expected division result (~0.0)
                      // Mutant code: returns subtraction result (hugeNum - hugeDen = NaN)
                      assertEquals(expected, actual, 0.0001f);
                      
                      // Additional check to ensure we're testing the NaN case
                      assertFalse(Float.isNaN(actual));
                  }

 @Test
                 public void testFloatValueWithLargeNumbers8() {
                     // Create numbers that are too large for float (will produce NaN initially)
                     BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                     BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                     
                     // Create BigFraction with these numbers
                     BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                     
                     // Calculate expected value by manually doing what the original code should do
                     int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                     float expected = hugeNum.shiftRight(shift).floatValue() / 
                                     hugeDen.shiftRight(shift).floatValue();
                     
                     // Calculate actual value
                     float actual = fraction.floatValue();
                     
                     // The mutant would use denominator.shiftRight() for both numerator and denominator
                     // So calculate what the mutant would produce
                     float mutantResult = hugeDen.shiftRight(shift).floatValue() / 
                                         hugeDen.shiftRight(shift).floatValue();
                     
                     // Verify actual matches expected (not mutant result)
                     assertEquals(expected, actual, 0.0001f);
                     
                     // Additional assertion to explicitly show the mutant would fail
                     assertNotEquals(mutantResult, actual, 0.0001f);
                 }

 @Test
                public void testFloatValueWithLargeNumbers9() {
                    // Create very large numbers that will overflow float without scaling
                    BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
                    BigInteger hugeDen = BigInteger.valueOf(3).pow(100);  // 3^100
                    
                    BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                    
                    // Calculate expected value by scaling both numbers down
                    int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                    BigInteger scaledNum = hugeNum.shiftRight(shift);
                    BigInteger scaledDen = hugeDen.shiftRight(shift);
                    float expected = scaledNum.floatValue() / scaledDen.floatValue();
                    
                    // The mutant would shiftLeft the denominator, making it even larger
                    // resulting in either incorrect value or infinity
                    float actual = fraction.floatValue();
                    
                    // Verify the result is finite and correct
                    assertFalse("Result should not be NaN", Float.isNaN(actual));
                    assertFalse("Result should not be infinite", Float.isInfinite(actual));
                    assertEquals("Scaled float value incorrect", expected, actual, 0.0001f);
                }

 @Test
              public void testFloatValueWithLargeNumbersDetectsShiftRightMutant() {
                  // Create very large numbers that will cause initial division to be NaN
                  BigInteger hugeNum = BigInteger.TEN.pow(1000); // 10^1000
                  BigInteger hugeDen = BigInteger.TEN.pow(1000).multiply(BigInteger.valueOf(2)); // 2*10^1000
                  
                  BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                  
                  // Calculate expected value by manually doing what original method should do
                  int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                  float expected = hugeNum.shiftRight(shift).floatValue() / 
                                  hugeDen.shiftRight(shift).floatValue();
                  
                  // The mutated version would do: hugeNum.shiftRight(shift) / hugeDen (no shift)
                  // which would be much smaller than expected
                  
                  float actual = fraction.floatValue();
                  
                  // Assert the result matches the properly scaled value
                  assertEquals(expected, actual, 0.0001f);
                  
                  // Additional check that we're not getting the mutated behavior
                  float mutatedVersion = hugeNum.shiftRight(shift).floatValue() / hugeDen.floatValue();
                  assertNotEquals(mutatedVersion, actual, 0.0001f);
              }

 @Test
          public void testFloatValueWithLargeNumbers10() {
              // Create numerator and denominator that are too large for direct float conversion
              BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
              BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
              
              BigFraction fraction = new BigFraction(hugeNum, hugeDen);
              
              // Calculate expected value by doing proper float conversion after shifting
              int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
              BigInteger shiftedNum = hugeNum.shiftRight(shift);
              BigInteger shiftedDen = hugeDen.shiftRight(shift);
              float expected = shiftedNum.floatValue() / shiftedDen.floatValue();
              
              // The mutant would do integer division here instead of float division
              float actual = fraction.floatValue();
              
              // Verify the result matches proper float division
              assertEquals(expected, actual, 0.0001f);
              
              // Additional verification that we're not doing integer division
              // Choose numbers where float and int division would differ
              BigInteger num = BigInteger.valueOf(3).shiftLeft(100);  // 3 * 2^100
              BigInteger den = BigInteger.valueOf(2).shiftLeft(100);  // 2 * 2^100
              BigFraction simpleFraction = new BigFraction(num, den);
              
              // Proper float division should give 1.5, int division would give 1.0
              assertEquals(1.5f, simpleFraction.floatValue(), 0.0001f);
          }

 @Test
             public void testDoubleValueWithLargeNumbersDifferentBitLengths() {
                 // Create numbers with significantly different bit lengths
                 // 2^2000 is a very large number (bit length 2001)
                 BigInteger hugeNum = BigInteger.valueOf(2).pow(2000);
                 // 2^1000 is large but half the bit length of hugeNum
                 BigInteger largeDen = BigInteger.valueOf(2).pow(1000);
                 
                 BigFraction fraction = new BigFraction(hugeNum, largeDen);
                 
                 // With original code (Math.max), this should work fine
                 // With mutant (Math.min), it would use shift of 1000 which isn't enough
                 // for the numerator (needs 2000 - Double.MAX_EXPONENT shift)
                 // so would still result in NaN
                 double result = fraction.doubleValue();
                 
                 // Verify we got a proper number, not NaN
                 assertFalse("Result should not be NaN", Double.isNaN(result));
                 
                 // Verify the result is approximately correct
                 // Expected value is 2^(2000-1000) = 2^1000
                 // We can't represent 2^1000 exactly as double, but can check it's finite
                 assertTrue("Result should be finite", Double.isFinite(result));
                 assertTrue("Result should be positive", result > 0);
             }

 @Test
        public void testDoubleValueWithLargeNumbersDetectsShiftRightMutant() {
            // Create numbers large enough to cause overflow in direct double conversion
            BigInteger hugeNum = BigInteger.valueOf(2).pow(Double.MAX_EXPONENT + 100);
            BigInteger hugeDen = BigInteger.valueOf(3).pow(Double.MAX_EXPONENT + 50);
            
            BigFraction fraction = new BigFraction(hugeNum, hugeDen);
            
            // Calculate expected value by manual scaling
            int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Double.MAX_EXPONENT;
            BigInteger scaledNum = hugeNum.shiftRight(shift);
            BigInteger scaledDen = hugeDen.shiftRight(shift);
            double expected = scaledNum.doubleValue() / scaledDen.doubleValue();
            
            // Test the actual value
            double actual = fraction.doubleValue();
            
            // Verify the result is finite and correct
            assertFalse("Result should not be NaN", Double.isNaN(actual));
            assertFalse("Result should not be infinite", Double.isInfinite(actual));
            assertEquals("Scaled value should match expected", expected, actual, 0.0001);
        }

 @Test
       public void testDoubleValueWithLargeNumbers() {
           // Create very large numbers that will cause initial division to be NaN
           BigInteger hugeNum = BigInteger.valueOf(2).pow(1024); // 2^1024 (larger than Double.MAX_VALUE)
           BigInteger hugeDen = BigInteger.valueOf(3).pow(1024); // 3^1024
           
           BigFraction fraction = new BigFraction(hugeNum, hugeDen);
           
           // Calculate expected value by doing proper double conversion after shifting
           int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Double.MAX_EXPONENT;
           BigInteger shiftedNum = hugeNum.shiftRight(shift);
           BigInteger shiftedDen = hugeDen.shiftRight(shift);
           double expected = shiftedNum.doubleValue() / shiftedDen.doubleValue();
           
           // The mutant would use intValue() instead, which would give different result
           double actual = fraction.doubleValue();
           
           // Verify we get the expected precise double value
           assertEquals(expected, actual, 0.0000001);
           
           // Additional verification that the result is not just an integer division
           // (which would happen with the mutant)
           assertNotEquals(shiftedNum.intValue() / shiftedDen.intValue(), actual, 0.0000001);
       }

 @Test
          public void testDoubleValueWithLargeNumbers1() {
              // Create numbers with significantly different bit lengths
              // numerator has ~1000 bits, denominator has ~10 bits
              BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890" +
                                                "1234567890123456789012345678901234567890" +
                                                "1234567890123456789012345678901234567890" +
                                                "1234567890123456789012345678901234567890" +
                                                "1234567890123456789012345678901234567890");
              BigInteger smallDen = BigInteger.valueOf(123);
              
              BigFraction fraction = new BigFraction(hugeNum, smallDen);
              
              // The original would shift by ~1000-1023 (max bit length - Double.MAX_EXPONENT)
              // The mutant would shift by ~990 (abs difference) - Double.MAX_EXPONENT
              // These would produce different results
              double result = fraction.doubleValue();
              
              // Verify the result is finite (not NaN or infinite)
              assertFalse(Double.isNaN(result));
              assertFalse(Double.isInfinite(result));
              
              // Calculate expected value using correct shift
              int correctShift = Math.max(hugeNum.bitLength(), smallDen.bitLength()) - Double.MAX_EXPONENT;
              double expected = hugeNum.shiftRight(correctShift).doubleValue() / 
                               smallDen.shiftRight(correctShift).doubleValue();
              
              // The mutant would produce a different value
              assertEquals(expected, result, 0.0);
          }

 @Test
     public void testDoubleValueWithLargeNumbers2() {
         // Create very large numbers that will trigger the shift case
         BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
         BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
         
         // Create fraction and calculate expected value using double conversion
         BigFraction fraction = new BigFraction(hugeNum, hugeDen);
         
         // Calculate what the result should be with proper double conversion
         int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Double.MAX_EXPONENT;
         double expected = hugeNum.shiftRight(shift).doubleValue() / 
                          hugeDen.shiftRight(shift).doubleValue();
         
         // Get actual value from method
         double actual = fraction.doubleValue();
         
         // Verify the result matches expected with proper precision
         assertEquals(expected, actual, 0.0000001);
         
         // Additional verification that float conversion would give different result
         double floatBasedResult = hugeNum.shiftRight(shift).floatValue() / 
                                 hugeDen.shiftRight(shift).floatValue();
         assertNotEquals(floatBasedResult, actual, 0.0000001);
     }

 @Test
        public void testDoubleValueWithLargeNumbers3() {
            // Create numbers large enough to trigger the shift case
            // Using 2^1024 as numerator and 2^1023 as denominator
            // These are just beyond Double.MAX_VALUE (which is ~1.8e308)
            BigInteger hugeNumerator = BigInteger.valueOf(2).pow(1024);
            BigInteger hugeDenominator = BigInteger.valueOf(2).pow(1023);
            
            // Create BigFraction with these values
            BigFraction fraction = new BigFraction(hugeNumerator, hugeDenominator);
            
            // Calculate expected value - should be 2.0 (2^1024 / 2^1023 = 2)
            // The shift should preserve this ratio
            double expected = 2.0;
            double actual = fraction.doubleValue();
            
            // With the original code, this should pass
            // With the mutant (shift+1), the result would be 1.0 (extra shift makes it 2^1023 / 2^1023)
            assertEquals("Double value should maintain ratio after shift", expected, actual, 0.0);
        }

 @Test
   public void testDoubleValueWithLargeNumbersOfDifferentBitLengths() {
       // Create numerator and denominator with significantly different bit lengths
       // Numerator is a very large number (bitLength > Double.MAX_EXPONENT)
       BigInteger numerator = BigInteger.valueOf(2).pow(Double.MAX_EXPONENT + 100);
       // Denominator is large but smaller than numerator (bitLength < numerator.bitLength())
       BigInteger denominator = BigInteger.valueOf(2).pow(Double.MAX_EXPONENT + 50);
       
       BigFraction fraction = new BigFraction(numerator, denominator);
       
       // The original code would use max (numerator's bitLength) and shift enough
       // The mutant would use min (denominator's bitLength) and not shift numerator enough
       double result = fraction.doubleValue();
       
       // Verify the result is finite (not NaN) - this will fail with the mutant
       assertFalse("Result should be finite", Double.isNaN(result));
       
       // Verify the result is approximately correct (should be ~2^50)
       double expected = Math.pow(2, 50);
       assertEquals(expected, result, expected * 1e-10);
   }

 @Test
  public void testDoubleValueWithLargeNumbers4() {
      // Create numbers that will overflow double representation
      BigInteger hugeNum = BigInteger.valueOf(2).pow(2000);  // 2^2000
      BigInteger hugeDen = BigInteger.valueOf(3).pow(1000);  // 3^1000
      
      // Create BigFraction instance (using constructor that takes two BigIntegers)
      BigFraction fraction = new BigFraction(hugeNum, hugeDen);
      
      // Calculate expected value after proper right shift
      int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Double.MAX_EXPONENT;
      BigInteger expectedNum = hugeNum.shiftRight(shift);
      BigInteger expectedDen = hugeDen.shiftRight(shift);
      double expected = expectedNum.doubleValue() / expectedDen.doubleValue();
      
      // Test the actual value
      double actual = fraction.doubleValue();
      
      // Verify the result is finite and correct
      assertFalse("Result should not be NaN", Double.isNaN(actual));
      assertFalse("Result should not be infinite", Double.isInfinite(actual));
      assertEquals("Result should match scaled calculation", expected, actual, 1e-10);
      
      // The mutant using shiftLeft would either:
      // 1. Return Infinity (if shifted left makes numbers too big)
      // 2. Return completely wrong value (if shifted left but still finite)
      // Our assertions will catch both cases
  }

 @Test
     public void testDoubleValueWithLargeNumbers5() {
         // Create numbers that are too large for direct double conversion
         // 2^2000 is way beyond Double.MAX_VALUE (which is ~1.8e308)
         BigInteger hugeNum = BigInteger.valueOf(2).pow(2000);
         BigInteger hugeDen = BigInteger.valueOf(3).pow(2000);
         
         BigFraction fraction = new BigFraction(hugeNum, hugeDen);
         
         double result = fraction.doubleValue();
         
         // The original code should return a finite value after shifting
         // The mutant will return NaN because it doesn't shift the numerator
         assertFalse("Result should not be NaN", Double.isNaN(result));
         assertFalse("Result should not be infinite", Double.isInfinite(result));
         
         // Verify the result is mathematically correct (approximately)
         // After shifting, it should be roughly (2/3)^2000
         // Since we shifted both numerator and denominator by the same amount,
         // the ratio should be preserved
         double expected = Math.pow(2.0/3.0, 2000);
         assertEquals(expected, result, 1e-15);
     }

}
