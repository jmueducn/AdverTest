package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                    public void testCosh_NaN() {
                                                                                                                        double nan = Double.NaN;
                                                                                                                        assertEquals(nan, FastMath.cosh(nan), 0.0);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_Zero() {
                                                                                                                        assertEquals(1.0, FastMath.cosh(0.0), 0.0);
                                                                                                                        assertEquals(1.0, FastMath.cosh(-0.0), 0.0);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_SmallPositiveValues() {
                                                                                                                        assertEquals(1.1276259652063807, FastMath.cosh(0.5), 1e-15);
                                                                                                                        assertEquals(1.5430806348152437, FastMath.cosh(1.0), 1e-15);
                                                                                                                        assertEquals(3.7621956910836314, FastMath.cosh(2.0), 1e-15);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_SmallNegativeValues() {
                                                                                                                        assertEquals(1.1276259652063807, FastMath.cosh(-0.5), 1e-15);
                                                                                                                        assertEquals(1.5430806348152437, FastMath.cosh(-1.0), 1e-15);
                                                                                                                        assertEquals(3.7621956910836314, FastMath.cosh(-2.0), 1e-15);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_LargePositiveValues() {
                                                                                                                        double x = 25.0;
                                                                                                                        double expected = 0.5 * Math.exp(x);
                                                                                                                        assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                
                                                                                                                        // Test very large value (x >= LOG_MAX_VALUE)
                                                                                                                        x = 710.0; // Just below Double.MAX_EXPONENT*Math.log(2)
                                                                                                                        double result = FastMath.cosh(x);
                                                                                                                        assertFalse(Double.isInfinite(result));
                                                                                                                        assertTrue(result > 1e300);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_LargeNegativeValues() {
                                                                                                                        double x = -25.0;
                                                                                                                        double expected = 0.5 * Math.exp(-x);
                                                                                                                        assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                
                                                                                                                        // Test very large negative value (x <= -LOG_MAX_VALUE)
                                                                                                                        x = -710.0; // Just below -Double.MAX_EXPONENT*Math.log(2)
                                                                                                                        double result = FastMath.cosh(x);
                                                                                                                        assertFalse(Double.isInfinite(result));
                                                                                                                        assertTrue(result > 1e300);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_BoundaryValues() {
                                                                                                                        double x = 20.0;
                                                                                                                        double expected = 0.5 * Math.exp(x);
                                                                                                                        assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                
                                                                                                                        x = -20.0;
                                                                                                                        expected = 0.5 * Math.exp(-x);
                                                                                                                        assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_ExtremeValues() {
                                                                                                                        // Positive infinity
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.cosh(Double.POSITIVE_INFINITY), 0.0);
                                                                                                                        
                                                                                                                        // Negative infinity
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.cosh(Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                        
                                                                                                                        // Max double value
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.cosh(Double.MAX_VALUE), 0.0);
                                                                                                                        
                                                                                                                        // Min double value (closest to zero)
                                                                                                                        assertEquals(1.0, FastMath.cosh(Double.MIN_VALUE), 0.0);
                                                                                                                    }

 @Test
                                                                                                                    public void testCosh_Precision() {
                                                                                                                        // Test values where we need high precision
                                                                                                                        double x = 1.23456789;
                                                                                                                        double expected = (Math.exp(x) + Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.cosh(x), 1e-15 * expected);
                                                                                                                
                                                                                                                        x = -5.67890123;
                                                                                                                        expected = (Math.exp(-x) + Math.exp(x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.cosh(x), 1e-15 * expected);
                                                                                                                    }

 @Test
                                                                                                                    public void testSinh_NaN() {
                                                                                                                        double nan = Double.NaN;
                                                                                                                        assertEquals(nan, FastMath.sinh(nan), 0.0);
                                                                                                                    }

 @Test
                                                                                                                    public void testSinh_Zero() {
                                                                                                                        assertEquals(0.0, FastMath.sinh(0.0), 0.0);
                                                                                                                        assertEquals(-0.0, FastMath.sinh(-0.0), 0.0);
                                                                                                                    }

 @Test
                                                                                                                    public void testSinh_SmallPositive() {
                                                                                                                        double x = 0.25;
                                                                                                                        double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                
                                                                                                                        x = 1.0;
                                                                                                                        expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                
                                                                                                                        x = 5.0;
                                                                                                                        expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                    }

 @Test
                                                                                                                    public void testSinh_SmallNegative() {
                                                                                                                        double x = -0.25;
                                                                                                                        double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                
                                                                                                                        x = -1.0;
                                                                                                                        expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                
                                                                                                                        x = -5.0;
                                                                                                                        expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                    }

 @Test
                                                                                                                    public void testSinh_BoundaryAroundQuarter() {
                                                                                                                        double x = 0.24;
                                                                                                                        double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                
                                                                                                                        x = 0.25;
                                                                                                                        expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                
                                                                                                                        x = 0.26;
                                                                                                                        expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                        assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                    }

 @Test
                                                                                                                    public void testSinh_ExtremeValues() {
                                                                                                                        // Positive infinity
                                                                                                                        double x = Double.POSITIVE_INFINITY;
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.sinh(x), 0.0);
                                                                                                                
                                                                                                                        // Negative infinity
                                                                                                                        x = Double.NEGATIVE_INFINITY;
                                                                                                                        assertEquals(Double.NEGATIVE_INFINITY, FastMath.sinh(x), 0.0);
                                                                                                                
                                                                                                                        // Max double value
                                                                                                                        x = Double.MAX_VALUE;
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.sinh(x), 0.0);
                                                                                                                
                                                                                                                        // Min double value
                                                                                                                        x = -Double.MAX_VALUE;
                                                                                                                        assertEquals(Double.NEGATIVE_INFINITY, FastMath.sinh(x), 0.0);
                                                                                                                    }

 @Test
                                                                                                                    public void testSinh_SymmetryProperty() {
                                                                                                                        double[] testValues = {0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0};
                                                                                                                        for (double x : testValues) {
                                                                                                                            assertEquals(-FastMath.sinh(x), FastMath.sinh(-x), Math.abs(FastMath.sinh(x)) * 1e-15);
                                                                                                                        }
                                                                                                                    }

 @Test
                                                                                                            public void testSinh_LargePositive() {
                                                                                                                // Regular large value
                                                                                                                double x = 20.0;
                                                                                                                double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                
                                                                                                                // Very large value (near overflow threshold)
                                                                                                                // Calculate LOG_MAX_VALUE as ln(Double.MAX_VALUE)
                                                                                                                double logMaxValue = Math.log(Double.MAX_VALUE);
                                                                                                                x = logMaxValue - 1;
                                                                                                                expected = 0.5 * Math.exp(x);
                                                                                                                assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                
                                                                                                                // Extremely large value (overflow case)
                                                                                                                x = logMaxValue + 1;
                                                                                                                double t = Math.exp(0.5 * x);
                                                                                                                expected = 0.5 * t * t;
                                                                                                                assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                            }

 @Test
                                                                                                            public void testSinh_LargeNegative() {
                                                                                                                // Regular large negative value
                                                                                                                double x = -20.0;
                                                                                                                double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                
                                                                                                                // Calculate LOG_MAX_VALUE equivalent
                                                                                                                double logMaxValue = Math.log(Double.MAX_VALUE);
                                                                                                                
                                                                                                                // Very large negative value (near overflow threshold)
                                                                                                                x = -logMaxValue + 1;
                                                                                                                expected = -0.5 * Math.exp(-x);
                                                                                                                assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                
                                                                                                                // Extremely large negative value (overflow case)
                                                                                                                x = -logMaxValue - 1;
                                                                                                                double t = Math.exp(-0.5 * x);
                                                                                                                expected = -0.5 * t * t;
                                                                                                                assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                            }

 @Test
                                                                                                       public void testSinhWithNaNInput() {
                                                                                                           // Test NaN input
                                                                                                           double input = Double.NaN;
                                                                                                           
                                                                                                           // The original method should return NaN for NaN input
                                                                                                           double result = FastMath.sinh(input);
                                                                                                           
                                                                                                           // Verify the result is NaN
                                                                                                           assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
                                                                                                           
                                                                                                           // Additional check to ensure it's not returning 0 (the mutated behavior)
                                                                                                           assertNotEquals("sinh(NaN) should not return 0", 0.0, result, 0.0);
                                                                                                       }

 @Test
                                                                                                       public void testSinhBoundaryAt() {
                                                                                                           // Test the exact boundary case where x = 20
                                                                                                           double x = 20.0;
                                                                                                           
                                                                                                           // Calculate expected value using original behavior (medium value path)
                                                                                                           // This would be the correct implementation
                                                                                                           double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                           
                                                                                                           // Call the method under test
                                                                                                           double actual = FastMath.sinh(x);
                                                                                                           
                                                                                                           // Verify the result matches the expected calculation
                                                                                                           assertEquals("sinh(20) should use medium value calculation path", 
                                                                                                                       expected, actual, 1e-10);
                                                                                                           
                                                                                                           // Additional verification that we're not using the large value approximation
                                                                                                           double largeValueApproximation = 0.5 * Math.exp(x);
                                                                                                           assertNotEquals("sinh(20) should not use large value approximation",
                                                                                                                         largeValueApproximation, actual, 1e-10);
                                                                                                       }

 @Test
                                                                                                      public void testSinhLargePositiveValueWithOverflowProtection() {
                                                                                                          // Setup
                                                                                                          double logMaxValue = 709.782712893384; // Typical LOG_MAX_VALUE
                                                                                                          double x = logMaxValue + 1; // Value that triggers the overflow protection branch
                                                                                                          
                                                                                                          // Mock the exp method to verify correct usage
                                                                                                          FastMath fastMath = spy(FastMath.class);
                                                                                                          doReturn(Math.exp(0.5 * x)).when(fastMath).exp(0.5 * x);
                                                                                                          doReturn(Math.exp(x)).when(fastMath).exp(x);
                                                                                                          
                                                                                                          // Calculate expected value using correct formula
                                                                                                          double expected = 0.5 * Math.exp(0.5 * x);
                                                                                                          expected = expected * expected;
                                                                                                          
                                                                                                          // Execute
                                                                                                          double result = fastMath.sinh(x);
                                                                                                          
                                                                                                          // Verify
                                                                                                          // The mutant would calculate exp(x) instead of exp(0.5*x), 
                                                                                                          // leading to a much larger result that might overflow
                                                                                                          assertEquals("Sinh calculation for large positive value with overflow protection", 
                                                                                                                      expected, result, 1e-10);
                                                                                                          
                                                                                                          // Verify the correct exp method was called
                                                                                                          verify(fastMath).exp(0.5 * x);
                                                                                                          verify(fastMath, never()).exp(x);
                                                                                                      }

 @Test
                                                                                                     public void testSinhLargePositiveValue() {
                                                                                                         // Setup
                                                                                                         double logMaxValue = 709.782712893384; // Typical value for LOG_MAX_VALUE
                                                                                                         double x = 710.0; // Just above LOG_MAX_VALUE
                                                                                                         
                                                                                                         // Mock the LOG_MAX_VALUE constant since it's private
                                                                                                         // In real test, we would either:
                                                                                                         // 1. Use reflection to get the actual value
                                                                                                         // 2. Or refactor to make it accessible for testing
                                                                                                         // Here we'll assume it's approximately 709.78
                                                                                                         
                                                                                                         // Calculate expected value
                                                                                                         double t = Math.exp(0.5 * x);
                                                                                                         double expected = (0.5 * t) * t; // Correct calculation
                                                                                                         double mutantValue = t * t; // Mutant calculation
                                                                                                         
                                                                                                         // Test - this will fail if the mutant is present
                                                                                                         double result = FastMath.sinh(x);
                                                                                                         
                                                                                                         // Verify the result is correct (not the mutant value)
                                                                                                         assertEquals("Sinh calculation for large positive value is incorrect", 
                                                                                                                     expected, result, 1e-10);
                                                                                                         
                                                                                                         // Additional assertion to explicitly check against mutant
                                                                                                         assertNotEquals("Test should detect the mutant", 
                                                                                                                        mutantValue, result, 1e-10);
                                                                                                     }

 @Test
                                                                                                    public void testSinhBoundaryNegative() {
                                                                                                        // Test the exact boundary case where x = -20
                                                                                                        double x = -20.0;
                                                                                                        
                                                                                                        // Expected behavior (original code):
                                                                                                        // Should use general case calculation (not the large negative case)
                                                                                                        // We can verify this by checking the result is not equal to -0.5*exp(20)
                                                                                                        
                                                                                                        // Calculate expected value using general case formula
                                                                                                        double expected = -FastMath.sinh(20.0); // sinh(-x) = -sinh(x)
                                                                                                        
                                                                                                        // Actual result
                                                                                                        double result = FastMath.sinh(x);
                                                                                                        
                                                                                                        // Verify the result matches general case calculation
                                                                                                        assertEquals("sinh(-20) should use general case calculation", 
                                                                                                                    expected, result, 1e-15);
                                                                                                        
                                                                                                        // Additional verification that it's not using the large negative case formula
                                                                                                        double largeNegCaseResult = -0.5 * FastMath.exp(20.0);
                                                                                                        assertNotEquals("sinh(-20) should not use large negative case formula",
                                                                                                                      largeNegCaseResult, result, 1e-15);
                                                                                                    }

 @Test
                                                                                                   public void testSinhWithNaNInput1() {
                                                                                                       // Test with NaN input
                                                                                                       double input = Double.NaN;
                                                                                                       
                                                                                                       // Call the method
                                                                                                       double result = FastMath.sinh(input);
                                                                                                       
                                                                                                       // Verify the result is NaN (original behavior)
                                                                                                       // This will fail if mutant returns 0 instead
                                                                                                       assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
                                                                                                   }

 @Test
                                                                                                  public void testSinhZeroInput() {
                                                                                                      // Test the boundary case of x=0
                                                                                                      double input = 0.0;
                                                                                                      double expected = 0.0;
                                                                                                      
                                                                                                      // Call the method
                                                                                                      double result = FastMath.sinh(input);
                                                                                                      
                                                                                                      // Verify the result is exactly 0.0 (not negated)
                                                                                                      assertEquals("sinh(0) should return 0.0", expected, result, 0.0);
                                                                                                      
                                                                                                      // Additional check to ensure it's not -0.0
                                                                                                      assertTrue("sinh(0) should not be negative zero", 
                                                                                                                 Double.doubleToRawLongBits(result) != Double.doubleToRawLongBits(-0.0));
                                                                                                  }

 @Test
                                                                                                 public void testSinhBoundaryAt0_() {
                                                                                                     // Test exact boundary case that would be affected by the mutation
                                                                                                     double x = 0.25;
                                                                                                     
                                                                                                     // Expected value calculated using standard math library
                                                                                                     double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                     
                                                                                                     // Calculate using FastMath
                                                                                                     double actual = FastMath.sinh(x);
                                                                                                     
                                                                                                     // Verify the result is correct with a small tolerance
                                                                                                     assertEquals("sinh(0.25) should use expm1 calculation", 
                                                                                                                  expected, actual, 1e-15);
                                                                                                     
                                                                                                     // Additional test cases around the boundary
                                                                                                     double justBelow = 0.24999999999999999;
                                                                                                     double justAbove = 0.25000000000000001;
                                                                                                     
                                                                                                     assertEquals("sinh(just below 0.25) should use expm1 calculation",
                                                                                                                 (Math.exp(justBelow) - Math.exp(-justBelow)) / 2,
                                                                                                                 FastMath.sinh(justBelow), 1e-15);
                                                                                                                 
                                                                                                     assertEquals("sinh(just above 0.25) should use exp calculation",
                                                                                                                 (Math.exp(justAbove) - Math.exp(-justAbove)) / 2,
                                                                                                                 FastMath.sinh(justAbove), 1e-15);
                                                                                                 }

 @Test
                                                                                                public void testSinhHighPrecisionPath() {
                                                                                                    // Test value that will take the high precision path (x > 0.25)
                                                                                                    double x = 1.0;
                                                                                                    
                                                                                                    // Calculate expected value using original formula (ya = hiPrec[0] + hiPrec[1])
                                                                                                    // We'll compute what the correct sinh(1.0) should be
                                                                                                    double expected = (Math.exp(1.0) - Math.exp(-1.0)) / 2;
                                                                                                    
                                                                                                    // Call the method under test
                                                                                                    double actual = FastMath.sinh(x);
                                                                                                    
                                                                                                    // Verify the result matches expected value with reasonable tolerance
                                                                                                    assertEquals("sinh(1.0) should match expected value", 
                                                                                                                expected, actual, 1e-15);
                                                                                                    
                                                                                                    // Additional test with another value > 0.25
                                                                                                    x = 0.5;
                                                                                                    expected = (Math.exp(0.5) - Math.exp(-0.5)) / 2;
                                                                                                    actual = FastMath.sinh(x);
                                                                                                    assertEquals("sinh(0.5) should match expected value",
                                                                                                                expected, actual, 1e-15);
                                                                                                }

 @Test
                                                                                               public void testSinhWithHighPrecisionCalculation() {
                                                                                                   // Test a value that will use the high-precision calculation path (x > 0.25)
                                                                                                   double x = 1.5;
                                                                                                   
                                                                                                   // Calculate expected value using standard Math.sinh as reference
                                                                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                   
                                                                                                   // Call the method under test
                                                                                                   double actual = FastMath.sinh(x);
                                                                                                   
                                                                                                   // Verify the result matches expected value with a small tolerance
                                                                                                   assertEquals("sinh calculation incorrect for x > 0.25", 
                                                                                                               expected, actual, 1e-15);
                                                                                                   
                                                                                                   // Additional test case with negative value to ensure negation is handled correctly
                                                                                                   x = -1.5;
                                                                                                   expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                   actual = FastMath.sinh(x);
                                                                                                   assertEquals("sinh calculation incorrect for negative x > -0.25", 
                                                                                                               expected, actual, 1e-15);
                                                                                               }

 @Test
                                                                                          public void testSinhWithValueGreaterThanQuarter() {
                                                                                              // This test is designed to catch the mutation where multiplication was changed to division
                                                                                              // in the high-precision calculation part (x > 0.25 case)
                                                                                              
                                                                                              // Choose a value where x > 0.25 to trigger the affected code path
                                                                                              double input = 1.0;
                                                                                              
                                                                                              // Calculate expected value using standard Math.sinh for comparison
                                                                                              double expected = (Math.exp(input) - Math.exp(-input)) / 2;
                                                                                              
                                                                                              // Call the method under test
                                                                                              double actual = FastMath.sinh(input);
                                                                                              
                                                                                              // Verify the result is correct with high precision
                                                                                              assertEquals(expected, actual, 1e-15);
                                                                                              
                                                                                              // Additionally test with a negative value to cover both positive and negative cases
                                                                                              input = -1.0;
                                                                                              expected = (Math.exp(input) - Math.exp(-input)) / 2;
                                                                                              actual = FastMath.sinh(input);
                                                                                              assertEquals(expected, actual, 1e-15);
                                                                                              
                                                                                              // Test with a larger value (but still < 20) to ensure robustness
                                                                                              input = 5.0;
                                                                                              expected = (Math.exp(input) - Math.exp(-input)) / 2;
                                                                                              actual = FastMath.sinh(input);
                                                                                              assertEquals(expected, actual, 1e-10);
                                                                                          }

 @Test
                                                                                         public void testSinhWithPreciseValueToDetectMutant() {
                                                                                             // This value is chosen because:
                                                                                             // 1. It's > 0.25 to trigger the branch with the mutation
                                                                                             // 2. It has significant high and low parts that will be affected by the precision change
                                                                                             double x = 1.23456789012345;
                                                                                             
                                                                                             // Calculate expected value using standard Math.sinh for comparison
                                                                                             double expected = Math.sinh(x);
                                                                                             
                                                                                             // Call the method under test
                                                                                             double actual = FastMath.sinh(x);
                                                                                             
                                                                                             // Verify the result is correct and precise
                                                                                             assertEquals("Sinh calculation should match expected value", 
                                                                                                         expected, actual, 1e-15);
                                                                                             
                                                                                             // Additional verification - check that the high precision calculation was accurate
                                                                                             // The mutation would affect the precision of the result
                                                                                             double preciseExpected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                             assertEquals("Sinh should match precise calculation", 
                                                                                                         preciseExpected, actual, 1e-15);
                                                                                             
                                                                                             // Verify the relative error is small
                                                                                             double relativeError = Math.abs((actual - preciseExpected) / preciseExpected);
                                                                                             assertTrue("Relative error should be very small", relativeError < 1e-14);
                                                                                         }

 @Test
                                                                                            public void testSinhWithValueGreaterThanQuarter1() {
                                                                                                // This test is designed to catch the mutation where multiplication was changed to division
                                                                                                // in the high-precision calculation path (x > 0.25)
                                                                                                
                                                                                                // Test value where x > 0.25 to trigger the affected code path
                                                                                                double x = 1.0;
                                                                                                
                                                                                                // Calculate expected value using standard math library
                                                                                                double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                
                                                                                                // Call the method under test
                                                                                                double actual = FastMath.sinh(x);
                                                                                                
                                                                                                // Verify the result is correct to within reasonable floating point precision
                                                                                                assertEquals("sinh calculation for x > 0.25 is incorrect", 
                                                                                                            expected, actual, 1e-15);
                                                                                                
                                                                                                // Additional verification - check that the result isn't zero or extremely small,
                                                                                                // which might happen if the division mutation caused underflow
                                                                                                assertTrue("sinh result is unexpectedly small", Math.abs(actual) > 0.5);
                                                                                                
                                                                                                // Verify the sign is correct
                                                                                                assertEquals("sinh result has wrong sign", 
                                                                                                            Math.signum(expected), Math.signum(actual), 0.0);
                                                                                            }

 @Test
                                                                                           public void testSinhWithPrecisionCalculation() {
                                                                                               // Test a value that will exercise the x > 0.25 code path
                                                                                               double x = 1.0;
                                                                                               
                                                                                               // Expected value calculated using standard math library
                                                                                               double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                               
                                                                                               // Actual value from FastMath
                                                                                               double actual = FastMath.sinh(x);
                                                                                               
                                                                                               // Verify the result matches expected value with a small tolerance
                                                                                               assertEquals("sinh calculation for x > 0.25 is incorrect", 
                                                                                                           expected, actual, 1e-15);
                                                                                               
                                                                                               // Additional verification - test negative value to ensure symmetry
                                                                                               double negativeX = -1.0;
                                                                                               double expectedNegative = -expected;
                                                                                               double actualNegative = FastMath.sinh(negativeX);
                                                                                               assertEquals("sinh calculation for negative x > 0.25 is incorrect",
                                                                                                           expectedNegative, actualNegative, 1e-15);
                                                                                           }

 @Test
                                                                                          public void testSinhWithReciprocalCalculation() {
                                                                                              // Test value where x > 0.25 to hit the mutated code path
                                                                                              double x = 1.0;
                                                                                              
                                                                                              // Expected value calculated using standard math library
                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                              
                                                                                              // Actual value from FastMath
                                                                                              double actual = FastMath.sinh(x);
                                                                                              
                                                                                              // Verify the result is very close to expected value
                                                                                              assertEquals("sinh calculation with reciprocal error correction", 
                                                                                                          expected, actual, 1e-15);
                                                                                              
                                                                                              // Additional verification that the result is not NaN and finite
                                                                                              assertFalse("Result should not be NaN", Double.isNaN(actual));
                                                                                              assertTrue("Result should be finite", Double.isFinite(actual));
                                                                                              
                                                                                              // Verify the sign is correct
                                                                                              assertTrue("Result should be positive for positive input", actual > 0);
                                                                                          }

 @Test
                                                                                     public void testSinhWithMutationDetection() {
                                                                                         // Choose a value where x > 0.25 to trigger the relevant code path
                                                                                         // and where the error correction term is significant
                                                                                         double x = 1.0;
                                                                                         
                                                                                         // Calculate expected value using original formula
                                                                                         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                         
                                                                                         // Test the actual implementation
                                                                                         double actual = FastMath.sinh(x);
                                                                                         
                                                                                         // The mutation would cause a significant difference in the result
                                                                                         // because it reverses the sign of the error correction term
                                                                                         assertEquals("Sinh calculation should be accurate", expected, actual, 1e-15);
                                                                                         
                                                                                         // Additional test with a value that stresses the error correction more
                                                                                         x = 0.5;
                                                                                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                         actual = FastMath.sinh(x);
                                                                                         assertEquals("Sinh calculation should handle moderate values correctly", 
                                                                                                      expected, actual, 1e-15);
                                                                                         
                                                                                         // Edge case just above 0.25 boundary
                                                                                         x = 0.2501;
                                                                                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                         actual = FastMath.sinh(x);
                                                                                         assertEquals("Sinh calculation should be accurate near boundary", 
                                                                                                      expected, actual, 1e-15);
                                                                                     }

 @Test
                                                                                        public void testSinhWithHighPrecisionComponents() {
                                                                                            // Test value chosen to ensure yb is non-zero in the high-precision calculation
                                                                                            double x = 1.0;
                                                                                            
                                                                                            // Calculate expected value using original formula
                                                                                            double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                            
                                                                                            // Calculate actual value from FastMath
                                                                                            double actual = FastMath.sinh(x);
                                                                                            
                                                                                            // Verify the result matches expected value with reasonable tolerance
                                                                                            assertEquals("Sinh calculation with high-precision components failed", 
                                                                                                        expected, actual, 1e-15);
                                                                                            
                                                                                            // Additional verification that we're testing the right branch
                                                                                            assertTrue("Test should verify x > 0.25 case", x > 0.25);
                                                                                        }

 @Test
                                                                                   public void testSinhWithValueGreaterThanQuarter2() {
                                                                                       // Choose a value where x > 0.25 to trigger the affected code path
                                                                                       double x = 1.0;
                                                                                       
                                                                                       // Calculate expected value using standard Math.sinh
                                                                                       double expected = Math.sinh(x);
                                                                                       
                                                                                       // Call the method under test
                                                                                       double actual = FastMath.sinh(x);
                                                                                       
                                                                                       // The mutation affects the precision, so we need to check with a tight tolerance
                                                                                       assertEquals("Sinh calculation for x > 0.25 is incorrect", 
                                                                                                   expected, actual, 1.0e-16);
                                                                                       
                                                                                       // Additional test with a different value in the same range
                                                                                       x = 0.5;
                                                                                       expected = Math.sinh(x);
                                                                                       actual = FastMath.sinh(x);
                                                                                       assertEquals("Sinh calculation for x > 0.25 is incorrect", 
                                                                                                   expected, actual, 1.0e-16);
                                                                                       
                                                                                       // Test with a negative value (should also go through the same code path after negation)
                                                                                       x = -0.3;
                                                                                       expected = Math.sinh(x);
                                                                                       actual = FastMath.sinh(x);
                                                                                       assertEquals("Sinh calculation for negative x > -0.25 is incorrect", 
                                                                                                   expected, actual, 1.0e-16);
                                                                                   }

 @Test
                                                                                      public void testSinhWithHighPrecisionCalculation1() {
                                                                                          // Test values where x > 0.25 to trigger the high-precision path
                                                                                          double x1 = 0.5;
                                                                                          double expected1 = (Math.exp(x1) - Math.exp(-x1)) / 2;
                                                                                          double result1 = FastMath.sinh(x1);
                                                                                          assertEquals("sinh(0.5) should match exact calculation", expected1, result1, 1e-15);
                                                                                          
                                                                                          double x2 = 1.0;
                                                                                          double expected2 = (Math.exp(x2) - Math.exp(-x2)) / 2;
                                                                                          double result2 = FastMath.sinh(x2);
                                                                                          assertEquals("sinh(1.0) should match exact calculation", expected2, result2, 1e-15);
                                                                                          
                                                                                          // Test negative value to ensure sign handling is correct
                                                                                          double x3 = -0.75;
                                                                                          double expected3 = (Math.exp(x3) - Math.exp(-x3)) / 2;
                                                                                          double result3 = FastMath.sinh(x3);
                                                                                          assertEquals("sinh(-0.75) should match exact calculation", expected3, result3, 1e-15);
                                                                                          
                                                                                          // Test boundary case just above 0.25
                                                                                          double x4 = 0.2501;
                                                                                          double expected4 = (Math.exp(x4) - Math.exp(-x4)) / 2;
                                                                                          double result4 = FastMath.sinh(x4);
                                                                                          assertEquals("sinh(0.2501) should match exact calculation", expected4, result4, 1e-15);
                                                                                      }

 @Test
                                                                                 public void testSinhWithPrecisionCalculation1() {
                                                                                     // Test value where x > 0.25 to trigger the high-precision calculation path
                                                                                     double x = 1.0;
                                                                                     
                                                                                     // Expected value calculated using standard math library
                                                                                     double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                     
                                                                                     // Actual value from FastMath
                                                                                     double actual = FastMath.sinh(x);
                                                                                     
                                                                                     // Verify the result matches expected with high precision
                                                                                     assertEquals(expected, actual, 1e-15);
                                                                                     
                                                                                     // Additional verification - the mutant would produce a significantly different result
                                                                                     // The correct calculation should be very close to the expected value
                                                                                     double mutantResult = actual;
                                                                                     // Simulate what the mutant would do by corrupting the yb adjustment
                                                                                     if (x > 0.25) {
                                                                                         // This is a simplified simulation of the mutant's effect
                                                                                         mutantResult = mutantResult + 2 * (expected - mutantResult);
                                                                                     }
                                                                                     assertFalse(Math.abs(expected - mutantResult) < 1e-15);
                                                                                 }

 @Test
                                                                                    public void testSinhWithPreciseCalculation() {
                                                                                        // Test value where x > 0.25 and high-precision calculation is used
                                                                                        double x = 1.0;
                                                                                        double expected = 1.1752011936438014; // Known precise value of sinh(1.0)
                                                                                        
                                                                                        // Calculate actual value
                                                                                        double actual = FastMath.sinh(x);
                                                                                        
                                                                                        // Verify the result with high precision delta
                                                                                        assertEquals("High-precision sinh calculation failed", expected, actual, 1e-15);
                                                                                        
                                                                                        // Additional verification that the result is not what the mutant would produce
                                                                                        // The mutant would produce a significantly different result due to subtraction instead of addition
                                                                                        double mutantResult = FastMath.sinh(x);
                                                                                        assertNotEquals("Mutant not detected (ya - yb instead of ya + yb)", 
                                                                                                       mutantResult, actual, 1e-10);
                                                                                    }

 @Test
                                                                                   public void testSinhWithHighPrecisionCalculation2() {
                                                                                       // Test a value that will trigger the high-precision calculation path (x > 0.25)
                                                                                       double x = 1.0;  // This will use the affected code path
                                                                                       
                                                                                       // Calculate expected value using standard Math.sinh for comparison
                                                                                       double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                       
                                                                                       // Call the method under test
                                                                                       double actual = FastMath.sinh(x);
                                                                                       
                                                                                       // Verify the result matches expected value with high precision
                                                                                       assertEquals("sinh calculation with x > 0.25 should be accurate", 
                                                                                                   expected, actual, 1e-15);
                                                                                       
                                                                                       // Additional verification that the result isn't just the negative of expected
                                                                                       assertNotEquals("Result should not be negative of expected (would indicate mutation)", 
                                                                                                      -expected, actual, 1e-15);
                                                                                   }

 @Test
                                                                                  public void testSinhWithNaNInput2() {
                                                                                      // Test with NaN input
                                                                                      double input = Double.NaN;
                                                                                      
                                                                                      // The original should return NaN, mutant returns 0
                                                                                      double result = FastMath.sinh(input);
                                                                                      
                                                                                      // Assert that result is NaN
                                                                                      assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
                                                                                      
                                                                                      // Additional assertion to ensure it's not 0
                                                                                      assertNotEquals("sinh(NaN) should not return 0", 0.0, result, 0.0);
                                                                                  }

 @Test
                                                                            public void testSinhBoundaryAt1() {
                                                                                // Test the boundary case x=20 to catch the x>=20 mutant
                                                                                double x = 20.0;
                                                                                
                                                                                // Calculate what the precise value should be (using the original method's logic for x <= 20)
                                                                                // For x=20, the original method would use the precise calculation path
                                                                                // while the mutant would use the approximation path (0.5 * exp(x))
                                                                                
                                                                                // We'll calculate both values to show the difference
                                                                                
                                                                                // 1. Precise calculation (what original method would do)
                                                                                boolean negate = false;
                                                                                if (x < 0.0) {
                                                                                    x = -x;
                                                                                    negate = true;
                                                                                }
                                                                                
                                                                                // Calculate exp(x) and exp(-x) using public methods
                                                                                double expX = FastMath.exp(x);
                                                                                double expNegX = FastMath.exp(-x);
                                                                                
                                                                                // Calculate precise sinh(x) = (exp(x) - exp(-x))/2
                                                                                double preciseResult = (expX - expNegX) * 0.5;
                                                                                
                                                                                if (negate) {
                                                                                    preciseResult = -preciseResult;
                                                                                }
                                                                                
                                                                                // 2. Approximation (what mutant would do)
                                                                                double approxResult = 0.5 * FastMath.exp(x);
                                                                                
                                                                                // The results should be different enough to detect the mutant
                                                                                assertNotEquals("At x=20, precise and approx results should differ", 
                                                                                               approxResult, preciseResult, 0.0001);
                                                                                
                                                                                // Now test the actual method - should use precise calculation
                                                                                double actualResult = FastMath.sinh(x);
                                                                                assertEquals("At x=20, should use precise calculation", 
                                                                                            preciseResult, actualResult, 0.0001);
                                                                            }

 @Test
                                                                       public void testSinhLargeValueOverflowProtection() {
                                                                           // Setup
                                                                           double logMaxValue = Math.log(Double.MAX_VALUE); // Equivalent to FastMath.LOG_MAX_VALUE
                                                                           double x = logMaxValue + 1; // Value guaranteed to be >= LOG_MAX_VALUE
                                                                           
                                                                           // Expected behavior (original code)
                                                                           // Should calculate as (0.5 * exp(0.5x))² to avoid overflow
                                                                           double expected = FastMath.sinh(x);
                                                                           
                                                                           // Mutated behavior would calculate as (0.5 * exp(x))² which could overflow
                                                                           // or produce a different result
                                                                           
                                                                           // Verify the result is finite and correct
                                                                           assertTrue("Result should be finite", Double.isFinite(expected));
                                                                           
                                                                           // Verify against known mathematical properties
                                                                           // sinh(x) = (exp(x) - exp(-x))/2
                                                                           // For large x, exp(-x) is negligible
                                                                           double approxExpected = 0.5 * Math.exp(x);
                                                                           double relativeError = Math.abs((expected - approxExpected)/approxExpected);
                                                                           
                                                                           assertTrue("Result should be close to 0.5*exp(x) for large x", 
                                                                                     relativeError < 1e-10);
                                                                           
                                                                           // Additional verification - check the calculation method
                                                                           // Original code would compute via exp(0.5x)
                                                                           double t = Math.exp(0.5 * x);
                                                                           double manualCalc = 0.5 * t * t;
                                                                           assertEquals("Should compute via exp(0.5x) method", 
                                                                                       manualCalc, expected, 1e-10);
                                                                       }

 @Test
                                                                  public void testSinhLargePositiveValueWithPotentialOverflow() {
                                                                      // Setup
                                                                      double logMaxValue;
                                                                      try {
                                                                          Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                          field.setAccessible(true);
                                                                          logMaxValue = field.getDouble(null);
                                                                      } catch (Exception e) {
                                                                          throw new RuntimeException("Failed to access LOG_MAX_VALUE via reflection", e);
                                                                      }
                                                                      double x = logMaxValue; // Use exactly LOG_MAX_VALUE to test the overflow case
                                                                      
                                                                      // Expected behavior: sinh(x) = (exp(x) - exp(-x))/2 ≈ exp(x)/2 for large x
                                                                      // For x = LOG_MAX_VALUE, original code computes exp(0.5*x)^2 * 0.5
                                                                      // Mutated code would compute exp(0.5*x)^2 (without the 0.5 factor)
                                                                      
                                                                      // Calculate expected value using original formula
                                                                      double t = Math.exp(0.5 * x);
                                                                      double expected = (0.5 * t) * t;
                                                                      
                                                                      // Test
                                                                      double actual = FastMath.sinh(x);
                                                                      
                                                                      // Assert
                                                                      assertEquals("Sinh of large positive value should handle overflow correctly", 
                                                                                  expected, actual, 0.0);
                                                                      
                                                                      // Additional check to ensure we're testing the right branch
                                                                      assertTrue(x >= logMaxValue);
                                                                  }

 @Test
                                                                  public void testSinhNegativeTwentyBoundary() {
                                                                      // Test the boundary case where x is exactly -20
                                                                      double x = -20.0;
                                                                      
                                                                      // Calculate expected value using original logic (should use the |x| <= 20 path)
                                                                      // For the original code, this would use the more complex calculation
                                                                      double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                      
                                                                      // Calculate actual value using FastMath.sinh
                                                                      double actual = FastMath.sinh(x);
                                                                      
                                                                      // Verify they match with a small tolerance
                                                                      assertEquals("sinh(-20) should use the |x|<=20 calculation path", 
                                                                                  expected, actual, 1e-10);
                                                                      
                                                                      // Additional verification that we're not using the simplified path
                                                                      double simplifiedPathResult = -0.5 * Math.exp(-x);
                                                                      assertNotEquals("sinh(-20) should not use the simplified x<=-20 calculation",
                                                                                     simplifiedPathResult, actual, 1e-10);
                                                                  }

 @Test
                                                                 public void testSinhWithNaNInput3() {
                                                                     // Test NaN input
                                                                     double nanInput = Double.NaN;
                                                                     
                                                                     // The original method should return NaN for NaN input
                                                                     double result = FastMath.sinh(nanInput);
                                                                     
                                                                     // Verify the result is NaN
                                                                     assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
                                                                     
                                                                     // Additional test cases for completeness
                                                                     // Test positive infinity
                                                                     double posInfResult = FastMath.sinh(Double.POSITIVE_INFINITY);
                                                                     assertEquals("sinh(+Inf) should be +Inf", Double.POSITIVE_INFINITY, posInfResult, 0.0);
                                                                     
                                                                     // Test negative infinity
                                                                     double negInfResult = FastMath.sinh(Double.NEGATIVE_INFINITY);
                                                                     assertEquals("sinh(-Inf) should be -Inf", Double.NEGATIVE_INFINITY, negInfResult, 0.0);
                                                                     
                                                                     // Test zero
                                                                     double zeroResult = FastMath.sinh(0.0);
                                                                     assertEquals("sinh(0.0) should be 0.0", 0.0, zeroResult, 0.0);
                                                                 }

 @Test
                                                                public void testSinhZeroInput1() {
                                                                    // Test the boundary case where x=0
                                                                    double input = 0.0;
                                                                    
                                                                    // Expected behavior: sinh(0) should be 0
                                                                    double expected = 0.0;
                                                                    
                                                                    // Call the method
                                                                    double result = FastMath.sinh(input);
                                                                    
                                                                    // Verify the result
                                                                    assertEquals("sinh(0) should be 0", expected, result, 0.0);
                                                                    
                                                                    // Additional verification that negation path wasn't taken
                                                                    // For x=0, negate flag should remain false
                                                                    // We can verify this by checking the result is exactly 0 (not -0)
                                                                    assertTrue(Double.doubleToRawLongBits(result) == Double.doubleToRawLongBits(0.0));
                                                                }

 @Test
                                                          public void testSinhBoundaryAtQuarter() {
                                                              // Test the boundary case x = 0.25
                                                              double x = 0.25;
                                                              
                                                              try {
                                                                  // Use reflection to access private expm1 method
                                                                  Method expm1Method = FastMath.class.getDeclaredMethod("expm1", double.class, double[].class);
                                                                  expm1Method.setAccessible(true);
                                                                  
                                                                  // Calculate expected value using the original path (expm1)
                                                                  double[] hiPrec = new double[2];
                                                                  expm1Method.invoke(null, x, hiPrec);
                                                                  
                                                                  double ya = hiPrec[0] + hiPrec[1];
                                                                  double yb = -(ya - hiPrec[0] - hiPrec[1]);
                                                                  double denom = 1.0 + ya;
                                                                  double denomr = 1.0 / denom;
                                                                  double denomb = -(denom - 1.0 - ya) + yb;
                                                                  double ratio = ya * denomr;
                                                                  double temp = ratio * Double.longBitsToDouble(0x4000000000000000L);
                                                                  double ra = ratio + temp - temp;
                                                                  double rb = ratio - ra;
                                                                  temp = denom * Double.longBitsToDouble(0x4000000000000000L);
                                                                  double za = denom + temp - temp;
                                                                  double zb = denom - za;
                                                                  rb += (ya - za*ra - za*rb - zb*ra - zb*rb) * denomr;
                                                                  rb += yb*denomr;
                                                                  rb += -ya * denomb * denomr * denomr;
                                                                  temp = ya + ra;
                                                                  yb += -(temp - ya - ra);
                                                                  ya = temp;
                                                                  temp = ya + rb;
                                                                  yb += -(temp - ya - rb);
                                                                  ya = temp;
                                                                  double expected = (ya + yb) * 0.5;
                                                                  
                                                                  // Verify the actual implementation uses the correct path
                                                                  double actual = FastMath.sinh(x);
                                                                  
                                                                  // The results should be exactly equal if the correct path was taken
                                                                  assertEquals("Sinh calculation for x=0.25 should use expm1 path", 
                                                                              expected, actual, 0.0);
                                                                  
                                                                  // Additional verification that we're testing the boundary
                                                                  // The difference between paths should be detectable
                                                                  double wrongPathResult = 0.5 * (FastMath.exp(x) - FastMath.exp(-x));
                                                                  assertNotEquals("Sinh calculation for x=0.25 should not use exp path",
                                                                                 wrongPathResult, actual, 0.0000000001);
                                                              } catch (Exception e) {
                                                                  fail("Failed to access private expm1 method via reflection: " + e.getMessage());
                                                              }
                                                          }

 @Test
                                                     public void testSinhWithHighPrecisionComponents1() {
                                                         // Test a value where x > 0.25 and hiPrec components are both significant
                                                         double x = 1.0; // This will use the branch where mutation occurs
                                                         
                                                         try {
                                                             // Get private exp method via reflection
                                                             Method expMethod = FastMath.class.getDeclaredMethod("exp", double.class, double.class, double[].class);
                                                             expMethod.setAccessible(true);
                                                             
                                                             // Calculate expected value using original formula
                                                             double[] hiPrec = new double[2];
                                                             expMethod.invoke(null, x, 0.0, hiPrec);
                                                             
                                                             double expectedYa = hiPrec[0] + hiPrec[1]; // Original behavior
                                                             double expectedYb = -(expectedYa - hiPrec[0] - hiPrec[1]);
                                                             
                                                             // Calculate what mutated version would produce
                                                             double mutatedYa = hiPrec[0] - hiPrec[1]; // Mutated behavior
                                                             double mutatedYb = -(mutatedYa - hiPrec[0] - hiPrec[1]);
                                                             
                                                             // The difference should be significant enough to detect
                                                             assertNotEquals("Mutated ya should differ from expected", mutatedYa, expectedYa, 0.0);
                                                             assertNotEquals("Mutated yb should differ from expected", mutatedYb, expectedYb, 0.0);
                                                             
                                                             // Now test the actual method
                                                             double result = FastMath.sinh(x);
                                                             
                                                             // Calculate expected final result
                                                             double temp = expectedYa + (-1.0/expectedYa);
                                                             double yb = expectedYb + -(temp - expectedYa - (-1.0/expectedYa));
                                                             double ya = temp;
                                                             temp = ya + (-1.0/expectedYa);
                                                             yb += -(temp - ya - (-1.0/expectedYa));
                                                             ya = temp;
                                                             double expectedResult = (ya + yb) * 0.5;
                                                             
                                                             assertEquals("Sinh calculation should match expected", expectedResult, result, 1e-15);
                                                         } catch (Exception e) {
                                                             fail("Failed to access private exp method via reflection: " + e.getMessage());
                                                         }
                                                     }

 @Test
                                                     public void testSinhWithMutationDetection1() {
                                                         // Test a value that will use the high-precision calculation path (x > 0.25)
                                                         double x = 1.0; // This will trigger the path where the mutation occurs
                                                         
                                                         // Calculate expected value using Math.sinh for comparison
                                                         double expected = Math.sinh(x);
                                                         
                                                         // Call the method under test
                                                         double actual = FastMath.sinh(x);
                                                         
                                                         // Verify the result is correct to a reasonable precision
                                                         assertEquals("sinh calculation is incorrect", expected, actual, 1.0e-15);
                                                         
                                                         // Additional verification - test with a value that would make yb significant
                                                         x = 0.5;
                                                         expected = Math.sinh(x);
                                                         actual = FastMath.sinh(x);
                                                         assertEquals("sinh calculation with significant yb is incorrect", 
                                                                     expected, actual, 1.0e-15);
                                                         
                                                         // Test negative value to ensure proper handling of negation
                                                         x = -1.5;
                                                         expected = Math.sinh(x);
                                                         actual = FastMath.sinh(x);
                                                         assertEquals("sinh calculation for negative value is incorrect",
                                                                     expected, actual, 1.0e-15);
                                                     }

 @Test
                                                public void testSinhWithMutationDetection2() {
                                                    // Test a value that will take the x > 0.25 path
                                                    double input = 1.0;
                                                    
                                                    // Expected value calculated using standard math library
                                                    double expected = (Math.exp(input) - Math.exp(-input)) / 2;
                                                    
                                                    // Actual value from the method
                                                    double actual = FastMath.sinh(input);
                                                    
                                                    // Verify the result with a small delta to account for floating point differences
                                                    assertEquals("Sinh calculation should be correct for x > 0.25", 
                                                                expected, actual, 1e-15);
                                                    
                                                    // Additional test with a negative value to cover the negate path
                                                    double negativeInput = -1.5;
                                                    double expectedNegative = (Math.exp(negativeInput) - Math.exp(-negativeInput)) / 2;
                                                    double actualNegative = FastMath.sinh(negativeInput);
                                                    assertEquals("Sinh calculation should be correct for negative x > -20", 
                                                                expectedNegative, actualNegative, 1e-15);
                                                    
                                                    // Test a boundary value just above 0.25
                                                    double boundaryInput = 0.26;
                                                    double expectedBoundary = (Math.exp(boundaryInput) - Math.exp(-boundaryInput)) / 2;
                                                    double actualBoundary = FastMath.sinh(boundaryInput);
                                                    assertEquals("Sinh calculation should be correct near 0.25 boundary", 
                                                                expectedBoundary, actualBoundary, 1e-15);
                                                }

 @Test
                                              public void testSinhWithPrecisionSensitiveValue() {
                                                  // This value is chosen to be >0.25 and have significant fractional parts
                                                  // that would make the mutation affect the result due to floating-point precision
                                                  double x = 0.5;
                                                  
                                                  // Get the private HEX_40000000 constant via reflection
                                                  double hex40000000;
                                                  try {
                                                      Field field = FastMath.class.getDeclaredField("HEX_40000000");
                                                      field.setAccessible(true);
                                                      hex40000000 = field.getDouble(null);
                                                  } catch (Exception e) {
                                                      throw new RuntimeException("Failed to access HEX_40000000 via reflection", e);
                                                  }
                                                  
                                                  // Calculate expected value using original computation
                                                  double expected;
                                                  {
                                                      boolean negate = false;
                                                      if (x < 0.0) {
                                                          x = -x;
                                                          negate = true;
                                                      }
                                                      
                                                      double ya = FastMath.exp(x);
                                                      double temp = ya * hex40000000;
                                                      // Original computation
                                                      double yaa = ya + temp - temp;
                                                      
                                                      // Rest of original computation path
                                                      double yab = ya - yaa;
                                                      double recip = 1.0/ya;
                                                      temp = recip * hex40000000;
                                                      double recipa = recip + temp - temp;
                                                      double recipb = recip - recipa;
                                                      recipb += (1.0 - yaa*recipa - yaa*recipb - yab*recipa - yab*recipb) * recip;
                                                      recipa = -recipa;
                                                      recipb = -recipb;
                                                      temp = ya + recipa;
                                                      double yb = -(temp - ya - recipa);
                                                      ya = temp;
                                                      temp = ya + recipb;
                                                      yb += -(temp - ya - recipb);
                                                      ya = temp;
                                                      expected = (ya + yb) * 0.5;
                                                      if (negate) {
                                                          expected = -expected;
                                                      }
                                                  }
                                                  
                                                  // The actual computation should match our expected value
                                                  double actual = FastMath.sinh(x);
                                                  
                                                  // Use a very small delta to catch precision differences
                                                  assertEquals("Sinh computation affected by mutation in precision-sensitive path", 
                                                              expected, actual, 1e-20);
                                              }

 @Test
                                          public void testSinhWithValueGreaterThanQuarterToDetectReciprocalMutation() {
                                              // This test specifically targets the mutation where multiplication was changed to division
                                              // in the high-precision calculation path (x > 0.25)
                                              
                                              // Test value chosen to:
                                              // 1. Be > 0.25 to trigger the affected code path
                                              // 2. Have a known expected value
                                              // 3. Be small enough that the mutation's effect is significant
                                              double input = 1.0;
                                              double expected = 1.1752011936438014; // Known correct value of sinh(1.0)
                                              
                                              // Calculate with original method
                                              double actual = FastMath.sinh(input);
                                              
                                              // Assert with delta to account for any floating-point differences
                                              // The delta should be very small since we're testing high-precision calculation
                                              assertEquals("sinh calculation incorrect - mutation not detected", 
                                                          expected, actual, 1e-15);
                                              
                                              // Additional assertion to verify the calculation isn't wildly off
                                              // The mutated version would produce a completely different result
                                              assertTrue("Result is suspiciously small (mutation likely present)",
                                                         Math.abs(actual) > 1.0);
                                              assertTrue("Result is suspiciously large (mutation likely present)",
                                                         Math.abs(actual) < 1.5);
                                          }

 @Test
                                             public void testSinhHighPrecisionCalculation() {
                                                 // Choose a value where x > 0.25 to trigger the high-precision calculation path
                                                 double x = 1.0;
                                                 
                                                 // Calculate expected value using original formula
                                                 double expectedRecip = 1.0 / Math.exp(x);
                                                 double temp = expectedRecip * Double.longBitsToDouble(0x40000000L);
                                                 double expectedRecipa = expectedRecip + temp - temp; // Original calculation
                                                 
                                                 // Calculate what mutant would produce
                                                 double mutantRecipa = expectedRecip - temp + temp; // Mutant calculation
                                                 
                                                 // Verify they are different (this assertion would fail if mutant is present)
                                                 assertNotEquals("Mutation not detected - recipa calculation changed", 
                                                                mutantRecipa, expectedRecipa, 0.0);
                                                 
                                                 // Now test the actual method - this will fail if mutant is present
                                                 double result = FastMath.sinh(x);
                                                 double expected = (Math.exp(x) - Math.exp(-x)) / 2; // Standard sinh formula
                                                 
                                                 // Use a tight delta because we're testing high-precision calculation
                                                 assertEquals("High-precision sinh calculation incorrect", 
                                                            expected, result, 1.0e-16);
                                             }

 @Test
                                            public void testSinhWithReciprocalCalculation1() {
                                                // Test a value that will exercise the reciprocal calculation path (x > 0.25)
                                                double x = 1.0;  // Chosen because it's >0.25 and has a known sinh value
                                                
                                                // Expected value calculated using standard math library
                                                double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                
                                                // Calculate using FastMath
                                                double actual = FastMath.sinh(x);
                                                
                                                // Verify the result is very close to expected (using delta for floating point comparison)
                                                assertEquals("sinh calculation with reciprocal is incorrect", 
                                                            expected, actual, 1e-15);
                                                
                                                // Additional verification - check that the mutant would produce a different result
                                                // The mutant would add recipa instead of subtracting, leading to a different result
                                                double mutantExpected = 1.1752011936438014;  // Approximate value the mutant would produce
                                                assertNotEquals("Test should fail if mutant is present", 
                                                               mutantExpected, actual, 1e-15);
                                            }

 @Test
                                           public void testSinhWithMutationDetection3() {
                                               // Test value chosen to exercise the affected code path (x > 0.25)
                                               double x = 1.0;
                                               
                                               // Calculate expected value using standard math library
                                               double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                               
                                               // Calculate actual value using FastMath
                                               double actual = FastMath.sinh(x);
                                               
                                               // Verify the result is very close to expected (with tight tolerance)
                                               assertEquals("sinh calculation affected by mutation", expected, actual, 1e-15);
                                               
                                               // Additional verification that the result isn't wildly off
                                               assertTrue("sinh result is NaN", !Double.isNaN(actual));
                                               assertTrue("sinh result is infinite", !Double.isInfinite(actual));
                                               
                                               // Test another value in the same range
                                               x = 0.5;
                                               expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                               actual = FastMath.sinh(x);
                                               assertEquals("sinh calculation affected by mutation for x=0.5", expected, actual, 1e-15);
                                           }

 @Test
                                          public void testSinhWithMutationDetection4() {
                                              // Test value chosen to ensure we enter the x > 0.25 path
                                              // and have non-negligible yb component
                                              double x = 1.5;
                                              
                                              // Calculate expected value using alternative implementation
                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                              
                                              // Call the method under test
                                              double actual = FastMath.sinh(x);
                                              
                                              // Verify with high precision tolerance since we're testing error correction terms
                                              assertEquals("Sinh calculation should match expected value", 
                                                          expected, actual, 1.0e-15);
                                              
                                              // Additional test with another value
                                              x = 2.5;
                                              expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                              actual = FastMath.sinh(x);
                                              assertEquals("Sinh calculation should match expected value for x=2.5",
                                                          expected, actual, 1.0e-15);
                                          }

 @Test
                                         public void testSinhHighPrecisionPath1() {
                                             // Test value chosen to exercise the x > 0.25 path where the mutation occurs
                                             double x = 1.0;
                                             
                                             // Expected value calculated using standard math library
                                             double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                             
                                             // Actual value from FastMath
                                             double actual = FastMath.sinh(x);
                                             
                                             // Verify the result matches expected value with high precision
                                             assertEquals("High precision sinh calculation incorrect", 
                                                         expected, actual, 1e-15);
                                             
                                             // Additional verification - check if the result is approximately correct
                                             // This helps ensure we're testing the right code path
                                             assertTrue("Result not in expected range", 
                                                       actual > 1.175 && actual < 1.176);
                                         }

 @Test
                                    public void testSinhWithSignificantResidualComponents() {
                                        // Choose a value where x > 0.25 and residual components are significant
                                        double x = 1.5;  // This value will trigger the affected branch and have non-negligible residuals
                                        
                                        // Calculate expected value using standard Math.sinh()
                                        double expected = Math.sinh(x);
                                        
                                        // Call the method under test
                                        double actual = FastMath.sinh(x);
                                        
                                        // Verify the result with a tight tolerance since we're testing high-precision calculation
                                        assertEquals("Sinh calculation with significant residuals failed", 
                                                    expected, actual, 1.0e-16);
                                        
                                        // Additional verification - check that the result is not what the mutant would produce
                                        // For the mutant (temp = ya - recipb), the result would be significantly different
                                        assertFalse("Mutant not detected - result matches mutant output", 
                                                   Math.abs(expected - actual) > 1.0e-8);
                                    }

 @Test
                                   public void testSinhWithHighPrecisionCalculation3() {
                                       // Test values where x > 0.25 to trigger the affected code path
                                       // Using values where the high-precision calculation is significant
                                       
                                       // Test case 1: Moderate positive value
                                       double x1 = 1.0;
                                       double expected1 = (Math.exp(x1) - Math.exp(-x1)) / 2;
                                       double actual1 = FastMath.sinh(x1);
                                       assertEquals("sinh(1.0) should match exact calculation", expected1, actual1, 1e-15);
                                       
                                       // Test case 2: Value slightly above 0.25 threshold
                                       double x2 = 0.26;
                                       double expected2 = (Math.exp(x2) - Math.exp(-x2)) / 2;
                                       double actual2 = FastMath.sinh(x2);
                                       assertEquals("sinh(0.26) should match exact calculation", expected2, actual2, 1e-15);
                                       
                                       // Test case 3: Larger value where high-precision is important
                                       double x3 = 2.5;
                                       double expected3 = (Math.exp(x3) - Math.exp(-x3)) / 2;
                                       double actual3 = FastMath.sinh(x3);
                                       assertEquals("sinh(2.5) should match exact calculation", expected3, actual3, 1e-15);
                                       
                                       // Test case 4: Negative value (tests the negate path)
                                       double x4 = -1.5;
                                       double expected4 = (Math.exp(x4) - Math.exp(-x4)) / 2;
                                       double actual4 = FastMath.sinh(x4);
                                       assertEquals("sinh(-1.5) should match exact calculation", expected4, actual4, 1e-15);
                                   }

 @Test
                                  public void testSinhWithMediumPositiveValue() {
                                      // This value is chosen because:
                                      // 1. It's > 0.25 to trigger the affected code path
                                      // 2. It's not large enough to use the exponential approximation
                                      // 3. It will produce non-negligible yb component
                                      double x = 1.5;
                                      
                                      // Calculate expected value using standard math library
                                      double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                      
                                      // Test the FastMath implementation
                                      double actual = FastMath.sinh(x);
                                      
                                      // The mutant would produce significantly different result
                                      // We use a tight delta because we expect high precision
                                      assertEquals(expected, actual, 1.0e-15);
                                      
                                      // Additional assertion to specifically catch the mutant
                                      // The mutant would produce approximately exp(x)/2 - exp(-x)/2
                                      double mutantValue = (Math.exp(x)/2) - (Math.exp(-x)/2);
                                      assertNotEquals(mutantValue, actual, 1.0e-15);
                                  }

 @Test
                                     public void testSinhWithHighPrecCalculation() {
                                         // Test value where x > 0.25 to trigger the high-precision calculation path
                                         double x = 0.5;
                                         
                                         // Calculate expected value using standard Math.sinh as reference
                                         double expected = Math.sinh(x);
                                         
                                         // Call the method and get actual result
                                         double actual = FastMath.sinh(x);
                                         
                                         // Verify the result matches expected with a small tolerance
                                         assertEquals("High-precision sinh calculation incorrect", 
                                                     expected, actual, 1e-15);
                                         
                                         // Additional verification - test with negative value
                                         double xNeg = -0.5;
                                         double expectedNeg = Math.sinh(xNeg);
                                         double actualNeg = FastMath.sinh(xNeg);
                                         assertEquals("High-precision sinh calculation incorrect for negative value",
                                                     expectedNeg, actualNeg, 1e-15);
                                         
                                         // Test boundary case just above 0.25
                                         double xBoundary = 0.2501;
                                         double expectedBoundary = Math.sinh(xBoundary);
                                         double actualBoundary = FastMath.sinh(xBoundary);
                                         assertEquals("High-precision sinh calculation incorrect near boundary",
                                                     expectedBoundary, actualBoundary, 1e-15);
                                     }

 @Test
                                    public void testSinhWithNaNInput4() {
                                        // Test NaN input
                                        double nanInput = Double.NaN;
                                        
                                        // Call the method
                                        double result = FastMath.sinh(nanInput);
                                        
                                        // Verify the result is NaN (original behavior)
                                        // This will fail if mutant returns 0 instead
                                        assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
                                        
                                        // Additional check to ensure it's not 0
                                        assertNotEquals("sinh(NaN) should not return 0", 0.0, result, 0.0);
                                    }

 @Test
                                   public void testSinhBoundaryAt2() {
                                       // Test exactly at the boundary (x=20)
                                       double x = 20.0;
                                       
                                       // Expected value calculated using standard math formula
                                       double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                       
                                       // Actual value from FastMath
                                       double actual = FastMath.sinh(x);
                                       
                                       // Verify the result is not using the simplified calculation
                                       // (which would be approximately 0.5*exp(x))
                                       double simplifiedApprox = 0.5 * Math.exp(x);
                                       assertNotEquals(simplifiedApprox, actual, 0.0001);
                                       
                                       // Verify correct calculation
                                       assertEquals(expected, actual, 0.0001);
                                       
                                       // Test value just above 20 (should use simplified calculation)
                                       double xAbove = 20.0001;
                                       double actualAbove = FastMath.sinh(xAbove);
                                       double simplifiedApproxAbove = 0.5 * Math.exp(xAbove);
                                       assertEquals(simplifiedApproxAbove, actualAbove, 0.0001);
                                       
                                       // Test value just below 20 (should not use simplified calculation)
                                       double xBelow = 19.9999;
                                       double actualBelow = FastMath.sinh(xBelow);
                                       double expectedBelow = (Math.exp(xBelow) - Math.exp(-xBelow)) / 2;
                                       assertEquals(expectedBelow, actualBelow, 0.0001);
                                   }

 @Test
                             public void testSinhBoundaryNegative1() {
                                 // Test the exact boundary case where x = -20
                                 double input = -20.0;
                                 
                                 // Calculate expected value using public methods
                                 // sinh(x) = (exp(x) - exp(-x))/2
                                 double expPos = FastMath.exp(-input); // exp(20)
                                 double expNeg = FastMath.exp(input);  // exp(-20)
                                 double expectedMainPathResult = (expNeg - expPos) / 2;
                                 
                                 // Now test the actual method
                                 double actual = FastMath.sinh(input);
                                 
                                 // Verify the result matches what we expect from the main path calculation
                                 assertEquals("sinh(-20) should use main calculation path", 
                                             expectedMainPathResult, actual, 1e-10);
                                 
                                 // Additionally verify it's not using the large negative path
                                 // Large negative path would return approximately -0.5 * exp(20)
                                 double largeNegativePathResult = -0.5 * FastMath.exp(-input);
                                 assertNotEquals("sinh(-20) should not use large negative path", 
                                                largeNegativePathResult, actual, 1e-10);
                             }

 @Test
                             public void testSinhWithNaNInput5() {
                                 // Test NaN input
                                 double nanInput = Double.NaN;
                                 double result = FastMath.sinh(nanInput);
                                 
                                 // Verify the result is NaN
                                 assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
                                 
                                 // Additional check to ensure it's not returning 0
                                 assertNotEquals("sinh(NaN) should not return 0", 0.0, result, 0.0);
                             }

 @Test
                            public void testSinhWithZeroInput() {
                                // Test the boundary case of x=0
                                double input = 0.0;
                                double expected = 0.0;  // sinh(0) should be 0
                                
                                // Call the method
                                double result = FastMath.sinh(input);
                                
                                // Verify the result
                                assertEquals("sinh(0) should be 0", expected, result, 0.0);
                                
                                // Additional verification that the result isn't negated
                                // (which would happen if the mutant was active)
                                assertFalse("Result should not be negative", result < 0.0);
                                assertFalse("Result should not be positive", result > 0.0);
                            }

 @Test
                           public void testSinhBoundaryAt0_1() {
                               // Test the exact boundary value that triggers the mutant
                               double x = 0.25;
                               
                               // Expected value calculated using standard math library
                               double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                               
                               // Calculate using FastMath
                               double actual = FastMath.sinh(x);
                               
                               // Verify the result is correct with a small tolerance
                               assertEquals("sinh(0.25) should use expm1-based calculation", 
                                           expected, actual, 1e-15);
                               
                               // Additional tests around the boundary
                               double justBelow = 0.24999999999999999;
                               double justAbove = 0.25000000000000001;
                               
                               // Verify behavior just below the boundary
                               double expectedBelow = (Math.exp(justBelow) - Math.exp(-justBelow)) / 2;
                               double actualBelow = FastMath.sinh(justBelow);
                               assertEquals(expectedBelow, actualBelow, 1e-15);
                               
                               // Verify behavior just above the boundary
                               double expectedAbove = (Math.exp(justAbove) - Math.exp(-justAbove)) / 2;
                               double actualAbove = FastMath.sinh(justAbove);
                               assertEquals(expectedAbove, actualAbove, 1e-15);
                               
                               // Verify the difference between boundary approaches
                               // The difference between exp and expm1 approaches should be noticeable
                               // for the mutant case (x >= 0.25) vs original (x > 0.25)
                               double deltaApproaches = Math.abs(actual - actualBelow);
                               assertTrue("Different calculation approaches should produce slightly different results",
                                         deltaApproaches > 1e-16);
                           }

 @Test
                          public void testSinhWithHighPrecisionComponents2() {
                              // Choose a value where x > 0.25 and hiPrec components are both significant
                              double x = 1.0;  // This will trigger the x > 0.25 branch
                              
                              // Calculate expected value using standard math library
                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                              
                              // Calculate actual value from FastMath
                              double actual = FastMath.sinh(x);
                              
                              // Verify the result is very close to expected (allowing for small floating point differences)
                              assertEquals("Sinh calculation with high precision components failed", 
                                          expected, actual, 1e-15);
                              
                              // Additional verification that the result isn't zero or NaN
                              assertFalse("Result should not be NaN", Double.isNaN(actual));
                              assertTrue("Result should not be zero", actual != 0.0);
                          }

 @Test
                         public void testSinhWithMutationDetection5() {
                             // Test case designed to catch the yb negation mutation
                             double x = 1.0; // Chosen because 1.0 > 0.25 and will trigger the affected code path
                             
                             // Calculate expected value using standard Math.sinh as reference
                             double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                             
                             // Call the method under test
                             double actual = FastMath.sinh(x);
                             
                             // Verify the result is very close to expected (allowing for small floating point differences)
                             assertEquals("Test failed - possible mutation in yb calculation not detected", 
                                         expected, actual, 1e-15);
                             
                             // Additional verification - test with negative value to ensure symmetry
                             double xNeg = -1.0;
                             double expectedNeg = (Math.exp(xNeg) - Math.exp(-xNeg)) / 2;
                             double actualNeg = FastMath.sinh(xNeg);
                             assertEquals("Test failed for negative value - possible mutation in yb calculation not detected",
                                         expectedNeg, actualNeg, 1e-15);
                         }

 @Test
                    public void testSinhWithValueGreaterThanQuarter3() {
                        // This test is designed to catch the mutation where multiplication by HEX_40000000
                        // was changed to division. We use a value > 0.25 to enter the relevant branch.
                        
                        // Value chosen to ensure the high-precision calculation affects the result
                        double input = 1.0;
                        
                        // Calculate expected value using standard Math.sinh for comparison
                        double expected = (Math.exp(input) - Math.exp(-input)) / 2;
                        
                        // Call the method under test
                        double actual = FastMath.sinh(input);
                        
                        // Verify the result with a tight delta since we're testing precise calculations
                        assertEquals("Sinh calculation incorrect - mutation not detected", 
                                     expected, actual, 1e-15);
                        
                        // Additional assertion to specifically test the high-precision part
                        // If the mutation exists, this will fail due to significant difference
                        assertTrue("High-precision calculation incorrect - mutation not detected",
                                   Math.abs(expected - actual) < 1e-15);
                    }

 @Test
                  public void testSinhWithPrecisionSensitiveValue1() {
                      // This value is chosen to exercise the precision-sensitive code path
                      double input = 1.0;
                      
                      // Calculate expected value using standard math library
                      double expected = (Math.exp(input) - Math.exp(-input)) / 2;
                      
                      // Call the method under test
                      double actual = FastMath.sinh(input);
                      
                      // Verify the result matches expected value with high precision
                      assertEquals(expected, actual, 1e-15);
                      
                      // Additionally verify the computation path by checking intermediate precision
                      // This is where the mutant would fail - the rounding behavior would differ
                      double ya = Math.exp(input);
                      // Use the same value as HEX_40000000 (2^30) since we can't access the private field
                      double temp = ya * 1073741824.0;
                      
                      // Original behavior: ya + temp - temp (proper high part extraction)
                      double expectedYaa = ya + temp - temp;
                      
                      // Mutated behavior: ya - temp + temp (different rounding)
                      double mutatedYaa = ya - temp + temp;
                      
                      // Verify the original computation method was used
                      assertNotEquals(mutatedYaa, expectedYaa);
                      assertEquals(expectedYaa, ya - (ya - expectedYaa), 0.0); // Verify high part extraction
                  }

 @Test
                  public void testSinhDetectsReciprocalMutation() {
                      // Test value chosen to exercise the high-precision path (x > 0.25)
                      double x = 1.0;
                      
                      // Calculate expected value using standard math library
                      double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                      
                      // Call the method under test
                      double actual = FastMath.sinh(x);
                      
                      // Verify the result is very close to expected (allowing for small floating point differences)
                      assertEquals("sinh calculation affected by reciprocal mutation", 
                                  expected, actual, 1e-15);
                      
                      // Additional assertion to verify it's not zero or some obviously wrong value
                      assertTrue("sinh result should not be zero for x=1.0", actual != 0.0);
                  }

 @Test
             public void testSinhWithMutationDetection6() {
                 // Test value chosen to exercise the mutated code path (x > 0.25)
                 double x = 1.0;
                 
                 // Expected value calculated using standard math library
                 double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                 
                 // Actual value from FastMath
                 double actual = FastMath.sinh(x);
                 
                 // Verify the result is correct to 15 decimal places
                 assertEquals(expected, actual, 1e-15);
                 
                 // Additional test with negative value to ensure symmetry
                 double xNeg = -1.0;
                 double expectedNeg = (Math.exp(xNeg) - Math.exp(-xNeg)) / 2;
                 double actualNeg = FastMath.sinh(xNeg);
                 assertEquals(expectedNeg, actualNeg, 1e-15);
                 
                 // Test boundary case just above 0.25
                 double xBoundary = 0.2501;
                 double expectedBoundary = (Math.exp(xBoundary) - Math.exp(-xBoundary)) / 2;
                 double actualBoundary = FastMath.sinh(xBoundary);
                 assertEquals(expectedBoundary, actualBoundary, 1e-15);
             }

 @Test
                public void testSinhWithReciprocalCalculation2() {
                    // Test a value that will take the high-precision path (0.25 < x < 20)
                    double x = 1.0;  // Well-known value where sinh(1) ≈ 1.175201194
                    
                    // Calculate expected value using alternative implementation
                    double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                    
                    // Call the method under test
                    double actual = FastMath.sinh(x);
                    
                    // Verify the result with high precision
                    assertEquals("sinh calculation with reciprocal is incorrect", 
                                expected, actual, 1e-15);
                    
                    // Also test a negative value in the same range
                    double xNeg = -1.0;
                    double expectedNeg = (Math.exp(xNeg) - Math.exp(-xNeg)) / 2;
                    double actualNeg = FastMath.sinh(xNeg);
                    assertEquals("sinh calculation for negative value with reciprocal is incorrect",
                                expectedNeg, actualNeg, 1e-15);
                }

 @Test
               public void testSinhWithMutationDetection7() {
                   // Test a value that will exercise the x > 0.25 code path
                   double x = 1.0;  // This will go through the affected code path
                   
                   // Calculate expected value using standard math library
                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                   
                   // Call the method under test
                   double actual = FastMath.sinh(x);
                   
                   // Verify the result is correct to within reasonable precision
                   assertEquals("sinh calculation should be accurate", 
                               expected, actual, 1e-15);
                   
                   // Additional assertion to specifically catch the mutation
                   // The mutation would cause a much larger error than expected
                   double delta = Math.abs(actual - expected);
                   assertTrue("Test should detect the recipb mutation",
                             delta < 1e-14);
               }

 @Test
         public void testSinhWithMutationDetection8() {
             // Test value chosen to:
             // 1. Be > 0.25 to trigger the affected code path
             // 2. Have significant yb component in the high-precision calculation
             // 3. Show measurable difference when correction term sign is flipped
             double x = 1.0;
             
             // Calculate expected value using original formula
             double expected = (Math.exp(x) - Math.exp(-x)) / 2;
             
             // Calculate actual value from FastMath
             double actual = FastMath.sinh(x);
             
             // Verify the result is very close to expected
             assertEquals("sinh calculation is incorrect", expected, actual, 1e-15);
             
             // Additional verification that the mutant would fail:
             // The mutant would produce a value that's approximately 2*yb*recip*recip away from correct
             // For x=1.0, this difference should be detectable
             double mutantValue = actual;
             if (x > 0.25) {
                 // Simulate what the mutant would do by adding twice the correction term
                 // (since mutant adds instead of subtracts)
                 double hiPrec[] = new double[2];
                 try {
                     // Use reflection to access private exp method
                     Method expMethod = FastMath.class.getDeclaredMethod("exp", double.class, double.class, double[].class);
                     expMethod.setAccessible(true);
                     expMethod.invoke(null, x, 0.0, hiPrec);
                 } catch (Exception e) {
                     fail("Failed to access private exp method via reflection: " + e.getMessage());
                 }
                 double ya = hiPrec[0] + hiPrec[1];
                 double yb = -(ya - hiPrec[0] - hiPrec[1]);
                 double recip = 1.0/ya;
                 mutantValue += 2 * yb * recip * recip;
             }
             
             // Verify our actual value is NOT what the mutant would produce
             assertNotEquals("Test should detect the recipb sign mutation", 
                            mutantValue, actual, 1e-15);
         }

 @Test
     public void testSinhWithMutationDetection9() {
         // Test value that will trigger the high-precision calculation path (x > 0.25)
         double x = 1.0;
         
         // Calculate expected value using Math.sinh for comparison
         double expected = Math.sinh(x);
         
         // Call the method under test
         double actual = FastMath.sinh(x);
         
         // Verify the result is correct with high precision
         assertEquals(expected, actual, 1.0e-15);
         
         // Additional test with a negative value to ensure the negate path works
         double xNeg = -1.0;
         double expectedNeg = Math.sinh(xNeg);
         double actualNeg = FastMath.sinh(xNeg);
         assertEquals(expectedNeg, actualNeg, 1.0e-15);
         
         // Test a value slightly above 0.25 to ensure boundary condition
         double xBoundary = 0.26;
         double expectedBoundary = Math.sinh(xBoundary);
         double actualBoundary = FastMath.sinh(xBoundary);
         assertEquals(expectedBoundary, actualBoundary, 1.0e-15);
     }

 @Test
    public void testSinhWithMediumPositiveValue1() {
        // This test is designed to catch the mutation where temp = ya + recipb was changed to temp = ya - recipb
        // We choose a value between 0.25 and 20 to exercise the affected code path
        double x = 1.5; // Chosen because:
                        // 1. It's > 0.25 to enter the affected branch
                        // 2. Not large enough to trigger special cases
                        // 3. Small enough that recipb will be significant
        
        // Calculate expected value using standard math library
        double expected = (Math.exp(x) - Math.exp(-x)) / 2;
        
        // Call the method under test
        double actual = FastMath.sinh(x);
        
        // Verify the result with tight tolerance since we're testing high-precision calculation
        assertEquals("Sinh calculation incorrect - mutation not detected", 
                    expected, actual, 1.0e-15);
        
        // Additional verification - check that the result is positive and reasonable
        assertTrue("Sinh of positive number should be positive", actual > 0);
        assertTrue("Sinh(1.5) should be greater than 1.5", actual > 1.5);
    }

 @Test
       public void testSinhWithPrecisionAffectedValue() {
           // This value is chosen because:
           // 1. It's > 0.25 (enters the affected code path)
           // 2. The yb adjustment is significant enough to affect the result
           // 3. We can calculate the expected value using alternative methods
           
           double x = 0.5;
           
           // Calculate expected value using alternative implementation
           double expected = (Math.exp(x) - Math.exp(-x)) / 2;
           
           // Test the FastMath implementation
           double actual = FastMath.sinh(x);
           
           // The mutation would cause a different result because it incorrectly updates yb
           assertEquals("Sinh calculation affected by yb adjustment mutation", 
                        expected, actual, 1e-15);
           
           // Additional assertion to verify the precision
           // The mutant would fail this due to incorrect yb handling
           assertEquals("High precision sinh calculation", 
                        0.5210953054937474, actual, 1e-15);
       }

 @Test
       public void testSinhWithLargerValueToAmplifyEffect() {
           // A larger value to amplify the effect of the mutation
           double x = 1.0;
           
           double expected = (Math.exp(x) - Math.exp(-x)) / 2;
           double actual = FastMath.sinh(x);
           
           // The mutant would produce a significantly different result here
           assertEquals(expected, actual, 1e-14);
           
           // Specific value check
           assertEquals(1.1752011936438014, actual, 1e-15);
       }

 @Test
  public void testSinhWithMediumPositiveValue2() {
      // Test a value that will take the x > 0.25 code path
      double x = 1.0;
      
      // Calculate expected value using standard math library
      double expected = (Math.exp(x) - Math.exp(-x)) / 2;
      
      // Call the method under test
      double actual = FastMath.sinh(x);
      
      // Verify the result is correct with high precision
      assertEquals(expected, actual, 1e-15);
      
      // Additional verification - check that the low precision part (yb) was properly added
      // If the mutant is present (using subtraction), this will fail
      double naiveCalculation = 0.5 * (Math.exp(x) - Math.exp(-x));
      assertNotEquals(naiveCalculation, actual, 1e-15);
  }

 @Test
     public void testSinhWithMutation() {
         // Test value that will trigger the affected code path (x > 0.25)
         double x = 1.5;
         
         // Calculate expected value using Math.sinh for comparison
         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
         
         // Call the method under test
         double actual = FastMath.sinh(x);
         
         // Verify the result is correct to 15 decimal places
         // The mutation would cause a significant difference in the result
         assertEquals(expected, actual, 1e-15);
         
         // Additional test case with different value
         x = 0.5;
         expected = (Math.exp(x) - Math.exp(-x)) / 2;
         actual = FastMath.sinh(x);
         assertEquals(expected, actual, 1e-15);
         
         // Test negative value to ensure proper handling of sign
         x = -1.5;
         expected = (Math.exp(x) - Math.exp(-x)) / 2;
         actual = FastMath.sinh(x);
         assertEquals(expected, actual, 1e-15);
     }

}
