package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math3.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                    public void testEbeDivide_TypicalValues() {
                                                                                                                        // Create a vector with values [4.0, 9.0, 16.0]
                                                                                                                        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{4.0, 9.0, 16.0});
                                                                                                                        // Create a divisor vector with values [2.0, 3.0, 4.0]
                                                                                                                        OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 3.0, 4.0});
                                                                                                                        
                                                                                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                                                                                        
                                                                                                                        assertEquals(3, result.getDimension());
                                                                                                                        assertEquals(2.0, result.getEntry(0), 0.0001);
                                                                                                                        assertEquals(3.0, result.getEntry(1), 0.0001);
                                                                                                                        assertEquals(4.0, result.getEntry(2), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testEbeDivide_WithZeroValues() {
                                                                                                                        // Create a vector with values [0.0, 5.0, 0.0]
                                                                                                                        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0.0, 5.0, 0.0});
                                                                                                                        // Create a divisor vector with values [1.0, 2.0, 3.0]
                                                                                                                        OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                                                                                                                        
                                                                                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                                                                                        
                                                                                                                        assertEquals(3, result.getDimension());
                                                                                                                        assertEquals(0.0, result.getEntry(0), 0.0001);
                                                                                                                        assertEquals(2.5, result.getEntry(1), 0.0001);
                                                                                                                        assertEquals(0.0, result.getEntry(2), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testEbeDivide_DivisionByZeroResultsInInfinity() {
                                                                                                                        // Create a vector with values [1.0, 2.0, 3.0]
                                                                                                                        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                                                                                                                        // Create a divisor vector with values [1.0, 0.0, -0.0]
                                                                                                                        OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 0.0, -0.0});
                                                                                                                        
                                                                                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                                                                                        
                                                                                                                        assertEquals(3, result.getDimension());
                                                                                                                        assertEquals(1.0, result.getEntry(0), 0.0001);
                                                                                                                        assertTrue(Double.isInfinite(result.getEntry(1)));
                                                                                                                        assertTrue(Double.isInfinite(result.getEntry(2)));
                                                                                                                    }

    @Test
                                                                                                                    public void testEbeDivide_ZeroDividedByZeroResultsInNaN() {
                                                                                                                        // Create a vector with values [0.0, 0.0]
                                                                                                                        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0.0, 0.0});
                                                                                                                        // Create a divisor vector with values [0.0, -0.0]
                                                                                                                        OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{0.0, -0.0});
                                                                                                                        
                                                                                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                                                                                        
                                                                                                                        assertEquals(2, result.getDimension());
                                                                                                                        assertTrue(Double.isNaN(result.getEntry(0)));
                                                                                                                        assertTrue(Double.isNaN(result.getEntry(1)));
                                                                                                                    }

    @Test
                                                                                                                    public void testEbeDivide_WithRealVectorParameter() {
                                                                                                                        // Create our test vector
                                                                                                                        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{10.0, 20.0, 30.0});
                                                                                                                        
                                                                                                                        // Mock a RealVector
                                                                                                                        RealVector mockVector = mock(RealVector.class);
                                                                                                                        when(mockVector.getDimension()).thenReturn(3);
                                                                                                                        when(mockVector.getEntry(0)).thenReturn(2.0);
                                                                                                                        when(mockVector.getEntry(1)).thenReturn(5.0);
                                                                                                                        when(mockVector.getEntry(2)).thenReturn(10.0);
                                                                                                                        
                                                                                                                        OpenMapRealVector result = vector1.ebeDivide(mockVector);
                                                                                                                        
                                                                                                                        assertEquals(3, result.getDimension());
                                                                                                                        assertEquals(5.0, result.getEntry(0), 0.0001);
                                                                                                                        assertEquals(4.0, result.getEntry(1), 0.0001);
                                                                                                                        assertEquals(3.0, result.getEntry(2), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testEbeDivide_WithSparseVectors() {
                                                                                                                        // Create sparse vectors (most entries are 0)
                                                                                                                        OpenMapRealVector vector1 = new OpenMapRealVector(5);
                                                                                                                        vector1.setEntry(1, 8.0);  // [0, 8, 0, 0, 0]
                                                                                                                        vector1.setEntry(4, 10.0); // [0, 8, 0, 0, 10]
                                                                                                                        
                                                                                                                        OpenMapRealVector vector2 = new OpenMapRealVector(5);
                                                                                                                        vector2.setEntry(1, 2.0);   // [0, 2, 0, 0, 0]
                                                                                                                        vector2.setEntry(3, 5.0);   // [0, 2, 0, 5, 0]
                                                                                                                        
                                                                                                                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                                                                                        
                                                                                                                        assertEquals(5, result.getDimension());
                                                                                                                        assertEquals(0.0, result.getEntry(0), 0.0001);  // 0/0 = NaN (but implementation might handle differently)
                                                                                                                        assertEquals(4.0, result.getEntry(1), 0.0001);  // 8/2 = 4
                                                                                                                        assertEquals(0.0, result.getEntry(2), 0.0001);  // 0/0 = NaN
                                                                                                                        assertEquals(0.0, result.getEntry(3), 0.0001);  // 0/5 = 0
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, result.getEntry(4), 0.0001);  // 10/0 = Inf
                                                                                                                    }

    @Test
                                                                                                                    public void testEbeMultiply_EmptyVector() {
                                                                                                                        OpenMapRealVector emptyVector = new OpenMapRealVector(0);
                                                                                                                        OpenMapRealVector other = new OpenMapRealVector(0);
                                                                                                                        OpenMapRealVector result = emptyVector.ebeMultiply(other);
                                                                                                                        
                                                                                                                        assertEquals(0, result.getDimension());
                                                                                                                    }

    @Test
                                                                                                            public void testEbeDivide_DifferentDimensionsThrowsException() {
                                                                                                                // Create a vector with 3 elements
                                                                                                                OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                                                                                                                // Create a vector with 2 elements
                                                                                                                OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0});
                                                                                                                
                                                                                                                // Set up expected exception
                                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                                exception.expect(IllegalArgumentException.class);
                                                                                                                vector1.ebeDivide(vector2);
                                                                                                            }

    @Test
                                                                                                            public void testEbeMultiply_TypicalValues() {
                                                                                                                OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 0.0, 4.0});
                                                                                                                OpenMapRealVector other = new OpenMapRealVector(new double[]{2.0, 3.0, 5.0, 0.5});
                                                                                                                OpenMapRealVector result = vector.ebeMultiply(other);
                                                                                                                
                                                                                                                assertEquals(2.0, result.getEntry(0), 0.0001);
                                                                                                                assertEquals(6.0, result.getEntry(1), 0.0001);
                                                                                                                assertEquals(0.0, result.getEntry(2), 0.0001);
                                                                                                                assertEquals(2.0, result.getEntry(3), 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testEbeMultiply_WithZeroValues() {
                                                                                                                OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0, 4.0});
                                                                                                                OpenMapRealVector other = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0, 0.0});
                                                                                                                OpenMapRealVector result = vector.ebeMultiply(other);
                                                                                                                
                                                                                                                assertEquals(0.0, result.getEntry(0), 0.0001);
                                                                                                                assertEquals(0.0, result.getEntry(1), 0.0001);
                                                                                                                assertEquals(0.0, result.getEntry(2), 0.0001);
                                                                                                                assertEquals(0.0, result.getEntry(3), 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testEbeMultiply_WithNaNValues() {
                                                                                                                OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0, 4.0});
                                                                                                                OpenMapRealVector other = new OpenMapRealVector(new double[]{Double.NaN, 2.0, Double.NaN, 3.0});
                                                                                                                OpenMapRealVector result = vector.ebeMultiply(other);
                                                                                                                
                                                                                                                assertTrue(Double.isNaN(result.getEntry(0)));
                                                                                                                assertEquals(4.0, result.getEntry(1), 0.0001);
                                                                                                                assertTrue(Double.isNaN(result.getEntry(2)));
                                                                                                                assertEquals(12.0, result.getEntry(3), 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testEbeMultiply_WithInfinityValues() {
                                                                                                                OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0, 4.0});
                                                                                                                OpenMapRealVector other = new OpenMapRealVector(new double[]{Double.POSITIVE_INFINITY, 2.0, 
                                                                                                                    Double.NEGATIVE_INFINITY, 0.0});
                                                                                                                OpenMapRealVector result = vector.ebeMultiply(other);
                                                                                                                
                                                                                                                assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0001);
                                                                                                                assertEquals(4.0, result.getEntry(1), 0.0001);
                                                                                                                assertEquals(Double.NEGATIVE_INFINITY, result.getEntry(2), 0.0001);
                                                                                                                assertEquals(0.0, result.getEntry(3), 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testEbeMultiply_WithZeroTimesInfinity() {
                                                                                                                // Create and initialize the vector with 4 elements
                                                                                                                OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 1.0, 1.0, 4.0});
                                                                                                                OpenMapRealVector other = new OpenMapRealVector(new double[]{1.0, Double.POSITIVE_INFINITY, 
                                                                                                                    Double.POSITIVE_INFINITY, 1.0});
                                                                                                                vector.setEntry(2, 0.0); // Set the third element to 0
                                                                                                                OpenMapRealVector result = vector.ebeMultiply(other);
                                                                                                                
                                                                                                                assertEquals(1.0, result.getEntry(0), 0.0001);
                                                                                                                assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0001);
                                                                                                                assertEquals(Double.NaN, result.getEntry(2), 0.0001); // 0 * Infinity = NaN
                                                                                                                assertEquals(4.0, result.getEntry(3), 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testEbeMultiply_DimensionMismatch() {
                                                                                                                OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0});
                                                                                                                OpenMapRealVector other = new OpenMapRealVector(new double[]{1.0, 2.0});
                                                                                                                
                                                                                                                try {
                                                                                                                    vector.ebeMultiply(other);
                                                                                                                    fail("Expected IllegalArgumentException");
                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                    // expected
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testEbeMultiply_WithMockVector() {
                                                                                                                // Create a test vector with values [1.0, 2.0, 1.0, 1.0]
                                                                                                                OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0, 1.0, 1.0});
                                                                                                                
                                                                                                                RealVector mockVector = mock(RealVector.class);
                                                                                                                when(mockVector.getDimension()).thenReturn(4);
                                                                                                                when(mockVector.getEntry(0)).thenReturn(2.0);
                                                                                                                when(mockVector.getEntry(1)).thenReturn(3.0);
                                                                                                                when(mockVector.getEntry(2)).thenReturn(Double.NaN);
                                                                                                                when(mockVector.getEntry(3)).thenReturn(Double.POSITIVE_INFINITY);
                                                                                                                when(mockVector.isNaN()).thenReturn(true);
                                                                                                                when(mockVector.isInfinite()).thenReturn(true);
                                                                                                                
                                                                                                                OpenMapRealVector result = vector.ebeMultiply(mockVector);
                                                                                                                
                                                                                                                assertEquals(2.0, result.getEntry(0), 0.0001);
                                                                                                                assertEquals(6.0, result.getEntry(1), 0.0001);
                                                                                                                assertTrue(Double.isNaN(result.getEntry(2)));
                                                                                                                assertEquals(Double.POSITIVE_INFINITY, result.getEntry(3), 0.0001);
                                                                                                                
                                                                                                                verify(mockVector, times(1)).getDimension();
                                                                                                                verify(mockVector, atLeastOnce()).getEntry(anyInt());
                                                                                                                verify(mockVector, times(1)).isNaN();
                                                                                                                verify(mockVector, times(1)).isInfinite();
                                                                                                            }

    @Test
                                                                                                            public void testConstructorHandlesInvalidValues() {
                                                                                                                // Test with NaN value
                                                                                                                double[] nanValues = {1.0, Double.NaN, 2.0};
                                                                                                                OpenMapRealVector nanVector = new OpenMapRealVector(nanValues);
                                                                                                                assertEquals(3, nanVector.getDimension());
                                                                                                                assertTrue(Double.isNaN(nanVector.getEntry(1))); // Should be preserved
                                                                                                                
                                                                                                                // Test with positive infinity
                                                                                                                double[] posInfValues = {1.0, Double.POSITIVE_INFINITY, 2.0};
                                                                                                                OpenMapRealVector posInfVector = new OpenMapRealVector(posInfValues);
                                                                                                                assertEquals(3, posInfVector.getDimension());
                                                                                                                assertTrue(Double.isInfinite(posInfVector.getEntry(1))); // Should be preserved
                                                                                                                
                                                                                                                // Test with negative infinity
                                                                                                                double[] negInfValues = {1.0, Double.NEGATIVE_INFINITY, 2.0};
                                                                                                                OpenMapRealVector negInfVector = new OpenMapRealVector(negInfValues);
                                                                                                                assertEquals(3, negInfVector.getDimension());
                                                                                                                assertTrue(Double.isInfinite(negInfVector.getEntry(1))); // Should be preserved
                                                                                                                
                                                                                                                // Test with both NaN and Infinite in same vector
                                                                                                                double[] mixedValues = {Double.NaN, Double.POSITIVE_INFINITY};
                                                                                                                OpenMapRealVector mixedVector = new OpenMapRealVector(mixedValues);
                                                                                                                assertEquals(2, mixedVector.getDimension());
                                                                                                                assertTrue(Double.isNaN(mixedVector.getEntry(0)));
                                                                                                                assertTrue(Double.isInfinite(mixedVector.getEntry(1)));
                                                                                                            }

    @Test
                                                                                                public void testGetEntriesDoesNotContainNaNOrInfiniteValues() throws Exception {
                                                                                                    // Create a vector with problematic values
                                                                                                    double[] values = {1.0, Double.NaN, Double.POSITIVE_INFINITY, 2.0};
                                                                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                                                    
                                                                                                    // Use reflection to access private getEntries() method
                                                                                                    Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                                                                                                    getEntriesMethod.setAccessible(true);
                                                                                                    OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                                                                                                    
                                                                                                    // Verify NaN and Infinite values are not stored
                                                                                                    assertEquals(2, entries.size()); // Should only contain 1.0 and 2.0
                                                                                                    assertEquals(1.0, entries.get(0), 0.0001);
                                                                                                    assertEquals(2.0, entries.get(3), 0.0001);
                                                                                                    
                                                                                                    // Verify indices 1 and 2 (NaN and Infinite) are not present
                                                                                                    assertFalse(entries.containsKey(1));
                                                                                                    assertFalse(entries.containsKey(2));
                                                                                                }

    @Test
                                                                                        public void testGetEntriesContainsAllElements() throws Exception {
                                                                                            // Create a vector with known values where the last element is non-default
                                                                                            double[] testValues = {0.0, 1.0, 0.0, 2.0}; // Last element is non-default
                                                                                            OpenMapRealVector vector = new OpenMapRealVector(testValues);
                                                                                            
                                                                                            // Use reflection to access private getEntries() method
                                                                                            Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                                                                                            getEntriesMethod.setAccessible(true);
                                                                                            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                                                                                            
                                                                                            // Use reflection to access private epsilon field
                                                                                            Field epsilonField = OpenMapRealVector.class.getDeclaredField("epsilon");
                                                                                            epsilonField.setAccessible(true);
                                                                                            double epsilon = (Double) epsilonField.get(vector);
                                                                                            
                                                                                            // Verify all non-default values are present, especially the last one
                                                                                            assertEquals(1.0, entries.get(1), epsilon);
                                                                                            assertEquals(2.0, entries.get(3), epsilon); // This would fail with the mutant
                                                                                            
                                                                                            // Verify the size of entries is correct
                                                                                            assertEquals(2, entries.size()); // Only two non-default values
                                                                                            
                                                                                            // Verify the last element was processed by checking its presence
                                                                                            assertTrue(entries.containsKey(3)); // This assertion would catch the mutant
                                                                                        }

    @Test
                                                                                        public void testGetEntriesWithSingleElement() throws Exception {
                                                                                            // Test edge case with single element
                                                                                            double[] singleValue = {5.0};
                                                                                            OpenMapRealVector vector = new OpenMapRealVector(singleValue);
                                                                                            
                                                                                            // Use reflection to access private getEntries() method
                                                                                            Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                                                                                            getEntriesMethod.setAccessible(true);
                                                                                            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                                                                                            
                                                                                            // Use reflection to access private epsilon field
                                                                                            Field epsilonField = OpenMapRealVector.class.getDeclaredField("epsilon");
                                                                                            epsilonField.setAccessible(true);
                                                                                            double epsilon = (Double) epsilonField.get(vector);
                                                                                            
                                                                                            // Verify the single element is present
                                                                                            assertEquals(1, entries.size());
                                                                                            assertEquals(5.0, entries.get(0), epsilon);
                                                                                        }

    @Test
                                                                                public void testGetEntriesDetectsFirstElementMutation() throws Exception {
                                                                                    // Create test data with non-default value at index 0
                                                                                    double[] values = {1.0, 0.0, 0.0}; // First element is non-default
                                                                                    
                                                                                    // Create vector
                                                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                                    
                                                                                    // Get the entries map using reflection
                                                                                    Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                                                                                    getEntriesMethod.setAccessible(true);
                                                                                    OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                                                                                    
                                                                                    // Get epsilon using reflection
                                                                                    Field epsilonField = OpenMapRealVector.class.getDeclaredField("epsilon");
                                                                                    epsilonField.setAccessible(true);
                                                                                    double epsilon = (Double) epsilonField.get(vector);
                                                                                    
                                                                                    // Verify index 0 is present in entries (would be missing in mutated version)
                                                                                    assertTrue("First element should be in entries", entries.containsKey(0));
                                                                                    
                                                                                    // Verify the value at index 0 is correct
                                                                                    assertEquals(1.0, entries.get(0), epsilon);
                                                                                    
                                                                                    // Verify total entries count is correct (should be 1)
                                                                                    assertEquals(1, entries.size());
                                                                                    
                                                                                    // Additional check - verify all expected indices are present
                                                                                    // This would fail if the loop starts at 1
                                                                                    for (int i = 0; i < values.length; i++) {
                                                                                        if (values[i] != 0.0) {
                                                                                            assertTrue("Entry at index " + i + " should be present", 
                                                                                                      entries.containsKey(i));
                                                                                        }
                                                                                    }
                                                                                }

    @Test
                                                                        public void testGetEntriesHandlesNaNValues() throws Exception {
                                                                            // Create a test vector with NaN values
                                                                            double[] values = {1.0, Double.NaN, 3.0};
                                                                            OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                            
                                                                            // Use reflection to access the private getEntries() method
                                                                            Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                                                                            getEntriesMethod.setAccessible(true);
                                                                            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                                                                            
                                                                            // Verify NaN value is properly stored
                                                                            // The original code should store NaN values (if isNaN check is proper)
                                                                            // The mutant (if (false)) would skip storing NaN values
                                                                            assertEquals(3, vector.getDimension());
                                                                            assertTrue(entries.containsKey(0));  // 1.0
                                                                            assertTrue(entries.containsKey(1));  // NaN should be stored
                                                                            assertTrue(entries.containsKey(2));  // 3.0
                                                                            
                                                                            // Verify the actual values
                                                                            assertEquals(1.0, entries.get(0), 0.0001);
                                                                            assertTrue(Double.isNaN(entries.get(1)));  // Special check for NaN
                                                                            assertEquals(3.0, entries.get(2), 0.0001);
                                                                        }

    @Test
                                                                public void testGetEntries() throws Exception {
                                                                    // Create a test vector with some sample data
                                                                    double[] values = {1.0, 0.0, 3.0, 0.0, 5.0};
                                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                                    
                                                                    // Use reflection to access private getEntries() method
                                                                    Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                                                                    getEntriesMethod.setAccessible(true);
                                                                    OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                                                                    
                                                                    // Use reflection to access private entries field
                                                                    Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                                                    entriesField.setAccessible(true);
                                                                    OpenIntToDoubleHashMap actualEntries = (OpenIntToDoubleHashMap) entriesField.get(vector);
                                                                    
                                                                    // Verify it returns the actual entries map (same reference)
                                                                    assertSame("Should return the actual entries map", actualEntries, entries);
                                                                    
                                                                    // Verify the map contains the expected non-zero values
                                                                    assertEquals(1.0, entries.get(0), 0.0);
                                                                    assertEquals(3.0, entries.get(2), 0.0);
                                                                    assertEquals(5.0, entries.get(4), 0.0);
                                                                    
                                                                    // Verify default value (0.0) is returned for empty entries
                                                                    assertEquals(0.0, entries.get(1), 0.0);
                                                                    
                                                                    // Test that modifications to the returned map affect the vector
                                                                    entries.put(1, 2.0); // Add a new entry
                                                                    assertEquals(2.0, vector.getEntry(1), 0.0);
                                                                    
                                                                    entries.remove(0); // Remove an entry
                                                                    assertEquals(0.0, vector.getEntry(0), 0.0);
                                                                }

    @Test
                                                        public void testNaNHandling() throws NoSuchFieldException, IllegalAccessException {
                                                            // Create a test array containing NaN values
                                                            double[] testValues = {1.0, Double.NaN, 2.0, Double.POSITIVE_INFINITY};
                                                            
                                                            // Create vector with test values
                                                            OpenMapRealVector vector = new OpenMapRealVector(testValues);
                                                            
                                                            // Use reflection to access private entries field
                                                            Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                                            entriesField.setAccessible(true);
                                                            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) entriesField.get(vector);
                                                            
                                                            // Verify NaN values are not in the entries (should be filtered out)
                                                            // The original code should filter out NaN values (via isDefaultValue which checks isNaN)
                                                            // The mutant would potentially keep NaN values
                                                            for (OpenIntToDoubleHashMap.Iterator iter = entries.iterator(); iter.hasNext();) {
                                                                iter.advance();
                                                                double value = iter.value();
                                                                assertFalse("Vector contains NaN value which should be filtered out", 
                                                                          Double.isNaN(value));
                                                            }
                                                            
                                                            // Also verify that infinite values are handled correctly
                                                            boolean hasInfinite = false;
                                                            for (OpenIntToDoubleHashMap.Iterator iter = entries.iterator(); iter.hasNext();) {
                                                                iter.advance();
                                                                if (Double.isInfinite(iter.value())) {
                                                                    hasInfinite = true;
                                                                    break;
                                                                }
                                                            }
                                                            assertTrue("Vector should contain infinite values", hasInfinite);
                                                        }

    @Test
                                                public void testGetEntriesWithSpecificValues() throws Exception {
                                                    // Setup test data with known values at specific indices
                                                    double[] testValues = {1.0, 0.0, 3.0, 0.0, 5.0};
                                                    double epsilon = 1.0e-12; // Define our own epsilon for assertions
                                                    
                                                    // Create vector with test values
                                                    OpenMapRealVector vector = new OpenMapRealVector(testValues);
                                                    
                                                    // Use reflection to access private entries map
                                                    Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                                    entriesField.setAccessible(true);
                                                    OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) entriesField.get(vector);
                                                    
                                                    // Verify all non-zero values were stored correctly
                                                    assertEquals(1.0, entries.get(0), epsilon);
                                                    assertEquals(3.0, entries.get(2), epsilon);
                                                    assertEquals(5.0, entries.get(4), epsilon);
                                                    
                                                    // Verify zero values are not stored (default behavior)
                                                    assertFalse(entries.containsKey(1));
                                                    assertFalse(entries.containsKey(3));
                                                    
                                                    // Verify size is correct (only non-zero entries stored)
                                                    assertEquals(3, entries.size());
                                                    
                                                    // Verify iteration order by checking first and last entries
                                                    // This would fail if iteration was reversed in the constructor
                                                    OpenIntToDoubleHashMap.Iterator iterator = entries.iterator();
                                                    assertTrue(iterator.hasNext());
                                                    assertEquals(0, iterator.key()); // First entry should be at index 0
                                                }

    @Test
                                        public void testConstructorStoresAllNonDefaultValues() throws Exception {
                                            // Prepare test data with non-default values at both even and odd indices
                                            double[] testValues = {1.0, 2.0, 3.0, 4.0}; // Even length to test boundary
                                            
                                            // Create instance using constructor that will be mutated
                                            OpenMapRealVector vector = new OpenMapRealVector(testValues);
                                            
                                            // Use reflection to access private entries field
                                            Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                            entriesField.setAccessible(true);
                                            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) entriesField.get(vector);
                                            
                                            // Verify all non-default values were stored, including odd indices
                                            assertEquals(1.0, entries.get(0), 0.0001);
                                            assertEquals(2.0, entries.get(1), 0.0001);
                                            assertEquals(3.0, entries.get(2), 0.0001);
                                            assertEquals(4.0, entries.get(3), 0.0001);
                                            
                                            // Also verify the size is correct (should be 4 entries)
                                            assertEquals(4, entries.size());
                                        }

    @Test
                                public void testGetEntriesHandlesNaNValues1() throws NoSuchFieldException, IllegalAccessException {
                                    // Create a vector with NaN value
                                    double[] values = {1.0, Double.NaN, 3.0};
                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                    
                                    // Use reflection to access private entries field
                                    Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
                                    entriesField.setAccessible(true);
                                    OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) entriesField.get(vector);
                                    
                                    // Verify NaN value is properly stored in entries
                                    assertTrue(Double.isNaN(entries.get(1))); // Index 1 has NaN
                                    
                                    // Verify other values are stored correctly
                                    assertEquals(1.0, entries.get(0), 0.0001);
                                    assertEquals(3.0, entries.get(2), 0.0001);
                                    
                                    // Verify size is correct (should contain all non-default values)
                                    assertEquals(3, entries.size());
                                }

    @Test
                        public void testGetEntriesWithLargeVector() throws Exception {
                            // Create a large vector to test loop iteration behavior
                            double[] largeArray = new double[10000];
                            for (int i = 0; i < largeArray.length; i++) {
                                largeArray[i] = i * 1.5; // Fill with non-default values
                            }
                            
                            OpenMapRealVector vector = new OpenMapRealVector(largeArray);
                            
                            // Use reflection to access private getEntries() method
                            Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                            getEntriesMethod.setAccessible(true);
                            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                            
                            // Use reflection to access private epsilon field
                            Field epsilonField = OpenMapRealVector.class.getDeclaredField("epsilon");
                            epsilonField.setAccessible(true);
                            double epsilon = (Double) epsilonField.get(vector);
                            
                            // Verify all expected entries are present
                            for (int i = 0; i < largeArray.length; i++) {
                                assertEquals(largeArray[i], entries.get(i), epsilon);
                            }
                            
                            // Verify the size matches exactly
                            assertEquals(largeArray.length, entries.size());
                        }

    @Test
                        public void testGetEntriesBoundaryCondition() throws Exception {
                            // Create a vector with size near Integer.MAX_VALUE
                            // (using a smaller size but testing the behavior)
                            double[] boundaryArray = new double[10];
                            for (int i = 0; i < boundaryArray.length; i++) {
                                boundaryArray[i] = i == boundaryArray.length - 1 ? Double.MAX_VALUE : 0;
                            }
                            
                            OpenMapRealVector vector = new OpenMapRealVector(boundaryArray);
                            
                            // Use reflection to access private getEntries() method
                            Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
                            getEntriesMethod.setAccessible(true);
                            OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
                            
                            // Use reflection to access private epsilon field
                            Field epsilonField = OpenMapRealVector.class.getDeclaredField("epsilon");
                            epsilonField.setAccessible(true);
                            double epsilon = (double) epsilonField.get(vector);
                            
                            // Verify only the last entry is stored (others are default 0)
                            assertEquals(1, entries.size());
                            assertEquals(Double.MAX_VALUE, entries.get(boundaryArray.length - 1), epsilon);
                        }

    @Test
    public void testGetEntriesWithNaNValues() throws Exception {
        // Create a vector with NaN values
        double[] values = {1.0, Double.NaN, 3.0};
        OpenMapRealVector vector = new OpenMapRealVector(values);
        
        // Use reflection to access private getEntries() method
        Method getEntriesMethod = OpenMapRealVector.class.getDeclaredMethod("getEntries");
        getEntriesMethod.setAccessible(true);
        OpenIntToDoubleHashMap entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
        
        // Verify NaN value was stored properly
        assertFalse(entries.containsKey(1)); // NaN should not be stored (default value)
        assertEquals(1.0, entries.get(0), 0.0001);
        assertEquals(3.0, entries.get(2), 0.0001);
        
        // Test setting a NaN value explicitly
        vector.setEntry(1, Double.NaN);
        entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(vector);
        assertFalse(entries.containsKey(1)); // Should still not store NaN
        
        // Test with only NaN values
        double[] allNaNs = {Double.NaN, Double.NaN};
        OpenMapRealVector nanVector = new OpenMapRealVector(allNaNs);
        entries = (OpenIntToDoubleHashMap) getEntriesMethod.invoke(nanVector);
        assertEquals(0, entries.size()); // Should store nothing
    }


}
