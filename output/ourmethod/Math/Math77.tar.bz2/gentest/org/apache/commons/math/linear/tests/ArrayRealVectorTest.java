package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class ArrayRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                    public void testMapInvToSelf_WithZeroValue() {
                                                                                                                                                                        // Setup
                                                                                                                                                                        double[] testData = {1.0, 0.0, 2.0};
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                        
                                                                                                                                                                        // Expect exception
                                                                                                                                                                        thrown.expect(ArithmeticException.class);
                                                                                                                                                                        thrown.expectMessage("/ by zero");
                                                                                                                                                                        
                                                                                                                                                                        // Execute
                                                                                                                                                                        vector.mapInvToSelf();
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_EmptyVector() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[0]);
                                                                                                                                                                        assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_SinglePositiveValue() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{5.0});
                                                                                                                                                                        assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_SingleNegativeValue() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{-3.0});
                                                                                                                                                                        assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_MultiplePositiveValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, 3.0, 4.0});
                                                                                                                                                                        assertEquals(4.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_MultipleNegativeValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{-1.0, -2.0, -3.0, -4.0});
                                                                                                                                                                        assertEquals(4.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_MixedPositiveNegativeValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{-5.0, 2.0, -3.0, 4.0, -1.0});
                                                                                                                                                                        assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_WithZeroValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{0.0, -0.0, 0.0});
                                                                                                                                                                        assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_ExtremeValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{Double.MAX_VALUE, Double.MIN_VALUE});
                                                                                                                                                                        assertEquals(Double.MAX_VALUE, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_WithNaNValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, Double.NaN, 3.0});
                                                                                                                                                                        assertEquals(Double.NaN, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_WithInfiniteValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, Double.POSITIVE_INFINITY, 3.0});
                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_AfterModification() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                        assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                        
                                                                                                                                                                        vector.setEntry(0, 5.0);
                                                                                                                                                                        assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                        
                                                                                                                                                                        vector.setEntry(1, -6.0);
                                                                                                                                                                        assertEquals(6.0, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_WithVerySmallValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{1e-300, -2e-300, 3e-300});
                                                                                                                                                                        assertEquals(3e-300, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetLInfNorm_WithVeryLargeValues() {
                                                                                                                                                                        ArrayRealVector vector = new ArrayRealVector(new double[]{1e300, -2e300, 3e300});
                                                                                                                                                                        assertEquals(3e300, vector.getLInfNorm(), 0.0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithPositiveValues() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {1.0, 2.0, 4.0, 8.0};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                RealVector result = vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result); // Should return self
                                                                                                                                                                assertEquals(1.0, result.getEntry(0), 1e-15);
                                                                                                                                                                assertEquals(0.5, result.getEntry(1), 1e-15);
                                                                                                                                                                assertEquals(0.25, result.getEntry(2), 1e-15);
                                                                                                                                                                assertEquals(0.125, result.getEntry(3), 1e-15);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithNegativeValues() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {-1.0, -2.0, -4.0};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                RealVector result = vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result);
                                                                                                                                                                assertEquals(-1.0, result.getEntry(0), 1e-15);
                                                                                                                                                                assertEquals(-0.5, result.getEntry(1), 1e-15);
                                                                                                                                                                assertEquals(-0.25, result.getEntry(2), 1e-15);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithMixedValues() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {1.0, -2.0, 0.5, -0.25};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                RealVector result = vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result);
                                                                                                                                                                assertEquals(1.0, result.getEntry(0), 1e-15);
                                                                                                                                                                assertEquals(-0.5, result.getEntry(1), 1e-15);
                                                                                                                                                                assertEquals(2.0, result.getEntry(2), 1e-15);
                                                                                                                                                                assertEquals(-4.0, result.getEntry(3), 1e-15);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithEmptyVector() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                RealVector result = vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result);
                                                                                                                                                                assertEquals(0, result.getDimension());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithVerySmallValues() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {Double.MIN_VALUE, Double.MIN_NORMAL};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result);
                                                                                                                                                                assertEquals(1.0 / Double.MIN_VALUE, result.getEntry(0), 1e-15);
                                                                                                                                                                assertEquals(1.0 / Double.MIN_NORMAL, result.getEntry(1), 1e-15);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithVeryLargeValues() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {Double.MAX_VALUE, -Double.MAX_VALUE};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                RealVector result = vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result);
                                                                                                                                                                assertEquals(1.0 / Double.MAX_VALUE, result.getEntry(0), 1e-15);
                                                                                                                                                                assertEquals(-1.0 / Double.MAX_VALUE, result.getEntry(1), 1e-15);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithNaNValues() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {1.0, Double.NaN, 2.0};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                RealVector result = vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result);
                                                                                                                                                                assertEquals(1.0, result.getEntry(0), 1e-15);
                                                                                                                                                                assertTrue(Double.isNaN(result.getEntry(1)));
                                                                                                                                                                assertEquals(0.5, result.getEntry(2), 1e-15);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testMapInvToSelf_WithInfiniteValues() {
                                                                                                                                                                // Setup
                                                                                                                                                                double[] testData = {1.0, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
                                                                                                                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                RealVector result = vector.mapInvToSelf();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertSame(vector, result);
                                                                                                                                                                assertEquals(1.0, result.getEntry(0), 1e-15);
                                                                                                                                                                assertEquals(0.0, result.getEntry(1), 1e-15);
                                                                                                                                                                assertEquals(-0.0, result.getEntry(2), 1e-15);
                                                                                                                                                            }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                                            public void testMutatedCopyThrowsException() {
                                                                                                                                                                // This test would only pass with the mutated version
                                                                                                                                                                double[] testData = {1.0, 2.0, 3.0};
                                                                                                                                                                ArrayRealVector original = new ArrayRealVector(testData);
                                                                                                                                                                
                                                                                                                                                                // In the mutated version, this would throw ArrayIndexOutOfBoundsException
                                                                                                                                                                // when trying to access data[data.length]
                                                                                                                                                                original.copy();
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testCopyDoesNotExceedArrayBounds() {
                                                                                                                                                        // Create a vector with some data
                                                                                                                                                        double[] testData = {1.0, 2.0, 3.0};
                                                                                                                                                        ArrayRealVector original = new ArrayRealVector(testData);
                                                                                                                                                        
                                                                                                                                                        // This should not throw an exception
                                                                                                                                                        AbstractRealVector copy = original.copy();
                                                                                                                                                        
                                                                                                                                                        // Verify the copy is correct
                                                                                                                                                        assertNotSame("Should be a different array instance", 
                                                                                                                                                                     original.getDataRef(), ((ArrayRealVector)copy).getDataRef());
                                                                                                                                                        assertEquals("Should have same length", 
                                                                                                                                                                    original.getDimension(), copy.getDimension());
                                                                                                                                                        assertArrayEquals("Data should be identical", 
                                                                                                                                                                        original.getData(), ((ArrayRealVector)copy).getData(), 0.0);
                                                                                                                                                    }

    @Test
                                                                                                                                            public void testCopyPreservesAllElements() {
                                                                                                                                                // Create original vector with known values
                                                                                                                                                double[] originalData = {1.0, 2.0, 3.0, 4.0}; // First element is important
                                                                                                                                                ArrayRealVector original = new ArrayRealVector(originalData);
                                                                                                                                                
                                                                                                                                                // Make a copy
                                                                                                                                                ArrayRealVector copy = (ArrayRealVector) original.copy();
                                                                                                                                                
                                                                                                                                                // Verify all elements were copied correctly
                                                                                                                                                assertEquals("First element not copied correctly", 
                                                                                                                                                             1.0, copy.getEntry(0), 0.0001);
                                                                                                                                                assertEquals("Second element not copied correctly", 
                                                                                                                                                             2.0, copy.getEntry(1), 0.0001);
                                                                                                                                                assertEquals("Third element not copied correctly", 
                                                                                                                                                             3.0, copy.getEntry(2), 0.0001);
                                                                                                                                                assertEquals("Fourth element not copied correctly", 
                                                                                                                                                             4.0, copy.getEntry(3), 0.0001);
                                                                                                                                                
                                                                                                                                                // Also verify the arrays are not the same reference
                                                                                                                                                assertNotSame("Data arrays should be different instances", 
                                                                                                                                                             original.getDataRef(), copy.getDataRef());
                                                                                                                                            }

    @Test
                                                                                                                                    public void testCopyShouldCopyAllElementsIncludingLast() {
                                                                                                                                        // Test with single element vector (edge case)
                                                                                                                                        double[] singleElementData = {5.0};
                                                                                                                                        ArrayRealVector singleElementVector = new ArrayRealVector(singleElementData);
                                                                                                                                        RealVector singleElementCopy = singleElementVector.copy();
                                                                                                                                        assertEquals(1, singleElementCopy.getDimension());
                                                                                                                                        assertEquals(5.0, singleElementCopy.getEntry(0), 0.0001);
                                                                                                                                        
                                                                                                                                        // Test with multiple elements
                                                                                                                                        double[] multiElementData = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                                                                        ArrayRealVector multiElementVector = new ArrayRealVector(multiElementData);
                                                                                                                                        RealVector multiElementCopy = multiElementVector.copy();
                                                                                                                                        
                                                                                                                                        // Verify all elements are copied, especially the last one
                                                                                                                                        assertEquals(multiElementData.length, multiElementCopy.getDimension());
                                                                                                                                        for (int i = 0; i < multiElementData.length; i++) {
                                                                                                                                            assertEquals(multiElementData[i], multiElementCopy.getEntry(i), 0.0001);
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Explicitly verify the last element
                                                                                                                                        assertEquals(multiElementData[multiElementData.length - 1], 
                                                                                                                                                    multiElementCopy.getEntry(multiElementData.length - 1), 
                                                                                                                                                    0.0001);
                                                                                                                                    }

    @Test
                                                                                                                            public void testCopyCreatesDeepCopyWithCorrectData() {
                                                                                                                                // Create a mock RealVector with specific behavior
                                                                                                                                RealVector originalVector = mock(RealVector.class);
                                                                                                                                when(originalVector.getDimension()).thenReturn(3);
                                                                                                                                when(originalVector.getEntry(0)).thenReturn(1.0);
                                                                                                                                when(originalVector.getEntry(1)).thenReturn(2.0);
                                                                                                                                when(originalVector.getEntry(2)).thenReturn(3.0);
                                                                                                                            
                                                                                                                                // Create the original ArrayRealVector from the mock
                                                                                                                                ArrayRealVector original = new ArrayRealVector(originalVector);
                                                                                                                                
                                                                                                                                // Make the copy and cast to ArrayRealVector
                                                                                                                                ArrayRealVector copy = (ArrayRealVector) original.copy();
                                                                                                                                
                                                                                                                                // Verify the copy is a new object
                                                                                                                                assertNotSame(original, copy);
                                                                                                                                
                                                                                                                                // Verify the data was copied correctly
                                                                                                                                assertEquals(3, copy.getDimension());
                                                                                                                                assertEquals(1.0, copy.getEntry(0), 0.0001);
                                                                                                                                assertEquals(2.0, copy.getEntry(1), 0.0001);
                                                                                                                                assertEquals(3.0, copy.getEntry(2), 0.0001);
                                                                                                                                
                                                                                                                                // Verify the exact sequence of calls to getEntry()
                                                                                                                                // This would detect if the loop increment was changed in a way that affects call order
                                                                                                                                verify(originalVector, times(1)).getEntry(0);
                                                                                                                                verify(originalVector, times(1)).getEntry(1);
                                                                                                                                verify(originalVector, times(1)).getEntry(2);
                                                                                                                                verifyNoMoreInteractions(originalVector);
                                                                                                                            }

    @Test
                                                                                                                            public void testCopyWithEmptyVector() {
                                                                                                                                // Test edge case with empty vector
                                                                                                                                ArrayRealVector original = new ArrayRealVector(new double[0]);
                                                                                                                                AbstractRealVector copy = original.copy();
                                                                                                                                
                                                                                                                                assertNotSame(original, copy);
                                                                                                                                assertEquals(0, copy.getDimension());
                                                                                                                            }

    @Test
                                                                                                                            public void testCopyIsIndependent() {
                                                                                                                                // Test that modifications to copy don't affect original
                                                                                                                                double[] data = {1.0, 2.0, 3.0};
                                                                                                                                ArrayRealVector original = new ArrayRealVector(data);
                                                                                                                                RealVector copy = original.copy();  // Changed to RealVector type
                                                                                                                                
                                                                                                                                // Modify the copy
                                                                                                                                copy.setEntry(0, 5.0);
                                                                                                                                
                                                                                                                                // Verify original unchanged
                                                                                                                                assertEquals(1.0, original.getEntry(0), 0.0001);
                                                                                                                                assertEquals(5.0, copy.getEntry(0), 0.0001);
                                                                                                                            }

    @Test
                                                                                                                    public void testCopyTrigonometricOperations() {
                                                                                                                        // Create a vector with a value where atan and asin differ
                                                                                                                        double[] originalData = {0.5};
                                                                                                                        ArrayRealVector originalVector = new ArrayRealVector(originalData);
                                                                                                                        
                                                                                                                        // Make a copy and cast to ArrayRealVector
                                                                                                                        ArrayRealVector copiedVector = (ArrayRealVector) originalVector.copy();
                                                                                                                        
                                                                                                                        // Apply atan to the original (expected behavior)
                                                                                                                        double expected = Math.atan(originalData[0]);
                                                                                                                        
                                                                                                                        // The mutation would apply asin instead of atan
                                                                                                                        // So we need to verify the trigonometric operation was applied correctly
                                                                                                                        // Since we don't see the exact mutated method, we'll test a scenario where
                                                                                                                        // the copy operation might apply trigonometric functions
                                                                                                                        
                                                                                                                        // If the mutation exists, the copied vector's data would have asin(0.5) instead of atan(0.5)
                                                                                                                        // So we need to verify the values are different
                                                                                                                        assertNotEquals("Copy should not use asin instead of atan", 
                                                                                                                                       Math.asin(originalData[0]), 
                                                                                                                                       copiedVector.getDataRef()[0], 
                                                                                                                                       0.0001);
                                                                                                                        
                                                                                                                        // Verify the correct value (atan) is present
                                                                                                                        assertEquals("Copy should use atan", 
                                                                                                                                     expected, 
                                                                                                                                     copiedVector.getDataRef()[0], 
                                                                                                                                     0.0001);
                                                                                                                    }

    @Test
                                                                                                        public void testCopyPreservesAtanOperation() {
                                                                                                            // Create a vector with known values that would produce different results for atan vs tan
                                                                                                            double[] testData = {0.5, 1.0, 1.5};
                                                                                                            ArrayRealVector original = new ArrayRealVector(testData);
                                                                                                            
                                                                                                            // Apply mapAtanToSelf which should use Math.atan internally
                                                                                                            original.mapAtanToSelf();
                                                                                                            
                                                                                                            // Create a copy of the vector after atan operation
                                                                                                            RealVector copy = original.copy();
                                                                                                            
                                                                                                            // Verify the copy contains the correct atan values
                                                                                                            double[] expected = new double[testData.length];
                                                                                                            for (int i = 0; i < testData.length; i++) {
                                                                                                                expected[i] = Math.atan(testData[i]);
                                                                                                            }
                                                                                                            
                                                                                                            // This will fail if the mutation (using tan instead of atan) is present
                                                                                                            assertArrayEquals(expected, copy.getData(), 1e-10);
                                                                                                            
                                                                                                            // Additional check to ensure it's not using tan
                                                                                                            double[] wrongValuesIfUsingTan = new double[testData.length];
                                                                                                            for (int i = 0; i < testData.length; i++) {
                                                                                                                wrongValuesIfUsingTan[i] = Math.tan(testData[i]);
                                                                                                            }
                                                                                                            for (int i = 0; i < testData.length; i++) {
                                                                                                                assertNotEquals(wrongValuesIfUsingTan[i], copy.getEntry(i), 1e-10);
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                        public void testMapAtanToSelfDetectsSignMutation() {
                                                                                                            // Create a test vector with both positive and negative values
                                                                                                            double[] testData = {1.0, -1.0, 0.5, -0.5, 0.0};
                                                                                                            ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                            
                                                                                                            // Make a copy for comparison
                                                                                                            ArrayRealVector originalCopy = new ArrayRealVector(vector, true);
                                                                                                            
                                                                                                            // Apply the atan operation
                                                                                                            vector.mapAtanToSelf();
                                                                                                            
                                                                                                            // Verify each element
                                                                                                            for (int i = 0; i < testData.length; i++) {
                                                                                                                double expected = Math.atan(originalCopy.getEntry(i));
                                                                                                                double actual = vector.getEntry(i);
                                                                                                                
                                                                                                                // This will fail if the mutation (atan(-x)) is present
                                                                                                                assertEquals("Element at index " + i + " differs", expected, actual, 1e-10);
                                                                                                                
                                                                                                                // Additional check to specifically catch the sign mutation
                                                                                                                if (originalCopy.getEntry(i) != 0) {
                                                                                                                    assertEquals("Sign of element at index " + i + " is wrong", 
                                                                                                                                Math.signum(originalCopy.getEntry(i)), 
                                                                                                                                Math.signum(actual), 
                                                                                                                                1e-10);
                                                                                                                }
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                    public void testMapAtanToSelfDetectsMutant() {
                                                                                                        // Create a vector with test data
                                                                                                        double[] testData = {0.0, 0.5, 1.0, -0.5, -1.0};
                                                                                                        ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                                        
                                                                                                        // Make a copy for comparison
                                                                                                        ArrayRealVector originalCopy = new ArrayRealVector(vector, true);
                                                                                                        
                                                                                                        // Apply atan operation
                                                                                                        vector.mapAtanToSelf();
                                                                                                        
                                                                                                        // Verify each element was transformed correctly
                                                                                                        for (int i = 0; i < testData.length; i++) {
                                                                                                            double expected = Math.atan(testData[i]);
                                                                                                            double actual = vector.getEntry(i);
                                                                                                            assertEquals("Element at index " + i + " should be atan of original value", 
                                                                                                                         expected, actual, 0.0001);
                                                                                                        }
                                                                                                        
                                                                                                        // Additional check that the original data wasn't modified
                                                                                                        for (int i = 0; i < testData.length; i++) {
                                                                                                            assertEquals("Original data should remain unchanged",
                                                                                                                        testData[i], originalCopy.getEntry(i), 0.0001);
                                                                                                        }
                                                                                                    }

    @Test
                                                                                        public void testMapAtanToSelfDetectsMutation() {
                                                                                            // Create a vector with test values
                                                                                            double[] testData = {0.5, 1.0, 1.5, -0.5};
                                                                                            ArrayRealVector vector = new ArrayRealVector(testData);
                                                                                            
                                                                                            // Make a copy for comparison using the ArrayRealVector constructor
                                                                                            ArrayRealVector originalCopy = new ArrayRealVector(vector.getDataRef());
                                                                                            
                                                                                            // Apply atan operation
                                                                                            vector.mapAtanToSelf();
                                                                                            
                                                                                            // Verify each element was transformed correctly
                                                                                            for (int i = 0; i < testData.length; i++) {
                                                                                                double expected = Math.atan(originalCopy.getEntry(i));
                                                                                                double actual = vector.getEntry(i);
                                                                                                assertEquals("Element at index " + i + " should be atan of original value",
                                                                                                             expected, actual, 1e-10);
                                                                                            }
                                                                                        }

    @Test
                                                                                public void testCopyPreservesElementWiseAtanValues() {
                                                                                    // Create original vector with various values that have non-zero arctangent
                                                                                    double[] originalData = {1.0, -1.0, 0.5, -0.5, 10.0, -10.0};
                                                                                    ArrayRealVector originalVector = new ArrayRealVector(originalData);
                                                                                    
                                                                                    // Make a copy - cast to ArrayRealVector since copy() returns AbstractRealVector
                                                                                    ArrayRealVector copiedVector = (ArrayRealVector) originalVector.copy();
                                                                                    
                                                                                    // Verify the copy has the expected values (atan of original elements)
                                                                                    for (int i = 0; i < originalData.length; i++) {
                                                                                        double expected = Math.atan(originalData[i]);
                                                                                        double actual = copiedVector.getEntry(i);
                                                                                        assertEquals("Element at index " + i + " should be atan of original value", 
                                                                                                     expected, actual, 1e-10);
                                                                                    }
                                                                                }

    @Test
                                                                        public void testCopyPreservesOriginalAtanBehavior() {
                                                                            // Create a vector with test data where atan(x) != atan(1/x)
                                                                            double[] testData = {0.5, 1.0, 2.0};
                                                                            ArrayRealVector original = new ArrayRealVector(testData);
                                                                            
                                                                            // Perform mapAtan operation (where the mutation would occur)
                                                                            // Changed to use RealVector type for the mapped variable
                                                                            RealVector mapped = original.copy().mapAtanToSelf();
                                                                            
                                                                            // Verify the mapping used atan(x) not atan(1/x)
                                                                            double delta = 1e-15; // tolerance for floating point comparisons
                                                                            assertEquals(Math.atan(0.5), mapped.getEntry(0), delta);
                                                                            assertEquals(Math.atan(1.0), mapped.getEntry(1), delta);
                                                                            assertEquals(Math.atan(2.0), mapped.getEntry(2), delta);
                                                                            
                                                                            // Also verify these are different from the mutated version
                                                                            assertNotEquals(Math.atan(1/0.5), mapped.getEntry(0), delta);
                                                                            assertNotEquals(Math.atan(1/1.0), mapped.getEntry(1), delta);
                                                                            assertNotEquals(Math.atan(1/2.0), mapped.getEntry(2), delta);
                                                                        }

    @Test
                                                                public void testCopyReturnsNonNullVector() {
                                                                    // Create a sample vector with test data
                                                                    double[] testData = {1.0, 2.0, 3.0};
                                                                    ArrayRealVector original = new ArrayRealVector(testData);
                                                                    
                                                                    // Call the copy method and cast to ArrayRealVector
                                                                    ArrayRealVector copy = (ArrayRealVector) original.copy();
                                                                    
                                                                    // Verify the copy is not null
                                                                    assertNotNull("Copy should not be null", copy);
                                                                    
                                                                    // Verify it's a different object
                                                                    assertNotSame("Copy should be a different instance", original, copy);
                                                                    
                                                                    // Verify the data is equal
                                                                    assertArrayEquals("Copy should have same data", 
                                                                                     original.getDataRef(), 
                                                                                     copy.getDataRef(), 
                                                                                     0.0);
                                                                }

    @Test
                                                        public void testCopyMethodWithDataMutation() {
                                                            // Setup original vector with test data
                                                            double[] testData = {1.0, 2.0, 3.0, 4.0};
                                                            ArrayRealVector original = new ArrayRealVector(testData);
                                                            
                                                            // Create copy with cast
                                                            ArrayRealVector copy = (ArrayRealVector) original.copy();
                                                            
                                                            // Verify the copy is not the same object
                                                            assertNotSame("Copy should be a different object", original, copy);
                                                            
                                                            // Verify data array is deep copied
                                                            assertNotSame("Data array should be cloned", original.getDataRef(), copy.getDataRef());
                                                            
                                                            // Verify data content is identical
                                                            assertArrayEquals("Data content should match", 
                                                                             original.getData(), 
                                                                             copy.getData(), 
                                                                             0.000001);
                                                            
                                                            // Modify original to ensure copy is independent
                                                            original.setEntry(0, 99.0);
                                                            assertEquals("Original modification should not affect copy",
                                                                         1.0, copy.getEntry(0), 0.000001);
                                                            
                                                            // Test with empty vector (edge case)
                                                            ArrayRealVector emptyOriginal = new ArrayRealVector();
                                                            ArrayRealVector emptyCopy = (ArrayRealVector) emptyOriginal.copy();
                                                            assertEquals("Empty vector copy should have zero length",
                                                                         0, emptyCopy.getDimension());
                                                        }

    @Test
                                                public void testCopyReturnsNewInstance() {
                                                    // Create original vector with sample data
                                                    double[] sampleData = {1.0, 2.0, 3.0};
                                                    ArrayRealVector original = new ArrayRealVector(sampleData);
                                                    
                                                    // Call copy method - cast the result to ArrayRealVector
                                                    ArrayRealVector copy = (ArrayRealVector) original.copy();
                                                    
                                                    // Verify copy is not null (would catch the mutant returning null)
                                                    assertNotNull("Copy should not be null", copy);
                                                    
                                                    // Verify it's a different object instance
                                                    assertNotSame("Copy should be a different instance", original, copy);
                                                    
                                                    // Verify content is equal
                                                    assertArrayEquals("Copy should have same data", 
                                                                    original.getDataRef(), 
                                                                    copy.getDataRef(), 
                                                                    0.0);
                                                    
                                                    // Verify modifying copy doesn't affect original
                                                    copy.setEntry(0, 99.0);
                                                    assertEquals("Original should not be modified", 
                                                                1.0, original.getEntry(0), 0.0);
                                                }

    @Test
                                                public void testCopyMethodDocumentation() throws Exception {
                                                    // Get the copy method
                                                    Method copyMethod = ArrayRealVector.class.getMethod("copy");
                                                    
                                                    // Get the method's Javadoc
                                                    String javadoc = copyMethod.getAnnotation(Override.class) != null ? 
                                                                     copyMethod.getDeclaredAnnotation(Override.class).toString() : "";
                                                    
                                                    // Verify the Javadoc is properly closed
                                                    assertTrue("Method documentation should be properly closed", 
                                                              copyMethod.getDeclaredAnnotations().length > 0);
                                                    assertTrue("Javadoc should contain proper closing */", 
                                                              javadoc.contains("*/") || 
                                                              (copyMethod.getDeclaredAnnotations()[0].toString().contains("*/")));
                                                }

    @Test
                                        public void testCopyCreatesNewIndependentInstance() {
                                            double[] testData = {1.0, 2.0, 3.0};
                                            ArrayRealVector original = new ArrayRealVector(testData);
                                            AbstractRealVector copy = original.copy();
                                            
                                            // Verify it's a different object
                                            assertNotSame(original, copy);
                                            
                                            // Verify data equality
                                            assertEquals(original.getDimension(), copy.getDimension());
                                            for (int i = 0; i < original.getDimension(); i++) {
                                                assertEquals(original.getEntry(i), copy.getEntry(i), 0.0);
                                            }
                                            
                                            // Verify independence
                                            original.setEntry(0, 99.0);
                                            assertNotEquals(original.getEntry(0), copy.getEntry(0), 0.0);
                                        }

    @Test
                                public void testCopyMethodDocumentation1() throws Exception {
                                    // Get the copy method
                                    Method copyMethod = ArrayRealVector.class.getMethod("copy");
                                    
                                    // Get the method's JavaDoc
                                    String javaDoc = copyMethod.getAnnotation(Override.class) != null ? 
                                        copyMethod.getDeclaredAnnotation(Override.class).toString() : "";
                                    
                                    // Verify the documentation uses standard {@inheritDoc} tag
                                    assertTrue("Method documentation should use standard {@inheritDoc} tag", 
                                        javaDoc.contains("{@inheritDoc}"));
                                    
                                    // Additionally verify the method behaves correctly
                                    ArrayRealVector original = new ArrayRealVector(new double[]{1.0, 2.0, 3.0});
                                    ArrayRealVector copy = (ArrayRealVector) original.copy();
                                    
                                    // Verify it's a different object
                                    assertNotSame("Copy should be a different object", original, copy);
                                    
                                    // Verify data equality
                                    assertEquals(original.getDimension(), copy.getDimension());
                                    for (int i = 0; i < original.getDimension(); i++) {
                                        assertEquals(original.getEntry(i), copy.getEntry(i), 0.0);
                                    }
                                    
                                    // Verify it's a deep copy by modifying original
                                    original.setEntry(0, 5.0);
                                    assertNotEquals(original.getEntry(0), copy.getEntry(0), 0.0);
                                }

    @Test
                                public void testCopyMethodDocumentation2() throws Exception {
                                    // Get the copy method
                                    Method copyMethod = ArrayRealVector.class.getMethod("copy");
                                    
                                    // Get the method's Javadoc comment
                                    String javadoc = copyMethod.getAnnotation(Override.class) != null ? 
                                        copyMethod.getDeclaredAnnotation(Override.class).toString() : "";
                                    
                                    // Verify the documentation contains the correct inheritDoc tag
                                    assertTrue("Method documentation should contain proper inheritDoc tag",
                                              javadoc.contains("{@inheritDoc}"));
                                    
                                    // Additional verification that it doesn't contain the mutant version
                                    assertFalse("Method documentation should not contain incorrect inheritDoc tag",
                                               javadoc.contains("{@inheritdoc}"));
                                }

    @Test
                    public void testCopyCreatesDeepCopy() {
                        // Setup original vector with test data
                        double[] testData = {1.0, 2.0, 3.0};
                        ArrayRealVector original = new ArrayRealVector(testData);
                        
                        // Create copy
                        ArrayRealVector copy = (ArrayRealVector) original.copy();
                        
                        // Verify it's a different object
                        assertNotSame("Copy should be a different object", original, copy);
                        
                        // Verify data is equal
                        assertArrayEquals("Data should be equal", original.getDataRef(), copy.getDataRef(), 0.0);
                        
                        // Verify it's a deep copy by modifying original and checking copy remains unchanged
                        original.setEntry(0, 99.0);
                        assertEquals("Modifying original should not affect copy", 
                                     1.0, copy.getEntry(0), 0.0);
                        
                        // Verify modifying copy doesn't affect original
                        copy.setEntry(1, 100.0);
                        assertEquals("Modifying copy should not affect original",
                                    2.0, original.getEntry(1), 0.0);
                    }

    @Test
            public void testCopyCreatesDeepCopy1() {
                // Create original vector with some data
                double[] originalData = {1.0, 2.0, 3.0};
                ArrayRealVector original = new ArrayRealVector(originalData);
                
                // Create a copy
                ArrayRealVector copy = (ArrayRealVector) original.copy();
                
                // Verify they have same values initially
                assertArrayEquals(original.getDataRef(), copy.getDataRef(), 0.0001);
                
                // Modify original data
                original.setEntry(0, 5.0);
                
                // Verify copy wasn't affected
                assertEquals(1.0, copy.getEntry(0), 0.0001);
                assertNotEquals(original.getEntry(0), copy.getEntry(0), 0.0001);
            }

    @Test
            public void testCopyWithEmptyVector1() {
                ArrayRealVector original = new ArrayRealVector();
                ArrayRealVector copy = (ArrayRealVector) original.copy();
                
                assertEquals(0, copy.getDimension());
                assertArrayEquals(original.getDataRef(), copy.getDataRef(), 0.0001);
            }

    @Test
            public void testCopyWithSingleElement() {
                ArrayRealVector original = new ArrayRealVector(new double[]{42.0});
                ArrayRealVector copy = (ArrayRealVector) original.copy();
                
                assertEquals(1, copy.getDimension());
                assertEquals(42.0, copy.getEntry(0), 0.0001);
            }

    @Test
            public void testCopyIsNewInstance() {
                ArrayRealVector original = new ArrayRealVector(new double[]{1.0, 2.0});
                ArrayRealVector copy = (ArrayRealVector) original.copy();
                
                assertNotSame(original, copy);
            }

    @Test
    public void testCopyTrigonometricOperations1() {
        // Create test data that would show differences between atan and atan2
        double[] testData = {0.0, 1.0, -1.0, 2.0, -2.0, Double.MAX_VALUE};
        ArrayRealVector original = new ArrayRealVector(testData);
        
        // Apply mapAtanToSelf to original
        original.mapAtanToSelf();
        double[] originalResults = original.toArray();
        
        // Create a copy and apply mutated version (map using atan2)
        ArrayRealVector copy = (ArrayRealVector) original.copy();
        for (int i = 0; i < copy.getDimension(); i++) {
            copy.setEntry(i, Math.atan2(testData[i], 1.0));
        }
        double[] mutatedResults = copy.toArray();
        
        // Verify the results are different for values where atan != atan2
        assertNotEquals("Results should differ for x=2.0", 
            originalResults[3], mutatedResults[3], 0.0001);
        assertNotEquals("Results should differ for x=-2.0", 
            originalResults[4], mutatedResults[4], 0.0001);
        assertNotEquals("Results should differ for large values", 
            originalResults[5], mutatedResults[5], 0.0001);
            
        // For x=1 and x=-1, results should be similar (atan(1) ≈ atan2(1,1))
        assertEquals(originalResults[1], mutatedResults[1], 0.0001);
        assertEquals(originalResults[2], mutatedResults[2], 0.0001);
    }


}
