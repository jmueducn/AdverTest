package gentest.org.apache.commons.math3.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testReciprocal_NaN() {
            Complex complex = new Complex(Double.NaN, Double.NaN);
            Complex result = complex.reciprocal();
            assertTrue(result.isNaN());
        }

    @Test
        public void testReciprocal_Zero() {
            Complex complex = new Complex(0.0, 0.0);
            Complex result = complex.reciprocal();
            assertEquals(Complex.INF, result);
        }

    @Test
        public void testReciprocal_Infinite() {
            Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
            Complex result = complex.reciprocal();
            assertEquals(Complex.ZERO, result);
        }

    @Test
        public void testReciprocal_RealDominant() {
            Complex complex = new Complex(2.0, 1.0); // real > imaginary
            Complex result = complex.reciprocal();
            assertEquals(0.4, result.getReal(), 1e-10);
            assertEquals(-0.2, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_ImaginaryDominant() {
            Complex complex = new Complex(1.0, 2.0); // imaginary > real
            Complex result = complex.reciprocal();
            assertEquals(0.2, result.getReal(), 1e-10);
            assertEquals(-0.4, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_RealOnly() {
            Complex complex = new Complex(5.0, 0.0);
            Complex result = complex.reciprocal();
            assertEquals(0.2, result.getReal(), 1e-10);
            assertEquals(0.0, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_ImaginaryOnly() {
            Complex complex = new Complex(0.0, 4.0);
            Complex result = complex.reciprocal();
            assertEquals(0.0, result.getReal(), 1e-10);
            assertEquals(-0.25, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_RealDominantNegative() {
            Complex complex = new Complex(-2.0, -1.0);
            Complex result = complex.reciprocal();
            assertEquals(-0.4, result.getReal(), 1e-10);
            assertEquals(0.2, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_ImaginaryDominantNegative() {
            Complex complex = new Complex(-1.0, -2.0);
            Complex result = complex.reciprocal();
            assertEquals(-0.2, result.getReal(), 1e-10);
            assertEquals(0.4, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_EdgeCaseVerySmallValues() {
            Complex complex = new Complex(Double.MIN_VALUE, Double.MIN_VALUE);
            Complex result = complex.reciprocal();
            // Should not be NaN or Infinite
            assertFalse(result.isNaN());
            assertFalse(result.isInfinite());
            // Values should be very large
            assertTrue(result.getReal() > Double.MAX_VALUE / 2);
            assertTrue(result.getImaginary() < -Double.MAX_VALUE / 2);
        }

}
