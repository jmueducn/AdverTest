package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Gamma;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class PoissonDistributionImplTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                            public void testConstructor_WithNegativeMean() {
                                // Test with negative mean (should throw exception)
                                double mean = -1.0;
                                
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("mean must be positive");
                                
                                new PoissonDistributionImpl(mean);
                            }

    @Test
                            public void testConstructor_WithNaNMean() {
                                // Test with NaN mean (should throw exception)
                                double mean = Double.NaN;
                                
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("mean must be positive");
                                
                                new PoissonDistributionImpl(mean);
                            }

    @Test
                            public void testConstructor_WithPositiveInfinityMean() {
                                // Test with positive infinity mean (should throw exception)
                                double mean = Double.POSITIVE_INFINITY;
                                
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("mean must be finite");
                                
                                new PoissonDistributionImpl(mean);
                            }

    @Test
                            public void testConstructor_ZeroMean() {
                                // Test with zero mean (should throw exception)
                                thrown.expect(NotStrictlyPositiveException.class);
                                thrown.expectMessage(LocalizedFormats.MEAN.toString());
                                
                                new PoissonDistributionImpl(0.0, 1e-12, 10000);
                            }

    @Test
                            public void testConstructor_NegativeMean() {
                                // Test with negative mean (should throw exception)
                                thrown.expect(NotStrictlyPositiveException.class);
                                thrown.expectMessage(LocalizedFormats.MEAN.toString());
                                
                                new PoissonDistributionImpl(-1.0, 1e-12, 10000);
                            }

    @Test
                            public void testConstructor_ValidParameters() {
                                // Test with typical valid parameters
                                double p = 5.0;
                                double epsilon = 1e-12;
                                
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon);
                                
                                // Verify mean is set correctly
                                assertEquals(p, distribution.getMean(), 0.0);
                                
                                // Verify epsilon is set correctly (might need reflection to test private field)
                                // Alternatively, if there's a getter, use that
                                
                                // Verify maxIterations is set to DEFAULT_MAX_ITERATIONS
                                // Would need reflection or a getter to verify this
                            }

    @Test
                            public void testConstructor_ZeroMean1() {
                                // Test with zero mean (edge case)
                                double p = 0.0;
                                double epsilon = 1e-12;
                                
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon);
                                
                                assertEquals(0.0, distribution.getMean(), 0.0);
                            }

    @Test
                            public void testConstructor_NegativeMean1() {
                                // Test with negative mean (should throw exception)
                                double p = -1.0;
                                double epsilon = 1e-12;
                                
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("mean must be positive");
                                
                                new PoissonDistributionImpl(p, epsilon);
                            }

    @Test
                            public void testConstructor_ZeroEpsilon() {
                                // Test with zero epsilon (edge case)
                                double p = 5.0;
                                double epsilon = 0.0;
                                
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("epsilon must be positive");
                                
                                new PoissonDistributionImpl(p, epsilon);
                            }

    @Test
                            public void testConstructor_NegativeEpsilon() {
                                // Test with negative epsilon
                                double p = 5.0;
                                double epsilon = -1e-12;
                                
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("epsilon must be positive");
                                
                                new PoissonDistributionImpl(p, epsilon);
                            }

    @Test
                            public void testConstructor_ExtremeEpsilon() {
                                // Test with extremely small epsilon
                                double p = 5.0;
                                double epsilon = Double.MIN_VALUE;
                                
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon);
                                
                                assertEquals(p, distribution.getMean(), 0.0);
                            }

    @Test
                            public void testConstructor_LargeMean() {
                                // Test with large mean value
                                double p = Double.MAX_VALUE / 2;
                                double epsilon = 1e-12;
                                
                                thrown.expect(IllegalArgumentException.class);
                                // Might throw due to internal calculations, exact message may vary
                                
                                new PoissonDistributionImpl(p, epsilon);
                            }

    @Test
                            public void testConstructor_NaNParameters() {
                                // Test with NaN parameters
                                double p = Double.NaN;
                                double epsilon = 1e-12;
                                
                                thrown.expect(IllegalArgumentException.class);
                                new PoissonDistributionImpl(p, epsilon);
                                
                                p = 5.0;
                                epsilon = Double.NaN;
                                
                                thrown.expect(IllegalArgumentException.class);
                                new PoissonDistributionImpl(p, epsilon);
                            }

    @Test
                            public void testConstructor_InfiniteParameters() {
                                // Test with infinite parameters
                                double p = Double.POSITIVE_INFINITY;
                                double epsilon = 1e-12;
                                
                                thrown.expect(IllegalArgumentException.class);
                                new PoissonDistributionImpl(p, epsilon);
                                
                                p = 5.0;
                                epsilon = Double.POSITIVE_INFINITY;
                                
                                thrown.expect(IllegalArgumentException.class);
                                new PoissonDistributionImpl(p, epsilon);
                            }

    @Test
                            public void testConstructor_ValidParameters1() {
                                // Arrange
                                double p = 5.0;
                                int maxIterations = 1000;
                                
                                // Act
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, maxIterations);
                                
                                // Assert
                                assertEquals(p, distribution.getMean(), 0.0);
                                // Since we can't directly access private fields, we test through available methods
                                // We assume getMean() reflects the mean field
                            }

    @Test
                            public void testConstructor_MaxAllowedIterations() {
                                // Arrange
                                double p = 3.0;
                                int maxIterations = PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS;
                                
                                // Act
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, maxIterations);
                                
                                // Assert
                                assertEquals(p, distribution.getMean(), 0.0);
                            }

    @Test
                            public void testConstructor_ZeroMean2() {
                                // Arrange
                                double p = 0.0;
                                int maxIterations = 100;
                                
                                // Act
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, maxIterations);
                                
                                // Assert
                                assertEquals(0.0, distribution.getMean(), 0.0);
                            }

    @Test
                            public void testConstructor_NegativeMean2() {
                                // Arrange
                                double p = -1.0;
                                int maxIterations = 100;
                                
                                // Expect exception
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("mean must be positive");
                                
                                // Act
                                new PoissonDistributionImpl(p, maxIterations);
                            }

    @Test
                            public void testConstructor_ZeroIterations() {
                                // Arrange
                                double p = 2.0;
                                int maxIterations = 0;
                                
                                // Expect exception
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("max iterations");
                                
                                // Act
                                new PoissonDistributionImpl(p, maxIterations);
                            }

    @Test
                            public void testConstructor_NegativeIterations() {
                                // Arrange
                                double p = 2.0;
                                int maxIterations = -1;
                                
                                // Expect exception
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("max iterations");
                                
                                // Act
                                new PoissonDistributionImpl(p, maxIterations);
                            }

    @Test
                            public void testConstructor_VerySmallMean() {
                                // Arrange
                                double p = Double.MIN_VALUE;
                                int maxIterations = 100;
                                
                                // Act
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, maxIterations);
                                
                                // Assert
                                assertEquals(p, distribution.getMean(), 0.0);
                            }

    @Test
                            public void testConstructor_VeryLargeMean() {
                                // Arrange
                                double p = Double.MAX_VALUE;
                                int maxIterations = Integer.MAX_VALUE;
                                
                                // Act
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, maxIterations);
                                
                                // Assert
                                assertEquals(p, distribution.getMean(), 0.0);
                            }

    @Test
                            public void testConstructor_UsesDefaultEpsilon() {
                                // Arrange
                                double p = 10.0;
                                int maxIterations = 1000;
                                
                                // Act
                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, maxIterations);
                                
                                // We can't directly test epsilon, but we can verify behavior through probability methods
                                // This is a bit indirect, but shows the constructor is properly delegating
                                assertTrue(distribution.probability(10) > 0);
                            }

    @Test
                    public void testConstructor_ValidParameters2() {
                        // Test with valid parameters
                        double mean = 5.0;
                        double epsilon = 1e-12;
                        int maxIterations = 10000;
                        
                        PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                        
                        assertEquals(mean, distribution.getMean(), 0.0);
                        
                        // Use reflection to access private normal field
                        try {
                            Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                            normalField.setAccessible(true);
                            NormalDistribution normal = (NormalDistribution) normalField.get(distribution);
                            
                            assertNotNull(normal);
                            assertEquals(mean, normal.getMean(), 0.0);
                            assertEquals(Math.sqrt(mean), normal.getStandardDeviation(), 0.0);
                        } catch (NoSuchFieldException | IllegalAccessException e) {
                            fail("Failed to access private field 'normal' through reflection");
                        }
                    }

    @Test
                    public void testConstructor_DefaultEpsilon() throws Exception {
                        // Test with default epsilon value
                        double mean = 3.0;
                        int maxIterations = 10000;
                        
                        PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, PoissonDistributionImpl.DEFAULT_EPSILON, maxIterations);
                        
                        // Use reflection to access private epsilon field
                        Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                        epsilonField.setAccessible(true);
                        double actualEpsilon = epsilonField.getDouble(distribution);
                        
                        assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, actualEpsilon, 0.0);
                    }

    @Test
                    public void testConstructor_DefaultMaxIterations() throws Exception {
                        // Test with default max iterations value
                        double mean = 4.0;
                        double epsilon = 1e-10;
                        
                        PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS);
                        
                        // Use reflection to access private field
                        Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                        maxIterationsField.setAccessible(true);
                        int actualMaxIterations = maxIterationsField.getInt(distribution);
                        
                        assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, actualMaxIterations);
                    }

    @Test
                    public void testConstructor_ZeroEpsilon1() throws Exception {
                        // Test with zero epsilon (edge case)
                        double mean = 2.0;
                        double epsilon = 0.0;
                        int maxIterations = 10000;
                        
                        PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                        
                        // Use reflection to access private epsilon field
                        Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                        epsilonField.setAccessible(true);
                        double actualEpsilon = epsilonField.getDouble(distribution);
                        
                        assertEquals(0.0, actualEpsilon, 0.0);
                    }

    @Test
                    public void testConstructor_NegativeEpsilon1() throws Exception {
                        // Test with negative epsilon (should be allowed)
                        double mean = 2.0;
                        double epsilon = -1e-12;
                        int maxIterations = 10000;
                        
                        PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                        
                        // Use reflection to access private epsilon field
                        Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                        epsilonField.setAccessible(true);
                        double actualEpsilon = epsilonField.getDouble(distribution);
                        
                        assertEquals(epsilon, actualEpsilon, 0.0);
                    }

    @Test
                    public void testConstructor_ZeroMaxIterations() throws Exception {
                        // Test with zero max iterations (edge case)
                        double mean = 1.5;
                        double epsilon = 1e-12;
                        int maxIterations = 0;
                        
                        PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                        
                        // Use reflection to access private field
                        Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                        maxIterationsField.setAccessible(true);
                        int actualMaxIterations = maxIterationsField.getInt(distribution);
                        
                        assertEquals(0, actualMaxIterations);
                    }

    @Test
                    public void testConstructor_NegativeMaxIterations() throws Exception {
                        // Test with negative max iterations (should be allowed)
                        double mean = 1.5;
                        double epsilon = 1e-12;
                        int maxIterations = -100;
                        
                        PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                        
                        // Use reflection to access private maxIterations field
                        Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                        maxIterationsField.setAccessible(true);
                        int actualMaxIterations = maxIterationsField.getInt(distribution);
                        
                        assertEquals(maxIterations, actualMaxIterations);
                    }

    @Test
                public void testConstructor_WithPositiveMean() {
                    // Test with typical positive mean value
                    double mean = 5.0;
                    
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    // Verify mean is set correctly
                    assertEquals(mean, distribution.getMean(), 0.0);
                    
                    // The class doesn't provide getEpsilon() or getMaxIterations() methods,
                    // so we can only test the mean value
                }

    @Test
                public void testConstructor_WithVerySmallPositiveMean() {
                    // Test with very small positive mean (edge case)
                    double mean = Double.MIN_VALUE;
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    assertEquals(mean, distribution.getMean(), 0.0);
                }

    @Test
                public void testConstructor_WithVeryLargeMean() {
                    // Test with very large mean value
                    double mean = Double.MAX_VALUE;
                    
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    assertEquals(mean, distribution.getMean(), 0.0);
                }

    @Test
            public void testConstructor_WithZeroMean() throws Exception {
                // Test with zero mean (edge case)
                double mean = 0.0;
                
                // Get the actual constants from the class using reflection
                Class<?> clazz = Class.forName("org.apache.commons.math.distribution.PoissonDistributionImpl");
                Field epsilonField = clazz.getDeclaredField("DEFAULT_EPSILON");
                epsilonField.setAccessible(true);
                double DEFAULT_EPSILON = epsilonField.getDouble(null);
                
                Field iterationsField = clazz.getDeclaredField("DEFAULT_MAX_ITERATIONS");
                iterationsField.setAccessible(true);
                int DEFAULT_MAX_ITERATIONS = iterationsField.getInt(null);
                
                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                
                // Get private fields through reflection
                Field epsilonDistField = clazz.getDeclaredField("epsilon");
                epsilonDistField.setAccessible(true);
                double actualEpsilon = epsilonDistField.getDouble(distribution);
                
                Field maxIterationsField = clazz.getDeclaredField("maxIterations");
                maxIterationsField.setAccessible(true);
                int actualMaxIterations = maxIterationsField.getInt(distribution);
                
                assertEquals(mean, distribution.getMean(), 0.0);
                assertEquals(DEFAULT_EPSILON, actualEpsilon, 0.0);
                assertEquals(DEFAULT_MAX_ITERATIONS, actualMaxIterations);
            }

    @Test
            public void testConstructorWithZeroMeanShouldThrowException() {
                // This test will fail if the mutant is present (p < 0 instead of p <= 0)
                thrown.expect(NotStrictlyPositiveException.class);
                thrown.expectMessage(LocalizedFormats.MEAN.toString());
                
                // Try to create with p = 0 which should throw exception in original code
                new PoissonDistributionImpl(0.0);
            }

    @Test
            public void testConstructorWithZeroMeanMutantBehavior() {
                // This is what would happen if mutant exists - no exception and mean = 0
                // Normally this test would fail for original code, but pass for mutant
                try {
                    PoissonDistributionImpl dist = new PoissonDistributionImpl(0.0);
                    assertEquals(0.0, dist.getMean(), 0.0);
                    fail("Expected NotStrictlyPositiveException not thrown");
                } catch (NotStrictlyPositiveException e) {
                    // Expected for original code
                    assertTrue(true);
                }
            }

    @Test
            public void testConstructorWithNegativeMean() {
                // Both original and mutant should throw for negative values
                thrown.expect(NotStrictlyPositiveException.class);
                new PoissonDistributionImpl(-1.0);
            }

    @Test
            public void testConstructorWithPositiveMean() {
                // Both original and mutant should work for positive values
                PoissonDistributionImpl dist = new PoissonDistributionImpl(5.0);
                assertEquals(5.0, dist.getMean(), 0.0);
            }

    @Test
        public void testConstructorWithNegativeMeanShouldThrowException() {
            // Test that constructor throws exception for negative mean (original behavior)
            thrown.expect(NotStrictlyPositiveException.class);
            new PoissonDistributionImpl(-1.0);
        }

    @Test
        public void testGetMeanWithNegativeValueShouldBeCaught() {
            // This test would catch the mutant by showing that negative values are allowed
            try {
                // Try to create with negative mean - should throw exception
                new PoissonDistributionImpl(-1.0);
                // If we get here, the mutant survived (no exception thrown)
                fail("Expected NotStrictlyPositiveException for negative mean");
            } catch (NotStrictlyPositiveException e) {
                // This is expected behavior for original code
                assertTrue(true);
            }
        }

    @Test
        public void testGetMeanWithZeroShouldThrowException() {
            // Test that both original and mutant throw exception for zero
            thrown.expect(NotStrictlyPositiveException.class);
            new PoissonDistributionImpl(0.0);
        }

    @Test
        public void testGetMeanWithPositiveValue() {
            // Sanity check for positive value
            double testMean = 5.0;
            PoissonDistributionImpl dist = new PoissonDistributionImpl(testMean);
            assertEquals(testMean, dist.getMean(), 0.0);
        }

}
