package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                    public void testIsFeasible_NullXWithBoundaries() throws Exception {
                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                        double[][] boundaries = new double[][] {{1.0, 2.0}, {2.0, 3.0}};
                                                                                                                                                        
                                                                                                                                                        // Get the private isFeasible method using reflection
                                                                                                                                                        Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class, double[][].class);
                                                                                                                                                        isFeasibleMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Invoke the method
                                                                                                                                                        isFeasibleMethod.invoke(optimizer, (Object)null, boundaries);
                                                                                                                                                    }

    @Test
                                                                                                                            public void testEncode_ZeroRangeBoundaries() {
                                                                                                                                // Setup
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                                                                                        100,                      // lambda
                                                                                                                                        new double[] {0.1, 0.1},   // inputSigma
                                                                                                                                        0,                         // maxIterations
                                                                                                                                        0.0,                       // stopFitness
                                                                                                                                        false,                     // isActiveCMA
                                                                                                                                        0,                         // diagonalOnly
                                                                                                                                        0,                         // checkFeasableCount
                                                                                                                                        new org.apache.commons.math3.random.JDKRandomGenerator(), // random
                                                                                                                                        false,                     // generateStatistics
                                                                                                                                        null                       // checker
                                                                                                                                    );
                                                                                                                                
                                                                                                                                // Using reflection to set boundaries
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field boundariesField = 
                                                                                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    double[][] boundaries = new double[][]{{1.0, 1.0}, {1.0, 1.0}}; // zero range
                                                                                                                                    boundariesField.set(optimizer, boundaries);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    org.junit.Assert.fail("Failed to set boundaries field via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = new double[]{1.0, 1.0};
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                try {
                                                                                                                                    org.junit.Assert.fail("Expected ArithmeticException");
                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                    // Expected exception
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testEncode_ArrayLengthMismatch() {
                                                                                                                                // Setup
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                                                                                
                                                                                                                                // Using reflection to set boundaries
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field boundariesField = 
                                                                                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    double[][] boundaries = {{0.0, 0.0}, {1.0, 1.0}}; // 2 elements
                                                                                                                                    boundariesField.set(optimizer, boundaries);
                                                                                                                                    
                                                                                                                                    // Also need to set inputSigma for the optimizer to work properly
                                                                                                                                    java.lang.reflect.Field inputSigmaField = 
                                                                                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("inputSigma");
                                                                                                                                    inputSigmaField.setAccessible(true);
                                                                                                                                    inputSigmaField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                } catch (Exception e) {
                                                                                                                                    org.junit.Assert.fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = {1.0, 2.0, 3.0}; // 3 elements
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                try {
                                                                                                                                    org.junit.Assert.fail("Expected ArrayIndexOutOfBoundsException");
                                                                                                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                    // Expected exception
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testIsFeasible_BelowLowerBound() {
                                                                                                                                // Create optimizer with default parameters
                                                                                                                                int lambda = 0;
                                                                                                                                double[] inputSigma = null;
                                                                                                                                int maxIterations = 10000;
                                                                                                                                double stopFitness = 0;
                                                                                                                                boolean isActiveCMA = true;
                                                                                                                                int diagonalOnly = 0;
                                                                                                                                int checkFeasableCount = 1;
                                                                                                                                org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                boolean generateStatistics = false;
                                                                                                                                
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                                                                                        lambda, inputSigma, maxIterations, 
                                                                                                                                        stopFitness, isActiveCMA, diagonalOnly, checkFeasableCount, 
                                                                                                                                        random, generateStatistics);
                                                                                                                                
                                                                                                                                // Set lower and upper bounds
                                                                                                                                double[] lowerBounds = {1.0, 1.0};
                                                                                                                                double[] upperBounds = {2.0, 3.0};
                                                                                                                                
                                                                                                                                // Create test data that's below lower bound
                                                                                                                                double[] x = {0.9, 2.5};
                                                                                                                                
                                                                                                                                // Test the method
                                                                                                                            }

    @Test
                                                                                                                            public void testIsFeasible_InconsistentDimensions() {
                                                                                                                                // Create optimizer with default constructor
                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                
                                                                                                                                // Set the dimension to 2 (different from our test array length of 3)
                                                                                                                                try {
                                                                                                                                    Field dimensionField = CMAESOptimizer.class.getDeclaredField("dimension");
                                                                                                                                    dimensionField.setAccessible(true);
                                                                                                                                    dimensionField.setInt(optimizer, 2);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set dimension field via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] x = {1.0, 2.0, 3.0};
                                                                                                                                
                                                                                                                                // Test the isFeasible method
                                                                                                                                try {
                                                                                                                                    fail("Expected DimensionMismatchException");
                                                                                                                                } catch (DimensionMismatchException e) {
                                                                                                                                    // Expected behavior
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                    public void testIsFeasible_WithinBounds() {
                                                                                                                        // Create optimizer with default constructor
                                                                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                            new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                                                                        
                                                                                                                        // Create spy
                                                                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer spyOptimizer = 
                                                                                                                            new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                                                                        
                                                                                                                        // Test input
                                                                                                                        double[] x = {1.5, 2.5};
                                                                                                                        double[][] boundaries = {{1.0, 2.0}, {2.0, 3.0}};
                                                                                                                        
                                                                                                                        // Use reflection to set the boundaries field since it might be private
                                                                                                                        try {
                                                                                                                            java.lang.reflect.Field boundariesField = 
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                            boundariesField.setAccessible(true);
                                                                                                                            boundariesField.set(spyOptimizer, boundaries);
                                                                                                                        } catch (Exception e) {
                                                                                                                            org.junit.Assert.fail("Failed to set boundaries through reflection: " + e.getMessage());
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test the isFeasible method using reflection since it might not be public
                                                                                                                        try {
                                                                                                                            java.lang.reflect.Method isFeasibleMethod = 
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                                            isFeasibleMethod.setAccessible(true);
                                                                                                                            boolean result = (boolean) isFeasibleMethod.invoke(spyOptimizer, x);
                                                                                                                            
                                                                                                                            // Assert that the point is within bounds
                                                                                                                            org.junit.Assert.assertTrue("Point should be within bounds", result);
                                                                                                                        } catch (Exception e) {
                                                                                                                            org.junit.Assert.fail("Failed to invoke isFeasible method: " + e.getMessage());
                                                                                                                        }
                                                                                                                    }

    @Test
                                                        public void testIsFeasible_ExactlyOnBoundary() {
                                                            // Create necessary mock objects and imports
                                                            org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                            org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> checker = 
                                                                new org.apache.commons.math3.optimization.SimpleValueChecker();
                                                            java.lang.reflect.Field boundariesField = null;
                                                            java.lang.reflect.Method isFeasibleMethod = null;
                                                            
                                                            // Create CMAESOptimizer with valid constructor parameters
                                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                    100,                      // lambda
                                                                    null,                     // inputSigma
                                                                    1000,                     // maxIterations
                                                                    1e-12,                    // stopFitness
                                                                    false,                    // isActiveCMA
                                                                    0,                        // diagonalOnly
                                                                    0,                        // checkFeasableCount
                                                                    random,                   // random
                                                                    false,                    // generateStatistics
                                                                    checker                   // checker
                                                                );
                                                            
                                                            double[][] boundaries = {{1.0, 2.0}, {2.0, 3.0}};
                                                            
                                                            // Need to set the boundaries for the optimizer
                                                            try {
                                                                boundariesField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                boundariesField.setAccessible(true);
                                                                boundariesField.set(optimizer, boundaries);
                                                                
                                                                // Get the isFeasible method
                                                                isFeasibleMethod = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                isFeasibleMethod.setAccessible(true);
                                                            } catch (Exception e) {
                                                                org.junit.Assert.fail("Failed to set up reflection: " + e.getMessage());
                                                            }
                                                            
                                                            // Test point exactly on boundary
                                                            double[] point = {1.0, 2.0};
                                                            boolean result = false;
                                                            try {
                                                                result = (boolean) isFeasibleMethod.invoke(optimizer, point);
                                                            } catch (Exception e) {
                                                                org.junit.Assert.fail("Failed to invoke isFeasible method: " + e.getMessage());
                                                            }
                                                            
                                                            // Assert that point on boundary is considered feasible
                                                            org.junit.Assert.assertTrue("Point on boundary should be feasible", result);
                                                        }

    @Test
                                            public void testDecode_WithMismatchedArrayLengths_ThrowsArrayIndexOutOfBoundsException() {
                                                // Set up
                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                double[] input = {0.5, 1.0, 1.5};
                                                
                                                try {
                                                    // Set boundaries field
                                                    java.lang.reflect.Field boundariesField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class
                                                        .getDeclaredField("boundaries");
                                                    boundariesField.setAccessible(true);
                                                    boundariesField.set(optimizer, new double[][] {
                                                        {10.0, 20.0},  // lower bounds (only 2 elements)
                                                        {20.0, 30.0}   // upper bounds (only 2 elements)
                                                    });
                                                    
                                                    // Set dimension field
                                                    java.lang.reflect.Field dimensionField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class
                                                        .getDeclaredField("dimension");
                                                    dimensionField.setAccessible(true);
                                                    dimensionField.setInt(optimizer, input.length);
                                                    
                                                    // Set inputSigma field to avoid NPE
                                                    java.lang.reflect.Field inputSigmaField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class
                                                        .getDeclaredField("inputSigma");
                                                    inputSigmaField.setAccessible(true);
                                                    inputSigmaField.set(optimizer, new double[input.length]);
                                                    
                                                    // Set isMinimize field to avoid NPE
                                                    java.lang.reflect.Field isMinimizeField = org.apache.commons.math3.optimization.direct.BaseAbstractMultivariateOptimizer.class
                                                        .getDeclaredField("minimize");
                                                    isMinimizeField.setAccessible(true);
                                                    isMinimizeField.setBoolean(optimizer, true);
                                                    
                                                    // Set startPoint field to avoid NPE
                                                    java.lang.reflect.Field startPointField = org.apache.commons.math3.optimization.direct.BaseAbstractMultivariateOptimizer.class
                                                        .getDeclaredField("startPoint");
                                                    startPointField.setAccessible(true);
                                                    startPointField.set(optimizer, new double[input.length]);
                                                } catch (Exception e) {
                                                    throw new RuntimeException("Failed to set up test fields", e);
                                                }
                                                
                                                // Expect exception
                                                try {
                                                    org.junit.Assert.fail("Expected ArrayIndexOutOfBoundsException");
                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                    // Expected exception
                                                }
                                            }

    @Test
                    public void testIsFeasible_AboveUpperBound() {
                        // Create optimizer with required parameters
                        int lambda = 4;  // population size
                        double[] inputSigma = new double[]{0.3, 0.3};  // initial standard deviations
                        int maxIterations = 100;
                        double stopFitness = 0.0;
                        boolean isActiveCMA = false;
                        int diagonalOnly = 0;
                        int checkFeasableCount = 0;
                        org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                        boolean generateStatistics = false;
                        
                        // Use the correct constructor that takes lambda and inputSigma
                        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                lambda,
                                inputSigma,
                                maxIterations,
                                stopFitness,
                                isActiveCMA,
                                diagonalOnly,
                                checkFeasableCount,
                                random,
                                generateStatistics,
                                new org.apache.commons.math3.optimization.SimpleValueChecker()
                            );
                        
                        double[] x = {1.5, 3.1};
                        double[][] boundaries = {{1.0, 2.0}, {2.0, 3.0}};
                        
                        // Set the boundaries using reflection
                        try {
                            java.lang.reflect.Field boundariesField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                            boundariesField.setAccessible(true);
                            boundariesField.set(optimizer, boundaries);
                        } catch (Exception e) {
                            org.junit.Assert.fail("Failed to set boundaries field: " + e.getMessage());
                        }
                        
                        // Test the isFeasible method using reflection since it might be private
                        try {
                            java.lang.reflect.Method isFeasibleMethod = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                            isFeasibleMethod.setAccessible(true);
                            boolean result = (boolean) isFeasibleMethod.invoke(optimizer, x);
                            org.junit.Assert.assertFalse("Point should not be feasible when above upper bound", result);
                        } catch (Exception e) {
                            org.junit.Assert.fail("Failed to invoke isFeasible method: " + e.getMessage());
                        }
                    }

    @Test
            public void testDecode_WithNegativeValues_ReturnsCorrectlyScaledValues() throws Exception {
                // Set up
                int lambda = 4;  // population size
                double[] inputSigma = null;  // default sigma values
                int maxIterations = 1000;
                double stopFitness = 0;
                boolean isActiveCMA = true;
                int diagonalOnly = 0;
                int checkFeasableCount = 1;
                org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                boolean generateStatistics = false;
                
                // Create optimizer with correct constructor
                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                        lambda, inputSigma, maxIterations, stopFitness, isActiveCMA,
                        diagonalOnly, checkFeasableCount, random, generateStatistics);
                
                double[] input = {-0.5, -1.0, 0.5};
                double[][] boundaries = {
                    {-10.0, -20.0, -30.0},  // lower bounds
                    {10.0, 20.0, 30.0}      // upper bounds
                };
                
                // Use reflection to set private boundaries field
                java.lang.reflect.Field boundariesField = 
                    org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                boundariesField.setAccessible(true);
                boundariesField.set(optimizer, boundaries);
                
                double[] expected = {
                    (10.0 - (-10.0)) * -0.5 + (-10.0),  // -10.0
                    (20.0 - (-20.0)) * -1.0 + (-20.0),  // -40.0
                    (30.0 - (-30.0)) * 0.5 + (-30.0)    // 0.0
                };
                
                // Get decode method via reflection and invoke it
                java.lang.reflect.Method decodeMethod = 
                    org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                decodeMethod.setAccessible(true);
                double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                
                // Verify
                org.junit.Assert.assertArrayEquals(expected, result, 0.0001);
            }

    @Test
        public void testDecode_WithZeroBoundaryDifference_ReturnsZeros() {
            // Set up
            int maxIterations = 1000;
            double stopFitness = 0;
            boolean isActiveCMA = true;
            int diagonalOnly = 0;
            int checkFeasableCount = 1;
            org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.MersenneTwister();
            boolean generateStatistics = false;
            int lambda = 10;
            double[] inputSigma = new double[]{0.5};
            
            // Create the optimizer with correct constructor
            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                    lambda,
                    inputSigma,
                    maxIterations,
                    stopFitness,
                    isActiveCMA,
                    diagonalOnly,
                    checkFeasableCount,
                    random,
                    generateStatistics,
                    new org.apache.commons.math3.optimization.SimpleValueChecker(1.0e-10, 1.0e-10));
            
            double[] input = {0.5, 1.0, 0.0};
            
            // Use reflection to set the private boundaries field
            try {
                java.lang.reflect.Field boundariesField = 
                    org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                boundariesField.setAccessible(true);
                boundariesField.set(optimizer, new double[][] {
                    {10.0, 20.0, 30.0},  // lower bounds
                    {10.0, 20.0, 30.0}   // upper bounds (same as lower)
                });
            } catch (NoSuchFieldException | IllegalAccessException e) {
                org.junit.Assert.fail("Failed to set boundaries field: " + e.getMessage());
            }
            
            double[] expected = {0.0, 0.0, 0.0};
            
            // Execute using reflection since decode is likely private
            double[] result;
            try {
                java.lang.reflect.Method decodeMethod = 
                    org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                decodeMethod.setAccessible(true);
                result = (double[]) decodeMethod.invoke(optimizer, input);
            } catch (Exception e) {
                org.junit.Assert.fail("Failed to invoke decode method: " + e.getMessage());
                return;
            }
            
            // Verify
            org.junit.Assert.assertArrayEquals(expected, result, 0.0001);
        }

    @Test
    public void testEncode_NullBoundaries() {
        // Setup
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
{}
                0,                     // checkFeasableCount
                false,                 // generateStatistics
            );
        
        // Try to set inputSigma to null via reflection if the field exists
        try {
            java.lang.reflect.Field inputSigmaField = 
                org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("inputSigma");
            inputSigmaField.setAccessible(true);
            inputSigmaField.set(optimizer, null);
        } catch (NoSuchFieldException e) {
            // Field doesn't exist, which might be fine - test will proceed
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to set inputSigma field via reflection: " + e.getMessage());
        }
        
        double[] input = {1.0, 2.0, 3.0};
        
        // Execute
        
        // Verify
    }

    @Test
    public void testEncode_WithBoundaries() {
        // Setup
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                100,                   // lambda
                new double[] {0.1},    // inputSigma
                10000,                 // maxIterations
                1e-12,                // stopFitness
                true,                 // isActiveCMA
                0,                    // diagonalOnly
                0,                    // checkFeasableCount
                new org.apache.commons.math3.random.JDKRandomGenerator(), // random
                false                 // generateStatistics
            );
        
        // Using reflection to set boundaries
        try {
            java.lang.reflect.Field boundariesField = null;
            try {
                boundariesField = optimizer.getClass().getDeclaredField("boundaries");
            } catch (NoSuchFieldException e) {
                try {
                    boundariesField = optimizer.getClass().getDeclaredField("bounds");
                } catch (NoSuchFieldException e2) {
                    boundariesField = optimizer.getClass().getDeclaredField("boundaryFacor");
                }
            }
            boundariesField.setAccessible(true);
            double[][] boundaries = {{0.0, 0.0, 0.0}, {2.0, 4.0, 6.0}}; // lower and upper bounds
            boundariesField.set(optimizer, boundaries);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            org.junit.Assert.fail("Failed to set boundaries field via reflection: " + e.getMessage());
        }
        
        double[] input = {1.0, 2.0, 3.0};
        double[] expected = {0.5, 0.5, 0.5}; // 1/2, 2/4, 3/6
        
        // Execute
        
        // Verify
    }

    @Test
    public void testEncode_NegativeValues() {
        // Setup
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                10,          // lambda
                null,        // inputSigma
                0,           // maxIterations
                0,           // stopFitness
                false,       // isActiveCMA
                0,           // diagonalOnly
                0,           // checkFeasableCount
                new org.apache.commons.math3.random.JDKRandomGenerator(),  // random
                false        // generateStatistics
            );
        
        // Using reflection to set boundaries
        try {
            java.lang.reflect.Field boundariesField = 
                optimizer.getClass().getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            double[][] boundaries = new double[][]{{-2.0, -4.0}, {2.0, 4.0}}; // symmetric around zero
            boundariesField.set(optimizer, boundaries);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            org.junit.Assert.fail("Failed to set boundaries field via reflection: " + e.getMessage());
        }
        
        double[] input = new double[]{-1.0, -2.0};
        double[] expected = new double[]{0.25, 0.25}; // (-1 - -2)/4 = 0.25, (-2 - -4)/8 = 0.25
        
        // Execute
        
        // Verify
    }

    @Test
    public void testDecode_WhenBoundariesIsNull_ReturnsOriginalArray() {
        // Set up
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        
        // Try to set boundaries/valueRange to null through reflection
        boolean fieldSet = false;
        String[] fieldNames = {"boundaries", "valueRange"};
        
        for (String fieldName : fieldNames) {
            try {
                java.lang.reflect.Field field = 
                    optimizer.getClass().getDeclaredField(fieldName);
                field.setAccessible(true);
                field.set(optimizer, null);
                fieldSet = true;
                break;
            } catch (NoSuchFieldException e) {
                continue;
            } catch (IllegalAccessException e) {
                org.junit.Assert.fail("Failed to set " + fieldName + " field through reflection");
            } catch (IllegalArgumentException e) {
                org.junit.Assert.fail("Illegal argument when setting " + fieldName + " field through reflection");
            }
        }
        
        if (!fieldSet) {
            org.junit.Assert.fail("Failed to find either boundaries or valueRange field through reflection");
        }
        
        double[] input = new double[]{0.5, 1.0, 1.5};
        
        // Execute
        
        // Verify
    }

    @Test
    public void testIsFeasible_EmptyArray() {
        int maxIterations = 0;
        double stopFitness = 0.0;
        boolean isActiveCMA = false;
        int diagonalOnly = 0;
        int checkFeasableCount = 0;
        org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
        boolean generateStatistics = false;
        int lambda = 0;
        double[] inputSigma = new double[0];
        
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
        
    }

    @Test
    public void testEncode_EmptyInput() {
        // Setup
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                    10,                      // lambda
                    null,                    // inputSigma
                    1000,                    // maxIterations
                    0.0,                     // stopFitness
                    true,                    // isActiveCMA
                    0,                       // diagonalOnly
                    0,                       // checkFeasableCount
                    new org.apache.commons.math3.random.JDKRandomGenerator(), // random
                    false                    // generateStatistics
                );
        
        // Using reflection to set boundaries
        try {
            java.lang.reflect.Field boundariesField = 
                org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            double[][] boundaries = new double[][]{{0.0}, {1.0}};
            boundariesField.set(optimizer, boundaries);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            org.junit.Assert.fail("Failed to set boundaries field via reflection");
        }
        
        double[] input = new double[0];
        
        // Execute
        
        // Verify
    }

    @Test
    public void testDecode_WithValidBoundaries_ReturnsCorrectlyScaledValues() {
        // Set up
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        double[] input = {0.5, 1.0, 0.0};
        
        // Use reflection to set the boundaries field since it's private
        try {
            java.lang.reflect.Field boundariesField = 
                optimizer.getClass().getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            boundariesField.set(optimizer, new double[][] {
                {10.0, 20.0, 30.0},  // lower bounds
                {20.0, 30.0, 50.0}    // upper bounds
            });
            
            // Set valueRange field which is used in decode()
            java.lang.reflect.Field valueRangeField = 
                optimizer.getClass().getDeclaredField("valueRange");
            valueRangeField.setAccessible(true);
            valueRangeField.set(optimizer, 1.0);
            
            // Set the boundariesType field which might be needed
            java.lang.reflect.Field boundariesTypeField = 
                optimizer.getClass().getDeclaredField("boundariesType");
            boundariesTypeField.setAccessible(true);
            
            // Get the BoundaryType enum class
            Class<?>[] declaredClasses = optimizer.getClass().getDeclaredClasses();
            Class<?> boundaryTypeClass = null;
            for (Class<?> clazz : declaredClasses) {
                if (clazz.getSimpleName().equals("BoundaryType")) {
                    boundaryTypeClass = clazz;
                    break;
                }
            }
            if (boundaryTypeClass == null) {
                org.junit.Assert.fail("Could not find BoundaryType enum");
            }
            
            // Set FIXED boundary type
            Object[] enumConstants = boundaryTypeClass.getEnumConstants();
            Object fixedBoundary = null;
            for (Object constant : enumConstants) {
                if (constant.toString().equals("FIXED")) {
                    fixedBoundary = constant;
                    break;
                }
            }
            if (fixedBoundary == null) {
                org.junit.Assert.fail("Could not find FIXED enum constant");
            }
            boundariesTypeField.set(optimizer, fixedBoundary);
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to set fields via reflection: " + e.getMessage());
        }
        
        double[] expected = {
            10.0 + (20.0 - 10.0) * 0.5,  // 15.0
            20.0 + (30.0 - 20.0) * 1.0,   // 30.0
            30.0 + (50.0 - 30.0) * 0.0    // 30.0
        };
        
        // Execute
        
        // Verify
    }

    @Test
    public void testDecode_WithEmptyInputArray_ReturnsEmptyArray() throws Exception {
        // Set up
        int lambda = 1;
        double[] inputSigma = new double[0];
        double[] input = new double[0];
        
        // Create optimizer with simplest constructor
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(lambda, inputSigma);
        
        // Execute
        
        // Verify
    }

    @Test
    public void testIsFeasible_NullBoundaries() {
        // Using simplest constructor with default lambda value
        int maxIterations = 1000;
        double[] stopFitness = new double[]{0};  // Changed from double to double[]
        boolean isActiveCMA = false;
        int diagonalOnly = 0;
        int checkFeasableCount = 0;
        org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
        boolean generateStatistics = false;
        int lambda = 10; // population size (must be > 0)
        double[] inputSigma = null;
        
        // Create boundaries array (null in this case)
        double[][] boundaries = null;
        
        // Using the full constructor
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
        
        // Use reflection to set boundaries since it's not in the constructor
        try {
            java.lang.reflect.Field boundariesField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            boundariesField.set(optimizer, boundaries);
}{
            org.junit.Assert.fail("Failed to set boundaries via reflection: " + e.getMessage());
        }
        
        double[] x = {1.0, 2.0, 3.0};
        // When boundaries are null, all points should be feasible
    }


}
