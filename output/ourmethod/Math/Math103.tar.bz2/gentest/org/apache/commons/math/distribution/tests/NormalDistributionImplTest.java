package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
 
public class NormalDistributionImplTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                                                                                                                                                                                    public void testConstructor_InvalidStandardDeviation() {
                                                                                                                                                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                                                        new NormalDistributionImpl(0.0, 0.0); // Zero standard deviation
                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                                                        new NormalDistributionImpl(0.0, -1.0); // Negative standard deviation
                                                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testCumulativeProbability_TypicalValues() throws MathException {
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0); // Standard normal distribution
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Test values around the mean
                                                                                                                                                                                                                                                                                                                            assertEquals(0.5, dist.cumulativeProbability(0.0), 0.0001);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Test positive and negative values
                                                                                                                                                                                                                                                                                                                            assertEquals(0.8413, dist.cumulativeProbability(1.0), 0.0001);
                                                                                                                                                                                                                                                                                                                            assertEquals(0.1587, dist.cumulativeProbability(-1.0), 0.0001);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Test with different mean and standard deviation
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl customDist = new NormalDistributionImpl(10.0, 2.0);
                                                                                                                                                                                                                                                                                                                            assertEquals(0.6915, customDist.cumulativeProbability(11.0), 0.0001);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testCumulativeProbability_ExtremeValues() throws MathException {
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Far below mean
                                                                                                                                                                                                                                                                                                                            assertEquals(0.0, dist.cumulativeProbability(-21.0), 0.0001);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Far above mean
                                                                                                                                                                                                                                                                                                                            assertEquals(1.0, dist.cumulativeProbability(21.0), 0.0001);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Test with different standard deviation
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl wideDist = new NormalDistributionImpl(5.0, 0.1);
                                                                                                                                                                                                                                                                                                                            assertEquals(0.0, wideDist.cumulativeProbability(2.99), 0.0001); // 5 - 20*0.1 = 3
                                                                                                                                                                                                                                                                                                                            assertEquals(1.0, wideDist.cumulativeProbability(7.01), 0.0001); // 5 + 20*0.1 = 7
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testCumulativeProbability_VerySmallStandardDeviation() throws org.apache.commons.math.MathException {
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 0.0001);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Values very close to mean
                                                                                                                                                                                                                                                                                                                            assertEquals(0.0, dist.cumulativeProbability(9.999), 0.0001);
                                                                                                                                                                                                                                                                                                                            assertEquals(1.0, dist.cumulativeProbability(10.001), 0.0001);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Exactly at mean
                                                                                                                                                                                                                                                                                                                            assertEquals(0.5, dist.cumulativeProbability(10.0), 0.0001);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testCumulativeProbability_VeryLargeStandardDeviation() throws MathException {
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 100000.0);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Even large x values are within a few standard deviations
                                                                                                                                                                                                                                                                                                                            assertEquals(0.5, dist.cumulativeProbability(0.0), 0.0001);
                                                                                                                                                                                                                                                                                                                            assertEquals(0.5398, dist.cumulativeProbability(10000.0), 0.0001);
                                                                                                                                                                                                                                                                                                                            assertEquals(0.4602, dist.cumulativeProbability(-10000.0), 0.0001);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testCumulativeProbability_MaxIterationsExceededInMiddleRange() throws MathException {
                                                                                                                                                                                                                                                                                                                            // Create a mock Erf class that throws MaxIterationsExceededException
                                                                                                                                                                                                                                                                                                                            Erf mockErf = mock(Erf.class);
                                                                                                                                                                                                                                                                                                                            when(mockErf.erf(anyDouble())).thenThrow(new MaxIterationsExceededException(100));
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Use reflection to inject the mock Erf into a normal distribution instance
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                                                                Field erfField = NormalDistributionImpl.class.getDeclaredField("erf");
                                                                                                                                                                                                                                                                                                                                erfField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                erfField.set(dist, mockErf);
                                                                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                                fail("Failed to set erf field via reflection");
                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            thrown.expect(MaxIterationsExceededException.class);
                                                                                                                                                                                                                                                                                                                            dist.cumulativeProbability(0.5); // Within 20 standard deviations
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testSetStandardDeviationWithZeroShouldThrowException() {
                                                                                                                                                                                                                                                                                                                            // This test will detect the mutant because:
                                                                                                                                                                                                                                                                                                                            // Original code (sd <= 0.0) will throw exception for 0.0
                                                                                                                                                                                                                                                                                                                            // Mutant code (sd < 0.0) will accept 0.0
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Try to create distribution with sd = 0.0
                                                                                                                                                                                                                                                                                                                            new NormalDistributionImpl(0.0, 0.0);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testSetStandardDeviationWithNegativeShouldThrowException() {
                                                                                                                                                                                                                                                                                                                            // Additional test case for negative value (both original and mutant should behave same)
                                                                                                                                                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            new NormalDistributionImpl(0.0, -1.0);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testSetStandardDeviationWithPositiveValueShouldWork() {
                                                                                                                                                                                                                                                                                                                            // Valid case - should work for both original and mutant
                                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                                            assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                                                                                    public void testSetStandardDeviationWithNegativeValue() {
                                                                                                                                                                                                                                                                                                                        // This test will fail on the mutant (which allows negative SD) but pass on original
                                                                                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                                        dist.setStandardDeviation(-0.5); // Should throw exception
                                                                                                                                                                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                                                                                    public void testSetStandardDeviationWithZeroValue() {
                                                                                                                                                                                                                                                                                                                        // This test should pass on both original and mutant
                                                                                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                                        dist.setStandardDeviation(0.0); // Should throw exception
                                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                                    public void testSetStandardDeviationWithPositiveValue() {
                                                                                                                                                                                                                                                                                                                        // This test should pass on both original and mutant
                                                                                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                                        dist.setStandardDeviation(0.5); // Should accept
                                                                                                                                                                                                                                                                                                                        assertEquals(0.5, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                                                                                public void testSetStandardDeviation_PositiveOnly() {
                                                                                                                                                                                                                                                                                                                    // This should fail if the message was mutated to "non-negative"
                                                                                                                                                                                                                                                                                                                    new NormalDistributionImpl(0.0, 0.0);
                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                public void testSetStandardDeviation_PositiveValue() {
                                                                                                                                                                                                                                                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                                    assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                public void testSetStandardDeviation_VerifyErrorMessage() {
                                                                                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                                                                                        new NormalDistributionImpl(0.0, 0.0);
                                                                                                                                                                                                                                                                                                                        fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                                                                                        // This assertion will catch the mutant
                                                                                                                                                                                                                                                                                                                        assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                            public void testSetStandardDeviationWithNegativeValueThrowsCorrectException() {
                                                                                                                                                                                                                                                                                                                // Set up expectation for the exception
                                                                                                                                                                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                                thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Create instance with negative standard deviation to trigger exception
                                                                                                                                                                                                                                                                                                                new NormalDistributionImpl(0.0, -1.0);
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                            public void testGetMeanReturnsCorrectValue() {
                                                                                                                                                                                                                                                                                                                double expectedMean = 5.0;
                                                                                                                                                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                assertEquals(expectedMean, distribution.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                        public void testSetStandardDeviationWithNegativeValue1() {
                                                                                                                                                                                                                                                                                                            // Prepare for the test
                                                                                                                                                                                                                                                                                                            double mean = 0.0;
                                                                                                                                                                                                                                                                                                            double negativeSd = -1.0;
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Expect exception with specific message
                                                                                                                                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Execute the test
                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(mean, negativeSd);
                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                        public void testGetMeanReturnsCorrectValue1() {
                                                                                                                                                                                                                                                                                                            // Prepare test data
                                                                                                                                                                                                                                                                                                            double expectedMean = 5.0;
                                                                                                                                                                                                                                                                                                            double sd = 1.0;
                                                                                                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(expectedMean, sd);
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Execute and verify
                                                                                                                                                                                                                                                                                                            assertEquals("getMean should return the set mean value", 
                                                                                                                                                                                                                                                                                                                        expectedMean, 
                                                                                                                                                                                                                                                                                                                        dist.getMean(), 
                                                                                                                                                                                                                                                                                                                        0.0001);
                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                    public void testGetMeanUnaffectedByStandardDeviationChange() {
                                                                                                                                                                                                                                                                                                        // Setup - create distribution with mean 5.0 and sd 2.0
                                                                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(5.0, 2.0);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Verify initial mean
                                                                                                                                                                                                                                                                                                        assertEquals(5.0, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Change standard deviation
                                                                                                                                                                                                                                                                                                        dist.setStandardDeviation(3.0);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Verify mean remains unchanged
                                                                                                                                                                                                                                                                                                        assertEquals(5.0, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Change mean directly
                                                                                                                                                                                                                                                                                                        dist.setMean(7.0);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Verify new mean
                                                                                                                                                                                                                                                                                                        assertEquals(7.0, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Change standard deviation again
                                                                                                                                                                                                                                                                                                        dist.setStandardDeviation(1.0);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Verify mean remains unchanged
                                                                                                                                                                                                                                                                                                        assertEquals(7.0, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                    public void testGetMeanAfterConstruction() {
                                                                                                                                                                                                                                                                                                        // Test default constructor
                                                                                                                                                                                                                                                                                                        NormalDistributionImpl defaultDist = new NormalDistributionImpl();
                                                                                                                                                                                                                                                                                                        assertEquals(0.0, defaultDist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Test parameterized constructor
                                                                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(10.5, 2.5);
                                                                                                                                                                                                                                                                                                        assertEquals(10.5, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                    public void testGetMeanAfterSetMean() {
                                                                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Set various mean values and verify
                                                                                                                                                                                                                                                                                                        dist.setMean(-1.5);
                                                                                                                                                                                                                                                                                                        assertEquals(-1.5, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        dist.setMean(0.0);
                                                                                                                                                                                                                                                                                                        assertEquals(0.0, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        dist.setMean(1000000.0);
                                                                                                                                                                                                                                                                                                        assertEquals(1000000.0, dist.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                public void testSetStandardDeviationWithNegativeValue2() {
                                                                                                                                                                                                                                                                                                    // Create an instance of NormalDistributionImpl
                                                                                                                                                                                                                                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Set a negative standard deviation
                                                                                                                                                                                                                                                                                                    double negativeSD = -2.5;
                                                                                                                                                                                                                                                                                                    distribution.setStandardDeviation(negativeSD);
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Verify that the standard deviation is stored as-is (original behavior)
                                                                                                                                                                                                                                                                                                    // If the mutant survives, this will fail because the mutated version stores Math.abs(sd)
                                                                                                                                                                                                                                                                                                    assertEquals("Standard deviation should retain negative value if set", 
                                                                                                                                                                                                                                                                                                                 negativeSD, 
                                                                                                                                                                                                                                                                                                                 distribution.getStandardDeviation(), 
                                                                                                                                                                                                                                                                                                                 0.0001);
                                                                                                                                                                                                                                                                                                }

    @Test(expected = RuntimeException.class)
                                                                                                                                                                                                                                                                                            public void testGetMeanDoesNotCatchOtherExceptions() {
                                                                                                                                                                                                                                                                                                // Create a mock that throws a different exception
                                                                                                                                                                                                                                                                                                NormalDistributionImpl mockDist = mock(NormalDistributionImpl.class);
                                                                                                                                                                                                                                                                                                when(mockDist.getMean()).thenThrow(new RuntimeException("Test exception"));
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // This should throw the RuntimeException, not catch it
                                                                                                                                                                                                                                                                                                mockDist.getMean();
                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                    public void testGetMeanReturnsCorrectValue2() {
                                                                                                                                                                                                                                                                                        // Test normal behavior
                                                                                                                                                                                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl(5.0, 1.0);
                                                                                                                                                                                                                                                                                        assertEquals(5.0, distribution.getMean(), 0.0001);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                            public void testCumulativeProbabilityAtLowerBoundary() throws MathException {
                                                                                                                                                                                                                                                                                // Setup test values where x is exactly at mean - 20*standardDeviation
                                                                                                                                                                                                                                                                                double mean = 100.0;
                                                                                                                                                                                                                                                                                double standardDeviation = 5.0;
                                                                                                                                                                                                                                                                                double x = mean - 20 * standardDeviation; // x = 0.0
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create the normal distribution
                                                                                                                                                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(mean, standardDeviation);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // The exact behavior depends on the implementation of cumulativeProbability,
                                                                                                                                                                                                                                                                                // but we know it should treat the boundary case differently in original vs mutated code
                                                                                                                                                                                                                                                                                // We expect the original to use the < condition, while mutant uses <=
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Call the method with the boundary value
                                                                                                                                                                                                                                                                                double result = dist.cumulativeProbability(x);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify the result is as expected for the original code
                                                                                                                                                                                                                                                                                // Since we don't know the exact expected value, we'll verify it's consistent
                                                                                                                                                                                                                                                                                // with the original implementation's behavior
                                                                                                                                                                                                                                                                                double expectedForOriginal = dist.cumulativeProbability(x - Double.MIN_VALUE);
                                                                                                                                                                                                                                                                                assertNotEquals("Should treat boundary case differently", 
                                                                                                                                                                                                                                                                                               expectedForOriginal, result, 0.0001);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Alternatively, if we know the expected behavior at this boundary:
                                                                                                                                                                                                                                                                                // For a normal distribution, at 20 SDs below mean, probability should be 0
                                                                                                                                                                                                                                                                                assertEquals(0.0, result, 0.0001);
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                    public void testCumulativeProbabilityBoundaryCondition() throws Exception {
                                                                                                                                                                                                                                                                        // Setup test with mean=100, standard deviation=5
                                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(100.0, 5.0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test point that is between 10 and 20 standard deviations below mean
                                                                                                                                                                                                                                                                        // x = mean - 15*standardDeviation = 100 - 15*5 = 25
                                                                                                                                                                                                                                                                        double x = 25.0;
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // The original should handle this as a boundary case (x < mean-20σ is false)
                                                                                                                                                                                                                                                                        // The mutant would handle it as boundary case (x < mean-10σ is true)
                                                                                                                                                                                                                                                                        // So we need to verify the behavior is correct for original
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Since we don't know the exact implementation, we'll verify it's not zero
                                                                                                                                                                                                                                                                        // (assuming boundary cases might return 0 or some other special value)
                                                                                                                                                                                                                                                                        double result = dist.cumulativeProbability(x);
                                                                                                                                                                                                                                                                        assertNotEquals("Result should not be zero for this boundary case", 0.0, result, 0.0001);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Also test a point below the original boundary (x < mean-20σ)
                                                                                                                                                                                                                                                                        double x2 = 100 - 21*5; // = -5
                                                                                                                                                                                                                                                                        double result2 = dist.cumulativeProbability(x2);
                                                                                                                                                                                                                                                                        // This should be handled as boundary case in both original and mutant
                                                                                                                                                                                                                                                                        // So we can verify it's different from the previous result
                                                                                                                                                                                                                                                                        assertNotEquals(result, result2, 0.0001);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                            public void testCumulativeProbabilityBoundaryCondition1() throws MathException {
                                                                                                                                                                                                                                                                // Setup test with mean 100 and standard deviation 5
                                                                                                                                                                                                                                                                double mean = 100.0;
                                                                                                                                                                                                                                                                double sd = 5.0;
                                                                                                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test value far below mean (20 SDs below)
                                                                                                                                                                                                                                                                double farBelow = mean - 20 * sd;  // = 0
                                                                                                                                                                                                                                                                double resultFarBelow = distribution.cumulativeProbability(farBelow);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test value slightly below mean
                                                                                                                                                                                                                                                                double slightlyBelow = mean - 1.0;  // 99
                                                                                                                                                                                                                                                                double resultSlightlyBelow = distribution.cumulativeProbability(slightlyBelow);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test value above mean
                                                                                                                                                                                                                                                                double above = mean + 1.0;  // 101
                                                                                                                                                                                                                                                                double resultAbove = distribution.cumulativeProbability(above);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // In original code, farBelow would trigger special condition
                                                                                                                                                                                                                                                                // but slightlyBelow would not. In mutant, both would trigger.
                                                                                                                                                                                                                                                                // So we can detect mutant by verifying slightlyBelow behavior
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Assert that slightlyBelow produces different result than farBelow
                                                                                                                                                                                                                                                                // (which would only be true for original code)
                                                                                                                                                                                                                                                                assertNotEquals("Mutant detected: slightlyBelow should produce different result than farBelow",
                                                                                                                                                                                                                                                                              resultFarBelow, resultSlightlyBelow);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Additional assertions to verify expected behavior
                                                                                                                                                                                                                                                                assertTrue(resultFarBelow < resultSlightlyBelow);
                                                                                                                                                                                                                                                                assertTrue(resultSlightlyBelow < resultAbove);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                    public void testCumulativeProbabilityForExtremeLowValue() {
                                                                                                                                                                                                                                                        // Setup test data
                                                                                                                                                                                                                                                        double mean = 0.0;
                                                                                                                                                                                                                                                        double standardDeviation = 1.0;
                                                                                                                                                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // This value is far below the mean (more than 20 standard deviations)
                                                                                                                                                                                                                                                        double extremeValue = mean - 21 * standardDeviation;
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            // The original code should handle this extreme value specially
                                                                                                                                                                                                                                                            // The mutated version (with if(false)) would skip this handling
                                                                                                                                                                                                                                                            double result = distribution.cumulativeProbability(extremeValue);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // In a normal distribution, values this far out should have probability 0
                                                                                                                                                                                                                                                            // or be handled specially (perhaps returning Double.MIN_VALUE)
                                                                                                                                                                                                                                                            // The exact expected value depends on the original implementation,
                                                                                                                                                                                                                                                            // but we know it shouldn't be the same as a non-extreme value
                                                                                                                                                                                                                                                            double meanProbability = distribution.cumulativeProbability(mean);
                                                                                                                                                                                                                                                            assertNotEquals("Extreme low value should be handled specially", 
                                                                                                                                                                                                                                                                           meanProbability, 
                                                                                                                                                                                                                                                                           result, 
                                                                                                                                                                                                                                                                           0.0001);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Additionally, we might expect the probability to be 0 for such extreme values
                                                                                                                                                                                                                                                            assertEquals("Extreme low value should have probability 0", 
                                                                                                                                                                                                                                                                         0.0, 
                                                                                                                                                                                                                                                                         result, 
                                                                                                                                                                                                                                                                         0.0001);
                                                                                                                                                                                                                                                        } catch (MathException e) {
                                                                                                                                                                                                                                                            fail("Unexpected MathException: " + e.getMessage());
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testGetMeanReturnsCorrectValue3() {
                                                                                                                                                                                                                                                        // Test with non-zero mean
                                                                                                                                                                                                                                                        double expectedMean = 5.0;
                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(expectedMean, 1.0);
                                                                                                                                                                                                                                                        double actualMean = dist.getMean();
                                                                                                                                                                                                                                                        assertEquals("Getter should return the set mean value", expectedMean, actualMean, 0.0001);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test with zero mean
                                                                                                                                                                                                                                                        NormalDistributionImpl zeroDist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                        assertEquals("Getter should return 0.0 when mean is 0", 0.0, zeroDist.getMean(), 0.0001);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test with negative mean
                                                                                                                                                                                                                                                        NormalDistributionImpl negativeDist = new NormalDistributionImpl(-2.5, 1.0);
                                                                                                                                                                                                                                                        assertEquals("Getter should return negative mean values", -2.5, negativeDist.getMean(), 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                public void testGetMeanReturnsCorrectValue4() {
                                                                                                                                                                                                                                                    // Test with positive mean
                                                                                                                                                                                                                                                    double expectedMean1 = 5.0;
                                                                                                                                                                                                                                                    NormalDistributionImpl distribution1 = new NormalDistributionImpl(expectedMean1, 1.0);
                                                                                                                                                                                                                                                    assertEquals("Getter should return the set mean value", 
                                                                                                                                                                                                                                                                expectedMean1, 
                                                                                                                                                                                                                                                                distribution1.getMean(), 
                                                                                                                                                                                                                                                                0.0001);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Test with negative mean
                                                                                                                                                                                                                                                    double expectedMean2 = -3.5;
                                                                                                                                                                                                                                                    NormalDistributionImpl distribution2 = new NormalDistributionImpl(expectedMean2, 1.0);
                                                                                                                                                                                                                                                    assertEquals("Getter should return the set mean value", 
                                                                                                                                                                                                                                                                expectedMean2, 
                                                                                                                                                                                                                                                                distribution2.getMean(), 
                                                                                                                                                                                                                                                                0.0001);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Test with zero mean
                                                                                                                                                                                                                                                    double expectedMean3 = 0.0;
                                                                                                                                                                                                                                                    NormalDistributionImpl distribution3 = new NormalDistributionImpl(expectedMean3, 1.0);
                                                                                                                                                                                                                                                    assertEquals("Getter should return the set mean value", 
                                                                                                                                                                                                                                                                expectedMean3, 
                                                                                                                                                                                                                                                                distribution3.getMean(), 
                                                                                                                                                                                                                                                                0.0001);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                            public void testGetMeanReturnsCorrectValue5() {
                                                                                                                                                                                                                                                // Create instance with specific mean value (not 0.5)
                                                                                                                                                                                                                                                double testMean = 10.0;
                                                                                                                                                                                                                                                double testSD = 2.0;
                                                                                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(testMean, testSD);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify getMean returns the correct value
                                                                                                                                                                                                                                                assertEquals("getMean() should return the mean value set in constructor", 
                                                                                                                                                                                                                                                            testMean, 
                                                                                                                                                                                                                                                            distribution.getMean(), 
                                                                                                                                                                                                                                                            0.0001);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with another mean value to be thorough
                                                                                                                                                                                                                                                double anotherMean = -5.0;
                                                                                                                                                                                                                                                distribution.setMean(anotherMean);
                                                                                                                                                                                                                                                assertEquals("getMean() should return the updated mean value",
                                                                                                                                                                                                                                                            anotherMean,
                                                                                                                                                                                                                                                            distribution.getMean(),
                                                                                                                                                                                                                                                            0.0001);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                public void testCumulativeProbabilityForExtremeValues() throws Exception {
                                                                                                                                                                                                                                    // Setup normal distribution with mean=0, sd=1 for simplicity
                                                                                                                                                                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test value just below 20 standard deviations
                                                                                                                                                                                                                                    double x1 = 19.9;
                                                                                                                                                                                                                                    double prob1 = dist.cumulativeProbability(x1);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test value at exactly 20 standard deviations
                                                                                                                                                                                                                                    double x2 = 20.0;
                                                                                                                                                                                                                                    double prob2 = dist.cumulativeProbability(x2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test value above 20 standard deviations
                                                                                                                                                                                                                                    double x3 = 20.1;
                                                                                                                                                                                                                                    double prob3 = dist.cumulativeProbability(x3);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Verify probabilities are calculated correctly
                                                                                                                                                                                                                                    // For standard normal distribution, P(X>20) should be extremely small (~0)
                                                                                                                                                                                                                                    // The mutant would potentially handle these cases differently
                                                                                                                                                                                                                                    assertTrue("Probability for x < 20σ should be < 1", prob1 < 1.0);
                                                                                                                                                                                                                                    assertEquals("Probability for x = 20σ should be ~1", 1.0, prob2, 1e-10);
                                                                                                                                                                                                                                    assertEquals("Probability for x > 20σ should be 1", 1.0, prob3, 1e-10);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // The key assertion that would catch the mutant:
                                                                                                                                                                                                                                    // The original else-if would have different behavior than the mutated if
                                                                                                                                                                                                                                    // when processing values around the 20σ threshold
                                                                                                                                                                                                                                    assertTrue("Probability should increase monotonically", prob1 < prob2);
                                                                                                                                                                                                                                    assertTrue("Probability should increase monotonically", prob2 <= prob3);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                        public void testCumulativeProbabilityAtBoundary() throws Exception {
                                                                                                                                                                                                                            // Setup test values
                                                                                                                                                                                                                            double mean = 10.0;
                                                                                                                                                                                                                            double standardDeviation = 2.0;
                                                                                                                                                                                                                            double boundaryValue = mean + 20 * standardDeviation; // x = 50.0
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Create mock of the class
                                                                                                                                                                                                                            NormalDistributionImpl distribution = mock(NormalDistributionImpl.class);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Setup original behavior (using >)
                                                                                                                                                                                                                            when(distribution.cumulativeProbability(boundaryValue))
                                                                                                                                                                                                                                .thenAnswer(invocation -> {
                                                                                                                                                                                                                                    double x = invocation.getArgument(0);
                                                                                                                                                                                                                                    if (x > (mean + 20 * standardDeviation)) {
                                                                                                                                                                                                                                        return 1.0; // or whatever the original implementation returns
                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                        return 0.0; // or whatever the original implementation returns
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                });
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Setup mutated behavior (using >=)
                                                                                                                                                                                                                            NormalDistributionImpl mutatedDistribution = mock(NormalDistributionImpl.class);
                                                                                                                                                                                                                            when(mutatedDistribution.cumulativeProbability(boundaryValue))
                                                                                                                                                                                                                                .thenAnswer(invocation -> {
                                                                                                                                                                                                                                    double x = invocation.getArgument(0);
                                                                                                                                                                                                                                    if (x >= (mean + 20 * standardDeviation)) {
                                                                                                                                                                                                                                        return 1.0; // or whatever the mutated implementation returns
                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                        return 0.0; // or whatever the mutated implementation returns
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                });
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test original behavior
                                                                                                                                                                                                                            double originalResult = distribution.cumulativeProbability(boundaryValue);
                                                                                                                                                                                                                            // Test mutated behavior
                                                                                                                                                                                                                            double mutatedResult = mutatedDistribution.cumulativeProbability(boundaryValue);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Assert that the results differ at the boundary
                                                                                                                                                                                                                            assertNotEquals("Mutation should be detected at boundary value", 
                                                                                                                                                                                                                                           originalResult, mutatedResult);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                public void testCumulativeProbabilityForExtremeValues1() throws MathException {
                                                                                                                                                                                                                    // Setup normal distribution with mean=0 and sd=1 for simplicity
                                                                                                                                                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test value between 10 and 20 standard deviations above mean
                                                                                                                                                                                                                    double testValue = 15; // 15 standard deviations above mean
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // In original code, this should be treated as regular value
                                                                                                                                                                                                                    // In mutated code, this would be treated as extreme value
                                                                                                                                                                                                                    double result = dist.cumulativeProbability(testValue);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // The exact expected value isn't specified, but we know:
                                                                                                                                                                                                                    // For such extreme values, the cumulative probability should be very close to 1
                                                                                                                                                                                                                    // We use a delta of 1e-10 to account for floating point precision
                                                                                                                                                                                                                    assertEquals(1.0, result, 1e-10);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Additionally, we can verify it's not being treated as an extreme case
                                                                                                                                                                                                                    // by checking it's not exactly 1.0 (which it might be if treated as extreme)
                                                                                                                                                                                                                    assertTrue(result < 1.0);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                        public void testCumulativeProbabilityForExtremeValues2() throws MathException {
                                                                                                                                                                                                            // Setup test with known parameters
                                                                                                                                                                                                            double mean = 0.0;
                                                                                                                                                                                                            double sd = 1.0;
                                                                                                                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test value that is more than 20 standard deviations above mean
                                                                                                                                                                                                            double extremeValue = mean + 21 * sd;
                                                                                                                                                                                                            
                                                                                                                                                                                                            // The original implementation should return a value very close to 1.0
                                                                                                                                                                                                            // The mutated version would return a different value since it takes the else-if branch
                                                                                                                                                                                                            double probability = distribution.cumulativeProbability(extremeValue);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify the result is as expected (very close to 1)
                                                                                                                                                                                                            assertEquals(1.0, probability, 1e-10);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test another extreme value case
                                                                                                                                                                                                            extremeValue = mean + 30 * sd;
                                                                                                                                                                                                            probability = distribution.cumulativeProbability(extremeValue);
                                                                                                                                                                                                            assertEquals(1.0, probability, 1e-10);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test negative extreme value (more than 20 SD below mean)
                                                                                                                                                                                                            extremeValue = mean - 21 * sd;
                                                                                                                                                                                                            probability = distribution.cumulativeProbability(extremeValue);
                                                                                                                                                                                                            // Should be very close to 0 for extreme negative values
                                                                                                                                                                                                            assertEquals(0.0, probability, 1e-10);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testGetMeanReturnsCorrectValue6() {
                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                            double expectedMean = 5.0;
                                                                                                                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Act
                                                                                                                                                                                                            double actualMean = distribution.getMean();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                            assertEquals("getMean() should return the exact mean value that was set", 
                                                                                                                                                                                                                        expectedMean, actualMean, 0.0001);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testGetMeanWithZeroMean() {
                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                            double expectedMean = 0.0;
                                                                                                                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Act
                                                                                                                                                                                                            double actualMean = distribution.getMean();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                            assertEquals("getMean() should return 0.0 when mean is set to 0.0",
                                                                                                                                                                                                                        expectedMean, actualMean, 0.0001);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testGetMeanWithNegativeMean() {
                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                            double expectedMean = -2.5;
                                                                                                                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Act
                                                                                                                                                                                                            double actualMean = distribution.getMean();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                            assertEquals("getMean() should return negative values when mean is negative",
                                                                                                                                                                                                                        expectedMean, actualMean, 0.0001);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                    public void testGetMeanReturnsCorrectValue7() {
                                                                                                                                                                                                        // Test with positive mean
                                                                                                                                                                                                        double expectedMean1 = 5.0;
                                                                                                                                                                                                        NormalDistributionImpl distribution1 = new NormalDistributionImpl(expectedMean1, 1.0);
                                                                                                                                                                                                        assertEquals("Mean should be " + expectedMean1, expectedMean1, distribution1.getMean(), 0.0001);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test with negative mean
                                                                                                                                                                                                        double expectedMean2 = -3.5;
                                                                                                                                                                                                        NormalDistributionImpl distribution2 = new NormalDistributionImpl(expectedMean2, 1.0);
                                                                                                                                                                                                        assertEquals("Mean should be " + expectedMean2, expectedMean2, distribution2.getMean(), 0.0001);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test with zero mean
                                                                                                                                                                                                        double expectedMean3 = 0.0;
                                                                                                                                                                                                        NormalDistributionImpl distribution3 = new NormalDistributionImpl(expectedMean3, 1.0);
                                                                                                                                                                                                        assertEquals("Mean should be " + expectedMean3, expectedMean3, distribution3.getMean(), 0.0001);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                public void testConstructorAndGetters() {
                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                    double expectedMean = 5.0;
                                                                                                                                                                                                    double expectedStdDev = 2.0;
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Act
                                                                                                                                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, expectedStdDev);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                    assertEquals("Mean should match constructor input", 
                                                                                                                                                                                                        expectedMean, distribution.getMean(), 0.0001);
                                                                                                                                                                                                    assertEquals("Standard deviation should match constructor input",
                                                                                                                                                                                                        expectedStdDev, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testSettersAndGetters() {
                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                    double expectedMean = 3.0;
                                                                                                                                                                                                    double expectedStdDev = 1.5;
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Act
                                                                                                                                                                                                    distribution.setMean(expectedMean);
                                                                                                                                                                                                    distribution.setStandardDeviation(expectedStdDev);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                    assertEquals("Mean should match setter input",
                                                                                                                                                                                                        expectedMean, distribution.getMean(), 0.0001);
                                                                                                                                                                                                    assertEquals("Standard deviation should match setter input",
                                                                                                                                                                                                        expectedStdDev, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                            public void testSetStandardDeviationWithNegativeValue3() {
                                                                                                                                                                                                // Create normal distribution with negative standard deviation
                                                                                                                                                                                                double mean = 0.0;
                                                                                                                                                                                                double negativeSd = -1.5;
                                                                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(mean, negativeSd);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify standard deviation is stored as-is (should fail if mutant is present)
                                                                                                                                                                                                assertEquals("Standard deviation should preserve negative values", 
                                                                                                                                                                                                            negativeSd, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                
                                                                                                                                                                                                // Also verify mean is unaffected
                                                                                                                                                                                                assertEquals("Mean should be unchanged", 
                                                                                                                                                                                                            mean, dist.getMean(), 0.0001);
                                                                                                                                                                                            }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                        public void testGetMeanDoesNotCatchGeneralExceptions() {
                                                                                                                                                                                            // Create a mock that will throw NullPointerException when getMean is called
                                                                                                                                                                                            NormalDistributionImpl mockDistribution = mock(NormalDistributionImpl.class);
                                                                                                                                                                                            when(mockDistribution.getMean()).thenThrow(new NullPointerException());
                                                                                                                                                                                            
                                                                                                                                                                                            // This should throw NullPointerException, not catch it
                                                                                                                                                                                            mockDistribution.getMean();
                                                                                                                                                                                            
                                                                                                                                                                                            /* 
                                                                                                                                                                                             * If the mutant is present (catching Exception instead of MaxIterationsExceededException),
                                                                                                                                                                                             * this test will fail because the NullPointerException would be caught.
                                                                                                                                                                                             * The original code would let the exception propagate.
                                                                                                                                                                                             */
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                            public void testCumulativeProbabilityAtLowerBoundary1() {
                                                                                                                                                                                // Setup test with known mean and standard deviation
                                                                                                                                                                                double mean = 100.0;
                                                                                                                                                                                double sd = 5.0;
                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                
                                                                                                                                                                                // Calculate the exact boundary value
                                                                                                                                                                                double boundaryValue = mean - 20 * sd;  // 100 - 20*5 = 0
                                                                                                                                                                                
                                                                                                                                                                                try {
                                                                                                                                                                                    // Test the boundary condition
                                                                                                                                                                                    double result = distribution.cumulativeProbability(boundaryValue);
                                                                                                                                                                                    
                                                                                                                                                                                    // In original code, x == boundary should return a very small but non-zero probability
                                                                                                                                                                                    // In mutated code, it might return 0 or behave differently
                                                                                                                                                                                    // Assert that probability is very small but not zero
                                                                                                                                                                                    assertTrue("Probability at boundary should be very small but non-zero", 
                                                                                                                                                                                              result > 0 && result < Double.MIN_VALUE * 10);
                                                                                                                                                                                } catch (MathException e) {
                                                                                                                                                                                    fail("Unexpected MathException: " + e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                            }

    @Test
                                                                                                                                                                    public void testCumulativeProbabilityBoundaryCondition2() throws MathException {
                                                                                                                                                                        // Setup test with mean=100, standard deviation=5
                                                                                                                                                                        double mean = 100.0;
                                                                                                                                                                        double sd = 5.0;
                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                        
                                                                                                                                                                        // Test value between mean-20σ and mean-10σ (between 0 and 50 for our values)
                                                                                                                                                                        double x = 25.0; // mean - 15σ
                                                                                                                                                                        
                                                                                                                                                                        // The original should handle this as normal case, mutant would treat as boundary
                                                                                                                                                                        // Since we don't know exact probability values, we'll verify it's not 0 or 1
                                                                                                                                                                        double probability = dist.cumulativeProbability(x);
                                                                                                                                                                        
                                                                                                                                                                        // Assert the probability is within expected range (not 0 or 1)
                                                                                                                                                                        assertTrue("Probability should be greater than 0", probability > 0.0);
                                                                                                                                                                        assertTrue("Probability should be less than 1", probability < 1.0);
                                                                                                                                                                        
                                                                                                                                                                        // For more precise testing, we could calculate expected value
                                                                                                                                                                        // But since we don't have the exact implementation, this should catch the mutant
                                                                                                                                                                        // as it would likely return 0 for x < (mean-10σ) in the mutant case
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testCumulativeProbabilityExtremeLowValue() throws org.apache.commons.math.MathException {
                                                                                                                                                                        // Setup test with mean=100, standard deviation=5
                                                                                                                                                                        double mean = 100.0;
                                                                                                                                                                        double sd = 5.0;
                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                        
                                                                                                                                                                        // Test value below mean-20σ (should be handled as boundary in original)
                                                                                                                                                                        double x = -10.0; // mean - 22σ
                                                                                                                                                                        
                                                                                                                                                                        double probability = dist.cumulativeProbability(x);
                                                                                                                                                                        
                                                                                                                                                                        // Should return minimum probability (likely 0) for extreme low values
                                                                                                                                                                        assertEquals(0.0, probability, 0.0001);
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testCumulativeProbabilityDetectsMutant() throws MathException {
                                                                                                                                                                // Setup test with mean=10, stdDev=1
                                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 1.0);
                                                                                                                                                                
                                                                                                                                                                // Test value far below mean (more than 20 std devs)
                                                                                                                                                                double x1 = -20.0; // 10 - 20*1 = -10, so -20 is below threshold
                                                                                                                                                                double result1 = dist.cumulativeProbability(x1);
                                                                                                                                                                
                                                                                                                                                                // Test value just below mean but above original threshold
                                                                                                                                                                double x2 = -9.0; // -9 > -10 (original threshold) but < 10 (mutant threshold)
                                                                                                                                                                double result2 = dist.cumulativeProbability(x2);
                                                                                                                                                                
                                                                                                                                                                // Test value above mean
                                                                                                                                                                double x3 = 11.0;
                                                                                                                                                                double result3 = dist.cumulativeProbability(x3);
                                                                                                                                                                
                                                                                                                                                                // Assertions that would catch the mutant
                                                                                                                                                                // For x1, both original and mutant would enter the if block
                                                                                                                                                                // For x2, original wouldn't enter if block but mutant would
                                                                                                                                                                // For x3, neither would enter if block
                                                                                                                                                                
                                                                                                                                                                // The key assertion is that result2 should be different in original vs mutant
                                                                                                                                                                // Since we can't know the exact implementation, we'll assert it's not zero
                                                                                                                                                                // (assuming original would give very small but non-zero probability)
                                                                                                                                                                assertNotEquals(0.0, result2, 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Additional sanity checks
                                                                                                                                                                assertTrue(result1 < result2); // More extreme value should have lower probability
                                                                                                                                                                assertTrue(result3 > 0.5); // Above mean should have >50% probability
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testCumulativeProbabilityForExtremeLowValue1() {
                                                                                                                                                        // Setup normal distribution with mean=0, sd=1
                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                        
                                                                                                                                                        // Test value that's more than 20 standard deviations below mean
                                                                                                                                                        double extremeValue = -21.0;
                                                                                                                                                        
                                                                                                                                                        try {
                                                                                                                                                            // In original code, this should trigger special handling
                                                                                                                                                            // In mutant (if(false)), it will skip the special handling
                                                                                                                                                            double probability = dist.cumulativeProbability(extremeValue);
                                                                                                                                                            
                                                                                                                                                            // The exact assertion depends on what the special handling should return
                                                                                                                                                            // For a normal distribution, this should be very close to 0
                                                                                                                                                            assertEquals(0.0, probability, 1e-10);
                                                                                                                                                            
                                                                                                                                                            // Alternatively, we could verify it's not NaN or some other invalid value
                                                                                                                                                            assertFalse(Double.isNaN(probability));
                                                                                                                                                        } catch (MathException e) {
                                                                                                                                                            fail("Unexpected MathException: " + e.getMessage());
                                                                                                                                                        }
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testGetMeanReturnsCorrectValue8() {
                                                                                                                                                        // Create an instance with a specific mean value (not 1.0)
                                                                                                                                                        double expectedMean = 5.0;
                                                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                                                                                                                                                        
                                                                                                                                                        // Verify getMean returns the expected value
                                                                                                                                                        assertEquals("getMean() should return the mean value set in constructor", 
                                                                                                                                                                    expectedMean, 
                                                                                                                                                                    distribution.getMean(), 
                                                                                                                                                                    0.0001);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testGetMeanAfterSetMean1() {
                                                                                                                                                        // Create an instance with default mean
                                                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                        
                                                                                                                                                        // Set a new mean value (not 1.0)
                                                                                                                                                        double newMean = 3.5;
                                                                                                                                                        distribution.setMean(newMean);
                                                                                                                                                        
                                                                                                                                                        // Verify getMean returns the updated value
                                                                                                                                                        assertEquals("getMean() should return the updated mean value after setMean()", 
                                                                                                                                                                    newMean, 
                                                                                                                                                                    distribution.getMean(), 
                                                                                                                                                                    0.0001);
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testGetMeanReturnsCorrectValue9() {
                                                                                                                                                    // Test with default constructor (mean = 0.0)
                                                                                                                                                    NormalDistributionImpl dist1 = new NormalDistributionImpl();
                                                                                                                                                    assertEquals("Default mean should be 0.0", 0.0, dist1.getMean(), 0.0001);
                                                                                                                                                    
                                                                                                                                                    // Test with explicit mean value
                                                                                                                                                    NormalDistributionImpl dist2 = new NormalDistributionImpl(5.0, 1.0);
                                                                                                                                                    assertEquals("Mean should be 5.0", 5.0, dist2.getMean(), 0.0001);
                                                                                                                                                    
                                                                                                                                                    // Test after changing mean value
                                                                                                                                                    NormalDistributionImpl dist3 = new NormalDistributionImpl();
                                                                                                                                                    dist3.setMean(10.5);
                                                                                                                                                    assertEquals("Mean should be 10.5 after setting", 10.5, dist3.getMean(), 0.0001);
                                                                                                                                                    
                                                                                                                                                    // Test with negative mean value
                                                                                                                                                    NormalDistributionImpl dist4 = new NormalDistributionImpl(-3.2, 1.0);
                                                                                                                                                    assertEquals("Mean should be -3.2", -3.2, dist4.getMean(), 0.0001);
                                                                                                                                                }

    @Test
                                                                                                                                            public void testGetMeanReturnsCorrectValue10() {
                                                                                                                                                // Create object with specific mean value (not 0.5)
                                                                                                                                                double testMean = 10.0;
                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(testMean, 1.0);
                                                                                                                                                
                                                                                                                                                // Verify getMean returns the correct value
                                                                                                                                                assertEquals("getMean() should return the set mean value", 
                                                                                                                                                            testMean, 
                                                                                                                                                            distribution.getMean(), 
                                                                                                                                                            0.0001);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testGetMeanWithDefaultConstructor() {
                                                                                                                                                // Test with default constructor which sets mean to 0.0
                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                
                                                                                                                                                // Verify getMean returns 0.0 (not 0.5)
                                                                                                                                                assertEquals("getMean() should return 0.0 for default constructor", 
                                                                                                                                                            0.0, 
                                                                                                                                                            distribution.getMean(), 
                                                                                                                                                            0.0001);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testGetMeanAfterChangingValue() {
                                                                                                                                                // Create object and then change mean
                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(5.0, 1.0);
                                                                                                                                                double newMean = 7.5;
                                                                                                                                                distribution.setMean(newMean);
                                                                                                                                                
                                                                                                                                                // Verify getMean returns the updated value
                                                                                                                                                assertEquals("getMean() should return updated mean value after setMean", 
                                                                                                                                                            newMean, 
                                                                                                                                                            distribution.getMean(), 
                                                                                                                                                            0.0001);
                                                                                                                                            }

    @Test
                                                                                                                                public void testCumulativeProbabilityDetectsMutant1() {
                                                                                                                                    // Setup with known mean and standard deviation
                                                                                                                                    double mean = 0.0;
                                                                                                                                    double sd = 1.0;
                                                                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                    
                                                                                                                                    try {
                                                                                                                                        // Test value that's extremely low (should return 0)
                                                                                                                                        double extremeLow = mean - 21 * sd;
                                                                                                                                        assertEquals(0.0, dist.cumulativeProbability(extremeLow), 0.0001);
                                                                                                                                        
                                                                                                                                        // Test value that's extremely high (should return 1)
                                                                                                                                        double extremeHigh = mean + 21 * sd;
                                                                                                                                        assertEquals(1.0, dist.cumulativeProbability(extremeHigh), 0.0001);
                                                                                                                                        
                                                                                                                                        // Test value within bounds (should return proper probability)
                                                                                                                                        double withinBounds = mean + 0.5 * sd;
                                                                                                                                        double expectedProbability = 0.6915; // approximate value for z=0.5
                                                                                                                                        assertEquals(expectedProbability, dist.cumulativeProbability(withinBounds), 0.0001);
                                                                                                                                        
                                                                                                                                        // Critical test: value that would pass previous conditions but now gets caught by mutated if
                                                                                                                                        double boundaryValue = mean - 19 * sd;
                                                                                                                                        // Original would return proper probability, mutant might return 0 incorrectly
                                                                                                                                        assertTrue(dist.cumulativeProbability(boundaryValue) > 0);
                                                                                                                                    } catch (MathException e) {
                                                                                                                                        fail("Unexpected MathException: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                        public void testCumulativeProbabilityAtUpperBoundary() throws MathException {
                                                                                                                            // Setup test data
                                                                                                                            double mean = 10.0;
                                                                                                                            double standardDeviation = 2.0;
                                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                                                                                                            
                                                                                                                            // Calculate the exact boundary point
                                                                                                                            double boundaryX = mean + 20 * standardDeviation;
                                                                                                                            
                                                                                                                            // The test should verify that x at exactly the boundary is handled correctly
                                                                                                                            // In original code: x > boundary would be false, so it would fall to else case
                                                                                                                            // In mutated code: x >= boundary would be true, so it would enter this condition
                                                                                                                            
                                                                                                                            // Since we don't have the actual implementation of cumulativeProbability,
                                                                                                                            // we need to make some reasonable assumptions about its behavior.
                                                                                                                            // Typically, for values far in the tail (20σ), probability should be very close to 1
                                                                                                                            
                                                                                                                            double result = distribution.cumulativeProbability(boundaryX);
                                                                                                                            
                                                                                                                            // The exact assertion would depend on the actual implementation,
                                                                                                                            // but we can reasonably expect it to be very close to 1 at this point
                                                                                                                            assertEquals(1.0, result, 0.0001);
                                                                                                                            
                                                                                                                            // Additionally, test a value just below the boundary
                                                                                                                            double justBelowBoundary = boundaryX - Double.MIN_VALUE;
                                                                                                                            double belowResult = distribution.cumulativeProbability(justBelowBoundary);
                                                                                                                            assertEquals(1.0, belowResult, 0.0001);
                                                                                                                            
                                                                                                                            // And a value just above the boundary
                                                                                                                            double justAboveBoundary = boundaryX + Double.MIN_VALUE;
                                                                                                                            double aboveResult = distribution.cumulativeProbability(justAboveBoundary);
                                                                                                                            assertEquals(1.0, aboveResult, 0.0001);
                                                                                                                        }

    @Test
                                                                                                                public void testCumulativeProbabilityForExtremeValues3() throws Exception {
                                                                                                                    // Setup normal distribution with mean 0 and sd 1
                                                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                    
                                                                                                                    // Test value at 15 standard deviations (between 10 and 20)
                                                                                                                    double x = 15.0;
                                                                                                                    
                                                                                                                    // In original, this should be treated as normal case (not extreme)
                                                                                                                    // In mutant, this would be treated as extreme case
                                                                                                                    double probability = dist.cumulativeProbability(x);
                                                                                                                    
                                                                                                                    // Verify the probability is calculated normally (not treated as extreme case)
                                                                                                                    // For standard normal distribution, P(X>15) should be very small but non-zero
                                                                                                                    assertTrue("Probability should be very small but non-zero", probability > 0.0);
                                                                                                                    assertTrue("Probability should be less than normal range", probability < 1e-100);
                                                                                                                    
                                                                                                                    // Also test exactly at 20 standard deviations
                                                                                                                    x = 20.0;
                                                                                                                    probability = dist.cumulativeProbability(x);
                                                                                                                    assertTrue(probability > 0.0);
                                                                                                                    assertTrue(probability < 1e-100);
                                                                                                                    
                                                                                                                    // Test at 10 standard deviations to verify both versions
                                                                                                                    x = 10.0;
                                                                                                                    probability = dist.cumulativeProbability(x);
                                                                                                                    assertTrue(probability > 0.0);
                                                                                                                    assertTrue(probability < 1e-23);
                                                                                                                }

    @Test
                                                                                                        public void testCumulativeProbabilityForExtremeValues4() throws MathException {
                                                                                                            // Setup normal distribution with mean=0, sd=1
                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                            
                                                                                                            // Test value that is exactly at mean + 20*sd (20 in this case)
                                                                                                            double boundaryValue = 20.0;
                                                                                                            double resultAtBoundary = dist.cumulativeProbability(boundaryValue);
                                                                                                            
                                                                                                            // Test value just below boundary (should not trigger the else-if)
                                                                                                            double belowBoundaryValue = 19.999;
                                                                                                            double resultBelowBoundary = dist.cumulativeProbability(belowBoundaryValue);
                                                                                                            
                                                                                                            // Test value just above boundary (should trigger the else-if)
                                                                                                            double aboveBoundaryValue = 20.001;
                                                                                                            double resultAboveBoundary = dist.cumulativeProbability(aboveBoundaryValue);
                                                                                                            
                                                                                                            // The mutant would make all cases take the else-if branch (true condition)
                                                                                                            // So we verify that results are different across the boundary
                                                                                                            assertNotEquals("Results should differ across boundary", 
                                                                                                                          resultBelowBoundary, resultAboveBoundary);
                                                                                                            
                                                                                                            // Additional verification that boundary case is handled properly
                                                                                                            assertTrue("Boundary value should produce high probability",
                                                                                                                     resultAtBoundary > 0.999);
                                                                                                        }

    @Test
                                                                                                        public void testGetMeanReturnsCorrectValue11() {
                                                                                                            // Create instance with non-zero mean
                                                                                                            double testMean = 5.0;
                                                                                                            double testSD = 1.0;
                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(testMean, testSD);
                                                                                                            
                                                                                                            // Verify getMean returns the correct value
                                                                                                            assertEquals("getMean() should return the mean value set in constructor", 
                                                                                                                         testMean, distribution.getMean(), 0.0001);
                                                                                                        }

    @Test
                                                                                                        public void testGetMeanAfterSettingNewValue() {
                                                                                                            // Create instance with initial mean
                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                            
                                                                                                            // Set new mean value
                                                                                                            double newMean = 10.0;
                                                                                                            distribution.setMean(newMean);
                                                                                                            
                                                                                                            // Verify getMean returns the updated value
                                                                                                            assertEquals("getMean() should return the updated mean value",
                                                                                                                         newMean, distribution.getMean(), 0.0001);
                                                                                                        }

    @Test
                                                                                                    public void testGetMeanReturnsCorrectValue12() {
                                                                                                        // Test with positive mean
                                                                                                        NormalDistributionImpl dist1 = new NormalDistributionImpl(5.0, 1.0);
                                                                                                        assertEquals(5.0, dist1.getMean(), 0.0001);
                                                                                                        
                                                                                                        // Test with negative mean
                                                                                                        NormalDistributionImpl dist2 = new NormalDistributionImpl(-3.5, 1.0);
                                                                                                        assertEquals(-3.5, dist2.getMean(), 0.0001);
                                                                                                        
                                                                                                        // Test with zero mean
                                                                                                        NormalDistributionImpl dist3 = new NormalDistributionImpl(0.0, 1.0);
                                                                                                        assertEquals(0.0, dist3.getMean(), 0.0001);
                                                                                                        
                                                                                                        // Test with default constructor (mean=0.0)
                                                                                                        NormalDistributionImpl dist4 = new NormalDistributionImpl();
                                                                                                        assertEquals(0.0, dist4.getMean(), 0.0001);
                                                                                                        
                                                                                                        // Test after changing mean
                                                                                                        NormalDistributionImpl dist5 = new NormalDistributionImpl(10.0, 1.0);
                                                                                                        dist5.setMean(7.5);
                                                                                                        assertEquals(7.5, dist5.getMean(), 0.0001);
                                                                                                    }

    @Test
                                                                                                public void testGettersAfterConstruction() {
                                                                                                    // Arrange
                                                                                                    double expectedMean = 5.0;
                                                                                                    double expectedStdDev = 2.5;
                                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, expectedStdDev);
                                                                                                    
                                                                                                    // Act
                                                                                                    double actualMean = distribution.getMean();
                                                                                                    double actualStdDev = distribution.getStandardDeviation();
                                                                                                    
                                                                                                    // Assert
                                                                                                    assertEquals("Mean should match constructor value", 
                                                                                                        expectedMean, actualMean, 0.0001);
                                                                                                    assertEquals("Standard deviation should match constructor value",
                                                                                                        expectedStdDev, actualStdDev, 0.0001);
                                                                                                }

    @Test
                                                                                                public void testGettersAfterSetters() {
                                                                                                    // Arrange
                                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                    double expectedMean = 10.0;
                                                                                                    double expectedStdDev = 3.0;
                                                                                                    
                                                                                                    // Act
                                                                                                    distribution.setMean(expectedMean);
                                                                                                    distribution.setStandardDeviation(expectedStdDev);
                                                                                                    double actualMean = distribution.getMean();
                                                                                                    double actualStdDev = distribution.getStandardDeviation();
                                                                                                    
                                                                                                    // Assert
                                                                                                    assertEquals("Mean should match set value", 
                                                                                                        expectedMean, actualMean, 0.0001);
                                                                                                    assertEquals("Standard deviation should match set value",
                                                                                                        expectedStdDev, actualStdDev, 0.0001);
                                                                                                }

    @Test
                                                                                            public void testSetStandardDeviationWithNegativeValue4() {
                                                                                                // Test with negative value to detect the Math.abs mutant
                                                                                                double negativeSD = -1.5;
                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                
                                                                                                // Set the standard deviation to a negative value
                                                                                                dist.setStandardDeviation(negativeSD);
                                                                                                
                                                                                                // Original behavior would store the negative value as-is
                                                                                                // Mutant behavior would store the absolute value
                                                                                                // So we assert it should equal exactly what we set (negative value)
                                                                                                assertEquals("Standard deviation should store exact input value", 
                                                                                                             negativeSD, dist.getStandardDeviation(), 0.0001);
                                                                                            }

    @Test
                                                                                            public void testSetStandardDeviationWithPositiveValue1() {
                                                                                                // Also test with positive value for completeness
                                                                                                double positiveSD = 1.5;
                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                
                                                                                                dist.setStandardDeviation(positiveSD);
                                                                                                
                                                                                                assertEquals("Standard deviation should store exact input value", 
                                                                                                             positiveSD, dist.getStandardDeviation(), 0.0001);
                                                                                            }

    @Test
                                                                                        public void testGetMeanReturnsCorrectValue13() {
                                                                                            // Arrange
                                                                                            double expectedMean = 5.0;
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                                                                                            
                                                                                            // Act
                                                                                            double actualMean = distribution.getMean();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals("Mean value should match what was set in constructor", 
                                                                                                        expectedMean, actualMean, 0.0001);
                                                                                        }

    @Test
                                                                                        public void testGetMeanAfterSetMean2() {
                                                                                            // Arrange
                                                                                            double initialMean = 0.0;
                                                                                            double newMean = 10.0;
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(initialMean, 1.0);
                                                                                            
                                                                                            // Act
                                                                                            distribution.setMean(newMean);
                                                                                            double actualMean = distribution.getMean();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals("Mean value should match what was set via setMean", 
                                                                                                        newMean, actualMean, 0.0001);
                                                                                        }

    @Test
                                                                                        public void testGetMeanDefaultConstructor() {
                                                                                            // Arrange
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                            double expectedMean = 0.0; // From default constructor
                                                                                            
                                                                                            // Act
                                                                                            double actualMean = distribution.getMean();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals("Default mean should be 0.0", 
                                                                                                        expectedMean, actualMean, 0.0001);
                                                                                        }

    @Test
                                                                                public void testGetMean() {
                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(5.0, 2.0);
                                                                                    assertEquals(5.0, dist.getMean(), 0.0);
                                                                                }

    @Test
                                                                            public void testCumulativeProbabilityAtLowerBoundary2() throws Exception {
                                                                                // Setup normal distribution with mean=10 and standard deviation=1
                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 1.0);
                                                                                
                                                                                // Calculate the exact boundary value
                                                                                double boundaryValue = 10.0 - 20 * 1.0; // mean - 20*standardDeviation
                                                                                
                                                                                // Test the boundary value
                                                                                double result = dist.cumulativeProbability(boundaryValue);
                                                                                
                                                                                // The original code would treat this as not satisfying the condition
                                                                                // while the mutant would treat it as satisfying the condition
                                                                                // We need to verify the behavior matches the original
                                                                                
                                                                                // For a normal distribution, values this far from mean should have 
                                                                                // cumulative probability very close to 0
                                                                                assertEquals(0.0, result, 1e-10);
                                                                                
                                                                                // Also test a value just above the boundary to ensure both cases are covered
                                                                                double justAboveBoundary = boundaryValue + 1e-10;
                                                                                double resultAbove = dist.cumulativeProbability(justAboveBoundary);
                                                                                assertEquals(0.0, resultAbove, 1e-10);
                                                                            }

    @Test
                                                                    public void testCumulativeProbabilityForExtremeLowValues() throws org.apache.commons.math.MathException {
                                                                        // Setup - create distribution with mean 0 and SD 1 for simplicity
                                                                        double mean = 0.0;
                                                                        double sd = 1.0;
                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                        
                                                                        // Test a value between 10-20 SDs below mean (original vs mutant will differ)
                                                                        double x = -15.0; // 15 SDs below mean
                                                                        
                                                                        // Calculate expected result - should be very close to 0 for 15 SDs below
                                                                        double expected = 0.0; // For practical purposes
                                                                        
                                                                        // Verify
                                                                        double actual = distribution.cumulativeProbability(x);
                                                                        assertEquals("Cumulative probability for extreme low value", expected, actual, 1e-10);
                                                                        
                                                                        // The mutant would return a different (non-zero) value here because it would
                                                                        // not treat -15 as an extreme value (since 15 > 10)
                                                                    }

    @Test
                                                            public void testCumulativeProbabilityDetectsMutant2() throws MathException {
                                                                // Setup test with known mean and standard deviation
                                                                double mean = 100.0;
                                                                double sd = 5.0;
                                                                NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                
                                                                // Calculate the original boundary (20 SDs below mean)
                                                                double boundary = mean - 20 * sd;
                                                                
                                                                // Choose a test value between boundary and mean
                                                                double testValue = mean - 10 * sd; // 50.0 (between -20SD and mean)
                                                                
                                                                // In original code, this value would be above the boundary
                                                                // In mutated code, it would be below the mean and trigger different behavior
                                                                
                                                                // Get actual probability
                                                                double probability = dist.cumulativeProbability(testValue);
                                                                
                                                                // Verify it's not treating it as a special case (original behavior)
                                                                // The exact expected value would depend on the implementation,
                                                                // but it should be a normal probability calculation, not 0 or some special value
                                                                assertTrue("Probability should be greater than 0", probability > 0);
                                                                assertTrue("Probability should be less than 0.5 for value below mean", probability < 0.5);
                                                                
                                                                // For the mutated version, the probability might be 0 or handled differently,
                                                                // so these assertions would fail
                                                            }

    @Test
                                                            public void testGetMeanReturnsCorrectValue14() {
                                                                // Test with default constructor (mean = 0.0)
                                                                NormalDistributionImpl dist1 = new NormalDistributionImpl();
                                                                assertEquals(0.0, dist1.getMean(), 0.0001);
                                                                
                                                                // Test with explicit mean value
                                                                NormalDistributionImpl dist2 = new NormalDistributionImpl(5.0, 1.0);
                                                                assertEquals(5.0, dist2.getMean(), 0.0001);
                                                                
                                                                // Test after changing mean
                                                                NormalDistributionImpl dist3 = new NormalDistributionImpl();
                                                                dist3.setMean(10.5);
                                                                assertEquals(10.5, dist3.getMean(), 0.0001);
                                                                
                                                                // Test with negative mean
                                                                NormalDistributionImpl dist4 = new NormalDistributionImpl(-3.2, 1.0);
                                                                assertEquals(-3.2, dist4.getMean(), 0.0001);
                                                            }

    @Test
                                                        public void testGetMeanReturnsCorrectValue15() {
                                                            // Test with positive mean
                                                            NormalDistributionImpl dist1 = new NormalDistributionImpl(5.0, 1.0);
                                                            assertEquals("Getter should return the set mean value", 5.0, dist1.getMean(), 0.0001);
                                                            
                                                            // Test with negative mean
                                                            NormalDistributionImpl dist2 = new NormalDistributionImpl(-3.5, 1.0);
                                                            assertEquals("Getter should return the set mean value", -3.5, dist2.getMean(), 0.0001);
                                                            
                                                            // Test with zero mean
                                                            NormalDistributionImpl dist3 = new NormalDistributionImpl(0.0, 1.0);
                                                            assertEquals("Getter should return the set mean value", 0.0, dist3.getMean(), 0.0001);
                                                            
                                                            // Test with default constructor (mean should be 0.0)
                                                            NormalDistributionImpl dist4 = new NormalDistributionImpl();
                                                            assertEquals("Default constructor should set mean to 0.0", 0.0, dist4.getMean(), 0.0001);
                                                        }

    @Test
                                                    public void testGetMeanReturnsCorrectValue16() {
                                                        // Test with positive mean
                                                        double expectedMean1 = 5.0;
                                                        NormalDistributionImpl distribution1 = new NormalDistributionImpl(expectedMean1, 1.0);
                                                        assertEquals("Getter should return the mean value set in constructor", 
                                                                    expectedMean1, distribution1.getMean(), 0.0001);
                                                        
                                                        // Test with negative mean
                                                        double expectedMean2 = -3.5;
                                                        NormalDistributionImpl distribution2 = new NormalDistributionImpl(expectedMean2, 1.0);
                                                        assertEquals("Getter should return the mean value set in constructor", 
                                                                    expectedMean2, distribution2.getMean(), 0.0001);
                                                        
                                                        // Test with zero mean
                                                        double expectedMean3 = 0.0;
                                                        NormalDistributionImpl distribution3 = new NormalDistributionImpl(expectedMean3, 1.0);
                                                        assertEquals("Getter should return the mean value set in constructor", 
                                                                    expectedMean3, distribution3.getMean(), 0.0001);
                                                    }

    @Test
                                                public void testGetMeanReturnsCorrectValue17() {
                                                    // Test with positive mean
                                                    double expectedMean1 = 5.0;
                                                    NormalDistributionImpl distribution1 = new NormalDistributionImpl(expectedMean1, 1.0);
                                                    assertEquals("Mean should match constructor value", expectedMean1, distribution1.getMean(), 0.0001);
                                            
                                                    // Test with negative mean
                                                    double expectedMean2 = -3.5;
                                                    NormalDistributionImpl distribution2 = new NormalDistributionImpl(expectedMean2, 1.0);
                                                    assertEquals("Mean should match constructor value", expectedMean2, distribution2.getMean(), 0.0001);
                                            
                                                    // Test with zero mean
                                                    double expectedMean3 = 0.0;
                                                    NormalDistributionImpl distribution3 = new NormalDistributionImpl(expectedMean3, 1.0);
                                                    assertEquals("Mean should match constructor value", expectedMean3, distribution3.getMean(), 0.0001);
                                            
                                                    // Test after changing mean
                                                    double newMean = 2.7;
                                                    distribution1.setMean(newMean);
                                                    assertEquals("Mean should match set value", newMean, distribution1.getMean(), 0.0001);
                                                }

    @Test
                                    public void testCumulativeProbabilityBoundaryCondition3() throws MathException {
                                        // Setup normal distribution with mean=0, sd=1
                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                        
                                        // Test boundary case (x = mean + 20*sd)
                                        double boundaryValue = 0.0 + 20 * 1.0;
                                        double result = dist.cumulativeProbability(boundaryValue);
                                        
                                        // The exact expected value isn't specified, but we know it should be very close to 1
                                        // for 20 standard deviations above mean
                                        assertEquals(1.0, result, 1e-10);
                                        
                                        // Test value just below boundary
                                        double justBelow = boundaryValue - 1e-10;
                                        double belowResult = dist.cumulativeProbability(justBelow);
                                        assertTrue(belowResult < 1.0);
                                        
                                        // Test value just above boundary
                                        double justAbove = boundaryValue + 1e-10;
                                        double aboveResult = dist.cumulativeProbability(justAbove);
                                        assertEquals(1.0, aboveResult, 1e-10);
                                    }

    @Test
                            public void testCumulativeProbabilityAtUpperBoundary1() throws MathException {
                                double mean = 10.0;
                                double sd = 2.0;
                                NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                
                                // Calculate the exact boundary value
                                double boundaryValue = mean + 20 * sd;
                                
                                // The original code would treat this as outside the upper bound
                                // The mutated code would treat this as inside the upper bound
                                // Therefore we need to verify the behavior at this exact point
                                
                                // Since we don't have the implementation of cumulativeProbability,
                                // we'll assume it returns different values for inside vs outside bounds
                                // In reality, we'd need to know the expected behavior
                                
                                // This test would fail if the mutation is present, as the boundary behavior changes
                                double result = dist.cumulativeProbability(boundaryValue);
                                
                                // We can't know the exact expected value without seeing the implementation,
                                // but we can verify it's not the same as the value just below the boundary
                                double justBelow = dist.cumulativeProbability(boundaryValue - Double.MIN_VALUE);
                                assertNotEquals("Boundary value should produce different result than values below it", 
                                              justBelow, result, 0.0001);
                            }

    @Test
                    public void testCumulativeProbabilityForExtremeValues5() throws Exception {
                        // Setup with mean=0 and standard deviation=1 for simplicity
                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                        
                        // Test value just below 10 SDs (should be treated normally)
                        double x1 = 9.9;
                        double result1 = dist.cumulativeProbability(x1);
                        assertTrue("Value below 10 SDs should be treated normally", result1 < 1.0);
                        
                        // Test value between 10 and 20 SDs (mutant will treat this differently)
                        double x2 = 15.0;
                        double result2 = dist.cumulativeProbability(x2);
                        
                        // Original code would treat this as extreme (probability ~1.0)
                        // Mutant would treat it differently
                        // We expect probability to be very close to 1 (practically 1 for 15 SDs)
                        assertEquals("Value between 10-20 SDs should be treated as extreme", 
                                    1.0, result2, 1e-10);
                        
                        // Test value above 20 SDs (both original and mutant treat as extreme)
                        double x3 = 25.0;
                        double result3 = dist.cumulativeProbability(x3);
                        assertEquals("Value above 20 SDs should be treated as extreme", 
                                    1.0, result3, 1e-10);
                    }

    @Test
            public void testCumulativeProbabilityForExtremeValues6() {
                // Setup with known mean and standard deviation
                double mean = 0.0;
                double stddev = 1.0;
                NormalDistributionImpl dist = new NormalDistributionImpl(mean, stddev);
                
                // Calculate the boundary value (20 std deviations above mean)
                double boundaryValue = mean + 20 * stddev;
                
                // Test value just below boundary
                double justBelowBoundary = boundaryValue - 0.1;
                
                // Test value at boundary
                double atBoundary = boundaryValue;
                
                // Test value above boundary
                double aboveBoundary = boundaryValue + 0.1;
                
                // Test extreme value
                double extremeValue = boundaryValue + 100;
                
                // For the original code, values above boundary should have probability ~1.0
                // For the mutated code (true condition), all values would get the same special handling
                
                // The key test is that values below boundary should have different behavior than above
                double probBelow = 0;
                double probAbove = 0;
                try {
                    probBelow = dist.cumulativeProbability(justBelowBoundary);
                    probAbove = dist.cumulativeProbability(aboveBoundary);
                } catch (MathException e) {
                    fail("Unexpected MathException: " + e.getMessage());
                }
                
                // These should not be equal (unless we're dealing with extreme tail values)
                assertNotEquals("Probability below and above boundary should differ", 
                               probBelow, probAbove, 0.0001);
                
                // Extreme value should be very close to 1.0
                try {
                    assertEquals(1.0, dist.cumulativeProbability(extremeValue), 0.0001);
                } catch (MathException e) {
                    fail("Unexpected MathException: " + e.getMessage());
                }
            }

    @Test
            public void testGetMeanReturnsCorrectValue18() {
                // Create instance with specific mean value (5.0)
                double expectedMean = 5.0;
                NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                
                // Verify getMean returns the correct value
                double actualMean = distribution.getMean();
                
                // This assertion will catch the mutant that returns 0.0
                assertEquals("getMean() should return the set mean value", 
                            expectedMean, actualMean, 0.0001);
            }

    @Test
            public void testGetMeanWithZeroMean1() {
                // Test with mean set to 0.0 (edge case)
                double expectedMean = 0.0;
                NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                
                double actualMean = distribution.getMean();
                
                // This test ensures the method works correctly with 0.0 mean
                assertEquals("getMean() should return 0.0 when mean is set to 0.0",
                            expectedMean, actualMean, 0.0001);
            }

    @Test
            public void testGetMeanWithNegativeMean1() {
                // Test with negative mean value
                double expectedMean = -2.5;
                NormalDistributionImpl distribution = new NormalDistributionImpl(expectedMean, 1.0);
                
                double actualMean = distribution.getMean();
                
                // This test ensures the method works with negative values
                assertEquals("getMean() should return negative values when set",
                            expectedMean, actualMean, 0.0001);
            }

    @Test
        public void testGetMeanReturnsCorrectValue19() {
            // Test with positive mean
            double mean1 = 5.0;
            NormalDistributionImpl dist1 = new NormalDistributionImpl(mean1, 1.0);
            assertEquals("Getter should return the exact mean value that was set", 
                         mean1, dist1.getMean(), 0.0001);
            
            // Test with negative mean
            double mean2 = -3.5;
            NormalDistributionImpl dist2 = new NormalDistributionImpl(mean2, 1.0);
            assertEquals("Getter should return the exact mean value that was set", 
                         mean2, dist2.getMean(), 0.0001);
            
            // Test with zero mean
            double mean3 = 0.0;
            NormalDistributionImpl dist3 = new NormalDistributionImpl(mean3, 1.0);
            assertEquals("Getter should return the exact mean value that was set", 
                         mean3, dist3.getMean(), 0.0001);
            
            // Test with very large mean
            double mean4 = Double.MAX_VALUE;
            NormalDistributionImpl dist4 = new NormalDistributionImpl(mean4, 1.0);
            assertEquals("Getter should return the exact mean value that was set", 
                         mean4, dist4.getMean(), 0.0001);
            
            // Test with very small (negative) mean
            double mean5 = -Double.MAX_VALUE;
            NormalDistributionImpl dist5 = new NormalDistributionImpl(mean5, 1.0);
            assertEquals("Getter should return the exact mean value that was set", 
                         mean5, dist5.getMean(), 0.0001);
        }

    @Test
        public void testGetMeanAfterChangingValue1() {
            // Test changing mean after construction
            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
            
            double newMean1 = 10.5;
            dist.setMean(newMean1);
            assertEquals("Getter should return updated mean value", 
                         newMean1, dist.getMean(), 0.0001);
            
            double newMean2 = -7.2;
            dist.setMean(newMean2);
            assertEquals("Getter should return updated mean value", 
                         newMean2, dist.getMean(), 0.0001);
        }

}
