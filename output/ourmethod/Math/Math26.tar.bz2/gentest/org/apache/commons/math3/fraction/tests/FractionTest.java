package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                            public void testConstructor_WholeNumbers() {
                                Fraction fraction1 = new Fraction(0.0);
                                assertEquals(0, fraction1.getNumerator());
                                assertEquals(1, fraction1.getDenominator());
                                
                                Fraction fraction2 = new Fraction(1.0);
                                assertEquals(1, fraction2.getNumerator());
                                assertEquals(1, fraction2.getDenominator());
                                
                                Fraction fraction3 = new Fraction(-2.0);
                                assertEquals(-2, fraction3.getNumerator());
                                assertEquals(1, fraction3.getDenominator());
                            }

    @Test
                            public void testConstructor_CommonFractions() {
                                Fraction fraction1 = new Fraction(0.5);
                                assertEquals(1, fraction1.getNumerator());
                                assertEquals(2, fraction1.getDenominator());
                                
                                Fraction fraction2 = new Fraction(0.333333333);
                                assertEquals(1, fraction2.getNumerator());
                                assertEquals(3, fraction2.getDenominator());
                                
                                Fraction fraction3 = new Fraction(0.666666667);
                                assertEquals(2, fraction3.getNumerator());
                                assertEquals(3, fraction3.getDenominator());
                                
                                Fraction fraction4 = new Fraction(0.2);
                                assertEquals(1, fraction4.getNumerator());
                                assertEquals(5, fraction4.getDenominator());
                            }

    @Test
                            public void testConstructor_NegativeFractions() {
                                Fraction fraction1 = new Fraction(-0.5);
                                assertEquals(-1, fraction1.getNumerator());
                                assertEquals(2, fraction1.getDenominator());
                                
                                Fraction fraction2 = new Fraction(-0.333333333);
                                assertEquals(-1, fraction2.getNumerator());
                                assertEquals(3, fraction2.getDenominator());
                            }

    @Test
                            public void testConstructor_ApproximateFractions() {
                                // Test values that are close but not exact
                                Fraction fraction1 = new Fraction(0.666666); // close to 2/3
                                assertEquals(2, fraction1.getNumerator());
                                assertEquals(3, fraction1.getDenominator());
                                
                                Fraction fraction2 = new Fraction(0.142857); // close to 1/7
                                assertEquals(1, fraction2.getNumerator());
                                assertEquals(7, fraction2.getDenominator());
                            }

    @Test
                            public void testConstructor_EdgeCases() {
                                // Very small value
                                Fraction fraction1 = new Fraction(1.0e-6);
                                assertTrue(Math.abs(fraction1.doubleValue() - 1.0e-6) < 1.0e-5);
                                
                                // Very large value
                                Fraction fraction2 = new Fraction(1.0e6);
                                assertEquals(1000000, fraction2.getNumerator());
                                assertEquals(1, fraction2.getDenominator());
                                
                                // NaN should throw exception
                                thrown.expect(IllegalArgumentException.class);
                                new Fraction(Double.NaN);
                            }

    @Test
                            public void testConstructor_InfinityCases() {
                                thrown.expect(IllegalArgumentException.class);
                                new Fraction(Double.POSITIVE_INFINITY);
                                
                                thrown.expect(IllegalArgumentException.class);
                                new Fraction(Double.NEGATIVE_INFINITY);
                            }

    @Test
                            public void testConstructor_CompareWithConstants() {
                                Fraction half = new Fraction(0.5);
                                assertEquals(Fraction.ONE_HALF.getNumerator(), half.getNumerator());
                                assertEquals(Fraction.ONE_HALF.getDenominator(), half.getDenominator());
                                
                                Fraction third = new Fraction(0.333333333);
                                assertEquals(Fraction.ONE_THIRD.getNumerator(), third.getNumerator());
                                assertEquals(Fraction.ONE_THIRD.getDenominator(), third.getDenominator());
                                
                                Fraction twoThirds = new Fraction(0.666666667);
                                assertEquals(Fraction.TWO_THIRDS.getNumerator(), twoThirds.getNumerator());
                                assertEquals(Fraction.TWO_THIRDS.getDenominator(), twoThirds.getDenominator());
                            }

    @Test
                            public void testConstructor_ExactValue() {
                                // Test with exact values that have precise fraction representations
                                Fraction fraction = new Fraction(0.5, 0.00001, 100);
                                assertEquals(1, fraction.getNumerator());
                                assertEquals(2, fraction.getDenominator());
                                
                                fraction = new Fraction(0.3333333333333333, 0.00001, 100);
                                assertEquals(1, fraction.getNumerator());
                                assertEquals(3, fraction.getDenominator());
                            }

    @Test
                            public void testConstructor_ApproximateValue() {
                                // Test with values that need approximation
                                Fraction fraction = new Fraction(Math.PI, 0.00001, 1000);
                                assertTrue(Math.abs(Math.PI - fraction.doubleValue()) <= 0.00001);
                                
                                fraction = new Fraction(0.123456789, 0.0000001, 1000);
                                assertTrue(Math.abs(0.123456789 - fraction.doubleValue()) <= 0.0000001);
                            }

    @Test
                            public void testConstructor_EdgeCases1() {
                                // Test with zero
                                Fraction fraction = new Fraction(0.0, 0.00001, 100);
                                assertEquals(Fraction.ZERO, fraction);
                                
                                // Test with one
                                fraction = new Fraction(1.0, 0.00001, 100);
                                assertEquals(Fraction.ONE, fraction);
                                
                                // Test with negative value
                                fraction = new Fraction(-0.5, 0.00001, 100);
                                assertEquals(-1, fraction.getNumerator());
                                assertEquals(2, fraction.getDenominator());
                            }

    @Test
                            public void testConstructor_InvalidEpsilon() {
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("epsilon must be > 0");
                                new Fraction(0.5, -0.00001, 100);
                            }

    @Test
                            public void testConstructor_ZeroEpsilon() {
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("epsilon must be > 0");
                                new Fraction(0.5, 0.0, 100);
                            }

    @Test
                            public void testConstructor_InvalidMaxIterations() {
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("maximum number of iterations must be > 0");
                                new Fraction(0.5, 0.00001, 0);
                            }

    @Test
                            public void testConstructor_ConvergenceFailure() {
                                thrown.expect(ArithmeticException.class);
                                thrown.expectMessage("unable to convert double to fraction");
                                // Use a very small epsilon and small max iterations to force failure
                                new Fraction(Math.PI, 1e-20, 10);
                            }

    @Test
                            public void testConstructor_Infinity() {
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("value must be finite");
                                new Fraction(Double.POSITIVE_INFINITY, 0.00001, 100);
                            }

    @Test
                            public void testConstructor_NaN() {
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("value must be finite");
                                new Fraction(Double.NaN, 0.00001, 100);
                            }

    @Test
                            public void testConstructor_WholeNumbers1() {
                                Fraction fraction = new Fraction(5.0, 0.00001, 100);
                                assertEquals(5, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                                
                                fraction = new Fraction(-3.0, 0.00001, 100);
                                assertEquals(-3, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                            }

    @Test
                            public void testConstructor_VerySmallEpsilon() {
                                // Test with very tight tolerance
                                Fraction fraction = new Fraction(0.123456789, 1e-10, 10000);
                                assertTrue(Math.abs(0.123456789 - fraction.doubleValue()) <= 1e-10);
                            }

    @Test
                            public void testConstructor_SimpleFractions() {
                                // Test simple fractions that can be exactly represented
                                Fraction half = new Fraction(0.5, 100);
                                assertEquals(1, half.getNumerator());
                                assertEquals(2, half.getDenominator());
                                
                                Fraction third = new Fraction(1.0/3, 100);
                                assertEquals(1, third.getNumerator());
                                assertEquals(3, third.getDenominator());
                                
                                Fraction twoThirds = new Fraction(2.0/3, 100);
                                assertEquals(2, twoThirds.getNumerator());
                                assertEquals(3, twoThirds.getDenominator());
                            }

    @Test
                            public void testConstructor_WholeNumbers2() {
                                // Test whole number values
                                Fraction zero = new Fraction(0.0, 100);
                                assertEquals(0, zero.getNumerator());
                                assertEquals(1, zero.getDenominator());
                                
                                Fraction one = new Fraction(1.0, 100);
                                assertEquals(1, one.getNumerator());
                                assertEquals(1, one.getDenominator());
                                
                                Fraction five = new Fraction(5.0, 100);
                                assertEquals(5, five.getNumerator());
                                assertEquals(1, five.getDenominator());
                            }

    @Test
                            public void testConstructor_NegativeNumbers() {
                                // Test negative values
                                Fraction negativeHalf = new Fraction(-0.5, 100);
                                assertEquals(-1, negativeHalf.getNumerator());
                                assertEquals(2, negativeHalf.getDenominator());
                                
                                Fraction negativeTwoThirds = new Fraction(-2.0/3, 100);
                                assertEquals(-2, negativeTwoThirds.getNumerator());
                                assertEquals(3, negativeTwoThirds.getDenominator());
                            }

    @Test
                            public void testConstructor_MaxDenominatorLimit() {
                                // Test that the max denominator is respected
                                Fraction piApprox = new Fraction(Math.PI, 10);
                                assertEquals(22, piApprox.getNumerator());
                                assertEquals(7, piApprox.getDenominator());
                                
                                Fraction piApproxBetter = new Fraction(Math.PI, 100);
                                assertEquals(311, piApproxBetter.getNumerator());
                                assertEquals(99, piApproxBetter.getDenominator());
                                
                                // Test with very small max denominator
                                Fraction goldenRatio = new Fraction(1.61803398875, 1);
                                assertEquals(2, goldenRatio.getNumerator());
                                assertEquals(1, goldenRatio.getDenominator());
                            }

    @Test
                            public void testConstructor_EdgeCases2() {
                                // Test very small values
                                Fraction smallValue = new Fraction(0.0001, 1000);
                                assertEquals(1, smallValue.getNumerator());
                                assertEquals(9999, smallValue.getDenominator());
                                
                                // Test values very close to 1
                                Fraction almostOne = new Fraction(0.9999, 100);
                                assertEquals(100, almostOne.getNumerator());
                                assertEquals(100, almostOne.getDenominator());
                            }

    @Test
                            public void testConstructor_InvalidMaxDenominator() {
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("maxDenominator must be positive");
                                new Fraction(0.5, 0);
                            }

    @Test
                            public void testConstructor_ExtremeValues() {
                                // Test very large values
                                Fraction largeValue = new Fraction(1.0e6, 100);
                                assertEquals(1000000, largeValue.getNumerator());
                                assertEquals(1, largeValue.getDenominator());
                                
                                // Test very large denominator cases
                                Fraction preciseValue = new Fraction(0.123456789, 1000000);
                                // Verify the approximation is reasonable
                                double error = Math.abs(preciseValue.doubleValue() - 0.123456789);
                                assertTrue(error < 1.0e-8);
                            }

    @Test
                            public void testConstructor_CompareWithStaticConstants() {
                                // Test that constructor matches static constants
                                Fraction half = new Fraction(0.5, 100);
                                assertEquals(Fraction.ONE_HALF.getNumerator(), half.getNumerator());
                                assertEquals(Fraction.ONE_HALF.getDenominator(), half.getDenominator());
                                
                                Fraction third = new Fraction(1.0/3, 100);
                                assertEquals(Fraction.ONE_THIRD.getNumerator(), third.getNumerator());
                                assertEquals(Fraction.ONE_THIRD.getDenominator(), third.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_PositiveNumber() {
                                Fraction fraction = new Fraction(3);
                                assertEquals(3, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_NegativeNumber() {
                                Fraction fraction = new Fraction(-5);
                                assertEquals(-5, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_Zero() {
                                Fraction fraction = new Fraction(0);
                                assertEquals(0, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_MaxIntegerValue() {
                                Fraction fraction = new Fraction(Integer.MAX_VALUE);
                                assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_MinIntegerValue() {
                                Fraction fraction = new Fraction(Integer.MIN_VALUE);
                                assertEquals(Integer.MIN_VALUE, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_EqualsOneConstant() {
                                Fraction fraction = new Fraction(1);
                                assertEquals(1, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                                assertEquals(Fraction.ONE.getNumerator(), fraction.getNumerator());
                                assertEquals(Fraction.ONE.getDenominator(), fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_EqualsMinusOneConstant() {
                                Fraction fraction = new Fraction(-1);
                                assertEquals(-1, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                                assertEquals(Fraction.MINUS_ONE.getNumerator(), fraction.getNumerator());
                                assertEquals(Fraction.MINUS_ONE.getDenominator(), fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_EqualsTwoConstant() {
                                Fraction fraction = new Fraction(2);
                                assertEquals(2, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                                assertEquals(Fraction.TWO.getNumerator(), fraction.getNumerator());
                                assertEquals(Fraction.TWO.getDenominator(), fraction.getDenominator());
                            }

    @Test
                            public void testConstructorWithNumerator_ResultingFractionIsReduced() {
                                // Even though we're passing just numerator, the resulting fraction should be in simplest form
                                Fraction fraction = new Fraction(4);
                                assertEquals(4, fraction.getNumerator());
                                assertEquals(1, fraction.getDenominator());
                                // Verify it's not equal to fractions that would simplify to the same value
                                assertNotEquals(Fraction.FOUR_FIFTHS, fraction);
                                assertNotEquals(Fraction.TWO_THIRDS, fraction);
                            }

    @Test
                            public void testConstructorWithNumerator_EqualsMethodWorks() {
                                Fraction fraction1 = new Fraction(7);
                                Fraction fraction2 = new Fraction(7);
                                assertTrue(fraction1.equals(fraction2));
                            }

    @Test
                            public void testConstructorWithNumerator_ToString() {
                                Fraction fraction = new Fraction(3);
                                assertEquals("3", fraction.toString());
                            }

    @Test
                            public void testConstructor_NormalPositiveFraction() {
                                Fraction f = new Fraction(3, 4);
                                assertEquals(3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_NormalNegativeFraction() {
                                Fraction f = new Fraction(-3, 4);
                                assertEquals(-3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_DenominatorNegative() {
                                Fraction f = new Fraction(3, -4);
                                assertEquals(-3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_BothNegative() {
                                Fraction f = new Fraction(-3, -4);
                                assertEquals(3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_ReducesFraction() {
                                Fraction f = new Fraction(6, 8);
                                assertEquals(3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_ReducesNegativeFraction() {
                                Fraction f = new Fraction(-6, 8);
                                assertEquals(-3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_ReducesWhenDenominatorNegative() {
                                Fraction f = new Fraction(6, -8);
                                assertEquals(-3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_ReducesWhenBothNegative() {
                                Fraction f = new Fraction(-6, -8);
                                assertEquals(3, f.getNumerator());
                                assertEquals(4, f.getDenominator());
                            }

    @Test
                            public void testConstructor_ZeroNumerator() {
                                Fraction f = new Fraction(0, 1);
                                assertEquals(0, f.getNumerator());
                                assertEquals(1, f.getDenominator());
                            }

    @Test
                            public void testConstructor_AlreadyReduced() {
                                Fraction f = new Fraction(3, 5);
                                assertEquals(3, f.getNumerator());
                                assertEquals(5, f.getDenominator());
                            }

    @Test
                            public void testConstructor_LargeValues() {
                                Fraction f = new Fraction(123456, 987654);
                                // Assuming gcd(123456, 987654) is 6
                                assertEquals(20576, f.getNumerator());
                                assertEquals(164609, f.getDenominator());
                            }

    @Test
                            public void testConstructor_WholeNumber() {
                                Fraction f = new Fraction(5, 1);
                                assertEquals(5, f.getNumerator());
                                assertEquals(1, f.getDenominator());
                            }

    @Test
                    public void testConstructor_IntegerValue() {
                        Fraction fraction = new Fraction(3.0);
                        assertEquals(3, fraction.getNumerator());
                        assertEquals(1, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_SimpleFraction() {
                        Fraction fraction = new Fraction(0.5);
                        assertEquals(1, fraction.getNumerator());
                        assertEquals(2, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_WithinEpsilon() {
                        Fraction fraction = new Fraction(0.33333333, 0.0001, 100);
                        assertEquals(1, fraction.getNumerator());
                        assertEquals(3, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_ReachesMaxDenominator() {
                        Fraction fraction = new Fraction(Math.PI, 7);  // Using constructor with value and max denominator
                        // Should return 22/7 which is a common approximation of PI
                        assertEquals(22, fraction.getNumerator());
                        assertEquals(7, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_ReachesMaxIterations() {
                        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                        exception.expect(org.apache.commons.math3.fraction.FractionConversionException.class);
                        new org.apache.commons.math3.fraction.Fraction(Math.PI, 0.0000001, 5); // Too strict epsilon with few iterations
                    }

    @Test(expected = FractionConversionException.class)
                    public void testConstructor_ValueTooLarge() {
                        new Fraction(Double.MAX_VALUE, 0.00001, 100);
                    }

    @Test
                    public void testConstructor_NegativeValue() {
                        Fraction fraction = new Fraction(-0.5);
                        assertEquals(-1, fraction.getNumerator());
                        assertEquals(2, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_ZeroValue() {
                        Fraction fraction = new Fraction(0.0);
                        assertEquals(0, fraction.getNumerator());
                        assertEquals(1, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_ValueVeryCloseToInteger() throws Exception {
                        // Get the private constructor
                        Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                            double.class, double.class, int.class, int.class);
                        constructor.setAccessible(true);
                        
                        // Create the fraction using the private constructor
                        Fraction fraction = constructor.newInstance(2.0000001, 0.00001, 100, 100);
                        
                        assertEquals(2, fraction.getNumerator());
                        assertEquals(1, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_ComplexFraction() {
                        Fraction fraction = new Fraction(0.42857142857, 0.00001, 100);
                        // Should approximate 3/7
                        assertEquals(3, fraction.getNumerator());
                        assertEquals(7, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_MaxDenominatorLimitation() {
                        Fraction fraction = new Fraction(0.333333, 5);
                        // With max denominator of 5, should get 1/3 rather than more precise fractions
                        assertEquals(1, fraction.getNumerator());
                        assertEquals(3, fraction.getDenominator());
                    }

    @Test
                    public void testConstructor_ZeroDenominator() {
                        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                        exception.expect(org.apache.commons.math3.exception.MathArithmeticException.class);
                        exception.expectMessage(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION.toString());
                        new Fraction(1, 0);
                    }

    @Test
                    public void testConstructor_IntegerMinValueDenominator() {
                        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                        exception.expect(org.apache.commons.math3.exception.MathArithmeticException.class);
                        exception.expectMessage(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION.toString());
                        new Fraction(1, Integer.MIN_VALUE);
                    }

    @Test
                public void testConstructor_IntegerMinValueNumerator() {
                    org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                    
                    thrown.expect(org.apache.commons.math3.exception.MathArithmeticException.class);
                    thrown.expectMessage(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION.toString());
                    new Fraction(Integer.MIN_VALUE, -1);
                }

    @Test
            public void testConstructor_OverflowDuringConversion() {
                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                exception.expect(org.apache.commons.math3.fraction.FractionConversionException.class);
                // Use a value that will cause overflow during the continued fraction calculation
                new Fraction(1.0e-10, 1.0e-20, Integer.MAX_VALUE);
            }

    @Test
        public void testAbsWithNegativeFraction() {
            // Create a negative fraction with a fractional part
            // Value of -1.6 which would be handled differently by floor vs direct cast
            Fraction fraction = new Fraction(-1.6);
            
            // The original code with floor would create -8/5 (-1.6)
            // The mutated code with direct cast might create a different fraction
            Fraction absFraction = fraction.abs();
            
            // Verify the absolute value is correct
            assertEquals(8, absFraction.getNumerator());
            assertEquals(5, absFraction.getDenominator());
            
            // Also verify the original fraction was properly constructed
            assertEquals(-8, fraction.getNumerator());
            assertEquals(5, fraction.getDenominator());
        }

    @Test
        public void testAbsWithMaxValueConversion() {
            // This test is designed to catch the mutant where overflow check uses >= instead of >
            // We need to create a fraction that would make p2 or q2 exactly Integer.MAX_VALUE
            
            // Using a value that would lead to Integer.MAX_VALUE during conversion
            // Note: The exact value needed depends on the continued fraction algorithm,
            // but we know it should work with the original code and fail with the mutant
            
            try {
                // This value is chosen because its continued fraction expansion would hit MAX_VALUE
                double value = (double)Integer.MAX_VALUE / (Integer.MAX_VALUE - 1);
                Fraction fraction = new Fraction(value, 1.0e-10, Integer.MAX_VALUE);
                
                // Test the abs method - though the real test is in the constructor
                Fraction absFraction = fraction.abs();
                
                // If we get here, the original code worked (no exception)
                // The mutant would throw FractionConversionException
                assertNotNull(absFraction);
            } catch (FractionConversionException e) {
                fail("Original code should handle exact MAX_VALUE without exception");
            }
        }

    @Test(expected = FractionConversionException.class)
        public void testConstructorWithExactOverflow() {
            // This complementary test shows that values exceeding MAX_VALUE are caught
            double overflowValue = (double)Integer.MAX_VALUE * 1.1;
            new Fraction(overflowValue, 1.0e-10, Integer.MAX_VALUE);
        }

}
