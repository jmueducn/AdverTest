package gentest.org.apache.commons.math3.analysis.differentiation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.analysis.differentiation.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class DSCompilerTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                    public void testAtan2CorrectArgumentOrder() {
                                                                                                                        // Setup test data
                                                                                                                        double[] y = {1.0};  // y coordinate
                                                                                                                        double[] x = {0.0};  // x coordinate
                                                                                                                        double[] result = new double[1];
                                                                                                                        
                                                                                                                        // Expected value: atan2(1.0, 0.0) should be π/2 (90 degrees)
                                                                                                                        double expected = Math.PI/2;
                                                                                                                        
                                                                                                                        // Create compiler instance (parameters and order don't matter for this test)
                                                                                                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                                                        
                                                                                                                        // Call the method
                                                                                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                                                                                        
                                                                                                                        // Verify the result
                                                                                                                        assertEquals("atan2 should calculate correct angle", 
                                                                                                                                    expected, result[0], 1e-10);
                                                                                                                        
                                                                                                                        // Additional test case where arguments order matters
                                                                                                                        y[0] = 1.0;
                                                                                                                        x[0] = 1.0;
                                                                                                                        expected = Math.PI/4;  // 45 degrees
                                                                                                                        
                                                                                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                                                                                        assertEquals("atan2(1,1) should be π/4", 
                                                                                                                                    expected, result[0], 1e-10);
                                                                                                                        
                                                                                                                        // Test case that would fail with swapped arguments
                                                                                                                        y[0] = 0.0;
                                                                                                                        x[0] = 1.0;
                                                                                                                        expected = 0.0;  // 0 degrees
                                                                                                                        
                                                                                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                                                                                        assertEquals("atan2(0,1) should be 0", 
                                                                                                                                    expected, result[0], 1e-10);
                                                                                                                    }

    @Test
                                                                                                                public void testAtan() {
                                                                                                                    // Setup - create a compiler instance with parameters=1, order=1
                                                                                                                    DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                                                    
                                                                                                                    // Test data - use known values where atan2 is not 0
                                                                                                                    double[] y = {1.0};
                                                                                                                    int yOffset = 0;
                                                                                                                    double[] x = {1.0};
                                                                                                                    int xOffset = 0;
                                                                                                                    double[] result = new double[1];
                                                                                                                    int resultOffset = 0;
                                                                                                                    
                                                                                                                    // Expected value - actual atan2 calculation
                                                                                                                    double expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                                                                    
                                                                                                                    // Call method
                                                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                                    
                                                                                                                    // Assert - verify result is correct atan2 value, not 0
                                                                                                                    assertEquals("atan2 result should match Math.atan2 calculation", 
                                                                                                                                expected, result[resultOffset], 0.0001);
                                                                                                                    
                                                                                                                    // Additional test case with different values
                                                                                                                    y[0] = 1.5;
                                                                                                                    x[0] = 2.5;
                                                                                                                    expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                                    assertEquals("atan2 should work for different inputs",
                                                                                                                                expected, result[resultOffset], 0.0001);
                                                                                                                    
                                                                                                                    // Edge case - x=0
                                                                                                                    y[0] = 1.0;
                                                                                                                    x[0] = 0.0;
                                                                                                                    expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                                    assertEquals("atan2 should handle x=0 case correctly",
                                                                                                                                expected, result[resultOffset], 0.0001);
                                                                                                                }

    @Test
                                                                                                            public void testAtan2Mutation() {
                                                                                                                // Setup - create a compiler instance
                                                                                                                DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                                                
                                                                                                                // Test data - use values where atan2 is not π
                                                                                                                double[] y = {1.0};
                                                                                                                int yOffset = 0;
                                                                                                                double[] x = {1.0};
                                                                                                                int xOffset = 0;
                                                                                                                double[] result = new double[1];
                                                                                                                int resultOffset = 0;
                                                                                                                
                                                                                                                // Expected value - actual atan2(1,1) = π/4
                                                                                                                double expected = Math.PI / 4;
                                                                                                                
                                                                                                                // Call method
                                                                                                                compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                                
                                                                                                                // Verify - should not be π
                                                                                                                assertNotEquals("Result should not be π", Math.PI, result[resultOffset], 0.0001);
                                                                                                                assertEquals("Result should be correct atan2 value", 
                                                                                                                            expected, result[resultOffset], 0.0001);
                                                                                                                
                                                                                                                // Additional test case with different values
                                                                                                                y[0] = 1.0;
                                                                                                                x[0] = 0.0;
                                                                                                                expected = Math.PI / 2;  // atan2(1,0) = π/2
                                                                                                                
                                                                                                                compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                                
                                                                                                                assertNotEquals("Result should not be π for vertical vector", 
                                                                                                                               Math.PI, result[resultOffset], 0.0001);
                                                                                                                assertEquals("Result should be π/2 for vertical vector",
                                                                                                                            expected, result[resultOffset], 0.0001);
                                                                                                            }

    @Test
                                                                                                        public void testAtan1() {
                                                                                                            // Setup - create a compiler instance
                                                                                                            DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                                            
                                                                                                            // Test data - cases where atan2 and atan(y/x) differ
                                                                                                            double[] y = {1.0, 1.0, -1.0, -1.0, 1.0, 0.0};  // Various y values
                                                                                                            double[] x = {1.0, -1.0, -1.0, 1.0, 0.0, 1.0};   // Various x values
                                                                                                            double[] result = new double[6];
                                                                                                            
                                                                                                            int yOffset = 0;
                                                                                                            int xOffset = 0;
                                                                                                            int resultOffset = 0;
                                                                                                            
                                                                                                            // Expected results from Math.atan2
                                                                                                            double[] expected = {
                                                                                                                Math.PI/4,       // 45° Q1
                                                                                                                3*Math.PI/4,     // 135° Q2
                                                                                                                -3*Math.PI/4,    // -135° Q3
                                                                                                                -Math.PI/4,      // -45° Q4
                                                                                                                Math.PI/2,       // 90° (x=0)
                                                                                                                0.0              // 0° (y=0)
                                                                                                            };
                                                                                                            
                                                                                                            // Execute
                                                                                                            compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                            
                                                                                                            // Verify - check all test cases
                                                                                                            for (int i = 0; i < expected.length; i++) {
                                                                                                                assertEquals("Mismatch at case " + i, expected[i], result[i], 1e-10);
                                                                                                            }
                                                                                                            
                                                                                                            // Additional edge case: both zero
                                                                                                            try {
                                                                                                                double[] zeroY = {0.0};
                                                                                                                double[] zeroX = {0.0};
                                                                                                                double[] zeroResult = new double[1];
                                                                                                                compiler.atan2(zeroY, 0, zeroX, 0, zeroResult, 0);
                                                                                                                fail("Expected ArithmeticException for atan2(0,0)");
                                                                                                            } catch (ArithmeticException e) {
                                                                                                                // Expected behavior
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                    public void testAtan2CalculatesCorrectAngle() {
                                                                                                        // Setup test data
                                                                                                        double[] y = {1.0};  // y coordinate
                                                                                                        int yOffset = 0;
                                                                                                        double[] x = {1.0};  // x coordinate
                                                                                                        int xOffset = 0;
                                                                                                        double[] result = new double[1];
                                                                                                        int resultOffset = 0;
                                                                                                        
                                                                                                        // Expected value: atan2(1,1) = π/4 radians
                                                                                                        double expected = Math.PI/4;
                                                                                                        
                                                                                                        // Get a compiler instance (parameters=1, order=1)
                                                                                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                                        
                                                                                                        // Call the method
                                                                                                        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                        
                                                                                                        // Verify the calculation
                                                                                                        assertEquals("atan2 should calculate correct angle", 
                                                                                                                    expected, 
                                                                                                                    result[resultOffset], 
                                                                                                                    0.000001);
                                                                                                        
                                                                                                        // Additional test case with different values
                                                                                                        y[0] = 1.0;
                                                                                                        x[0] = 0.0;
                                                                                                        expected = Math.PI/2;  // 90 degrees
                                                                                                        
                                                                                                        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                        assertEquals("atan2 should handle vertical angle", 
                                                                                                                    expected, 
                                                                                                                    result[resultOffset], 
                                                                                                                    0.000001);
                                                                                                        
                                                                                                        // Test with negative values
                                                                                                        y[0] = -1.0;
                                                                                                        x[0] = -1.0;
                                                                                                        expected = -3*Math.PI/4;  // -135 degrees
                                                                                                        
                                                                                                        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                        assertEquals("atan2 should handle negative coordinates", 
                                                                                                                    expected, 
                                                                                                                    result[resultOffset], 
                                                                                                                    0.000001);
                                                                                                    }

    @Test
                                                                                                public void testAtan2DetectsMutant() {
                                                                                                    // Setup - create a compiler instance
                                                                                                    DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                                    
                                                                                                    // Test data - use values where atan2(y,x) != x
                                                                                                    double[] y = {1.0};
                                                                                                    int yOffset = 0;
                                                                                                    double[] x = {2.0};
                                                                                                    int xOffset = 0;
                                                                                                    double[] result = new double[1];
                                                                                                    int resultOffset = 0;
                                                                                                    
                                                                                                    // Expected value
                                                                                                    double expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                                                    
                                                                                                    // Call method
                                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                    
                                                                                                    // Verify - this will fail if mutant is present
                                                                                                    assertEquals("atan2 should calculate correct value", 
                                                                                                                expected, result[resultOffset], 0.0001);
                                                                                                    
                                                                                                    // Additional test case with different values
                                                                                                    y[0] = -1.5;
                                                                                                    x[0] = 3.2;
                                                                                                    expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                    assertEquals("atan2 should calculate correct value for negative y", 
                                                                                                                expected, result[resultOffset], 0.0001);
                                                                                                    
                                                                                                    // Edge case - x is zero
                                                                                                    y[0] = 1.0;
                                                                                                    x[0] = 0.0;
                                                                                                    expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                    assertEquals("atan2 should handle x=0 case correctly",
                                                                                                                expected, result[resultOffset], 0.0001);
                                                                                                }

    @Test
                                                                                            public void testAtan2() {
                                                                                                // Setup
                                                                                                DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler with parameters=1, order=1
                                                                                                
                                                                                                // Test data - we'll use known angle values
                                                                                                double[] y = {1.0, -1.0, 0.0, 1.0};  // Various y values including positive, negative and zero
                                                                                                double[] x = {1.0, 1.0, 1.0, -1.0};   // Various x values
                                                                                                double[] result = new double[4];       // To store results
                                                                                                
                                                                                                int yOffset = 0;
                                                                                                int xOffset = 0;
                                                                                                int resultOffset = 0;
                                                                                                
                                                                                                // Expected values (in radians)
                                                                                                double expected1 = Math.PI/4;      // atan2(1,1)
                                                                                                double expected2 = -Math.PI/4;     // atan2(-1,1)
                                                                                                double expected3 = 0.0;            // atan2(0,1)
                                                                                                double expected4 = 3*Math.PI/4;    // atan2(1,-1)
                                                                                                
                                                                                                // Execute
                                                                                                compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                                
                                                                                                // Verify - check all test cases
                                                                                                assertEquals(expected1, result[0], 1e-10);
                                                                                                assertEquals(expected2, result[1], 1e-10);
                                                                                                assertEquals(expected3, result[2], 1e-10);
                                                                                                assertEquals(expected4, result[3], 1e-10);
                                                                                                
                                                                                                // The mutant would fail these assertions because:
                                                                                                // 1. For result[0], it would return -π/4 instead of π/4
                                                                                                // 2. For result[1], it would return π/4 instead of -π/4
                                                                                                // 3. For result[2], it would still return 0 (unchanged)
                                                                                                // 4. For result[3], it would return -3π/4 instead of 3π/4
                                                                                            }

    @Test
                                                                                        public void testAtan3() {
                                                                                            // Setup
                                                                                            DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler instance
                                                                                            double[] y = {1.0, 0.0, -1.0, 1.0};  // Test values for y
                                                                                            double[] x = {1.0, 1.0, 1.0, -1.0};  // Test values for x
                                                                                            double[] result = new double[4];
                                                                                            
                                                                                            // Expected results (original behavior)
                                                                                            double[] expected = {
                                                                                                Math.atan2(1.0, 1.0),   // π/4
                                                                                                Math.atan2(0.0, 1.0),   // 0
                                                                                                Math.atan2(-1.0, 1.0),  // -π/4
                                                                                                Math.atan2(1.0, -1.0)   // 3π/4
                                                                                            };
                                                                                            
                                                                                            // Mutated results (if mutation exists)
                                                                                            double[] mutated = {
                                                                                                Math.atan2(1.0, -1.0),  // 3π/4
                                                                                                Math.atan2(0.0, -1.0),  // π
                                                                                                Math.atan2(-1.0, -1.0), // -3π/4
                                                                                                Math.atan2(1.0, 1.0)    // π/4
                                                                                            };
                                                                                            
                                                                                            // Execute
                                                                                            compiler.atan2(y, 0, x, 0, result, 0);
                                                                                            
                                                                                            // Verify - this will fail if mutation exists
                                                                                            assertEquals(expected[0], result[0], 1e-10);
                                                                                            assertEquals(expected[1], result[1], 1e-10);
                                                                                            assertEquals(expected[2], result[2], 1e-10);
                                                                                            assertEquals(expected[3], result[3], 1e-10);
                                                                                            
                                                                                            // Additional check to ensure we're not getting mutated results
                                                                                            for (int i = 0; i < expected.length; i++) {
                                                                                                assertNotEquals(mutated[i], result[i], 1e-10);
                                                                                            }
                                                                                        }

    @Test
                                                                                    public void testAtan2DetectsMutant1() {
                                                                                        // Setup - create a compiler instance
                                                                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                        
                                                                                        // Test data with non-zero y values
                                                                                        double[] y = {1.0, -1.0, 1.0, -1.0};  // Different quadrants
                                                                                        double[] x = {1.0, 1.0, -1.0, -1.0};   // Different quadrants
                                                                                        double[] result = new double[4];
                                                                                        
                                                                                        // Expected results (correct atan2 calculations)
                                                                                        double[] expected = {
                                                                                            Math.atan2(1.0, 1.0),   // Q1
                                                                                            Math.atan2(-1.0, 1.0),  // Q4
                                                                                            Math.atan2(1.0, -1.0),  // Q2
                                                                                            Math.atan2(-1.0, -1.0)  // Q3
                                                                                        };
                                                                                        
                                                                                        // Mutant would produce these results instead (with y=0)
                                                                                        double[] mutantResults = {
                                                                                            Math.atan2(0, 1.0),
                                                                                            Math.atan2(0, 1.0),
                                                                                            Math.atan2(0, -1.0),
                                                                                            Math.atan2(0, -1.0)
                                                                                        };
                                                                                        
                                                                                        // Execute
                                                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                                                        
                                                                                        // Verify - check each quadrant
                                                                                        for (int i = 0; i < 4; i++) {
                                                                                            // Assert the result matches expected, not mutant result
                                                                                            assertEquals(expected[i], result[i], 0.0001);
                                                                                            assertNotEquals(mutantResults[i], result[i], 0.0001);
                                                                                        }
                                                                                    }

    @Test
                                                                                public void testAtan2UsesBothInputs() {
                                                                                    // Setup
                                                                                    DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                                    double[] y = {1.0};  // y value
                                                                                    int yOffset = 0;
                                                                                    double[] x = {1.0};   // non-zero x value
                                                                                    int xOffset = 0;
                                                                                    double[] result = new double[1];
                                                                                    int resultOffset = 0;
                                                                                    
                                                                                    // Expected value: atan2(1.0, 1.0) = π/4
                                                                                    double expected = Math.PI / 4;
                                                                                    
                                                                                    // Execute
                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                    
                                                                                    // Verify
                                                                                    assertEquals("atan2 should compute using both x and y inputs", 
                                                                                                expected, result[resultOffset], 1e-10);
                                                                                    
                                                                                    // Additional test with different x value to ensure x is really used
                                                                                    x[0] = 2.0;
                                                                                    expected = Math.atan2(1.0, 2.0);
                                                                                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                                    assertEquals("atan2 should change when x input changes",
                                                                                                expected, result[resultOffset], 1e-10);
                                                                                }

    @Test
                                                                            public void testAtan2DetectsMutant2() {
                                                                                // Setup
                                                                                DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler with parameters=1, order=1
                                                                                
                                                                                // Test data with varying y values
                                                                                double[] y = {0.5, 1.0, 2.0, -1.0}; // Include 1.0 to show it would pass when y=1
                                                                                double[] x = {1.0, 1.0, 1.0, 1.0};  // Constant x for simplicity
                                                                                double[] result = new double[4];
                                                                                
                                                                                // Expected results
                                                                                double[] expected = new double[4];
                                                                                for (int i = 0; i < expected.length; i++) {
                                                                                    expected[i] = Math.atan2(y[i], x[i]);
                                                                                }
                                                                                
                                                                                // Execute
                                                                                compiler.atan2(y, 0, x, 0, result, 0);
                                                                                
                                                                                // Verify - this will fail for mutated version when y != 1
                                                                                assertArrayEquals("atan2 should calculate correct angle for all y values", 
                                                                                                 expected, result, 0.0001);
                                                                                
                                                                                // Additional verification for specific cases
                                                                                assertNotEquals("Result should differ when y=0.5 vs y=1", 
                                                                                               Math.atan2(1, 1.0), result[0], 0.0001);
                                                                                assertNotEquals("Result should differ when y=2.0 vs y=1", 
                                                                                               Math.atan2(1, 1.0), result[2], 0.0001);
                                                                            }

    @Test
                                                                    public void testAtan2DetectsMutant3() {
                                                                        // Create a compiler instance for testing
                                                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                        
                                                                        // Test data where x is not 1 to detect the mutant
                                                                        double[] y = {1.0};  // y coordinate
                                                                        double[] x = {2.0};  // x coordinate (not 1)
                                                                        double[] result = new double[1];
                                                                        
                                                                        // Expected value is atan2(y/x)
                                                                        double expected = FastMath.atan2(y[0], x[0]);
                                                                        
                                                                        // Call the method
                                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                                        
                                                                        // Verify the result matches the expected atan2 calculation
                                                                        assertEquals("atan2 should compute using both y and x values", 
                                                                                    expected, result[0], 1e-15);
                                                                        
                                                                        // Additional test case with negative x value
                                                                        x[0] = -1.5;
                                                                        expected = FastMath.atan2(y[0], x[0]);
                                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                                        assertEquals("atan2 should handle negative x values correctly",
                                                                                    expected, result[0], 1e-15);
                                                                        
                                                                        // Test case with x = 0 (edge case)
                                                                        x[0] = 0.0;
                                                                        expected = FastMath.atan2(y[0], x[0]);
                                                                        compiler.atan2(y, 0, x, 0, result, 0);
                                                                        assertEquals("atan2 should handle x=0 case correctly",
                                                                                    expected, result[0], 1e-15);
                                                                    }

    @Test
                                                                    public void testAtan2DetectsMutant4() {
                                                                        // Setup
                                                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler instance
                                                                        double[] y = {0.5}; // Small y value
                                                                        double[] x = {1.0}; 
                                                                        double[] result = new double[1];
                                                                        int yOffset = 0;
                                                                        int xOffset = 0;
                                                                        int resultOffset = 0;
                                                                        
                                                                        // Expected value calculation
                                                                        double expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                        
                                                                        // Mutant would calculate Math.atan2(Double.MAX_VALUE, x[xOffset])
                                                                        double mutantValue = Math.atan2(Double.MAX_VALUE, x[xOffset]);
                                                                        
                                                                        // Execute
                                                                        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                        
                                                                        // Verify
                                                                        assertEquals("atan2 should calculate correct angle", 
                                                                                    expected, result[resultOffset], 1e-10);
                                                                        
                                                                        // Additional assertion to explicitly catch the mutant
                                                                        assertNotEquals("Test should fail if mutant is present",
                                                                                      mutantValue, result[resultOffset], 1e-10);
                                                                        
                                                                        // Test with zero case
                                                                        y[0] = 0.0;
                                                                        expected = Math.atan2(y[yOffset], x[xOffset]);
                                                                        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                                        assertEquals("atan2(0,x) should be 0", 
                                                                                    expected, result[resultOffset], 1e-10);
                                                                    }

    @Test
                                                                public void testAtan2Mutation1() {
                                                                    // Setup - get a compiler instance
                                                                    DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                    
                                                                    // Test data with known atan2 result
                                                                    double[] y = {1.0};
                                                                    double[] x = {1.0};  // atan2(1,1) should be π/4
                                                                    double[] result = new double[1];
                                                                    
                                                                    // Expected value
                                                                    double expected = Math.PI / 4;
                                                                    
                                                                    // Call the method
                                                                    compiler.atan2(y, 0, x, 0, result, 0);
                                                                    
                                                                    // Verify - should be approximately π/4
                                                                    assertEquals(expected, result[0], 1e-10);
                                                                    
                                                                    // Additional test with different x value to ensure x is used
                                                                    double[] x2 = {2.0};
                                                                    double expected2 = Math.atan2(1.0, 2.0);
                                                                    compiler.atan2(y, 0, x2, 0, result, 0);
                                                                    assertEquals(expected2, result[0], 1e-10);
                                                                    
                                                                    // Edge case - x = 0 should give π/2
                                                                    double[] x3 = {0.0};
                                                                    double expected3 = Math.PI / 2;
                                                                    compiler.atan2(y, 0, x3, 0, result, 0);
                                                                    assertEquals(expected3, result[0], 1e-10);
                                                                }

    @Test
                                                            public void testAtan4() {
                                                                // Create a compiler instance for testing
                                                                DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                                
                                                                // Test data where atan2(y,x) != atan2(x,y)
                                                                double[] y = {1.0};
                                                                double[] x = {2.0};
                                                                double[] result = new double[1];
                                                                
                                                                // Expected value: atan2(1.0, 2.0)
                                                                double expected = Math.atan2(1.0, 2.0);
                                                                
                                                                // Call the method
                                                                compiler.atan2(y, 0, x, 0, result, 0);
                                                                
                                                                // Verify the result
                                                                assertEquals("atan2 result is incorrect", expected, result[0], 1e-10);
                                                                
                                                                // Test with different values to ensure proper quadrant handling
                                                                y[0] = -1.0;
                                                                x[0] = -2.0;
                                                                expected = Math.atan2(-1.0, -2.0);
                                                                compiler.atan2(y, 0, x, 0, result, 0);
                                                                assertEquals("atan2 result for negative values is incorrect", expected, result[0], 1e-10);
                                                                
                                                                // Test boundary case where x is zero
                                                                y[0] = 1.0;
                                                                x[0] = 0.0;
                                                                expected = Math.atan2(1.0, 0.0);
                                                                compiler.atan2(y, 0, x, 0, result, 0);
                                                                assertEquals("atan2 result when x=0 is incorrect", expected, result[0], 1e-10);
                                                                
                                                                // Test boundary case where y is zero
                                                                y[0] = 0.0;
                                                                x[0] = 1.0;
                                                                expected = Math.atan2(0.0, 1.0);
                                                                compiler.atan2(y, 0, x, 0, result, 0);
                                                                assertEquals("atan2 result when y=0 is incorrect", expected, result[0], 1e-10);
                                                            }

    @Test
                                                        public void testAtan2DetectsMutant5() {
                                                            // Setup - create a compiler instance with parameters=1, order=1
                                                            DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                            
                                                            // Test inputs - values that should produce known atan2 results
                                                            double[] y = {1.0};  // y coordinate
                                                            int yOffset = 0;
                                                            double[] x = {1.0};  // x coordinate
                                                            int xOffset = 0;
                                                            double[] result = new double[1];
                                                            int resultOffset = 0;
                                                            
                                                            // Expected value - correct atan2(1,1) = π/4
                                                            double expected = Math.PI/4;
                                                            
                                                            // Call the method
                                                            compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                            
                                                            // Verify - should be the correct atan2 value, not 0
                                                            assertEquals("atan2 result should be correct calculation", 
                                                                        expected, result[resultOffset], 0.0001);
                                                            
                                                            // Additional test case with different values
                                                            y[0] = 1.0;
                                                            x[0] = 0.0;
                                                            expected = Math.PI/2;
                                                            compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                            assertEquals("atan2 result should be correct for vertical angle",
                                                                        expected, result[resultOffset], 0.0001);
                                                            
                                                            // Test with negative values
                                                            y[0] = -1.0;
                                                            x[0] = -1.0;
                                                            expected = -3*Math.PI/4;
                                                            compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                            assertEquals("atan2 result should be correct for negative coordinates",
                                                                        expected, result[resultOffset], 0.0001);
                                                        }

    @Test
                                                    public void testAtan5() {
                                                        // Setup
                                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler with 1 parameter and order 1
                                                        
                                                        // Test data - we'll use points where we know the expected angles
                                                        double[] y = {1.0, 0.0, -1.0, 1.0};  // y coordinates to test
                                                        double[] x = {1.0, 1.0, 1.0, -1.0};  // x coordinates to test
                                                        double[] expectedAngles = {
                                                            Math.PI/4,     // 45 degrees for (1,1)
                                                            0.0,          // 0 degrees for (1,0)
                                                            -Math.PI/4,    // -45 degrees for (1,-1)
                                                            3*Math.PI/4    // 135 degrees for (-1,1)
                                                        };
                                                        
                                                        double[] result = new double[1];
                                                        
                                                        // Test each case
                                                        for (int i = 0; i < y.length; i++) {
                                                            double[] currentY = {y[i]};
                                                            double[] currentX = {x[i]};
                                                            
                                                            // Call the method
                                                            compiler.atan2(currentY, 0, currentX, 0, result, 0);
                                                            
                                                            // Verify the result is the expected angle (with delta for floating point precision)
                                                            assertEquals("atan2 failed for input (" + x[i] + "," + y[i] + ")",
                                                                        expectedAngles[i], result[0], 1e-10);
                                                            
                                                            // Additional assertion to specifically catch the PI mutant
                                                            assertNotEquals("Mutant detected: atan2 always returns PI",
                                                                          Math.PI, result[0], 1e-10);
                                                        }
                                                    }

    @Test
                                                public void testAtan2DetectsMutant6() {
                                                    // Setup
                                                    DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                                    double[] y = new double[2];
                                                    double[] x = new double[2];
                                                    double[] result = new double[2];
                                                    
                                                    // Test quadrant I (should be same for both)
                                                    y[0] = 1.0;
                                                    x[0] = 1.0;
                                                    compiler.atan2(y, 0, x, 0, result, 0);
                                                    assertEquals(Math.PI/4, result[0], 1e-10);
                                                    
                                                    // Test quadrant II (different results)
                                                    y[0] = 1.0;
                                                    x[0] = -1.0;
                                                    compiler.atan2(y, 0, x, 0, result, 0);
                                                    assertEquals(3*Math.PI/4, result[0], 1e-10); // atan2 correct
                                                    // mutant would return -PI/4
                                                    
                                                    // Test x = 0 case
                                                    y[0] = 1.0;
                                                    x[0] = 0.0;
                                                    compiler.atan2(y, 0, x, 0, result, 0);
                                                    assertEquals(Math.PI/2, result[0], 1e-10); // atan2 correct
                                                    // mutant would throw ArithmeticException or return Infinity
                                                    
                                                    // Test negative y case
                                                    y[0] = -1.0;
                                                    x[0] = -1.0;
                                                    compiler.atan2(y, 0, x, 0, result, 0);
                                                    assertEquals(-3*Math.PI/4, result[0], 1e-10); // atan2 correct
                                                    // mutant would return PI/4
                                                }

    @Test
                                            public void testAtan2DetectsMutant7() {
                                                // Setup
                                                DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler with 1 parameter and order 1
                                                
                                                // Test inputs - choose values where atan2(y,x) != y
                                                double[] y = {1.0}; // y value
                                                double[] x = {1.0}; // x value
                                                double[] result = new double[1];
                                                
                                                // Expected value
                                                double expected = Math.atan2(y[0], x[0]);
                                                
                                                // Call method
                                                compiler.atan2(y, 0, x, 0, result, 0);
                                                
                                                // Verify
                                                assertEquals("atan2 result should match mathematical calculation", 
                                                            expected, result[0], 0.0001);
                                                
                                                // Additional assertion to explicitly catch the mutant
                                                assertNotEquals("Result should not equal y value (mutant check)", 
                                                               y[0], result[0], 0.0001);
                                            }

    @Test
                                        public void testAtan2DetectsMutant8() {
                                            // Setup
                                            DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                            double[] y = new double[]{1.0}; // y value
                                            double[] x = new double[]{2.0}; // x value
                                            double[] result = new double[1];
                                            
                                            // Expected value: atan2(1.0, 2.0) ≈ 0.463647609
                                            double expected = Math.atan2(y[0], x[0]);
                                            
                                            // Execute
                                            compiler.atan2(y, 0, x, 0, result, 0);
                                            
                                            // Verify - both the exact value and that it's not just x
                                            assertEquals("atan2 result should match trigonometric calculation", 
                                                        expected, result[0], 1e-10);
                                            assertNotEquals("atan2 result should not equal x value", 
                                                           x[0], result[0], 1e-10);
                                        }

    @Test
                                    public void testAtan6() {
                                        // Setup
                                        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler with parameters=1, order=1
                                        
                                        // Test data - use values that will clearly show sign difference
                                        double[] y = {1.0, 2.0, -1.0};
                                        int yOffset = 0;
                                        double[] x = {1.0, 1.0, 1.0};
                                        int xOffset = 0;
                                        double[] result = new double[3];
                                        int resultOffset = 0;
                                        
                                        // Expected values
                                        double expected1 = Math.atan2(y[yOffset], x[xOffset]);
                                        double expected2 = Math.atan2(y[yOffset+1], x[xOffset+1]);
                                        double expected3 = Math.atan2(y[yOffset+2], x[xOffset+2]);
                                        
                                        // Execute
                                        compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                        
                                        // Verify
                                        assertEquals("First atan2 value incorrect", expected1, result[resultOffset], 1e-10);
                                        assertEquals("Second atan2 value incorrect", expected2, result[resultOffset+1], 1e-10);
                                        assertEquals("Negative y value atan2 incorrect", expected3, result[resultOffset+2], 1e-10);
                                        
                                        // The mutant would fail on all assertions since it negates y values
                                        // For example, for first value:
                                        // Original: atan2(1,1) = π/4 ≈ 0.785398
                                        // Mutant: atan2(-1,1) = -π/4 ≈ -0.785398
                                    }

    @Test
                                public void testAtan2Mutation2() {
                                    // Setup test data
                                    DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler instance
                                    double[] y = {1.0, 0.0, -1.0, 1.0}; // Test cases for y
                                    double[] x = {1.0, 1.0, 1.0, -1.0}; // Corresponding x values
                                    double[] result = new double[4];
                                    double[] expected = {
                                        Math.PI/4,    // atan2(1,1) = 45°
                                        0.0,         // atan2(0,1) = 0°
                                        -Math.PI/4,   // atan2(-1,1) = -45°
                                        3*Math.PI/4   // atan2(1,-1) = 135°
                                    };
                                    
                                    // Test each case
                                    for (int i = 0; i < y.length; i++) {
                                        double[] singleY = {y[i]};
                                        double[] singleX = {x[i]};
                                        double[] singleResult = new double[1];
                                        
                                        compiler.atan2(singleY, 0, singleX, 0, singleResult, 0);
                                        
                                        // Verify the result matches expected value
                                        assertEquals("atan2 test case " + i + " failed", 
                                                    expected[i], singleResult[0], 1e-10);
                                    }
                                    
                                    // Additional edge case: x = 0
                                    double[] edgeY = {1.0};
                                    double[] edgeX = {0.0};
                                    double[] edgeResult = new double[1];
                                    compiler.atan2(edgeY, 0, edgeX, 0, edgeResult, 0);
                                    assertEquals(Math.PI/2, edgeResult[0], 1e-10); // atan2(1,0) = 90°
                                }

    @Test
                            public void testAtan2UsesYValue() {
                                // Setup test data with non-zero y values
                                double[] y = {1.0, 2.0, 3.0};  // non-zero y values
                                int yOffset = 0;
                                double[] x = {1.0, 1.0, 1.0}; // arbitrary x values
                                int xOffset = 0;
                                double[] result = new double[3];
                                int resultOffset = 0;
                                
                                // Get a compiler instance
                                DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                
                                // Call the method
                                compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                
                                // Verify the results are calculated using both y and x values
                                // The mutant would return atan2(0, x) which would be 0 for x>0
                                assertEquals(Math.atan2(y[0], x[0]), result[0], 0.0001);
                                assertEquals(Math.atan2(y[1], x[1]), result[1], 0.0001);
                                assertEquals(Math.atan2(y[2], x[2]), result[2], 0.0001);
                                
                                // Additional test with negative y values
                                y = new double[]{-1.0, -2.0, -3.0};
                                compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                assertEquals(Math.atan2(y[0], x[0]), result[0], 0.0001);
                                assertEquals(Math.atan2(y[1], x[1]), result[1], 0.0001);
                                assertEquals(Math.atan2(y[2], x[2]), result[2], 0.0001);
                            }

    @Test
                        public void testAtan2UsesBothInputs1() {
                            // Create a compiler instance with parameters=1, order=1
                            DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                            
                            // Test data with non-zero x values
                            double[] y = {1.0};
                            double[] x = {1.0};  // Non-zero x value
                            double[] result = new double[1];
                            
                            // Expected value: atan2(1.0, 1.0) = π/4
                            double expected = Math.PI / 4;
                            
                            // Call the method
                            compiler.atan2(y, 0, x, 0, result, 0);
                            
                            // Verify the result uses both x and y inputs
                            assertEquals(expected, result[0], 1e-10);
                            
                            // Additional test case with different x/y ratio
                            y[0] = 1.0;
                            x[0] = Math.sqrt(3);  // 60 degree angle
                            expected = Math.PI / 6;
                            
                            compiler.atan2(y, 0, x, 0, result, 0);
                            assertEquals(expected, result[0], 1e-10);
                            
                            // Edge case: x negative
                            y[0] = 1.0;
                            x[0] = -1.0;
                            expected = 3 * Math.PI / 4;  // Second quadrant
                            
                            compiler.atan2(y, 0, x, 0, result, 0);
                            assertEquals(expected, result[0], 1e-10);
                        }

    @Test
                    public void testAtan2DetectsMutant9() {
                        // Setup
                        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler with parameters=1, order=1
                        
                        // Test data where y != 1
                        double[] y = {2.0}; // y != 1 to detect mutant
                        double[] x = {1.0};
                        double[] result = new double[1];
                        
                        // Expected value
                        double expected = Math.atan2(y[0], x[0]);
                        
                        // Execute
                        compiler.atan2(y, 0, x, 0, result, 0);
                        
                        // Verify
                        assertEquals("atan2 result should match expected calculation", 
                                    expected, result[0], 0.0001);
                        
                        // This will fail if mutant is present because:
                        // Mutant would calculate atan2(1, x[0]) instead of atan2(y[0], x[0])
                        // Since y[0] = 2.0, the results would differ
                    }

    @Test
                public void testAtan2DetectsMutant10() {
                    // Setup
                    DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler with parameters=1, order=1
                    
                    // Test inputs where x != 1 to catch the mutant
                    double[] y = {1.0, 2.0, 3.0};
                    int yOffset = 0;
                    double[] x = {2.0, 0.5, -1.0}; // Different from 1.0
                    int xOffset = 0;
                    double[] result = new double[3];
                    int resultOffset = 0;
                    
                    // Expected results
                    double[] expected = new double[3];
                    for (int i = 0; i < expected.length; i++) {
                        expected[i] = Math.atan2(y[yOffset + i], x[xOffset + i]);
                    }
                    
                    // Execute
                    compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                    
                    // Verify
                    for (int i = 0; i < expected.length; i++) {
                        assertEquals("atan2 result mismatch at index " + i,
                                    expected[i], result[resultOffset + i], 1e-10);
                    }
                    
                    // Additional edge cases
                    // Test with x = 0 (special case for atan2)
                    double[] y2 = {1.0, -1.0};
                    double[] x2 = {0.0, 0.0};
                    double[] expected2 = {Math.PI/2, -Math.PI/2};
                    double[] result2 = new double[2];
                    
                    compiler.atan2(y2, 0, x2, 0, result2, 0);
                    
                    assertEquals(expected2[0], result2[0], 1e-10);
                    assertEquals(expected2[1], result2[1], 1e-10);
                }

    @Test
            public void testAtan2DetectsMutant11() {
                // Setup
                DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Get a compiler instance
                double[] y = {1.0}; // Normal y value (not Double.MAX_VALUE)
                double[] x = {2.0}; // Arbitrary x value
                double[] result = new double[1];
                
                // Expected value calculation
                double expected = Math.atan2(y[0], x[0]);
                
                // Mutant would produce this instead
                double mutantValue = Math.atan2(Double.MAX_VALUE, x[0]);
                
                // Execute
                compiler.atan2(y, 0, x, 0, result, 0);
                
                // Verify
                assertEquals("atan2 result should match expected value", 
                            expected, result[0], 0.0001);
                
                // Additional assertion to explicitly catch the mutant
                assertNotEquals("atan2 result should not equal mutant value", 
                               mutantValue, result[0], 0.0001);
                
                // Test with negative y value
                y[0] = -1.0;
                expected = Math.atan2(y[0], x[0]);
                mutantValue = Math.atan2(Double.MAX_VALUE, x[0]);
                
                compiler.atan2(y, 0, x, 0, result, 0);
                assertEquals("atan2 with negative y should match expected", 
                            expected, result[0], 0.0001);
                assertNotEquals("atan2 with negative y should not equal mutant value", 
                               mutantValue, result[0], 0.0001);
                
                // Test with very small y value
                y[0] = 1.0e-300;
                expected = Math.atan2(y[0], x[0]);
                mutantValue = Math.atan2(Double.MAX_VALUE, x[0]);
                
                compiler.atan2(y, 0, x, 0, result, 0);
                assertEquals("atan2 with small y should match expected", 
                            expected, result[0], 0.0001);
                assertNotEquals("atan2 with small y should not equal mutant value", 
                               mutantValue, result[0], 0.0001);
            }

    @Test
        public void testAtan7() {
            // Setup test data
            double[] y = {1.0};  // Known y value
            double[] x = {1.0};  // Known x value
            double[] result = new double[1];
            int yOffset = 0;
            int xOffset = 0;
            int resultOffset = 0;
            
            // Expected value calculation
            double expected = Math.atan2(y[yOffset], x[xOffset]);
            
            // Get a compiler instance (parameters=1, order=1)
            DSCompiler compiler = DSCompiler.getCompiler(1, 1);
            
            // Call the method
            compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
            
            // Verify the result
            assertEquals("atan2 result should match expected calculation", 
                        expected, result[resultOffset], 0.0001);
            
            // Additional test with different x value to ensure x is actually used
            x[0] = 2.0;
            expected = Math.atan2(y[yOffset], x[xOffset]);
            compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
            assertEquals("atan2 should use actual x value", 
                        expected, result[resultOffset], 0.0001);
        }

}
