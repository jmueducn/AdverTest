package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.geometry.Vector;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Embedding;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Precision;
 
public class LineTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                    public void testRevert_NegatesDirection() {
                                        // Setup original line with real vectors
                                        Vector3D zeroPoint = new Vector3D(1, 2, 3);
                                        Vector3D direction = new Vector3D(2, 3, 4);
                                        Line originalLine = new Line(zeroPoint, direction);
                                        
                                        // Execute revert
                                        Line revertedLine = originalLine.revert();
                                        
                                        // Verify direction was negated
                                        assertEquals(direction.negate(), revertedLine.getDirection());
                                    }

    @Test
                                    public void testRevert_OriginalLineUnchanged() {
                                        // Setup original line
                                        Vector3D p1 = new Vector3D(1, 0, 0);
                                        Vector3D p2 = new Vector3D(0, 1, 0);
                                        Line originalLine = new Line(p1, p2);
                                        Vector3D originalDirection = originalLine.getDirection();
                                        Vector3D originalZero = originalLine.getOrigin();
                                        
                                        // Execute revert
                                        Line revertedLine = originalLine.revert();
                                        
                                        // Verify original line unchanged
                                        assertEquals(originalDirection, originalLine.getDirection());
                                        assertEquals(originalZero, originalLine.getOrigin());
                                    }

    @Test
                                    public void testRevert_ZeroPointPreserved() {
                                        // Setup original line
                                        Vector3D p1 = new Vector3D(1, 2, 3);
                                        Vector3D p2 = new Vector3D(4, 5, 6);
                                        Line originalLine = new Line(p1, p2);
                                        Vector3D originalZero = originalLine.getOrigin();
                                        
                                        // Execute revert
                                        Line revertedLine = originalLine.revert();
                                        
                                        // Verify zero point is the same
                                        assertEquals(originalZero, revertedLine.getOrigin());
                                    }

    @Test
                                    public void testRevert_WithDifferentDirections() {
                                        // Test with x-axis direction
                                        Vector3D xDir = new Vector3D(1, 0, 0);
                                        Vector3D zero = new Vector3D(0, 0, 0);
                                        Line xLine = new Line(zero, xDir);
                                        Line revertedX = xLine.revert();
                                        assertEquals(new Vector3D(-1, 0, 0), revertedX.getDirection());
                                        
                                        // Test with y-axis direction
                                        Vector3D yDir = new Vector3D(0, 1, 0);
                                        Line yLine = new Line(zero, yDir);
                                        Line revertedY = yLine.revert();
                                        assertEquals(new Vector3D(0, -1, 0), revertedY.getDirection());
                                        
                                        // Test with arbitrary direction
                                        Vector3D arbDir = new Vector3D(1, 2, 3);
                                        Line arbLine = new Line(zero, arbDir);
                                        Line revertedArb = arbLine.revert();
                                        assertEquals(new Vector3D(-1, -2, -3), revertedArb.getDirection());
                                    }

    @Test
                                    public void testRevert_IsIdempotent() {
                                        // Reverting twice should return to original direction
                                        Vector3D p1 = new Vector3D(1, 1, 1);
                                        Vector3D p2 = new Vector3D(2, 2, 2);
                                        Line originalLine = new Line(p1, p2);
                                        
                                        Line onceReverted = originalLine.revert();
                                        Line twiceReverted = onceReverted.revert();
                                        
                                        assertEquals(originalLine.getDirection(), twiceReverted.getDirection());
                                        assertNotEquals(originalLine.getDirection(), onceReverted.getDirection());
                                    }

    @Test
                                    public void testRevertDirectionNotAffectedByOriginalLineChange() {
                                        // Create original line
                                        Vector3D p1 = new Vector3D(1, 0, 0);
                                        Vector3D p2 = new Vector3D(2, 0, 0);
                                        Line originalLine = new Line(p1, p2);
                                        
                                        // Get original direction
                                        Vector3D originalDirection = originalLine.getDirection();
                                        
                                        // Create reverted line
                                        Line revertedLine = originalLine.revert();
                                        Vector3D expectedRevertedDirection = originalDirection.negate();
                                        
                                        // Verify initial revert is correct
                                        assertEquals(expectedRevertedDirection, revertedLine.getDirection());
                                        
                                        // Now modify the original line
                                        Vector3D newP1 = new Vector3D(0, 1, 0);
                                        Vector3D newP2 = new Vector3D(0, 2, 0);
                                        originalLine.reset(newP1, newP2);
                                        
                                        // The reverted line's direction should NOT change
                                        assertEquals(expectedRevertedDirection, revertedLine.getDirection());
                                        
                                        // Additional check: the original line's new direction should be different
                                        assertNotEquals(originalDirection, originalLine.getDirection());
                                    }

    @Test
                                public void testRevertCreatesProperImmutableCopy() {
                                    // Setup original line
                                    Vector3D p1 = new Vector3D(1, 0, 0);
                                    Vector3D p2 = new Vector3D(0, 1, 0);
                                    Line original = new Line(p1, p2);
                                    
                                    // Create reverted line
                                    Line reverted = original.revert();
                                    
                                    // Verify it's a proper copy
                                    assertEquals(original.getDirection(), reverted.getDirection());
                                    assertEquals(original.getOrigin(), reverted.getOrigin());
                                    
                                    // Verify it's a separate instance
                                    assertNotSame(original, reverted);
                                    
                                    // Verify immutability by changing original and checking reverted stays same
                                    Vector3D newP1 = new Vector3D(0, 0, 0);
                                    Vector3D newP2 = new Vector3D(0, 0, 1);
                                    original.reset(newP1, newP2);
                                    
                                    assertNotEquals(original.getDirection(), reverted.getDirection());
                                    assertNotEquals(original.getOrigin(), reverted.getOrigin());
                                    
                                    // Additional test to catch the mutant - try to reassign the reverted variable
                                    // This would be possible with the mutant but not with original code
                                    try {
                                        reverted = new Line(newP1, newP2);
                                        // If we get here, the test should fail as the variable was modifiable
                                        fail("The reverted variable should be final and not reassignable");
                                    } catch (Exception e) {
                                        // This is expected for the original code
                                    }
                                }

    @Test
                            public void testRevertDirectionIsIndependent() {
                                // Create original line
                                Vector3D p1 = new Vector3D(0, 0, 0);
                                Vector3D p2 = new Vector3D(1, 0, 0);
                                Line original = new Line(p1, p2);
                                
                                // Create reverted line
                                Line reverted = original.revert();
                                Vector3D originalDirectionBefore = original.getDirection();
                                Vector3D revertedDirectionBefore = reverted.getDirection();
                                
                                // Verify initial directions are opposites
                                assertEquals(originalDirectionBefore, revertedDirectionBefore.negate());
                                
                                // Modify original line's direction
                                Vector3D newP2 = new Vector3D(0, 1, 0);
                                original.reset(p1, newP2);
                                Vector3D originalDirectionAfter = original.getDirection();
                                Vector3D revertedDirectionAfter = reverted.getDirection();
                                
                                // In original code, reverted direction should NOT change when original changes
                                // In mutant code, reverted direction WOULD change
                                assertEquals("Reverted line direction should not change when original line changes", 
                                            revertedDirectionBefore, revertedDirectionAfter);
                                assertNotEquals("Original line direction should change after reset",
                                              originalDirectionBefore, originalDirectionAfter);
                            }

    @Test
                        public void testRevertDirection() {
                            // Setup
                            Vector3D p1 = new Vector3D(1, 0, 0);
                            Vector3D p2 = new Vector3D(2, 0, 0);
                            Line line = new Line(p1, p2);
                            
                            // Get original direction
                            Vector3D originalDirection = line.getDirection();
                            
                            // Perform revert
                            Line reverted = line.revert();
                            Vector3D revertedDirection = reverted.getDirection();
                            
                            // Verify mathematical negation
                            assertEquals(-1, revertedDirection.getX(), 1e-15);
                            assertEquals(0, revertedDirection.getY(), 1e-15);
                            assertEquals(0, revertedDirection.getZ(), 1e-15);
                            
                            // Verify it's exactly the negation of original
                            // This would catch the scalarMultiply vs negate difference
                            assertTrue(Vector3D.distance(originalDirection.negate(), revertedDirection) < 1e-15);
                            
                            // Verify the reverted line's direction is properly inverted
                            // by checking a point along the line
                            Vector3D originalPoint = line.pointAt(1.0);
                            Vector3D revertedPoint = reverted.pointAt(-1.0);
                            assertEquals(0, Vector3D.distance(originalPoint, revertedPoint), 1e-15);
                        }

    @Test
                    public void testResetWithSamePointsShouldThrowExceptionWithProperMessage() {
                        // Arrange
                        Vector3D p1 = new Vector3D(1, 1, 1);
                        Vector3D p2 = new Vector3D(1, 1, 1); // Same as p1
                        Line line = new Line(p1, p2); // This will call reset internally
                        
                        try {
                            // Act - This should throw an exception
                            line.reset(p1, p2);
                            fail("Expected MathIllegalArgumentException");
                        } catch (MathIllegalArgumentException e) {
                            // Assert
                            assertNotNull("Exception message should not be null", e.getMessage());
                            assertEquals("Localized message should be for ZERO_NORM", 
                                         LocalizedFormats.ZERO_NORM.toString(), 
                                         e.getMessage());
                        }
                    }

    @Test
                public void testResetWithIdenticalPointsThrowsCorrectException() {
                    // Arrange
                    Vector3D p1 = new Vector3D(1, 1, 1);
                    Vector3D p2 = new Vector3D(1, 1, 1);  // Same as p1
                    Line line = new Line(p1, p2);  // This will call reset internally
                    
                    // We expect the original behavior to throw ZERO_NORM exception
                    thrown.expect(MathIllegalArgumentException.class);
                    thrown.expectMessage(LocalizedFormats.ZERO_NORM.toString());
                    
                    // Act - this should throw the exception
                    line.reset(p1, p2);
                }

    @Test
            public void testResetWithIdenticalPointsThrowsCorrectException1() {
                // Arrange
                Vector3D p1 = new Vector3D(1, 1, 1);
                Vector3D p2 = new Vector3D(1, 1, 1); // Same as p1
                Line line = new Line(p1, new Vector3D(0, 0, 0)); // Any line, will be reset
                
                // Set expectation for exception type and message format
                thrown.expect(MathIllegalArgumentException.class);
                thrown.expectMessage(LocalizedFormats.ZERO_NORM.getSourceString());
                
                // Act
                line.reset(p1, p2);
                
                // Assertion is handled by the ExpectedException rule
            }

    @Test
        public void testResetWithCoincidentPointsThrowsExceptionWithProperMessage() {
            // Arrange
            Line line = new Line(new Vector3D(1, 0, 0), new Vector3D(0, 1, 0));
            Vector3D p1 = new Vector3D(1, 2, 3);
            Vector3D p2 = new Vector3D(1, 2, 3); // Same as p1
            
            try {
                // Act
                line.reset(p1, p2);
                fail("Expected MathIllegalArgumentException");
            } catch (MathIllegalArgumentException e) {
                // Assert
                assertNotNull("Exception message should not be null", e.getMessage());
                assertEquals("LocalizedFormats.ZERO_NORM", e.getLocalizedMessage());
            }
        }

}
