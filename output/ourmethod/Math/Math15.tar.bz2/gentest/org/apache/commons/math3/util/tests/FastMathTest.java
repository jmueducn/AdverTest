package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                    public void testPow_ZeroExponent() {
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(0.0, 0.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(1.0, 0.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(-1.0, 0.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(Double.POSITIVE_INFINITY, 0.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(Double.NEGATIVE_INFINITY, 0.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(Double.NaN, 0.0), 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_NaNBase() {
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 1.0)));
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 0.0))); // Even though y=0 returns 1 normally
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, -1.0)));
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, Double.POSITIVE_INFINITY)));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_ZeroBase() {
                                                                                                                                                                                                                                                                        // Positive zero cases
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(0.0, 1.0), 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(0.0, 0.0)));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                        // Negative zero cases
                                                                                                                                                                                                                                                                        assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(-0.0, -3.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-0.0, FastMath.pow(-0.0, 3.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(-0.0, -2.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(-0.0, 2.0), 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_InfinityBase() {
                                                                                                                                                                                                                                                                        // Positive infinity cases
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.POSITIVE_INFINITY, 2.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(Double.POSITIVE_INFINITY, -2.0), 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(Double.POSITIVE_INFINITY, Double.NaN)));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                        // Negative infinity cases
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 2.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 3.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -2.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -3.0), 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_InfinityExponent() {
                                                                                                                                                                                                                                                                        // Positive infinity exponent
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, Double.POSITIVE_INFINITY), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(0.5, Double.POSITIVE_INFINITY), 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(1.0, Double.POSITIVE_INFINITY)));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                        // Negative infinity exponent
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(2.0, Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.5, Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(1.0, Double.NEGATIVE_INFINITY)));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_NegativeBase() {
                                                                                                                                                                                                                                                                        // Integer exponents
                                                                                                                                                                                                                                                                        assertEquals(16.0, FastMath.pow(-2.0, 4.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-32.0, FastMath.pow(-2.0, 5.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.25, FastMath.pow(-2.0, -2.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-0.125, FastMath.pow(-2.0, -3.0), 0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                        // Non-integer exponents should return NaN
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(-2.0, 0.5)));
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(-2.0, Double.NaN)));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_NormalCases() {
                                                                                                                                                                                                                                                                        // Typical positive cases
                                                                                                                                                                                                                                                                        assertEquals(8.0, FastMath.pow(2.0, 3.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.125, FastMath.pow(2.0, -3.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.4142135623730951, FastMath.pow(2.0, 0.5), 1e-15);
                                                                                                                                                                                                                                                                        assertEquals(9.0, FastMath.pow(3.0, 2.0), 0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                        // Values near 1
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(1.0, 100.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(100.0, 0.0), 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_EdgeCases() {
                                                                                                                                                                                                                                                                        // Test with very small numbers
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(Double.MIN_VALUE, 2.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.MIN_VALUE, -2.0), 0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                        // Test with very large numbers
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.MAX_VALUE, 2.0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(Double.MAX_VALUE, -2.0), 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_ZeroExponent1() {
                                                                                                                                                                                                                                                                        // Any number to the power of 0 should be 1
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(0.0, 0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(1.0, 0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(-1.0, 0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(Double.MAX_VALUE, 0), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(Double.MIN_VALUE, 0), 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_PositiveExponent() {
                                                                                                                                                                                                                                                                        // Positive exponents
                                                                                                                                                                                                                                                                        assertEquals(8.0, FastMath.pow(2.0, 3), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(1.0, 5), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.125, FastMath.pow(0.5, 3), 1e-15);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(-1.0, 4), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-1.0, FastMath.pow(-1.0, 3), 0.0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Large exponents
                                                                                                                                                                                                                                                                        assertEquals(1.0E20, FastMath.pow(10.0, 20), 1e5); // Allow some tolerance for large numbers
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_NegativeExponent() {
                                                                                                                                                                                                                                                                        // Negative exponents
                                                                                                                                                                                                                                                                        assertEquals(0.5, FastMath.pow(2.0, -1), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.25, FastMath.pow(2.0, -2), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(8.0, FastMath.pow(0.5, -3), 1e-15);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(-1.0, -4), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-1.0, FastMath.pow(-1.0, -3), 0.0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Very small results
                                                                                                                                                                                                                                                                        assertEquals(1.0E-20, FastMath.pow(10.0, -20), 1e-25); // Allow some tolerance for very small numbers
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_SpecialCases() {
                                                                                                                                                                                                                                                                        // Special cases
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(0.0, 1), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(0.0, 5), 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isInfinite(FastMath.pow(0.0, -1)));
                                                                                                                                                                                                                                                                        assertTrue(Double.isInfinite(FastMath.pow(0.0, -5)));
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(1.0, 100), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(1.0, FastMath.pow(1.0, -100), 0.0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 2)));
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(2.0, Double.NaN)));
                                                                                                                                                                                                                                                                        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, Double.NaN)));
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        assertTrue(Double.isInfinite(FastMath.pow(Double.POSITIVE_INFINITY, 2)));
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(Double.POSITIVE_INFINITY, -2), 0.0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        assertTrue(Double.isInfinite(FastMath.pow(Double.NEGATIVE_INFINITY, 3)));
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -3), 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isInfinite(FastMath.pow(Double.NEGATIVE_INFINITY, 4)));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_EdgeCases1() {
                                                                                                                                                                                                                                                                        // Edge cases with very large/small numbers
                                                                                                                                                                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, 1024), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(2.0, -1024), 0.0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test with subnormal numbers
                                                                                                                                                                                                                                                                        assertEquals(0.0, FastMath.pow(Double.MIN_VALUE, 2), 0.0);
                                                                                                                                                                                                                                                                        assertTrue(Double.isInfinite(FastMath.pow(Double.MIN_VALUE, -2)));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_Precision() {
                                                                                                                                                                                                                                                                        // Test precision with non-integer base values
                                                                                                                                                                                                                                                                        double base = 1.0000001;
                                                                                                                                                                                                                                                                        double expected = 1.0001000050001000; // (1 + 1e-6)^100 ≈ 1 + 100*1e-6 + 100*99/2*1e-12
                                                                                                                                                                                                                                                                        assertEquals(expected, FastMath.pow(base, 100), 1e-15);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        base = 0.9999999;
                                                                                                                                                                                                                                                                        expected = 0.9999000049995000; // (1 - 1e-6)^100 ≈ 1 - 100*1e-6 + 100*99/2*1e-12
                                                                                                                                                                                                                                                                        assertEquals(expected, FastMath.pow(base, 100), 1e-15);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testPow_OddEvenNegativeBase() {
                                                                                                                                                                                                                                                                        // Negative base with odd/even exponents
                                                                                                                                                                                                                                                                        assertEquals(16.0, FastMath.pow(-2.0, 4), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-32.0, FastMath.pow(-2.0, 5), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(0.0625, FastMath.pow(-2.0, -4), 0.0);
                                                                                                                                                                                                                                                                        assertEquals(-0.03125, FastMath.pow(-2.0, -5), 0.0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                            public void testPow_VeryLargeExponents() throws Exception {
                                                                                                                                                                                                                                                                // Use reflection to access private TWO_POWER_53 field
                                                                                                                                                                                                                                                                Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                                                                                                                                                                twoPower53Field.setAccessible(true);
                                                                                                                                                                                                                                                                double twoPower53 = twoPower53Field.getDouble(null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double largePos = twoPower53 + 1;
                                                                                                                                                                                                                                                                double largeNeg = -twoPower53 - 1;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, largePos), 0.0);
                                                                                                                                                                                                                                                                assertEquals(0.0, FastMath.pow(2.0, largeNeg), 0.0);
                                                                                                                                                                                                                                                                assertEquals(0.0, FastMath.pow(0.5, largePos), 0.0);
                                                                                                                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.5, largeNeg), 0.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                    public void testDoubleHighPartWithZero() throws Exception {
                                                                                                                                                                                                                                                        // Test with input exactly 0.0
                                                                                                                                                                                                                                                        double input = 0.0;
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Get private MASK_30BITS field using reflection
                                                                                                                                                                                                                                                        Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                                                                                                                                                                                        maskField.setAccessible(true);
                                                                                                                                                                                                                                                        long MASK_30BITS = maskField.getLong(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Expected behavior (original): should process the bits
                                                                                                                                                                                                                                                        long expectedBits = Double.doubleToLongBits(input) & MASK_30BITS;
                                                                                                                                                                                                                                                        double expected = Double.longBitsToDouble(expectedBits);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Get private doubleHighPart method using reflection
                                                                                                                                                                                                                                                        Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                                                        doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Actual result
                                                                                                                                                                                                                                                        double actual = (double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Assert that the result matches expected bit manipulation
                                                                                                                                                                                                                                                        // This will fail if the mutant is present (which would return 0.0 directly)
                                                                                                                                                                                                                                                        assertEquals("Double high part of 0.0 should be processed normally", 
                                                                                                                                                                                                                                                                    expected, actual, 0.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Additional assertion to be extra sure
                                                                                                                                                                                                                                                        assertNotEquals("Double high part of 0.0 should not return exactly 0.0", 
                                                                                                                                                                                                                                                                       0.0, actual, 0.0);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                            public void testDoubleHighPartWithExactTwoPower() throws Exception {
                                                                                                                                                                                                                                                // Get private constants via reflection
                                                                                                                                                                                                                                                Class<?> fastMathClass = Class.forName("org.apache.commons.math3.util.FastMath");
                                                                                                                                                                                                                                                Field twoPower53Field = fastMathClass.getDeclaredField("TWO_POWER_53");
                                                                                                                                                                                                                                                twoPower53Field.setAccessible(true);
                                                                                                                                                                                                                                                double input = (Double) twoPower53Field.get(null);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Field mask30BitsField = fastMathClass.getDeclaredField("MASK_30BITS");
                                                                                                                                                                                                                                                mask30BitsField.setAccessible(true);
                                                                                                                                                                                                                                                long MASK_30BITS = (Long) mask30BitsField.get(null);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get expected value by manually performing bit operations
                                                                                                                                                                                                                                                long xl = Double.doubleToLongBits(input);
                                                                                                                                                                                                                                                xl = xl & MASK_30BITS;
                                                                                                                                                                                                                                                double expected = Double.longBitsToDouble(xl);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get private method via reflection
                                                                                                                                                                                                                                                Method doubleHighPartMethod = fastMathClass.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                                                doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                                                double actual = (Double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                assertEquals("Method should process exact TWO_POWER_53 value", 
                                                                                                                                                                                                                                                            expected, actual, 0.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                // Also verify it's not returning the input directly
                                                                                                                                                                                                                                                assertNotEquals("Method should not return exact TWO_POWER_53 value",
                                                                                                                                                                                                                                                              input, actual, 0.0);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                    public void testDoubleHighPartWithLargePositiveValue() throws Exception {
                                                                                                                                                                                                                                        // Get private TWO_POWER_53 field using reflection
                                                                                                                                                                                                                                        Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                                                                                                                                        twoPower53Field.setAccessible(true);
                                                                                                                                                                                                                                        double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Value larger than TWO_POWER_53
                                                                                                                                                                                                                                        double input = TWO_POWER_53 + 1.0;
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Get private doubleHighPart method using reflection
                                                                                                                                                                                                                                        Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                                        doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                                        double expected = (double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // The original would handle this specially, mutant would not
                                                                                                                                                                                                                                        assertNotEquals(input, expected, 0.0);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                    public void testDoubleHighPartWithLargeNegativeValue() throws Exception {
                                                                                                                                                                                                                                        // Get private TWO_POWER_53 field using reflection
                                                                                                                                                                                                                                        Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                                                                                                                                        twoPower53Field.setAccessible(true);
                                                                                                                                                                                                                                        double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Value smaller than -TWO_POWER_53
                                                                                                                                                                                                                                        double input = -TWO_POWER_53 - 1.0;
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Get private doubleHighPart method using reflection
                                                                                                                                                                                                                                        Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                                        doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                                        double expected = (double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // The original would handle this specially, mutant would not
                                                                                                                                                                                                                                        assertNotEquals(input, expected, 0.0);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                    public void testDoubleHighPartWithSmallValue() throws Exception {
                                                                                                                                                                                                                                        // Value within safe range
                                                                                                                                                                                                                                        double safeMin = Double.MIN_VALUE; // Using Double.MIN_VALUE as safe minimum
                                                                                                                                                                                                                                        double input = safeMin / 2;
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Get private method via reflection
                                                                                                                                                                                                                                        Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                                        doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                                        double expected = (Double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Both original and mutant should return same value
                                                                                                                                                                                                                                        assertEquals(input, expected, 0.0);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                            public void testDoubleHighPartWithLargeNegativeValue1() throws Exception {
                                                                                                                                                                                                                                // Use reflection to access private fields and methods
                                                                                                                                                                                                                                Class<?> fastMathClass = FastMath.class;
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Get TWO_POWER_53 field
                                                                                                                                                                                                                                Field twoPower53Field = fastMathClass.getDeclaredField("TWO_POWER_53");
                                                                                                                                                                                                                                twoPower53Field.setAccessible(true);
                                                                                                                                                                                                                                double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Get MASK_30BITS field
                                                                                                                                                                                                                                Field mask30BitsField = fastMathClass.getDeclaredField("MASK_30BITS");
                                                                                                                                                                                                                                mask30BitsField.setAccessible(true);
                                                                                                                                                                                                                                long MASK_30BITS = mask30BitsField.getLong(null);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Get doubleHighPart method
                                                                                                                                                                                                                                Method doubleHighPartMethod = fastMathClass.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                                doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Create a value much smaller than -TWO_POWER_53
                                                                                                                                                                                                                                double largeNegative = -2 * TWO_POWER_53;
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // In original code, this should be handled specially (similar to large positive)
                                                                                                                                                                                                                                // In mutant, it will go through normal processing
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Get the actual result
                                                                                                                                                                                                                                double result = (double) doubleHighPartMethod.invoke(null, largeNegative);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify it's not just returning the input (which mutant might do)
                                                                                                                                                                                                                                assertNotEquals(largeNegative, result, 0.0);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify the high bits are properly masked
                                                                                                                                                                                                                                long bits = Double.doubleToLongBits(result);
                                                                                                                                                                                                                                assertEquals(0, bits & ~MASK_30BITS);
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                    public void testDoubleHighPart() throws Exception {
                                                                                                                                                                                                                        // Get private TWO_POWER_53 field using reflection
                                                                                                                                                                                                                        Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                                                                                                                        twoPower53Field.setAccessible(true);
                                                                                                                                                                                                                        double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Get private doubleHighPart method using reflection
                                                                                                                                                                                                                        Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                        doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Test with value > TWO_POWER_53 - should detect the mutant
                                                                                                                                                                                                                        double largePositive = TWO_POWER_53 + 1.0;
                                                                                                                                                                                                                        double resultPositive = (double) doubleHighPartMethod.invoke(null, largePositive);
                                                                                                                                                                                                                        assertNotEquals("Mutant detected: large positive value was modified", 
                                                                                                                                                                                                                                       largePositive, resultPositive, 0.0);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Test with value < -TWO_POWER_53 - should behave same in both
                                                                                                                                                                                                                        double largeNegative = -TWO_POWER_53 - 1.0;
                                                                                                                                                                                                                        double resultNegative = (double) doubleHighPartMethod.invoke(null, largeNegative);
                                                                                                                                                                                                                        assertEquals(largeNegative, resultNegative, 0.0);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Test with value in normal range - should behave same in both
                                                                                                                                                                                                                        double normalValue = 123.456;
                                                                                                                                                                                                                        double resultNormal = (double) doubleHighPartMethod.invoke(null, normalValue);
                                                                                                                                                                                                                        assertNotEquals(normalValue, resultNormal, 0.0); // Should be modified by bit mask
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Test with very small value - should return same value
                                                                                                                                                                                                                        double smallValue = Double.MIN_VALUE / 2; // Using Double.MIN_VALUE instead of SAFE_MIN
                                                                                                                                                                                                                        double resultSmall = (double) doubleHighPartMethod.invoke(null, smallValue);
                                                                                                                                                                                                                        assertEquals(smallValue, resultSmall, 0.0);
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                            public void testDoubleHighPartWithLargeValues() throws Exception {
                                                                                                                                                                                                                // Get private TWO_POWER_53 field using reflection
                                                                                                                                                                                                                Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                                                                                                                twoPower53Field.setAccessible(true);
                                                                                                                                                                                                                double TWO_POWER_53 = (Double) twoPower53Field.get(null);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Values greater than or equal to TWO_POWER_53
                                                                                                                                                                                                                double largePositive = TWO_POWER_53;
                                                                                                                                                                                                                double veryLargePositive = TWO_POWER_53 * 2;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Values less than or equal to -TWO_POWER_53
                                                                                                                                                                                                                double largeNegative = -TWO_POWER_53;
                                                                                                                                                                                                                double veryLargeNegative = -TWO_POWER_53 * 2;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Get private doubleHighPart method using reflection
                                                                                                                                                                                                                Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                                doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test that large positive values are handled correctly
                                                                                                                                                                                                                double resultPos1 = (Double) doubleHighPartMethod.invoke(null, largePositive);
                                                                                                                                                                                                                double resultPos2 = (Double) doubleHighPartMethod.invoke(null, veryLargePositive);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test that large negative values are handled correctly
                                                                                                                                                                                                                double resultNeg1 = (Double) doubleHighPartMethod.invoke(null, largeNegative);
                                                                                                                                                                                                                double resultNeg2 = (Double) doubleHighPartMethod.invoke(null, veryLargeNegative);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify the results are different from input (special handling occurred)
                                                                                                                                                                                                                assertNotEquals("Large positive value should be modified", largePositive, resultPos1, 0.0);
                                                                                                                                                                                                                assertNotEquals("Very large positive value should be modified", veryLargePositive, resultPos2, 0.0);
                                                                                                                                                                                                                assertNotEquals("Large negative value should be modified", largeNegative, resultNeg1, 0.0);
                                                                                                                                                                                                                assertNotEquals("Very large negative value should be modified", veryLargeNegative, resultNeg2, 0.0);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // For the mutant version, these assertions would fail because the special handling is bypassed
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testPowWithNegativeBaseAndOddExponent() {
                                                                                                                                                                                                                // Test case that would detect the pow(-x,y) -> pow(x,y) mutation
                                                                                                                                                                                                                double negativeBase = -2.0;
                                                                                                                                                                                                                double oddExponent = 3.0;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Original should return (-2)^3 = -8
                                                                                                                                                                                                                // Mutated would return 2^3 = 8
                                                                                                                                                                                                                double result = FastMath.pow(negativeBase, oddExponent);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify the sign is preserved
                                                                                                                                                                                                                assertTrue("Result should be negative for negative base with odd exponent", 
                                                                                                                                                                                                                          result < 0);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify exact value
                                                                                                                                                                                                                assertEquals(-8.0, result, 0.0);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testPowWithNegativeBaseAndEvenExponent() {
                                                                                                                                                                                                                // Additional test case to verify even exponents work correctly
                                                                                                                                                                                                                double negativeBase = -2.0;
                                                                                                                                                                                                                double evenExponent = 4.0;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Both original and mutated would return 16 since (-2)^4 = 2^4
                                                                                                                                                                                                                double result = FastMath.pow(negativeBase, evenExponent);
                                                                                                                                                                                                                
                                                                                                                                                                                                                assertEquals(16.0, result, 0.0);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testPowWithPositiveBase() {
                                                                                                                                                                                                                // Test case with positive base to ensure basic functionality
                                                                                                                                                                                                                double positiveBase = 2.0;
                                                                                                                                                                                                                double exponent = 3.0;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Both original and mutated would return 8
                                                                                                                                                                                                                double result = FastMath.pow(positiveBase, exponent);
                                                                                                                                                                                                                
                                                                                                                                                                                                                assertEquals(8.0, result, 0.0);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testPowNegativeBase() {
                                                                                                                                                                                                            // Test case that would catch pow(-x,y) vs pow(-x,-y) mutation
                                                                                                                                                                                                            double x = -2.0;
                                                                                                                                                                                                            double y = 3.0;
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Original should return (-2)^3 = -8
                                                                                                                                                                                                            // Mutated would return (-2)^-3 = -0.125
                                                                                                                                                                                                            double result = FastMath.pow(x, y);
                                                                                                                                                                                                            assertEquals(-8.0, result, 0.0001);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test with even exponent to check sign
                                                                                                                                                                                                            y = 4.0;
                                                                                                                                                                                                            result = FastMath.pow(x, y);
                                                                                                                                                                                                            assertEquals(16.0, result, 0.0001); // (-2)^4 = 16 vs mutated (-2)^-4 = 0.0625
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test with fractional exponent
                                                                                                                                                                                                            y = 0.5;
                                                                                                                                                                                                            result = FastMath.pow(x, y);
                                                                                                                                                                                                            assertTrue(Double.isNaN(result)); // sqrt of negative should be NaN
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                            public void testDoubleHighPart1() throws Exception {
                                                                                                                                                                                                // Get private members via reflection
                                                                                                                                                                                                Class<?> fastMathClass = FastMath.class;
                                                                                                                                                                                                Method doubleHighPart = fastMathClass.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                                doubleHighPart.setAccessible(true);
                                                                                                                                                                                                
                                                                                                                                                                                                Field maskField = fastMathClass.getDeclaredField("MASK_30BITS");
                                                                                                                                                                                                maskField.setAccessible(true);
                                                                                                                                                                                                long MASK_30BITS = maskField.getLong(null);
                                                                                                                                                                                                
                                                                                                                                                                                                // Define SAFE_MIN as Double.MIN_VALUE (smallest positive nonzero value)
                                                                                                                                                                                                double SAFE_MIN = Double.MIN_VALUE;
                                                                                                                                                                                            
                                                                                                                                                                                                // Test values within SAFE_MIN range - should return unchanged
                                                                                                                                                                                                double smallValue = SAFE_MIN / 2;
                                                                                                                                                                                                assertEquals(smallValue, (Double)doubleHighPart.invoke(null, smallValue), 0.0);
                                                                                                                                                                                                assertEquals(-smallValue, (Double)doubleHighPart.invoke(null, -smallValue), 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test values just outside SAFE_MIN range
                                                                                                                                                                                                double justAbove = SAFE_MIN * 1.1;
                                                                                                                                                                                                double expectedAbove = Double.longBitsToDouble(Double.doubleToLongBits(justAbove) & MASK_30BITS);
                                                                                                                                                                                                assertEquals(expectedAbove, (Double)doubleHighPart.invoke(null, justAbove), 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                double justBelow = -SAFE_MIN * 1.1;
                                                                                                                                                                                                double expectedBelow = Double.longBitsToDouble(Double.doubleToLongBits(justBelow) & MASK_30BITS);
                                                                                                                                                                                                assertEquals(expectedBelow, (Double)doubleHighPart.invoke(null, justBelow), 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test normal values
                                                                                                                                                                                                double normalValue = 123.456;
                                                                                                                                                                                                double expectedNormal = Double.longBitsToDouble(Double.doubleToLongBits(normalValue) & MASK_30BITS);
                                                                                                                                                                                                assertEquals(expectedNormal, (Double)doubleHighPart.invoke(null, normalValue), 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test large values
                                                                                                                                                                                                double largeValue = 1e100;
                                                                                                                                                                                                double expectedLarge = Double.longBitsToDouble(Double.doubleToLongBits(largeValue) & MASK_30BITS);
                                                                                                                                                                                                assertEquals(expectedLarge, (Double)doubleHighPart.invoke(null, largeValue), 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test zero
                                                                                                                                                                                                assertEquals(0.0, (Double)doubleHighPart.invoke(null, 0.0), 0.0);
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                public void testDoubleHighPartWithOddIntegerBits() throws Exception {
                                                                                                                                                                                    // Get private MASK_30BITS field using reflection
                                                                                                                                                                                    Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                                                                                                                    maskField.setAccessible(true);
                                                                                                                                                                                    long MASK_30BITS = maskField.getLong(null);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get private doubleHighPart method using reflection
                                                                                                                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                    // Test with a value that would produce odd integer bits when converted to long bits
                                                                                                                                                                                    double input = 1.5; // Binary representation will have odd integer bits
                                                                                                                                                                                    double expected = Double.longBitsToDouble(Double.doubleToLongBits(input) & MASK_30BITS);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test normal case outside SAFE_MIN range
                                                                                                                                                                                    double result = (double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                                    assertEquals("High part should match masked bits", expected, result, 0.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test edge case just above SAFE_MIN
                                                                                                                                                                                    double edgeInput = Precision.SAFE_MIN * 1.1;
                                                                                                                                                                                    double edgeExpected = Double.longBitsToDouble(Double.doubleToLongBits(edgeInput) & MASK_30BITS);
                                                                                                                                                                                    double edgeResult = (double) doubleHighPartMethod.invoke(null, edgeInput);
                                                                                                                                                                                    assertEquals("Edge case above SAFE_MIN should be processed", edgeExpected, edgeResult, 0.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case within SAFE_MIN range (should return input directly)
                                                                                                                                                                                    double smallInput = Precision.SAFE_MIN / 2;
                                                                                                                                                                                    double smallResult = (double) doubleHighPartMethod.invoke(null, smallInput);
                                                                                                                                                                                    assertEquals("Value within SAFE_MIN range should return unchanged", smallInput, smallResult, 0.0);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testDoubleHighPartWithEvenIntegers() throws Exception {
                                                                                                                                                                            // Get private methods/fields via reflection
                                                                                                                                                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                            doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                                                                                                            maskField.setAccessible(true);
                                                                                                                                                                            long MASK_30BITS = maskField.getLong(null);
                                                                                                                                                                        
                                                                                                                                                                            // Test with even integer within SAFE_MIN range
                                                                                                                                                                            double smallEven = 1.0E-300; // Well below SAFE_MIN
                                                                                                                                                                            assertEquals("Small even number should be returned unchanged", 
                                                                                                                                                                                        smallEven, 
                                                                                                                                                                                        (Double)doubleHighPartMethod.invoke(null, smallEven), 
                                                                                                                                                                                        0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Test with even integer outside SAFE_MIN range
                                                                                                                                                                            double largeEven = 2.0; // Simple even integer
                                                                                                                                                                            long expectedBits = Double.doubleToLongBits(largeEven) & MASK_30BITS;
                                                                                                                                                                            double expected = Double.longBitsToDouble(expectedBits);
                                                                                                                                                                            assertEquals("High part of even integer should be correctly extracted",
                                                                                                                                                                                        expected,
                                                                                                                                                                                        (Double)doubleHighPartMethod.invoke(null, largeEven),
                                                                                                                                                                                        0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Test with even integer near SAFE_MIN boundary
                                                                                                                                                                            double boundaryEven = Precision.SAFE_MIN * 2; // Just above SAFE_MIN
                                                                                                                                                                            long boundaryExpectedBits = Double.doubleToLongBits(boundaryEven) & MASK_30BITS;
                                                                                                                                                                            double boundaryExpected = Double.longBitsToDouble(boundaryExpectedBits);
                                                                                                                                                                            assertEquals("Even number at boundary should be processed",
                                                                                                                                                                                        boundaryExpected,
                                                                                                                                                                                        (Double)doubleHighPartMethod.invoke(null, boundaryEven),
                                                                                                                                                                                        0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Test with negative even integer
                                                                                                                                                                            double negativeEven = -4.0;
                                                                                                                                                                            long negativeExpectedBits = Double.doubleToLongBits(negativeEven) & MASK_30BITS;
                                                                                                                                                                            double negativeExpected = Double.longBitsToDouble(negativeExpectedBits);
                                                                                                                                                                            assertEquals("Negative even number should be processed correctly",
                                                                                                                                                                                        negativeExpected,
                                                                                                                                                                                        (Double)doubleHighPartMethod.invoke(null, negativeEven),
                                                                                                                                                                                        0.0);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testDoubleHighPartWithZeroInput() throws Exception {
                                                                                                                                                                    // Test with exactly zero - should be treated differently by original vs mutant
                                                                                                                                                                    double input = 0.0;
                                                                                                                                                                    
                                                                                                                                                                    // Get private doubleHighPart method via reflection
                                                                                                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                    double result = (Double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                    
                                                                                                                                                                    // Get private MASK_30BITS field via reflection
                                                                                                                                                                    Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                                                                                                    maskField.setAccessible(true);
                                                                                                                                                                    long mask = maskField.getLong(null);
                                                                                                                                                                    
                                                                                                                                                                    // Verify the result went through bit manipulation (not returned directly)
                                                                                                                                                                    long bits = Double.doubleToLongBits(result);
                                                                                                                                                                    long expectedBits = Double.doubleToLongBits(input) & mask;
                                                                                                                                                                    assertEquals("Zero input should be processed through bit manipulation", 
                                                                                                                                                                                expectedBits, bits);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testDoubleHighPartWithVerySmallPositiveValue() throws Exception {
                                                                                                                                                                    // Test with a value just above zero but below SAFE_MIN
                                                                                                                                                                    double safeMin = Double.MIN_VALUE; // Using Double.MIN_VALUE as SAFE_MIN equivalent
                                                                                                                                                                    double input = safeMin / 2;
                                                                                                                                                                    
                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                    double result = (Double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                    
                                                                                                                                                                    // Should return the input directly (not processed through bit manipulation)
                                                                                                                                                                    assertEquals("Very small positive input should be returned directly",
                                                                                                                                                                                input, result, 0.0);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testDoubleHighPartWithVerySmallNegativeValue() throws Exception {
                                                                                                                                                                    // Define SAFE_MIN as Double.MIN_VALUE (smallest positive nonzero value)
                                                                                                                                                                    final double SAFE_MIN = Double.MIN_VALUE;
                                                                                                                                                                    
                                                                                                                                                                    // Test with a value just below zero but above -SAFE_MIN
                                                                                                                                                                    double input = -SAFE_MIN / 2;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access private doubleHighPart method
                                                                                                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                                                                    double result = (Double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                                    
                                                                                                                                                                    // Should return the input directly (not processed through bit manipulation)
                                                                                                                                                                    assertEquals("Very small negative input should be returned directly",
                                                                                                                                                                                input, result, 0.0);
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testDoubleHighPart_ExactlyTwoPower() throws Exception {
                                                                                                                                                            // Define TWO_POWER_53 constant
                                                                                                                                                            final double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                                                                                                                            
                                                                                                                                                            // Get private MASK_30BITS field using reflection
                                                                                                                                                            Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                                                                                            maskField.setAccessible(true);
                                                                                                                                                            long MASK_30BITS = maskField.getLong(null);
                                                                                                                                                            
                                                                                                                                                            // Get private doubleHighPart method using reflection
                                                                                                                                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                            doubleHighPartMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test with value exactly equal to TWO_POWER_53
                                                                                                                                                            double input = TWO_POWER_53;
                                                                                                                                                            
                                                                                                                                                            // The original method should treat this as a special case
                                                                                                                                                            // The mutated version will process it normally
                                                                                                                                                            double result = (double) doubleHighPartMethod.invoke(null, input);
                                                                                                                                                            
                                                                                                                                                            // Verify the result is handled correctly
                                                                                                                                                            // For the original code, this would be different from just masking bits
                                                                                                                                                            long expectedBits = Double.doubleToLongBits(input) & MASK_30BITS;
                                                                                                                                                            double expected = Double.longBitsToDouble(expectedBits);
                                                                                                                                                            
                                                                                                                                                            // This assertion will fail if the mutant is present
                                                                                                                                                            assertEquals("Should handle TWO_POWER_53 as special case", 
                                                                                                                                                                        expected, result, 0.0);
                                                                                                                                                            
                                                                                                                                                            // Additional check to ensure the value was processed
                                                                                                                                                            assertNotEquals("Input should be processed", input, result, 0.0);
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testDoubleHighPartDetectsMutant() throws Exception {
                                                                                                                                                    // Get private TWO_POWER_53 field using reflection
                                                                                                                                                    Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                                                    twoPower53Field.setAccessible(true);
                                                                                                                                                    double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                                                                                                                    
                                                                                                                                                    // Get private doubleHighPart method using reflection
                                                                                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test with value greater than TWO_POWER_53
                                                                                                                                                    double largePositive = TWO_POWER_53 + 1.0;
                                                                                                                                                    double resultPositive = (double) doubleHighPartMethod.invoke(null, largePositive);
                                                                                                                                                    // Should be different from input if original condition works (|| case)
                                                                                                                                                    // But will be same if mutant condition is used (&& case)
                                                                                                                                                    assertNotEquals("Value > TWO_POWER_53 should be processed", 
                                                                                                                                                                  largePositive, resultPositive, 0.0);
                                                                                                                                                    
                                                                                                                                                    // Test with value less than -TWO_POWER_53
                                                                                                                                                    double largeNegative = -TWO_POWER_53 - 1.0;
                                                                                                                                                    double resultNegative = (double) doubleHighPartMethod.invoke(null, largeNegative);
                                                                                                                                                    // Should be different from input if original condition works (|| case)
                                                                                                                                                    // But will be same if mutant condition is used (&& case)
                                                                                                                                                    assertNotEquals("Value < -TWO_POWER_53 should be processed", 
                                                                                                                                                                  largeNegative, resultNegative, 0.0);
                                                                                                                                                    
                                                                                                                                                    // Additional test with value between -TWO_POWER_53 and TWO_POWER_53
                                                                                                                                                    double mediumValue = TWO_POWER_53 - 1.0;
                                                                                                                                                    double resultMedium = (double) doubleHighPartMethod.invoke(null, mediumValue);
                                                                                                                                                    assertEquals("Value within range should be processed normally",
                                                                                                                                                               mediumValue, resultMedium, 0.0);
                                                                                                                                                }

    @Test
                                                                                                                                        public void testDoubleHighPartWithLargeNegativeValue2() throws Exception {
                                                                                                                                            // Use reflection to access private fields and methods
                                                                                                                                            Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                                            twoPower53Field.setAccessible(true);
                                                                                                                                            double TWO_POWER_53 = (Double) twoPower53Field.get(null);
                                                                                                                                            
                                                                                                                                            Field mask30BitsField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                                                                            mask30BitsField.setAccessible(true);
                                                                                                                                            long MASK_30BITS = (Long) mask30BitsField.get(null);
                                                                                                                                            
                                                                                                                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                            doubleHighPartMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Create a value that's <= -TWO_POWER_53
                                                                                                                                            double largeNegativeValue = -TWO_POWER_53 - 1.0;
                                                                                                                                            
                                                                                                                                            // Get the actual bits to understand expected behavior
                                                                                                                                            long originalBits = Double.doubleToLongBits(largeNegativeValue);
                                                                                                                                            long maskedBits = originalBits & MASK_30BITS;
                                                                                                                                            double expected = Double.longBitsToDouble(maskedBits);
                                                                                                                                            
                                                                                                                                            // The original code would handle this differently than the mutant
                                                                                                                                            // The mutant would process it through the normal path
                                                                                                                                            double actual = (Double) doubleHighPartMethod.invoke(null, largeNegativeValue);
                                                                                                                                            
                                                                                                                                            // For the original code, this would fail if the mutant is present
                                                                                                                                            // because the mutant would process the large negative value normally
                                                                                                                                            assertEquals("Large negative value should be processed normally", 
                                                                                                                                                       expected, actual, 0.0);
                                                                                                                                            
                                                                                                                                            // Additional check - verify the value is indeed <= -TWO_POWER_53
                                                                                                                                            assertTrue("Test value should be <= -TWO_POWER_53", 
                                                                                                                                                      largeNegativeValue <= -TWO_POWER_53);
                                                                                                                                        }

    @Test
                                                                                                                                public void testDoubleHighPartWithLargePositiveValue1() throws Exception {
                                                                                                                                    // This value is greater than TWO_POWER_53 (2^53)
                                                                                                                                    double largeValue = 9007199254740993.0; // TWO_POWER_53 + 1
                                                                                                                                    
                                                                                                                                    // Get private doubleHighPart method using reflection
                                                                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                                    double result = (Double) doubleHighPartMethod.invoke(null, largeValue);
                                                                                                                                    
                                                                                                                                    // Verify the result is different from input (normal processing would modify it)
                                                                                                                                    // If mutant is present, it would return the same value (no special handling)
                                                                                                                                    assertNotEquals("Large positive value should be modified", largeValue, result, 0.0);
                                                                                                                                    
                                                                                                                                    // Get private MASK_30BITS field using reflection
                                                                                                                                    Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                                                                    maskField.setAccessible(true);
                                                                                                                                    long MASK_30BITS = (Long) maskField.get(null);
                                                                                                                                    
                                                                                                                                    // Additional verification - check if high bits were properly masked
                                                                                                                                    long bits = Double.doubleToLongBits(result);
                                                                                                                                    long maskedBits = bits & MASK_30BITS;
                                                                                                                                    assertEquals("High bits should be properly masked", bits, maskedBits);
                                                                                                                                }

    @Test
                                                                                                                                public void testDoubleHighPartWithLargeNegativeValue3() throws Exception {
                                                                                                                                    // This value is less than -TWO_POWER_53
                                                                                                                                    double largeNegativeValue = -9007199254740993.0; // -TWO_POWER_53 - 1
                                                                                                                                    
                                                                                                                                    // Get the private method using reflection
                                                                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Invoke the method
                                                                                                                                    double result = (Double) doubleHighPartMethod.invoke(null, largeNegativeValue);
                                                                                                                                    
                                                                                                                                    // Verify the result is different from input
                                                                                                                                    assertNotEquals("Large negative value should be modified", largeNegativeValue, result, 0.0);
                                                                                                                                }

    @Test
                                                                                                                        public void testDoubleHighPartWithLargeValues1() throws Exception {
                                                                                                                            // Get private TWO_POWER_53 field using reflection
                                                                                                                            Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                                                                            twoPower53Field.setAccessible(true);
                                                                                                                            double TWO_POWER_53 = (Double) twoPower53Field.get(null);
                                                                                                                            
                                                                                                                            // Get private doubleHighPart method using reflection
                                                                                                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                            doubleHighPartMethod.setAccessible(true);
                                                                                                                            
                                                                                                                            // Values greater than or equal to TWO_POWER_53
                                                                                                                            double largePositive = TWO_POWER_53;
                                                                                                                            double veryLargePositive = TWO_POWER_53 * 2;
                                                                                                                            
                                                                                                                            // Values less than or equal to -TWO_POWER_53
                                                                                                                            double largeNegative = -TWO_POWER_53;
                                                                                                                            double veryLargeNegative = -TWO_POWER_53 * 2;
                                                                                                                            
                                                                                                                            // Test that large positive values are handled correctly
                                                                                                                            double resultPos1 = (Double) doubleHighPartMethod.invoke(null, largePositive);
                                                                                                                            double resultPos2 = (Double) doubleHighPartMethod.invoke(null, veryLargePositive);
                                                                                                                            
                                                                                                                            // Test that large negative values are handled correctly
                                                                                                                            double resultNeg1 = (Double) doubleHighPartMethod.invoke(null, largeNegative);
                                                                                                                            double resultNeg2 = (Double) doubleHighPartMethod.invoke(null, veryLargeNegative);
                                                                                                                            
                                                                                                                            // The mutant would return the modified bits for these large values,
                                                                                                                            // while the original would return them unchanged (due to the condition)
                                                                                                                            // So we assert that the results should be different from input for the original,
                                                                                                                            // but the mutant would return the same as input
                                                                                                                            assertNotEquals("Large positive value should be modified", largePositive, resultPos1, 0.0);
                                                                                                                            assertNotEquals("Very large positive value should be modified", veryLargePositive, resultPos2, 0.0);
                                                                                                                            assertNotEquals("Large negative value should be modified", largeNegative, resultNeg1, 0.0);
                                                                                                                            assertNotEquals("Very large negative value should be modified", veryLargeNegative, resultNeg2, 0.0);
                                                                                                                        }

    @Test
                                                                                                                public void testDoubleHighPart2() throws Exception {
                                                                                                                    // Get private constants and methods via reflection
                                                                                                                    Class<?> fastMathClass = FastMath.class;
                                                                                                                    Field safeMinField = fastMathClass.getDeclaredField("SAFE_MIN");
                                                                                                                    safeMinField.setAccessible(true);
                                                                                                                    double SAFE_MIN = safeMinField.getDouble(null);
                                                                                                                    
                                                                                                                    Field maskField = fastMathClass.getDeclaredField("MASK_30BITS");
                                                                                                                    maskField.setAccessible(true);
                                                                                                                    long MASK_30BITS = maskField.getLong(null);
                                                                                                                    
                                                                                                                    Method doubleHighPartMethod = fastMathClass.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                                                
                                                                                                                    // Test values within SAFE_MIN range - should return unchanged
                                                                                                                    double smallPositive = SAFE_MIN / 2;
                                                                                                                    assertEquals(smallPositive, (double)doubleHighPartMethod.invoke(null, smallPositive), 0.0);
                                                                                                                    
                                                                                                                    double smallNegative = -SAFE_MIN / 2;
                                                                                                                    assertEquals(smallNegative, (double)doubleHighPartMethod.invoke(null, smallNegative), 0.0);
                                                                                                                    
                                                                                                                    // Test zero
                                                                                                                    assertEquals(0.0, (double)doubleHighPartMethod.invoke(null, 0.0), 0.0);
                                                                                                                    
                                                                                                                    // Test values just outside SAFE_MIN range
                                                                                                                    double justAbove = SAFE_MIN * 1.1;
                                                                                                                    long bitsJustAbove = Double.doubleToLongBits(justAbove);
                                                                                                                    long expectedBitsJustAbove = bitsJustAbove & MASK_30BITS;
                                                                                                                    double expectedResultJustAbove = Double.longBitsToDouble(expectedBitsJustAbove);
                                                                                                                    assertEquals(expectedResultJustAbove, (double)doubleHighPartMethod.invoke(null, justAbove), 0.0);
                                                                                                                    
                                                                                                                    double justBelow = -SAFE_MIN * 1.1;
                                                                                                                    long bitsJustBelow = Double.doubleToLongBits(justBelow);
                                                                                                                    long expectedBitsJustBelow = bitsJustBelow & MASK_30BITS;
                                                                                                                    double expectedResultJustBelow = Double.longBitsToDouble(expectedBitsJustBelow);
                                                                                                                    assertEquals(expectedResultJustBelow, (double)doubleHighPartMethod.invoke(null, justBelow), 0.0);
                                                                                                                    
                                                                                                                    // Test large values
                                                                                                                    double largeValue = 123456789.0;
                                                                                                                    long bitsLarge = Double.doubleToLongBits(largeValue);
                                                                                                                    long expectedBitsLarge = bitsLarge & MASK_30BITS;
                                                                                                                    double expectedResultLarge = Double.longBitsToDouble(expectedBitsLarge);
                                                                                                                    assertEquals(expectedResultLarge, (double)doubleHighPartMethod.invoke(null, largeValue), 0.0);
                                                                                                                    
                                                                                                                    // Test special cases
                                                                                                                    assertTrue(Double.isNaN((double)doubleHighPartMethod.invoke(null, Double.NaN)));
                                                                                                                    assertEquals(Double.POSITIVE_INFINITY, (double)doubleHighPartMethod.invoke(null, Double.POSITIVE_INFINITY), 0.0);
                                                                                                                    assertEquals(Double.NEGATIVE_INFINITY, (double)doubleHighPartMethod.invoke(null, Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                    
                                                                                                                    // Test boundary case - exactly SAFE_MIN (should be modified)
                                                                                                                    double safeMin = SAFE_MIN;
                                                                                                                    long bitsSafeMin = Double.doubleToLongBits(safeMin);
                                                                                                                    long expectedBitsSafeMin = bitsSafeMin & MASK_30BITS;
                                                                                                                    double expectedResultSafeMin = Double.longBitsToDouble(expectedBitsSafeMin);
                                                                                                                    assertEquals(expectedResultSafeMin, (double)doubleHighPartMethod.invoke(null, safeMin), 0.0);
                                                                                                                }

    @Test
                                                                                                                public void testPowNegativeBase1() {
                                                                                                                    // Test case that would catch the pow(-x,y) -> pow(-x,-y) mutation
                                                                                                                    double x = 2.0;
                                                                                                                    double y = 3.0;
                                                                                                                    
                                                                                                                    // Original should return (-2)^3 = -8
                                                                                                                    // Mutant would return (-2)^-3 = -0.125
                                                                                                                    double expected = -8.0;
                                                                                                                    double actual = FastMath.pow(-x, y);
                                                                                                                    
                                                                                                                    assertEquals("pow(-x,y) should return correct value", expected, actual, 0.0001);
                                                                                                                    
                                                                                                                    // Additional test case with negative y to ensure both cases are covered
                                                                                                                    double yNeg = -3.0;
                                                                                                                    double expectedNeg = -0.125;
                                                                                                                    double actualNeg = FastMath.pow(-x, yNeg);
                                                                                                                    
                                                                                                                    assertEquals("pow(-x,-y) should return correct value", expectedNeg, actualNeg, 0.0001);
                                                                                                                }

    @Test
                                                                                                                public void testPowEdgeCases() {
                                                                                                                    // Test edge cases that would reveal the mutation
                                                                                                                    // Case 1: y = 0 (any x^0 should be 1)
                                                                                                                    assertEquals(1.0, FastMath.pow(-5.0, 0.0), 0.0001);
                                                                                                                    
                                                                                                                    // Case 2: y = 1 (should return -x)
                                                                                                                    assertEquals(-3.0, FastMath.pow(-3.0, 1.0), 0.0001);
                                                                                                                    
                                                                                                                    // Case 3: x = 0
                                                                                                                    assertEquals(0.0, FastMath.pow(-0.0, 2.0), 0.0001);
                                                                                                                }

    @Test
                                                                                                            public void testPowWithNegativeBase() {
                                                                                                                // Test with negative base and odd exponent
                                                                                                                double result1 = FastMath.pow(-2.0, 3.0); // Should be -8.0
                                                                                                                assertNotEquals("Negative base with odd exponent should not return 0", 0.0, result1, 0.0001);
                                                                                                                assertEquals(-8.0, result1, 0.0001);
                                                                                                                
                                                                                                                // Test with negative base and even exponent
                                                                                                                double result2 = FastMath.pow(-2.0, 4.0); // Should be 16.0
                                                                                                                assertNotEquals("Negative base with even exponent should not return 0", 0.0, result2, 0.0001);
                                                                                                                assertEquals(16.0, result2, 0.0001);
                                                                                                                
                                                                                                                // Test with negative base and fractional exponent
                                                                                                                double result3 = FastMath.pow(-8.0, 1.0/3.0); // Should be -2.0
                                                                                                                assertNotEquals("Negative base with fractional exponent should not return 0", 0.0, result3, 0.0001);
                                                                                                                assertEquals(-2.0, result3, 0.0001);
                                                                                                            }

    @Test
                                                                                                public void testDoubleHighPartEvenOddCases() throws Exception {
                                                                                                    // Test with values that will produce even and odd results after bit manipulation
                                                                                                    double evenCase = 4.0;  // Binary representation will have even bits
                                                                                                    double oddCase = 5.0;   // Binary representation will have odd bits
                                                                                                    
                                                                                                    // Get the private method using reflection
                                                                                                    Method doubleHighPart = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                                    doubleHighPart.setAccessible(true);
                                                                                                    
                                                                                                    // Get the high parts
                                                                                                    double evenHighPart = (Double) doubleHighPart.invoke(null, evenCase);
                                                                                                    double oddHighPart = (Double) doubleHighPart.invoke(null, oddCase);
                                                                                                    
                                                                                                    // Convert back to bits to verify parity
                                                                                                    long evenBits = Double.doubleToLongBits(evenHighPart);
                                                                                                    long oddBits = Double.doubleToLongBits(oddHighPart);
                                                                                                    
                                                                                                    // Mask to check the lowest bit (parity)
                                                                                                    long evenMasked = evenBits & 1L;
                                                                                                    long oddMasked = oddBits & 1L;
                                                                                                    
                                                                                                    // Verify even case produces even result (0 in LSB)
                                                                                                    assertEquals(0L, evenMasked);
                                                                                                    
                                                                                                    // Verify odd case produces odd result (1 in LSB)
                                                                                                    assertEquals(1L, oddMasked);
                                                                                                    
                                                                                                    // Additional verification that the values are different
                                                                                                    assertNotEquals(evenHighPart, oddHighPart);
                                                                                                }

    @Test
                                                                                        public void testDoubleHighPartWithEvenInteger() throws Exception {
                                                                                            // Get private MASK_30BITS field using reflection
                                                                                            Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                            maskField.setAccessible(true);
                                                                                            long MASK_30BITS = maskField.getLong(null);
                                                                                            
                                                                                            // Get private doubleHighPart method using reflection
                                                                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                            doubleHighPartMethod.setAccessible(true);
                                                                                        
                                                                                            // Test with an even integer value outside SAFE_MIN range
                                                                                            double input = 4.0; // Even integer
                                                                                            double expected = Double.longBitsToDouble(Double.doubleToLongBits(input) & MASK_30BITS);
                                                                                            
                                                                                            // Verify the high part extraction works correctly
                                                                                            double result = (double) doubleHighPartMethod.invoke(null, input);
                                                                                            assertEquals("High part of even integer not extracted correctly", 
                                                                                                         expected, result, 0.0);
                                                                                            
                                                                                            // Additional test with negative even integer
                                                                                            double negativeInput = -6.0;
                                                                                            double negativeExpected = Double.longBitsToDouble(Double.doubleToLongBits(negativeInput) & MASK_30BITS);
                                                                                            double negativeResult = (double) doubleHighPartMethod.invoke(null, negativeInput);
                                                                                            assertEquals("High part of negative even integer not extracted correctly",
                                                                                                        negativeExpected, negativeResult, 0.0);
                                                                                            
                                                                                            // Test with even integer within SAFE_MIN range (should return input directly)
                                                                                            double smallEven = Precision.SAFE_MIN / 2;
                                                                                            double smallResult = (double) doubleHighPartMethod.invoke(null, smallEven);
                                                                                            assertEquals("Small even number should return input directly",
                                                                                                        smallEven, smallResult, 0.0);
                                                                                        }

    @Test
                                                                                public void testDoubleHighPart_ZeroValue() throws Exception {
                                                                                    // Test with exactly zero
                                                                                    double input = 0.0;
                                                                                    
                                                                                    // Get private MASK_30BITS field using reflection
                                                                                    Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                    maskField.setAccessible(true);
                                                                                    long MASK_30BITS = maskField.getLong(null);
                                                                                    
                                                                                    // The original method would process zero through the bit manipulation
                                                                                    // The mutated method would return zero directly
                                                                                    long expectedBits = Double.doubleToLongBits(input) & MASK_30BITS;
                                                                                    double expected = Double.longBitsToDouble(expectedBits);
                                                                                    
                                                                                    // Get private doubleHighPart method using reflection
                                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                    doubleHighPartMethod.setAccessible(true);
                                                                                    double result = (double) doubleHighPartMethod.invoke(null, input);
                                                                                    
                                                                                    // Verify the result went through bit manipulation
                                                                                    assertEquals(expected, result, 0.0);
                                                                                    
                                                                                    // Also verify it's not returning the input directly
                                                                                    assertNotSame(input, result);
                                                                                }

    @Test
                                                                                public void testDoubleHighPart_NearZeroValues() throws Exception {
                                                                                    // Get private members via reflection
                                                                                    Method doubleHighPart = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                                    doubleHighPart.setAccessible(true);
                                                                                    
                                                                                    Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                                    maskField.setAccessible(true);
                                                                                    long MASK_30BITS = maskField.getLong(null);
                                                                                    
                                                                                    // Define SAFE_MIN as Double.MIN_VALUE (smallest positive nonzero value)
                                                                                    double SAFE_MIN = Double.MIN_VALUE;
                                                                                    
                                                                                    // Test with very small positive number
                                                                                    double smallPositive = SAFE_MIN / 2;
                                                                                    assertEquals(smallPositive, (double)doubleHighPart.invoke(null, smallPositive), 0.0);
                                                                                    
                                                                                    // Test with very small negative number
                                                                                    double smallNegative = -SAFE_MIN / 2;
                                                                                    assertEquals(smallNegative, (double)doubleHighPart.invoke(null, smallNegative), 0.0);
                                                                                    
                                                                                    // Test with number just above SAFE_MIN
                                                                                    double aboveThreshold = SAFE_MIN * 1.1;
                                                                                    long expectedBits = Double.doubleToLongBits(aboveThreshold) & MASK_30BITS;
                                                                                    double expected = Double.longBitsToDouble(expectedBits);
                                                                                    assertEquals(expected, (double)doubleHighPart.invoke(null, aboveThreshold), 0.0);
                                                                                }

    @Test
                                                                        public void testDoubleHighPartWithExactTwoPower1() throws Exception {
                                                                            // Use reflection to access private fields and methods
                                                                            Class<?> fastMathClass = FastMath.class;
                                                                            
                                                                            // Get TWO_POWER_53 field
                                                                            Field twoPower53Field = fastMathClass.getDeclaredField("TWO_POWER_53");
                                                                            twoPower53Field.setAccessible(true);
                                                                            double twoPower53 = (Double) twoPower53Field.get(null);
                                                                            
                                                                            // Get MASK_30BITS field
                                                                            Field mask30BitsField = fastMathClass.getDeclaredField("MASK_30BITS");
                                                                            mask30BitsField.setAccessible(true);
                                                                            long MASK_30BITS = (Long) mask30BitsField.get(null);
                                                                            
                                                                            // Get doubleHighPart method
                                                                            Method doubleHighPartMethod = fastMathClass.getDeclaredMethod("doubleHighPart", double.class);
                                                                            doubleHighPartMethod.setAccessible(true);
                                                                            
                                                                            // Test with the exact boundary value
                                                                            double result = (Double) doubleHighPartMethod.invoke(null, twoPower53);
                                                                            
                                                                            // In original code, this should be handled by the special case
                                                                            // In mutated code, it would fall through to the bit manipulation
                                                                            // Verify it's not just passing through unchanged
                                                                            assertNotEquals(twoPower53, result, 0.0);
                                                                            
                                                                            // Additionally verify the bit manipulation produces expected result
                                                                            long expectedBits = Double.doubleToLongBits(twoPower53) & MASK_30BITS;
                                                                            double expectedValue = Double.longBitsToDouble(expectedBits);
                                                                            assertEquals(expectedValue, result, 0.0);
                                                                        }

    @Test
                                                                public void testDoubleHighPart_LargePositiveValue() throws Exception {
                                                                    // Get private TWO_POWER_53 field using reflection
                                                                    Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                    twoPower53Field.setAccessible(true);
                                                                    double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                                    
                                                                    // Get private doubleHighPart method using reflection
                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                    doubleHighPartMethod.setAccessible(true);
                                                                    
                                                                    // Value larger than TWO_POWER_53
                                                                    double input = TWO_POWER_53 + 1000.0;
                                                                    double expected = input; // Should be handled specially in original
                                                                    double actual = (Double) doubleHighPartMethod.invoke(null, input);
                                                                    
                                                                    // This will fail if the mutant is present because the mutant's condition
                                                                    // (>= TWO_POWER_53 AND <= -TWO_POWER_53) can never be true
                                                                    assertEquals("Large positive value should be handled differently", 
                                                                                expected, actual, 0.0);
                                                                }

    @Test
                                                                public void testDoubleHighPart_LargeNegativeValue() throws Exception {
                                                                    // Get private TWO_POWER_53 field using reflection
                                                                    Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                                    twoPower53Field.setAccessible(true);
                                                                    double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                                    
                                                                    // Value smaller than -TWO_POWER_53
                                                                    double input = -TWO_POWER_53 - 1000.0;
                                                                    double expected = input; // Should be handled specially in original
                                                                    
                                                                    // Get private doubleHighPart method using reflection
                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                    doubleHighPartMethod.setAccessible(true);
                                                                    double actual = (double) doubleHighPartMethod.invoke(null, input);
                                                                    
                                                                    // This will fail if the mutant is present for same reason
                                                                    assertEquals("Large negative value should be handled differently",
                                                                                expected, actual, 0.0);
                                                                }

    @Test
                                                                public void testDoubleHighPart_WithinRangeValue() throws Exception {
                                                                    // Value within [-TWO_POWER_53, TWO_POWER_53]
                                                                    double input = 123.456;
                                                                    
                                                                    // Get private MASK_30BITS field using reflection
                                                                    Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                                    maskField.setAccessible(true);
                                                                    long MASK_30BITS = maskField.getLong(null);
                                                                    
                                                                    // Calculate expected value
                                                                    double expected = Double.longBitsToDouble(Double.doubleToLongBits(input) & MASK_30BITS);
                                                                    
                                                                    // Get private doubleHighPart method using reflection
                                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                                    doubleHighPartMethod.setAccessible(true);
                                                                    
                                                                    // Call the method
                                                                    double actual = (Double) doubleHighPartMethod.invoke(null, input);
                                                                    
                                                                    assertEquals("Normal value should have low bits masked",
                                                                                expected, actual, 0.0);
                                                                }

    @Test
                                                        public void testDoubleHighPart_LargeNegativeValue1() throws Exception {
                                                            // Get private TWO_POWER_53 field using reflection
                                                            Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                            twoPower53Field.setAccessible(true);
                                                            double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                            
                                                            // Get private doubleHighPart method using reflection
                                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                            doubleHighPartMethod.setAccessible(true);
                                                            
                                                            // This test will catch the mutant by using a very large negative number
                                                            double largeNegative = -TWO_POWER_53 - 1.0;
                                                            
                                                            // In original code, this should be handled specially (same as large positive)
                                                            // In mutant code, it will fall through to normal processing
                                                            double result = (Double) doubleHighPartMethod.invoke(null, largeNegative);
                                                            
                                                            // We can't predict exact result, but should differ from input
                                                            assertNotEquals(largeNegative, result, 0.0);
                                                            
                                                            // Also test that large positive is handled (both versions should pass this)
                                                            double largePositive = TWO_POWER_53 + 1.0;
                                                            double posResult = (Double) doubleHighPartMethod.invoke(null, largePositive);
                                                            assertNotEquals(largePositive, posResult, 0.0);
                                                        }

    @Test
                                                        public void testDoubleHighPart_RegularValues() throws Exception {
                                                            // Test normal case that should work the same in both versions
                                                            double input = 123.456;
                                                            
                                                            // Get private doubleHighPart method via reflection
                                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                            doubleHighPartMethod.setAccessible(true);
                                                            double result = (Double) doubleHighPartMethod.invoke(null, input);
                                                            
                                                            // Get private MASK_30BITS field via reflection
                                                            Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                                            maskField.setAccessible(true);
                                                            long MASK_30BITS = (Long) maskField.get(null);
                                                            
                                                            // Result should be input with lower bits masked off
                                                            long bits = Double.doubleToLongBits(input);
                                                            long expectedBits = bits & MASK_30BITS;
                                                            double expected = Double.longBitsToDouble(expectedBits);
                                                            
                                                            assertEquals(expected, result, 0.0);
                                                        }

    @Test
                                                        public void testDoubleHighPart_SmallValues() throws Exception {
                                                            // Get private method via reflection
                                                            Method doubleHighPart = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                            doubleHighPart.setAccessible(true);
                                                            
                                                            // Test small values that should be returned unchanged
                                                            double safeMin = Double.MIN_VALUE; // Using Double.MIN_VALUE as SAFE_MIN equivalent
                                                            double smallPos = safeMin / 2;
                                                            assertEquals(smallPos, (double)doubleHighPart.invoke(null, smallPos), 0.0);
                                                            
                                                            double smallNeg = -safeMin / 2;
                                                            assertEquals(smallNeg, (double)doubleHighPart.invoke(null, smallNeg), 0.0);
                                                        }

    @Test
                                                public void testDoubleHighPartWithLargePositiveValue2() throws Exception {
                                                    // Get private TWO_POWER_53 field using reflection
                                                    Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                                    twoPower53Field.setAccessible(true);
                                                    double TWO_POWER_53 = twoPower53Field.getDouble(null);
                                                    
                                                    // Create a value larger than TWO_POWER_53
                                                    double largeValue = TWO_POWER_53 + 1.0;
                                                    
                                                    // Get private doubleHighPart method using reflection
                                                    Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                                    doubleHighPartMethod.setAccessible(true);
                                                    
                                                    // Call the method
                                                    double result = (double) doubleHighPartMethod.invoke(null, largeValue);
                                                    
                                                    // Assert that the value is returned unchanged (original behavior)
                                                    assertEquals(largeValue, result, 0.0);
                                                }

    @Test
                                        public void testDoubleHighPartWithLargeValues2() throws Exception {
                                            // Use reflection to access private TWO_POWER_53 field
                                            Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                            twoPower53Field.setAccessible(true);
                                            double power53 = (Double) twoPower53Field.get(null);
                                            
                                            // Use reflection to access private doubleHighPart method
                                            Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                            doubleHighPartMethod.setAccessible(true);
                                            
                                            // Test with value exactly at TWO_POWER_53 boundary
                                            double result = (Double) doubleHighPartMethod.invoke(null, power53);
                                            
                                            // In original code, this should have special handling
                                            // In mutated code, it will go through normal processing
                                            // We expect the result to be different from input for original code
                                            assertNotEquals("Value at TWO_POWER_53 boundary should be modified", 
                                                           power53, result, 0.0);
                                            
                                            // Test with value above TWO_POWER_53
                                            double abovePower53 = power53 * 1.1;
                                            result = (Double) doubleHighPartMethod.invoke(null, abovePower53);
                                            assertNotEquals("Value above TWO_POWER_53 should be modified",
                                                          abovePower53, result, 0.0);
                                            
                                            // Test with negative value at -TWO_POWER_53 boundary
                                            double negPower53 = -power53;
                                            result = (Double) doubleHighPartMethod.invoke(null, negPower53);
                                            assertNotEquals("Value at -TWO_POWER_53 boundary should be modified",
                                                          negPower53, result, 0.0);
                                        }

    @Test
                                        public void testPowNegativeBaseOddExponent() {
                                            // Test case to catch the pow(-x,y) -> pow(x,y) mutation
                                            double negativeValue = -2.0;
                                            int oddExponent = 3;
                                            
                                            // Original should return -8.0 (-2^3)
                                            // Mutant would return 8.0 (2^3)
                                            double result = FastMath.pow(negativeValue, oddExponent);
                                            
                                            // Assert the sign is preserved
                                            assertTrue("Result should be negative for negative base with odd exponent", 
                                                      result < 0);
                                            assertEquals(-8.0, result, 0.0001);
                                        }

    @Test
                                        public void testPowNegativeBaseEvenExponent() {
                                            // Additional test case for completeness
                                            double negativeValue = -2.0;
                                            int evenExponent = 4;
                                            
                                            // Both original and mutant should return 16.0 here
                                            double result = FastMath.pow(negativeValue, evenExponent);
                                            
                                            assertEquals(16.0, result, 0.0001);
                                        }

    @Test
                                    public void testPowNegativeBasePositiveExponent() {
                                        // Test case that would catch the pow(-x,y) -> pow(-x,-y) mutation
                                        double x = -2.0;
                                        double y = 3.0;
                                        
                                        // Original should return (-2)^3 = -8
                                        // Mutated would return (-2)^(-3) = -0.125
                                        double result = FastMath.pow(x, y);
                                        
                                        assertEquals(-8.0, result, 0.0001);
                                        
                                        // Additional test with even exponent to check sign
                                        double y2 = 4.0;
                                        double result2 = FastMath.pow(x, y2);
                                        assertEquals(16.0, result2, 0.0001);
                                    }

    @Test
                            public void testDoubleHighPart3() throws Exception {
                                // Test for the actual shown doubleHighPart method
                                double smallValue = Precision.SAFE_MIN / 2;
                                
                                // Get private doubleHighPart method via reflection
                                Method doubleHighPart = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                                doubleHighPart.setAccessible(true);
                                double resultSmall = (Double) doubleHighPart.invoke(null, smallValue);
                                assertEquals(smallValue, resultSmall, 0.0);
                                
                                double normalValue = 123.456;
                                long bits = Double.doubleToLongBits(normalValue);
                                
                                // Get private MASK_30BITS field via reflection
                                Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                                maskField.setAccessible(true);
                                long MASK_30BITS = maskField.getLong(null);
                                
                                long maskedBits = bits & MASK_30BITS;
                                double expected = Double.longBitsToDouble(maskedBits);
                                double resultNormal = (Double) doubleHighPart.invoke(null, normalValue);
                                assertEquals(expected, resultNormal, 0.0);
                            }

    @Test
                    public void testDoubleHighPart4() throws Exception {
                        // Get private MASK_30BITS field using reflection
                        Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                        maskField.setAccessible(true);
                        long MASK_30BITS = maskField.getLong(null);
                        
                        // Get private doubleHighPart method using reflection
                        Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                        doubleHighPartMethod.setAccessible(true);
                        
                        // Test with value within SAFE_MIN range
                        double smallValue = Precision.SAFE_MIN / 2;
                        assertEquals(smallValue, (double)doubleHighPartMethod.invoke(null, smallValue), 0.0);
                        
                        // Test with negative value within SAFE_MIN range
                        double smallNegativeValue = -Precision.SAFE_MIN / 2;
                        assertEquals(smallNegativeValue, (double)doubleHighPartMethod.invoke(null, smallNegativeValue), 0.0);
                        
                        // Test with value just above SAFE_MIN
                        double aboveSafeMin = Precision.SAFE_MIN * 1.1;
                        long expectedBits = Double.doubleToLongBits(aboveSafeMin) & MASK_30BITS;
                        double expectedValue = Double.longBitsToDouble(expectedBits);
                        assertEquals(expectedValue, (double)doubleHighPartMethod.invoke(null, aboveSafeMin), 0.0);
                        
                        // Test with value just below -SAFE_MIN
                        double belowNegativeSafeMin = -Precision.SAFE_MIN * 1.1;
                        expectedBits = Double.doubleToLongBits(belowNegativeSafeMin) & MASK_30BITS;
                        expectedValue = Double.longBitsToDouble(expectedBits);
                        assertEquals(expectedValue, (double)doubleHighPartMethod.invoke(null, belowNegativeSafeMin), 0.0);
                        
                        // Test with large positive value
                        double largeValue = 123456.789;
                        expectedBits = Double.doubleToLongBits(largeValue) & MASK_30BITS;
                        expectedValue = Double.longBitsToDouble(expectedBits);
                        assertEquals(expectedValue, (double)doubleHighPartMethod.invoke(null, largeValue), 0.0);
                        
                        // Test with large negative value
                        double largeNegativeValue = -987654.321;
                        expectedBits = Double.doubleToLongBits(largeNegativeValue) & MASK_30BITS;
                        expectedValue = Double.longBitsToDouble(expectedBits);
                        assertEquals(expectedValue, (double)doubleHighPartMethod.invoke(null, largeNegativeValue), 0.0);
                    }

    @Test
            public void testDoubleHighPartWithBitPatternAffectedByEvenOdd() throws Exception {
                // Get private MASK_30BITS field using reflection
                Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                maskField.setAccessible(true);
                long MASK_30BITS = (Long) maskField.get(null);
                
                // Get private doubleHighPart method using reflection
                Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                doubleHighPartMethod.setAccessible(true);
                
                // Test a value where the 30th bit is set (this would be affected by even/odd masking)
                double input = Double.longBitsToDouble(0x40000000L); // Value with 30th bit set
                
                // Expected behavior - should mask out lower 30 bits
                long expectedBits = Double.doubleToLongBits(input) & MASK_30BITS;
                double expected = Double.longBitsToDouble(expectedBits);
                
                // Actual result
                double actual = (Double) doubleHighPartMethod.invoke(null, input);
                
                // Verify the result matches the expected bit manipulation
                assertEquals("High part should properly mask out lower 30 bits", 
                            expected, actual, 0.0);
                
                // Additional verification - check that the bits match exactly
                assertEquals("Bit pattern should match expected masking",
                            expectedBits, Double.doubleToLongBits(actual));
            }

    @Test
            public void testDoubleHighPartWithSmallValue1() throws Exception {
                // Define SAFE_MIN as Double.MIN_VALUE (smallest positive nonzero value)
                double SAFE_MIN = Double.MIN_VALUE;
                
                // Test the SAFE_MIN boundary case
                double smallValue = SAFE_MIN / 2;
                
                // Get the private doubleHighPart method via reflection
                Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                doubleHighPartMethod.setAccessible(true);
                
                // Invoke the method
                double result = (Double) doubleHighPartMethod.invoke(null, smallValue);
                
                assertEquals("Small values should be returned unchanged",
                            smallValue, result, 0.0);
            }

    @Test
            public void testDoubleHighPartWithNormalValue() throws Exception {
                // Test a normal value that's not near the SAFE_MIN boundary
                double normalValue = 123.456;
                
                // Get private MASK_30BITS field using reflection
                Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
                maskField.setAccessible(true);
                long MASK_30BITS = maskField.getLong(null);
                
                // Calculate expected bits using the mask
                long expectedBits = Double.doubleToLongBits(normalValue) & MASK_30BITS;
                double expected = Double.longBitsToDouble(expectedBits);
                
                // Get private doubleHighPart method using reflection
                Method doubleHighPartMethod = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
                doubleHighPartMethod.setAccessible(true);
                double result = (Double) doubleHighPartMethod.invoke(null, normalValue);
                
                assertEquals("Normal values should have lower bits masked",
                            expected, result, 0.0);
            }

    @Test
    public void testDoubleHighPart5() throws Exception {
        // Get private members via reflection
        Method doubleHighPart = FastMath.class.getDeclaredMethod("doubleHighPart", double.class);
        doubleHighPart.setAccessible(true);
        
        Field maskField = FastMath.class.getDeclaredField("MASK_30BITS");
        maskField.setAccessible(true);
        long MASK_30BITS = maskField.getLong(null);
    
        // Test with very small numbers (should return unchanged)
        double smallPos = Precision.SAFE_MIN / 2;
        double smallNeg = -Precision.SAFE_MIN / 2;
        assertEquals(smallPos, (double)doubleHighPart.invoke(null, smallPos), 0.0);
        assertEquals(smallNeg, (double)doubleHighPart.invoke(null, smallNeg), 0.0);
        
        // Test with normal numbers
        double normal1 = 123.456789;
        long bits1 = Double.doubleToLongBits(normal1);
        long expectedBits1 = bits1 & MASK_30BITS;
        double expected1 = Double.longBitsToDouble(expectedBits1);
        assertEquals(expected1, (double)doubleHighPart.invoke(null, normal1), 0.0);
        
        // Test with even integer value (related to the comment mutation)
        double evenInt = 42.0;  // Even integer as double
        long bits2 = Double.doubleToLongBits(evenInt);
        long expectedBits2 = bits2 & MASK_30BITS;
        double expected2 = Double.longBitsToDouble(expectedBits2);
        assertEquals(expected2, (double)doubleHighPart.invoke(null, evenInt), 0.0);
        
        // Test with number where lower bits are significant
        double preciseValue = 1.0000000000000002; // Value where lower bits matter
        long bits3 = Double.doubleToLongBits(preciseValue);
        long expectedBits3 = bits3 & MASK_30BITS;
        double expected3 = Double.longBitsToDouble(expectedBits3);
        assertEquals(expected3, (double)doubleHighPart.invoke(null, preciseValue), 0.0);
        
        // Test boundary condition just outside SAFE_MIN
        double boundaryPos = Precision.SAFE_MIN * 1.1;
        long bits4 = Double.doubleToLongBits(boundaryPos);
        long expectedBits4 = bits4 & MASK_30BITS;
        double expected4 = Double.longBitsToDouble(expectedBits4);
        assertEquals(expected4, (double)doubleHighPart.invoke(null, boundaryPos), 0.0);
    }


}
