package gentest.org.apache.commons.math.stat.regression.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.regression.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.TDistribution;
 
public class SimpleRegressionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                public void testGetSumSquaredErrors_AllZeros() {
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    // Add data points where both x and y are zero
                                                                    regression.addData(0.0, 0.0);
                                                                    regression.addData(0.0, 0.0);
                                                                    
                                                                    assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_PositiveResult() throws Exception {
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.set(regression, 10.0);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.set(regression, 20.0);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.set(regression, 5.0);
                                                                    
                                                                    // Expected: 20 - (5*5)/10 = 20 - 2.5 = 17.5
                                                                    assertEquals(17.5, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_NegativeResultClampedToZero() throws Exception {
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.setDouble(regression, 10);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.setDouble(regression, 2);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.setDouble(regression, 5);
                                                                    
                                                                    // Expected: max(0, 2 - (5*5)/10) = max(0, -0.5) = 0
                                                                    assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_ExactBoundary() throws Exception {
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.setDouble(regression, 4.0);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.setDouble(regression, 9.0);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.setDouble(regression, 6.0);
                                                                    
                                                                    // Expected: 9 - (6*6)/4 = 9 - 9 = 0
                                                                    assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_WithLargeNumbers() throws Exception {
                                                                    // Create regression instance
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.set(regression, 1.0E20);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.set(regression, 2.0E20);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.set(regression, 1.0E20);
                                                                    
                                                                    // Expected: 2.0E20 - (1.0E20 * 1.0E20)/1.0E20 = 1.0E20
                                                                    assertEquals(1.0E20, regression.getSumSquaredErrors(), 1.0E10);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_WithVerySmallNumbers() throws Exception {
                                                                    // Create regression instance
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.set(regression, 1.0E-20);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.set(regression, 2.0E-20);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.set(regression, 1.0E-20);
                                                                    
                                                                    // Expected: 2.0E-20 - (1.0E-20 * 1.0E-20)/1.0E-20 = 1.0E-20
                                                                    assertEquals(1.0E-20, regression.getSumSquaredErrors(), 1.0E-25);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_SumXXZeroButOthersNonZero() throws Exception {
                                                                    // Create regression instance
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.set(regression, 0.0);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.set(regression, 10.0);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.set(regression, 5.0);
                                                                    
                                                                    // Should return max(0, sumYY - Infinity) which should be 0
                                                                    assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_NaNInput() throws Exception {
                                                                    // Create regression object
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.set(regression, Double.NaN);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.set(regression, 10.0);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.set(regression, 5.0);
                                                                    
                                                                    assertEquals(Double.NaN, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_PositiveInfinity() throws Exception {
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    sumXXField.setAccessible(true);
                                                                    sumXXField.set(regression, Double.POSITIVE_INFINITY);
                                                                    
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    sumYYField.setAccessible(true);
                                                                    sumYYField.set(regression, 10.0);
                                                                    
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    sumXYField.setAccessible(true);
                                                                    sumXYField.set(regression, 5.0);
                                                                    
                                                                    assertEquals(10.0, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testGetSumSquaredErrors_NegativeInfinity() throws Exception {
                                                                    // Create regression object
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    
                                                                    // Get private fields using reflection
                                                                    Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                                                                    Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                                                                    Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                                                                    
                                                                    // Make fields accessible
                                                                    sumXXField.setAccessible(true);
                                                                    sumYYField.setAccessible(true);
                                                                    sumXYField.setAccessible(true);
                                                                    
                                                                    // Set field values
                                                                    sumXXField.set(regression, Double.NEGATIVE_INFINITY);
                                                                    sumYYField.set(regression, 10.0);
                                                                    sumXYField.set(regression, 5.0);
                                                                    
                                                                    // Behavior is undefined but should clamp to 0
                                                                    assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
                                                                }

    @Test
                                                                public void testAddDataWithExactlyTwoPoints() {
                                                                    // Setup
                                                                    SimpleRegression regression = new SimpleRegression();
                                                                    double[][] data = {{1.0, 2.0}, {2.0, 3.0}}; // Exactly 2 data points
                                                                    
                                                                    // Execute
                                                                    regression.addData(data);
                                                                    
                                                                    // Verify behavior that should work with n=2
                                                                    // The mutant would skip these calculations when n<=2
                                                                    double slope = regression.getSlope();
                                                                    double intercept = regression.getIntercept();
                                                                    
                                                                    // Assert expected values (calculated manually for the test data)
                                                                    assertEquals(1.0, slope, 0.0001);
                                                                    assertEquals(1.0, intercept, 0.0001);
                                                                    
                                                                    // Verify other statistics that require n>=2
                                                                    double rSquare = regression.getRSquare();
                                                                    assertEquals(1.0, rSquare, 0.0001); // Perfect correlation in this test data
                                                                }

    @Test
                                                        public void testAddDataDetectsNLessThan2Mutant() throws Exception {
                                                            SimpleRegression regression = new SimpleRegression();
                                                            
                                                            // Use reflection to access private fields
                                                            Field xbarField = SimpleRegression.class.getDeclaredField("xbar");
                                                            Field ybarField = SimpleRegression.class.getDeclaredField("ybar");
                                                            xbarField.setAccessible(true);
                                                            ybarField.setAccessible(true);
                                                            
                                                            // First data point (n=0) - both original and mutant use initialization path
                                                            regression.addData(1.0, 2.0);
                                                            assertEquals(1.0, regression.getN());
                                                            assertEquals(1.0, (Double)xbarField.get(regression), 0.0001);
                                                            assertEquals(2.0, (Double)ybarField.get(regression), 0.0001);
                                                            
                                                            // Second data point (n=1) - critical test case
                                                            // Original: should use incremental update path
                                                            // Mutant: will use initialization path (n < 2)
                                                            regression.addData(3.0, 4.0);
                                                            
                                                            // Verify n was incremented correctly
                                                            assertEquals(2, regression.getN());
                                                            
                                                            // Verify means were updated correctly (should be (1+3)/2 and (2+4)/2)
                                                            assertEquals(2.0, (Double)xbarField.get(regression), 0.0001);
                                                            assertEquals(3.0, (Double)ybarField.get(regression), 0.0001);
                                                            
                                                            // Verify sum of squares calculations
                                                            // For original:
                                                            // dx = 3-1 = 2, dy = 4-2 = 2
                                                            // sumXX should be 0 + 2*2*(1)/(2) = 2.0
                                                            // sumYY should be 0 + 2*2*(1)/(2) = 2.0
                                                            // sumXY should be 0 + 2*2*(1)/(2) = 2.0
                                                            assertEquals(2.0, regression.getTotalSumSquares(), 0.0001);
                                                            assertEquals(2.0, regression.getRegressionSumSquares(), 0.0001);
                                                            assertEquals(2.0, regression.getSumSquaredErrors(), 0.0001);
                                                            
                                                            // For mutant:
                                                            // Would reinitialize xbar/ybar to 3.0/4.0
                                                            // And wouldn't update sumXX/sumYY/sumXY properly
                                                            // So these assertions would fail for the mutant
                                                        }

    @Test
                                                public void testAddDataDetectsMutatedInitializationCondition() {
                                                    SimpleRegression regression = new SimpleRegression();
                                                    
                                                    // Add first data point (n=0)
                                                    regression.addData(1.0, 2.0);
                                                    
                                                    // Add second data point (n=1)
                                                    regression.addData(3.0, 4.0);
                                                    
                                                    // Verify n count
                                                    assertEquals(2, regression.getN());
                                                    
                                                    // Verify slope and intercept instead of internal sums
                                                    // With points (1,2) and (3,4), slope should be 1.0 and intercept 1.0
                                                    assertEquals(1.0, regression.getSlope(), 1e-10);
                                                    assertEquals(1.0, regression.getIntercept(), 1e-10);
                                                    
                                                    // Verify RSquare should be 1.0 for perfect fit
                                                    assertEquals(1.0, regression.getRSquare(), 1e-10);
                                                }

    @Test
                                            public void testAddDataShouldNotCalculateStatsWithSinglePoint() {
                                                // Create test data - first with just one data point
                                                double[][] singlePointData = {{1.0, 2.0}};
                                                
                                                SimpleRegression regression = new SimpleRegression();
                                                regression.addData(singlePointData);
                                                
                                                // Verify basic accumulation
                                                assertEquals(1, regression.getN());
                                                // Verify sums through adding another point and checking the total
                                                regression.addData(1.0, 2.0); // Add same point again to verify sums
                                                
                                                // Instead of accessing private fields, we'll verify through predictions
                                                // With two identical points, the regression line should predict y=2.0 for x=1.0
                                                assertEquals(2.0, regression.predict(1.0), 0.0001);
                                                
                                                regression.clear(); // Clear and start over
                                                
                                                // Add original single point again
                                                regression.addData(singlePointData);
                                                
                                                // These statistics shouldn't be calculated with n < 2
                                                // The mutant would calculate them anyway
                                                assertEquals(0.0, regression.getSlope(), 0.0001);
                                                assertEquals(0.0, regression.getIntercept(), 0.0001);
                                                assertEquals(0.0, regression.getRSquare(), 0.0001);
                                                
                                                // Now add second point to make n >= 2
                                                double[][] secondPoint = {{3.0, 4.0}};
                                                regression.addData(secondPoint);
                                                
                                                // Now statistics should be calculated
                                                assertNotEquals(0.0, regression.getSlope(), 0.0001);
                                                assertNotEquals(0.0, regression.getIntercept(), 0.0001);
                                            }

    @Test
                                            public void testAddDataShouldCalculateStatsWithMultiplePoints() {
                                                // Create test data with multiple points
                                                double[][] multiPointData = {{1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0}};
                                                
                                                SimpleRegression regression = new SimpleRegression();
                                                regression.addData(multiPointData);
                                                
                                                // Verify basic accumulation
                                                assertEquals(3, regression.getN());
                                                
                                                // Calculate expected sums
                                                double expectedSumX = 0.0;
                                                double expectedSumY = 0.0;
                                                for (double[] point : multiPointData) {
                                                    expectedSumX += point[0];
                                                    expectedSumY += point[1];
                                                }
                                                
                                                // Verify sums by predicting values and checking consistency
                                                // Since we can't directly access sums, we'll verify the model is properly fitted
                                                for (double[] point : multiPointData) {
                                                    double predictedY = regression.predict(point[0]);
                                                    // The points are colinear, so prediction should match exactly
                                                    assertEquals(point[1], predictedY, 0.0001);
                                                }
                                                
                                                // Statistics should be properly calculated
                                                assertNotEquals(0.0, regression.getSlope(), 0.0001);
                                                assertNotEquals(0.0, regression.getIntercept(), 0.0001);
                                                assertTrue(regression.getRSquare() >= 0.0 && regression.getRSquare() <= 1.0);
                                            }

    @Test
                                            public void testGetSlopeWithInsufficientData() {
                                                SimpleRegression regression = new SimpleRegression();
                                                // Test with no data
                                                double slope = regression.getSlope();
                                                assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
                                                
                                                // Test with one data point
                                                regression.addData(1.0, 2.0);
                                                slope = regression.getSlope();
                                                assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
                                            }

    @Test
                                            public void testGetInterceptWithInsufficientData() {
                                                SimpleRegression regression = new SimpleRegression();
                                                // Test with no data
                                                double intercept = regression.getIntercept();
                                                assertTrue("Intercept should be NaN when n < 2", Double.isNaN(intercept));
                                                
                                                // Test with one data point
                                                regression.addData(1.0, 2.0);
                                                intercept = regression.getIntercept();
                                                assertTrue("Intercept should be NaN when n < 2", Double.isNaN(intercept));
                                            }

    @Test
                                            public void testGetSlopeWithInsufficientData1() {
                                                SimpleRegression regression = new SimpleRegression();
                                                
                                                // Test with no data
                                                double slope = regression.getSlope();
                                                assertTrue("Slope should be NaN with no data", Double.isNaN(slope));
                                                
                                                // Test with only one data point
                                                regression.addData(1.0, 2.0);
                                                slope = regression.getSlope();
                                                assertTrue("Slope should be NaN with only one data point", Double.isNaN(slope));
                                            }

    @Test
                                            public void testGetInterceptWithInsufficientData1() {
                                                SimpleRegression regression = new SimpleRegression();
                                                
                                                // Test with no data
                                                double intercept = regression.getIntercept();
                                                assertTrue("Intercept should be NaN with no data", Double.isNaN(intercept));
                                                
                                                // Test with only one data point
                                                regression.addData(1.0, 2.0);
                                                intercept = regression.getIntercept();
                                                assertTrue("Intercept should be NaN with only one data point", Double.isNaN(intercept));
                                            }

    @Test
                                            public void testGetRSquareWithInsufficientData() {
                                                SimpleRegression regression = new SimpleRegression();
                                                
                                                // Test with no data
                                                double rSquare = regression.getRSquare();
                                                assertTrue("RSquare should be NaN with no data", Double.isNaN(rSquare));
                                                
                                                // Test with only one data point
                                                regression.addData(1.0, 2.0);
                                                rSquare = regression.getRSquare();
                                                assertTrue("RSquare should be NaN with only one data point", Double.isNaN(rSquare));
                                            }

    @Test
                                        public void testGetSlopeWithInsufficientData2() {
                                            // Setup - create regression object with insufficient data
                                            SimpleRegression regression = new SimpleRegression();
                                            
                                            // Add only one data point (insufficient for slope calculation)
                                            regression.addData(1.0, 2.0);
                                            
                                            // Verify slope returns NaN (not 0.0)
                                            double slope = regression.getSlope();
                                            assertTrue("Slope should be NaN with insufficient data", 
                                                      Double.isNaN(slope));
                                            
                                            // Also verify intercept returns NaN
                                            double intercept = regression.getIntercept();
                                            assertTrue("Intercept should be NaN with insufficient data",
                                                      Double.isNaN(intercept));
                                        }

    @Test
                                        public void testGetSlopeWithNoData() {
                                            // Setup - create regression object with no data
                                            SimpleRegression regression = new SimpleRegression();
                                            
                                            // Verify slope returns NaN (not 0.0)
                                            double slope = regression.getSlope();
                                            assertTrue("Slope should be NaN with no data", 
                                                      Double.isNaN(slope));
                                            
                                            // Also verify intercept returns NaN
                                            double intercept = regression.getIntercept();
                                            assertTrue("Intercept should be NaN with no data",
                                                      Double.isNaN(intercept));
                                        }

    @Test
                                        public void testGetSlopeWithInsufficientDataShouldReturnNaN() {
                                            // Create regression object
                                            SimpleRegression regression = new SimpleRegression();
                                            
                                            // Add just one data point (insufficient for regression)
                                            regression.addData(1.0, 2.0);
                                            
                                            // Verify slope returns NaN with insufficient data
                                            assertTrue(Double.isNaN(regression.getSlope()));
                                            
                                            // Also test intercept
                                            assertTrue(Double.isNaN(regression.getIntercept()));
                                        }

    @Test
                                public void testGetSlopeWithNoDataShouldReturnNaN() throws MathException {
                                    // Create regression object with no data
                                    SimpleRegression regression = new SimpleRegression();
                                    
                                    // Verify slope returns NaN when no data is added
                                    // This should catch the mutant that returns 0.0 instead
                                    assertTrue(Double.isNaN(regression.getSlope()));
                                    
                                    // Also test other methods that should return NaN with no data
                                    assertTrue(Double.isNaN(regression.getIntercept()));
                                    assertTrue(Double.isNaN(regression.getRSquare()));
                                    assertTrue(Double.isNaN(regression.getSignificance()));
                                }

    @Test
                            public void testAddDataWithSumXXExactlyAtThreshold() {
                                SimpleRegression regression = new SimpleRegression();
                                
                                // First add data points to set up sumXX to be exactly 10 * Double.MIN_VALUE
                                // We need to carefully calculate values that will result in this exact sumXX
                                
                                // Add initial point to establish xbar and ybar
                                regression.addData(0.0, 0.0);
                                
                                // Calculate x value that will make sumXX exactly 10 * Double.MIN_VALUE
                                double targetSumXX = 10 * Double.MIN_VALUE;
                                double x = Math.sqrt(targetSumXX * 2.0); // Since n=1 at this point, sumXX = dx^2 * n/(n+1) = x^2 * 1/2
                                
                                // Add the calculated point
                                regression.addData(x, 0.0);
                                
                                // Verify sumXX is exactly at our threshold
                                assertEquals(10 * Double.MIN_VALUE, regression.getSumSquaredErrors(), 0.0);
                                
                                // The mutation would affect methods that check this condition, like getSlope()
                                // In original code, slope should be calculated normally
                                // In mutated code, it might return 0 due to the changed condition
                                
                                // Add another point to make sure slope would be non-zero if calculated
                                regression.addData(x, x);
                                
                                // Verify slope is calculated correctly (should be 1.0 in this case)
                                // This will fail if the mutant is present because it would return 0
                                assertEquals(1.0, regression.getSlope(), 1e-10);
                            }

    @Test
                                public void testSumXXBoundaryCondition() {
                                    // Create test data that will make sumXX exactly equal to 10*Double.MIN_VALUE
                                    SimpleRegression regression = new SimpleRegression();
                                    
                                    // Calculate x values that will make sumXX = 10*Double.MIN_VALUE
                                    // Since sumXX is sum of squares, we need sqrt(10*Double.MIN_VALUE) as the value
                                    double xValue = Math.sqrt(10 * Double.MIN_VALUE);
                                    
                                    // Add two data points: (x,0) and (-x,0) so sumX will be 0 but sumXX will be 2*x² = 10*Double.MIN_VALUE
                                    regression.addData(new double[][] {
                                        {xValue, 0},
                                        {-xValue, 0}
                                    });
                                    
                                    // In original code, sumXX == 10*Double.MIN_VALUE would NOT pass the condition
                                    // In mutated code, it would pass
                                    // This affects methods that depend on this check, like getSlope()
                                    
                                    // Verify slope calculation - original would treat this as non-zero variance case
                                    // while mutant would treat it as zero variance case
                                    double slope = regression.getSlope();
                                    
                                    // In original code, with sumXX exactly equal to threshold, we should get NaN slope
                                    // because it's treated as insufficient variation
                                    assertTrue("Slope should be NaN when sumXX equals threshold", 
                                              Double.isNaN(slope));
                                    
                                    // The mutant would return 0.0 here instead of NaN
                                }

    @Test
                            public void testAddDataWithVerySmallSumXX() {
                                // Create a regression instance
                                SimpleRegression regression = new SimpleRegression();
                                
                                // Add data points that will create a very small but non-zero sumXX
                                // We need sumXX to be between 10*Double.MIN_VALUE and 100*Double.MIN_VALUE
                                double tinyValue = 50 * Double.MIN_VALUE; // Right in the middle of our target range
                                
                                // First point sets the initial means
                                regression.addData(0.0, 0.0);
                                
                                // Second point carefully chosen to create the desired sumXX
                                // dx = tinyValue - 0 = tinyValue
                                // sumXX = dx*dx * n/(n+1) = tinyValue² * 1/2
                                regression.addData(tinyValue, 0.0);
                                
                                // Verify the slope calculation
                                // Original method would treat sumXX as effectively zero (special case)
                                // Mutated method would perform normal calculation
                                double slope = regression.getSlope();
                                
                                // In original, slope would be 0 (special case for tiny sumXX)
                                // In mutant, slope would be sumXY/sumXX = 0/(tinyValue²/2) = 0
                                // Wait, this shows both would return 0 - need a better test
                                
                                // Let's try with non-zero y values to make sumXY non-zero
                                regression.clear();
                                regression.addData(0.0, 0.0);
                                regression.addData(tinyValue, tinyValue); // Now sumXY should be same as sumXX
                                
                                // Original: would treat as zero, slope = 0
                                // Mutant: slope = sumXY/sumXX = 1
                                assertEquals("Slope should be 1 for y=x line", 1.0, regression.getSlope(), 1e-10);
                                
                                // Alternative approach: check getRSquare() which uses sumXX
                                // For original: would treat sumXX as 0, leading to NaN or other special value
                                // For mutant: would calculate normally
                                double rSquare = regression.getRSquare();
                                assertTrue("R² should be 1 for perfect correlation", Math.abs(rSquare - 1.0) < 1e-10);
                            }

    @Test
                            public void testSumXXThresholdForSlopeCalculation() {
                                // Create test data where sumXX is between 10*MIN_VALUE and 100*MIN_VALUE
                                double testValue = 50 * Double.MIN_VALUE; // Midway between thresholds
                                
                                SimpleRegression regression = new SimpleRegression();
                                
                                // Add data points that will result in sumXX = testValue
                                // For SimpleRegression, sumXX = sum((x - xbar)^2)
                                // We'll add two points that create this condition
                                double x1 = 0.0;
                                double x2 = Math.sqrt(testValue);
                                double y = 1.0; // y value doesn't affect sumXX
                                
                                regression.addData(x1, y);
                                regression.addData(x2, y);
                                
                                // Verify sumXX is in our target range
                                double sumXX = regression.getSumSquaredErrors(); // Or appropriate method to get sumXX
                                assertTrue(sumXX >= 10 * Double.MIN_VALUE);
                                assertTrue(sumXX <= 100 * Double.MIN_VALUE);
                                
                                // Test the behavior - slope should be treated as 0 in original
                                // but calculated in mutant
                                double slope = regression.getSlope();
                                
                                // Original would return 0 for this case, mutant would calculate a slope
                                assertEquals(0.0, slope, 0.0);
                            }

    @Test
                        public void testGetSlopeWithNoXVariationShouldReturnNaN() {
                            // Setup - create regression object and add data with no x variation
                            SimpleRegression regression = new SimpleRegression();
                            
                            // Add multiple points with identical x values
                            regression.addData(5.0, 10.0);
                            regression.addData(5.0, 12.0);
                            regression.addData(5.0, 8.0);
                            
                            // Test - getSlope() should return NaN when no x variation
                            double slope = regression.getSlope();
                            
                            // Verify - assert it's NaN (original behavior) not infinity (mutant)
                            assertTrue("Slope should be NaN when no x variation", 
                                      Double.isNaN(slope));
                            
                            // Additional verification that it's not infinity
                            assertFalse("Slope should not be infinity when no x variation",
                                       Double.isInfinite(slope));
                        }

    @Test
                        public void testGetRSquareWithNoXVariationShouldReturnNaN() {
                            // Setup - create regression object and add data with no x variation
                            SimpleRegression regression = new SimpleRegression();
                            
                            // Add multiple points with identical x values
                            regression.addData(3.0, 5.0);
                            regression.addData(3.0, 7.0);
                            regression.addData(3.0, 9.0);
                            
                            // Test - getRSquare() should return NaN when no x variation
                            double rSquare = regression.getRSquare();
                            
                            // Verify - assert it's NaN (original behavior) not infinity (mutant)
                            assertTrue("R-squared should be NaN when no x variation", 
                                      Double.isNaN(rSquare));
                            
                            // Additional verification that it's not infinity
                            assertFalse("R-squared should not be infinity when no x variation",
                                       Double.isInfinite(rSquare));
                        }

    @Test
                        public void testAddDataWithNoXVariationShouldReturnNaN() {
                            // Create test data with identical x values (no variation)
                            double[][] testData = {
                                {1.0, 2.0},
                                {1.0, 3.0},
                                {1.0, 4.0}
                            };
                            
                            SimpleRegression regression = new SimpleRegression();
                            regression.addData(testData);
                            
                            // When there's no x variation, slope-related methods should return NaN
                            double slope = regression.getSlope();
                            double intercept = regression.getIntercept();
                            
                            // The original would return NaN, mutant returns POSITIVE_INFINITY
                            assertTrue("Slope should be NaN when no x variation", 
                                Double.isNaN(slope));
                            assertTrue("Intercept should be NaN when no x variation",
                                Double.isNaN(intercept));
                                
                            // Also test other methods that might be affected
                            double rSquare = regression.getRSquare();
                            assertTrue("RSquare should be NaN when no x variation",
                                Double.isNaN(rSquare));
                        }

    @Test
                    public void testAddDataWithNoXVariationShouldReturnNaNForSlope() {
                        // Create regression object
                        SimpleRegression regression = new SimpleRegression();
                        
                        // Add data points with no variation in x (all x values same)
                        regression.addData(5.0, 10.0);
                        regression.addData(5.0, 12.0);
                        regression.addData(5.0, 8.0);
                        
                        // Verify that slope is NaN (no variation in x)
                        // Note: We're assuming getSlope() would be the method affected by the mutation
                        // If the mutation is in a different method, adjust accordingly
                        assertTrue("Slope should be NaN when there's no variation in x",
                                  Double.isNaN(regression.getSlope()));
                        
                        // Also verify intercept is NaN in this case
                        assertTrue("Intercept should be NaN when there's no variation in x",
                                  Double.isNaN(regression.getIntercept()));
                        
                        // Verify R-squared is NaN in this case
                        assertTrue("R-squared should be NaN when there's no variation in x",
                                  Double.isNaN(regression.getRSquare()));
                    }

    @Test
                    public void testAddDataWithXVariationShouldNotReturnNaN() {
                        // Create regression object
                        SimpleRegression regression = new SimpleRegression();
                        
                        // Add data points with variation in x
                        regression.addData(1.0, 2.0);
                        regression.addData(2.0, 4.0);
                        regression.addData(3.0, 6.0);
                        
                        // Verify that slope is not NaN when there is variation in x
                        assertFalse("Slope should not be NaN when there's variation in x",
                                   Double.isNaN(regression.getSlope()));
                        
                        // Verify intercept is not NaN
                        assertFalse("Intercept should not be NaN when there's variation in x",
                                   Double.isNaN(regression.getIntercept()));
                        
                        // Verify R-squared is not NaN
                        assertFalse("R-squared should not be NaN when there's variation in x",
                                   Double.isNaN(regression.getRSquare()));
                    }

    @Test
                    public void testAddDataWithXVariationShouldReturnValidSlope() {
                        // Create test data with variation in x to ensure normal case works
                        double[][] testData = {
                            {1.0, 2.0},
                            {2.0, 4.0},
                            {3.0, 6.0}
                        };
                        
                        SimpleRegression regression = new SimpleRegression();
                        regression.addData(testData);
                        
                        // With x variation, we should get a valid slope
                        assertEquals(2.0, regression.getSlope(), 0.0001);
                        assertFalse("Slope should not be NaN when x varies",
                                   Double.isNaN(regression.getSlope()));
                    }

    @Test
            public void testAddDataWithNoXVariationShouldReturnNaNForSlope1() {
                // Create test data with no variation in x (all x values same)
                double[][] testData = {
                    {5.0, 10.0},
                    {5.0, 12.0},
                    {5.0, 8.0}
                };
                
                SimpleRegression regression = new SimpleRegression();
                regression.addData(testData);
                
                // The slope should be NaN when there's no variation in x
                // This will catch the mutant that returns 0.0 instead
                assertTrue("Slope should be NaN when no x variation", 
                          Double.isNaN(regression.getSlope()));
                
                // Also test related methods that depend on this behavior
                assertTrue("R-square should be NaN when no x variation",
                          Double.isNaN(regression.getRSquare()));
                try {
                    assertTrue("Significance should be NaN when no x variation",
                              Double.isNaN(regression.getSignificance()));
                } catch (Exception e) {
                    fail("Unexpected exception thrown: " + e.getMessage());
                }
            }

    @Test
            public void testGetSlopeDetectsMultiplicationMutant() {
                // Setup
                SimpleRegression regression = new SimpleRegression();
                
                // Add data points that will create known sumXY and sumXX values
                // These points are chosen to create simple, predictable values:
                // (1,2), (2,4) - perfect linear relationship y = 2x
                regression.addData(1.0, 2.0);
                regression.addData(2.0, 4.0);
                
                // Calculate expected values manually:
                // sumXY = Σ(x-x̄)(y-ȳ) = (1-1.5)(2-3) + (2-1.5)(4-3) = 0.5 + 0.5 = 1.0
                // sumXX = Σ(x-x̄)² = (1-1.5)² + (2-1.5)² = 0.25 + 0.25 = 0.5
                // Expected slope = sumXY / sumXX = 1.0 / 0.5 = 2.0
                // Mutant would return sumXY * sumXX = 1.0 * 0.5 = 0.5
                
                double expectedSlope = 2.0;  // Correct calculation
                double mutantSlope = 0.5;    // What mutant would return
                
                // Test will fail if mutant exists (actual slope would be 0.5)
                assertEquals("Slope calculation should use division, not multiplication", 
                            expectedSlope, regression.getSlope(), 0.0001);
            }

    @Test
            public void testGetSlopeDetectsDivisionMutation() {
                // Setup - create regression object
                SimpleRegression regression = new SimpleRegression();
                
                // Add data points that form a perfect line y = 2x
                // These should produce sumXY = 20, sumXX = 10
                regression.addData(new double[][] {
                    {1.0, 2.0},
                    {2.0, 4.0},
                    {3.0, 6.0}
                });
                
                // Verify slope calculation
                // Expected: sumXY/sumXX = 20/10 = 2.0
                // Mutant would return sumXY*sumXX = 20*10 = 200.0
                double slope = regression.getSlope();
                
                // Assert with delta for floating point precision
                assertEquals("Slope calculation should be sumXY/sumXX", 
                             2.0, slope, 0.0001);
                
                // Additional verification that the value is indeed the ratio
                // This would fail for the mutant (200 != 0.5)
                regression.clear();
                regression.addData(new double[][] {
                    {4.0, 2.0},
                    {8.0, 4.0}
                });
                assertEquals("Slope should be 0.5 for this data",
                            0.5, regression.getSlope(), 0.0001);
            }

    @Test
    public void testGetSlopeDetectsMutant() {
        SimpleRegression regression = new SimpleRegression();
        
        // Add data points that will create known sumXX and sumXY values
        // Using points that form a clear linear relationship y = 2x
        regression.addData(1.0, 2.0);  // x=1, y=2
        regression.addData(2.0, 4.0);  // x=2, y=4
        regression.addData(3.0, 6.0);  // x=3, y=6
        
        // Calculate expected values manually:
        // For y = 2x, slope should be 2
        // sumXY = Σ(x-x̄)(y-ȳ) = 2
        // sumXX = Σ(x-x̄)² = 1
        // So slope = sumXY/sumXX = 2/1 = 2
        
        double actualSlope = regression.getSlope();
        double expectedSlope = 2.0;
        
        // This will fail if mutant is present (would return 1/2 = 0.5 instead)
        assertEquals("Slope calculation should be sumXY/sumXX", 
                    expectedSlope, actualSlope, 0.0001);
        
        // Additional check with different data to be thorough
        regression.clear();
        regression.addData(1.0, 3.0);  // x=1, y=3 (different slope)
        regression.addData(2.0, 5.0);  // x=2, y=5
        
        // Expected slope for these points is 2 (y = 2x + 1)
        assertEquals(2.0, regression.getSlope(), 0.0001);
    }

    @Test
        public void testGetSlopeDetectsMutant1() {
            // Create test data where sumXY ≠ sumXX
            double[][] data = {
                {1.0, 2.0},  // x=1, y=2
                {2.0, 3.0},  // x=2, y=3
                {3.0, 4.0}   // x=3, y=4
            };
            
            // Calculate expected values manually
            // sumXY = Σ(xy) = (1*2)+(2*3)+(3*4) = 2+6+12 = 20
            // sumXX = Σ(x²) = (1²)+(2²)+(3²) = 1+4+9 = 14
            double expectedSlope = 20.0 / 14.0;  // ~1.42857
            
            // Create and test the regression
            SimpleRegression regression = new SimpleRegression();
            regression.addData(data);
            
            // This will fail if the mutant (sumXX/sumXY) is present
            // because 14/20 = 0.7 ≠ 1.42857
            assertEquals(expectedSlope, regression.getSlope(), 0.0001);
            
            // Additional verification that we're testing the right thing
            // If the mutant exists, this assertion would pass
            double mutantSlope = 14.0 / 20.0;
            assertFalse("Mutant detected - division is inverted", 
                       Math.abs(mutantSlope - regression.getSlope()) < 0.0001);
        }

}
