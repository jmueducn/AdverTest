package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import org.apache.commons.math.util.MathUtils;
 
public class ProperFractionFormatTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                public void testParse_ValidFractionWithoutWholeNumber() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "3/4";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertEquals(3, result.getNumerator());
                                    assertEquals(4, result.getDenominator());
                                    assertEquals(source.length(), pos.getIndex());
                                }

    @Test
                                public void testParse_ValidFractionWithWholeNumber() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "1 3/4";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertEquals(7, result.getNumerator()); // 1*4 + 3 = 7
                                    assertEquals(4, result.getDenominator());
                                    assertEquals(source.length(), pos.getIndex());
                                }

    @Test
                                public void testParse_NegativeWholeNumberWithFraction() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "-2 1/2";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertEquals(-5, result.getNumerator()); // -(2*2 + 1) = -5
                                    assertEquals(2, result.getDenominator());
                                    assertEquals(source.length(), pos.getIndex());
                                }

    @Test
                                public void testParse_JustWholeNumber() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "5";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertEquals(5, result.getNumerator());
                                    assertEquals(1, result.getDenominator());
                                    assertEquals(source.length(), pos.getIndex());
                                }

    @Test
                                public void testParse_InvalidFormatMissingDenominator() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "3/";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertNull(result);
                                    assertEquals(0, pos.getIndex());
                                    assertTrue(pos.getErrorIndex() > 0);
                                }

    @Test
                                public void testParse_InvalidFormatNegativeNumerator() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "1 -3/4";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertNull(result);
                                    assertEquals(0, pos.getIndex());
                                }

    @Test
                                public void testParse_InvalidFormatNegativeDenominator() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "1 3/-4";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertNull(result);
                                    assertEquals(0, pos.getIndex());
                                }

    @Test
                                public void testParse_InvalidCharacterInsteadOfSlash() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "3x4";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertNull(result);
                                    assertEquals(0, pos.getIndex());
                                    assertEquals(1, pos.getErrorIndex());
                                }

    @Test
                                public void testParse_WithWhitespace() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "  2   1  /  3  ";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertEquals(7, result.getNumerator()); // 2*3 + 1 = 7
                                    assertEquals(3, result.getDenominator());
                                    assertEquals(source.length(), pos.getIndex());
                                }

    @Test
                                public void testParse_EmptyString() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "";
                                    
                                    Fraction result = format.parse(source, pos);
                                    
                                    assertNull(result);
                                    assertEquals(0, pos.getIndex());
                                }

    @Test
                                public void testParse_NullSource() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    ParsePosition pos = new ParsePosition(0);
                                    
                                    thrown.expect(NullPointerException.class);
                                    format.parse(null, pos);
                                }

    @Test
                                public void testParse_NullPosition() {
                                    ProperFractionFormat format = new ProperFractionFormat();
                                    String source = "1/2";
                                    
                                    thrown.expect(NullPointerException.class);
                                    format.parse(source, null);
                                }

    @Test
                                public void testParse_WithMockedNumberFormats() {
                                    // Setup mocks
                                    NumberFormat wholeFormat = mock(NumberFormat.class);
                                    NumberFormat numeratorFormat = mock(NumberFormat.class);
                                    NumberFormat denominatorFormat = mock(NumberFormat.class);
                                    
                                    ParsePosition pos = new ParsePosition(0);
                                    String source = "1 2/3";
                                    
                                    // Mock behaviors
                                    when(wholeFormat.parse(source, pos)).thenReturn(1);
                                    when(numeratorFormat.parse(source, pos)).thenReturn(2);
                                    when(denominatorFormat.parse(source, pos)).thenReturn(3);
                                    
                                    ProperFractionFormat format = new ProperFractionFormat(wholeFormat, numeratorFormat, denominatorFormat);
                                    Fraction result = format.parse(source, pos);
                                    
                                    // Verify interactions
                                    verify(wholeFormat).parse(source, pos);
                                    verify(numeratorFormat).parse(source, pos);
                                    verify(denominatorFormat).parse(source, pos);
                                    
                                    assertEquals(5, result.getNumerator()); // 1*3 + 2 = 5
                                    assertEquals(3, result.getDenominator());
                                }

    @Test(expected = ArithmeticException.class)
                            public void testFormatWithZeroDenominatorShouldThrowException() {
                                // Setup
                                ProperFractionFormat formatter = new ProperFractionFormat();
                                Fraction fraction = new Fraction(1, 0); // This should throw ArithmeticException in original
                                StringBuffer buffer = new StringBuffer();
                                FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                                
                                // Exercise
                                formatter.format(fraction, buffer, pos);
                                
                                // If we get here, the mutant survived (it didn't throw exception for zero denominator)
                            }

    @Test
                            public void testFormatWithNegativeDenominator() {
                                // Setup
                                ProperFractionFormat formatter = new ProperFractionFormat();
                                Fraction fraction = new Fraction(3, -4); // Negative denominator
                                StringBuffer buffer = new StringBuffer();
                                FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                                String expected = "3 / -4"; // Expected format
                                
                                // Exercise
                                StringBuffer result = formatter.format(fraction, buffer, pos);
                                
                                // Verify
                                assertEquals("Format with negative denominator", expected, result.toString());
                            }

    @Test
                            public void testFormatWithPositiveDenominator() {
                                // Setup
                                ProperFractionFormat formatter = new ProperFractionFormat();
                                Fraction fraction = new Fraction(1, 2); // Positive denominator
                                StringBuffer buffer = new StringBuffer();
                                FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                                String expected = "1 / 2"; // Expected format
                                
                                // Exercise
                                StringBuffer result = formatter.format(fraction, buffer, pos);
                                
                                // Verify
                                assertEquals("Format with positive denominator", expected, result.toString());
                            }

    @Test
                        public void testFormatMaintainsFieldPositionIndex() {
                            // Setup
                            ProperFractionFormat formatter = new ProperFractionFormat();
                            Fraction fraction = new Fraction(7, 4); // 1 3/4
                            StringBuffer toAppendTo = new StringBuffer();
                            FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                            pos.setBeginIndex(5);  // Set initial index
                            pos.setEndIndex(10);   // Set initial index
                            
                            // Expected initial index values
                            int expectedBeginIndex = 5;
                            int expectedEndIndex = 10;
                            
                            // Execute
                            formatter.format(fraction, toAppendTo, pos);
                            
                            // Verify
                            assertEquals("FieldPosition beginIndex should maintain its value", 
                                        expectedBeginIndex, pos.getBeginIndex());
                            assertEquals("FieldPosition endIndex should maintain its value",
                                        expectedEndIndex, pos.getEndIndex());
                            
                            // Also verify the formatted output is correct
                            String expectedFormat = "1 3 / 4";
                            assertEquals(expectedFormat, toAppendTo.toString());
                        }

    @Test
                public void testFormatPreservesFieldPositionIndexes() {
                    // Setup
                    ProperFractionFormat formatter = new ProperFractionFormat();
                    Fraction fraction = new Fraction(3, 2); // 1 1/2
                    StringBuffer toAppendTo = new StringBuffer();
                    FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                    pos.setBeginIndex(5);
                    pos.setEndIndex(10);
                    
                    // Execute
                    StringBuffer result = formatter.format(fraction, toAppendTo, pos);
                    
                    // Verify output formatting
                    assertEquals("1 1 / 2", result.toString());
                    
                    // Critical assertions to catch the mutant
                    // Original should preserve the initial indexes, mutant will set them to 0
                    assertNotEquals(0, pos.getBeginIndex());
                    assertNotEquals(0, pos.getEndIndex());
                    assertEquals(5, pos.getBeginIndex());
                    assertEquals(10, pos.getEndIndex());
                    
                    // Additional verification that formatting actually occurred
                    assertTrue(pos.getFieldAttribute() instanceof NumberFormat.Field);
                }

    @Test
                public void testFormatFieldPositionIndices() {
                    // Setup
                    ProperFractionFormat formatter = new ProperFractionFormat();
                    Fraction fraction = new Fraction(7, 4); // 1 3/4
                    StringBuffer buffer = new StringBuffer();
                    FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                    
                    // Initial indices should be 0
                    pos.setBeginIndex(0);
                    pos.setEndIndex(0);
                    
                    // Execute
                    formatter.format(fraction, buffer, pos);
                    
                    // Verify FieldPosition indices were properly reset
                    // This will catch the mutant where indices were set to initialIndex + 1
                    assertEquals("Begin index should be properly reset", 0, pos.getBeginIndex());
                    assertEquals("End index should be properly reset", 0, pos.getEndIndex());
                    
                    // Additional verification that formatting itself worked
                    assertTrue("Formatted string should contain whole number", buffer.toString().contains("1"));
                    assertTrue("Formatted string should contain fraction", buffer.toString().contains("3/4"));
                }

    @Test
        public void testFormatAndParseConsistency() throws Exception {
            // Setup
            ProperFractionFormat formatter = new ProperFractionFormat();
            Fraction originalFraction = new Fraction(3, 2); // 1 1/2 when formatted
            StringBuffer buffer = new StringBuffer();
            FieldPosition pos = new FieldPosition(0);
            
            // Format the fraction
            StringBuffer formatted = formatter.format(originalFraction, buffer, pos);
            
            // Parse it back
            ParsePosition parsePos = new ParsePosition(0);
            Fraction parsedFraction = formatter.parse(formatted.toString(), parsePos);
            
            // Verify parsed fraction matches original
            assertEquals("Numerator should match original", 
                         originalFraction.getNumerator(), 
                         parsedFraction.getNumerator());
            assertEquals("Denominator should match original", 
                         originalFraction.getDenominator(), 
                         parsedFraction.getDenominator());
            
            // Also verify the whole formatting logic
            assertEquals("Formatted string should be correct", 
                         "1 1 / 2", 
                         formatted.toString());
        }

    @Test
    public void testFormatWholeNumberDetectsMutant() {
        // Setup
        ProperFractionFormat formatter = new ProperFractionFormat();
        StringBuffer toAppendTo = new StringBuffer();
        FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
        
        // Create a fraction that should format as a whole number (4/1)
        Fraction fraction = new Fraction(4, 1);
        
        // Execute
        StringBuffer result = formatter.format(fraction, toAppendTo, pos);
        
        // Verify - original should produce "4", mutant would produce "4 / 2"
        assertEquals("Whole number formatting incorrect", "4", result.toString());
        
        // Additional verification of position markers
        assertEquals("Begin position incorrect", 0, pos.getBeginIndex());
        assertEquals("End position incorrect", 0, pos.getEndIndex());
    }

}
