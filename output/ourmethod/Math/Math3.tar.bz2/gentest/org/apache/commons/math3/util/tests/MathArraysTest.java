package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class MathArraysTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testLinearCombination_TypicalCase() {
                                                    double[] a = {1.0, 2.0, 3.0};
                                                    double[] b = {4.0, 5.0, 6.0};
                                                    double expected = 1.0*4.0 + 2.0*5.0 + 3.0*6.0; // 4 + 10 + 18 = 32
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombination_SingleElement() {
                                                    double[] a = {2.5};
                                                    double[] b = {3.5};
                                                    double expected = 2.5 * 3.5; // 8.75
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 0.0);
                                                }

    @Test
                                                public void testLinearCombination_DifferentLengths() {
                                                    double[] a = {1.0, 2.0};
                                                    double[] b = {1.0};
                                                    
                                                    thrown.expect(DimensionMismatchException.class);
                                                    thrown.expectMessage("2 != 1");
                                                    MathArrays.linearCombination(a, b);
                                                }

    @Test
                                                public void testLinearCombination_EmptyArrays() {
                                                    double[] a = {};
                                                    double[] b = {};
                                                    
                                                    thrown.expect(DimensionMismatchException.class);
                                                    thrown.expectMessage("0 != 0"); // Actually both are 0 but the method checks a.length != b.length
                                                    MathArrays.linearCombination(a, b);
                                                }

    @Test
                                                public void testLinearCombination_VerySmallValues() {
                                                    double[] a = {1e-300, 2e-300};
                                                    double[] b = {3e-300, 4e-300};
                                                    double expected = 1e-300*3e-300 + 2e-300*4e-300;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-315);
                                                }

    @Test
                                                public void testLinearCombination_VeryLargeValues() {
                                                    double[] a = {1e300, 2e300};
                                                    double[] b = {3e300, 4e300};
                                                    double expected = 1e300*3e300 + 2e300*4e300;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e285); // Larger delta due to floating point precision limits
                                                }

    @Test
                                                public void testLinearCombination_WithNaN() {
                                                    double[] a = {1.0, Double.NaN, 3.0};
                                                    double[] b = {4.0, 5.0, 6.0};
                                                    double expected = 1.0*4.0 + Double.NaN*5.0 + 3.0*6.0;
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertTrue(Double.isNaN(result));
                                                }

    @Test
                                                public void testLinearCombination_WithInfiniteValues() {
                                                    double[] a = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                    double[] b = {4.0, 5.0, 6.0};
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertTrue(Double.isInfinite(result));
                                                }

    @Test
                                                public void testLinearCombination_OverflowProtection() {
                                                    double[] a = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                    double[] b = {2.0, -2.0};
                                                    // The exact result should be 0, but naive implementation would overflow
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(0.0, result, 0.0);
                                                }

    @Test
                                                public void testLinearCombination_UnderflowProtection() {
                                                    double[] a = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                    double[] b = {2.0, -2.0};
                                                    // The exact result should be 0
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(0.0, result, 0.0);
                                                }

    @Test
                                                public void testLinearCombination_AlternatingSigns() {
                                                    double[] a = {1.0, -2.0, 3.0, -4.0};
                                                    double[] b = {5.0, -6.0, 7.0, -8.0};
                                                    double expected = 1.0*5.0 + -2.0*-6.0 + 3.0*7.0 + -4.0*-8.0; // 5 + 12 + 21 + 32 = 70
                                                    double result = MathArrays.linearCombination(a, b);
                                                    assertEquals(expected, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombination_TypicalValues() {
                                                    // Test with typical positive values
                                                    double result = MathArrays.linearCombination(2.0, 3.0, 4.0, 5.0);
                                                    assertEquals(2.0 * 3.0 + 4.0 * 5.0, result, 1e-15);
                                            
                                                    // Test with mixed positive and negative values
                                                    result = MathArrays.linearCombination(-2.0, 3.0, 4.0, -5.0);
                                                    assertEquals(-2.0 * 3.0 + 4.0 * -5.0, result, 1e-15);
                                            
                                                    // Test with small values
                                                    result = MathArrays.linearCombination(1e-10, 2e-10, 3e-10, 4e-10);
                                                    assertEquals(1e-10 * 2e-10 + 3e-10 * 4e-10, result, 1e-25);
                                                }

    @Test
                                                public void testLinearCombination_ExtremeValues() {
                                                    // Test with very large values
                                                    double result = MathArrays.linearCombination(Double.MAX_VALUE, 1.0, Double.MAX_VALUE, -1.0);
                                                    assertEquals(0.0, result, 1e-15);
                                            
                                                    // Test with very small values
                                                    result = MathArrays.linearCombination(Double.MIN_VALUE, 1.0, Double.MIN_VALUE, 1.0);
                                                    assertEquals(2 * Double.MIN_VALUE, result, 0.0);
                                            
                                                    // Test with one very large and one very small value
                                                    result = MathArrays.linearCombination(Double.MAX_VALUE, Double.MIN_VALUE, 1.0, 1.0);
                                                    assertEquals(Double.MAX_VALUE * Double.MIN_VALUE + 1.0, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombination_SpecialCases() {
                                                    // Test with zero values
                                                    double result = MathArrays.linearCombination(0.0, 3.0, 4.0, 0.0);
                                                    assertEquals(0.0, result, 0.0);
                                            
                                                    // Test with one zero coefficient
                                                    result = MathArrays.linearCombination(0.0, 3.0, 4.0, 5.0);
                                                    assertEquals(4.0 * 5.0, result, 1e-15);
                                            
                                                    // Test with NaN values (should fall back to simple multiplication)
                                                    result = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0);
                                                    assertTrue(Double.isNaN(result));
                                            
                                                    // Test with infinite values
                                                    result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 2.0, 3.0);
                                                    assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                            
                                                    result = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY, 2.0, 3.0);
                                                    assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                            
                                                    result = MathArrays.linearCombination(1.0, 2.0, Double.NEGATIVE_INFINITY, 3.0);
                                                    assertEquals(Double.NEGATIVE_INFINITY, result, 0.0);
                                                }

    @Test
                                                public void testLinearCombination_CancellationEffects() {
                                                    // Test cases where cancellation occurs in the addition
                                                    double a = 1.0 + 1e-16;
                                                    double b = 1.0 - 1e-16;
                                                    
                                                    // This would lose precision with standard floating-point arithmetic
                                                    double result = MathArrays.linearCombination(a, 1.0, b, -1.0);
                                                    double expected = a * 1.0 + b * -1.0;
                                                    assertEquals(expected, result, 1e-20);
                                                    
                                                    // More extreme cancellation case
                                                    result = MathArrays.linearCombination(1.0e20, 1.0, 1.0, -1.0e20);
                                                    assertEquals(0.0, result, 1e-15);
                                                }

    @Test
                                                public void testLinearCombination_Accuracy() {
                                                    // Test the accuracy compared to naive implementation
                                                    double a1 = 1.0000000000000001;
                                                    double b1 = 1.0000000000000002;
                                                    double a2 = 1.0000000000000003;
                                                    double b2 = 1.0000000000000004;
                                                    
                                                    double naive = a1 * b1 + a2 * b2;
                                                    double precise = MathArrays.linearCombination(a1, b1, a2, b2);
                                                    
                                                    // The precise version should be more accurate
                                                    assertNotEquals(naive, precise, 0.0);
                                                    assertEquals(2.0000000000000007, precise, 1e-16);
                                                }

    @Test
                                                public void testLinearCombination_TypicalValues1() {
                                                    // Simple case with small integers
                                                    double result1 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0);
                                                    assertEquals(44.0, result1, 1e-15); // 1*2 + 3*4 + 5*6 = 2 + 12 + 30 = 44
                                                    
                                                    // Case with decimal values
                                                    double result2 = MathArrays.linearCombination(0.1, 0.2, 0.3, 0.4, 0.5, 0.6);
                                                    assertEquals(0.44, result2, 1e-15); // 0.02 + 0.12 + 0.30 = 0.44
                                                    
                                                    // Case with mixed signs
                                                    double result3 = MathArrays.linearCombination(1.0, -2.0, -3.0, 4.0, 5.0, -6.0);
                                                    assertEquals(-44.0, result3, 1e-15); // -2 + (-12) + (-30) = -44
                                                }

    @Test
                                                public void testLinearCombination_ExtremeValues1() {
                                                    // Large numbers
                                                    double large = 1e100;
                                                    double result1 = MathArrays.linearCombination(large, large, large, large, large, large);
                                                    assertEquals(3 * large * large, result1, 1e85); // Allow some tolerance for floating point
                                                    
                                                    // Small numbers
                                                    double small = 1e-100;
                                                    double result2 = MathArrays.linearCombination(small, small, small, small, small, small);
                                                    assertEquals(3 * small * small, result2, 1e-215); // Very small tolerance
                                                    
                                                    // Mixed large and small numbers
                                                    double result3 = MathArrays.linearCombination(large, small, small, large, 1.0, 1.0);
                                                    assertEquals(2.0 + 2 * large * small, result3, 1e-15);
                                                }

    @Test
                                                public void testLinearCombination_SpecialValues() {
                                                    // Zero values
                                                    double result1 = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                                    assertEquals(0.0, result1, 0.0);
                                                    
                                                    // NaN handling
                                                    double result2 = MathArrays.linearCombination(Double.NaN, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                    assertTrue(Double.isNaN(result2));
                                                    
                                                    // Infinity handling
                                                    double result3 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                                 1.0, 1.0, 1.0, 1.0);
                                                    assertTrue(Double.isInfinite(result3));
                                                    
                                                    // Mixed infinity
                                                    double result4 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                                Double.NEGATIVE_INFINITY, 1.0,
                                                                                                1.0, 1.0);
                                                    assertTrue(Double.isNaN(result4));
                                                }

    @Test
                                                public void testLinearCombination_CancellationCases() {
                                                    // Case where terms nearly cancel each other
                                                    double a = 1e18;
                                                    double b = 1e-18;
                                                    double result1 = MathArrays.linearCombination(a, b, -a, b, 1.0, 1.0);
                                                    assertEquals(1.0, result1, 1e-15); // Should be exactly 1.0
                                                    
                                                    // Another cancellation case
                                                    double x = 1e16;
                                                    double result2 = MathArrays.linearCombination(x+1, x-1, x-1, x+1, 1.0, 1.0);
                                                    double expected = (x*x - 1) + (x*x - 1) + 1.0;
                                                    assertEquals(expected, result2, 1e-15);
                                                }

    @Test
                                                public void testLinearCombination_OverflowCases() {
                                                    double max = Double.MAX_VALUE;
                                                    double result = MathArrays.linearCombination(max, max, max, max, max, max);
                                                    assertTrue(Double.isInfinite(result));
                                                    
                                                    double halfMax = Double.MAX_VALUE / 2;
                                                    double result2 = MathArrays.linearCombination(halfMax, halfMax, halfMax, halfMax, 0.0, 0.0);
                                                    assertEquals(2 * halfMax * halfMax, result2, 1e292); // Should not overflow
                                                }

    @Test
                                                public void testLinearCombination_Precision() {
                                                    // This case would lose precision with naive implementation
                                                    double a = 1.000000000000001;
                                                    double b = 1.000000000000002;
                                                    double c = 1.000000000000003;
                                                    
                                                    double naive = a*a + b*b + c*c;
                                                    double precise = MathArrays.linearCombination(a, a, b, b, c, c);
                                                    
                                                    // The precise version should be more accurate
                                                    double exact = 3.000000000000006000000000000014;
                                                    assertTrue(Math.abs(precise - exact) < Math.abs(naive - exact));
                                                }

    @Test
                                                public void testLinearCombination_WithNaNValues() {
                                                    // Test with NaN inputs - should fall back to naive implementation
                                                    double result = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                                    assertTrue(Double.isNaN(result));
                                                    
                                                    result = MathArrays.linearCombination(1.0, Double.NaN, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                                    assertTrue(Double.isNaN(result));
                                                }

    @Test
                                        public void testLinearCombination_TypicalValues2() {
                                            // Define epsilon for floating point comparisons
                                            final double EPSILON = 1e-15;
                                            
                                            // Test with typical positive values
                                            double result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);
                                            assertEquals(1.0*2.0 + 3.0*4.0 + 5.0*6.0 + 7.0*8.0, result, EPSILON);
                                            
                                            // Test with mixed positive and negative values
                                            result = MathArrays.linearCombination(1.5, -2.5, 3.5, -4.5, 5.5, -6.5, 7.5, -8.5);
                                            assertEquals(1.5*-2.5 + 3.5*-4.5 + 5.5*-6.5 + 7.5*-8.5, result, EPSILON);
                                        }

    @Test
                                        public void testLinearCombination_ExtremeValues2() {
                                            // Define epsilon for floating point comparisons
                                            final double EPSILON = 1.0e-15;
                                            
                                            // Test with very large values
                                            double large = 1e100;
                                            double result = MathArrays.linearCombination(large, large, large, large, large, large, large, large);
                                            assertEquals(4 * large * large, result, large * EPSILON);
                                            
                                            // Test with very small values
                                            double small = 1e-100;
                                            result = MathArrays.linearCombination(small, small, small, small, small, small, small, small);
                                            assertEquals(4 * small * small, result, EPSILON);
                                        }

    @Test
                                        public void testLinearCombination_CancellationEffects1() {
                                            // Define epsilon for floating point comparisons
                                            final double EPSILON = 1e-20;
                                            
                                            // Test cases where cancellation occurs to verify the high-precision algorithm works
                                            double a = 1e18;
                                            double b = 1e-18;
                                            
                                            // This would suffer from catastrophic cancellation in naive implementation
                                            double result = MathArrays.linearCombination(a, b, -a, b, a, b, -a, b);
                                            assertEquals(0.0, result, EPSILON);
                                            
                                            // Another cancellation case
                                            result = MathArrays.linearCombination(1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
                                            assertEquals(0.0, result, EPSILON);
                                        }

    @Test
                                        public void testLinearCombination_WithZeroValues() {
                                            final double EPSILON = 1e-15; // Define epsilon for double comparison
                                            
                                            // Test with some zero coefficients
                                            double result = MathArrays.linearCombination(0.0, 5.0, 3.0, 0.0, 0.0, 6.0, 7.0, 0.0);
                                            assertEquals(0.0*5.0 + 3.0*0.0 + 0.0*6.0 + 7.0*0.0, result, EPSILON);
                                            
                                            // All zeros
                                            result = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                            assertEquals(0.0, result, EPSILON);
                                        }

    @Test
                                        public void testLinearCombination_WithInfiniteValues1() {
                                            // Define EPSILON constant for double comparison
                                            final double EPSILON = 1e-15;
                                            
                                            // Test with infinite values - should fall back to naive implementation
                                            double result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                            assertEquals(Double.POSITIVE_INFINITY, result, EPSILON);
                                            
                                            result = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                            assertEquals(Double.POSITIVE_INFINITY, result, EPSILON);
                                            
                                            result = MathArrays.linearCombination(Double.NEGATIVE_INFINITY, 1.0, Double.POSITIVE_INFINITY, 1.0, 1.0, 1.0, 1.0, 1.0);
                                            assertTrue(Double.isNaN(result));
                                        }

    @Test
                                        public void testLinearCombination_Accuracy1() {
                                            // Test accuracy against known values
                                            // This is the example where naive implementation would fail due to cancellation
                                            double a = 1.0;
                                            double b = 1.0;
                                            double c = 1.0;
                                            double d = 1.0;
                                            double e = 1.0 + 1e-16;
                                            double f = 1.0 - 1e-16;
                                            
                                            // Define epsilon for floating point comparison
                                            final double EPSILON = 1e-20;
                                            
                                            // Naive implementation would return 0.0 due to cancellation
                                            double result = MathArrays.linearCombination(a, e, -a, f, b, e, -b, f);
                                            double expected = a*e - a*f + b*e - b*f;
                                            assertEquals(expected, result, EPSILON);
                                        }


}
