package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                public void testGcd_ZeroCases() {
                                                                                                                                                                                    // Test when one or both parameters are zero
                                                                                                                                                                                    assertEquals(5, MathUtils.gcd(0, 5));
                                                                                                                                                                                    assertEquals(7, MathUtils.gcd(7, 0));
                                                                                                                                                                                    assertEquals(0, MathUtils.gcd(0, 0));
                                                                                                                                                                                    assertEquals(10, MathUtils.gcd(-10, 0));
                                                                                                                                                                                    assertEquals(15, MathUtils.gcd(0, -15));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGcd_PositiveNumbers() {
                                                                                                                                                                                    // Test with positive numbers
                                                                                                                                                                                    assertEquals(1, MathUtils.gcd(1, 1));
                                                                                                                                                                                    assertEquals(2, MathUtils.gcd(2, 4));
                                                                                                                                                                                    assertEquals(6, MathUtils.gcd(12, 18));
                                                                                                                                                                                    assertEquals(14, MathUtils.gcd(42, 56));
                                                                                                                                                                                    assertEquals(1, MathUtils.gcd(13, 17)); // coprime numbers
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGcd_NegativeNumbers() {
                                                                                                                                                                                    // Test with negative numbers
                                                                                                                                                                                    assertEquals(3, MathUtils.gcd(-3, -9));
                                                                                                                                                                                    assertEquals(5, MathUtils.gcd(-10, 15));
                                                                                                                                                                                    assertEquals(7, MathUtils.gcd(21, -28));
                                                                                                                                                                                    assertEquals(11, MathUtils.gcd(-121, -44));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGcd_EqualNumbers() {
                                                                                                                                                                                    // Test when both numbers are equal
                                                                                                                                                                                    assertEquals(5, MathUtils.gcd(5, 5));
                                                                                                                                                                                    assertEquals(10, MathUtils.gcd(-10, -10));
                                                                                                                                                                                    assertEquals(1, MathUtils.gcd(1, 1));
                                                                                                                                                                                    assertEquals(Integer.MAX_VALUE, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGcd_LargeNumbers() {
                                                                                                                                                                                    // Test with large numbers
                                                                                                                                                                                    assertEquals(1000000, MathUtils.gcd(1000000, 1000000));
                                                                                                                                                                                    assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE - 1));
                                                                                                                                                                                    assertEquals(2, MathUtils.gcd(Integer.MIN_VALUE + 2, -2));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGcd_EdgeCases() {
                                                                                                                                                                                    // Test edge cases
                                                                                                                                                                                    assertEquals(1, MathUtils.gcd(1, Integer.MAX_VALUE));
                                                                                                                                                                                    assertEquals(1, MathUtils.gcd(1, Integer.MIN_VALUE + 1));
                                                                                                                                                                                    assertEquals(2, MathUtils.gcd(Integer.MIN_VALUE + 2, Integer.MAX_VALUE - 1));
                                                                                                                                                                                    assertEquals(1073741824, MathUtils.gcd(-1073741824, 0)); // 2^30
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGcd_PowersOfTwo() {
                                                                                                                                                                                    // Test with numbers that are powers of two
                                                                                                                                                                                    assertEquals(8, MathUtils.gcd(16, 24));
                                                                                                                                                                                    assertEquals(16, MathUtils.gcd(32, 48));
                                                                                                                                                                                    assertEquals(32, MathUtils.gcd(64, 96));
                                                                                                                                                                                    assertEquals(64, MathUtils.gcd(128, 192));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGcd_OneIsMultipleOfOther() {
                                                                                                                                                                                    // Test when one number is a multiple of the other
                                                                                                                                                                                    assertEquals(3, MathUtils.gcd(3, 9));
                                                                                                                                                                                    assertEquals(5, MathUtils.gcd(25, 5));
                                                                                                                                                                                    assertEquals(7, MathUtils.gcd(7, 49));
                                                                                                                                                                                    assertEquals(11, MathUtils.gcd(121, 11));
                                                                                                                                                                                }

    @Test
                                                                                                                                                                    public void testGcd_OverflowCase() {
                                                                                                                                                                        // Test the overflow condition (gcd is 2^31)
                                                                                                                                                                        try {
                                                                                                                                                                            MathUtils.gcd(Integer.MIN_VALUE, 0);
                                                                                                                                                                            fail("Expected ArithmeticException");
                                                                                                                                                                        } catch (ArithmeticException e) {
                                                                                                                                                                            assertEquals("overflow: gcd is 2^31", e.getMessage());
                                                                                                                                                                            throw e;
                                                                                                                                                                        }
                                                                                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                                    public void testAddAndCheck_SumEqualsMinValue() {
                                                                                                                                                                        // Test case where sum equals Integer.MIN_VALUE
                                                                                                                                                                        int x = Integer.MIN_VALUE + 1;
                                                                                                                                                                        int y = -1;
                                                                                                                                                                        
                                                                                                                                                                        // Should throw ArithmeticException in original
                                                                                                                                                                        // Mutant would return Integer.MIN_VALUE
                                                                                                                                                                        MathUtils.addAndCheck(x, y);
                                                                                                                                                                        
                                                                                                                                                                        // If we reach here in original, test fails
                                                                                                                                                                        // Mutant would pass this point, so we need to verify the return value
                                                                                                                                                                        // But with expected exception, mutant would fail the test
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddAndCheck_SumJustAboveMinValue() {
                                                                                                                                                                        // Additional test case to verify normal behavior just above boundary
                                                                                                                                                                        int x = Integer.MIN_VALUE + 1;
                                                                                                                                                                        int y = 0;
                                                                                                                                                                        
                                                                                                                                                                        int result = MathUtils.addAndCheck(x, y);
                                                                                                                                                                        assertEquals(Integer.MIN_VALUE + 1, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testAddAndCheck_SumJustBelowMaxValue() {
                                                                                                                                                                        // Test case for upper boundary
                                                                                                                                                                        int x = Integer.MAX_VALUE - 1;
                                                                                                                                                                        int y = 1;
                                                                                                                                                                        
                                                                                                                                                                        int result = MathUtils.addAndCheck(x, y);
                                                                                                                                                                        assertEquals(Integer.MAX_VALUE, result);
                                                                                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                                    public void testAddAndCheck_SumExceedsMaxValue() {
                                                                                                                                                                        // Test case where sum exceeds Integer.MAX_VALUE
                                                                                                                                                                        int x = Integer.MAX_VALUE;
                                                                                                                                                                        int y = 1;
                                                                                                                                                                        
                                                                                                                                                                        MathUtils.addAndCheck(x, y);
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testAddAndCheck_ZeroSumShouldNotThrowException() throws Exception {
                                                                                                                                                                // Test case where sum is zero - should be valid in original but would throw exception in mutant
                                                                                                                                                                long a = Long.MAX_VALUE;
                                                                                                                                                                long b = -Long.MAX_VALUE;
                                                                                                                                                                
                                                                                                                                                                // Get the private method
                                                                                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                                                addAndCheck.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Invoke the method
                                                                                                                                                                long result = (long) addAndCheck.invoke(null, a, b, "overflow: add");
                                                                                                                                                                
                                                                                                                                                                // Verify the result is correct
                                                                                                                                                                assertEquals(0, result);
                                                                                                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                            public void testAddAndCheck_NegativeSumShouldThrowException() throws Exception {
                                                                                                                                                                // Test case where sum is negative - should throw exception in both original and mutant
                                                                                                                                                                long a = -Long.MAX_VALUE;
                                                                                                                                                                long b = -Long.MAX_VALUE;
                                                                                                                                                                
                                                                                                                                                                // Get the private method using reflection
                                                                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                                                                    "addAndCheck", long.class, long.class, String.class);
                                                                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                                                                addAndCheckMethod.invoke(null, a, b, "overflow: add");
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAddAndCheck_PositiveSumShouldNotThrowException() throws Exception {
                                                                                                                                                                // Test case where sum is positive - should be valid in both original and mutant
                                                                                                                                                                long a = Long.MAX_VALUE - 1;
                                                                                                                                                                long b = 1;
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access the private method
                                                                                                                                                                Class<?> mathUtilsClass = Class.forName("org.apache.commons.math.util.MathUtils");
                                                                                                                                                                Method addAndCheckMethod = mathUtilsClass.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                long result = (long) addAndCheckMethod.invoke(null, a, b, "overflow: add");
                                                                                                                                                                
                                                                                                                                                                assertEquals(Long.MAX_VALUE, result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAddAndCheck_ZeroWithLargePositive() throws Exception {
                                                                                                                                                                // Test case where a=0 and b is large positive
                                                                                                                                                                // This should succeed in original (0 + b = b)
                                                                                                                                                                // Mutant would incorrectly process this in negative branch
                                                                                                                                                                long largePositive = Long.MAX_VALUE - 100;
                                                                                                                                                                
                                                                                                                                                                // Get the private method using reflection
                                                                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                                                                    "addAndCheck", long.class, long.class, String.class);
                                                                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Invoke the method
                                                                                                                                                                long result = (long) addAndCheckMethod.invoke(
                                                                                                                                                                    null, 0L, largePositive, "Should not throw");
                                                                                                                                                                
                                                                                                                                                                assertEquals(largePositive, result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAddAndCheck_ZeroWithMaxValue() throws Exception {
                                                                                                                                                                // Test case where a=0 and b=Long.MAX_VALUE
                                                                                                                                                                // Original would process in positive branch (0 <= Long.MAX_VALUE - Long.MAX_VALUE is true)
                                                                                                                                                                // Mutant would process in negative branch (incorrect)
                                                                                                                                                                
                                                                                                                                                                // Get the private method using reflection
                                                                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                                                                    "addAndCheck", long.class, long.class, String.class);
                                                                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Invoke the method
                                                                                                                                                                long result = (long) addAndCheckMethod.invoke(null, 0L, Long.MAX_VALUE, "Should throw");
                                                                                                                                                                
                                                                                                                                                                // Verify the result
                                                                                                                                                                assertEquals(Long.MAX_VALUE, result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAddAndCheck_ZeroWithNegative() throws Exception {
                                                                                                                                                                // Additional test case where a=0 and b is negative
                                                                                                                                                                // Both original and mutant should process in negative branch
                                                                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                                                                long result = (long) addAndCheckMethod.invoke(null, 0L, -100L, "Should not throw");
                                                                                                                                                                assertEquals(-100L, result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAddAndCheck_ZeroWithZero() throws Exception {
                                                                                                                                                                // Edge case where both a and b are 0
                                                                                                                                                                // Both original and mutant should return 0
                                                                                                                                                                Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                long result = (long) method.invoke(null, 0L, 0L, "Should not throw");
                                                                                                                                                                assertEquals(0L, result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAddAndCheck_WithinBounds() {
                                                                                                                                                                // Test normal addition within bounds
                                                                                                                                                                assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                                                                                assertEquals(0, MathUtils.addAndCheck(0, 0));
                                                                                                                                                                assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                                                                                                                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                            public void testAddAndCheck_PositiveOverflow() {
                                                                                                                                                                // Test positive overflow
                                                                                                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                            public void testAddAndCheck_NegativeOverflow() {
                                                                                                                                                                // Test negative overflow
                                                                                                                                                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                            public void testAddAndCheck_LargePositiveOverflow() {
                                                                                                                                                                // Test large positive overflow
                                                                                                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                                                                                                                                                            }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                            public void testAddAndCheck_LargeNegativeOverflow() {
                                                                                                                                                                // Test large negative overflow
                                                                                                                                                                MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testAddAndCheck_BoundaryCases() {
                                                                                                                                                                // Test boundary cases
                                                                                                                                                                assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                                                                                                                                                                assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFactorial() {
                                                                                                                                                                // Test case for n=0 (0! should be 1)
                                                                                                                                                                assertEquals(1, MathUtils.factorial(0));
                                                                                                                                                                
                                                                                                                                                                // Test case for n=1 (1! should be 1)
                                                                                                                                                                assertEquals(1, MathUtils.factorial(1));
                                                                                                                                                                
                                                                                                                                                                // Test case for n=2 (2! should be 2)
                                                                                                                                                                assertEquals(2, MathUtils.factorial(2));
                                                                                                                                                                
                                                                                                                                                                // Test case for n=3 (3! should be 6)
                                                                                                                                                                assertEquals(6, MathUtils.factorial(3));
                                                                                                                                                                
                                                                                                                                                                // Test case for n=4 (4! should be 24)
                                                                                                                                                                assertEquals(24, MathUtils.factorial(4));
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testAddAndCheck() {
                                                                                                                                                            // Normal addition
                                                                                                                                                            assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                                                                            
                                                                                                                                                            // Zero addition
                                                                                                                                                            assertEquals(2, MathUtils.addAndCheck(2, 0));
                                                                                                                                                            
                                                                                                                                                            // Negative numbers
                                                                                                                                                            assertEquals(-1, MathUtils.addAndCheck(2, -3));
                                                                                                                                                            
                                                                                                                                                            // Overflow case (should throw exception)
                                                                                                                                                            try {
                                                                                                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                                                                fail("Expected ArithmeticException for overflow");
                                                                                                                                                            } catch (ArithmeticException e) {
                                                                                                                                                                // Expected
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testAddAndCheck1() throws Exception {
                                                                                                                                                        // Get the private method using reflection
                                                                                                                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                                                            "addAndCheck", long.class, long.class, String.class);
                                                                                                                                                        addAndCheckMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Test symmetric case (a > b)
                                                                                                                                                        assertEquals(5, addAndCheckMethod.invoke(null, 3L, 2L, "Should not throw"));
                                                                                                                                                        assertEquals(5, addAndCheckMethod.invoke(null, 2L, 3L, "Should not throw"));
                                                                                                                                                        
                                                                                                                                                        // Test positive additions
                                                                                                                                                        assertEquals(Long.MAX_VALUE - 1, 
                                                                                                                                                            addAndCheckMethod.invoke(null, Long.MAX_VALUE - 2, 1L, "Should not throw"));
                                                                                                                                                        
                                                                                                                                                        // Test positive overflow
                                                                                                                                                        try {
                                                                                                                                                            addAndCheckMethod.invoke(null, Long.MAX_VALUE - 1, 2L, "Should throw");
                                                                                                                                                            fail("Expected ArithmeticException");
                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                            assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        // Test negative additions
                                                                                                                                                        assertEquals(Long.MIN_VALUE + 1, 
                                                                                                                                                            addAndCheckMethod.invoke(null, Long.MIN_VALUE, 1L, "Should not throw"));
                                                                                                                                                        
                                                                                                                                                        // Test negative overflow
                                                                                                                                                        try {
                                                                                                                                                            addAndCheckMethod.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
                                                                                                                                                            fail("Expected ArithmeticException");
                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                            assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        // Test mixed sign additions (should never overflow)
                                                                                                                                                        assertEquals(0, addAndCheckMethod.invoke(null, -1L, 1L, "Should not throw"));
                                                                                                                                                        assertEquals(-Long.MAX_VALUE + 1, 
                                                                                                                                                            addAndCheckMethod.invoke(null, -Long.MAX_VALUE, 1L, "Should not throw"));
                                                                                                                                                            
                                                                                                                                                        // Test boundary cases
                                                                                                                                                        assertEquals(0, addAndCheckMethod.invoke(null, Long.MAX_VALUE, -Long.MAX_VALUE, "Should not throw"));
                                                                                                                                                        assertEquals(-1, addAndCheckMethod.invoke(null, Long.MAX_VALUE, Long.MIN_VALUE, "Should not throw"));
                                                                                                                                                        
                                                                                                                                                        // Test zero cases
                                                                                                                                                        assertEquals(5, addAndCheckMethod.invoke(null, 5L, 0L, "Should not throw"));
                                                                                                                                                        assertEquals(-5, addAndCheckMethod.invoke(null, -5L, 0L, "Should not throw"));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testAddAndCheckNormalAddition() {
                                                                                                                                                        // Test normal addition cases
                                                                                                                                                        assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                                                                        assertEquals(-1, MathUtils.addAndCheck(2, -3));
                                                                                                                                                        assertEquals(0, MathUtils.addAndCheck(0, 0));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testAddAndCheckBoundaryValues() {
                                                                                                                                                        // Test addition with boundary values that don't overflow
                                                                                                                                                        assertEquals(Integer.MAX_VALUE, 
                                                                                                                                                            MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                                                                        assertEquals(Integer.MIN_VALUE, 
                                                                                                                                                            MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                    public void testAddAndCheckPositiveOverflow() {
                                                                                                                                                        // Test positive overflow
                                                                                                                                                        MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                    public void testAddAndCheckNegativeOverflow() {
                                                                                                                                                        // Test negative overflow
                                                                                                                                                        MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                    public void testAddAndCheckLargePositiveOverflow() {
                                                                                                                                                        // Test large positive overflow
                                                                                                                                                        MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                                                                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                                                                    public void testAddAndCheckLargeNegativeOverflow() {
                                                                                                                                                        // Test large negative overflow
                                                                                                                                                        MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testAddAndCheckMaxPlusMin() {
                                                                                                                                                        // Test MAX_VALUE + MIN_VALUE which shouldn't overflow
                                                                                                                                                        assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testBinomialCoefficientLogAccumulation() {
                                                                                                                                                        // Test with values that require multiple iterations/logarithmic additions
                                                                                                                                                        // Original code would accumulate, mutant would only keep last value
                                                                                                                                                        double result1 = MathUtils.binomialCoefficientLog(10, 2);
                                                                                                                                                        double result2 = MathUtils.binomialCoefficientLog(10, 5);
                                                                                                                                                        
                                                                                                                                                        // Verify the results are as expected (using known good values)
                                                                                                                                                        // These expected values would need to be calculated or obtained from a reliable source
                                                                                                                                                        assertEquals(3.5553480614894135, result1, MathUtils.EPSILON);
                                                                                                                                                        assertEquals(4.8283137373023015, result2, MathUtils.EPSILON);
                                                                                                                                                        
                                                                                                                                                        // The key is that these values can't be achieved without proper accumulation
                                                                                                                                                        // The mutant would produce different (incorrect) results
                                                                                                                                                    }

    @Test
                                                                                                                                            public void testAddAndCheck2() throws Exception {
                                                                                                                                                // Get the private method using reflection
                                                                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                                addAndCheck.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Test symmetric case (a > b)
                                                                                                                                                assertEquals(5, addAndCheck.invoke(null, 3L, 2L, "Should work for a > b"));
                                                                                                                                                
                                                                                                                                                // Test normal addition
                                                                                                                                                assertEquals(10, addAndCheck.invoke(null, 4L, 6L, "Normal addition should work"));
                                                                                                                                                
                                                                                                                                                // Test opposite signs (no overflow possible)
                                                                                                                                                assertEquals(-2, addAndCheck.invoke(null, -5L, 3L, "Opposite signs should work"));
                                                                                                                                                assertEquals(2, addAndCheck.invoke(null, 5L, -3L, "Opposite signs should work"));
                                                                                                                                                
                                                                                                                                                // Test negative overflow boundary
                                                                                                                                                assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1L, "Negative boundary should work"));
                                                                                                                                                
                                                                                                                                                // Test positive overflow boundary
                                                                                                                                                assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 1L, "Positive boundary should work"));
                                                                                                                                                
                                                                                                                                                // Test negative overflow
                                                                                                                                                try {
                                                                                                                                                    addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "Should throw ArithmeticException");
                                                                                                                                                    fail("Expected ArithmeticException for negative overflow");
                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                    assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test positive overflow
                                                                                                                                                try {
                                                                                                                                                    addAndCheck.invoke(null, Long.MAX_VALUE, 1L, "Should throw ArithmeticException");
                                                                                                                                                    fail("Expected ArithmeticException for positive overflow");
                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                    assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test both negative numbers near boundary
                                                                                                                                                try {
                                                                                                                                                    addAndCheck.invoke(null, Long.MIN_VALUE/2, Long.MIN_VALUE/2 - 1, "Should throw ArithmeticException");
                                                                                                                                                    fail("Expected ArithmeticException for large negative sum");
                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                    assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test both positive numbers near boundary
                                                                                                                                                try {
                                                                                                                                                    addAndCheck.invoke(null, Long.MAX_VALUE/2 + 1, Long.MAX_VALUE/2 + 1, "Should throw ArithmeticException");
                                                                                                                                                    fail("Expected ArithmeticException for large positive sum");
                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                    assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                            public void testAddAndCheckDetectsAbsSumVsMaxMutant() {
                                                                                                                                                // Test case where sum of absolute values is different from max absolute value
                                                                                                                                                int x = 5;
                                                                                                                                                int y = 3;
                                                                                                                                                
                                                                                                                                                // Original should return 5+3=8
                                                                                                                                                // Mutant would return max(5,3)=5
                                                                                                                                                int result = MathUtils.addAndCheck(x, y);
                                                                                                                                                assertEquals("Sum should be 8 for 5+3", 8, result);
                                                                                                                                                
                                                                                                                                                // Test with negative numbers
                                                                                                                                                x = -4;
                                                                                                                                                y = -2;
                                                                                                                                                
                                                                                                                                                // Original should return -4 + -2 = -6
                                                                                                                                                // Mutant would return max(4,2)=4
                                                                                                                                                result = MathUtils.addAndCheck(x, y);
                                                                                                                                                assertEquals("Sum should be -6 for -4 + -2", -6, result);
                                                                                                                                                
                                                                                                                                                // Test with mixed signs
                                                                                                                                                x = 10;
                                                                                                                                                y = -3;
                                                                                                                                                
                                                                                                                                                // Original should return 10 + -3 = 7
                                                                                                                                                // Mutant would return max(10,3)=10
                                                                                                                                                result = MathUtils.addAndCheck(x, y);
                                                                                                                                                assertEquals("Sum should be 7 for 10 + -3", 7, result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testAddAndCheckOverflowDetection() {
                                                                                                                                                // Test case where sum would overflow but max absolute wouldn't catch it
                                                                                                                                                int a = Integer.MAX_VALUE - 100;
                                                                                                                                                int b = 200;
                                                                                                                                                
                                                                                                                                                try {
                                                                                                                                                    MathUtils.addAndCheck(a, b);
                                                                                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                                    // Expected behavior - original would throw, mutant might not
                                                                                                                                                    assertEquals("overflow: add", e.getMessage());
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Another test case with negative numbers
                                                                                                                                                int c = Integer.MIN_VALUE + 100;
                                                                                                                                                int d = -200;
                                                                                                                                                
                                                                                                                                                try {
                                                                                                                                                    MathUtils.addAndCheck(c, d);
                                                                                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                                    assertEquals("overflow: add", e.getMessage());
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test case where sum is exactly at limit
                                                                                                                                                int e = Integer.MAX_VALUE - 1;
                                                                                                                                                int f = 1;
                                                                                                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(e, f));
                                                                                                                                            }

    @Test
                                                                                                                                    public void testAddAndCheckDetectsAbsSumMutant() throws Exception {
                                                                                                                                        // Test case with two positive numbers
                                                                                                                                        long a = 5L;
                                                                                                                                        long b = 10L;
                                                                                                                                        String msg = "Overflow occurred";
                                                                                                                                        
                                                                                                                                        // Get the private method using reflection
                                                                                                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                        addAndCheckMethod.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Should return 15 (5+10) in original, but would return 10 (max(5,10)) in mutant
                                                                                                                                        long result = (long) addAndCheckMethod.invoke(null, a, b, msg);
                                                                                                                                        assertEquals(15L, result);
                                                                                                                                        
                                                                                                                                        // Test case with two negative numbers
                                                                                                                                        long c = -5L;
                                                                                                                                        long d = -10L;
                                                                                                                                        
                                                                                                                                        // Should return -15 (-5 + -10) in original, but would return -10 (max(5,10)*-1 in mutant
                                                                                                                                        long result2 = (long) addAndCheckMethod.invoke(null, c, d, msg);
                                                                                                                                        assertEquals(-15L, result2);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testGcdWithZero() {
                                                                                                                                        // This test will detect the mutant u >= 0 vs original u > 0
                                                                                                                                        // When u=0, original would skip the if block, mutant would enter it
                                                                                                                                        int result = MathUtils.gcd(0, 5);
                                                                                                                                        
                                                                                                                                        // Original behavior: gcd(0,5) should return 5
                                                                                                                                        // Mutant behavior might return different value if it enters the if block
                                                                                                                                        assertEquals(5, result);
                                                                                                                                        
                                                                                                                                        // Also test with both zeros
                                                                                                                                        result = MathUtils.gcd(0, 0);
                                                                                                                                        assertEquals(0, result);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testGcdWithPositive() {
                                                                                                                                        // Test with positive u to ensure both versions behave same
                                                                                                                                        int result = MathUtils.gcd(5, 10);
                                                                                                                                        assertEquals(5, result);
                                                                                                                                        
                                                                                                                                        result = MathUtils.gcd(15, 10);
                                                                                                                                        assertEquals(5, result);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testGcdWithNegative() {
                                                                                                                                        // Test with negative u to ensure both versions behave same
                                                                                                                                        int result = MathUtils.gcd(-5, 10);
                                                                                                                                        assertEquals(5, result);
                                                                                                                                        
                                                                                                                                        result = MathUtils.gcd(-15, -10);
                                                                                                                                        assertEquals(5, result);
                                                                                                                                    }

    @Test
                                                                                                                            public void testAddAndCheckWithZeroOperand() throws Exception {
                                                                                                                                // Get the private method via reflection
                                                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                addAndCheck.setAccessible(true);
                                                                                                                                
                                                                                                                                // Test case where one operand is zero - should not throw exception
                                                                                                                                // This will catch the mutant where condition changed to u >= 0
                                                                                                                                long a = Long.MAX_VALUE;
                                                                                                                                long b = 0L;
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    long result = (long) addAndCheck.invoke(null, a, b, "overflow: add");
                                                                                                                                    assertEquals(Long.MAX_VALUE, result);
                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                    if (e.getTargetException() instanceof ArithmeticException) {
                                                                                                                                        fail("Should not throw exception when adding zero to MAX_VALUE");
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Also test with negative value and zero
                                                                                                                                long c = Long.MIN_VALUE;
                                                                                                                                long d = 0L;
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    long result = (long) addAndCheck.invoke(null, c, d, "overflow: add");
                                                                                                                                    assertEquals(Long.MIN_VALUE, result);
                                                                                                                                } catch (InvocationTargetException ex) {
                                                                                                                                    if (ex.getTargetException() instanceof ArithmeticException) {
                                                                                                                                        fail("Should not throw exception when adding zero to MIN_VALUE");
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Test with both operands zero
                                                                                                                                long eVal = 0L;
                                                                                                                                long f = 0L;
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    long result = (long) addAndCheck.invoke(null, eVal, f, "overflow: add");
                                                                                                                                    assertEquals(0L, result);
                                                                                                                                } catch (InvocationTargetException ex) {
                                                                                                                                    if (ex.getTargetException() instanceof ArithmeticException) {
                                                                                                                                        fail("Should not throw exception when adding zero to zero");
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testAddAndCheck_ZeroWithMaxLong_ShouldThrowOverflow() throws Exception {
                                                                                                                                // This test will catch the mutant because:
                                                                                                                                // Original: 0 + Long.MAX_VALUE would be checked in positive overflow branch and throw
                                                                                                                                // Mutated: Would incorrectly go to mixed signs branch and not check for overflow
                                                                                                                                
                                                                                                                                // Get the private method using reflection
                                                                                                                                Class<?> mathUtilsClass = Class.forName("org.apache.commons.math.util.MathUtils");
                                                                                                                                Method addAndCheckMethod = mathUtilsClass.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Invoke the method and expect ArithmeticException
                                                                                                                                try {
                                                                                                                                    addAndCheckMethod.invoke(null, 0L, Long.MAX_VALUE, "Overflow should occur");
                                                                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testAddAndCheck_ZeroWithNegativeMaxLong_ShouldNotThrow() throws Exception {
                                                                                                                                // Additional test for zero case with negative number
                                                                                                                                // Both original and mutant should behave the same here
                                                                                                                                
                                                                                                                                // Get the private method using reflection
                                                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                                    "addAndCheck", long.class, long.class, String.class);
                                                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Invoke the method
                                                                                                                                long result = (long) addAndCheckMethod.invoke(
                                                                                                                                    null, 0L, -Long.MAX_VALUE, "Should not overflow");
                                                                                                                                
                                                                                                                                assertEquals(-Long.MAX_VALUE, result);
                                                                                                                            }

    @Test
                                                                                                                            public void testAddAndCheck_MaxLongWithZero_ShouldThrowOverflow() throws Exception {
                                                                                                                                // Get the private method using reflection
                                                                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                addAndCheck.setAccessible(true);
                                                                                                                                
                                                                                                                                // Test that overflow exception is thrown
                                                                                                                                try {
                                                                                                                                    addAndCheck.invoke(null, Long.MAX_VALUE, 0L, "Overflow should occur");
                                                                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                    assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testAddAndCheck_ZeroWithZero_ShouldReturnZero() throws Exception {
                                                                                                                                // Edge case where a=0 and b=0
                                                                                                                                Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                                method.setAccessible(true);
                                                                                                                                long result = (long) method.invoke(null, 0L, 0L, "Should not overflow");
                                                                                                                                assertEquals(0L, result);
                                                                                                                            }

    @Test
                                                                                                                            public void testGcdWithNegativeNumbers() {
                                                                                                                                // Test case where /= 2 and >>= 1 would produce different intermediate results
                                                                                                                                int a = -12;
                                                                                                                                int b = 8;
                                                                                                                                
                                                                                                                                // Original gcd(-12,8) steps:
                                                                                                                                // -12 / 2 = -6 (would be -7 with >>=)
                                                                                                                                // Then gcd(8, -6) etc...
                                                                                                                                // Final result should still be 4, but mutation might give different result
                                                                                                                                
                                                                                                                                int result = MathUtils.gcd(a, b);
                                                                                                                                assertEquals(4, result);
                                                                                                                                
                                                                                                                                // Another test case where odd negative number is halved
                                                                                                                                a = -5;
                                                                                                                                b = 15;
                                                                                                                                result = MathUtils.gcd(a, b);
                                                                                                                                assertEquals(5, result);
                                                                                                                            }

    @Test
                                                                                                                    public void testAddAndCheck3() {
                                                                                                                        // Test normal addition within range
                                                                                                                        assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                                        assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                                                                                                        
                                                                                                                        // Test boundary cases
                                                                                                                        assertEquals(Integer.MAX_VALUE, 
                                                                                                                            MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                                        assertEquals(Integer.MIN_VALUE, 
                                                                                                                            MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                                                        
                                                                                                                        // Test exact boundary values
                                                                                                                        assertEquals(Integer.MAX_VALUE, 
                                                                                                                            MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                                                                                                                        assertEquals(Integer.MIN_VALUE, 
                                                                                                                            MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                                                                                                                        
                                                                                                                        // Test overflow cases
                                                                                                                        try {
                                                                                                                            MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                            fail("Expected ArithmeticException for overflow");
                                                                                                                        } catch (ArithmeticException e) {
                                                                                                                            assertTrue(e.getMessage().contains("overflow"));
                                                                                                                        }
                                                                                                                        
                                                                                                                        try {
                                                                                                                            MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                                            fail("Expected ArithmeticException for underflow");
                                                                                                                        } catch (ArithmeticException e) {
                                                                                                                            assertTrue(e.getMessage().contains("overflow"));
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test cases that would fail with mutated conditions
                                                                                                                        // These would catch mutations like changing < to <= or > to >=
                                                                                                                        assertEquals(Integer.MAX_VALUE, 
                                                                                                                            MathUtils.addAndCheck(Integer.MAX_VALUE - 100, 100));
                                                                                                                        assertEquals(Integer.MIN_VALUE, 
                                                                                                                            MathUtils.addAndCheck(Integer.MIN_VALUE + 100, -100));
                                                                                                                    }

    @Test
                                                                                                                    public void testAddAndCheckPositiveOverflow1() throws Exception {
                                                                                                                        long a = Long.MAX_VALUE;
                                                                                                                        long b = 1;
                                                                                                                        thrown.expect(ArithmeticException.class);
                                                                                                                        
                                                                                                                        // Get the private method using reflection
                                                                                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                            "addAndCheck", long.class, long.class, String.class);
                                                                                                                        addAndCheckMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Invoke the method
                                                                                                                        addAndCheckMethod.invoke(null, a, b, "Should overflow");
                                                                                                                    }

    @Test
                                                                                                                    public void testAddAndCheckNegativeOverflow1() throws Exception {
                                                                                                                        long a = Long.MIN_VALUE;
                                                                                                                        long b = -1;
                                                                                                                        
                                                                                                                        // Get the private method using reflection
                                                                                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                            "addAndCheck", long.class, long.class, String.class);
                                                                                                                        addAndCheckMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Set up expected exception
                                                                                                                        thrown.expect(ArithmeticException.class);
                                                                                                                        thrown.expectMessage("Should overflow");
                                                                                                                        
                                                                                                                        // Invoke the private method
                                                                                                                        addAndCheckMethod.invoke(null, a, b, "Should overflow");
                                                                                                                    }

    @Test
                                                                                                                    public void testAddAndCheckNormalAddition1() throws Exception {
                                                                                                                        long a = 100;
                                                                                                                        long b = 200;
                                                                                                                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                        method.setAccessible(true);
                                                                                                                        assertEquals(300, (long) method.invoke(null, a, b, "Should not overflow"));
                                                                                                                    }

    @Test
                                                                                                                    public void testAddAndCheckOppositeSigns() throws Exception {
                                                                                                                        long a = Long.MAX_VALUE;
                                                                                                                        long b = -100;
                                                                                                                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                        method.setAccessible(true);
                                                                                                                        assertEquals(Long.MAX_VALUE - 100, (long) method.invoke(null, a, b, "Should not overflow"));
                                                                                                                    }

    @Test
                                                                                                                    public void testAddAndCheckSwappedArguments() throws Exception {
                                                                                                                        long a = 100;
                                                                                                                        long b = 50;
                                                                                                                        
                                                                                                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                        addAndCheck.setAccessible(true);
                                                                                                                        
                                                                                                                        assertEquals(150, addAndCheck.invoke(null, a, b, "Should not overflow"));
                                                                                                                        assertEquals(150, addAndCheck.invoke(null, b, a, "Should not overflow"));
                                                                                                                    }

    @Test
                                                                                                                public void testAddAndCheckNegativeNumbersWithPotentialOverflow() throws Exception {
                                                                                                                    // Get the private method using reflection
                                                                                                                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                                    addAndCheck.setAccessible(true);
                                                                                                                    
                                                                                                                    // Test case that would reveal the difference between /=2 and >>=1
                                                                                                                    // Using Long.MIN_VALUE + Long.MIN_VALUE/2 to create a scenario where
                                                                                                                    // the mutation would behave differently
                                                                                                                    long a = Long.MIN_VALUE;
                                                                                                                    long b = Long.MIN_VALUE / 2;
                                                                                                                    
                                                                                                                    try {
                                                                                                                        addAndCheck.invoke(null, a, b, "overflow: add");
                                                                                                                        fail("Expected ArithmeticException for overflow");
                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                        // Verify the exception message matches expected
                                                                                                                        assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Another test case with different negative values
                                                                                                                    long c = -9223372036854775807L; // Long.MIN_VALUE + 1
                                                                                                                    long d = -4611686018427387904L;  // c/2
                                                                                                                    
                                                                                                                    try {
                                                                                                                        addAndCheck.invoke(null, c, d, "overflow: add");
                                                                                                                        fail("Expected ArithmeticException for overflow");
                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                        assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                                                                                                                    }
                                                                                                                }

    @Test
                                                                                                                public void testAddAndCheckWithNegativeOddNumbers() {
                                                                                                                    // Test case that would reveal difference between /=2 and >>=1
                                                                                                                    // Using values that would exercise any division operations in the class
                                                                                                                    int x = -5;
                                                                                                                    int y = -3;
                                                                                                                    
                                                                                                                    // The actual sum should be -8 which is within int range
                                                                                                                    assertEquals(-8, MathUtils.addAndCheck(x, y));
                                                                                                                    
                                                                                                                    // Also test boundary cases
                                                                                                                    assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                                                                                                                    assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                                                                                                                    
                                                                                                                    // Test case where sum would be negative odd number if divided
                                                                                                                    assertEquals(-4, MathUtils.addAndCheck(-2, -2));
                                                                                                                }

    @Test(expected = ArithmeticException.class)
                                                                                                                public void testAddAndCheckOverflowPositive() {
                                                                                                                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                }

    @Test(expected = ArithmeticException.class)
                                                                                                                public void testAddAndCheckOverflowNegative() {
                                                                                                                    MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                                }

    @Test
                                                                                                        public void testAddAndCheckNegativeOverflow2() throws Exception {
                                                                                                            // This test will detect the mutant because:
                                                                                                            // Original code (t /= 2) handles negative numbers correctly for overflow check
                                                                                                            // Mutated code (t >>= 1) will not properly detect negative overflow due to sign bit preservation
                                                                                                            long a = Long.MIN_VALUE;
                                                                                                            long b = -1;
                                                                                                            
                                                                                                            // Get the private method using reflection
                                                                                                            Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                            addAndCheck.setAccessible(true);
                                                                                                            
                                                                                                            try {
                                                                                                                addAndCheck.invoke(null, a, b, "Should throw overflow for negative numbers");
                                                                                                                fail("Expected ArithmeticException for overflow");
                                                                                                            } catch (InvocationTargetException e) {
                                                                                                                assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                        public void testAddAndCheckNoOverflow() throws Exception {
                                                                                                            // Regular case that should work in both original and mutated code
                                                                                                            long a = 1000;
                                                                                                            long b = 2000;
                                                                                                            
                                                                                                            // Get the private method using reflection
                                                                                                            Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                                "addAndCheck", long.class, long.class, String.class);
                                                                                                            addAndCheckMethod.setAccessible(true);
                                                                                                            
                                                                                                            // Invoke the method
                                                                                                            long result = (Long) addAndCheckMethod.invoke(null, a, b, "No overflow expected");
                                                                                                            
                                                                                                            assertEquals(3000, result);
                                                                                                        }

    @Test
                                                                                                        public void testAddAndCheckPositiveOverflow2() throws Exception {
                                                                                                            // Test positive overflow (should be caught by both versions)
                                                                                                            long a = Long.MAX_VALUE;
                                                                                                            long b = 1;
                                                                                                            
                                                                                                            // Get the private method via reflection
                                                                                                            Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                            method.setAccessible(true);
                                                                                                            
                                                                                                            try {
                                                                                                                method.invoke(null, a, b, "Should throw overflow for positive numbers");
                                                                                                                fail("Expected ArithmeticException for positive overflow");
                                                                                                            } catch (InvocationTargetException e) {
                                                                                                                assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                        public void testAddAndCheckMixedSignsNoOverflow() throws Exception {
                                                                                                            // Test mixed signs where no overflow occurs
                                                                                                            long a = Long.MAX_VALUE;
                                                                                                            long b = Long.MIN_VALUE;
                                                                                                            
                                                                                                            // Get the private method via reflection
                                                                                                            java.lang.reflect.Method method = MathUtils.class.getDeclaredMethod(
                                                                                                                "addAndCheck", long.class, long.class, String.class);
                                                                                                            method.setAccessible(true);
                                                                                                            
                                                                                                            // Invoke the method
                                                                                                            long result = (long) method.invoke(null, a, b, "No overflow expected for MAX + MIN");
                                                                                                            
                                                                                                            assertEquals(-1, result);
                                                                                                        }

    @Test
                                                                                                        public void testAddAndCheckNegativeNearOverflow() throws Exception {
                                                                                                            // Test case designed to detect the difference between /= 2 and >>= 1
                                                                                                            // with negative numbers near overflow boundary
                                                                                                            
                                                                                                            // These values are chosen because:
                                                                                                            // - Both are negative
                                                                                                            // - Their sum is close to Long.MIN_VALUE
                                                                                                            // - The overflow check calculation would be affected by /= 2 vs >>= 1
                                                                                                            long a = Long.MIN_VALUE + 1;
                                                                                                            long b = -1;
                                                                                                            
                                                                                                            // Get private method via reflection
                                                                                                            Method addAndCheck = MathUtils.class.getDeclaredMethod(
                                                                                                                "addAndCheck", long.class, long.class, String.class);
                                                                                                            addAndCheck.setAccessible(true);
                                                                                                            
                                                                                                            try {
                                                                                                                long result = (long) addAndCheck.invoke(null, a, b, "Should overflow");
                                                                                                                // If we get here, the test should fail as we expect overflow
                                                                                                                fail("Expected ArithmeticException for overflow");
                                                                                                            } catch (InvocationTargetException e) {
                                                                                                                // This is the expected behavior
                                                                                                                assertEquals("Should overflow", ((ArithmeticException)e.getCause()).getMessage());
                                                                                                            }
                                                                                                            
                                                                                                            // Additional test case with values that would behave differently
                                                                                                            // with the mutation when checking for overflow
                                                                                                            long c = Long.MIN_VALUE / 2 - 1;
                                                                                                            long d = Long.MIN_VALUE / 2 - 1;
                                                                                                            
                                                                                                            try {
                                                                                                                long result = (long) addAndCheck.invoke(null, c, d, "Should overflow");
                                                                                                                fail("Expected ArithmeticException for overflow");
                                                                                                            } catch (InvocationTargetException e) {
                                                                                                                assertEquals("Should overflow", ((ArithmeticException)e.getCause()).getMessage());
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                        public void testAddAndCheckBoundaryConditions() {
                                                                                                            // Test minimum integer boundaries
                                                                                                            assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                                            assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(-1, Integer.MIN_VALUE + 1));
                                                                                                            
                                                                                                            // Test maximum integer boundaries
                                                                                                            assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                            assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(1, Integer.MAX_VALUE - 1));
                                                                                                            
                                                                                                            // Test overflow conditions
                                                                                                            try {
                                                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                                fail("Expected ArithmeticException for overflow");
                                                                                                            } catch (ArithmeticException e) {
                                                                                                                assertEquals("overflow: add", e.getMessage());
                                                                                                            }
                                                                                                            
                                                                                                            try {
                                                                                                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                                fail("Expected ArithmeticException for underflow");
                                                                                                            } catch (ArithmeticException e) {
                                                                                                                assertEquals("overflow: add", e.getMessage());
                                                                                                            }
                                                                                                            
                                                                                                            // Test normal addition
                                                                                                            assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                            assertEquals(0, MathUtils.addAndCheck(-5, 5));
                                                                                                            
                                                                                                            // Test with zero values
                                                                                                            assertEquals(10, MathUtils.addAndCheck(10, 0));
                                                                                                            assertEquals(-10, MathUtils.addAndCheck(0, -10));
                                                                                                        }

    @Test
                                                                                                        public void testFactorialDetectsLoopMutation() {
                                                                                                            // Test case to detect the loop mutation (i starts at 1 instead of 2)
                                                                                                            // For n=2, original: 2! = 2 (loop runs once: i=2)
                                                                                                            // Mutated: would calculate 1 * 1 * 2 = 2 (same result)
                                                                                                            // For n=3, original: 3! = 6 (loop: i=2, i=3)
                                                                                                            // Mutated: would calculate 1 * 1 * 2 * 3 = 6 (same result)
                                                                                                            // For n=4, original: 4! = 24 (loop: i=2, i=3, i=4)
                                                                                                            // Mutated: would calculate 1 * 1 * 2 * 3 * 4 = 24 (same result)
                                                                                                            // This mutation might not affect factorial calculation
                                                                                                            
                                                                                                            // However, looking at binomialCoefficient which likely uses similar loop:
                                                                                                            // n choose k where n >= k
                                                                                                            // For binomialCoefficient(2,1):
                                                                                                            // Original might calculate 2/(1) = 2
                                                                                                            // Mutated might calculate 1*2/(1*1) = 2 (same)
                                                                                                            // Need to find where extra iteration matters
                                                                                                            
                                                                                                            // Alternative approach: test addAndCheck directly
                                                                                                            // Since the mutation is in addAndCheck's loop, but we don't see its full implementation
                                                                                                            // We'll test boundary cases where loop iterations matter
                                                                                                            
                                                                                                            // Since we can't see addAndCheck's full implementation, we'll test factorial
                                                                                                            // which likely uses similar loop structure
                                                                                                            assertEquals(2, MathUtils.factorial(2));  // 2! = 2
                                                                                                            assertEquals(6, MathUtils.factorial(3));  // 3! = 6
                                                                                                            assertEquals(24, MathUtils.factorial(4)); // 4! = 24
                                                                                                            
                                                                                                            // The mutation might not be caught by factorial tests
                                                                                                            // Need to test binomialCoefficient which might show differences
                                                                                                            assertEquals(3, MathUtils.binomialCoefficient(3, 2)); // 3 choose 2 = 3
                                                                                                            assertEquals(4, MathUtils.binomialCoefficient(4, 3)); // 4 choose 3 = 4
                                                                                                        }

    @Test
                                                                                                        public void testBinomialCoefficientDetectsLoopMutation() {
                                                                                                            // Test case to detect the loop mutation from i=2 to i=1
                                                                                                            
                                                                                                            // Case where n=1, k=1 - should be 1
                                                                                                            // With original i=2, this would skip loop and return 1
                                                                                                            // With mutated i=1, it would do one unnecessary multiplication
                                                                                                            assertEquals(1, MathUtils.binomialCoefficient(1, 1));
                                                                                                            
                                                                                                            // Case where n=2, k=1 - should be 2
                                                                                                            // Original would do one iteration (i=2)
                                                                                                            // Mutated would do two iterations (i=1 and i=2)
                                                                                                            assertEquals(2, MathUtils.binomialCoefficient(2, 1));
                                                                                                            
                                                                                                            // Case where n=5, k=2 - should be 10
                                                                                                            // Original would do iterations for i=2,3,4,5
                                                                                                            // Mutated would do extra iteration for i=1
                                                                                                            assertEquals(10, MathUtils.binomialCoefficient(5, 2));
                                                                                                            
                                                                                                            // Edge case where k=0 - should always be 1 regardless of n
                                                                                                            assertEquals(1, MathUtils.binomialCoefficient(5, 0));
                                                                                                            assertEquals(1, MathUtils.binomialCoefficient(0, 0));
                                                                                                        }

    @Test
                                                                                                    public void testAddAndCheckReturnsCorrectSum() {
                                                                                                        // Test case where sum is different from max absolute value
                                                                                                        assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                        assertEquals(-1, MathUtils.addAndCheck(2, -3));
                                                                                                        assertEquals(0, MathUtils.addAndCheck(-5, 5));
                                                                                                        
                                                                                                        // Test with zero values
                                                                                                        assertEquals(3, MathUtils.addAndCheck(0, 3));
                                                                                                        assertEquals(-4, MathUtils.addAndCheck(-4, 0));
                                                                                                        
                                                                                                        // Test with same absolute value but different signs
                                                                                                        assertEquals(0, MathUtils.addAndCheck(10, -10));
                                                                                                        
                                                                                                        // Test boundary cases
                                                                                                        assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                        assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                    public void testAddAndCheckThrowsOnOverflow() {
                                                                                                        MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                                    public void testAddAndCheckThrowsOnUnderflow() {
                                                                                                        MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                    }

    @Test
                                                                                                    public void testAddAndCheckDetectsSumOverflow() {
                                                                                                        // Test case where sum of absolute values would overflow but max wouldn't
                                                                                                        long a = Long.MAX_VALUE / 2 + 1;
                                                                                                        long b = Long.MAX_VALUE / 2 + 1;
                                                                                                        
                                                                                                        try {
                                                                                                            MathUtils.addAndCheck(a, b);
                                                                                                            fail("Expected ArithmeticException for overflow");
                                                                                                        } catch (ArithmeticException e) {
                                                                                                            assertEquals("overflow: add", e.getMessage());
                                                                                                        }
                                                                                                        
                                                                                                        // Test with negative values that would overflow when summed
                                                                                                        long c = Long.MIN_VALUE / 2 - 1;
                                                                                                        long d = Long.MIN_VALUE / 2 - 1;
                                                                                                        
                                                                                                        try {
                                                                                                            MathUtils.addAndCheck(c, d);
                                                                                                            fail("Expected ArithmeticException for overflow");
                                                                                                        } catch (ArithmeticException e) {
                                                                                                            assertEquals("overflow: add", e.getMessage());
                                                                                                        }
                                                                                                        
                                                                                                        // Test with one large positive and one large negative
                                                                                                        long e = Long.MAX_VALUE;
                                                                                                        long f = -Long.MAX_VALUE + 1;
                                                                                                        
                                                                                                        try {
                                                                                                            MathUtils.addAndCheck(e, f);
                                                                                                            // Should not throw for this case
                                                                                                            assertEquals(2L, MathUtils.addAndCheck(e, f));
                                                                                                        } catch (ArithmeticException ex) {
                                                                                                            fail("Should not throw for this case");
                                                                                                        }
                                                                                                    }

    @Test
                                                                                            public void testAddAndCheckDetectsAbsSumVsMaxMutation() throws Exception {
                                                                                                // Test case where sum of absolute values differs from max absolute value
                                                                                                long a = 5L;
                                                                                                long b = 3L;
                                                                                                String msg = "Test message";
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                                addAndCheckMethod.setAccessible(true);
                                                                                                
                                                                                                // Original should return 8 (5+3), mutated would return 5 (max of 5 and 3)
                                                                                                long result = (long) addAndCheckMethod.invoke(null, a, b, msg);
                                                                                                assertEquals("Sum should be 8 for 5+3", 8L, result);
                                                                                                
                                                                                                // Test with negative numbers
                                                                                                long c = -5L;
                                                                                                long d = -3L;
                                                                                                result = (long) addAndCheckMethod.invoke(null, c, d, msg);
                                                                                                assertEquals("Sum should be -8 for -5 + -3", -8L, result);
                                                                                                
                                                                                                // Test with mixed signs
                                                                                                long e = 5L;
                                                                                                long f = -3L;
                                                                                                result = (long) addAndCheckMethod.invoke(null, e, f, msg);
                                                                                                assertEquals("Sum should be 2 for 5 + -3", 2L, result);
                                                                                                
                                                                                                // Test with larger difference in magnitudes
                                                                                                long g = 100L;
                                                                                                long h = 50L;
                                                                                                result = (long) addAndCheckMethod.invoke(null, g, h, msg);
                                                                                                assertEquals("Sum should be 150 for 100+50", 150L, result);
                                                                                            }

    @Test
                                                                                            public void testAddAndCheck4() {
                                                                                                // Test normal addition within range
                                                                                                assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                                assertEquals(-1, MathUtils.addAndCheck(2, -3));
                                                                                                
                                                                                                // Test boundary cases
                                                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                                
                                                                                                // Test overflow cases
                                                                                                try {
                                                                                                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                                } catch (ArithmeticException e) {
                                                                                                    assertEquals("overflow: add", e.getMessage());
                                                                                                }
                                                                                                
                                                                                                try {
                                                                                                    MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                                    fail("Expected ArithmeticException for underflow");
                                                                                                } catch (ArithmeticException e) {
                                                                                                    assertEquals("overflow: add", e.getMessage());
                                                                                                }
                                                                                                
                                                                                                // Test cases near boundaries
                                                                                                assertEquals(Integer.MAX_VALUE - 1, MathUtils.addAndCheck(Integer.MAX_VALUE - 2, 1));
                                                                                                assertEquals(Integer.MIN_VALUE + 1, MathUtils.addAndCheck(Integer.MIN_VALUE + 2, -1));
                                                                                                
                                                                                                // Test with zero
                                                                                                assertEquals(0, MathUtils.addAndCheck(0, 0));
                                                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                                                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                                                                                            }

    @Test
                                                                                    public void testAddAndCheck_ZeroSum() throws Exception {
                                                                                        // This test will catch the mutant
                                                                                        // Original: should pass when sum is exactly zero
                                                                                        // Mutant: will throw exception when sum is exactly zero
                                                                                        try {
                                                                                            // Get the private method using reflection
                                                                                            Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                "addAndCheck", long.class, long.class, String.class);
                                                                                            addAndCheckMethod.setAccessible(true);
                                                                                            
                                                                                            // Invoke the method
                                                                                            long result = (long) addAndCheckMethod.invoke(
                                                                                                null, Long.MIN_VALUE, Long.MAX_VALUE, "overflow test");
                                                                                            
                                                                                            assertEquals(-1, result); // Should reach here in original
                                                                                        } catch (InvocationTargetException e) {
                                                                                            if (e.getTargetException() instanceof ArithmeticException) {
                                                                                                fail("Original should not throw exception for sum=0");
                                                                                            } else {
                                                                                                throw e;
                                                                                            }
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testAddAndCheck_PositiveOverflow1() {
                                                                                        // Both original and mutant should throw
                                                                                        try {
                                                                                            // Get the private method using reflection
                                                                                            Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                "addAndCheck", long.class, long.class, String.class);
                                                                                            addAndCheckMethod.setAccessible(true);
                                                                                            
                                                                                            // Invoke the method
                                                                                            addAndCheckMethod.invoke(null, Long.MAX_VALUE, 1L, "overflow test");
                                                                                            fail("Should throw exception for positive overflow");
                                                                                        } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                            fail("Failed to access private method");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            // Check if the cause is ArithmeticException
                                                                                            Throwable cause = e.getCause();
                                                                                            assertTrue(cause instanceof ArithmeticException);
                                                                                            assertEquals("overflow: add", cause.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testAddAndCheck_NegativeOverflow1() throws Exception {
                                                                                        // Both original and mutant should throw
                                                                                        try {
                                                                                            // Get the private method using reflection
                                                                                            Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                                "addAndCheck", long.class, long.class, String.class);
                                                                                            addAndCheckMethod.setAccessible(true);
                                                                                            
                                                                                            // Invoke the method
                                                                                            addAndCheckMethod.invoke(null, Long.MIN_VALUE, -1L, "overflow test");
                                                                                            fail("Should throw exception for negative overflow");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            // The actual exception is wrapped in InvocationTargetException
                                                                                            Throwable cause = e.getCause();
                                                                                            assertTrue(cause instanceof ArithmeticException);
                                                                                            assertEquals("overflow: add", cause.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckWithZeroAndMinValue() throws Exception {
                                                                                        // Test case where a = 0 and b = Long.MIN_VALUE
                                                                                        // Original behavior: should handle this in negative overflow check
                                                                                        // Mutated behavior: will incorrectly handle in positive check path
                                                                                        
                                                                                        // Get the private method using reflection
                                                                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                        addAndCheck.setAccessible(true);
                                                                                        
                                                                                        // This should work fine since 0 + Long.MIN_VALUE cannot overflow
                                                                                        long result = (long) addAndCheck.invoke(null, 0L, Long.MIN_VALUE, "Should not overflow");
                                                                                        assertEquals(Long.MIN_VALUE, result);
                                                                                        
                                                                                        // Test the symmetric case
                                                                                        result = (long) addAndCheck.invoke(null, Long.MIN_VALUE, 0L, "Should not overflow");
                                                                                        assertEquals(Long.MIN_VALUE, result);
                                                                                        
                                                                                        // Also test with a negative number and 0
                                                                                        result = (long) addAndCheck.invoke(null, -5L, 0L, "Should not overflow");
                                                                                        assertEquals(-5L, result);
                                                                                        
                                                                                        // And with 0 and a positive number
                                                                                        result = (long) addAndCheck.invoke(null, 0L, 5L, "Should not overflow");
                                                                                        assertEquals(5L, result);
                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                    public void testAddAndCheckPositiveOverflow3() throws Exception {
                                                                                        // Test positive overflow case
                                                                                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                        method.setAccessible(true);
                                                                                        method.invoke(null, Long.MAX_VALUE, 1L, "Should overflow");
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckNegativeOverflow3() throws Exception {
                                                                                        // Test negative overflow case
                                                                                        try {
                                                                                            Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                            method.setAccessible(true);
                                                                                            method.invoke(null, Long.MIN_VALUE, -1L, "Should overflow");
                                                                                            fail("Expected ArithmeticException for overflow");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckNormalAddition2() {
                                                                                        // Test normal addition cases
                                                                                        assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                                        assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                                                                        assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckBoundaryCases() {
                                                                                        // Test boundary cases without overflow
                                                                                        assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                                        assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                                        assertEquals(0, MathUtils.addAndCheck(Integer.MAX_VALUE, -Integer.MAX_VALUE));
                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                    public void testAddAndCheckPositiveOverflow4() {
                                                                                        // Test positive overflow
                                                                                        MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                    public void testAddAndCheckNegativeOverflow4() {
                                                                                        // Test negative overflow
                                                                                        MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                                    }

    @Test
                                                                                    public void testAddAndCheckLargeNumbers() {
                                                                                        // Test with large numbers that sum to valid range
                                                                                        assertEquals(Integer.MAX_VALUE - 100, 
                                                                                                   MathUtils.addAndCheck(Integer.MAX_VALUE - 200, 100));
                                                                                        assertEquals(Integer.MIN_VALUE + 100, 
                                                                                                   MathUtils.addAndCheck(Integer.MIN_VALUE + 200, -100));
                                                                                    }

    @Test
                                                                            public void testAddAndCheckNegativeNumbersWithPotentialOverflow1() throws Exception {
                                                                                try {
                                                                                    // Get the private method using reflection
                                                                                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                    addAndCheck.setAccessible(true);
                                                                                    
                                                                                    // Test case that would trigger different behavior between /=2 and >>=1
                                                                                    // with negative numbers
                                                                                    long a = Long.MIN_VALUE + 1;
                                                                                    long b = -1;
                                                                                    
                                                                                    // Should throw ArithmeticException due to overflow
                                                                                    addAndCheck.invoke(null, a, b, "overflow: add");
                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                    assertEquals("overflow: add", e.getCause().getMessage());
                                                                                }
                                                                                
                                                                                try {
                                                                                    // Get the private method using reflection again (could also reuse from above)
                                                                                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                    addAndCheck.setAccessible(true);
                                                                                    
                                                                                    // Another test case with different negative numbers
                                                                                    long a = Long.MIN_VALUE;
                                                                                    long b = Long.MIN_VALUE;
                                                                                    
                                                                                    // Should throw ArithmeticException due to overflow
                                                                                    addAndCheck.invoke(null, a, b, "overflow: add");
                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertTrue(e.getCause() instanceof ArithmeticException);
                                                                                    assertEquals("overflow: add", e.getCause().getMessage());
                                                                                }
                                                                            }

    @Test
                                                                            public void testAddAndCheckPositiveNumbersWithPotentialOverflow() {
                                                                                try {
                                                                                    // Also test positive overflow case for completeness
                                                                                    long a = Long.MAX_VALUE;
                                                                                    long b = 1;
                                                                                    
                                                                                    // Get the private method using reflection
                                                                                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                                                        "addAndCheck", long.class, long.class, String.class);
                                                                                    addAndCheckMethod.setAccessible(true);
                                                                                    
                                                                                    // Should throw ArithmeticException due to overflow
                                                                                    addAndCheckMethod.invoke(null, a, b, "overflow: add");
                                                                                    fail("Expected ArithmeticException for overflow");
                                                                                } catch (ArithmeticException e) {
                                                                                    assertEquals("overflow: add", e.getMessage());
                                                                                } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                    fail("Failed to access private addAndCheck method");
                                                                                } catch (InvocationTargetException e) {
                                                                                    // The actual ArithmeticException will be wrapped in InvocationTargetException
                                                                                    Throwable cause = e.getCause();
                                                                                    if (cause instanceof ArithmeticException) {
                                                                                        assertEquals("overflow: add", cause.getMessage());
                                                                                    } else {
                                                                                        fail("Unexpected exception type: " + cause.getClass().getName());
                                                                                    }
                                                                                }
                                                                            }

    @Test
                                                                            public void testAddAndCheck_PositiveNoOverflow() throws Exception {
                                                                                // Get the private method using reflection
                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                addAndCheckMethod.setAccessible(true);
                                                                                
                                                                                // Invoke the method
                                                                                long result = (long) addAndCheckMethod.invoke(null, 1000L, 2000L, "Should not throw");
                                                                                
                                                                                assertEquals(3000L, result);
                                                                            }

    @Test
                                                                            public void testAddAndCheck_PositiveOverflow2() {
                                                                                try {
                                                                                    Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                    method.setAccessible(true);
                                                                                    method.invoke(null, Long.MAX_VALUE, 1L, "Should throw");
                                                                                    fail("Expected ArithmeticException");
                                                                                } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                    fail("Failed to access private method");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertEquals("Should throw", e.getCause().getMessage());
                                                                                }
                                                                            }

    @Test
                                                                            public void testAddAndCheck_NegativeNoUnderflow() throws Exception {
                                                                                // Get the private method using reflection
                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                addAndCheckMethod.setAccessible(true);
                                                                                
                                                                                // Invoke the method
                                                                                long result = (long) addAndCheckMethod.invoke(null, -1000L, -2000L, "Should not throw");
                                                                                
                                                                                assertEquals(-3000L, result);
                                                                            }

    @Test
                                                                            public void testAddAndCheck_NegativeUnderflow() {
                                                                                try {
                                                                                    Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                    method.setAccessible(true);
                                                                                    method.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
                                                                                    fail("Expected ArithmeticException");
                                                                                } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                    fail("Failed to access private method");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertEquals("Should throw", e.getCause().getMessage());
                                                                                }
                                                                            }

    @Test
                                                                            public void testAddAndCheck_MixedSigns() throws Exception {
                                                                                // Get the private method using reflection
                                                                                java.lang.reflect.Method addAndCheck = MathUtils.class.getDeclaredMethod(
                                                                                    "addAndCheck", long.class, long.class, String.class);
                                                                                addAndCheck.setAccessible(true);
                                                                                
                                                                                // Test case 1: negative + positive
                                                                                long result = (long) addAndCheck.invoke(null, -1000L, 2000L, "Should not throw");
                                                                                assertEquals(1000L, result);
                                                                                
                                                                                // Test case 2: positive + negative
                                                                                result = (long) addAndCheck.invoke(null, 1000L, -2000L, "Should not throw");
                                                                                assertEquals(-1000L, result);
                                                                            }

    @Test
                                                                            public void testAddAndCheck_SymmetricCase() throws Exception {
                                                                                // Get the private method using reflection
                                                                                Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                addAndCheckMethod.setAccessible(true);
                                                                                
                                                                                // Invoke the method
                                                                                long result = (long) addAndCheckMethod.invoke(null, 2000L, 1000L, "Should not throw");
                                                                                
                                                                                assertEquals(3000L, result);
                                                                            }

    @Test
                                                                            public void testAddAndCheck_BoundaryCases1() throws Exception {
                                                                                // Get the private method using reflection
                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                addAndCheck.setAccessible(true);
                                                                                
                                                                                // Just below overflow
                                                                                long result = (long) addAndCheck.invoke(null, Long.MAX_VALUE - 10, 9L, "Should not throw");
                                                                                assertEquals(Long.MAX_VALUE - 1, result);
                                                                                
                                                                                // Just above underflow
                                                                                result = (long) addAndCheck.invoke(null, Long.MIN_VALUE + 10, -9L, "Should not throw");
                                                                                assertEquals(Long.MIN_VALUE + 1, result);
                                                                            }

    @Test
                                                                            public void testAddAndCheck_ZeroCases() throws Exception {
                                                                                // Get the private method via reflection
                                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                                addAndCheck.setAccessible(true);
                                                                                
                                                                                // Test cases
                                                                                long result = (long) addAndCheck.invoke(null, 0L, 0L, "Should not throw");
                                                                                assertEquals(0L, result);
                                                                                
                                                                                result = (long) addAndCheck.invoke(null, 0L, Long.MAX_VALUE, "Should not throw");
                                                                                assertEquals(Long.MAX_VALUE, result);
                                                                                
                                                                                result = (long) addAndCheck.invoke(null, 0L, Long.MIN_VALUE, "Should not throw");
                                                                                assertEquals(Long.MIN_VALUE, result);
                                                                            }

    @Test
                                                                        public void testAddAndCheckExceptionMessage() {
                                                                            // Verify the exact exception message
                                                                            try {
                                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                                                                fail("Expected ArithmeticException");
                                                                            } catch (ArithmeticException e) {
                                                                                assertEquals("overflow: add", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testAddAndCheckWithNegativeOddNumber() {
                                                                            // This test will detect the difference between /= and >>= for negative odd numbers
                                                                            int x = -5;
                                                                            int y = 0;
                                                                            
                                                                            // The original behavior with /= 2 would give -2 for -5/2
                                                                            // The mutated behavior with >>= 1 would give -3 for -5 >> 1
                                                                            // We need to test if any internal calculations use the correct operation
                                                                            
                                                                            // Since we can't see the exact usage of the mutated operation in the method,
                                                                            // we'll test the overall behavior with values that would be affected
                                                                            
                                                                            // Test with values that would trigger internal calculations
                                                                            // that might use the mutated operation
                                                                            int result = MathUtils.addAndCheck(Integer.MIN_VALUE + 1, 0);
                                                                            assertEquals(Integer.MIN_VALUE + 1, result);
                                                                            
                                                                            result = MathUtils.addAndCheck(-3, -2);
                                                                            assertEquals(-5, result);
                                                                            
                                                                            // Test boundary cases
                                                                            result = MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1);
                                                                            assertEquals(Integer.MAX_VALUE, result);
                                                                            
                                                                            result = MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1);
                                                                            assertEquals(Integer.MIN_VALUE, result);
                                                                        }

    @Test(expected = ArithmeticException.class)
                                                                        public void testAddAndCheckOverflowPositive1() {
                                                                            MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                                        }

    @Test(expected = ArithmeticException.class)
                                                                        public void testAddAndCheckOverflowNegative1() {
                                                                            MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                                        }

    @Test
                                                                        public void testAddAndCheckNormalCases() {
                                                                            assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                            assertEquals(0, MathUtils.addAndCheck(-5, 5));
                                                                            assertEquals(-10, MathUtils.addAndCheck(-7, -3));
                                                                        }

    @Test
                                                                public void testAddAndCheckNegativeOverflow5() throws Exception {
                                                                    // Get the private method using reflection
                                                                    Method addAndCheck = MathUtils.class.getDeclaredMethod(
                                                                        "addAndCheck", long.class, long.class, String.class);
                                                                    addAndCheck.setAccessible(true);
                                                                    
                                                                    // Test case that would detect the t >>= 1 mutation
                                                                    // Using Long.MIN_VALUE and -1 to trigger different behavior between /=2 and >>=1
                                                                    try {
                                                                        addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "overflow: add");
                                                                        fail("Expected ArithmeticException for overflow");
                                                                    } catch (InvocationTargetException e) {
                                                                        assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                                                                    }
                                                                    
                                                                    // Additional test case with values that would behave differently
                                                                    try {
                                                                        long val = Long.MIN_VALUE/2 - 1;
                                                                        addAndCheck.invoke(null, val, val, "overflow: add");
                                                                        fail("Expected ArithmeticException for overflow");
                                                                    } catch (InvocationTargetException e) {
                                                                        assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                                                                    }
                                                                    
                                                                    // Test with regular values that should work
                                                                    assertEquals(0L, addAndCheck.invoke(null, -1L, 1L, "overflow: add"));
                                                                    assertEquals(Long.MAX_VALUE-1, 
                                                                        addAndCheck.invoke(null, Long.MAX_VALUE, -1L, "overflow: add"));
                                                                }

    @Test
                                                                public void testAddAndCheckNegativeEvenNumbers() throws Exception {
                                                                    // Test with even negative numbers (should behave same with both operations)
                                                                    long a = Long.MIN_VALUE;  // Even negative number
                                                                    long b = -2L;
                                                                    
                                                                    // Get the private method via reflection
                                                                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                    addAndCheck.setAccessible(true);
                                                                    
                                                                    try {
                                                                        long result = (long) addAndCheck.invoke(null, a, b, "Should overflow");
                                                                        fail("Expected ArithmeticException for negative overflow");
                                                                    } catch (InvocationTargetException e) {
                                                                        assertTrue(e.getCause() instanceof ArithmeticException);
                                                                        assertEquals("Should overflow", e.getCause().getMessage());
                                                                    }
                                                                }

    @Test
                                                            public void testAddAndCheckNegativeOddNumbers() throws Exception {
                                                                // Get the private addAndCheck method via reflection
                                                                Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                                addAndCheck.setAccessible(true);
                                                                
                                                                // Test case where mutation would be detected
                                                                // Adding two negative numbers where one is odd
                                                                long a = Long.MIN_VALUE + 1;  // Odd negative number
                                                                long b = -1L;
                                                                
                                                                try {
                                                                    long result = (long) addAndCheck.invoke(null, a, b, "Should overflow");
                                                                    // If we get here, the test should fail as we expect overflow
                                                                    fail("Expected ArithmeticException for negative overflow");
                                                                } catch (InvocationTargetException e) {
                                                                    // Expected behavior
                                                                    org.hamcrest.MatcherAssert.assertThat(((ArithmeticException)e.getCause()).getMessage(), 
                                                                        org.hamcrest.CoreMatchers.is("Should overflow"));
                                                                }
                                                                
                                                                // Additional test case with different odd negative
                                                                try {
                                                                    long result = (long) addAndCheck.invoke(null, -3L, Long.MIN_VALUE, "Should overflow");
                                                                    fail("Expected ArithmeticException for negative overflow");
                                                                } catch (InvocationTargetException e) {
                                                                    org.hamcrest.MatcherAssert.assertThat(((ArithmeticException)e.getCause()).getMessage(), 
                                                                        org.hamcrest.CoreMatchers.is("Should overflow"));
                                                                }
                                                            }

    @Test
                                                            public void testAddAndCheck_NoOverflow() {
                                                                // Test normal addition without overflow
                                                                assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                                                assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheck_PositiveOverflow3() {
                                                                // Test addition that would exceed Integer.MAX_VALUE
                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheck_NegativeOverflow2() {
                                                                // Test addition that would exceed Integer.MIN_VALUE
                                                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                            }

    @Test
                                                            public void testAddAndCheck_BoundaryCases2() {
                                                                // Test boundary cases
                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                                assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                                                            }

    @Test
                                                        public void testFactorialLoopInitialization() {
                                                            // Test factorial for n=2 - this would reveal if loop starts at 1 instead of 2
                                                            // While mathematically same, we can verify the number of multiplications
                                                            // by mocking or spying if available, but with pure JUnit4 we can only check results
                                                            
                                                            // For factorial, starting at 1 vs 2 doesn't change result, so this mutant is actually
                                                            // equivalent and can't be killed by output verification alone
                                                            // This explains why it survived
                                                            
                                                            // However, if we had access to internal state or could verify operations,
                                                            // we might detect the extra multiplication
                                                            
                                                            // Since we can't, and given the method signatures, I'll provide a test
                                                            // that would catch if the loop was completely broken (e.g., wrong operator)
                                                            
                                                            assertEquals(1, MathUtils.factorial(0));
                                                            assertEquals(1, MathUtils.factorial(1));
                                                            assertEquals(2, MathUtils.factorial(2));
                                                            assertEquals(6, MathUtils.factorial(3));
                                                            assertEquals(24, MathUtils.factorial(4));
                                                            
                                                            // The mutant would pass these tests, which explains its survival
                                                            // To actually catch this, we'd need implementation details or operation counting
                                                            
                                                            // Alternative approach - test exception case:
                                                            try {
                                                                MathUtils.factorial(-1);
                                                                fail("Should have thrown IllegalArgumentException");
                                                            } catch (IllegalArgumentException e) {
                                                                // expected
                                                            }
                                                        }

    @Test
                                                    public void testAddAndCheck5() throws Exception {
                                                        // Get the private method using reflection
                                                        Method addAndCheckLong = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                        addAndCheckLong.setAccessible(true);
                                                        
                                                        // Test symmetry property
                                                        assertEquals(5L, addAndCheckLong.invoke(null, 2L, 3L, "msg"));
                                                        assertEquals(5L, addAndCheckLong.invoke(null, 3L, 2L, "msg"));
                                                        
                                                        // Test opposite signs (always safe)
                                                        assertEquals(-1L, addAndCheckLong.invoke(null, -3L, 2L, "msg"));
                                                        assertEquals(1L, addAndCheckLong.invoke(null, 3L, -2L, "msg"));
                                                        
                                                        // Test negative overflow boundary
                                                        assertEquals(Long.MIN_VALUE, addAndCheckLong.invoke(null, Long.MIN_VALUE + 1, -1L, "msg"));
                                                        
                                                        // Test positive overflow boundary
                                                        assertEquals(Long.MAX_VALUE, addAndCheckLong.invoke(null, Long.MAX_VALUE - 1, 1L, "msg"));
                                                        
                                                        // Test both negative numbers
                                                        assertEquals(-5L, addAndCheckLong.invoke(null, -2L, -3L, "msg"));
                                                        
                                                        // Test both positive numbers
                                                        assertEquals(5L, addAndCheckLong.invoke(null, 2L, 3L, "msg"));
                                                    }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckPositiveOverflow5() throws Exception {
                                                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                        method.setAccessible(true);
                                                        method.invoke(null, Long.MAX_VALUE, 1L, "Should overflow");
                                                    }

    @Test
                                                    public void testAddAndCheckNegativeOverflow6() throws Exception {
                                                        try {
                                                            Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                            method.setAccessible(true);
                                                            method.invoke(null, Long.MIN_VALUE, -1L, "Should underflow");
                                                            fail("Expected ArithmeticException for underflow");
                                                        } catch (InvocationTargetException e) {
                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                        }
                                                    }

    @Test
                                                    public void testAddAndCheckMaxPlusMax() throws Exception {
                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                        addAndCheckMethod.setAccessible(true);
                                                        try {
                                                            addAndCheckMethod.invoke(null, Long.MAX_VALUE, Long.MAX_VALUE, "Should overflow");
                                                            fail("Expected ArithmeticException");
                                                        } catch (InvocationTargetException e) {
                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                        }
                                                    }

    @Test
                                                    public void testAddAndCheckMinPlusMin() throws Exception {
                                                        // Get the private method using reflection
                                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod(
                                                            "addAndCheck", long.class, long.class, String.class);
                                                        addAndCheckMethod.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        try {
                                                            addAndCheckMethod.invoke(null, Long.MIN_VALUE, Long.MIN_VALUE, "Should underflow");
                                                            fail("Expected ArithmeticException for underflow");
                                                        } catch (InvocationTargetException e) {
                                                            assertEquals(ArithmeticException.class, e.getCause().getClass());
                                                        }
                                                    }

    @Test
                                                    public void testAddAndCheckBoundaryNoOverflow() throws Exception {
                                                        // Get the private method using reflection
                                                        Class<?> mathUtilsClass = Class.forName("org.apache.commons.math.util.MathUtils");
                                                        Method addAndCheckMethod = mathUtilsClass.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                        addAndCheckMethod.setAccessible(true);
                                                        
                                                        // These should not throw exceptions
                                                        addAndCheckMethod.invoke(null, Long.MAX_VALUE - 1, 1, "msg");
                                                        addAndCheckMethod.invoke(null, Long.MIN_VALUE + 1, -1, "msg");
                                                    }

    @Test
                                                public void testAddAndCheckDetectsSumVsMaxMutant() {
                                                    // Test case where sum != max of absolute values
                                                    int a = 5;
                                                    int b = 3;
                                                    
                                                    // Original should return sum (8), mutant would return max(5,3)=5
                                                    assertEquals(8, MathUtils.addAndCheck(a, b));
                                                    
                                                    // Test with negative numbers
                                                    int c = -4;
                                                    int d = -6;
                                                    // Original should return -10, mutant would return max(4,6)=6
                                                    assertEquals(-10, MathUtils.addAndCheck(c, d));
                                                    
                                                    // Test with mixed signs
                                                    int e = 7;
                                                    int f = -2;
                                                    // Original should return 5, mutant would return max(7,2)=7
                                                    assertEquals(5, MathUtils.addAndCheck(e, f));
                                                    
                                                    // Edge case where values are equal
                                                    int g = 10;
                                                    int h = 10;
                                                    // Original returns 20, mutant would return 10
                                                    assertEquals(20, MathUtils.addAndCheck(g, h));
                                                }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckDetectsOverflow() {
                                                        // This test case will catch the mutant because:
                                                        // Original: Math.abs(1) + Math.abs(Integer.MAX_VALUE) = 1 + 2147483647 = 2147483648 (overflows)
                                                        // Mutant: Math.max(Math.abs(1), Math.abs(Integer.MAX_VALUE)) = 2147483647 (no overflow detected)
                                                        // The original would throw ArithmeticException, mutant would not
                                                        MathUtils.addAndCheck(1, Integer.MAX_VALUE);
                                                    }

    @Test(expected = ArithmeticException.class)
                                                    public void testAddAndCheckDetectsNegativeOverflow() {
                                                        // Similarly for negative overflow case:
                                                        // Original: Math.abs(-1) + Math.abs(Integer.MIN_VALUE) = 1 + 2147483648 = 2147483649 (overflows)
                                                        // Mutant: Math.max(Math.abs(-1), Math.abs(Integer.MIN_VALUE)) = 2147483648 (no overflow detected)
                                                        MathUtils.addAndCheck(-1, Integer.MIN_VALUE);
                                                    }

    @Test
                                                    public void testAddAndCheckNormalCase() {
                                                        // Test normal case that shouldn't overflow
                                                        assertEquals(3, MathUtils.addAndCheck(1, 2));
                                                    }

    @Test
                                            public void testAddAndCheckReturnsSumNotMax() {
                                                // Test with positive numbers where sum != max
                                                long result1 = MathUtils.addAndCheck(2L, 3L);
                                                assertEquals(5L, result1); // 2+3=5, not max(2,3)=3
                                                
                                                // Test with negative numbers where sum != max
                                                long result2 = MathUtils.addAndCheck(-2L, -3L);
                                                assertEquals(-5L, result2); // -2+-3=-5, not max(2,3)=3
                                                
                                                // Test with zero and positive
                                                long result3 = MathUtils.addAndCheck(0L, 5L);
                                                assertEquals(5L, result3); // 0+5=5, not max(0,5)=5
                                                // Note: This case wouldn't catch the mutant since sum equals max
                                                
                                                // Test with equal positive numbers
                                                long result4 = MathUtils.addAndCheck(4L, 4L);
                                                assertEquals(8L, result4); // 4+4=8, not max(4,4)=4
                                                
                                                // Test with one positive and one negative
                                                long result5 = MathUtils.addAndCheck(-3L, 5L);
                                                assertEquals(2L, result5); // -3+5=2, not max(3,5)=5
                                            }

    @Test
                                            public void testGcdWithZero1() {
                                                // Test case where one number is 0
                                                // Original behavior: gcd(0, x) should return x
                                                // Mutant behavior: might return incorrect value when u=0
                                                
                                                // Test gcd(0, positive)
                                                assertEquals(5, MathUtils.gcd(0, 5));
                                                
                                                // Test gcd(positive, 0)
                                                assertEquals(5, MathUtils.gcd(5, 0));
                                                
                                                // Test gcd(0, 0) - edge case
                                                assertEquals(0, MathUtils.gcd(0, 0));
                                                
                                                // Test gcd(0, negative) - should return absolute value
                                                assertEquals(5, MathUtils.gcd(0, -5));
                                            }

    @Test
                                            public void testGcdWithZero2() {
                                                // Test case where one number is 0
                                                // Original behavior: gcd(u, 0) where u > 0 should return u
                                                // Mutated behavior might handle 0 differently
                                                int result1 = MathUtils.gcd(5, 0);
                                                assertEquals(5, result1);
                                                
                                                int result2 = MathUtils.gcd(0, 5);
                                                assertEquals(5, result2);
                                                
                                                // Test case where both numbers are 0
                                                // Should return 0 or throw exception depending on implementation
                                                int result3 = MathUtils.gcd(0, 0);
                                                assertEquals(0, result3);
                                                
                                                // Test case with negative number and 0
                                                int result4 = MathUtils.gcd(-5, 0);
                                                assertEquals(5, result4);
                                                
                                                int result5 = MathUtils.gcd(0, -5);
                                                assertEquals(5, result5);
                                            }

    @Test
                                    public void testAddAndCheckOverflowDetection1() throws Exception {
                                        // Get the private method using reflection
                                        Method addAndCheck = MathUtils.class.getDeclaredMethod(
                                            "addAndCheck", long.class, long.class, String.class);
                                        addAndCheck.setAccessible(true);
                                        
                                        // Test normal addition without overflow
                                        assertEquals(5L, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
                                        
                                        // Test positive overflow (Long.MAX_VALUE + 1)
                                        try {
                                            addAndCheck.invoke(null, Long.MAX_VALUE, 1L, "overflow: add");
                                            fail("Expected ArithmeticException for positive overflow");
                                        } catch (InvocationTargetException e) {
                                            assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                                        }
                                        
                                        // Test negative overflow (Long.MIN_VALUE + (-1))
                                        try {
                                            addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "overflow: add");
                                            fail("Expected ArithmeticException for negative overflow");
                                        } catch (InvocationTargetException e) {
                                            assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                                        }
                                        
                                        // Test edge case that would pass mutated condition but fail original
                                        try {
                                            addAndCheck.invoke(null, Long.MAX_VALUE, Long.MIN_VALUE, "overflow: add");
                                        } catch (InvocationTargetException e) {
                                            fail("Should not throw exception for Long.MAX_VALUE + Long.MIN_VALUE");
                                        }
                                    }

    @Test
                                    public void testGcdWithNegativeNumbers1() {
                                        // Test case where mutation would show different behavior
                                        int a = -12;
                                        int b = 18;
                                        
                                        // Original behavior (using division): gcd(-12, 18) = 6
                                        // Mutated behavior (using shift): might produce different result with negatives
                                        int result = MathUtils.gcd(a, b);
                                        
                                        assertEquals("GCD should work correctly with negative numbers", 6, result);
                                        
                                        // Additional test case with two negative numbers
                                        int c = -24;
                                        int d = -36;
                                        result = MathUtils.gcd(c, d);
                                        assertEquals("GCD should work correctly with two negative numbers", 12, result);
                                        
                                        // Test case with one negative and one positive
                                        int e = -7;
                                        int f = 21;
                                        result = MathUtils.gcd(e, f);
                                        assertEquals("GCD should work correctly with one negative and one positive", 7, result);
                                    }

    @Test
                                    public void testGcdWithNegativeOddNumbers() {
                                        // Test case that would show difference between /=2 and >>=1
                                        // For -5 and -15:
                                        // Original (/=2): 
                                        //   gcd(-5,-15) -> gcd(-15, -5) -> gcd(-5, 0) -> 5
                                        // Mutant (>>=1):
                                        //   Might follow different path due to different rounding
                                        
                                        int result = MathUtils.gcd(-5, -15);
                                        assertEquals(5, result);
                                        
                                        // Another case with odd negative numbers
                                        result = MathUtils.gcd(-9, -27);
                                        assertEquals(9, result);
                                        
                                        // Mixed signs
                                        result = MathUtils.gcd(-21, 14);
                                        assertEquals(7, result);
                                        
                                        // Larger numbers
                                        result = MathUtils.gcd(-123456789, 987654321);
                                        assertEquals(9, result);
                                    }

    @Test
                            public void testAddAndCheckWithNegativeNumbers() {
                                try {
                                    // Get the private method using reflection
                                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                    addAndCheck.setAccessible(true);
                                    
                                    // Test case where u /= 2 and u >>= 1 would produce different intermediate results
                                    // Using values that would trigger the internal overflow check with negative numbers
                                    long a = Long.MIN_VALUE + 1;
                                    long b = Long.MIN_VALUE + 1;
                                    
                                    // This should throw ArithmeticException("overflow: add")
                                    addAndCheck.invoke(null, a, b, "overflow: add");
                                    fail("Expected ArithmeticException for overflow");
                                } catch (ArithmeticException e) {
                                    assertEquals("overflow: add", e.getMessage());
                                } catch (Exception e) {
                                    fail("Unexpected exception: " + e);
                                }
                                
                                try {
                                    // Get the private method again (could also reuse from above)
                                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                    addAndCheck.setAccessible(true);
                                    
                                    // Another test case with different negative numbers
                                    long c = -9223372036854775807L; // Long.MIN_VALUE + 1
                                    long d = -9223372036854775807L;
                                    
                                    addAndCheck.invoke(null, c, d, "overflow: add");
                                    fail("Expected ArithmeticException for overflow");
                                } catch (ArithmeticException e) {
                                    assertEquals("overflow: add", e.getMessage());
                                } catch (Exception e) {
                                    fail("Unexpected exception: " + e);
                                }
                            }

    @Test(expected = ArithmeticException.class)
                            public void testAddAndCheckPositiveOverflow6() {
                                // Should overflow MAX_VALUE
                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                            }

    @Test(expected = ArithmeticException.class)
                            public void testAddAndCheckNegativeOverflow7() {
                                // Should overflow MIN_VALUE
                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                            }

    @Test(expected = ArithmeticException.class)
                            public void testAddAndCheckLargePositiveOverflow1() {
                                // Large overflow case
                                MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MAX_VALUE);
                            }

    @Test(expected = ArithmeticException.class)
                            public void testAddAndCheckLargeNegativeOverflow1() {
                                // Large negative overflow case
                                MathUtils.addAndCheck(Integer.MIN_VALUE, Integer.MIN_VALUE);
                            }

    @Test
                    public void testAddAndCheckCrossBoundaryNoOverflow() {
                        // Cases crossing from negative to positive without overflow
                        assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                        assertEquals(-1, MathUtils.addAndCheck(Integer.MIN_VALUE, Integer.MAX_VALUE));
                    }

    @Test
                    public void testAddAndCheckNegativeOverflow8() throws Exception {
                        // Get the private method using reflection
                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                        addAndCheck.setAccessible(true);
                        
                        // Test case that would differentiate between /=2 and >>=1
                        // Using Long.MIN_VALUE which is -2^63
                        long a = Long.MIN_VALUE;
                        long b = Long.MIN_VALUE;
                        
                        try {
                            addAndCheck.invoke(null, a, b, "overflow: add");
                            fail("Expected ArithmeticException for overflow");
                        } catch (InvocationTargetException e) {
                            assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                        }
                        
                        // Additional test case with values that would behave differently
                        // when using division vs bit shift for overflow detection
                        long c = -9223372036854775807L; // Long.MIN_VALUE + 1
                        long d = -1L;
                        
                        try {
                            addAndCheck.invoke(null, c, d, "overflow: add");
                            fail("Expected ArithmeticException for overflow");
                        } catch (InvocationTargetException e) {
                            assertEquals("overflow: add", ((ArithmeticException)e.getCause()).getMessage());
                        }
                    }

    @Test
                    public void testAddAndCheckWithNegativeOddNumbers1() throws Exception {
                        // Get the private method
                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                        addAndCheck.setAccessible(true);
                        
                        // Test case that would reveal difference between /= 2 and >>= 1
                        long a = -5;
                        long b = -3;
                        
                        try {
                            long result = (Long)addAndCheck.invoke(null, a, b, "Overflow occurred");
                            assertEquals(-8, result);
                        } catch (InvocationTargetException e) {
                            if (e.getTargetException() instanceof ArithmeticException) {
                                fail("Unexpected overflow with negative numbers");
                            }
                            throw e;
                        }
                        
                        // Test boundary case
                        a = Long.MIN_VALUE + 1;
                        b = -2;
                        try {
                            long result = (Long)addAndCheck.invoke(null, a, b, "Overflow occurred");
                            assertEquals(Long.MIN_VALUE - 1, result);
                        } catch (InvocationTargetException e) {
                            if (e.getTargetException() instanceof ArithmeticException) {
                                fail("Unexpected overflow with negative numbers");
                            }
                            throw e;
                        }
                    }

    @Test
                    public void testAddAndCheckNegativeOverflowEdgeCases() throws Exception {
                        // Get the private method using reflection
                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                        addAndCheck.setAccessible(true);
                        
                        // Test cases that would stress the negative overflow detection
                        // which might be affected by the mutation
                        long a = Long.MIN_VALUE;
                        long b = -1;
                        
                        try {
                            addAndCheck.invoke(null, a, b, "Should overflow");
                            fail("Expected ArithmeticException for overflow");
                        } catch (InvocationTargetException e) {
                            assertEquals("Should overflow", ((ArithmeticException)e.getCause()).getMessage());
                        }
                        
                        // Test case where values are just below overflow threshold
                        a = Long.MIN_VALUE + 1;
                        b = -1;
                        try {
                            long result = (Long)addAndCheck.invoke(null, a, b, "Overflow occurred");
                            assertEquals(Long.MIN_VALUE, result);
                        } catch (InvocationTargetException e) {
                            fail("Unexpected overflow with negative numbers");
                        }
                    }

    @Test
                public void testAddAndCheckWithinRange() {
                    // Normal cases within integer range
                    org.hamcrest.MatcherAssert.assertThat(MathUtils.addAndCheck(1, 2), org.hamcrest.CoreMatchers.is(3));
                    org.hamcrest.MatcherAssert.assertThat(MathUtils.addAndCheck(-1, -2), org.hamcrest.CoreMatchers.is(-3));
                    org.hamcrest.MatcherAssert.assertThat(MathUtils.addAndCheck(0, 0), org.hamcrest.CoreMatchers.is(0));
                    org.hamcrest.MatcherAssert.assertThat(MathUtils.addAndCheck(100, -50), org.hamcrest.CoreMatchers.is(50));
                }

    @Test
    public void testAddAndCheckAtBoundaryNoOverflow() {
        // Boundary cases that don't overflow
        assertThat(org.apache.commons.math.util.MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1), 
                 org.hamcrest.CoreMatchers.is(Integer.MAX_VALUE));
        assertThat(org.apache.commons.math.util.MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1), 
                 org.hamcrest.CoreMatchers.is(Integer.MIN_VALUE));
        assertThat(org.apache.commons.math.util.MathUtils.addAndCheck(Integer.MAX_VALUE / 2, Integer.MAX_VALUE / 2), 
                 org.hamcrest.CoreMatchers.is(Integer.MAX_VALUE - 1));
    }


}
