package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.util.MathUtils;
 
public class MultidimensionalCounterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testGetCounts_SingleDimensionCounter() {
                                            // Test with 1D counter (size = 5)
                                            MultidimensionalCounter singleDimCounter = new MultidimensionalCounter(new int[]{5});
                                            
                                            int[] expected1 = {0};
                                            assertArrayEquals(expected1, singleDimCounter.getCounts(0));
                                            
                                            int[] expected2 = {4};
                                            assertArrayEquals(expected2, singleDimCounter.getCounts(4));
                                        }

    @Test
                                        public void testGetCounts_TwoDimensionCounter() {
                                            // Test with 2D counter (size = 2x3)
                                            MultidimensionalCounter twoDimCounter = new MultidimensionalCounter(new int[]{2, 3});
                                            
                                            int[] expected1 = {0, 0};
                                            assertArrayEquals(expected1, twoDimCounter.getCounts(0));
                                            
                                            int[] expected2 = {0, 2};
                                            assertArrayEquals(expected2, twoDimCounter.getCounts(2));
                                            
                                            int[] expected3 = {1, 1};
                                            assertArrayEquals(expected3, twoDimCounter.getCounts(4));
                                        }

    @Test
                                        public void testGetCounts_AllDimensionsSizeOne() {
                                            // Test with counter where all dimensions have size 1 (3D)
                                            MultidimensionalCounter allOnesCounter = new MultidimensionalCounter(new int[]{1, 1, 1});
                                            
                                            int[] expected = {0, 0, 0};
                                            assertArrayEquals(expected, allOnesCounter.getCounts(0));
                                            
                                            thrown.expect(OutOfRangeException.class);
                                            thrown.expectMessage("1 out of [0, 1) range");
                                            allOnesCounter.getCounts(1);
                                        }

    @Test
                                public void testGetCounts_ValidIndex() {
                                    // Create a MultidimensionalCounter instance with appropriate dimensions
                                    int[] sizes = {2, 3, 4}; // Example sizes that would work with the test cases
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    // Test first index
                                    int[] expected1 = {0, 0, 0};
                                    assertArrayEquals(expected1, counter.getCounts(0));
                                    
                                    // Test middle index
                                    int[] expected2 = {1, 1, 2};
                                    assertArrayEquals(expected2, counter.getCounts(18)); // 1*3*4 + 1*4 + 2 = 18
                                    
                                    // Test last index
                                    int[] expected3 = {1, 2, 3};
                                    assertArrayEquals(expected3, counter.getCounts(23));
                                }

    @Test
                                public void testGetCounts_IndexAtDimensionBoundaries() {
                                    // Create a MultidimensionalCounter with dimensions [3, 4, 5] for testing
                                    MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{3, 4, 5});
                                    
                                    // Test boundary between first and second dimension
                                    int[] expected1 = {0, 1, 0};
                                    assertArrayEquals(expected1, counter.getCounts(4)); // 0*3*4 + 1*4 + 0 = 4
                                    
                                    // Test boundary between second and third dimension
                                    int[] expected2 = {0, 0, 3};
                                    assertArrayEquals(expected2, counter.getCounts(3));
                                }

    @Test
                                public void testGetCounts_NegativeIndex() {
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(OutOfRangeException.class);
                                    thrown.expectMessage("-1 out of [0, 24) range");
                                    MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{24});
                                    counter.getCounts(-1);
                                }

    @Test
                                public void testGetCounts_IndexEqualToTotalSize() {
                                    MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{24});
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(OutOfRangeException.class);
                                    thrown.expectMessage("24 out of [0, 24) range");
                                    counter.getCounts(24);
                                }

    @Test
                                public void testGetCounts_IndexGreaterThanTotalSize() {
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(OutOfRangeException.class);
                                    thrown.expectMessage("30 out of [0, 24) range");
                                    MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{24});
                                    counter.getCounts(30);
                                }

    @Test
                                public void testGetCounts_WithEmptyCounter() {
                                    // Create a counter with all sizes = 1
                                    int[] singleSize = new int[]{1, 1, 1};
                                    MultidimensionalCounter emptyCounter = new MultidimensionalCounter(singleSize);
                                    
                                    // Call getCounts() with a valid index (0 in this case)
                                    int[] result = emptyCounter.getCounts(0);
                                    
                                    assertNotNull(result);
                                    assertEquals(singleSize.length, result.length);
                                    for (int count : result) {
                                        assertEquals(0, count); // Assuming initial counts are 0
                                    }
                                }

    @Test
                            public void testGetCounts_ImmutableOriginal() {
                                // Create a MultidimensionalCounter instance with sample sizes
                                int[] sizes = {1, 2, 3}; // Example sizes
                                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                
                                // Use a valid index (0 in this case) to get counts
                                int[] originalCounts = counter.getCounts(0);
                                int[] modifiedCounts = counter.getCounts(0);
                                
                                // Modify the returned array
                                modifiedCounts[0] = 999;
                                
                                // Verify original wasn't affected
                                assertNotEquals(modifiedCounts[0], originalCounts[0]);
                                assertEquals(originalCounts[0], counter.getCounts(0)[0]);
                            }

    @Test
        public void testGetCounts_AfterModification() {
            // Create a MultidimensionalCounter instance for testing
            int[] dimensions = {2, 3}; // Example dimensions
            MultidimensionalCounter counter = new MultidimensionalCounter(dimensions);
            
            // Get initial counts
            int[] initialCounts = counter.getCounts(0); // Using index 0 as starting point
            
            // Modify the counter by iterating
            java.util.Iterator<Integer> iterator = counter.iterator();
            if (iterator.hasNext()) {
                iterator.next();
            }
            
            // Get counts after modification
            int[] modifiedCounts = counter.getCounts(0); // Using index 0 again for comparison
            
            // Verify the arrays are different
            org.junit.Assert.assertFalse(java.util.Arrays.equals(initialCounts, modifiedCounts));
            
            // Verify getCounts() returns a new copy each time
            org.junit.Assert.assertNotSame(modifiedCounts, counter.getCounts(0));
        }

    @Test
    public void testGetCounts_ReturnsCopyOfCounter() {
        // Initialize the counter with sample sizes
        int[] sizes = new int[]{2, 3, 4}; // Example dimensions
        MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
        
        // Get the counts using a valid index (0 in this case)
        int[] result = counter.getCounts(0);
        
        // Verify it's not null
        assertNotNull(result);
        
        // Verify it's a copy, not the original array
        int[] firstCall = counter.getCounts(0);
        int[] secondCall = counter.getCounts(0);
        assertNotSame(firstCall, secondCall);
        
        // Verify the length matches the expected dimensions
        assertEquals(sizes.length, result.length);
    }


}
