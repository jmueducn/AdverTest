package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Region.Location;
 
public class SubLineTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                            public void testIntersection_LinesDontIntersect() {
                                                                                                                                                                // Setup
                                                                                                                                                                Line line1 = mock(Line.class);
                                                                                                                                                                Line line2 = mock(Line.class);
                                                                                                                                                                IntervalsSet intervals1 = mock(IntervalsSet.class);
                                                                                                                                                                IntervalsSet intervals2 = mock(IntervalsSet.class);
                                                                                                                                                                
                                                                                                                                                                when(line1.intersection(line2)).thenReturn(null);
                                                                                                                                                                
                                                                                                                                                                SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                                                                                SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                                                                                
                                                                                                                                                                // Test & Verify
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, true));
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, false));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testIntersection_PointOutsideBothSubLines() {
                                                                                                                                                                // Setup
                                                                                                                                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                                                                                                
                                                                                                                                                                Line line1 = mock(Line.class);
                                                                                                                                                                Line line2 = mock(Line.class);
                                                                                                                                                                IntervalsSet intervals1 = mock(IntervalsSet.class);
                                                                                                                                                                IntervalsSet intervals2 = mock(IntervalsSet.class);
                                                                                                                                                                
                                                                                                                                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(intervals1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                                                                                                                when(intervals2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                                                                                                                
                                                                                                                                                                SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                                                                                SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                                                                                
                                                                                                                                                                // Test & Verify
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, true));
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, false));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testIntersection_PointInsideBothSubLines_IncludeEndpoints() {
                                                                                                                                                                // Setup
                                                                                                                                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                                                                                                
                                                                                                                                                                Line line1 = mock(Line.class);
                                                                                                                                                                Line line2 = mock(Line.class);
                                                                                                                                                                IntervalsSet intervals1 = mock(IntervalsSet.class);
                                                                                                                                                                IntervalsSet intervals2 = mock(IntervalsSet.class);
                                                                                                                                                                
                                                                                                                                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(intervals1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                                                                when(intervals2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                                                                
                                                                                                                                                                SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                                                                                SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                                                                                
                                                                                                                                                                // Test & Verify
                                                                                                                                                                assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                                                                                assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testIntersection_PointOnBoundary_IncludeEndpoints() {
                                                                                                                                                                // Setup
                                                                                                                                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                                                                                                
                                                                                                                                                                Line line1 = mock(Line.class);
                                                                                                                                                                Line line2 = mock(Line.class);
                                                                                                                                                                IntervalsSet intervals1 = mock(IntervalsSet.class);
                                                                                                                                                                IntervalsSet intervals2 = mock(IntervalsSet.class);
                                                                                                                                                                
                                                                                                                                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(intervals1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                                                                                                                                when(intervals2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                                                                                                                                
                                                                                                                                                                SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                                                                                SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                                                                                
                                                                                                                                                                // Test & Verify
                                                                                                                                                                assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, false));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testIntersection_MixedLocations_IncludeEndpoints() {
                                                                                                                                                                // Setup
                                                                                                                                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                                                                                                
                                                                                                                                                                Line line1 = mock(Line.class);
                                                                                                                                                                Line line2 = mock(Line.class);
                                                                                                                                                                IntervalsSet intervals1 = mock(IntervalsSet.class);
                                                                                                                                                                IntervalsSet intervals2 = mock(IntervalsSet.class);
                                                                                                                                                                
                                                                                                                                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(intervals1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                                                                when(intervals2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                                                                                                                                
                                                                                                                                                                SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                                                                                SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                                                                                
                                                                                                                                                                // Test & Verify
                                                                                                                                                                assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, false));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testIntersection_OneInsideOneOutside() {
                                                                                                                                                                // Setup
                                                                                                                                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                                                                                                
                                                                                                                                                                Line line1 = mock(Line.class);
                                                                                                                                                                Line line2 = mock(Line.class);
                                                                                                                                                                IntervalsSet intervals1 = mock(IntervalsSet.class);
                                                                                                                                                                IntervalsSet intervals2 = mock(IntervalsSet.class);
                                                                                                                                                                
                                                                                                                                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                                                                when(intervals1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                                                                when(intervals2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                                                                                                                
                                                                                                                                                                SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                                                                                SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                                                                                
                                                                                                                                                                // Test & Verify
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, true));
                                                                                                                                                                assertNull(subLine1.intersection(subLine2, false));
                                                                                                                                                            }

    @Test
                                                                                                                                            public void testGetSegmentsWithPointsOutsideRegion() {
                                                                                                                                                // Setup test data
                                                                                                                                                Line line = mock(Line.class);
                                                                                                                                                IntervalsSet intervalsSet = mock(IntervalsSet.class);
                                                                                                                                                
                                                                                                                                                // Mock the line behavior
                                                                                                                                                Vector3D insidePoint = new Vector3D(1, 1, 1);
                                                                                                                                                Vector3D outsidePoint = new Vector3D(2, 2, 2);
                                                                                                                                                when(line.toSpace(any(Vector1D.class))).thenReturn(insidePoint).thenReturn(outsidePoint);
                                                                                                                                                
                                                                                                                                                // Mock intervals - one valid interval and one that should be filtered out
                                                                                                                                                org.apache.commons.math3.geometry.euclidean.oned.Interval validInterval = 
                                                                                                                                                    new org.apache.commons.math3.geometry.euclidean.oned.Interval(0, 1);
                                                                                                                                                org.apache.commons.math3.geometry.euclidean.oned.Interval invalidInterval = 
                                                                                                                                                    new org.apache.commons.math3.geometry.euclidean.oned.Interval(1, 2);
                                                                                                                                                when(intervalsSet.asList()).thenReturn(java.util.Arrays.asList(validInterval, invalidInterval));
                                                                                                                                                
                                                                                                                                                // Mock checkPoint to return INSIDE for first point, OUTSIDE for second
                                                                                                                                                when(intervalsSet.checkPoint(any(Vector1D.class)))
                                                                                                                                                    .thenReturn(Location.INSIDE)   // For valid interval
                                                                                                                                                    .thenReturn(Location.OUTSIDE); // For invalid interval
                                                                                                                                                
                                                                                                                                                // Create SubLine instance
                                                                                                                                                SubLine subLine = new SubLine(line, intervalsSet);
                                                                                                                                                
                                                                                                                                                // Execute and verify
                                                                                                                                                List<Segment> segments = subLine.getSegments();
                                                                                                                                                
                                                                                                                                                // Should only contain segments from valid intervals
                                                                                                                                                assertEquals(1, segments.size());
                                                                                                                                                
                                                                                                                                                // Verify the segment is from the valid interval
                                                                                                                                                Segment segment = segments.get(0);
                                                                                                                                                assertEquals(insidePoint, segment.getStart());
                                                                                                                                                assertEquals(insidePoint, segment.getEnd());
                                                                                                                                                
                                                                                                                                                // Verify interactions
                                                                                                                                                verify(intervalsSet, times(2)).checkPoint(any(Vector1D.class));
                                                                                                                                            }

    @Test
                                                                                                                            public void testGetSegmentsUsesOwnLineNotSubLine() {
                                                                                                                                // Create two different lines
                                                                                                                                Vector3D p1 = new Vector3D(0, 0, 0);
                                                                                                                                Vector3D p2 = new Vector3D(1, 0, 0);
                                                                                                                                Vector3D p3 = new Vector3D(0, 1, 0);
                                                                                                                                Line line1 = new Line(p1, p2);
                                                                                                                                Line line2 = new Line(p1, p3);
                                                                                                                                
                                                                                                                                // Mock intervals set to return one interval
                                                                                                                                IntervalsSet intervals = mock(IntervalsSet.class);
                                                                                                                                when(intervals.asList()).thenReturn(java.util.Collections.singletonList(
                                                                                                                                    new org.apache.commons.math3.geometry.euclidean.oned.Interval(0, 1)));
                                                                                                                                
                                                                                                                                // Create SubLine with line1
                                                                                                                                SubLine subLine = new SubLine(line1, intervals);
                                                                                                                                
                                                                                                                                // Use reflection to replace the private line field with our spy
                                                                                                                                Line spyLine = spy(line1);
                                                                                                                                try {
                                                                                                                                    Field lineField = SubLine.class.getDeclaredField("line");
                                                                                                                                    lineField.setAccessible(true);
                                                                                                                                    lineField.set(subLine, spyLine);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set private line field via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Call method under test
                                                                                                                                List<Segment> segments = subLine.getSegments();
                                                                                                                                
                                                                                                                                // Verify correct line was used for conversion
                                                                                                                                verify(spyLine, times(2)).toSpace(any(Vector1D.class));
                                                                                                                                verifyNoInteractions(line2); // Ensure other line wasn't used
                                                                                                                                
                                                                                                                                // Verify segments
                                                                                                                                assertEquals(1, segments.size());
                                                                                                                                // Additional assertions on segment positions could be added
                                                                                                                            }

    @Test
                                                                                                                            public void testIntersectionUsesCorrectLineReference() {
                                                                                                                                // Create two different lines
                                                                                                                                Vector3D p1 = new Vector3D(0, 0, 0);
                                                                                                                                Vector3D p2 = new Vector3D(1, 0, 0);
                                                                                                                                Vector3D p3 = new Vector3D(0, 1, 0);
                                                                                                                                Line line1 = new Line(p1, p2);
                                                                                                                                Line line2 = new Line(p1, p3);
                                                                                                                                
                                                                                                                                // Create interval sets covering the full lines
                                                                                                                                IntervalsSet intervals1 = new IntervalsSet(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                                                                                                IntervalsSet intervals2 = new IntervalsSet(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                                                                                                
                                                                                                                                // Create two SubLines with different lines
                                                                                                                                SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                                                SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                                                
                                                                                                                                // They should intersect at point p1
                                                                                                                                Vector3D intersection = subLine1.intersection(subLine2, true);
                                                                                                                                
                                                                                                                                // Verify the intersection point is p1
                                                                                                                                assertEquals(p1, intersection);
                                                                                                                                
                                                                                                                                // The key part: if the mutant is present, it would use line1 instead of subLine2.line
                                                                                                                                // for the coordinate conversion, which would give wrong results for non-parallel lines
                                                                                                                                // This test would fail in that case
                                                                                                                            }

    @Test
                                                                                                            public void testGetSegmentsReturnsCompleteSegmentList() {
                                                                                                                // Setup test data
                                                                                                                Line line = mock(Line.class);
                                                                                                                IntervalsSet intervalsSet = mock(IntervalsSet.class);
                                                                                                                
                                                                                                                // Create mock intervals
                                                                                                                double lower1 = 0.0;
                                                                                                                double upper1 = 1.0;
                                                                                                                double lower2 = 2.0;
                                                                                                                double upper2 = 3.0;
                                                                                                                Interval interval1 = new Interval(lower1, upper1);
                                                                                                                Interval interval2 = new Interval(lower2, upper2);
                                                                                                                List<Interval> intervalList = java.util.Arrays.asList(interval1, interval2);
                                                                                                                when(intervalsSet.asList()).thenReturn(intervalList);
                                                                                                                
                                                                                                                // Mock line conversions
                                                                                                                Vector3D start1 = new Vector3D(0, 0, 0);
                                                                                                                Vector3D end1 = new Vector3D(1, 0, 0);
                                                                                                                Vector3D start2 = new Vector3D(2, 0, 0);
                                                                                                                Vector3D end2 = new Vector3D(3, 0, 0);
                                                                                                                
                                                                                                                when(line.toSpace(new Vector1D(lower1))).thenReturn(start1);
                                                                                                                when(line.toSpace(new Vector1D(upper1))).thenReturn(end1);
                                                                                                                when(line.toSpace(new Vector1D(lower2))).thenReturn(start2);
                                                                                                                when(line.toSpace(new Vector1D(upper2))).thenReturn(end2);
                                                                                                                
                                                                                                                // Create SubLine instance
                                                                                                                SubLine subLine = new SubLine(line, intervalsSet);
                                                                                                                
                                                                                                                // Execute method
                                                                                                                List<Segment> segments = subLine.getSegments();
                                                                                                                
                                                                                                                // Verify results
                                                                                                                assertEquals(2, segments.size());
                                                                                                                
                                                                                                                // Verify first segment
                                                                                                                Segment seg1 = segments.get(0);
                                                                                                                assertSame(start1, seg1.getStart());
                                                                                                                assertSame(end1, seg1.getEnd());
                                                                                                                assertSame(line, seg1.getLine());
                                                                                                                
                                                                                                                // Verify second segment
                                                                                                                Segment seg2 = segments.get(1);
                                                                                                                assertSame(start2, seg2.getStart());
                                                                                                                assertSame(end2, seg2.getEnd());
                                                                                                                assertSame(line, seg2.getLine());
                                                                                                                
                                                                                                                // Verify all intervals were processed
                                                                                                                verify(intervalsSet).asList();
                                                                                                                verify(line, times(4)).toSpace(any(Vector1D.class));
                                                                                                            }

    @Test
                                                                                                public void testGetSegmentsVerifiesPointLocations() {
                                                                                                    // Setup test data
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Line line = mock(org.apache.commons.math3.geometry.euclidean.threed.Line.class);
                                                                                                    org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet = mock(org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet.class);
                                                                                                    
                                                                                                    // Create test intervals
                                                                                                    org.apache.commons.math3.geometry.euclidean.oned.Interval interval1 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(0, 1);
                                                                                                    org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(2, 3);
                                                                                                    java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList = java.util.Arrays.asList(interval1, interval2);
                                                                                                    
                                                                                                    // Mock behaviors
                                                                                                    when(intervalsSet.asList()).thenReturn(intervalList);
                                                                                                    
                                                                                                    // Mock point conversions
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Vector3D start1 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 0, 0);
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Vector3D end1 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0);
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Vector3D start2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2, 0, 0);
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Vector3D end2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(3, 0, 0);
                                                                                                    
                                                                                                    when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0))).thenReturn(start1);
                                                                                                    when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1))).thenReturn(end1);
                                                                                                    when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2))).thenReturn(start2);
                                                                                                    when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(3))).thenReturn(end2);
                                                                                                    
                                                                                                    // Create SubLine instance
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line, intervalsSet);
                                                                                                    
                                                                                                    // Execute method
                                                                                                    java.util.List<org.apache.commons.math3.geometry.euclidean.threed.Segment> segments = subLine.getSegments();
                                                                                                    
                                                                                                    // Verify results
                                                                                                    assertEquals(2, segments.size());
                                                                                                    
                                                                                                    // Verify first segment
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Segment seg1 = segments.get(0);
                                                                                                    assertSame(start1, seg1.getStart());
                                                                                                    assertSame(end1, seg1.getEnd());
                                                                                                    assertSame(line, seg1.getLine());
                                                                                                    
                                                                                                    // Verify second segment
                                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Segment seg2 = segments.get(1);
                                                                                                    assertSame(start2, seg2.getStart());
                                                                                                    assertSame(end2, seg2.getEnd());
                                                                                                    assertSame(line, seg2.getLine());
                                                                                                    
                                                                                                    // Verify all points lie on the line
                                                                                                    for (org.apache.commons.math3.geometry.euclidean.threed.Segment seg : segments) {
                                                                                                        assertEquals(0, line.distance(seg.getStart()), 1e-10);
                                                                                                        assertEquals(0, line.distance(seg.getEnd()), 1e-10);
                                                                                                    }
                                                                                                    
                                                                                                    // Verify mock interactions
                                                                                                    verify(intervalsSet).asList();
                                                                                                    verify(line, times(4)).toSpace(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class));
                                                                                                }

    @Test
                                                                                public void testGetSegmentsShouldProcessAllIntervals() {
                                                                                    // Setup test data
                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Line line = 
                                                                                        mock(org.apache.commons.math3.geometry.euclidean.threed.Line.class);
                                                                                    org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet = 
                                                                                        mock(org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet.class);
                                                                                    
                                                                                    // Create mock intervals
                                                                                    org.apache.commons.math3.geometry.euclidean.oned.Interval interval1 = 
                                                                                        new org.apache.commons.math3.geometry.euclidean.oned.Interval(0, 1);
                                                                                    org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = 
                                                                                        new org.apache.commons.math3.geometry.euclidean.oned.Interval(2, 3);
                                                                                    java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList = 
                                                                                        java.util.Arrays.asList(interval1, interval2);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(intervalsSet.asList()).thenReturn(intervalList);
                                                                                    when(line.toSpace(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class))).thenAnswer(invocation -> {
                                                                                        double x = ((org.apache.commons.math3.geometry.euclidean.oned.Vector1D)invocation.getArguments()[0]).getX();
                                                                                        return new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(x, 0, 0);
                                                                                    });
                                                                                    
                                                                                    // Create SubLine instance
                                                                                    org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine = 
                                                                                        new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line, intervalsSet);
                                                                                    
                                                                                    // Execute method
                                                                                    java.util.List<org.apache.commons.math3.geometry.euclidean.threed.Segment> segments = subLine.getSegments();
                                                                                    
                                                                                    // Verify results
                                                                                    assertEquals(2, segments.size());
                                                                                    
                                                                                    // Verify first segment
                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Segment seg1 = segments.get(0);
                                                                                    assertEquals(0.0, seg1.getStart().getX(), 0.0001);
                                                                                    assertEquals(1.0, seg1.getEnd().getX(), 0.0001);
                                                                                    
                                                                                    // Verify second segment
                                                                                    org.apache.commons.math3.geometry.euclidean.threed.Segment seg2 = segments.get(1);
                                                                                    assertEquals(2.0, seg2.getStart().getX(), 0.0001);
                                                                                    assertEquals(3.0, seg2.getEnd().getX(), 0.0001);
                                                                                    
                                                                                    // Verify all intervals were processed
                                                                                    verify(intervalsSet).asList();
                                                                                    verify(line, times(4)).toSpace(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class));
                                                                                }

    @Test
                                                                        public void testGetSegmentsWithNullInterval() throws Exception {
                                                                            // Setup
                                                                            Line line = mock(Line.class);
                                                                            IntervalsSet intervals = mock(IntervalsSet.class);
                                                                            Interval interval = mock(Interval.class);
                                                                            
                                                                            // Mock behavior to produce null case
                                                                            when(intervals.asList()).thenReturn(java.util.Collections.singletonList(interval));
                                                                            when(interval.getInf()).thenReturn(Double.NEGATIVE_INFINITY);
                                                                            when(line.toSpace(any(Vector1D.class))).thenReturn(null);
                                                                            
                                                                            // Create test object
                                                                            SubLine subLine = new SubLine(line, intervals);
                                                                            
                                                                            // This should throw NPE when mutant is present
                                                                            subLine.getSegments();
                                                                            
                                                                            // Verify mock interactions
                                                                            verify(line, atLeastOnce()).toSpace(any(Vector1D.class));
                                                                        }

    @Test
                                                                public void testGetSegmentsShouldOnlyIncludeValidIntervals() throws Exception {
                                                                    // Setup test data
                                                                    Line line = mock(Line.class);
                                                                    IntervalsSet remainingRegion = mock(IntervalsSet.class);
                                                                    
                                                                    // Create test intervals - one valid, one invalid
                                                                    Interval validInterval = new Interval(1.0, 2.0);
                                                                    Interval invalidInterval = new Interval(3.0, 4.0);
                                                                    
                                                                    // Mock the intervals list
                                                                    when(remainingRegion.asList()).thenReturn(java.util.Arrays.asList(validInterval, invalidInterval));
                                                                    
                                                                    // Mock line conversions
                                                                    Vector3D start1 = new Vector3D(1, 0, 0);
                                                                    Vector3D end1 = new Vector3D(2, 0, 0);
                                                                    when(line.toSpace(new Vector1D(1.0))).thenReturn(start1);
                                                                    when(line.toSpace(new Vector1D(2.0))).thenReturn(end1);
                                                                    
                                                                    // Mock checkPoint to return OUTSIDE for invalid interval
                                                                    when(remainingRegion.checkPoint(any(Vector1D.class)))
                                                                        .thenAnswer(invocation -> {
                                                                            Vector1D point = invocation.getArgument(0);
                                                                            if (point.getX() >= 3.0) {
                                                                                return Location.OUTSIDE;
                                                                            }
                                                                            return Location.INSIDE;
                                                                        });
                                                                    
                                                                    // Create SubLine instance
                                                                    SubLine subLine = new SubLine(line, remainingRegion);
                                                                    
                                                                    // Execute and verify
                                                                    List<Segment> segments = subLine.getSegments();
                                                                    
                                                                    // Should only contain segments from valid interval
                                                                    assertEquals(1, segments.size());
                                                                    assertEquals(start1, segments.get(0).getStart());
                                                                    assertEquals(end1, segments.get(0).getEnd());
                                                                    
                                                                    // Verify interactions
                                                                    verify(line, times(2)).toSpace(any(Vector1D.class));
                                                                    verify(remainingRegion, atLeastOnce()).checkPoint(any(Vector1D.class));
                                                                }

    @Test
                                                        public void testGetSegmentsUsesOwnRegionNotSubLineRegion() {
                                                            // Create mock objects
                                                            Line line = mock(Line.class);
                                                            IntervalsSet ownRegion = mock(IntervalsSet.class);
                                                            IntervalsSet subLineRegion = mock(IntervalsSet.class);
                                                            
                                                            // Create test SubLine with mocked line and region
                                                            SubLine subLine = new SubLine(line, ownRegion);
                                                            
                                                            // Create another SubLine with different region
                                                            SubLine otherSubLine = new SubLine(line, subLineRegion);
                                                            
                                                            // Setup mock behaviors
                                                            Interval interval1 = new Interval(0, 1);
                                                            Interval interval2 = new Interval(2, 3);
                                                            
                                                            // Own region returns interval1
                                                            when(ownRegion.asList()).thenReturn(java.util.Arrays.asList(interval1));
                                                            // Other region returns interval2 (different interval)
                                                            when(subLineRegion.asList()).thenReturn(java.util.Arrays.asList(interval2));
                                                            
                                                            // Mock line conversions
                                                            Vector3D start1 = new Vector3D(0, 0, 0);
                                                            Vector3D end1 = new Vector3D(1, 1, 1);
                                                            Vector3D start2 = new Vector3D(2, 2, 2);
                                                            Vector3D end2 = new Vector3D(3, 3, 3);
                                                            
                                                            when(line.toSpace(new Vector1D(0))).thenReturn(start1);
                                                            when(line.toSpace(new Vector1D(1))).thenReturn(end1);
                                                            when(line.toSpace(new Vector1D(2))).thenReturn(start2);
                                                            when(line.toSpace(new Vector1D(3))).thenReturn(end2);
                                                            
                                                            // Execute and verify
                                                            List<Segment> segments = subLine.getSegments();
                                                            
                                                            // Should only contain segment from own region (interval1)
                                                            assertEquals(1, segments.size());
                                                            assertEquals(start1, segments.get(0).getStart());
                                                            assertEquals(end1, segments.get(0).getEnd());
                                                            
                                                            // Verify no interaction with subLine's region
                                                            verify(subLineRegion, never()).asList();
                                                        }

    @Test
                                                        public void testIntersectionUsesParameterLineNotOwnLine() {
                                                            // Create two different lines
                                                            Vector3D p1 = new Vector3D(0, 0, 0);
                                                            Vector3D p2 = new Vector3D(1, 0, 0);
                                                            Vector3D p3 = new Vector3D(0, 1, 0);
                                                            Line line1 = new Line(p1, p2);
                                                            Line line2 = new Line(p1, p3);
                                                            
                                                            // Create IntervalsSet that covers the whole line
                                                            IntervalsSet interval = new IntervalsSet(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                            
                                                            // Create two SubLines with different lines but same interval
                                                            SubLine subLine1 = new SubLine(line1, interval);
                                                            SubLine subLine2 = new SubLine(line2, interval);
                                                            
                                                            // The intersection should be at origin (0,0,0)
                                                            Vector3D expectedIntersection = p1;
                                                            
                                                            // Test intersection in both directions
                                                            Vector3D intersection1 = subLine1.intersection(subLine2, true);
                                                            Vector3D intersection2 = subLine2.intersection(subLine1, true);
                                                            
                                                            // Verify both intersections are at origin and used correct lines
                                                            assertEquals(expectedIntersection, intersection1);
                                                            assertEquals(expectedIntersection, intersection2);
                                                            
                                                            // The mutant would fail here because it would use the wrong line for conversion,
                                                            // potentially resulting in null or incorrect intersection points
                                                        }

    @Test
                                        public void testGetSegmentsWithMultipleIntervals() {
                                            // Setup test data
                                            org.apache.commons.math3.geometry.euclidean.threed.Line line = 
                                                mock(org.apache.commons.math3.geometry.euclidean.threed.Line.class);
                                            org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet = 
                                                mock(org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet.class);
                                            
                                            // Create mock intervals
                                            org.apache.commons.math3.geometry.euclidean.oned.Interval interval1 = 
                                                new org.apache.commons.math3.geometry.euclidean.oned.Interval(0, 1);
                                            org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = 
                                                new org.apache.commons.math3.geometry.euclidean.oned.Interval(2, 3);
                                            java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList = 
                                                java.util.Arrays.asList(interval1, interval2);
                                            
                                            // Mock behavior
                                            when(intervalsSet.asList()).thenReturn(intervalList);
                                            
                                            // Mock line conversion
                                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D start1 = 
                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 0, 0);
                                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D end1 = 
                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0);
                                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D start2 = 
                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2, 0, 0);
                                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D end2 = 
                                                new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(3, 0, 0);
                                            
                                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0))).thenReturn(start1);
                                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1))).thenReturn(end1);
                                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2))).thenReturn(start2);
                                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(3))).thenReturn(end2);
                                            
                                            // Create SubLine instance
                                            SubLine subLine = new SubLine(line, intervalsSet);
                                            
                                            // Execute method
                                            java.util.List<Segment> segments = subLine.getSegments();
                                            
                                            // Verify results
                                            assertEquals("Should return same number of segments as intervals", 
                                                         intervalList.size(), segments.size());
                                            
                                            // Verify first segment
                                            Segment seg1 = segments.get(0);
                                            assertSame("First segment start point incorrect", start1, seg1.getStart());
                                            assertSame("First segment end point incorrect", end1, seg1.getEnd());
                                            assertSame("First segment line incorrect", line, seg1.getLine());
                                            
                                            // Verify second segment
                                            Segment seg2 = segments.get(1);
                                            assertSame("Second segment start point incorrect", start2, seg2.getStart());
                                            assertSame("Second segment end point incorrect", end2, seg2.getEnd());
                                            assertSame("Second segment line incorrect", line, seg2.getLine());
                                            
                                            // Verify interactions
                                            verify(intervalsSet).asList();
                                            verify(line, times(4)).toSpace(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class));
                                        }

    @Test
                        public void testGetSegmentsWithVariousIntervals() {
                            // Setup test data
                            org.apache.commons.math3.geometry.euclidean.threed.Line line = mock(org.apache.commons.math3.geometry.euclidean.threed.Line.class);
                            org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet = mock(org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet.class);
                            
                            // Create mock intervals
                            org.apache.commons.math3.geometry.euclidean.oned.Interval interval1 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(0.0, 1.0);
                            org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(1.0, 1.0); // degenerate interval
                            org.apache.commons.math3.geometry.euclidean.oned.Interval interval3 = new org.apache.commons.math3.geometry.euclidean.oned.Interval(-1.0, 2.0);
                            java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList = java.util.Arrays.asList(interval1, interval2, interval3);
                            
                            when(intervalsSet.asList()).thenReturn(intervalList);
                            
                            // Mock line.toSpace behavior
                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D start1 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 0, 0);
                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D end1 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0);
                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D start2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0);
                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D end2 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0);
                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D start3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(-1, 0, 0);
                            org.apache.commons.math3.geometry.euclidean.threed.Vector3D end3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2, 0, 0);
                            
                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0))).thenReturn(start1);
                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.0))).thenReturn(end1);
                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(-1.0))).thenReturn(start3);
                            when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2.0))).thenReturn(end3);
                            
                            // Create SubLine instance
                            org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine = new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line, intervalsSet);
                            
                            // Execute method
                            java.util.List<org.apache.commons.math3.geometry.euclidean.threed.Segment> segments = subLine.getSegments();
                            
                            // Verify results
                            assertEquals(3, segments.size());
                            
                            // Verify first segment
                            assertEquals(start1, segments.get(0).getStart());
                            assertEquals(end1, segments.get(0).getEnd());
                            
                            // Verify degenerate segment
                            assertEquals(start2, segments.get(1).getStart());
                            assertEquals(end2, segments.get(1).getEnd());
                            
                            // Verify third segment
                            assertEquals(start3, segments.get(2).getStart());
                            assertEquals(end3, segments.get(2).getEnd());
                            
                            // Verify line is properly set in all segments
                            for (org.apache.commons.math3.geometry.euclidean.threed.Segment segment : segments) {
                                assertEquals(line, segment.getLine());
                            }
                            
                            // Verify interactions
                            verify(intervalsSet).asList();
                            verify(line, times(6)).toSpace(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class));
                        }

    @Test
            public void testGetSegmentsWithBoundaryPoints() {
                // Setup test data
                Line line = mock(Line.class);
                IntervalsSet intervalsSet = mock(IntervalsSet.class);
                
                // Create test intervals - one exactly at boundary, one within, one spanning
                Interval boundaryInterval = new Interval(1.0, 1.0);
                Interval withinInterval = new Interval(1.5, 2.5);
                Interval spanningInterval = new Interval(0.5, 3.0);
                
                when(intervalsSet.asList()).thenReturn(java.util.Arrays.asList(boundaryInterval, withinInterval, spanningInterval));
                
                // Mock line conversions
                Vector3D point1 = new Vector3D(1, 0, 0);
                Vector3D point2 = new Vector3D(2, 0, 0);
                Vector3D point3 = new Vector3D(3, 0, 0);
                Vector3D point05 = new Vector3D(0.5, 0, 0);
                
                when(line.toSpace(new Vector1D(1.0))).thenReturn(point1);
                when(line.toSpace(new Vector1D(1.5))).thenReturn(point2);
                when(line.toSpace(new Vector1D(2.5))).thenReturn(point3);
                when(line.toSpace(new Vector1D(0.5))).thenReturn(point05);
                when(line.toSpace(new Vector1D(3.0))).thenReturn(point3);
             
                // Create SubLine instance
                SubLine subLine = new SubLine(line, intervalsSet);
                
                // Execute method
                List<Segment> segments = subLine.getSegments();
                
                // Verify results
                assertEquals(3, segments.size());
                
                // Verify boundary interval segment
                Segment boundarySegment = segments.get(0);
                assertEquals(point1, boundarySegment.getStart());
                assertEquals(point1, boundarySegment.getEnd());
                
                // Verify within interval segment
                Segment withinSegment = segments.get(1);
                assertEquals(point2, withinSegment.getStart());
                assertEquals(point3, withinSegment.getEnd());
                
                // Verify spanning interval segment
                Segment spanningSegment = segments.get(2);
                assertEquals(point05, spanningSegment.getStart());
                assertEquals(point3, spanningSegment.getEnd());
                
                // Verify line used in segments
                for (Segment segment : segments) {
                    assertEquals(line, segment.getLine());
                }
            }

    @Test
    public void testGetSegmentsDetectsMutant() {
        // Setup test data
        org.apache.commons.math3.geometry.euclidean.threed.Line line = 
            mock(org.apache.commons.math3.geometry.euclidean.threed.Line.class);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet = 
            mock(org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet.class);
        
        // Create two test intervals
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval1 = 
            new org.apache.commons.math3.geometry.euclidean.oned.Interval(0, 1);
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = 
            new org.apache.commons.math3.geometry.euclidean.oned.Interval(2, 3);
        when(intervalsSet.asList()).thenReturn(java.util.Arrays.asList(interval1, interval2));
        
        // Mock line conversions
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D start1 = 
            new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0, 0, 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D end1 = 
            new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 0, 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D start2 = 
            new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2, 0, 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D end2 = 
            new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(3, 0, 0);
        
        when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0))).thenReturn(start1);
        when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1))).thenReturn(end1);
        when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(2))).thenReturn(start2);
        when(line.toSpace(new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(3))).thenReturn(end2);
        
        // Create SubLine instance
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine = 
            new org.apache.commons.math3.geometry.euclidean.threed.SubLine(line, intervalsSet);
        
        // Execute method
        java.util.List<org.apache.commons.math3.geometry.euclidean.threed.Segment> segments = subLine.getSegments();
        
        // Verify results - mutant would potentially add extra segments
        assertEquals(2, segments.size());
        
        // Verify first segment
        org.apache.commons.math3.geometry.euclidean.threed.Segment seg1 = segments.get(0);
        assertEquals(start1, seg1.getStart());
        assertEquals(end1, seg1.getEnd());
        assertEquals(line, seg1.getLine());
        
        // Verify second segment
        org.apache.commons.math3.geometry.euclidean.threed.Segment seg2 = segments.get(1);
        assertEquals(start2, seg2.getStart());
        assertEquals(end2, seg2.getEnd());
        assertEquals(line, seg2.getLine());
        
        // Verify no duplicates - mutant might add same segment twice
        assertNotEquals(seg1, seg2);
    }


}
