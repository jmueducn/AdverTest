package gentest.org.apache.commons.math.geometry.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class Vector3DTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                    public void testCrossProduct_TypicalVectors() {
                                                        Vector3D v1 = new Vector3D(1, 0, 0);
                                                        Vector3D v2 = new Vector3D(0, 1, 0);
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertEquals(0.0, result.getX(), 1e-15);
                                                        assertEquals(0.0, result.getY(), 1e-15);
                                                        assertEquals(1.0, result.getZ(), 1e-15);
                                                    }

    @Test
                                                    public void testCrossProduct_ParallelVectors() {
                                                        Vector3D v1 = new Vector3D(1, 2, 3);
                                                        Vector3D v2 = new Vector3D(2, 4, 6); // Exactly parallel
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertEquals(Vector3D.ZERO, result);
                                                    }

    @Test
                                                    public void testCrossProduct_VerySmallVectors() {
                                                        Vector3D v1 = new Vector3D(1e-100, 0, 0);
                                                        Vector3D v2 = new Vector3D(0, 1e-100, 0);
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertEquals(Vector3D.ZERO, result);
                                                    }

    @Test
                                                    public void testCrossProduct_DifferentMagnitudes() {
                                                        Vector3D v1 = new Vector3D(1e-50, 2e-50, 3e-50);
                                                        Vector3D v2 = new Vector3D(1e+50, 2e+50, 3e+50);
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        // Should be zero vector since parallel (just scaled versions)
                                                        assertEquals(Vector3D.ZERO, result);
                                                    }

    @Test
                                                    public void testCrossProduct_OrthogonalDifferentMagnitudes() {
                                                        Vector3D v1 = new Vector3D(1e-8, 0, 0);
                                                        Vector3D v2 = new Vector3D(0, 1e+8, 0);
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertEquals(0.0, result.getX(), 1e-15);
                                                        assertEquals(0.0, result.getY(), 1e-15);
                                                        assertEquals(1.0, result.getZ(), 1e-15); // (1e-8 * 1e+8) = 1
                                                    }

    @Test
                                                    public void testCrossProduct_OneZeroVector() {
                                                        Vector3D v1 = new Vector3D(1, 2, 3);
                                                        Vector3D v2 = Vector3D.ZERO;
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertEquals(Vector3D.ZERO, result);
                                                    }

    @Test
                                                    public void testCrossProduct_BothZeroVectors() {
                                                        Vector3D v1 = Vector3D.ZERO;
                                                        Vector3D v2 = Vector3D.ZERO;
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertEquals(Vector3D.ZERO, result);
                                                    }

    @Test
                                                    public void testCrossProduct_WithNaN() {
                                                        Vector3D v1 = new Vector3D(Double.NaN, 1, 1);
                                                        Vector3D v2 = new Vector3D(1, 1, 1);
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertTrue(result.isNaN());
                                                    }

    @Test
                                                    public void testCrossProduct_WithInfinity() {
                                                        Vector3D v1 = new Vector3D(Double.POSITIVE_INFINITY, 1, 1);
                                                        Vector3D v2 = new Vector3D(1, 1, 1);
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        assertTrue(result.isInfinite());
                                                    }

    @Test
                                                    public void testCrossProduct_NullVectors() {
                                                        thrown.expect(NullPointerException.class);
                                                        Vector3D.crossProduct(null, new Vector3D(1, 1, 1));
                                                    }

    @Test
                                                    public void testCrossProduct_NearlyParallelVectors() {
                                                        Vector3D v1 = new Vector3D(1, 2, 3);
                                                        Vector3D v2 = new Vector3D(1.0000001, 2.0000002, 3.0000003);
                                                        
                                                        Vector3D result = Vector3D.crossProduct(v1, v2);
                                                        
                                                        // Should be very small but not exactly zero
                                                        assertTrue(result.getNorm() > 0);
                                                        assertTrue(result.getNorm() < 1e-6);
                                                    }

    @Test
                                            public void testCrossProduct_WithMockedVectors() {
                                                Vector3D v1 = mock(Vector3D.class);
                                                Vector3D v2 = mock(Vector3D.class);
                                                
                                                when(v1.getNormSq()).thenReturn(1.0);
                                                when(v2.getNormSq()).thenReturn(1.0);
                                                when(v1.getX()).thenReturn(1.0);
                                                when(v1.getY()).thenReturn(0.0);
                                                when(v1.getZ()).thenReturn(0.0);
                                                when(v2.getX()).thenReturn(0.0);
                                                when(v2.getY()).thenReturn(1.0);
                                                when(v2.getZ()).thenReturn(0.0);
                                                
                                                Vector3D result = Vector3D.crossProduct(v1, v2);
                                                
                                                assertEquals(0.0, result.getX(), 1e-15);
                                                assertEquals(0.0, result.getY(), 1e-15);
                                                assertEquals(1.0, result.getZ(), 1e-15);
                                                
                                                verify(v1, atLeastOnce()).getNormSq();
                                                verify(v2, atLeastOnce()).getNormSq();
                                            }

    @Test
                                            public void testGetX() {
                                                // Test normal cases
                                                Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
                                                assertEquals(1.0, v1.getX(), 0.0001);
                                                
                                                Vector3D v2 = new Vector3D(-5.5, 0.0, 10.2);
                                                assertEquals(-5.5, v2.getX(), 0.0001);
                                                
                                                // Test edge cases
                                                Vector3D v3 = new Vector3D(Double.MAX_VALUE, 0.0, 0.0);
                                                assertEquals(Double.MAX_VALUE, v3.getX(), 0.0001);
                                                
                                                Vector3D v4 = new Vector3D(Double.MIN_VALUE, 0.0, 0.0);
                                                assertEquals(Double.MIN_VALUE, v4.getX(), 0.0001);
                                                
                                                // Test special values
                                                Vector3D v5 = new Vector3D(Double.NaN, 1.0, 1.0);
                                                assertTrue(Double.isNaN(v5.getX()));
                                                
                                                Vector3D v6 = new Vector3D(Double.POSITIVE_INFINITY, 1.0, 1.0);
                                                assertEquals(Double.POSITIVE_INFINITY, v6.getX(), 0.0001);
                                                
                                                Vector3D v7 = new Vector3D(Double.NEGATIVE_INFINITY, 1.0, 1.0);
                                                assertEquals(Double.NEGATIVE_INFINITY, v7.getX(), 0.0001);
                                                
                                                // Test constructor with angles
                                                Vector3D v8 = new Vector3D(0.0, 0.0); // should create (1,0,0)
                                                assertEquals(1.0, v8.getX(), 0.0001);
                                            }

    @Test
                                        public void testGetX1() {
                                            // Test with positive value
                                            Vector3D vector1 = new Vector3D(1.5, 2.0, 3.0);
                                            assertEquals(1.5, vector1.getX(), 0.0001);
                                            
                                            // Test with negative value
                                            Vector3D vector2 = new Vector3D(-4.2, 5.0, 6.0);
                                            assertEquals(-4.2, vector2.getX(), 0.0001);
                                            
                                            // Test with zero value
                                            Vector3D vector3 = new Vector3D(0.0, 1.0, 2.0);
                                            assertEquals(0.0, vector3.getX(), 0.0001);
                                            
                                            // Test with maximum double value
                                            Vector3D vector4 = new Vector3D(Double.MAX_VALUE, 0.0, 0.0);
                                            assertEquals(Double.MAX_VALUE, vector4.getX(), 0.0001);
                                            
                                            // Test with minimum double value
                                            Vector3D vector5 = new Vector3D(Double.MIN_VALUE, 0.0, 0.0);
                                            assertEquals(Double.MIN_VALUE, vector5.getX(), 0.0001);
                                        }

    @Test
                                    public void testGetXWithRoundingDifference() {
                                        // Create a vector where 256 * ratio would be exactly halfway between two integers
                                        // For example, ratio = (n + 0.5)/256 where n is integer
                                        double x = 1.5 / 256;  // 256 * x = 1.5
                                        Vector3D vector = new Vector3D(x, 0.0, 0.0);
                                        
                                        // With rint: should round to nearest even (2.0/256)
                                        // With floor: should round down (1.0/256)
                                        double expectedWithRint = FastMath.rint(256 * x) / 256;
                                        double actual = vector.getX();
                                        
                                        // This assertion will fail if the mutant is present
                                        assertEquals("getX() should return value rounded with rint", expectedWithRint, actual, 0.0);
                                        
                                        // Additional assertion to explicitly show the difference
                                        double expectedWithFloor = FastMath.floor(256 * x) / 256;
                                        assertNotEquals("getX() should not return floor-rounded value", expectedWithFloor, actual, 0.0);
                                    }

    @Test
                                public void testGetX2() {
                                    // Test with positive value
                                    Vector3D v1 = new Vector3D(5.0, 3.0, 2.0);
                                    assertEquals(5.0, v1.getX(), 0.0001);
                                    
                                    // Test with negative value
                                    Vector3D v2 = new Vector3D(-2.5, 1.0, 0.0);
                                    assertEquals(-2.5, v2.getX(), 0.0001);
                                    
                                    // Test with zero
                                    Vector3D v3 = new Vector3D(0.0, 0.0, 0.0);
                                    assertEquals(0.0, v3.getX(), 0.0001);
                                    
                                    // Test with maximum double value
                                    Vector3D v4 = new Vector3D(Double.MAX_VALUE, 1.0, 1.0);
                                    assertEquals(Double.MAX_VALUE, v4.getX(), 0.0001);
                                    
                                    // Test with minimum double value
                                    Vector3D v5 = new Vector3D(Double.MIN_VALUE, 1.0, 1.0);
                                    assertEquals(Double.MIN_VALUE, v5.getX(), 0.0001);
                                }

    @Test
                            public void testGetX3() {
                                // Test with positive value
                                Vector3D v1 = new Vector3D(3.14, 0.0, 0.0);
                                assertEquals(3.14, v1.getX(), 0.0);
                                
                                // Test with negative value
                                Vector3D v2 = new Vector3D(-2.5, 0.0, 0.0);
                                assertEquals(-2.5, v2.getX(), 0.0);
                                
                                // Test with zero
                                Vector3D v3 = new Vector3D(0.0, 0.0, 0.0);
                                assertEquals(0.0, v3.getX(), 0.0);
                                
                                // Test with maximum double value
                                Vector3D v4 = new Vector3D(Double.MAX_VALUE, 0.0, 0.0);
                                assertEquals(Double.MAX_VALUE, v4.getX(), 0.0);
                                
                                // Test with minimum double value
                                Vector3D v5 = new Vector3D(Double.MIN_VALUE, 0.0, 0.0);
                                assertEquals(Double.MIN_VALUE, v5.getX(), 0.0);
                                
                                // Test that x value doesn't change after construction
                                Vector3D v6 = new Vector3D(1.0, 2.0, 3.0);
                                assertEquals(1.0, v6.getX(), 0.0);
                                // Attempt to "change" x through another vector operation
                                Vector3D v7 = v6.scalarMultiply(2.0);
                                // Original vector should remain unchanged
                                assertEquals(1.0, v6.getX(), 0.0);
                            }

    @Test
                        public void testCrossProductDetectsMutant() {
                            // Create two non-parallel vectors where z3*x2 and x3*z2 are both non-zero
                            Vector3D v1 = new Vector3D(1, 0, 1);  // x=1, y=0, z=1
                            Vector3D v2 = new Vector3D(0, 1, 1);  // x=0, y=1, z=1
                            
                            // Calculate expected cross product manually using correct formula
                            // Cross product formula:
                            // x = y1*z2 - z1*y2 = 0*1 - 1*1 = -1
                            // y = z1*x2 - x1*z2 = 1*0 - 1*1 = -1
                            // z = x1*y2 - y1*x2 = 1*1 - 0*0 = 1
                            Vector3D expected = new Vector3D(-1, -1, 1);
                            
                            // Get actual cross product
                            Vector3D actual = Vector3D.crossProduct(v1, v2);
                            
                            // Assert all components match
                            assertEquals("X component of cross product incorrect", 
                                expected.getX(), actual.getX(), 0.0001);
                            assertEquals("Y component of cross product incorrect - mutant not detected", 
                                expected.getY(), actual.getY(), 0.0001);
                            assertEquals("Z component of cross product incorrect", 
                                expected.getZ(), actual.getZ(), 0.0001);
                        }

    @Test
                    public void testCrossProductDetectsMutant1() {
                        // Create two non-zero, non-parallel vectors
                        Vector3D v1 = new Vector3D(1, 0, 0);
                        Vector3D v2 = new Vector3D(0, 1, 0);
                        
                        // Calculate expected cross product (should be (0,0,1))
                        Vector3D result = Vector3D.crossProduct(v1, v2);
                        
                        // Verify all components
                        assertEquals(0.0, result.getX(), 0.0001);  // y3*z2 - z3*y2 = 0*0 - 0*1 = 0
                        assertEquals(0.0, result.getY(), 0.0001);  // z3*x2 - x3*z2 = 0*0 - 1*0 = 0
                        assertEquals(1.0, result.getZ(), 0.0001);  // x3*y2 - y3*x2 = 1*1 - 0*0 = 1
                        
                        // The mutant would calculate z as x3*y2 + y3*x2 = 1 + 0 = 1 (same in this case)
                        // Need another test case where subtraction and addition differ
                        
                        // Second test case where the mutation would be detected
                        Vector3D v3 = new Vector3D(1, 2, 3);
                        Vector3D v4 = new Vector3D(4, 5, 6);
                        
                        Vector3D result2 = Vector3D.crossProduct(v3, v4);
                        
                        // Correct z component should be (1*5 - 2*4) = -3
                        // Mutant would calculate (1*5 + 2*4) = 13
                        assertEquals(-3.0, result2.getZ(), 0.0001);
                    }

    @Test
                public void testGetX4() {
                    // Test with positive, negative and zero values
                    Vector3D vector1 = new Vector3D(1.0, 2.0, 3.0);
                    assertEquals(1.0, vector1.getX(), 0.0001);
                    
                    Vector3D vector2 = new Vector3D(-5.5, 0.0, 10.2);
                    assertEquals(-5.5, vector2.getX(), 0.0001);
                    
                    Vector3D vector3 = new Vector3D(0.0, 0.0, 0.0);
                    assertEquals(0.0, vector3.getX(), 0.0001);
                    
                    // Test with very large and very small values
                    Vector3D vector4 = new Vector3D(Double.MAX_VALUE, 1.0, 1.0);
                    assertEquals(Double.MAX_VALUE, vector4.getX(), 0.0001);
                    
                    Vector3D vector5 = new Vector3D(Double.MIN_VALUE, 1.0, 1.0);
                    assertEquals(Double.MIN_VALUE, vector5.getX(), 0.0001);
                }

    @Test
            public void testCrossProductDetectsMutant2() {
                // Create two non-parallel vectors where the y-component calculation differs
                // between subtraction and multiplication
                Vector3D v1 = new Vector3D(1, 2, 3);
                Vector3D v2 = new Vector3D(4, 5, 6);
                
                // Calculate expected cross product manually
                double expectedX = 2*6 - 3*5;  // y1*z2 - z1*y2 = -3
                double expectedY = 3*4 - 1*6;  // z1*x2 - x1*z2 = 6
                double expectedZ = 1*5 - 2*4;  // x1*y2 - y1*x2 = -3
                
                Vector3D result = Vector3D.crossProduct(v1, v2);
                
                // Verify each component separately
                assertEquals("X component incorrect", expectedX, result.getX(), 0.0001);
                assertEquals("Y component incorrect", expectedY, result.getY(), 0.0001);
                assertEquals("Z component incorrect", expectedZ, result.getZ(), 0.0001);
                
                // The mutant would fail on the Y component assertion since:
                // Mutant calculates y as z1*x2 * x1*z2 = 3*4 * 1*6 = 12 * 6 = 72
                // Instead of the correct z1*x2 - x1*z2 = 12 - 6 = 6
            }

    @Test
        public void testGetXReturnsCorrectValue() {
            // Test with regular values
            Vector3D vector1 = new Vector3D(1.0, 2.0, 3.0);
            assertEquals(1.0, vector1.getX(), 0.0001);
            
            Vector3D vector2 = new Vector3D(-5.5, 0.0, 100.0);
            assertEquals(-5.5, vector2.getX(), 0.0001);
            
            // Test with zero
            Vector3D vector3 = new Vector3D(0.0, 0.0, 0.0);
            assertEquals(0.0, vector3.getX(), 0.0001);
            
            // Test with very large numbers
            Vector3D vector4 = new Vector3D(Double.MAX_VALUE, 0.0, 0.0);
            assertEquals(Double.MAX_VALUE, vector4.getX(), 0.0001);
            
            // Test with very small numbers
            Vector3D vector5 = new Vector3D(Double.MIN_VALUE, 0.0, 0.0);
            assertEquals(Double.MIN_VALUE, vector5.getX(), 0.0001);
            
            // Test with special double values
            Vector3D vector6 = new Vector3D(Double.NaN, 0.0, 0.0);
            assertTrue(Double.isNaN(vector6.getX()));
            
            Vector3D vector7 = new Vector3D(Double.POSITIVE_INFINITY, 0.0, 0.0);
            assertTrue(Double.isInfinite(vector7.getX()));
        }

}
