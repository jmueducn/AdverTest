package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.NonPositiveDefiniteMatrixException;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class MultivariateNormalDistributionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                        public void testDensity_ValidInput() {
                                                                                                            // Setup
                                                                                                            double[] means = {1.0, 2.0};
                                                                                                            double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                                                                                            MultivariateNormalDistribution distribution = 
                                                                                                                new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                                                                                            
                                                                                                            // Test with valid input
                                                                                                            double[] values = {1.5, 2.5};
                                                                                                            double result = distribution.density(values);
                                                                                                            
                                                                                                            // Verify - we can't predict exact value due to complex calculation,
                                                                                                            // but we can verify it's positive and finite
                                                                                                            assertTrue(result > 0);
                                                                                                            assertTrue(Double.isFinite(result));
                                                                                                        }

    @Test
                                                                                                        public void testDensity_WithDifferentDimensions() {
                                                                                                            // Test with 1D case
                                                                                                            double[] means1D = {1.0};
                                                                                                            double[][] covariances1D = {{1.0}};
                                                                                                            MultivariateNormalDistribution dist1D = 
                                                                                                                new MultivariateNormalDistribution(new Well19937c(), means1D, covariances1D);
                                                                                                            double result1D = dist1D.density(new double[]{1.5});
                                                                                                            assertTrue(result1D > 0);
                                                                                                            
                                                                                                            // Test with 3D case
                                                                                                            double[] means3D = {1.0, 2.0, 3.0};
                                                                                                            double[][] covariances3D = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                                                                            MultivariateNormalDistribution dist3D = 
                                                                                                                new MultivariateNormalDistribution(new Well19937c(), means3D, covariances3D);
                                                                                                            double result3D = dist3D.density(new double[]{1.5, 2.5, 3.5});
                                                                                                            assertTrue(result3D > 0);
                                                                                                        }

    @Test
                                                                                                        public void testDensity_WithExtremeValues() {
                                                                                                            // Setup with large values
                                                                                                            double[] means = {1e100, -1e100};
                                                                                                            double[][] covariances = {{1e200, 0.0}, {0.0, 1e200}};
                                                                                                            MultivariateNormalDistribution distribution = 
                                                                                                                new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                                                                                            
                                                                                                            // Test with extreme values
                                                                                                            double[] values = {1e100, -1e100};
                                                                                                            double result = distribution.density(values);
                                                                                                            
                                                                                                            // Verify the result is finite and positive
                                                                                                            assertTrue(result > 0);
                                                                                                            assertTrue(Double.isFinite(result));
                                                                                                        }

    @Test
                                                                                                public void testDensity_DimensionMismatch() {
                                                                                                    // Setup rule for expected exception
                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                    
                                                                                                    // Setup test data
                                                                                                    double[] means = {1.0, 2.0, 3.0};
                                                                                                    double[][] covariances = {{1.0, 0.5, 0.0}, {0.5, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                                                                    MultivariateNormalDistribution distribution = 
                                                                                                        new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                                                                                    
                                                                                                    // Expect exception
                                                                                                    exception.expect(DimensionMismatchException.class);
                                                                                                    exception.expectMessage("2 != 3");
                                                                                                    
                                                                                                    // Test with wrong dimension input
                                                                                                    double[] wrongValues = {1.0, 2.0}; // Should be length 3
                                                                                                    distribution.density(wrongValues);
                                                                                                }

    @Test
                                                                                                public void testDensity_ZeroCovariance() {
                                                                                                    // Setup - diagonal covariance matrix with one zero variance
                                                                                                    double[] means = {1.0, 2.0};
                                                                                                    double[][] covariances = {{0.0, 0.0}, {0.0, 1.0}};
                                                                                                    
                                                                                                    // Setup exception expectation
                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                    exception.expect(NonPositiveDefiniteMatrixException.class);
                                                                                                    
                                                                                                    new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                                                                                }

    @Test
                                                                                                public void testDensity_WithMockedExponentTerm() throws Exception {
                                                                                                    // Setup
                                                                                                    double[] means = {1.0, 2.0};
                                                                                                    double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                                                                                    MultivariateNormalDistribution distribution = 
                                                                                                        new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                                                                                    
                                                                                                    // Get private covarianceMatrixDeterminant field
                                                                                                    Field determinantField = MultivariateNormalDistribution.class.getDeclaredField("covarianceMatrixDeterminant");
                                                                                                    determinantField.setAccessible(true);
                                                                                                    double determinant = determinantField.getDouble(distribution);
                                                                                                    
                                                                                                    // Mock the private getExponentTerm method using reflection
                                                                                                    double[] testValues = {1.5, 2.5};
                                                                                                    double mockExponentTerm = 0.5;
                                                                                                    
                                                                                                    // Create spy after setting up reflection
                                                                                                    MultivariateNormalDistribution spyDistribution = spy(distribution);
                                                                                                    
                                                                                                    // Mock the private method
                                                                                                    Method exponentTermMethod = MultivariateNormalDistribution.class.getDeclaredMethod("getExponentTerm", double[].class);
                                                                                                    exponentTermMethod.setAccessible(true);
                                                                                                    when(exponentTermMethod.invoke(spyDistribution, testValues)).thenReturn(mockExponentTerm);
                                                                                                    
                                                                                                    // Calculate expected value
                                                                                                    double expected = FastMath.pow(2 * FastMath.PI, -0.5 * 2) * 
                                                                                                                    FastMath.pow(determinant, -0.5) * 
                                                                                                                    mockExponentTerm;
                                                                                                    
                                                                                                    // Test
                                                                                                    double result = spyDistribution.density(testValues);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertEquals(expected, result, 1e-10);
                                                                                                }

    @Test
                                                                                                public void testConstructorThrowsCorrectDimensionMismatchException() {
                                                                                                    double[] means = {1.0, 2.0};
                                                                                                    double[][] invalidCovariances = {{1.0}}; // Wrong dimension
                                                                                                    
                                                                                                    thrown.expect(DimensionMismatchException.class);
                                                                                                    thrown.expectMessage("2 != 1"); // Original would be "1 != 2"
                                                                                                    
                                                                                                    new MultivariateNormalDistribution(means, invalidCovariances);
                                                                                                }

    @Test
                                                                                                public void testConstructorThrowsCorrectDimensionMismatchForRow() {
                                                                                                    double[] means = {1.0, 2.0};
                                                                                                    double[][] invalidCovariances = {{1.0, 2.0}, {3.0}}; // Second row has wrong length
                                                                                                    
                                                                                                    thrown.expect(DimensionMismatchException.class);
                                                                                                    thrown.expectMessage("2 != 1"); // Original would be "1 != 2"
                                                                                                    
                                                                                                    new MultivariateNormalDistribution(means, invalidCovariances);
                                                                                                }

    @Test
                                                                                            public void testConstructorThrowsDimensionMismatchWhenCovarianceMatrixRowsMismatch() {
                                                                                                double[] means = {1.0, 2.0};
                                                                                                double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}, {0.1, 0.2}}; // 3 rows for 2D means
                                                                                                
                                                                                                thrown.expect(DimensionMismatchException.class);
                                                                                                thrown.expectMessage("3 != 2"); // Verify the expected dimension mismatch
                                                                                                
                                                                                                new MultivariateNormalDistribution(means, covariances);
                                                                                            }

    @Test
                                                                                            public void testConstructorThrowsDimensionMismatchWhenCovarianceMatrixColumnsMismatch() {
                                                                                                double[] means = {1.0, 2.0, 3.0};
                                                                                                double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}, {0.1, 0.2}}; // 2 columns for 3D means
                                                                                                
                                                                                                thrown.expect(DimensionMismatchException.class);
                                                                                                thrown.expectMessage("2 != 3"); // Verify the expected dimension mismatch
                                                                                                
                                                                                                new MultivariateNormalDistribution(means, covariances);
                                                                                            }

    @Test
                                                                                            public void testGetMeansReturnsCorrectCopy() {
                                                                                                double[] expectedMeans = {1.0, 2.0};
                                                                                                double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                                                                                MultivariateNormalDistribution dist = new MultivariateNormalDistribution(expectedMeans, covariances);
                                                                                                
                                                                                                double[] actualMeans = dist.getMeans();
                                                                                                
                                                                                                // Verify content is equal
                                                                                                org.junit.Assert.assertArrayEquals(expectedMeans, actualMeans, 0.0);
                                                                                                // Verify it's a different array instance (copy)
                                                                                                org.junit.Assert.assertNotSame(expectedMeans, actualMeans);
                                                                                            }

    @Test
                                                                                        public void testGetMeansReturnsCopy() {
                                                                                            // Arrange
                                                                                            double[] expectedMeans = {1.0, 2.0, 3.0};
                                                                                            double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                                                            MultivariateNormalDistribution distribution = 
                                                                                                new MultivariateNormalDistribution(expectedMeans, covariances);
                                                                                            
                                                                                            // Act
                                                                                            double[] actualMeans = distribution.getMeans();
                                                                                            
                                                                                            // Assert - verify values are equal
                                                                                            assertArrayEquals(expectedMeans, actualMeans, 0.0001);
                                                                                            
                                                                                            // Modify the returned array
                                                                                            actualMeans[0] = 99.0;
                                                                                            
                                                                                            // Get means again and verify original wasn't modified
                                                                                            double[] unchangedMeans = distribution.getMeans();
                                                                                            assertArrayEquals(expectedMeans, unchangedMeans, 0.0001);
                                                                                            assertNotEquals(99.0, unchangedMeans[0], 0.0001);
                                                                                        }

    @Test
                                                                                    public void testGetMeansReturnsCorrectArrayCopy() {
                                                                                        // Setup test data
                                                                                        double[] expectedMeans = {1.0, 2.0, 3.0};
                                                                                        double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                                                        
                                                                                        // Create test instance
                                                                                        MultivariateNormalDistribution distribution = 
                                                                                            new MultivariateNormalDistribution(expectedMeans, covariances);
                                                                                        
                                                                                        // Test the getMeans() method
                                                                                        double[] actualMeans = distribution.getMeans();
                                                                                        
                                                                                        // Verify the returned array is not null
                                                                                        assertNotNull("Returned means array should not be null", actualMeans);
                                                                                        
                                                                                        // Verify the length matches
                                                                                        assertEquals("Array length should match input means", 
                                                                                                    expectedMeans.length, actualMeans.length);
                                                                                        
                                                                                        // Verify each element matches
                                                                                        assertArrayEquals("Returned means should match input means", 
                                                                                                         expectedMeans, actualMeans, 0.0001);
                                                                                        
                                                                                        // Verify it's a copy (not same reference)
                                                                                        assertNotSame("Should return a copy of means array", 
                                                                                                     expectedMeans, actualMeans);
                                                                                        
                                                                                        // Verify the type is double[] (would fail with mutated version)
                                                                                        assertTrue("Return type should be double[]", 
                                                                                                   actualMeans instanceof double[]);
                                                                                    }

    @Test
                                                                                public void testGetMeansReturnsCopy1() {
                                                                                    // Arrange
                                                                                    double[] expectedMeans = {1.0, 2.0, 3.0};
                                                                                    double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                                                    MultivariateNormalDistribution distribution = 
                                                                                        new MultivariateNormalDistribution(expectedMeans, covariances);
                                                                                    
                                                                                    // Act
                                                                                    double[] result = distribution.getMeans();
                                                                                    
                                                                                    // Assert - verify values match
                                                                                    assertArrayEquals(expectedMeans, result, 0.0001);
                                                                                    
                                                                                    // Modify the returned array
                                                                                    result[0] = 99.0;
                                                                                    
                                                                                    // Get means again and verify original wasn't modified
                                                                                    double[] newResult = distribution.getMeans();
                                                                                    assertArrayEquals(expectedMeans, newResult, 0.0001);
                                                                                    assertNotSame("Should return a new copy each time", result, newResult);
                                                                                }

    @Test
                                                                                public void testGetMeansWithEmptyArray() {
                                                                                    // Arrange
                                                                                    double[] expectedMeans = {};
                                                                                    double[][] covariances = {};
                                                                                    MultivariateNormalDistribution distribution = 
                                                                                        new MultivariateNormalDistribution(expectedMeans, covariances);
                                                                                    
                                                                                    // Act
                                                                                    double[] result = distribution.getMeans();
                                                                                    
                                                                                    // Assert
                                                                                    assertArrayEquals(expectedMeans, result, 0.0001);
                                                                                    assertEquals(0, result.length);
                                                                                }

    @Test
                                                                            public void testGetMeansReturnsCopyNotOriginal() {
                                                                                // Setup
                                                                                double[] expectedMeans = {1.0, 2.0, 3.0};
                                                                                double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                                                MultivariateNormalDistribution distribution = 
                                                                                    new MultivariateNormalDistribution(expectedMeans, covariances);
                                                                                
                                                                                // Test getMeans returns correct values
                                                                                double[] actualMeans = distribution.getMeans();
                                                                                assertArrayEquals("Means should match input", expectedMeans, actualMeans, 0.0);
                                                                                
                                                                                // Test that modifying the returned array doesn't affect internal state
                                                                                actualMeans[0] = 99.0; // Modify the returned array
                                                                                double[] newMeans = distribution.getMeans();
                                                                                assertArrayEquals("Internal means should not be modified", 
                                                                                                 expectedMeans, newMeans, 0.0);
                                                                            }

    @Test
                                                                        public void testDensityWithKnownValues() {
                                                                            // Setup test data
                                                                            double[] means = {1.0, 2.0};
                                                                            double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                                                            double[] testValues = {1.5, 2.5};
                                                                            
                                                                            // Create the distribution
                                                                            MultivariateNormalDistribution dist = 
                                                                                new MultivariateNormalDistribution(means, covariances);
                                                                            
                                                                            // Calculate expected density manually
                                                                            // For a proper test, we would need to implement the actual density calculation
                                                                            // Here we'll just verify it's not 1.0 (which the mutant would return)
                                                                            double actualDensity = dist.density(testValues);
                                                                            
                                                                            // Assert that the density is calculated properly (not just 1.0)
                                                                            assertNotEquals("Density should not be 1.0 - mutant detected", 
                                                                                           1.0, actualDensity, 0.0001);
                                                                            
                                                                            // Additional check that it's a valid probability density
                                                                            assertTrue("Density should be positive", actualDensity > 0);
                                                                        }

    @Test
                                                                        public void testDensityWithDifferentInputs() {
                                                                            // Setup test data
                                                                            double[] means = {0.0, 0.0};
                                                                            double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}}; // Identity matrix
                                                                            double[] testValues1 = {0.0, 0.0}; // At mean
                                                                            double[] testValues2 = {1.0, 1.0}; // One std dev away
                                                                            
                                                                            // Create the distribution
                                                                            MultivariateNormalDistribution dist = 
                                                                                new MultivariateNormalDistribution(means, covariances);
                                                                            
                                                                            // Calculate densities
                                                                            double densityAtMean = dist.density(testValues1);
                                                                            double densityOneStdDev = dist.density(testValues2);
                                                                            
                                                                            // Verify they're different (mutant would make them same)
                                                                            assertNotEquals("Densities at different points should differ - mutant detected", 
                                                                                           densityAtMean, densityOneStdDev, 0.0001);
                                                                            
                                                                            // Verify relative values are correct
                                                                            assertTrue("Density at mean should be higher", 
                                                                                       densityAtMean > densityOneStdDev);
                                                                        }

    @Test
                                                                    public void testConstructorWithExactDimensionMeans() {
                                                                        // This should pass in both original and mutant
                                                                        double[] means = {1.0, 2.0};
                                                                        double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                                                        MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                                                        assertArrayEquals(means, dist.getMeans(), 0.0001);
                                                                    }

    @Test
                                                                    public void testConstructorWithLargerMeansArray() {
                                                                        // This should throw exception in both original and mutant
                                                                        thrown.expect(DimensionMismatchException.class);
                                                                        double[] means = {1.0, 2.0, 3.0}; // 3 elements
                                                                        double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}}; // 2x2
                                                                        new MultivariateNormalDistribution(means, covariances);
                                                                    }

    @Test
                                                                    public void testConstructorWithSmallerMeansArray() {
                                                                        // This will catch the mutant - original throws exception, mutant doesn't
                                                                        thrown.expect(DimensionMismatchException.class);
                                                                        double[] means = {1.0}; // 1 element
                                                                        double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}}; // 2x2
                                                                        new MultivariateNormalDistribution(means, covariances);
                                                                    }

    @Test
                                                                public void testConstructorThrowsDimensionMismatchWithCorrectParameters() {
                                                                    // Setup
                                                                    double[] means = {1.0, 2.0}; // dim = 2
                                                                    double[][] covariances = {{1.0}}; // covariances.length = 1 (mismatch)
                                                            
                                                                    // Expect exception
                                                                    thrown.expect(DimensionMismatchException.class);
                                                                    thrown.expectMessage("1 != 2"); // Original would show "1 != 2", mutant would show "2 != 1"
                                                            
                                                                    // Test - this should throw DimensionMismatchException
                                                                    new MultivariateNormalDistribution(means, covariances);
                                                                }

    @Test
                                                                public void testConstructorThrowsDimensionMismatchForRowLength() {
                                                                    // Setup
                                                                    double[] means = {1.0, 2.0}; // dim = 2
                                                                    double[][] covariances = {{1.0}, {1.0, 2.0}}; // Second row has length 2 (mismatch)
                                                            
                                                                    // Expect exception
                                                                    thrown.expect(DimensionMismatchException.class);
                                                                    thrown.expectMessage("2 != 1"); // For the second row check
                                                            
                                                                    // Test - this should throw DimensionMismatchException
                                                                    new MultivariateNormalDistribution(means, covariances);
                                                                }

    @Test
                                                    public void testGetMeansReturnsCopy2() {
                                                        // Arrange
                                                        double[] expectedMeans = {1.0, 2.0, 3.0};
                                                        double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                        MultivariateNormalDistribution distribution = 
                                                            new MultivariateNormalDistribution(expectedMeans, covariances);
                                                        
                                                        // Act
                                                        double[] result = distribution.getMeans();
                                                        
                                                        // Assert - verify it's not the same array reference
                                                        assertFalse(result == expectedMeans);
                                                        assertFalse(result == distribution.getMeans());
                                                        
                                                        // Assert - verify contents are equal
                                                        assertArrayEquals(expectedMeans, result, 0.0001);
                                                        
                                                        // Assert - verify modifying the result doesn't affect internal state
                                                        result[0] = 99.0;
                                                        double[] newResult = distribution.getMeans();
                                                        assertArrayEquals(expectedMeans, newResult, 0.0001);
                                                    }

    @Test
                                                    public void testDensityCalculation() {
                                                        // Setup test data - simple 1D normal distribution with mean 0 and variance 1
                                                        double[] means = {0.0};
                                                        double[][] covariances = {{1.0}};
                                                        
                                                        MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                                        
                                                        // Test point at 1 standard deviation from mean
                                                        double[] point = {1.0};
                                                        
                                                        // Calculate expected density value manually using correct formula
                                                        double expectedDensity = FastMath.pow(2 * FastMath.PI, -0.5) * 
                                                                               FastMath.exp(-0.5 * 1.0 * 1.0);
                                                        
                                                        // The mutant would compute FastMath.pow(2 * FastMath.PI, 0.5) which would be sqrt(2π)
                                                        // instead of 1/sqrt(2π), making the result completely different
                                                        
                                                        double actualDensity = dist.density(point);
                                                        
                                                        // Verify the density matches expected value within reasonable tolerance
                                                        assertEquals("Density calculation is incorrect", 
                                                                    expectedDensity, actualDensity, 1e-10);
                                                        
                                                        // Additional check that density at mean is higher than at 1 std dev
                                                        double densityAtMean = dist.density(means);
                                                        assertTrue("Density should decrease away from mean", 
                                                                  densityAtMean > actualDensity);
                                                    }

    @Test
                                                public void testGetMeansReturnsCopy3() {
                                                    // Arrange
                                                    double[] expectedMeans = {1.0, 2.0, 3.0};
                                                    double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                                                    MultivariateNormalDistribution distribution = 
                                                        new MultivariateNormalDistribution(expectedMeans, covariances);
                                                    
                                                    // Act
                                                    double[] result = distribution.getMeans();
                                                    
                                                    // Assert - check it's not the same array reference
                                                    assertNotSame("Should return a copy of means array", expectedMeans, result);
                                                    assertArrayEquals("Returned array should match original means", 
                                                                     expectedMeans, result, 0.0001);
                                                    
                                                    // Modify the returned array and ensure original isn't affected
                                                    result[0] = 99.0;
                                                    double[] newResult = distribution.getMeans();
                                                    assertEquals("Original means should not be modified", 
                                                                expectedMeans[0], newResult[0], 0.0001);
                                                }

    @Test
                                                public void testGetMeansWithEmptyArray1() {
                                                    // Arrange
                                                    double[] expectedMeans = {};
                                                    double[][] covariances = {};
                                                    MultivariateNormalDistribution distribution = 
                                                        new MultivariateNormalDistribution(expectedMeans, covariances);
                                                    
                                                    // Act
                                                    double[] result = distribution.getMeans();
                                                    
                                                    // Assert
                                                    assertArrayEquals("Should handle empty means array", 
                                                                     expectedMeans, result, 0.0001);
                                                    assertEquals("Empty array should have length 0", 0, result.length);
                                                }

    @Test
                                public void testDensityDetectsExponentMutation() {
                                    // Setup test data with known determinant
                                    double[] means = {1.0, 2.0};
                                    double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                    MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                    
                                    // Test point - using mean should give highest probability density
                                    double[] vals = {1.0, 2.0};
                                    
                                    // Calculate expected value manually
                                    // For multivariate normal, density at mean is:
                                    // 1/( (2π)^(n/2) * det(cov)^(1/2) )
                                    int dim = means.length;
                                    double expected = 1.0 / (Math.pow(2 * Math.PI, dim/2.0) * 
                                                     Math.pow(0.75, -0.5)); // det of this cov matrix is 0.75
                                    
                                    // The mutant would calculate Math.pow(0.75, 0.5) instead, which is different
                                    double actual = dist.density(vals);
                                    
                                    // Verify with delta to account for floating point precision
                                    assertEquals("Density calculation should use negative exponent", 
                                                expected, actual, 1e-10);
                                }

    @Test
                                public void testConstructorWithSmallerInputArray() {
                                    // Setup test data
                                    double[] means = new double[]{1.0, 2.0};  // dim = 2
                                    double[][] covariances = new double[][]{{1.0}};  // dim = 1 (smaller than means length)
                            
                                    // Expect DimensionMismatchException because covariances length (1) != means length (2)
                                    thrown.expect(DimensionMismatchException.class);
                                    thrown.expectMessage("1 != 2");
                            
                                    // This should throw exception in original code but would pass in mutated code
                                    new MultivariateNormalDistribution(means, covariances);
                                }

    @Test
                                public void testGetMeansReturnsCopy4() {
                                    // Setup test data
                                    double[] means = new double[]{1.0, 2.0};
                                    double[][] covariances = new double[][]{{1.0, 0.0}, {0.0, 1.0}};
                                    
                                    MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                    
                                    // Get means copy and modify it
                                    double[] meansCopy = dist.getMeans();
                                    meansCopy[0] = 5.0;
                                    
                                    // Verify original means array wasn't modified
                                    double[] originalMeans = dist.getMeans();
                                    assertNotEquals(5.0, originalMeans[0], 0.0001);
                                    assertEquals(1.0, originalMeans[0], 0.0001);
                                }

    @Test
                            public void testConstructorThrowsDimensionMismatchWithCorrectParameters1() {
                                // Setup
                                double[] means = {1.0, 2.0};  // dim = 2
                                double[][] invalidCovariances = {{1.0}};  // length = 1
                                
                                // Expect exception
                                thrown.expect(DimensionMismatchException.class);
                                thrown.expectMessage("1 != 2");  // Original would be "2 != 1"
                                
                                // Test - this should throw DimensionMismatchException
                                new MultivariateNormalDistribution(means, invalidCovariances);
                            }

    @Test
                            public void testConstructorThrowsDimensionMismatchForNonSquareMatrix() {
                                // Setup
                                double[] means = {1.0, 2.0};  // dim = 2
                                double[][] invalidCovariances = {{1.0, 2.0}, {3.0}};  // second row has length 1
                                
                                // Expect exception
                                thrown.expect(DimensionMismatchException.class);
                                thrown.expectMessage("1 != 2");  // Original would be "2 != 1" for the first check
                                
                                // Test - this should throw DimensionMismatchException
                                new MultivariateNormalDistribution(means, invalidCovariances);
                            }

    @Test
                        public void testConstructorThrowsDimensionMismatchWhenCovarianceMatrixRowsMismatch1() {
                            double[] means = {1.0, 2.0};
                            double[][] invalidCovariances = {
                                {1.0, 0.5}, 
                                {0.5, 1.0},
                                {0.1, 0.2}  // Extra row makes it invalid
                            };
                            
                            thrown.expect(DimensionMismatchException.class);
                            thrown.expectMessage("3 != 2");  // Expected dimension mismatch
                            
                            new MultivariateNormalDistribution(means, invalidCovariances);
                        }

    @Test
                        public void testConstructorThrowsDimensionMismatchWhenCovarianceMatrixColumnsMismatch1() {
                            double[] means = {1.0, 2.0, 3.0};
                            double[][] invalidCovariances = {
                                {1.0, 0.5, 0.3},
                                {0.5, 1.0}  // Missing one column
                            };
                            
                            thrown.expect(DimensionMismatchException.class);
                            thrown.expectMessage("2 != 3");  // Expected dimension mismatch
                            
                            new MultivariateNormalDistribution(means, invalidCovariances);
                        }

    @Test
                    public void testGetMeansReturnsCopy5() {
                        // Arrange
                        double[] expectedMeans = {1.0, 2.0, 3.0};
                        double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                        MultivariateNormalDistribution distribution = 
                            new MultivariateNormalDistribution(expectedMeans, covariances);
                        
                        // Act
                        double[] actualMeans = distribution.getMeans();
                        
                        // Assert
                        assertArrayEquals("Means should match", expectedMeans, actualMeans, 0.0001);
                        assertNotSame("Should return a new array instance", expectedMeans, actualMeans);
                        
                        // Verify modifying the returned array doesn't affect internal state
                        actualMeans[0] = 99.0;
                        double[] secondCopy = distribution.getMeans();
                        assertEquals("Internal means should not change", 
                                    expectedMeans[0], secondCopy[0], 0.0001);
                    }

    @Test
                public void testGetMeansReturnsCopy6() {
                    // Arrange
                    double[] expectedMeans = {1.0, 2.0, 3.0};
                    double[][] covariances = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                    MultivariateNormalDistribution distribution = 
                        new MultivariateNormalDistribution(expectedMeans, covariances);
                    
                    // Act
                    double[] result = distribution.getMeans();
                    
                    // Assert - verify content matches
                    assertArrayEquals(expectedMeans, result, 0.0001);
                    
                    // Modify the returned array
                    result[0] = 99.0;
                    
                    // Get means again and verify original wasn't modified
                    double[] newResult = distribution.getMeans();
                    assertArrayEquals(expectedMeans, newResult, 0.0001);
                    assertNotEquals(result[0], newResult[0], 0.0001);
                }

    @Test
                public void testGetMeansWithEmptyArray2() {
                    // Arrange
                    double[] expectedMeans = {};
                    double[][] covariances = {};
                    MultivariateNormalDistribution distribution = 
                        new MultivariateNormalDistribution(expectedMeans, covariances);
                    
                    // Act
                    double[] result = distribution.getMeans();
                    
                    // Assert
                    assertArrayEquals(expectedMeans, result, 0.0001);
                    assertEquals(0, result.length);
                }

    @Test
                public void testGetMeansWithSingleValue() {
                    // Arrange
                    double[] expectedMeans = {5.0};
                    double[][] covariances = {{1.0}};
                    MultivariateNormalDistribution distribution = 
                        new MultivariateNormalDistribution(expectedMeans, covariances);
                    
                    // Act
                    double[] result = distribution.getMeans();
                    
                    // Assert
                    assertArrayEquals(expectedMeans, result, 0.0001);
                    assertEquals(1, result.length);
                }

    @Test
            public void testDensityCalculationDetectsMultiplicationMutant() {
                // Setup test data
                double[] means = {1.0, 2.0};
                double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                
                // Create the distribution
                MultivariateNormalDistribution dist = 
                    new MultivariateNormalDistribution(means, covariances);
                
                // Test point near the mean
                double[] valsNearMean = {1.1, 2.1};
                double densityNearMean = dist.density(valsNearMean);
                
                // Test point far from the mean
                double[] valsFarFromMean = {10.0, 20.0};
                double densityFarFromMean = dist.density(valsFarFromMean);
                
                // The key assertions that would catch the mutant:
                // 1. Verify density decreases as we move away from the mean
                assertTrue(densityNearMean > densityFarFromMean);
                
                // 2. Verify the density at the mean is higher than surrounding points
                double densityAtMean = dist.density(means);
                assertTrue(densityAtMean > densityNearMean);
                
                // 3. Verify the density calculation produces expected values
                // For standard normal (covariance matrix is identity), we know the exact formula
                double expectedDensityNearMean = 1/(2*Math.PI) * Math.exp(-0.01);
                assertEquals(expectedDensityNearMean, densityNearMean, 1e-10);
            }

    @Test
        public void testConstructorThrowsWhenMeansLengthLessThanDimension() {
            // Setup
            double[] shortMeans = new double[]{1.0, 2.0}; // length 2
            double[][] covariances = new double[3][3]; // dimension 3
            
            // Expect exception
            thrown.expect(DimensionMismatchException.class);
            thrown.expectMessage("3 != 2");
            
            // Test - this should throw in original but pass in mutant
            new MultivariateNormalDistribution(shortMeans, covariances);
        }

    @Test
        public void testConstructorThrowsWhenMeansLengthGreaterThanDimension() {
            // Setup
            double[] longMeans = new double[]{1.0, 2.0, 3.0, 4.0}; // length 4
            double[][] covariances = new double[3][3]; // dimension 3
            
            // Expect exception (both original and mutant should throw)
            thrown.expect(DimensionMismatchException.class);
            thrown.expectMessage("3 != 4");
            
            // Test
            new MultivariateNormalDistribution(longMeans, covariances);
        }

    @Test
        public void testConstructorAcceptsCorrectDimension() {
            // Setup
            double[] correctMeans = new double[]{1.0, 2.0, 3.0}; // length 3
            double[][] covariances = new double[3][3]; // dimension 3
            
            // Should not throw
            MultivariateNormalDistribution dist = 
                new MultivariateNormalDistribution(correctMeans, covariances);
            
            // Verify means were copied correctly
            double[] returnedMeans = dist.getMeans();
            org.junit.Assert.assertArrayEquals(correctMeans, returnedMeans, 0.0001);
        }

}
