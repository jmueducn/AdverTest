package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Pair;
 
public class DiscreteDistributionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                            public void testSample_WithSingleElementList() {
                                                                                                                                // Setup test data with single element
                                                                                                                                List<Pair<String, Double>> samples = new ArrayList<Pair<String, Double>>();
                                                                                                                                samples.add(new Pair<String, Double>("OnlyOne", 1.0));
                                                                                                                                
                                                                                                                                // Mock RandomGenerator
                                                                                                                                RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                when(mockRandom.nextDouble()).thenReturn(0.5); // any value should return the only element
                                                                                                                                
                                                                                                                                DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                                assertEquals("OnlyOne", dist.sample());
                                                                                                                            }

    @Test
                                                                                                                            public void testSample_EdgeCases() {
                                                                                                                                // Setup mock objects
                                                                                                                                RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                when(mockRandom.nextDouble()).thenReturn(0.0, 0.999999, 0.4);
                                                                                                                            
                                                                                                                                List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                samples.add(new Pair<>("A", 0.4));
                                                                                                                                samples.add(new Pair<>("B", 0.6));
                                                                                                                                
                                                                                                                                DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                            
                                                                                                                                // Test edge values from random generator
                                                                                                                                Object[] result = distribution.sample(3);
                                                                                                                                assertEquals(3, result.length);
                                                                                                                                assertEquals("A", result[0]); // 0.0 -> first element
                                                                                                                                assertEquals("B", result[1]); // 0.999999 -> last element
                                                                                                                                assertEquals("A", result[2]); // 0.4 -> boundary case
                                                                                                                            }

    @Test
                                                                                                                            public void testSample_LargeSampleSize() {
                                                                                                                                // Setup mock to always return first element
                                                                                                                                RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                when(mockRandom.nextDouble()).thenReturn(0.1);
                                                                                                                            
                                                                                                                                List<Pair<String, Double>> samples = new ArrayList<Pair<String, Double>>();
                                                                                                                                samples.add(new Pair<String, Double>("A", 0.4));
                                                                                                                                samples.add(new Pair<String, Double>("B", 0.6));
                                                                                                                                
                                                                                                                                DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                            
                                                                                                                                // Test with large sample size
                                                                                                                                int largeSize = 10000;
                                                                                                                                Object[] result = distribution.sample(largeSize);
                                                                                                                                assertEquals(largeSize, result.length);
                                                                                                                                
                                                                                                                                // Verify all elements are "A"
                                                                                                                                for (Object item : result) {
                                                                                                                                    assertEquals("A", item);
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                            public void testSample_EmptyDistribution() {
                                                                                                                // Setup empty distribution (shouldn't happen as constructor validates, but test anyway)
                                                                                                                RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                List<org.apache.commons.math3.util.Pair<String, Double>> emptySamples = 
                                                                                                                    new ArrayList<org.apache.commons.math3.util.Pair<String, Double>>();
                                                                                                                
                                                                                                                try {
                                                                                                                    new DiscreteDistribution<>(mockRandom, emptySamples);
                                                                                                                    fail("Expected IllegalArgumentException");
                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                    // expected
                                                                                                                }
                                                                                                            }

    @Test
                                                                                        public void testSample_InvalidSampleSize() {
                                                                                            // Setup
                                                                                            java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                                                                                                new org.apache.commons.math3.util.Pair<>("A", 0.5),
                                                                                                new org.apache.commons.math3.util.Pair<>("B", 0.5)
                                                                                            );
                                                                                            org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution = 
                                                                                                new org.apache.commons.math3.distribution.DiscreteDistribution<>(samples);
                                                                                            
                                                                                            // Test zero sample size
                                                                                            try {
                                                                                                distribution.sample(0);
                                                                                                org.junit.Assert.fail("Expected NotStrictlyPositiveException");
                                                                                            } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
                                                                                                org.hamcrest.MatcherAssert.assertThat(e.getMessage(), 
                                                                                                    org.hamcrest.CoreMatchers.containsString("number of samples"));
                                                                                            }
                                                                                            
                                                                                            // Test negative sample size
                                                                                            try {
                                                                                                distribution.sample(-1);
                                                                                                org.junit.Assert.fail("Expected NotStrictlyPositiveException");
                                                                                            } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
                                                                                                org.hamcrest.MatcherAssert.assertThat(e.getMessage(), 
                                                                                                    org.hamcrest.CoreMatchers.containsString("number of samples"));
                                                                                            }
                                                                                        }

    @Test
                                                                                    public void testSample_ValidSampleSize() {
                                                                                        // Create mock RandomGenerator
                                                                                        org.apache.commons.math3.random.RandomGenerator mockRandom = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                        mockRandom.setSeed(123L); // Set seed for predictable results
                                                                                        
                                                                                        // Create samples list
                                                                                        java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                                                                                            new org.apache.commons.math3.util.Pair<>("A", 0.4),
                                                                                            new org.apache.commons.math3.util.Pair<>("B", 0.6)
                                                                                        );
                                                                                        
                                                                                        org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution = 
                                                                                            new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                        
                                                                                        // Test with sample size 1
                                                                                        Object[] result1 = distribution.sample(1);
                                                                                        org.junit.Assert.assertEquals(1, result1.length);
                                                                                        org.junit.Assert.assertEquals("A", result1[0]); // 0.3 < 0.4 -> A
                                                                                        
                                                                                        // Test with sample size 3
                                                                                        Object[] result3 = distribution.sample(3);
                                                                                        org.junit.Assert.assertEquals(3, result3.length);
                                                                                        org.junit.Assert.assertEquals("A", result3[0]); // 0.3 < 0.4 -> A
                                                                                        org.junit.Assert.assertEquals("B", result3[1]); // 0.7 > 0.4 -> B
                                                                                        org.junit.Assert.assertEquals("A", result3[2]); // 0.1 < 0.4 -> A
                                                                                    }

    @Test
                                                                                public void testSample_ReturnsCorrectSingletonBasedOnProbability() {
                                                                                    // Setup test data
                                                                                    java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                                                                                        new org.apache.commons.math3.util.Pair<>("A", 0.2),
                                                                                        new org.apache.commons.math3.util.Pair<>("B", 0.3),
                                                                                        new org.apache.commons.math3.util.Pair<>("C", 0.5)
                                                                                    );
                                                                                    
                                                                                    // Create mock RandomGenerator
                                                                                    org.apache.commons.math3.random.RandomGenerator mockRandom = new org.apache.commons.math3.random.RandomGenerator() {
                                                                                        private double nextValue = 0.1;
                                                                                        
                                                                                        @Override
                                                                                        public double nextDouble() {
                                                                                            double value = nextValue;
                                                                                            // Cycle through the test values for each test case
                                                                                            if (nextValue == 0.1) {
                                                                                                nextValue = 0.25;
                                                                                            } else if (nextValue == 0.25) {
                                                                                                nextValue = 0.6;
                                                                                            } else {
                                                                                                nextValue = 0.1;
                                                                                            }
                                                                                            return value;
                                                                                        }
                                                                                        
                                                                                        // Implement all other required methods with default values
                                                                                        @Override public void setSeed(int seed) {}
                                                                                        @Override public void setSeed(int[] seed) {}
                                                                                        @Override public void setSeed(long seed) {}
                                                                                        @Override public void nextBytes(byte[] bytes) {}
                                                                                        @Override public int nextInt() { return 0; }
                                                                                        @Override public int nextInt(int n) { return 0; }
                                                                                        @Override public long nextLong() { return 0; }
                                                                                        @Override public boolean nextBoolean() { return false; }
                                                                                        @Override public float nextFloat() { return 0; }
                                                                                        @Override public double nextGaussian() { return 0; }
                                                                                    };
                                                                                    
                                                                                    // Test case 1: randomValue = 0.1 (should return "A")
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist1 = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("A", dist1.sample());
                                                                                    
                                                                                    // Test case 2: randomValue = 0.25 (should return "B")
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist2 = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("B", dist2.sample());
                                                                                    
                                                                                    // Test case 3: randomValue = 0.6 (should return "C")
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist3 = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("C", dist3.sample());
                                                                                }

    @Test
                                                                                public void testSample_ReturnsLastSingletonWhenRandomValueIsVeryCloseTo() {
                                                                                    // Setup test data
                                                                                    java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                                                                                        new org.apache.commons.math3.util.Pair<>("A", 0.2),
                                                                                        new org.apache.commons.math3.util.Pair<>("B", 0.3),
                                                                                        new org.apache.commons.math3.util.Pair<>("C", 0.5)
                                                                                    );
                                                                                    
                                                                                    // Mock RandomGenerator to return value just below 1.0
                                                                                    org.apache.commons.math3.random.RandomGenerator mockRandom = new org.apache.commons.math3.random.RandomGenerator() {
                                                                                        @Override
                                                                                        public double nextDouble() {
                                                                                            return 0.9999999999; // Value just below 1.0
                                                                                        }
                                                                                        
                                                                                        // Implement all other required methods with default values
                                                                                        @Override public void setSeed(int seed) {}
                                                                                        @Override public void setSeed(int[] seed) {}
                                                                                        @Override public void setSeed(long seed) {}
                                                                                        @Override public void nextBytes(byte[] bytes) {}
                                                                                        @Override public int nextInt() { return 0; }
                                                                                        @Override public int nextInt(int n) { return 0; }
                                                                                        @Override public long nextLong() { return 0; }
                                                                                        @Override public boolean nextBoolean() { return false; }
                                                                                        @Override public float nextFloat() { return 0; }
                                                                                        @Override public double nextGaussian() { return 0; }
                                                                                    };
                                                                                    
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("C", dist.sample());
                                                                                }

    @Test
                                                                                public void testSample_WithExtremeProbabilities() {
                                                                                    // Setup test data with one dominant probability
                                                                                    java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = new java.util.ArrayList<>();
                                                                                    samples.add(new org.apache.commons.math3.util.Pair<>("Rare", 0.0001));
                                                                                    samples.add(new org.apache.commons.math3.util.Pair<>("Common", 0.9999));
                                                                                    
                                                                                    // Mock RandomGenerator
                                                                                    org.apache.commons.math3.random.RandomGenerator mockRandom = new org.apache.commons.math3.random.RandomGenerator() {
                                                                                        @Override
                                                                                        public double nextDouble() {
                                                                                            // First call returns very small value (0.00001) for "Rare" case
                                                                                            // Second call returns normal value (0.5) for "Common" case
                                                                                            if (getCallCount() == 0) {
                                                                                                incrementCallCount();
                                                                                                return 0.00001;
                                                                                            } else {
                                                                                                return 0.5;
                                                                                            }
                                                                                        }
                                                                                        
                                                                                        // Dummy implementation for other required methods
                                                                                        private int callCount = 0;
                                                                                        private int getCallCount() { return callCount; }
                                                                                        private void incrementCallCount() { callCount++; }
                                                                                        
                                                                                        public void setSeed(int seed) {}
                                                                                        public void setSeed(int[] seed) {}
                                                                                        public void setSeed(long seed) {}
                                                                                        public void nextBytes(byte[] bytes) {}
                                                                                        public int nextInt() { return 0; }
                                                                                        public int nextInt(int n) { return 0; }
                                                                                        public long nextLong() { return 0; }
                                                                                        public boolean nextBoolean() { return false; }
                                                                                        public float nextFloat() { return 0; }
                                                                                        public double nextGaussian() { return 0; }
                                                                                    };
                                                                                    
                                                                                    // Test case 1: very small random value (should return "Rare")
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("Rare", dist.sample());
                                                                                    
                                                                                    // Test case 2: normal random value (should return "Common")
                                                                                    org.junit.Assert.assertEquals("Common", dist.sample());
                                                                                }

    @Test
                                                                                public void testSample_WithEqualProbabilities() {
                                                                                    // Setup test data with equal probabilities
                                                                                    java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = new java.util.ArrayList<>();
                                                                                    samples.add(new org.apache.commons.math3.util.Pair<>("X", 0.333));
                                                                                    samples.add(new org.apache.commons.math3.util.Pair<>("Y", 0.333));
                                                                                    samples.add(new org.apache.commons.math3.util.Pair<>("Z", 0.334)); // slight difference due to floating point
                                                                                    
                                                                                    // Mock RandomGenerator
                                                                                    org.apache.commons.math3.random.RandomGenerator mockRandom = new org.apache.commons.math3.random.RandomGenerator() {
                                                                                        @Override
                                                                                        public double nextDouble() {
                                                                                            // This will be called in sequence for each test case
                                                                                            if (nextDoubleCallCount++ == 0) return 0.1;  // first third - X
                                                                                            if (nextDoubleCallCount == 1) return 0.4;   // second third - Y
                                                                                            return 0.8;                                  // last third - Z
                                                                                        }
                                                                                        
                                                                                        private int nextDoubleCallCount = 0;
                                                                                        
                                                                                        // Implement all other required methods with default values
                                                                                        @Override public void setSeed(int seed) {}
                                                                                        @Override public void setSeed(int[] seed) {}
                                                                                        @Override public void setSeed(long seed) {}
                                                                                        @Override public void nextBytes(byte[] bytes) {}
                                                                                        @Override public int nextInt() { return 0; }
                                                                                        @Override public int nextInt(int n) { return 0; }
                                                                                        @Override public long nextLong() { return 0; }
                                                                                        @Override public boolean nextBoolean() { return false; }
                                                                                        @Override public float nextFloat() { return 0; }
                                                                                        @Override public double nextGaussian() { return 0; }
                                                                                    };
                                                                                    
                                                                                    // Test case 1: first third
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist1 = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("X", dist1.sample());
                                                                                    
                                                                                    // Test case 2: second third
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist2 = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("Y", dist2.sample());
                                                                                    
                                                                                    // Test case 3: last third
                                                                                    org.apache.commons.math3.distribution.DiscreteDistribution<String> dist3 = 
                                                                                        new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                                                                    org.junit.Assert.assertEquals("Z", dist3.sample());
                                                                                }

    @Test
                                                                        public void testSampleWithSizeOneShouldNotThrowException() {
                                                                            // Create a sample list for the distribution
                                                                            List<Pair<String, Double>> samples = new ArrayList<>();
                                                                            samples.add(new Pair<>("test", 1.0));
                                                                            
                                                                            // Create the distribution instance
                                                                            DiscreteDistribution<String> dist = new DiscreteDistribution<>(samples);
                                                                            
                                                                            // This test will pass for original code but fail for mutant
                                                                            try {
                                                                                Object[] result = dist.sample(1);
                                                                                assertNotNull(result);
                                                                                assertEquals(1, result.length);
                                                                            } catch (IllegalArgumentException e) {
                                                                                fail("sample(1) should not throw exception in original implementation");
                                                                            }
                                                                        }

    @Test
                                                                        public void testSampleWithSizeTwoShouldNotThrowException() {
                                                                            // Create sample data for the distribution
                                                                            List<Pair<String, Double>> samples = new ArrayList<>();
                                                                            samples.add(new Pair<>("A", 0.5));
                                                                            samples.add(new Pair<>("B", 0.5));
                                                                            
                                                                            // Create distribution instance
                                                                            DiscreteDistribution<String> dist = new DiscreteDistribution<>(samples);
                                                                            
                                                                            // This test should pass for both original and mutant
                                                                            try {
                                                                                Object[] result = dist.sample(2);
                                                                                assertNotNull(result);
                                                                                assertEquals(2, result.length);
                                                                            } catch (IllegalArgumentException e) {
                                                                                fail("sample(2) should not throw exception");
                                                                            }
                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                    public void testSampleWithSizeZeroShouldThrowException() {
                                                                        // Create a sample list for the distribution
                                                                        List<Pair<String, Double>> samples = new ArrayList<Pair<String, Double>>();
                                                                        samples.add(new Pair<String, Double>("test", 1.0));
                                                                        
                                                                        // Create the distribution
                                                                        DiscreteDistribution<String> dist = new DiscreteDistribution<String>(samples);
                                                                        
                                                                        // This should throw IllegalArgumentException
                                                                        dist.sample(0);
                                                                    }

    @Test
                                                                    public void testReseedRandomGenerator() {
                                                                        // Setup
                                                                        long testSeed = 12345L;
                                                                        RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                        List<Pair<String, Double>> samples = new ArrayList<>();
                                                                        samples.add(new Pair<>("A", 0.5));
                                                                        samples.add(new Pair<>("B", 0.5));
                                                                        
                                                                        // Create instance with mocked random generator
                                                                        DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                        
                                                                        // Test the method
                                                                        distribution.reseedRandomGenerator(testSeed);
                                                                        
                                                                        // Verify the seed was set
                                                                        verify(mockRandom).setSeed(testSeed);
                                                                    }

    @Test
                                                        public void testReseedRandomGeneratorProducesDeterministicSamples() {
                                                            // Setup with known seed
                                                            long testSeed = 54321L;
                                                            List<Pair<String, Double>> samples = new ArrayList<Pair<String, Double>>();
                                                            samples.add(new Pair<String, Double>("A", 0.5));
                                                            samples.add(new Pair<String, Double>("B", 0.5));
                                                            
                                                            // Create two identical distributions with same random generator
                                                            RandomGenerator rng1 = new Well19937c(testSeed);
                                                            RandomGenerator rng2 = new Well19937c(testSeed);
                                                            DiscreteDistribution<String> dist1 = new DiscreteDistribution<String>(rng1, samples);
                                                            DiscreteDistribution<String> dist2 = new DiscreteDistribution<String>(rng2, samples);
                                                            
                                                            // Reseed both with same seed
                                                            long newSeed = 98765L;
                                                            dist1.reseedRandomGenerator(newSeed);
                                                            dist2.reseedRandomGenerator(newSeed);
                                                            
                                                            // Verify they produce same sequence of samples
                                                            for (int i = 0; i < 10; i++) {
                                                                assertEquals(dist1.sample(), dist2.sample());
                                                            }
                                                        }

    @Test
                                                        public void testReseedRandomGeneratorSetsCorrectSeed() {
                                                            // Arrange
                                                            long testSeed = 12345L;
                                                            RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                            
                                                            // Create a samples list (content doesn't matter for this test)
                                                            List<Pair<String, Double>> samples = new ArrayList<>();
                                                            samples.add(new Pair<>("test", 1.0));
                                                            
                                                            // Create instance with mocked random generator
                                                            DiscreteDistribution<String> distribution = 
                                                                new DiscreteDistribution<>(mockRandom, samples);
                                                            
                                                            // Act
                                                            distribution.reseedRandomGenerator(testSeed);
                                                            
                                                            // Assert
                                                            verify(mockRandom).setSeed(testSeed); // Verify setSeed was called with correct seed
                                                        }

    @Test
                                                public void testSampleSizeDoesNotCreateMirroredSamples() {
                                                    // Setup test data
                                                    List<Pair<String, Double>> samples = new ArrayList<>();
                                                    samples.add(new Pair<>("A", 0.5));
                                                    samples.add(new Pair<>("B", 0.3));
                                                    samples.add(new Pair<>("C", 0.2));
                                                    
                                                    // Create discrete distribution
                                                    DiscreteDistribution<String> dist = new DiscreteDistribution<>(samples);
                                                    
                                                    // Get a sample of size 5
                                                    int sampleSize = 5;
                                                    Object[] result = dist.sample(sampleSize);
                                                    
                                                    // Verify basic properties
                                                    assertEquals(sampleSize, result.length);
                                                    
                                                    // Verify no mirrored duplicates (which would indicate the mutant)
                                                    for (int i = 0; i < sampleSize / 2; i++) {
                                                        int mirrorIndex = sampleSize - i - 1;
                                                        assertNotEquals("Samples should not be mirrored at positions " + i + " and " + mirrorIndex, 
                                                                       result[i], result[mirrorIndex]);
                                                    }
                                                    
                                                    // Verify all samples are valid options
                                                    for (Object item : result) {
                                                        assertTrue(samples.stream().anyMatch(p -> p.getKey().equals(item)));
                                                    }
                                                }

    @Test
                                    public void testSampleWithDifferentSizes() {
                                        // Setup test data
                                        List<org.apache.commons.math3.util.Pair<String, Double>> samples = new ArrayList<>();
                                        samples.add(new org.apache.commons.math3.util.Pair<>("A", 0.5));
                                        samples.add(new org.apache.commons.math3.util.Pair<>("B", 0.3));
                                        samples.add(new org.apache.commons.math3.util.Pair<>("C", 0.2));
                                        
                                        // Mock the RandomGenerator
                                        org.apache.commons.math3.random.RandomGenerator mockRandom = mock(org.apache.commons.math3.random.RandomGenerator.class);
                                        when(mockRandom.nextDouble()).thenReturn(0.1, 0.6, 0.9, 0.4, 0.7, 0.2);
                                        
                                        // Create instance with mock random generator
                                        org.apache.commons.math3.distribution.DiscreteDistribution<String> distribution = 
                                            new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, samples);
                                        
                                        // Test with sample size equal to 3 (boundary case)
                                        Object[] result1 = distribution.sample(3);
                                        assertEquals(3, result1.length);
                                        
                                        // Test with sample size larger than typical usage
                                        Object[] result2 = distribution.sample(5);
                                        assertEquals(5, result2.length);
                                        
                                        // Test with sample size of 1 (edge case)
                                        Object[] result3 = distribution.sample(1);
                                        assertEquals(1, result3.length);
                                        
                                        // Verify all samples were generated properly
                                        // The mutant would fail to generate all samples if the condition was incorrect
                                        for (Object sample : result1) {
                                            assertNotNull(sample);
                                        }
                                        for (Object sample : result2) {
                                            assertNotNull(sample);
                                        }
                                        for (Object sample : result3) {
                                            assertNotNull(sample);
                                        }
                                    }

    @Test
                            public void testReseedRandomGenerator1() {
                                // Setup test data
                                java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                                    new org.apache.commons.math3.util.Pair<>("A", 0.3),
                                    new org.apache.commons.math3.util.Pair<>("B", 0.7)
                                );
                                
                                // Create instance with known seed
                                long initialSeed = 12345L;
                                org.apache.commons.math3.random.Well19937c rng = new org.apache.commons.math3.random.Well19937c(initialSeed);
                                org.apache.commons.math3.distribution.DiscreteDistribution<String> dist = 
                                    new org.apache.commons.math3.distribution.DiscreteDistribution<>(rng, samples);
                                
                                // Get first sample with initial seed
                                String firstSample1 = dist.sample();
                                
                                // Reseed with same seed
                                dist.reseedRandomGenerator(initialSeed);
                                String firstSample2 = dist.sample();
                                
                                // Samples should be identical after reseeding
                                org.junit.Assert.assertEquals("Reseeding with same seed should produce same sequence", 
                                    firstSample1, firstSample2);
                                    
                                // Now test with different seed
                                long newSeed = 67890L;
                                dist.reseedRandomGenerator(newSeed);
                                String firstSampleNewSeed = dist.sample();
                                
                                // Should be different from original (with very high probability)
                                org.junit.Assert.assertNotEquals("Reseeding with different seed should produce different sequence",
                                    firstSample1, firstSampleNewSeed);
                            }

    @Test
                    public void testReseedRandomGenerator2() {
                        // Setup test data
                        java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                            new org.apache.commons.math3.util.Pair<>("A", 0.3),
                            new org.apache.commons.math3.util.Pair<>("B", 0.7)
                        );
                        
                        // Create instance with known initial state
                        org.apache.commons.math3.distribution.DiscreteDistribution<String> dist = 
                            new org.apache.commons.math3.distribution.DiscreteDistribution<>(
                                new org.apache.commons.math3.random.Well19937c(), 
                                samples
                            );
                        
                        // Set a specific seed
                        long seed = 12345L;
                        dist.reseedRandomGenerator(seed);
                        
                        // Get first sample - should be deterministic with this seed
                        String firstSample = dist.sample();
                        
                        // Reseed with same seed
                        dist.reseedRandomGenerator(seed);
                        
                        // Get sample again - should be same as first sample if seed was set correctly
                        String secondSample = dist.sample();
                        
                        // Verify the sequence is reproducible with same seed
                        assertEquals("Random sequence should be reproducible with same seed", 
                                    firstSample, secondSample);
                        
                        // Additional verification: get multiple samples and verify sequence
                        dist.reseedRandomGenerator(seed);
                        String[] expectedSequence = new String[] {
                            dist.sample(),
                            dist.sample(),
                            dist.sample()
                        };
                        
                        dist.reseedRandomGenerator(seed);
                        for (String expected : expectedSequence) {
                            assertEquals(expected, dist.sample());
                        }
                    }

    @Test
                public void testSampleSizeShouldCallSampleOncePerElement() {
                    // Setup test data
                    List<Pair<String, Double>> samples = new ArrayList<>();
                    samples.add(new Pair<>("A", 0.5));
                    samples.add(new Pair<>("B", 0.5));
                    
                    // Mock the random generator
                    RandomGenerator mockRandom = mock(RandomGenerator.class);
                    
                    // Create discrete distribution with our mock
                    DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
                    
                    // Mock sample() behavior to return alternating values
                    when(dist.sample())
                        .thenReturn("A")  // first call returns A
                        .thenReturn("B")  // second call returns B
                        .thenReturn("A")  // third call returns A
                        .thenReturn("B"); // fourth call returns B
                    
                    // Call the method under test
                    Object[] result = dist.sample(2);
                    
                    // Verify the results - should be A,B if called once per element
                    // If mutant is present, would be B,B because each element gets second sample() call
                    assertEquals("A", result[0]);
                    assertEquals("B", result[1]);
                    
                    // Verify sample() was called exactly twice (once per element)
                    verify(dist, times(2)).sample();
                }

    @Test
        public void testSampleReturnsCorrectWeightedElement() {
            // Setup test data with known probabilities
            java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samples = java.util.Arrays.asList(
                new org.apache.commons.math3.util.Pair<>("A", 0.1),  // 10% probability
                new org.apache.commons.math3.util.Pair<>("B", 0.1),  // 10% probability
                new org.apache.commons.math3.util.Pair<>("C", 0.8)    // 80% probability - should be returned most often
            );
            
            // Create distribution with deterministic random for testing
            org.apache.commons.math3.random.Well19937c random = new org.apache.commons.math3.random.Well19937c(12345L);
            org.apache.commons.math3.distribution.DiscreteDistribution<String> dist = 
                new org.apache.commons.math3.distribution.DiscreteDistribution<>(random, samples);
            
            // Sample multiple times and count occurrences
            int countA = 0, countB = 0, countC = 0;
            final int sampleCount = 1000;
            for (int i = 0; i < sampleCount; i++) {
                String result = dist.sample();
                switch (result) {
                    case "A": countA++; break;
                    case "B": countB++; break;
                    case "C": countC++; break;
                }
            }
            
            // Verify C is returned most often (original behavior)
            // The mutant would return A as often as C since it always gets index 0
            assertTrue("C should be sampled most frequently", countC > countA * 2);
            assertTrue("C should be sampled most frequently", countC > countB * 2);
            
            // Verify the distribution roughly matches expected probabilities
            assertEquals(0.1, (double)countA/sampleCount, 0.05);
            assertEquals(0.1, (double)countB/sampleCount, 0.05);
            assertEquals(0.8, (double)countC/sampleCount, 0.05);
        }

    @Test
    public void testSampleReturnsLastElementNotMiddle() {
        // Create sample data with 3 elements (odd number)
        List<Pair<String, Double>> samples = new ArrayList<>();
        samples.add(new Pair<>("first", 0.2));
        samples.add(new Pair<>("middle", 0.3));
        samples.add(new Pair<>("last", 0.5));
        
        // Create DiscreteDistribution instance
        DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
        
        // Mock the random generator to always return a value that would select the last element
        // The probabilities are normalized to [0.2, 0.5, 1.0], so any value >= 0.5 will select last
        RandomGenerator mockRandom = mock(RandomGenerator.class);
        when(mockRandom.nextDouble()).thenReturn(0.5);
        
        // Use reflection to replace the random generator with our mock
        try {
            Field randomField = DiscreteDistribution.class.getDeclaredField("random");
            randomField.setAccessible(true);
            randomField.set(distribution, mockRandom);
        } catch (Exception e) {
            fail("Failed to set mock random generator");
        }
        
        // Verify sample() returns the last element, not the middle one
        assertEquals("last", distribution.sample());
        
        // Verify the mock was called
        verify(mockRandom).nextDouble();
    }

}
