package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class HypergeometricDistributionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                public void testGetNumericalMean_StandardCase() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 10);
                                                    
                                                    // Act & Assert
                                                    // Expected: 10 * (20 / 100) = 2.0
                                                    assertEquals(2.0, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                                public void testGetNumericalMean_AllSuccesses() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(100, 100, 10);
                                                    
                                                    // Act & Assert
                                                    // Expected: 10 * (100 / 100) = 10.0
                                                    assertEquals(10.0, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                                public void testGetNumericalMean_NoSuccesses() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(100, 0, 10);
                                                    
                                                    // Act & Assert
                                                    // Expected: 10 * (0 / 100) = 0.0
                                                    assertEquals(0.0, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                                public void testGetNumericalMean_FullSample() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 100);
                                                    
                                                    // Act & Assert
                                                    // Expected: 100 * (20 / 100) = 20.0
                                                    assertEquals(20.0, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                                public void testGetNumericalMean_FractionalResult() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(7, 3, 5);
                                                    
                                                    // Act & Assert
                                                    // Expected: 5 * (3 / 7) ≈ 2.142857
                                                    assertEquals(2.142857, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                                public void testGetNumericalMean_WithMockedValues() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                                                    when(distribution.getSampleSize()).thenReturn(5);
                                                    when(distribution.getNumberOfSuccesses()).thenReturn(3);
                                                    when(distribution.getPopulationSize()).thenReturn(7);
                                                    when(distribution.getNumericalMean()).thenCallRealMethod();
                                                    
                                                    // Act & Assert
                                                    // Expected: 5 * (3 / 7) ≈ 2.142857
                                                    assertEquals(2.142857, distribution.getNumericalMean(), 0.0001);
                                                    
                                                    // Verify interactions
                                                    verify(distribution).getSampleSize();
                                                    verify(distribution).getNumberOfSuccesses();
                                                    verify(distribution).getPopulationSize();
                                                }

    @Test
                                                public void testGetNumericalMean_EdgeCaseMinimumValues() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(1, 1, 1);
                                                    
                                                    // Act & Assert
                                                    // Expected: 1 * (1 / 1) = 1.0
                                                    assertEquals(1.0, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                                public void testGetNumericalMean_WhenPopulationSizeIsOne() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(1, 0, 1);
                                                    
                                                    // Act & Assert
                                                    // Expected: 1 * (0 / 1) = 0.0
                                                    assertEquals(0.0, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                                public void testGetNumericalMean_WithLargeNumbers() {
                                                    // Arrange
                                                    HypergeometricDistribution distribution = new HypergeometricDistribution(1000000, 500000, 100000);
                                                    
                                                    // Act & Assert
                                                    // Expected: 100000 * (500000 / 1000000) = 50000.0
                                                    assertEquals(50000.0, distribution.getNumericalMean(), 0.0001);
                                                }

    @Test
                                        public void testCumulativeProbabilityWithinDomainShouldNotReturnZero() {
                                            // Arrange
                                            int populationSize = 10;
                                            int numberOfSuccesses = 5;
                                            int sampleSize = 3;
                                            HypergeometricDistribution distribution = new HypergeometricDistribution(populationSize, numberOfSuccesses, sampleSize);
                                            
                                            // Choose x within domain bounds (for these parameters, domain should be [max(0,3+5-10), min(3,5)] = [0,3])
                                            int x = 2;  // Clearly within [0,3] domain
                                            
                                            // Act
                                            double result = distribution.cumulativeProbability(x);
                                            
                                            // Assert
                                            // The result should be a calculated probability, not 0.0
                                            assertTrue("Result should be greater than 0 for x within domain", result > 0.0);
                                            assertTrue("Result should be less than 1 for x within domain", result < 1.0);
                                            
                                            // Additional check to ensure it's not exactly 0.0 which would indicate the mutant
                                            assertNotEquals(0.0, result, 0.000001);
                                        }

    @Test
                                public void testCumulativeProbabilityDetectsInnerProbabilityMutation() {
                                    // Setup test parameters
                                    int populationSize = 10;
                                    int numberOfSuccesses = 5;
                                    int sampleSize = 3;
                                    int x = 2; // Test value within domain
                                    
                                    // Create partial mock of HypergeometricDistribution
                                    HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                                    
                                    // Stub the methods we need to control
                                    when(distribution.getPopulationSize()).thenReturn(populationSize);
                                    when(distribution.getNumberOfSuccesses()).thenReturn(numberOfSuccesses);
                                    when(distribution.getSampleSize()).thenReturn(sampleSize);
                                    
                                    // Instead of mocking private getDomain(), we'll mock the public support bounds
                                    when(distribution.getSupportLowerBound()).thenReturn(0);
                                    when(distribution.getSupportUpperBound()).thenReturn(3);
                                    
                                    // Mock probability values - key to detecting the mutant
                                    when(distribution.probability(0)).thenReturn(0.1); // x0
                                    when(distribution.probability(1)).thenReturn(0.3); 
                                    when(distribution.probability(2)).thenReturn(0.4); // x1
                                    
                                    // Call real method for cumulativeProbability
                                    when(distribution.cumulativeProbability(anyInt())).thenCallRealMethod();
                                    
                                    // Expected: 0.1 (x0) + 0.3 (x0+1) + 0.4 (x0+2) = 0.8
                                    double expected = 0.8;
                                    double actual = distribution.cumulativeProbability(x);
                                    
                                    // This will fail if the mutant is present (would only use x1's probability)
                                    assertEquals(expected, actual, 0.0001);
                                    
                                    // Verify the interactions
                                    verify(distribution).probability(0);
                                    verify(distribution).probability(1);
                                    verify(distribution).probability(2);
                                }

    @Test
                            public void testCumulativeProbabilityDetectsWhileLoopMutant() {
                                // Setup - create a distribution where innerCumulativeProbability will be called
                                int populationSize = 10;
                                int numberOfSuccesses = 5;
                                int sampleSize = 3;
                                HypergeometricDistribution dist = new HypergeometricDistribution(populationSize, numberOfSuccesses, sampleSize);
                                
                                // Test a value within domain bounds (forces call to innerCumulativeProbability)
                                // For these parameters, domain should be [max(0, 3+5-10), min(3,5)] = [0,3]
                                int x = 1; // Within [0,3]
                                
                                // The test will either:
                                // 1. Pass with original code (correct probability calculated)
                                // 2. Fail with mutant (either infinite loop or wrong probability)
                                double probability = dist.cumulativeProbability(x);
                                
                                // Verify probability is within valid range [0,1]
                                assertTrue("Probability should be between 0 and 1", probability >= 0.0 && probability <= 1.0);
                                
                                // Verify it's not one of the boundary cases (since x is within domain)
                                assertTrue("Probability should not be 0 or 1 for x within domain", 
                                           probability > 0.0 && probability < 1.0);
                                
                                // For more precise verification, we could calculate expected value
                                // But even without exact value, the above assertions would catch:
                                // - Infinite loop (test would timeout)
                                // - Returning 0 or 1 incorrectly
                                // - Any invalid probability value
                            }

    @Test
                        public void testCumulativeProbabilityDetectsInnerCalculationMutant() {
                            // Setup - create a distribution where we'll exercise the inner calculation
                            int populationSize = 10;
                            int numberOfSuccesses = 5;
                            int sampleSize = 3;
                            HypergeometricDistribution dist = new HypergeometricDistribution(populationSize, numberOfSuccesses, sampleSize);
                            
                            // Test a value that will trigger inner calculation
                            // For these parameters, domain should be [max(0, k + m - N) = max(0, 3+5-10) = 0
                            // to min(k, m) = min(3,5) = 3
                            int x = 1; // Between 0 and 3
                            
                            // Calculate expected probability manually for x=1
                            // P(X<=1) = P(0) + P(1)
                            // P(0) = C(5,0)*C(5,3)/C(10,3) = 1*10/120 = 0.08333
                            // P(1) = C(5,1)*C(5,2)/C(10,3) = 5*10/120 = 0.41666
                            double expected = 0.08333 + 0.41666; // ~0.5
                            
                            // The mutant would either:
                            // 1. Not terminate (infinite loop)
                            // 2. Calculate wrong probability if it somehow terminates
                            double actual = dist.cumulativeProbability(x);
                            
                            // Assert with delta for floating point precision
                            assertEquals("Mutant should be detected by incorrect inner calculation", 
                                        expected, actual, 0.0001);
                            
                            // Also test another value to be thorough
                            x = 2;
                            // P(2) = C(5,2)*C(5,1)/C(10,3) = 10*5/120 = 0.41666
                            expected += 0.41666; // ~0.91666
                            actual = dist.cumulativeProbability(x);
                            assertEquals("Mutant should be detected by incorrect inner calculation for x=2",
                                        expected, actual, 0.0001);
                        }

    @Test
                    public void testCumulativeProbabilityDetectsInnerCalculationMutation() {
                        // Setup - create distribution with parameters that will require multiple steps
                        int populationSize = 100;
                        int numberOfSuccesses = 50;
                        int sampleSize = 10;
                        HypergeometricDistribution distribution = new HypergeometricDistribution(populationSize, numberOfSuccesses, sampleSize);
                        
                        // Get domain bounds
                        int lowerBound = distribution.getSupportLowerBound();
                        int upperBound = distribution.getSupportUpperBound();
                        
                        // Test single step range (should be same in original and mutated)
                        double singleStepResult = distribution.cumulativeProbability(lowerBound);
                        
                        // Test multi-step range (will differ between original and mutated)
                        int midPoint = lowerBound + (upperBound - lowerBound)/2;
                        double multiStepResult = distribution.cumulativeProbability(midPoint);
                        
                        // Verify multi-step result is greater than single step (original behavior)
                        // Mutated version would make them equal since it jumps directly to x1
                        assertTrue("Multi-step probability should be greater than single step", 
                                   multiStepResult > singleStepResult);
                        
                        // Additional verification that we're testing a meaningful range
                        assertTrue("Test should use a proper multi-step range", 
                                   (midPoint - lowerBound) > 1);
                    }

    @Test
                public void testCumulativeProbabilityDetectsSubtractionMutant() {
                    // Setup test object with parameters that will lead to innerCumulativeProbability call
                    HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
                    
                    // Mock the probability method to return known values
                    HypergeometricDistribution spyDist = spy(distribution);
                    when(spyDist.probability(anyInt())).thenReturn(0.1, 0.2); // Will return 0.1 first call, 0.2 second
                    
                    // Call with x value that will trigger innerCumulativeProbability
                    // Domain for (10,5,3) is [max(0,3+5-10), min(5,3)] = [0,3]
                    double result = spyDist.cumulativeProbability(1); // Between domain bounds
                    
                    // Verify the result is accumulating probabilities correctly
                    // Original: 0.1 + 0.2 = 0.3
                    // Mutant: 0.1 - 0.2 = -0.1
                    assertEquals("Cumulative probability should sum individual probabilities", 
                                0.3, result, 0.0001);
                    
                    // Verify probability was called twice (for x0=0 and x0=1)
                    verify(spyDist, times(2)).probability(anyInt());
                }

    @Test
        public void testCumulativeProbabilityDetectsSumMutation() throws Exception {
            // Create a real distribution instance first
            HypergeometricDistribution dist = new HypergeometricDistribution(10, 5, 3);
            HypergeometricDistribution spyDist = spy(dist);
            
            // Setup mock behavior for probability calls to return known sequence
            when(spyDist.probability(1)).thenReturn(0.1);
            when(spyDist.probability(2)).thenReturn(0.2);
            when(spyDist.probability(3)).thenReturn(0.3);
            
            // Use reflection to mock private getDomain method
            Method getDomainMethod = HypergeometricDistribution.class.getDeclaredMethod(
                "getDomain", int.class, int.class, int.class);
            getDomainMethod.setAccessible(true);
            when(getDomainMethod.invoke(spyDist, anyInt(), anyInt(), anyInt()))
                .thenReturn(new int[]{1, 5});
            
            // Use reflection to mock private innerCumulativeProbability method
            Method innerCumulativeMethod = HypergeometricDistribution.class.getDeclaredMethod(
                "innerCumulativeProbability", int.class, int.class, int.class);
            innerCumulativeMethod.setAccessible(true);
            when(innerCumulativeMethod.invoke(spyDist, anyInt(), anyInt(), anyInt()))
                .thenCallRealMethod();
            
            // Test value in the middle of the domain
            double result = spyDist.cumulativeProbability(3);
            
            // Verify the correct cumulative sum (0.1 + 0.2 + 0.3 = 0.6)
            assertEquals(0.6, result, 0.0001);
            
            // Verify probability was called for each value in the range
            verify(spyDist).probability(1);
            verify(spyDist).probability(2);
            verify(spyDist).probability(3);
        }

    @Test
    public void testGetNumericalVarianceWithLargeNumbers() {
        // Setup - use large numbers where floating point precision might differ
        int populationSize = Integer.MAX_VALUE / 2;
        int numberOfSuccesses = Integer.MAX_VALUE / 4;
        int sampleSize = Integer.MAX_VALUE / 8;
        
        HypergeometricDistribution dist = new HypergeometricDistribution(
            populationSize, numberOfSuccesses, sampleSize);
        
        // Calculate expected value using original formula
        double expected = sampleSize * (numberOfSuccesses / (double) populationSize);
        expected *= (populationSize - numberOfSuccesses) / (double) populationSize;
        expected *= (populationSize - sampleSize) / (double) (populationSize - 1);
        
        // Verify the actual variance matches expected
        assertEquals(expected, dist.getNumericalVariance(), 1e-10);
        
        // Additional verification that the calculation uses the correct formula
        // by checking intermediate values
        double mean = numberOfSuccesses * (sampleSize / (double) populationSize);
        double variance = mean * (populationSize - numberOfSuccesses) / populationSize;
        variance *= (populationSize - sampleSize) / (populationSize - 1);
        
        // This assertion would fail with the mutant
        assertEquals(expected, variance, 1e-10);
    }

}
