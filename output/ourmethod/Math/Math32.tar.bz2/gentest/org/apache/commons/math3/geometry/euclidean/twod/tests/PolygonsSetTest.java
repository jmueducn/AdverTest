package gentest.org.apache.commons.math3.geometry.euclidean.twod.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.twod.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane;
import org.apache.commons.math3.geometry.partitioning.BSPTree;
import org.apache.commons.math3.geometry.partitioning.BSPTreeVisitor;
import org.apache.commons.math3.geometry.partitioning.BoundaryAttribute;
import org.apache.commons.math3.geometry.partitioning.SubHyperplane;
import org.apache.commons.math3.geometry.partitioning.AbstractRegion;
import org.apache.commons.math3.geometry.partitioning.utilities.AVLTree;
import org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple;
import org.apache.commons.math3.util.FastMath;
 
public class PolygonsSetTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                                                                                                                                                            public void testComputeGeometricalProperties_EmptyVertices_CoversWholeSpace() throws Exception {
                                                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                                                PolygonsSet polygonsSet = new PolygonsSet();
                                                                                                                                                                                                                                                                                                                BSPTree<Euclidean2D> tree = new BSPTree<>(Boolean.TRUE);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Use reflection to set the tree
                                                                                                                                                                                                                                                                                                                Field treeField = PolygonsSet.class.getSuperclass().getDeclaredField("tree");
                                                                                                                                                                                                                                                                                                                treeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                treeField.set(polygonsSet, tree);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Use reflection to call computeGeometricalProperties
                                                                                                                                                                                                                                                                                                                Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                                                                                                                                computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                computeMethod.invoke(polygonsSet);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Verify results using reflection
                                                                                                                                                                                                                                                                                                                Field sizeField = PolygonsSet.class.getSuperclass().getDeclaredField("size");
                                                                                                                                                                                                                                                                                                                sizeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                double size = (Double) sizeField.get(polygonsSet);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                Field barycenterField = PolygonsSet.class.getSuperclass().getDeclaredField("barycenter");
                                                                                                                                                                                                                                                                                                                barycenterField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                Vector2D barycenter = (Vector2D) barycenterField.get(polygonsSet);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, size, 0.0);
                                                                                                                                                                                                                                                                                                                assertTrue(Double.isNaN(barycenter.getX()));
                                                                                                                                                                                                                                                                                                                assertTrue(Double.isNaN(barycenter.getY()));
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                            public void testComputeGeometricalProperties_ClosedLoop_InfiniteArea() throws Exception {
                                                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                                                // Create a polygon with negative sum (infinite area) by using the constructor that takes a BSPTree
                                                                                                                                                                                                                                                                                                                // First create the vertices for a clockwise triangle (will produce negative area)
                                                                                                                                                                                                                                                                                                                Vector2D[] vertices = new Vector2D[]{
                                                                                                                                                                                                                                                                                                                    new Vector2D(0, 0),
                                                                                                                                                                                                                                                                                                                    new Vector2D(1, 0),
                                                                                                                                                                                                                                                                                                                    new Vector2D(0, 1)
                                                                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Create segments from the vertices
                                                                                                                                                                                                                                                                                                                Line[] lines = new Line[vertices.length];
                                                                                                                                                                                                                                                                                                                Vector2D prev = vertices[vertices.length - 1];
                                                                                                                                                                                                                                                                                                                for (int i = 0; i < vertices.length; i++) {
                                                                                                                                                                                                                                                                                                                    lines[i] = new Line(prev, vertices[i]);
                                                                                                                                                                                                                                                                                                                    prev = vertices[i];
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Create subhyperplanes from the lines
                                                                                                                                                                                                                                                                                                                List<SubHyperplane<Euclidean2D>> subHyperplanes = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                for (Line line : lines) {
                                                                                                                                                                                                                                                                                                                    subHyperplanes.add(new SubLine(line, new IntervalsSet(0, 1)));
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Create the polygons set
                                                                                                                                                                                                                                                                                                                PolygonsSet polygonsSet = new PolygonsSet(subHyperplanes);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Use reflection to access protected methods for verification
                                                                                                                                                                                                                                                                                                                Class<?> cls = polygonsSet.getClass();
                                                                                                                                                                                                                                                                                                                Method computeGeometricalProperties = cls.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                                                                                                                                computeGeometricalProperties.setAccessible(true);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                Field sizeField = cls.getSuperclass().getDeclaredField("size");
                                                                                                                                                                                                                                                                                                                sizeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                Field barycenterField = cls.getSuperclass().getDeclaredField("barycenter");
                                                                                                                                                                                                                                                                                                                barycenterField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                                                                                computeGeometricalProperties.invoke(polygonsSet);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, sizeField.getDouble(polygonsSet));
                                                                                                                                                                                                                                                                                                                assertTrue(((Vector2D)barycenterField.get(polygonsSet)).isNaN());
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                            public void testComputeGeometricalProperties_MultipleClosedLoops() throws Exception {
                                                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                                                PolygonsSet polygonsSet = new PolygonsSet();
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Create two square polygons (one inside the other)
                                                                                                                                                                                                                                                                                                                Vector2D[][] vertices = new Vector2D[2][4];
                                                                                                                                                                                                                                                                                                                vertices[0] = new Vector2D[]{ // Outer square
                                                                                                                                                                                                                                                                                                                    new Vector2D(0, 0),
                                                                                                                                                                                                                                                                                                                    new Vector2D(2, 0),
                                                                                                                                                                                                                                                                                                                    new Vector2D(2, 2),
                                                                                                                                                                                                                                                                                                                    new Vector2D(0, 2)
                                                                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                                                                vertices[1] = new Vector2D[]{ // Inner square
                                                                                                                                                                                                                                                                                                                    new Vector2D(0.5, 0.5),
                                                                                                                                                                                                                                                                                                                    new Vector2D(1.5, 0.5),
                                                                                                                                                                                                                                                                                                                    new Vector2D(1.5, 1.5),
                                                                                                                                                                                                                                                                                                                    new Vector2D(0.5, 1.5)
                                                                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Use reflection to set vertices
                                                                                                                                                                                                                                                                                                                Field verticesField = PolygonsSet.class.getDeclaredField("vertices");
                                                                                                                                                                                                                                                                                                                verticesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                verticesField.set(polygonsSet, vertices);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Use reflection to call computeGeometricalProperties
                                                                                                                                                                                                                                                                                                                Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                                                                                                                                computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                computeMethod.invoke(polygonsSet);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Use reflection to get size and barycenter
                                                                                                                                                                                                                                                                                                                Method getSizeMethod = PolygonsSet.class.getSuperclass().getDeclaredMethod("getSize");
                                                                                                                                                                                                                                                                                                                getSizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                double size = (Double) getSizeMethod.invoke(polygonsSet);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                Method getBarycenterMethod = PolygonsSet.class.getSuperclass().getDeclaredMethod("getBarycenter");
                                                                                                                                                                                                                                                                                                                getBarycenterMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                Vector2D barycenter = (Vector2D) getBarycenterMethod.invoke(polygonsSet);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                                                                                // Area should be 4 (outer) - 1 (inner) = 3
                                                                                                                                                                                                                                                                                                                assertEquals(3.0, size, 1.0e-10);
                                                                                                                                                                                                                                                                                                                // Barycenter should be at (1, 1) due to symmetry
                                                                                                                                                                                                                                                                                                                assertEquals(1.0, barycenter.getX(), 1.0e-10);
                                                                                                                                                                                                                                                                                                                assertEquals(1.0, barycenter.getY(), 1.0e-10);
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                        public void testComputeGeometricalProperties_ClosedLoop_FiniteArea() throws Exception {
                                                                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                                                                            // Create a real PolygonsSet instance with a square boundary
                                                                                                                                                                                                                                                                            List<SubHyperplane<Euclidean2D>> boundaries = new ArrayList<SubHyperplane<Euclidean2D>>();
                                                                                                                                                                                                                                                                            double tolerance = 1.0e-10;
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Create lines for each side of the square using proper Line constructor
                                                                                                                                                                                                                                                                            // Square vertices: (0,0), (1,0), (1,1), (0,1)
                                                                                                                                                                                                                                                                            // Using Line(point, direction, tolerance) constructor
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Create PolygonsSet using the collection constructor without tolerance
                                                                                                                                                                                                                                                                            PolygonsSet polygonsSet = new PolygonsSet(boundaries);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Use reflection to access protected computeGeometricalProperties method
                                                                                                                                                                                                                                                                            Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                                                                                            computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                                                                            computeMethod.invoke(polygonsSet);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                                                                            // Verify properties through public methods or reflection
                                                                                                                                                                                                                                                                            Method getSizeMethod = polygonsSet.getClass().getSuperclass().getDeclaredMethod("getSize");
                                                                                                                                                                                                                                                                            getSizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                            assertEquals(1.0, (Double)getSizeMethod.invoke(polygonsSet), 1.0e-10);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            Method getBarycenterMethod = polygonsSet.getClass().getSuperclass().getDeclaredMethod("getBarycenter");
                                                                                                                                                                                                                                                                            getBarycenterMethod.setAccessible(true);
                                                                                                                                                                                                                                                                            Vector2D barycenter = (Vector2D)getBarycenterMethod.invoke(polygonsSet);
                                                                                                                                                                                                                                                                            assertEquals(0.5, barycenter.getX(), 1.0e-10);
                                                                                                                                                                                                                                                                            assertEquals(0.5, barycenter.getY(), 1.0e-10);
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                    public void testComputeGeometricalProperties_EmptyVertices_DoesNotCoverWholeSpace() throws Exception {
                                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                                        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[] emptyArray = 
                                                                                                                                                                                                                                                                            new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[0];
                                                                                                                                                                                                                                                                        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> tree = 
                                                                                                                                                                                                                                                                            new org.apache.commons.math3.geometry.partitioning.BSPTree<>(Boolean.FALSE);
                                                                                                                                                                                                                                                                        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet = 
                                                                                                                                                                                                                                                                            new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(tree);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to access protected methods
                                                                                                                                                                                                                                                                        java.lang.reflect.Method computeMethod = org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class
                                                                                                                                                                                                                                                                            .getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                                                                                        computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        java.lang.reflect.Method setSizeMethod = org.apache.commons.math3.geometry.partitioning.AbstractRegion.class
                                                                                                                                                                                                                                                                            .getDeclaredMethod("setSize", double.class);
                                                                                                                                                                                                                                                                        setSizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        java.lang.reflect.Method setBarycenterMethod = org.apache.commons.math3.geometry.partitioning.AbstractRegion.class
                                                                                                                                                                                                                                                                            .getDeclaredMethod("setBarycenter", org.apache.commons.math3.geometry.Vector.class);
                                                                                                                                                                                                                                                                        setBarycenterMethod.setAccessible(true);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                                        computeMethod.invoke(polygonsSet);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                                        // Verify the protected method calls
                                                                                                                                                                                                                                                                        org.apache.commons.math3.geometry.euclidean.twod.Vector2D expectedBarycenter = 
                                                                                                                                                                                                                                                                            new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0, 0);
                                                                                                                                                                                                                                                                        // You might want to add actual assertions here using reflection to verify the internal state
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                public void testComputeGeometricalProperties_OpenLoop() throws Exception {
                                                                                                                                                                                    // Arrange
                                                                                                                                                                                    // Create a real PolygonsSet instance instead of mocking it
                                                                                                                                                                                    org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet = 
                                                                                                                                                                                        new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock the vertices array
                                                                                                                                                                                    org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vertices = 
                                                                                                                                                                                        new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[1][1];
                                                                                                                                                                                    vertices[0][0] = null; // indicates open loop
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set the vertices
                                                                                                                                                                                    java.lang.reflect.Field verticesField = 
                                                                                                                                                                                        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class.getDeclaredField("vertices");
                                                                                                                                                                                    verticesField.setAccessible(true);
                                                                                                                                                                                    verticesField.set(polygonsSet, vertices);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access protected methods
                                                                                                                                                                                    java.lang.reflect.Method computeGeometricalProperties = 
                                                                                                                                                                                        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                    computeGeometricalProperties.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    Class<?> abstractRegionClass = Class.forName("org.apache.commons.math3.geometry.partitioning.AbstractRegion");
                                                                                                                                                                                    java.lang.reflect.Field sizeField = abstractRegionClass.getDeclaredField("size");
                                                                                                                                                                                    sizeField.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    java.lang.reflect.Field barycenterField = abstractRegionClass.getDeclaredField("barycenter");
                                                                                                                                                                                    barycenterField.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Act
                                                                                                                                                                                    computeGeometricalProperties.invoke(polygonsSet);
                                                                                                                                                                                    
                                                                                                                                                                                    // Assert
                                                                                                                                                                                    double size = (Double) sizeField.get(polygonsSet);
                                                                                                                                                                                    org.junit.Assert.assertEquals(0.0, size, 0.0001);
                                                                                                                                                                                    
                                                                                                                                                                                    Object barycenter = barycenterField.get(polygonsSet);
                                                                                                                                                                                    org.junit.Assert.assertNull(barycenter);
                                                                                                                                                                                }

    @Test
                                                                                                                                        public void testBoxBoundaryTreeConstruction() {
                                                                                                                                            // Test parameters for a simple square
                                                                                                                                            double xMin = 0.0;
                                                                                                                                            double xMax = 1.0;
                                                                                                                                            double yMin = 0.0;
                                                                                                                                            double yMax = 1.0;
                                                                                                                                            
                                                                                                                                            // Create polygons with both tree construction modes
                                                                                                                                            org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet falseTreePoly = 
                                                                                                                                                new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(xMin, xMax, yMin, yMax);
                                                                                                                                            
                                                                                                                                            // Verify the vertices are identical regardless of tree construction mode
                                                                                                                                            org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] verticesFalse = falseTreePoly.getVertices();
                                                                                                                                            
                                                                                                                                            // Create a version that would use getTree(true)
                                                                                                                                            // Since we can't directly control this, we'll verify through behavior
                                                                                                                                            // that the vertices remain consistent
                                                                                                                                            org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet trueTreePoly = 
                                                                                                                                                new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(xMin, xMax, yMin, yMax) {
                                                                                                                                                @Override
                                                                                                                                                public org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> 
                                                                                                                                                    getTree(boolean includeBoundaryAttributes) {
                                                                                                                                                    // Verify the original method would get true
                                                                                                                                                    assertTrue(includeBoundaryAttributes);
                                                                                                                                                    return super.getTree(includeBoundaryAttributes);
                                                                                                                                                }
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] verticesTrue = trueTreePoly.getVertices();
                                                                                                                                            
                                                                                                                                            // Assert both versions produce identical vertices
                                                                                                                                            assertEquals(verticesFalse.length, verticesTrue.length);
                                                                                                                                            for (int i = 0; i < verticesFalse.length; i++) {
                                                                                                                                                assertArrayEquals(verticesFalse[i], verticesTrue[i]);
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Additional test: verify the boundary lines are identical
                                                                                                                                            // Access private boxBoundary method via reflection
                                                                                                                                            org.apache.commons.math3.geometry.euclidean.twod.Line[] boundaryLines;
                                                                                                                                            try {
                                                                                                                                                java.lang.reflect.Method boxBoundaryMethod = 
                                                                                                                                                    org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class.getDeclaredMethod(
                                                                                                                                                        "boxBoundary", 
                                                                                                                                                        double.class, double.class, double.class, double.class);
                                                                                                                                                boxBoundaryMethod.setAccessible(true);
                                                                                                                                                boundaryLines = (org.apache.commons.math3.geometry.euclidean.twod.Line[]) 
                                                                                                                                                    boxBoundaryMethod.invoke(null, xMin, xMax, yMin, yMax);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                throw new RuntimeException("Failed to access boxBoundary method", e);
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            assertEquals(4, boundaryLines.length); // Should be 4 lines for a rectangle
                                                                                                                                            
                                                                                                                                            // Verify the box is properly formed
                                                                                                                                            // First line: bottom edge
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMin), boundaryLines[0].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMin)));
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMin), boundaryLines[0].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMin)));
                                                                                                                                            
                                                                                                                                            // Second line: right edge
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMin), boundaryLines[1].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMin)));
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMax), boundaryLines[1].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMax)));
                                                                                                                                            
                                                                                                                                            // Third line: top edge
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMax), boundaryLines[2].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, yMax)));
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMax), boundaryLines[2].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMax)));
                                                                                                                                            
                                                                                                                                            // Fourth line: left edge
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMax), boundaryLines[3].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMax)));
                                                                                                                                            assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMin), boundaryLines[3].toSubSpace(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, yMin)));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testBuildNewWithNullCutAndFalseAttribute() {
                                                                                                                                            // Setup mock tree
                                                                                                                                            BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                            when(tree.getCut()).thenReturn(null);
                                                                                                                                            when(tree.getAttribute()).thenReturn(false);
                                                                                                                                    
                                                                                                                                            // Original would fail here (AND condition), mutant would pass (OR condition)
                                                                                                                                            thrown.expect(IllegalStateException.class);
                                                                                                                                            new PolygonsSet(tree);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testBuildNewWithNonNullCutAndTrueAttribute() {
                                                                                                                                            // Setup mock tree
                                                                                                                                            BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                            SubHyperplane<Euclidean2D> cut = mock(SubHyperplane.class);
                                                                                                                                            when(tree.getCut()).thenReturn(cut);
                                                                                                                                            when(tree.getAttribute()).thenReturn(true);
                                                                                                                                    
                                                                                                                                            // Original would fail here (AND condition), mutant would pass (OR condition)
                                                                                                                                            thrown.expect(IllegalStateException.class);
                                                                                                                                            new PolygonsSet(tree);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testBuildNewWithNullCutAndTrueAttribute() {
                                                                                                                                            // Setup mock tree
                                                                                                                                            BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                            when(tree.getCut()).thenReturn(null);
                                                                                                                                            when(tree.getAttribute()).thenReturn(true);
                                                                                                                                    
                                                                                                                                            // Both original and mutant should pass
                                                                                                                                            new PolygonsSet(tree);
                                                                                                                                            // No exception expected
                                                                                                                                        }

    @Test
                                                                                                                                        public void testBuildNewWithNonNullCutAndFalseAttribute() {
                                                                                                                                            // Setup mock tree
                                                                                                                                            BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                            SubHyperplane<Euclidean2D> cut = mock(SubHyperplane.class);
                                                                                                                                            when(tree.getCut()).thenReturn(cut);
                                                                                                                                            when(tree.getAttribute()).thenReturn(false);
                                                                                                                                    
                                                                                                                                            // Both original and mutant should fail
                                                                                                                                            thrown.expect(IllegalStateException.class);
                                                                                                                                            new PolygonsSet(tree);
                                                                                                                                        }

    @Test
                                                                                                                                    public void testBuildNewWithNonNullCutShouldNotTreatAsEmpty() {
                                                                                                                                        // Create a mock tree that would make original condition false
                                                                                                                                        BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                        when(tree.getCut()).thenReturn(mock(SubHyperplane.class)); // non-null cut
                                                                                                                                        when(tree.getAttribute()).thenReturn(false);
                                                                                                                                        
                                                                                                                                        // Create polygons set with this tree
                                                                                                                                        PolygonsSet set = new PolygonsSet(tree);
                                                                                                                                        
                                                                                                                                        // In original code, this would affect vertices, but mutant will ignore
                                                                                                                                        Vector2D[][] vertices = set.getVertices();
                                                                                                                                        
                                                                                                                                        // Verify behavior differs from empty tree case
                                                                                                                                        // If mutant is present, it might treat this as empty tree
                                                                                                                                        assertNotNull("Vertices should not be null for non-empty tree", vertices);
                                                                                                                                        assertTrue("Should have some vertices for non-empty tree", vertices.length > 0);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testBuildNewWithFalseAttributeShouldNotTreatAsEmpty() {
                                                                                                                                        // Create a mock tree with null cut but false attribute
                                                                                                                                        BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                        when(tree.getCut()).thenReturn(null); // null cut
                                                                                                                                        when(tree.getAttribute()).thenReturn(false); // false attribute
                                                                                                                                        
                                                                                                                                        // Create polygons set with this tree
                                                                                                                                        PolygonsSet set = new PolygonsSet(tree);
                                                                                                                                        
                                                                                                                                        // In original code, this would be treated differently than empty tree
                                                                                                                                        Vector2D[][] vertices = set.getVertices();
                                                                                                                                        
                                                                                                                                        // Verify behavior differs from empty tree case
                                                                                                                                        assertNotNull("Vertices should not be null", vertices);
                                                                                                                                        // Depending on implementation, might check for specific vertex count
                                                                                                                                    }

    @Test
                                                                                                                        public void testBoxBoundarySizeProperty() throws Exception {
                                                                                                                            // Create a PolygonsSet using the box boundary
                                                                                                                            double xMin = 0.0;
                                                                                                                            double xMax = 10.0;
                                                                                                                            double yMin = 0.0;
                                                                                                                            double yMax = 10.0;
                                                                                                                            
                                                                                                                            PolygonsSet polygon = new PolygonsSet(xMin, xMax, yMin, yMax);
                                                                                                                            
                                                                                                                            // Use reflection to access the protected computeGeometricalProperties method
                                                                                                                            Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                            computeGeometricalProperties.setAccessible(true);
                                                                                                                            computeGeometricalProperties.invoke(polygon);
                                                                                                                            
                                                                                                                            // Get the size and verify it's positive infinity
                                                                                                                            double size = polygon.getSize();
                                                                                                                            assertEquals("Box boundary size should be POSITIVE_INFINITY", 
                                                                                                                                        Double.POSITIVE_INFINITY, size, 0.0);
                                                                                                                        }

    @Test
                                                                                                                public void testBoxBoundarySizeProperty1() throws Exception {
                                                                                                                    // Create a polygons set using the box boundary
                                                                                                                    double xMin = 0.0;
                                                                                                                    double xMax = 10.0;
                                                                                                                    double yMin = 0.0;
                                                                                                                    double yMax = 10.0;
                                                                                                                    
                                                                                                                    PolygonsSet polygon = new PolygonsSet(xMin, xMax, yMin, yMax);
                                                                                                                    
                                                                                                                    // Compute geometrical properties using reflection
                                                                                                                    Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                    computeGeometricalProperties.setAccessible(true);
                                                                                                                    computeGeometricalProperties.invoke(polygon);
                                                                                                                    
                                                                                                                    // Verify the size is infinite (original behavior)
                                                                                                                    // The mutant would set size to 0, so this assertion would fail
                                                                                                                    assertEquals(Double.POSITIVE_INFINITY, polygon.getSize(), 0.0);
                                                                                                                    
                                                                                                                    // Additional verification that the vertices form a proper rectangle
                                                                                                                    Vector2D[][] vertices = polygon.getVertices();
                                                                                                                    assertNotNull(vertices);
                                                                                                                    assertEquals(1, vertices.length); // Should have one polygon
                                                                                                                    assertEquals(4, vertices[0].length); // With 4 vertices
                                                                                                                    
                                                                                                                    // Verify the vertices are in correct positions
                                                                                                                    assertEquals(xMin, vertices[0][0].getX(), 0.0);
                                                                                                                    assertEquals(yMin, vertices[0][0].getY(), 0.0);
                                                                                                                    assertEquals(xMax, vertices[0][2].getX(), 0.0);
                                                                                                                    assertEquals(yMax, vertices[0][2].getY(), 0.0);
                                                                                                                }

    @Test
                                                                                                        public void testBoxBoundaryBarycenter() {
                                                                                                            // Create a polygons set using the box boundary constructor
                                                                                                            // This will internally call boxBoundary and computeGeometricalProperties
                                                                                                            double xMin = -1.0, xMax = 1.0, yMin = -1.0, yMax = 1.0;
                                                                                                            PolygonsSet polygon = new PolygonsSet(xMin, xMax, yMin, yMax);
                                                                                                            
                                                                                                            // Get the barycenter (this will trigger computeGeometricalProperties)
                                                                                                            Vector2D barycenter = (Vector2D) polygon.getBarycenter();
                                                                                                            
                                                                                                            // Verify the barycenter is NaN (original behavior)
                                                                                                            // The mutant would set it to (0,0) instead
                                                                                                            assertTrue(Double.isNaN(barycenter.getX()));
                                                                                                            assertTrue(Double.isNaN(barycenter.getY()));
                                                                                                            
                                                                                                            // Additional check - verify vertices are created correctly
                                                                                                            Vector2D[][] vertices = polygon.getVertices();
                                                                                                            assertNotNull(vertices);
                                                                                                            assertEquals(1, vertices.length); // Single polygon
                                                                                                            assertEquals(4, vertices[0].length); // 4 vertices
                                                                                                        }

    @Test
                                                                                                public void testBoxBoundaryBarycenterInitialization() {
                                                                                                    // Create a PolygonsSet using the box boundary constructor
                                                                                                    // This will internally call boxBoundary and compute geometrical properties
                                                                                                    double xMin = 0.0, xMax = 1.0, yMin = 0.0, yMax = 1.0;
                                                                                                    PolygonsSet box = new PolygonsSet(xMin, xMax, yMin, yMax);
                                                                                                    
                                                                                                    // Force computation of geometrical properties
                                                                                                    // This would throw NullPointerException if barycenter was set to null
                                                                                                    Vector2D barycenter = (Vector2D) box.getBarycenter();
                                                                                                    
                                                                                                    // Verify barycenter is not null (would be NaN for empty set)
                                                                                                    assertNotNull("Barycenter should not be null", barycenter);
                                                                                                    
                                                                                                    // For a non-empty box, barycenter should be properly computed
                                                                                                    // If the set is considered empty (due to mutation), it would be NaN
                                                                                                    assertFalse("Barycenter should not be NaN for non-empty set", 
                                                                                                               Double.isNaN(barycenter.getX()) || Double.isNaN(barycenter.getY()));
                                                                                                }

    @Test
                                                                                    public void testBoxBoundaryCreatesCorrectLines() throws Exception {
                                                                                        double xMin = 0.0, xMax = 1.0, yMin = 0.0, yMax = 1.0;
                                                                                        
                                                                                        // Use reflection to access private boxBoundary method
                                                                                        Method boxBoundaryMethod = PolygonsSet.class.getDeclaredMethod("boxBoundary", 
                                                                                            double.class, double.class, double.class, double.class);
                                                                                        boxBoundaryMethod.setAccessible(true);
                                                                                        org.apache.commons.math3.geometry.euclidean.twod.Line[] boundaries = 
                                                                                            (org.apache.commons.math3.geometry.euclidean.twod.Line[]) boxBoundaryMethod.invoke(null, xMin, xMax, yMin, yMax);
                                                                                        
                                                                                        assertEquals("Should create 4 boundary lines", 4, boundaries.length);
                                                                                        
                                                                                        // Verify the lines form a proper rectangle
                                                                                        // Check bottom line (y = yMin)
                                                                                        assertEquals(0.0, boundaries[0].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0, yMin)), 1.0e-10);
                                                                                        assertEquals(0.0, boundaries[0].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.0, yMin)), 1.0e-10);
                                                                                        
                                                                                        // Check right line (x = xMax)
                                                                                        assertEquals(0.0, boundaries[1].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, 0.0)), 1.0e-10);
                                                                                        assertEquals(0.0, boundaries[1].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMax, 1.0)), 1.0e-10);
                                                                                        
                                                                                        // Check top line (y = yMax)
                                                                                        assertEquals(0.0, boundaries[2].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0.0, yMax)), 1.0e-10);
                                                                                        assertEquals(0.0, boundaries[2].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1.0, yMax)), 1.0e-10);
                                                                                        
                                                                                        // Check left line (x = xMin)
                                                                                        assertEquals(0.0, boundaries[3].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, 0.0)), 1.0e-10);
                                                                                        assertEquals(0.0, boundaries[3].getOffset(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(xMin, 1.0)), 1.0e-10);
                                                                                    }

    @Test
                                                                                    public void testBuildNewWithNullCutAndFalseAttribute1() {
                                                                                        // Create a mock tree where getCut() is null and getAttribute() returns false
                                                                                        BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                        when(tree.getCut()).thenReturn(null);
                                                                                        when(tree.getAttribute()).thenReturn(false);
                                                                                        
                                                                                        // Create the PolygonsSet which should handle this case
                                                                                        PolygonsSet polygonsSet = new PolygonsSet(tree);
                                                                                        
                                                                                        // The original code would handle this case differently than the mutant
                                                                                        // For the original, with false attribute, it should create an empty polygons set
                                                                                        // The mutant would proceed as if the attribute was true
                                                                                        // Verify by checking vertices - empty for original, non-empty for mutant
                                                                                        Vector2D[][] vertices = polygonsSet.getVertices();
                                                                                        
                                                                                        // Original behavior would return empty vertices array for this case
                                                                                        // Mutant might return non-empty array
                                                                                        assertEquals("Should have empty vertices when attribute is false", 
                                                                                                    0, vertices.length);
                                                                                    }

    @Test
                                                                                public void testBoxBoundaryMutant() {
                                                                                    // Create a standard polygons set using the normal constructor
                                                                                    PolygonsSet standardSet = new PolygonsSet(0, 10, 0, 10);
                                                                                    
                                                                                    // Mock the behavior of getTree with different parameters
                                                                                    PolygonsSet spySet = spy(standardSet);
                                                                                    
                                                                                    // When getTree(false) is called (original behavior)
                                                                                    BSPTree<Euclidean2D> originalTree = mock(BSPTree.class);
                                                                                    when(spySet.getTree(false)).thenReturn(originalTree);
                                                                                    
                                                                                    // When getTree(true) is called (mutated behavior)
                                                                                    BSPTree<Euclidean2D> mutatedTree = mock(BSPTree.class);
                                                                                    when(spySet.getTree(true)).thenReturn(mutatedTree);
                                                                                    
                                                                                    // Build new sets with both trees
                                                                                    PolygonsSet originalBuiltSet = spySet.buildNew(originalTree);
                                                                                    PolygonsSet mutatedBuiltSet = spySet.buildNew(mutatedTree);
                                                                                    
                                                                                    // The vertices should be different if the mutant is present
                                                                                    // Since we can't predict exact vertex values, we'll verify the trees are different
                                                                                    // which would lead to different vertex calculations
                                                                                    assertNotEquals("Vertices should differ between original and mutated trees",
                                                                                                  originalBuiltSet.getVertices(),
                                                                                                  mutatedBuiltSet.getVertices());
                                                                                    
                                                                                    // Additional verification that the trees are indeed different
                                                                                    assertNotSame("Original and mutated trees should be different",
                                                                                                 originalTree,
                                                                                                 mutatedTree);
                                                                                }

    @Test
                                                                            public void testBuildNewWithDifferentTreeConditions() {
                                                                                // Create mock tree for case 1: getCut() null and attribute true
                                                                                BSPTree<Euclidean2D> tree1 = mock(BSPTree.class);
                                                                                when(tree1.getCut()).thenReturn(null);
                                                                                when(tree1.getAttribute()).thenReturn(true);
                                                                                
                                                                                // Case 2: getCut() not null and attribute true
                                                                                BSPTree<Euclidean2D> tree2 = mock(BSPTree.class);
                                                                                when(tree2.getCut()).thenReturn(mock(SubHyperplane.class));
                                                                                when(tree2.getAttribute()).thenReturn(true);
                                                                                
                                                                                // Case 3: getCut() null and attribute false
                                                                                BSPTree<Euclidean2D> tree3 = mock(BSPTree.class);
                                                                                when(tree3.getCut()).thenReturn(null);
                                                                                when(tree3.getAttribute()).thenReturn(false);
                                                                                
                                                                                // Case 4: getCut() not null and attribute false
                                                                                BSPTree<Euclidean2D> tree4 = mock(BSPTree.class);
                                                                                when(tree4.getCut()).thenReturn(mock(SubHyperplane.class));
                                                                                when(tree4.getAttribute()).thenReturn(false);
                                                                        
                                                                                // Test all cases
                                                                                PolygonsSet set1 = new PolygonsSet(tree1);
                                                                                PolygonsSet set2 = new PolygonsSet(tree2);
                                                                                PolygonsSet set3 = new PolygonsSet(tree3);
                                                                                PolygonsSet set4 = new PolygonsSet(tree4);
                                                                                
                                                                                // Verify vertices are computed correctly for each case
                                                                                // The mutant would behave differently in cases where only one condition is true
                                                                                assertNotNull(set1.getVertices());
                                                                                assertNotNull(set2.getVertices());
                                                                                assertNotNull(set3.getVertices());
                                                                                assertNotNull(set4.getVertices());
                                                                                
                                                                                // Additional assertions to verify correct behavior
                                                                                // For case1 and case3 where getCut() is null, behavior should be different
                                                                                // between original and mutant
                                                                                assertTrue(set1.getVertices().length > 0); // Should have vertices
                                                                                assertTrue(set3.getVertices().length == 0); // Should be empty
                                                                                
                                                                                // The mutant would incorrectly return vertices for case3
                                                                            }

    @Test
                                                                public void testBoxBoundarySize() {
                                                                    // Test with finite bounds
                                                                    double xMin = 0.0;
                                                                    double xMax = 10.0;
                                                                    double yMin = 0.0;
                                                                    double yMax = 5.0;
                                                                    
                                                                    PolygonsSet polygon = new PolygonsSet(xMin, xMax, yMin, yMax);
                                                                    Vector2D[][] vertices = polygon.getVertices();
                                                                    
                                                                    // Verify the vertices form a proper rectangle
                                                                    assertEquals(1, vertices.length); // Should have one polygon
                                                                    assertEquals(4, vertices[0].length); // With 4 vertices
                                                                    
                                                                    // Check all vertices are within bounds
                                                                    for (Vector2D vertex : vertices[0]) {
                                                                        assertTrue(vertex.getX() >= xMin && vertex.getX() <= xMax);
                                                                        assertTrue(vertex.getY() >= yMin && vertex.getY() <= yMax);
                                                                    }
                                                                    
                                                                    // Test with infinite bounds
                                                                    PolygonsSet infinitePolygon = new PolygonsSet(
                                                                        Double.NEGATIVE_INFINITY, 
                                                                        Double.POSITIVE_INFINITY, 
                                                                        Double.NEGATIVE_INFINITY, 
                                                                        Double.POSITIVE_INFINITY);
                                                                    
                                                                    Vector2D[][] infiniteVertices = infinitePolygon.getVertices();
                                                                    
                                                                    // Should still have valid vertices (though infinite bounds)
                                                                    assertNotNull(infiniteVertices);
                                                                    assertEquals(1, infiniteVertices.length);
                                                                    assertEquals(4, infiniteVertices[0].length);
                                                                    
                                                                    // The size verification is done implicitly through the vertices checks
                                                                }

    @Test
                                                        public void testBoxBoundarySizeProperty2() {
                                                            // Create a polygon set with finite bounds
                                                            double xMin = 0.0;
                                                            double xMax = 10.0;
                                                            double yMin = 0.0;
                                                            double yMax = 10.0;
                                                            
                                                            PolygonsSet polygon = new PolygonsSet(xMin, xMax, yMin, yMax);
                                                            
                                                            // Compute geometrical properties using reflection
                                                            try {
                                                                Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                computeGeometricalProperties.setAccessible(true);
                                                                computeGeometricalProperties.invoke(polygon);
                                                            } catch (Exception e) {
                                                                fail("Failed to invoke computeGeometricalProperties: " + e.getMessage());
                                                            }
                                                            
                                                            // The original implementation should have infinite size (positive infinity)
                                                            // The mutant would set size to 0
                                                            assertTrue("Polygon size should be infinite for box boundary", 
                                                                      Double.isInfinite(polygon.getSize()));
                                                            
                                                            // Additional check to ensure it's specifically positive infinity
                                                            assertEquals("Polygon size should be POSITIVE_INFINITY", 
                                                                        Double.POSITIVE_INFINITY, polygon.getSize(), 0.0);
                                                        }

    @Test
                                                        public void testComputeGeometricalPropertiesBarycenter() {
                                                            // Create a simple polygon (a square from (0,0) to (1,1))
                                                            PolygonsSet polygon = new PolygonsSet(0.0, 1.0, 0.0, 1.0);
                                                            
                                                            // Trigger computation of geometrical properties by getting vertices
                                                            Vector2D[][] vertices = polygon.getVertices();
                                                            
                                                            // The barycenter should be (0.5, 0.5) for this square
                                                            // But we need to test the case where it would be NaN in original code
                                                            // Create a more complex polygon that might trigger NaN case
                                                            PolygonsSet emptyOrInvalid = new PolygonsSet();
                                                            
                                                            // Try to get vertices to trigger computation
                                                            try {
                                                                Vector2D[][] emptyVertices = emptyOrInvalid.getVertices();
                                                                
                                                                // If we get here, we need to check barycenter state
                                                                // Since we can't directly access barycenter, we'll check vertices
                                                                // Original code might have NaN in vertices due to barycenter setting
                                                                for (Vector2D[] loop : emptyVertices) {
                                                                    for (Vector2D v : loop) {
                                                                        // Verify no vertex is (0,0) which might indicate mutant
                                                                        assertFalse("Vertex should not be (0,0) if barycenter was NaN",
                                                                                   v.equals(new Vector2D(0, 0)));
                                                                    }
                                                                }
                                                            } catch (Exception e) {
                                                                // Original code might throw exception due to NaN barycenter
                                                                // This would also detect mutant that sets barycenter to (0,0)
                                                                assertTrue("Expected exception with NaN barycenter", true);
                                                            }
                                                        }

    @Test
                                                    public void testBoxBoundaryGeometricalProperties() {
                                                        // Create a polygons set using box boundary
                                                        double xMin = 0.0, xMax = 1.0, yMin = 0.0, yMax = 1.0;
                                                        PolygonsSet polygon = new PolygonsSet(xMin, xMax, yMin, yMax);
                                                        
                                                        // Trigger computation of geometrical properties
                                                        // This would call computeGeometricalProperties() internally
                                                        Vector2D[][] vertices = polygon.getVertices();
                                                        
                                                        // Verify no NullPointerException was thrown
                                                        assertNotNull(vertices);
                                                        
                                                        // Additional verification that barycenter was properly set
                                                        // Since we can't directly access barycenter, we can verify the vertices
                                                        // which would be computed correctly only if geometrical properties were computed properly
                                                        assertEquals(1, vertices.length);
                                                        assertEquals(4, vertices[0].length);
                                                    }

    @Test
                                                public void testBuildNewWithNullCutAndFalseAttribute2() {
                                                    // Create a mock BSPTree where getCut() returns null and getAttribute() returns false
                                                    BSPTree<Euclidean2D> mockTree = mock(BSPTree.class);
                                                    when(mockTree.getCut()).thenReturn(null);
                                                    when(mockTree.getAttribute()).thenReturn(false);
                                                    
                                                    // Create the PolygonsSet which will call buildNew internally
                                                    PolygonsSet polygonsSet = new PolygonsSet(mockTree);
                                                    
                                                    // In original code, with false attribute, vertices should be empty
                                                    // In mutated code, vertices might be processed incorrectly
                                                    Vector2D[][] vertices = polygonsSet.getVertices();
                                                    
                                                    // Verify behavior - original code would have empty vertices in this case
                                                    assertNotNull(vertices);
                                                    assertEquals(0, vertices.length);
                                                    
                                                    // Additional verification that no processing occurred
                                                    verify(mockTree, times(1)).getCut();
                                                    verify(mockTree, times(1)).getAttribute();
                                                }

    @Test
                                            public void testBuildNewWithDifferentTreeConditions1() {
                                                // Create mock tree for case 1: getCut() null and attribute true
                                                BSPTree<Euclidean2D> tree1 = mock(BSPTree.class);
                                                when(tree1.getCut()).thenReturn(null);
                                                when(tree1.getAttribute()).thenReturn(true);
                                                
                                                PolygonsSet set1 = new PolygonsSet(tree1);
                                                Vector2D[][] vertices1 = set1.getVertices();
                                                // Should process the tree normally
                                                
                                                // Create mock tree for case 2: getCut() null but attribute false
                                                BSPTree<Euclidean2D> tree2 = mock(BSPTree.class);
                                                when(tree2.getCut()).thenReturn(null);
                                                when(tree2.getAttribute()).thenReturn(false);
                                                
                                                PolygonsSet set2 = new PolygonsSet(tree2);
                                                Vector2D[][] vertices2 = set2.getVertices();
                                                // Original would skip, mutant would process
                                                
                                                // Verify behavior differs between original and mutant
                                                // The mutant would process tree2 while original wouldn't
                                                assertTrue("Mutant should produce different vertices for case 2", 
                                                    vertices1.length != vertices2.length || 
                                                    !vertices1[0][0].equals(vertices2[0][0]));
                                                
                                                // Create mock tree for case 3: getCut() not null but attribute true
                                                BSPTree<Euclidean2D> tree3 = mock(BSPTree.class);
                                                SubHyperplane<Euclidean2D> cut = mock(SubHyperplane.class);
                                                when(tree3.getCut()).thenReturn(cut);
                                                when(tree3.getAttribute()).thenReturn(true);
                                                
                                                PolygonsSet set3 = new PolygonsSet(tree3);
                                                Vector2D[][] vertices3 = set3.getVertices();
                                                // Original would skip, mutant would process
                                                
                                                // Create mock tree for case 4: neither condition true
                                                BSPTree<Euclidean2D> tree4 = mock(BSPTree.class);
                                                when(tree4.getCut()).thenReturn(cut);
                                                when(tree4.getAttribute()).thenReturn(false);
                                                
                                                PolygonsSet set4 = new PolygonsSet(tree4);
                                                Vector2D[][] vertices4 = set4.getVertices();
                                                // Both would skip
                                                
                                                // Verify case 3 is processed differently by mutant
                                                assertTrue("Mutant should produce different vertices for case 3",
                                                    vertices3.length != vertices4.length || 
                                                    !vertices3[0][0].equals(vertices4[0][0]));
                                            }

    @Test
                                        public void testBuildNewWithDifferentTreeStates() {
                                            // Create mock BSPTree with no cut and true attribute
                                            BSPTree<Euclidean2D> treeNoCutTrueAttr = mock(BSPTree.class);
                                            when(treeNoCutTrueAttr.getCut()).thenReturn(null);
                                            when(treeNoCutTrueAttr.getAttribute()).thenReturn(true);
                                            
                                            // Create mock BSPTree with no cut and false attribute
                                            BSPTree<Euclidean2D> treeNoCutFalseAttr = mock(BSPTree.class);
                                            when(treeNoCutFalseAttr.getCut()).thenReturn(null);
                                            when(treeNoCutFalseAttr.getAttribute()).thenReturn(false);
                                            
                                            // Create mock BSPTree with cut (attribute shouldn't matter)
                                            BSPTree<Euclidean2D> treeWithCut = mock(BSPTree.class);
                                            SubHyperplane<Euclidean2D> mockCut = mock(SubHyperplane.class);
                                            when(treeWithCut.getCut()).thenReturn(mockCut);
                                            
                                            // Test with tree that has no cut and true attribute
                                            PolygonsSet ps1 = new PolygonsSet(treeNoCutTrueAttr);
                                            assertNotNull(ps1.getVertices());
                                            
                                            // Test with tree that has no cut and false attribute
                                            // This should fail with mutant but pass with original
                                            PolygonsSet ps2 = new PolygonsSet(treeNoCutFalseAttr);
                                            // Original would have empty vertices here, mutant would have some
                                            assertEquals(0, ps2.getVertices().length);
                                            
                                            // Test with tree that has a cut
                                            PolygonsSet ps3 = new PolygonsSet(treeWithCut);
                                            // Original would have empty vertices here, mutant would have some
                                            assertEquals(0, ps3.getVertices().length);
                                        }

    @Test
                                    public void testBoxBoundaryWithInfiniteBounds() {
                                        // Create a polygons set with infinite bounds
                                        double infinity = Double.POSITIVE_INFINITY;
                                        PolygonsSet infinitePolygon = new PolygonsSet(-infinity, infinity, -infinity, infinity);
                                        
                                        // Get the vertices - should handle infinite bounds correctly
                                        Vector2D[][] vertices = infinitePolygon.getVertices();
                                        
                                        // Verify the polygon has vertices (should not be empty)
                                        assertNotNull(vertices);
                                        assertTrue(vertices.length > 0);
                                        
                                        // Verify the polygon is infinite in size
                                        // This is where the mutant would fail as it sets negative infinity
                                        assertTrue(infinitePolygon.getSize() > 0);
                                        assertEquals(Double.POSITIVE_INFINITY, infinitePolygon.getSize(), 0.0);
                                        
                                        // Verify boundary lines are created correctly
                                        // For infinite bounds, some coordinates should be infinite
                                        for (Vector2D[] loop : vertices) {
                                            for (Vector2D vertex : loop) {
                                                assertTrue(Double.isInfinite(vertex.getX()) || Double.isInfinite(vertex.getY()));
                                            }
                                        }
                                    }

    @Test
                        public void testBoxBoundarySize1() {
                            // Create a PolygonsSet with a box boundary
                            double xMin = 0.0;
                            double xMax = 10.0;
                            double yMin = 0.0;
                            double yMax = 5.0;
                            PolygonsSet polygon = new PolygonsSet(xMin, xMax, yMin, yMax);
                            
                            // Use reflection to access protected computeGeometricalProperties method
                            try {
                                Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                computeGeometricalProperties.setAccessible(true);
                                computeGeometricalProperties.invoke(polygon);
                            } catch (Exception e) {
                                fail("Failed to invoke computeGeometricalProperties: " + e.getMessage());
                            }
                            
                            // Verify the size is infinite (original behavior)
                            // This will fail if the mutant (setSize(0)) is present
                            assertEquals(Double.POSITIVE_INFINITY, polygon.getSize(), 0.0);
                            
                            // Additional verification that we created a valid boundary
                            Vector2D[][] vertices = polygon.getVertices();
                            assertNotNull(vertices);
                            assertEquals(1, vertices.length); // Should have one polygon
                            assertEquals(4, vertices[0].length); // With 4 vertices (rectangle)
                        }

    @Test
                public void testComputeGeometricalPropertiesBarycenter1() {
                    // Create a simple box polygon
                    PolygonsSet polygon = new PolygonsSet(0.0, 1.0, 0.0, 1.0);
                    
                    // Force computation of geometrical properties using reflection
                    try {
                        Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                        computeGeometricalProperties.setAccessible(true);
                        computeGeometricalProperties.invoke(polygon);
                    } catch (Exception e) {
                        fail("Failed to invoke computeGeometricalProperties via reflection: " + e.getMessage());
                    }
                    
                    // Get the barycenter
                    Vector2D barycenter = (Vector2D) polygon.getBarycenter();
                    
                    // Verify it's NaN (original behavior)
                    // The mutant would set it to (0,0) instead
                    assertTrue(Double.isNaN(barycenter.getX()));
                    assertTrue(Double.isNaN(barycenter.getY()));
                    
                    // Additional check to ensure it's not the mutant's (0,0) value
                    assertFalse(barycenter.equals(new Vector2D(0, 0)));
                }

    @Test
        public void testBarycenterHandling() {
            // Create a simple polygon set using the box boundary
            PolygonsSet polygon = new PolygonsSet(0.0, 1.0, 0.0, 1.0);
            
            // Use reflection to access protected computeGeometricalProperties method
            try {
                Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                computeMethod.setAccessible(true);
                computeMethod.invoke(polygon);
            } catch (Exception e) {
                fail("Failed to compute geometrical properties: " + e.getMessage());
            }
            
            // Get the barycenter and cast to Vector2D
            Vector2D barycenter = (Vector2D) polygon.getBarycenter();
            
            // Verify barycenter is not null and has valid coordinates
            assertNotNull("Barycenter should not be null", barycenter);
            assertFalse("Barycenter should not be NaN", 
                       Double.isNaN(barycenter.getX()) || Double.isNaN(barycenter.getY()));
            
            // Verify expected barycenter position for a unit square
            assertEquals(0.5, barycenter.getX(), 1e-10);
            assertEquals(0.5, barycenter.getY(), 1e-10);
        }

    @Test
        public void testBuildNewWithNullCutAndAttribute() {
            // Create a tree with null cut
            BSPTree<Euclidean2D> tree = mock(BSPTree.class);
            when(tree.getCut()).thenReturn(null);
            
            // Case 1: Attribute is true - should build normally
            when(tree.getAttribute()).thenReturn(true);
            PolygonsSet set1 = new PolygonsSet(tree);
            assertNotNull(set1);
            
            // Case 2: Attribute is false - original would skip, mutant would still build
            when(tree.getAttribute()).thenReturn(false);
            PolygonsSet set2 = new PolygonsSet(tree);
            
            // This assertion would fail with the mutant but pass with original
            // Since original would return empty tree when attribute is false
            assertNotEquals(set1.getVertices(), set2.getVertices());
        }

}
