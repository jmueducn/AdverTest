package gentest.org.apache.commons.math.stat.regression.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.regression.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.TDistribution;
 
public class SimpleRegressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
              public void testGetSumSquaredErrors_PositiveResult() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 10.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 20.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 5.0);
                  
                  // Expected: 20 - (5*5)/10 = 20 - 2.5 = 17.5
                  assertEquals(17.5, regression.getSumSquaredErrors(), 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_NegativeResultClampedToZero() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.setDouble(regression, 5.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.setDouble(regression, 10.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.setDouble(regression, 10.0);
                  
                  // Expected: 10 - (10*10)/5 = 10 - 20 = -10 -> clamped to 0
                  assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_ZeroSumXX() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 0.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 10.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 5.0);
                  
                  // Should handle division by zero and return 0 (due to Math.max)
                  assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_AllZeros() {
                  SimpleRegression regression = new SimpleRegression();
                  // Add data points that will result in all sums being zero
                  regression.addData(new double[][]{{0,0}, {0,0}, {0,0}});
                  assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_PerfectCorrelation() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 4.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 9.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 6.0);
                  
                  // 9 - (6*6)/4 = 9 - 9 = 0
                  assertEquals(0.0, regression.getSumSquaredErrors(), 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_LargeValues() throws Exception {
                  // Test with large values to check for numeric stability
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 1.0E20);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 2.0E20);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 1.0E20);
                  
                  // 2E20 - (1E20 * 1E20)/1E20 = 2E20 - 1E20 = 1E20
                  assertEquals(1.0E20, regression.getSumSquaredErrors(), 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_SmallValues() throws Exception {
                  // Test with very small values
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 1.0E-20);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 2.0E-20);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 1.0E-20);
                  
                  // 2E-20 - (1E-20 * 1E-20)/1E-20 = 2E-20 - 1E-20 = 1E-20
                  assertEquals(1.0E-20, regression.getSumSquaredErrors(), 0.0001);
              }

 @Test
          public void testGetSlopeWithTwoDataPoints() {
              // Setup
              SimpleRegression regression = new SimpleRegression();
              
              // Add exactly 2 data points
              regression.addData(1.0, 2.0);
              regression.addData(2.0, 4.0);
              
              // Verify
              double slope = regression.getSlope();
              
              // Original behavior: should return calculated slope (2.0 in this case)
              // Mutated behavior: would return NaN
              assertFalse("Slope should not be NaN for n=2", Double.isNaN(slope));
              assertEquals(2.0, slope, 0.0001);
          }

 @Test
             public void testGetSlopeWithSingleDataPoint() {
                 // Setup - create regression object and add exactly one data point
                 SimpleRegression regression = new SimpleRegression();
                 regression.addData(1.0, 2.0);  // n becomes 1
                 
                 // Execute
                 double slope = regression.getSlope();
                 
                 // Verify - original should return NaN, mutant would return a number
                 assertTrue("Slope should be NaN when n=1", Double.isNaN(slope));
                 
                 // Additional verification that we indeed have n=1
                 assertEquals(1, regression.getN());
             }

 @Test
            public void testGetSlope_NotEnoughData_ShouldReturnNaN() {
                // Create regression object with insufficient data (n < 2)
                SimpleRegression regression = new SimpleRegression();
                
                // Case 1: No data added (n = 0)
                double slope1 = regression.getSlope();
                assertTrue("Slope should be NaN when no data points", Double.isNaN(slope1));
                
                // Case 2: Only one data point added (n = 1)
                regression.addData(1.0, 2.0);
                double slope2 = regression.getSlope();
                assertTrue("Slope should be NaN when only one data point", Double.isNaN(slope2));
                
                // These assertions will catch the mutant that returns POSITIVE_INFINITY
            }

 @Test
           public void testGetSlope_NotEnoughData_ShouldReturnNaN1() {
               // Create regression object with no data (n = 0)
               SimpleRegression regression = new SimpleRegression();
               
               // Verify slope returns NaN when not enough data
               double slope = regression.getSlope();
               
               // This will catch the mutant that returns 0.0 instead of NaN
               assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
               
               // Additional test case with exactly 1 data point (n = 1)
               regression.addData(1.0, 2.0);
               slope = regression.getSlope();
               assertTrue("Slope should be NaN when n = 1", Double.isNaN(slope));
           }

 @Test
          public void testGetSlope_BoundaryCaseForSumXX() {
              // Setup
              SimpleRegression regression = new SimpleRegression();
              
              // Set sumXX to exactly 10*Double.MIN_VALUE
              // Need to use reflection to set private fields since there's no public API for this
              try {
                  java.lang.reflect.Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 10 * Double.MIN_VALUE);
                  
                  java.lang.reflect.Field nField = SimpleRegression.class.getDeclaredField("n");
                  nField.setAccessible(true);
                  nField.set(regression, 2L); // Need at least 2 points
                  
                  java.lang.reflect.Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 1.0); // Any non-zero value
              } catch (Exception e) {
                  fail("Failed to set up test via reflection");
              }
              
              // Test - original should return a value, mutant would return NaN
              double slope = regression.getSlope();
              assertFalse("Should return a valid slope for sumXX = 10*MIN_VALUE", 
                        Double.isNaN(slope));
              
              // Verify the actual calculation is correct
              assertEquals(1.0 / (10 * Double.MIN_VALUE), slope, 0.0001);
          }

 @Test
         public void testGetSlopeWithVerySmallSumXX() {
             // Create a test case where sumXX is between 10*MIN_VALUE and 100*MIN_VALUE
             double testSumXX = 50 * Double.MIN_VALUE;
             double testSumXY = 1.0; // arbitrary value
             
             // Create and setup test object
             SimpleRegression regression = new SimpleRegression();
             
             // Use reflection to set private fields since we need specific test values
             try {
                 java.lang.reflect.Field nField = SimpleRegression.class.getDeclaredField("n");
                 nField.setAccessible(true);
                 nField.set(regression, 2L); // set n >= 2
                 
                 java.lang.reflect.Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                 sumXXField.setAccessible(true);
                 sumXXField.set(regression, testSumXX);
                 
                 java.lang.reflect.Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                 sumXYField.setAccessible(true);
                 sumXYField.set(regression, testSumXY);
                 
             } catch (Exception e) {
                 fail("Failed to set test fields via reflection");
             }
             
             // Test the behavior - original should return NaN, mutant would return a value
             double result = regression.getSlope();
             assertTrue("Should return NaN for sumXX between 10*MIN_VALUE and 100*MIN_VALUE", 
                       Double.isNaN(result));
         }

 @Test
    public void testGetSlope_WhenSumXXIsVerySmall_ShouldReturnNaN() {
        // Setup test data with very small sumXX
        SimpleRegression regression = new SimpleRegression();
        
        // Add data points with almost identical x values (very small variation)
        // Using values that will make sumXX very small but not zero
        regression.addData(1.0, 2.0);
        regression.addData(1.0 + Double.MIN_VALUE, 3.0);
        
        // Verify the sumXX is small enough to trigger the condition
        // Reflection to access private field sumXX
        try {
            Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
            sumXXField.setAccessible(true);
            double sumXX = sumXXField.getDouble(regression);
            assertTrue(Math.abs(sumXX) < 10 * Double.MIN_VALUE);
            
            // Test the actual behavior
            double slope = regression.getSlope();
            assertTrue(Double.isNaN(slope)); // Should be NaN, mutant would return POSITIVE_INFINITY
        } catch (Exception e) {
            fail("Failed to access sumXX field: " + e.getMessage());
        }
    }

 @Test
   public void testGetSlope_WhenSumXXIsVerySmall_ShouldReturnNaN1() {
       // Setup test data where sumXX is very small
       SimpleRegression regression = new SimpleRegression();
       
       // Add data points with almost no variation in x
       // Using reflection to directly set private fields since addData() might modify them
       try {
           Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
           sumXXField.setAccessible(true);
           sumXXField.set(regression, Double.MIN_VALUE); // Set sumXX to minimal possible value
           
           Field nField = SimpleRegression.class.getDeclaredField("n");
           nField.setAccessible(true);
           nField.set(regression, 2L); // Set n=2 to pass first condition
           
           // Call method and verify
           double result = regression.getSlope();
           
           // Original behavior should return NaN, mutant would return 0.0
           assertTrue("Should return NaN when sumXX is very small", 
                     Double.isNaN(result));
       } catch (Exception e) {
           fail("Reflection failed: " + e.getMessage());
       }
   }

 @Test
   public void testGetSlope_WhenSumXXIsVerySmall_ShouldReturnNaN2() {
       SimpleRegression regression = new SimpleRegression();
       
       // Add two identical x values (no variation)
       regression.addData(1.0, 2.0);
       regression.addData(1.0, 3.0); // Same x value
       
       double result = regression.getSlope();
       
       // Original behavior should return NaN, mutant would return 0.0
       assertTrue("Should return NaN when x values are identical",
                 Double.isNaN(result));
   }

 @Test
  public void testGetSlopeDetectsDivisionMutant() {
      // Setup test data - simple case where x and y are perfectly correlated
      SimpleRegression regression = new SimpleRegression();
      regression.addData(new double[][] {
          {1, 2},  // x=1, y=2
          {2, 4},  // x=2, y=4
          {3, 6}   // x=3, y=6
      });
      
      // Calculate expected values manually
      // sumX = 1+2+3 = 6
      // sumY = 2+4+6 = 12
      // sumXY = (1*2)+(2*4)+(3*6) = 2+8+18 = 28
      // sumXX = 1²+2²+3² = 1+4+9 = 14
      // Expected slope = sumXY/sumXX = 28/14 = 2.0
      
      double expectedSlope = 2.0;
      double actualSlope = regression.getSlope();
      
      // This will catch the mutant because:
      // Original: 28/14 = 2.0
      // Mutant: 14/28 = 0.5
      assertEquals("Slope calculation should be sumXY/sumXX", 
                  expectedSlope, actualSlope, 0.0001);
      
      // Additional verification that we're not getting the mutant value
      assertNotEquals("Should not be getting sumXX/sumXY value",
                     0.5, actualSlope, 0.0001);
  }

 @Test
     public void testGetSlopeDetectsDivisionMutant1() {
         // Setup test data
         SimpleRegression regression = new SimpleRegression();
         // Add data points that will produce non-zero, non-trivial sumXY and sumXX
         regression.addData(new double[][]{{1, 2}, {3, 6}, {5, 10}});
         
         // Calculate expected slope manually using correct formula
         // For these points, sumXY = (1*2 + 3*6 + 5*10) = 2 + 18 + 50 = 70
         // sumXX = (1² + 3² + 5²) = 1 + 9 + 25 = 35
         double expectedSlope = 70.0 / 35.0;  // Correct calculation: division
         double mutantSlope = 70.0 * 35.0;    // Mutant calculation: multiplication
         
         // Verify the actual slope matches expected (division) and not mutant (multiplication)
         double actualSlope = regression.getSlope();
         
         // Assert correct behavior
         assertEquals("Slope should be calculated using division", expectedSlope, actualSlope, 0.0001);
         
         // Additional assertion to explicitly show the mutant would fail
         assertNotEquals("Test should detect multiplication mutant", 
                        mutantSlope, actualSlope, 0.0001);
     }

}
