package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                public void testAddValue_WithComparableObject_ShouldDelegate() {
                                                                    // Setup
                                                                    Frequency frequency = new Frequency();
                                                                    Comparable<String> comparableString = "testString";
                                                                    
                                                                    // This test verifies the method delegates to addValue(Comparable) without throwing exception
                                                                    // We can't easily verify the delegation, so we just check no exception is thrown
                                                                    frequency.addValue(comparableString);
                                                                    
                                                                    // Verify the value was actually added by checking count
                                                                    assertEquals(1, frequency.getCount(comparableString));
                                                                }

    @Test
                                                                public void testAddValue_WithNonComparableObject_ShouldThrowException() {
                                                                    // Setup
                                                                    Frequency frequency = new Frequency();
                                                                    Object nonComparable = new Object();
                                                                    
                                                                    // Expect exception
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Object must implement Comparable");
                                                                    
                                                                    // Test
                                                                    frequency.addValue(nonComparable);
                                                                }

    @Test
                                                                public void testAddValue_WithNull_ShouldThrowException() {
                                                                    // Setup
                                                                    Frequency frequency = new Frequency();
                                                                    
                                                                    // Expect exception
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Object must implement Comparable");
                                                                    
                                                                    // Test
                                                                    frequency.addValue(null);
                                                                }

    @Test
                                                                public void testAddValue_WithPrimitiveWrapper_ShouldDelegate() {
                                                                    // Setup
                                                                    Frequency frequency = new Frequency();
                                                                    Integer integerValue = 42;
                                                                    
                                                                    // Test
                                                                    frequency.addValue(integerValue);
                                                                    
                                                                    // Verify
                                                                    assertEquals(1, frequency.getCount(integerValue));
                                                                }

    @Test
                                                                public void testAddValue_WithCustomComparable_ShouldDelegate() {
                                                                    // Setup
                                                                    Frequency frequency = new Frequency();
                                                                    Comparable<Object> customComparable = new Comparable<Object>() {
                                                                        @Override
                                                                        public int compareTo(Object o) {
                                                                            return 0;
                                                                        }
                                                                    };
                                                                    
                                                                    // Test
                                                                    frequency.addValue(customComparable);
                                                                    
                                                                    // Verify
                                                                    assertEquals(1, frequency.getCount(customComparable));
                                                                }

    @Test
                                                                public void testAddValue_WithComparatorConstructor_ShouldWorkWithComparable() {
                                                                    // Setup
                                                                    Comparator<String> comparator = (s1, s2) -> s1.length() - s2.length();
                                                                    Frequency frequency = new Frequency(comparator);
                                                                    String value = "test";
                                                                    
                                                                    // Test
                                                                    frequency.addValue(value);
                                                                    
                                                                    // Verify
                                                                    assertEquals(1, frequency.getCount(value));
                                                                }

    @Test
                                                                public void testAddValue_MixedTypesWithCustomComparator() {
                                                                    // Test with custom comparator that can handle mixed types
                                                                    Comparator<Object> mockComparator = mock(Comparator.class);
                                                                    when(mockComparator.compare(any(), any())).thenReturn(0);
                                                                    
                                                                    Frequency customFrequency = new Frequency(mockComparator);
                                                                    
                                                                    // These would normally throw, but our mock comparator allows it
                                                                    customFrequency.addValue(1);
                                                                    customFrequency.addValue("string");
                                                                    customFrequency.addValue(1.5);
                                                                    
                                                                    // Verify all were added (count would be 3 if comparator considered them equal)
                                                                    assertEquals(1L, customFrequency.getCount(1));
                                                                    assertEquals(1L, customFrequency.getCount("string"));
                                                                    assertEquals(1L, customFrequency.getCount(1.5));
                                                                }

    @Test
                                                                public void testAddValue_WithCustomComparator() {
                                                                    // Test with a custom comparator that orders in reverse
                                                                    Frequency reverseFrequency = new Frequency((o1, o2) -> ((Comparable)o2).compareTo(o1));
                                                                    
                                                                    reverseFrequency.addValue(5L);
                                                                    reverseFrequency.addValue(10L);
                                                                    reverseFrequency.addValue(5L);
                                                                    
                                                                    assertEquals(2, reverseFrequency.getCount(5L));
                                                                    assertEquals(1, reverseFrequency.getCount(10L));
                                                                    assertEquals(3, reverseFrequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_WithCustomComparator1() {
                                                                    Comparator<Integer> reverseComparator = (a, b) -> b.compareTo(a);
                                                                    Frequency customFrequency = new Frequency(reverseComparator);
                                                                    
                                                                    customFrequency.addValue(1);
                                                                    customFrequency.addValue(2);
                                                                    customFrequency.addValue(3);
                                                                    
                                                                    // Verify counts are correct regardless of comparator
                                                                    assertEquals(1, customFrequency.getCount(1));
                                                                    assertEquals(1, customFrequency.getCount(2));
                                                                    assertEquals(1, customFrequency.getCount(3));
                                                                }

    @Test
                                                                public void testAddValue_Long_WithPositiveValue() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(5L);
                                                                    assertEquals(1, frequency.getCount(5L));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_WithNegativeValue() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(-10L);
                                                                    assertEquals(1, frequency.getCount(-10L));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_WithZeroValue() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(0L);
                                                                    assertEquals(1, frequency.getCount(0L));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_WithMaxLongValue() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(Long.MAX_VALUE);
                                                                    assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_WithMinLongValue() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(Long.MIN_VALUE);
                                                                    assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_WithDuplicateValues() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(100L);
                                                                    frequency.addValue(100L);
                                                                    frequency.addValue(100L);
                                                                    assertEquals(3, frequency.getCount(100L));
                                                                    assertEquals(3, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_WithMultipleDifferentValues() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(1L);
                                                                    frequency.addValue(2L);
                                                                    frequency.addValue(3L);
                                                                    frequency.addValue(2L);
                                                                    
                                                                    assertEquals(1, frequency.getCount(1L));
                                                                    assertEquals(2, frequency.getCount(2L));
                                                                    assertEquals(1, frequency.getCount(3L));
                                                                    assertEquals(4, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_WithCustomComparator() {
                                                                    // Test with a reverse order comparator
                                                                    Frequency frequency = new Frequency((o1, o2) -> ((Comparable)o2).compareTo(o1));
                                                                    frequency.addValue(10L);
                                                                    frequency.addValue(20L);
                                                                    frequency.addValue(10L);
                                                                    
                                                                    assertEquals(2, frequency.getCount(10L));
                                                                    assertEquals(1, frequency.getCount(20L));
                                                                    assertEquals(3, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Long_AfterClear() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue(5L);
                                                                    frequency.clear();
                                                                    frequency.addValue(10L);
                                                                    
                                                                    assertEquals(0, frequency.getCount(5L));
                                                                    assertEquals(1, frequency.getCount(10L));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AddSingleCharacter() {
                                                                    Frequency frequency = new Frequency();
                                                                    char testChar = 'a';
                                                                    
                                                                    frequency.addValue(testChar);
                                                                    
                                                                    assertEquals(1, frequency.getCount(testChar));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AddMultipleSameCharacters() {
                                                                    Frequency frequency = new Frequency();
                                                                    char testChar = 'b';
                                                                    int count = 5;
                                                                    
                                                                    for (int i = 0; i < count; i++) {
                                                                        frequency.addValue(testChar);
                                                                    }
                                                                    
                                                                    assertEquals(count, frequency.getCount(testChar));
                                                                    assertEquals(count, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AddDifferentCharacters() {
                                                                    Frequency frequency = new Frequency();
                                                                    char[] testChars = {'a', 'b', 'c', 'a', 'b', 'a'};
                                                                    
                                                                    for (char c : testChars) {
                                                                        frequency.addValue(c);
                                                                    }
                                                                    
                                                                    assertEquals(3, frequency.getCount('a'));
                                                                    assertEquals(2, frequency.getCount('b'));
                                                                    assertEquals(1, frequency.getCount('c'));
                                                                    assertEquals(6, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AddSpecialCharacters() {
                                                                    Frequency frequency = new Frequency();
                                                                    char[] specialChars = {'\n', '\t', ' ', '!', '@', '#'};
                                                                    
                                                                    for (char c : specialChars) {
                                                                        frequency.addValue(c);
                                                                    }
                                                                    
                                                                    for (char c : specialChars) {
                                                                        assertEquals(1, frequency.getCount(c));
                                                                    }
                                                                    assertEquals(specialChars.length, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AddUpperCaseAndLowerCase() {
                                                                    Frequency frequency = new Frequency();
                                                                    char upperCase = 'A';
                                                                    char lowerCase = 'a';
                                                                    
                                                                    frequency.addValue(upperCase);
                                                                    frequency.addValue(lowerCase);
                                                                    
                                                                    assertEquals(1, frequency.getCount(upperCase));
                                                                    assertEquals(1, frequency.getCount(lowerCase));
                                                                    assertEquals(2, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AddZeroCharacter() {
                                                                    Frequency frequency = new Frequency();
                                                                    char zeroChar = '\0';
                                                                    
                                                                    frequency.addValue(zeroChar);
                                                                    
                                                                    assertEquals(1, frequency.getCount(zeroChar));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AddToExistingFrequency() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue('x');
                                                                    frequency.addValue('y');
                                                                    frequency.addValue('x');
                                                                    
                                                                    assertEquals(2, frequency.getCount('x'));
                                                                    assertEquals(1, frequency.getCount('y'));
                                                                    assertEquals(3, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_AfterClear() {
                                                                    Frequency frequency = new Frequency();
                                                                    frequency.addValue('a');
                                                                    frequency.addValue('b');
                                                                    frequency.clear();
                                                                    
                                                                    frequency.addValue('c');
                                                                    
                                                                    assertEquals(0, frequency.getCount('a'));
                                                                    assertEquals(0, frequency.getCount('b'));
                                                                    assertEquals(1, frequency.getCount('c'));
                                                                    assertEquals(1, frequency.getSumFreq());
                                                                }

    @Test
                                                                public void testAddValue_Char_WithCustomComparator() {
                                                                    Frequency frequency = new Frequency(String.CASE_INSENSITIVE_ORDER);
                                                                    frequency.addValue('A');
                                                                    frequency.addValue('a');
                                                                    
                                                                    // Should treat 'A' and 'a' as the same with case insensitive comparator
                                                                    assertEquals(2, frequency.getCount('A'));
                                                                    assertEquals(2, frequency.getCount('a'));
                                                                    assertEquals(2, frequency.getSumFreq());
                                                                }

    @Test
                                                        public void testAddValue_IntegerInput_IncrementsCount() {
                                                            // Create frequency instance for testing
                                                            Frequency frequency = new Frequency();
                                                            
                                                            // Test with Integer input
                                                            frequency.addValue(5);
                                                            assertEquals(1L, frequency.getCount(5));
                                                            
                                                            // Add same value again
                                                            frequency.addValue(5);
                                                            assertEquals(2L, frequency.getCount(5));
                                                        }

    @Test
                                                        public void testAddValue_LongConversionForInteger() {
                                                            // Verify Integer is converted to Long in the frequency table
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(Integer.valueOf(10));
                                                            assertEquals(1L, frequency.getCount(10L)); // Check with long value
                                                        }

    @Test
                                                        public void testAddValue_NonIntegerObject() {
                                                            // Initialize frequency object
                                                            Frequency frequency = new Frequency();
                                                            
                                                            // Test with String (Comparable)
                                                            String testString = "test";
                                                            frequency.addValue(testString);
                                                            assertEquals(1L, frequency.getCount(testString));
                                                            
                                                            frequency.addValue(testString);
                                                            assertEquals(2L, frequency.getCount(testString));
                                                        }

    @Test
                                                        public void testAddValue_NullInput() {
                                                            org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                            
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("Value not comparable to existing values.");
                                                            frequency.addValue(null);
                                                        }

    @Test
                                                        public void testAddValue_NonComparableObject() {
                                                            // Create a new Frequency object
                                                            Frequency frequency = new Frequency();
                                                            
                                                            // Create a non-comparable object
                                                            Object nonComparable = new Object();
                                                            
                                                            // Set up expected exception
                                                            ExpectedException thrown = ExpectedException.none();
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("Value not comparable to existing values.");
                                                            
                                                            // Test the method
                                                            frequency.addValue(nonComparable);
                                                        }

    @Test
                                                        public void testAddValue_FirstValueSetsComparisonType() {
                                                            // First added value determines what types can be added later
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue("first");
                                                            
                                                            ExpectedException thrown = ExpectedException.none();
                                                            thrown.expect(IllegalArgumentException.class);
                                                            frequency.addValue(123); // Can't add Integer after String
                                                        }

    @Test
                                                        public void testAddValue_EdgeCaseMaxValues() {
                                                            // Test with max integer/long values
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(Integer.MAX_VALUE);
                                                            assertEquals(1L, frequency.getCount((long)Integer.MAX_VALUE));
                                                            
                                                            frequency.addValue(Long.MAX_VALUE);
                                                            assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                        }

    @Test
                                                        public void testAddValue_WithPositiveLong() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(5L);
                                                            frequency.addValue(5L);
                                                            frequency.addValue(10L);
                                                            
                                                            assertEquals(2, frequency.getCount(5L));
                                                            assertEquals(1, frequency.getCount(10L));
                                                            assertEquals(3, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValue_WithNegativeLong() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(-3L);
                                                            frequency.addValue(-3L);
                                                            frequency.addValue(-3L);
                                                            frequency.addValue(-5L);
                                                            
                                                            assertEquals(3, frequency.getCount(-3L));
                                                            assertEquals(1, frequency.getCount(-5L));
                                                            assertEquals(4, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValue_WithZero() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(0L);
                                                            frequency.addValue(0L);
                                                            frequency.addValue(0L);
                                                            frequency.addValue(0L);
                                                            
                                                            assertEquals(4, frequency.getCount(0L));
                                                            assertEquals(4, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValue_WithMaxLongValue() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(Long.MAX_VALUE);
                                                            frequency.addValue(Long.MAX_VALUE);
                                                            
                                                            assertEquals(2, frequency.getCount(Long.MAX_VALUE));
                                                            assertEquals(2, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValue_WithMinLongValue() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(Long.MIN_VALUE);
                                                            
                                                            assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                            assertEquals(1, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValue_MixedValues() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(100L);
                                                            frequency.addValue(-100L);
                                                            frequency.addValue(0L);
                                                            frequency.addValue(100L);
                                                            frequency.addValue(Long.MAX_VALUE);
                                                            frequency.addValue(Long.MIN_VALUE);
                                                            
                                                            assertEquals(2, frequency.getCount(100L));
                                                            assertEquals(1, frequency.getCount(-100L));
                                                            assertEquals(1, frequency.getCount(0L));
                                                            assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                            assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                            assertEquals(6, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValue_AfterClear() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(5L);
                                                            frequency.addValue(5L);
                                                            frequency.clear();
                                                            frequency.addValue(5L);
                                                            
                                                            assertEquals(1, frequency.getCount(5L));
                                                            assertEquals(1, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValue_Object_NullValue() {
                                                            org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                            Frequency frequency = new Frequency();
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("Value cannot be null");
                                                            frequency.addValue((Object)null);
                                                        }

    @Test
                                                        public void testAddValue_Object_ValidValue() {
                                                            Frequency frequency = new Frequency();
                                                            String value = "test";
                                                            frequency.addValue(value);
                                                            assertEquals(1, frequency.getCount(value));
                                                        }

    @Test
                                                        public void testAddValue_Comparable_NullValue() {
                                                            org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                            org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                            
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("Value cannot be null");
                                                            frequency.addValue((Comparable<?>)null);
                                                        }

    @Test
                                                        public void testAddValue_Comparable_ValidValue() {
                                                            Frequency frequency = new Frequency();
                                                            Integer value = 42;
                                                            frequency.addValue(value);
                                                            assertEquals(1, frequency.getCount(value));
                                                        }

    @Test
                                                        public void testAddValue_Int_ValidValue() {
                                                            Frequency frequency = new Frequency();
                                                            int value = 10;
                                                            frequency.addValue(value);
                                                            assertEquals(1, frequency.getCount(value));
                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                        public void testAddValue_Integer_NullValue() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue((Integer)null);
                                                        }

    @Test
                                                        public void testAddValue_Integer_ValidValue() {
                                                            Frequency frequency = new Frequency();
                                                            Integer value = 20;
                                                            frequency.addValue(value);
                                                            assertEquals(1, frequency.getCount(value));
                                                        }

    @Test
                                                        public void testAddValue_Long_ValidValue() {
                                                            Frequency frequency = new Frequency();
                                                            long value = 100L;
                                                            frequency.addValue(value);
                                                            assertEquals(1, frequency.getCount(value));
                                                        }

    @Test
                                                        public void testAddValue_Char_ValidValue() {
                                                            Frequency frequency = new Frequency();
                                                            char value = 'A';
                                                            frequency.addValue(value);
                                                            assertEquals(1, frequency.getCount(value));
                                                        }

    @Test
                                                        public void testAddValue_MultipleValues() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(1);
                                                            frequency.addValue(2L);
                                                            frequency.addValue('3');
                                                            frequency.addValue("4");
                                                            
                                                            assertEquals(1, frequency.getCount(1));
                                                            assertEquals(1, frequency.getCount(2L));
                                                            assertEquals(1, frequency.getCount('3'));
                                                            assertEquals(1, frequency.getCount("4"));
                                                        }

    @Test
                                                        public void testAddValue_DuplicateValues() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(5);
                                                            frequency.addValue(5);
                                                            frequency.addValue(5L);
                                                            
                                                            assertEquals(2, frequency.getCount(5)); // int and long are treated separately
                                                            assertEquals(1, frequency.getCount(5L));
                                                        }

    @Test
                                                        public void testAddValue_MixedTypes() {
                                                            Frequency frequency = new Frequency();
                                                            
                                                            frequency.addValue(1);          // int
                                                            frequency.addValue(1L);         // long
                                                            frequency.addValue("1");       // String
                                                            frequency.addValue('1');       // char
                                                            
                                                            assertEquals(1L, frequency.getCount(1));     // int
                                                            assertEquals(1L, frequency.getCount(1L));    // long
                                                            assertEquals(1L, frequency.getCount("1"));   // String
                                                            assertEquals(1L, frequency.getCount('1'));   // char
                                                        }

    @Test
                                                        public void testAddValue_Long_VerifyTreeMapStructure() {
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue(5L);
                                                            frequency.addValue(3L);
                                                            frequency.addValue(7L);
                                                            
                                                            try {
                                                                // Use reflection to access private freqTable field
                                                                Field field = Frequency.class.getDeclaredField("freqTable");
                                                                field.setAccessible(true);
                                                                @SuppressWarnings("unchecked")
                                                                TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                                                
                                                                // Verify the first and last keys in the TreeMap
                                                                assertEquals(3L, freqTable.firstKey());
                                                                assertEquals(7L, freqTable.lastKey());
                                                            } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                fail("Failed to access private freqTable field: " + e.getMessage());
                                                            }
                                                        }

    @Test
                                                        public void testAddValueWithNullShouldThrowNullPointerException() {
                                                            Frequency frequency = new Frequency();
                                                            
                                                            // Expect NullPointerException from original code
                                                            thrown.expect(NullPointerException.class);
                                                            
                                                            // Call method with null to test original vs mutated behavior
                                                            frequency.addValue((Object) null);
                                                            
                                                            // Note: If the test passes, it means the original code is in place
                                                            // If it fails with IllegalArgumentException, the mutant is detected
                                                        }

    @Test(expected = NullPointerException.class)
                                                    public void testAddValueWithNullShouldThrowNPE() {
                                                        Frequency frequency = new Frequency();
                                                        frequency.addValue(null);
                                                    }

    @Test(expected = NullPointerException.class)
                                                        public void testAddValueWithNullShouldThrowException() {
                                                            // This test will pass with original code (throws NPE) 
                                                            // and fail with mutated code (handles null silently)
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue((Object)null);
                                                            
                                                            // Additional check to ensure null wasn't added to freqTable
                                                            assertEquals(0, frequency.getCount(null));
                                                        }

    @Test
                                                        public void testAddValueWithNonNullComparable() {
                                                            Frequency frequency = new Frequency();
                                                            String testValue = "test"; // String implements Comparable
                                                            
                                                            frequency.addValue(testValue);
                                                            
                                                            assertEquals(1, frequency.getCount(testValue));
                                                        }

    @Test
                                                        public void testAddValueWithNonComparableObject() {
                                                            Frequency frequency = new Frequency();
                                                            Object testValue = new Object(); // Object doesn't implement Comparable
                                                            
                                                            frequency.addValue(testValue);
                                                            
                                                            // Behavior depends on implementation, but likely should be 0
                                                            assertEquals(0, frequency.getCount(testValue));
                                                        }

    @Test(expected = NullPointerException.class)
                                                        public void testAddValueObjectWithNullShouldThrowNPE() {
                                                            // This test will pass with original code (throws NPE) 
                                                            // and fail with mutant (handles null)
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue((Object)null);
                                                        }

    @Test
                                                        public void testAddValueObjectWithNullShouldNotModifyFrequency() {
                                                            Frequency frequency = new Frequency();
                                                            long initialSize = frequency.getSumFreq();
                                                            
                                                            try {
                                                                frequency.addValue((Object)null);
                                                            } catch (NullPointerException e) {
                                                                // Expected for original code
                                                            }
                                                            
                                                            // For original code: size remains same if NPE thrown
                                                            // For mutant: size remains same because null is skipped
                                                            assertEquals("Frequency count should not change after adding null",
                                                                        initialSize, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValueObjectWithNonNullComparable() {
                                                            Frequency frequency = new Frequency();
                                                            String comparableValue = "test";
                                                            
                                                            frequency.addValue((Object)comparableValue);
                                                            
                                                            assertEquals("Frequency count should increment for non-null Comparable",
                                                                        1, frequency.getCount(comparableValue));
                                                        }

    @Test
                                                        public void testAddValueObjectWithNonNullNonComparable() {
                                                            Frequency frequency = new Frequency();
                                                            Object nonComparable = new Object();
                                                            
                                                            try {
                                                                frequency.addValue(nonComparable);
                                                                fail("Expected ClassCastException for non-Comparable object");
                                                            } catch (ClassCastException e) {
                                                                // Expected behavior
                                                            }
                                                        }

    @Test(expected = NullPointerException.class)
                                                        public void testAddValueWithNullShouldThrowException1() {
                                                            // This test will pass with original code (throws NPE) 
                                                            // and fail with mutated code (no exception)
                                                            Frequency frequency = new Frequency();
                                                            frequency.addValue((Object)null);
                                                        }

    @Test
                                                        public void testAddValueWithComparable() {
                                                            Frequency frequency = new Frequency();
                                                            String comparableValue = "test"; // String implements Comparable
                                                            
                                                            frequency.addValue(comparableValue);
                                                            
                                                            assertEquals(1L, frequency.getCount(comparableValue));
                                                            assertEquals(1L, frequency.getSumFreq());
                                                        }

    @Test
                                                        public void testAddValueWithNonComparable() {
                                                            Frequency frequency = new Frequency();
                                                            Object nonComparable = new Object(); // Object doesn't implement Comparable
                                                            
                                                            frequency.addValue(nonComparable);
                                                            
                                                            // Should not be added to frequency table
                                                            assertEquals(0L, frequency.getCount(nonComparable));
                                                            assertEquals(0L, frequency.getSumFreq());
                                                        }

    @Test
                                                   public void testAddValueWithNullShouldNotAddToFrequencyTable() {
                                                       // Setup
                                                       Frequency frequency = new Frequency();
                                                       
                                                       // Action - add null value
                                                       frequency.addValue((Object)null);
                                                       
                                                       // Verification
                                                       assertEquals("Frequency table should be empty after adding null", 0, frequency.getSumFreq());
                                                       
                                                       // Additional check for count
                                                       assertEquals("Count for null should be 0", 0, frequency.getCount(null));
                                                   }

    @Test
                                                   public void testAddValueWithComparableShouldNotThrowException() {
                                                       // Setup
                                                       Frequency frequency = new Frequency();
                                                       Comparable<String> comparableValue = mock(Comparable.class);
                                                       
                                                       try {
                                                           // Action
                                                           frequency.addValue(comparableValue);
                                                           
                                                           // Verification - if we get here, the test passes for original code
                                                           // The mutant would have thrown an exception
                                                       } catch (IllegalArgumentException e) {
                                                           fail("Should not throw IllegalArgumentException for Comparable input");
                                                       }
                                                   }

    @Test
                                                   public void testAddValueWithNonComparableShouldThrowException() {
                                                       // Setup
                                                       Frequency frequency = new Frequency();
                                                       Object nonComparableValue = new Object();
                                                       
                                                       try {
                                                           // Action
                                                           frequency.addValue(nonComparableValue);
                                                           fail("Expected IllegalArgumentException for non-Comparable input");
                                                       } catch (IllegalArgumentException e) {
                                                           // Verification
                                                           assertEquals("Object must implement Comparable", e.getMessage());
                                                       }
                                                   }

    @Test
                                                   public void testAddValueWithComparableShouldCallOverloadedMethod() {
                                                       // Setup
                                                       Frequency frequencySpy = spy(new Frequency());
                                                       Comparable<String> comparableValue = mock(Comparable.class);
                                                       
                                                       // Action
                                                       frequencySpy.addValue(comparableValue);
                                                       
                                                       // Verification
                                                       verify(frequencySpy).addValue(comparableValue);
                                                       // The mutant would fail this verification as it never calls the overloaded method
                                                   }

    @Test
                                                   public void testAddValueWithNonComparableObjectShouldThrowIllegalArgumentException() {
                                                       // Create a non-comparable object
                                                       class NonComparable {}
                                                       Object nonComparable = new NonComparable();
                                                       
                                                       Frequency frequency = new Frequency();
                                                       
                                                       // Expect IllegalArgumentException for original code
                                                       thrown.expect(IllegalArgumentException.class);
                                                       thrown.expectMessage("Value not comparable to existing values.");
                                                       
                                                       // This will:
                                                       // - Pass with original code (throws IllegalArgumentException)
                                                       // - Fail with mutant (either throws ClassCastException or no exception)
                                                       frequency.addValue(nonComparable);
                                                   }

    @Test(expected = ClassCastException.class)
                                               public void testAddValueWithNonComparableShouldNotBeAdded() {
                                                   // Create a non-comparable object
                                                   Object nonComparable = new Object() {
                                                       @Override
                                                       public String toString() {
                                                           return "NonComparableObject";
                                                       }
                                                   };
                                                   
                                                   // Create frequency instance
                                                   Frequency frequency = new Frequency();
                                                   
                                                   // This should throw ClassCastException in original version 
                                                   // because the object isn't comparable,
                                                   // but would pass in mutant version since the check is bypassed
                                                   frequency.addValue(nonComparable);
                                                   
                                                   // Verify the object wasn't added (this line won't be reached if exception is thrown)
                                                   assertEquals(0, frequency.getCount(nonComparable));
                                               }

    @Test
                                                   public void testAddValueCharacterShouldIncreaseCount() {
                                                       // Setup
                                                       Frequency frequency = new Frequency();
                                                       char testChar = 'a';
                                                       
                                                       // Action - add the character value
                                                       frequency.addValue(testChar);
                                                       
                                                       // Verification
                                                       // Original: count should be 1 since Character is Comparable
                                                       // Mutant: count will remain 0 since condition is always false
                                                       assertEquals("Character value should be added to frequency table", 
                                                                    1L, frequency.getCount(testChar));
                                                       
                                                       // Additional verification that the value exists in the table
                                                       assertEquals("Character value should be counted once", 
                                                                    1L, frequency.getCount(Character.valueOf(testChar)));
                                                   }

    @Test
                                              public void testAddValueObject_ShouldOnlyAddComparableValues() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  Comparable<String> comparableValue = "test";
                                                  Object nonComparableValue = new Object();
                                                  
                                                  // Test with comparable value (should be added in original, not in mutant)
                                                  frequency.addValue(comparableValue);
                                                  assertEquals("Comparable value should be added to freqTable", 
                                                      1, frequency.getCount(comparableValue));
                                                  
                                                  // Test with non-comparable value (should not be added in either)
                                                  try {
                                                      frequency.addValue(nonComparableValue);
                                                      assertEquals("Non-comparable value should not be added to freqTable",
                                                          0, frequency.getCount(nonComparableValue));
                                                  } catch (ClassCastException e) {
                                                      // Expected for TreeMap with non-comparable keys
                                                  }
                                                  
                                                  // Additional verification through public API
                                                  assertEquals("Frequency should still contain the comparable value",
                                                      1, frequency.getCount(comparableValue));
                                                  assertEquals("Frequency should not contain non-comparable value",
                                                      0, frequency.getCount(nonComparableValue));
                                              }

    @Test
                                              public void testAddValueWithComparableShouldAddToTable() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  String comparableValue = "testValue"; // String implements Comparable
                                                  
                                                  // Action
                                                  frequency.addValue(comparableValue);
                                                  
                                                  // Verification
                                                  // Check if value was added to freqTable
                                                  assertEquals("Value should be added to frequency table", 1, frequency.getCount(comparableValue));
                                                  // Verify total count is 1 instead of directly checking table size
                                                  assertEquals("Frequency table total count should be 1", 1, frequency.getSumFreq());
                                              }

    @Test
                                              public void testAddValueWithNonComparableShouldNotAddToTable() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  Object nonComparableValue = new Object(); // Object doesn't implement Comparable
                                                  
                                                  // Action
                                                  frequency.addValue(nonComparableValue);
                                                  
                                                  // Verification
                                                  // Check if value was not added to freqTable
                                                  assertEquals("Non-comparable value should not be added", 0, frequency.getCount(nonComparableValue));
                                                  assertEquals("Frequency table should remain empty", 0, frequency.getSumFreq());
                                              }

    @Test
                                              public void testAddValueWithNonComparableObject1() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  Object nonComparable = new Object(); // Object that doesn't implement Comparable
                                                  
                                                  try {
                                                      // This should fail with ClassCastException in original version
                                                      // but might work in mutated version (bad behavior)
                                                      frequency.addValue(nonComparable);
                                                      
                                                      // If we get here, the mutant survived (bad)
                                                      fail("Expected ClassCastException when adding non-Comparable object");
                                                  } catch (ClassCastException e) {
                                                      // Expected behavior - original version would throw this
                                                      // Test passes - mutant would be caught
                                                  }
                                              }

    @Test
                                              public void testAddValueWithNull() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  
                                                  try {
                                                      frequency.addValue(null);
                                                      
                                                      // Check if it was properly added (count should be 1)
                                                      assertEquals(1, frequency.getCount(null));
                                                  } catch (NullPointerException e) {
                                                      // Original version might throw NPE if TreeMap doesn't allow nulls
                                                      // This depends on TreeMap implementation
                                                      // Either behavior is acceptable as long as it's consistent
                                                  }
                                              }

    @Test
                                              public void testAddValueTypeSafety() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  Long value = 123L;
                                                  
                                                  // This should use the more specific addValue(Comparable) method
                                                  frequency.addValue(value);
                                                  
                                                  // Verify it was added correctly
                                                  assertEquals(1, frequency.getCount(value));
                                                  assertEquals(1, frequency.getCount(123L));
                                                  
                                                  // Verify no ClassCastException occurred (would indicate wrong method called)
                                              }

    @Test
                                              public void testAddValueWithCustomComparator() {
                                                  // Create a custom comparator that handles raw objects
                                                  Comparator<Object> customComparator = new Comparator<Object>() {
                                                      @Override
                                                      public int compare(Object o1, Object o2) {
                                                          // Custom comparison logic
                                                          return o1.toString().compareTo(o2.toString());
                                                      }
                                                  };
                                                  
                                                  // Create Frequency with custom comparator
                                                  Frequency freq = new Frequency(customComparator);
                                                  
                                                  // Create a test object that isn't naturally Comparable
                                                  Object testValue = new Object() {
                                                      @Override
                                                      public String toString() {
                                                          return "testObject";
                                                      }
                                                  };
                                                  
                                                  // Add the value - this should work with original code but fail with mutant
                                                  freq.addValue(testValue);
                                                  
                                                  // Verify the count was properly recorded
                                                  assertEquals(1L, freq.getCount(testValue));
                                                  
                                                  // Add another value to test the comparator works
                                                  Object testValue2 = new Object() {
                                                      @Override
                                                      public String toString() {
                                                          return "anotherObject";
                                                      }
                                                  };
                                                  freq.addValue(testValue2);
                                                  
                                                  // Verify both values are properly counted and distinguished
                                                  assertEquals(1L, freq.getCount(testValue));
                                                  assertEquals(1L, freq.getCount(testValue2));
                                              }

    @Test
                                              public void testAddValueWithNonComparableShouldUseObjectVersion() {
                                                  // Create a custom non-Comparable object
                                                  class NonComparable {
                                                      final int value;
                                                      NonComparable(int v) { this.value = v; }
                                                  }
                                                  
                                                  Frequency freq = new Frequency();
                                                  NonComparable nc = new NonComparable(5);
                                                  
                                                  // This should call addValue(Object) in original, but would fail with ClassCastException
                                                  // in mutated version since it would try to put non-Comparable in TreeMap
                                                  try {
                                                      freq.addValue(nc);
                                                      // If we get here, the test should fail as the mutant survived
                                                      fail("Expected ClassCastException when adding non-Comparable object");
                                                  } catch (ClassCastException e) {
                                                      // Expected behavior for the mutant
                                                      // But we want the original to pass, so we need another way to detect
                                                      
                                                      // Alternative verification - check if value was actually added
                                                      // Original would add to map (as Object), mutant would throw exception
                                                      assertEquals(0, freq.getCount(nc)); // Should be 0 if exception thrown
                                                  }
                                              }

    @Test
                                              public void testAddValueWithComparableShouldUseComparableVersion() {
                                                  Frequency freq = new Frequency();
                                                  Comparable<Integer> compValue = 10; // Integer implements Comparable
                                                  
                                                  freq.addValue(compValue);
                                                  
                                                  // Verify value was added correctly
                                                  assertEquals(1, freq.getCount(compValue));
                                              }

    @Test
                                              public void testAddValueWithLongShouldUseLongVersion() {
                                                  Frequency freq = new Frequency();
                                                  long longValue = 20L;
                                                  
                                                  freq.addValue(longValue);
                                                  
                                                  // Verify value was added correctly
                                                  assertEquals(1, freq.getCount(longValue));
                                              }

    @Test
                                          public void testAddValueCharDetectsMutant() {
                                              // Create frequency object
                                              Frequency frequency = new Frequency();
                                              
                                              // Test char value
                                              char testChar = 'a';
                                              
                                              // Add the char value - should be converted to Character
                                              frequency.addValue(testChar);
                                              
                                              // Verify the count is correct (1)
                                              assertEquals(1L, frequency.getCount(testChar));
                                              
                                              // Verify the count when queried as Character object
                                              assertEquals(1L, frequency.getCount(Character.valueOf(testChar)));
                                              
                                              // Add same char again
                                              frequency.addValue(testChar);
                                              
                                              // Verify count increments to 2
                                              assertEquals(2L, frequency.getCount(testChar));
                                              assertEquals(2L, frequency.getCount(Character.valueOf(testChar)));
                                              
                                              // Verify the toString output contains the character (indirect check of storage)
                                              assertTrue(frequency.toString().contains("'a'"));
                                          }

    @Test
                                         public void testAddValueWithComparableObject() {
                                             // Create a Frequency instance
                                             Frequency frequency = new Frequency();
                                             
                                             // Create a Comparable object
                                             Comparable<String> comparableObj = "testString";
                                             
                                             // Add the value - should call addValue(Comparable<?>)
                                             frequency.addValue(comparableObj);
                                             
                                             // Verify it was added correctly by checking count
                                             long count = frequency.getCount(comparableObj);
                                             assertEquals("Comparable object should be added to frequency table", 1, count);
                                             
                                             // Verify no exception was thrown
                                             try {
                                                 frequency.addValue(comparableObj);
                                             } catch (IllegalArgumentException e) {
                                                 fail("Should not throw exception for Comparable object");
                                             }
                                         }

    @Test(expected = IllegalArgumentException.class)
                                         public void testAddValueWithNonComparableObject2() {
                                             // Create a Frequency object
                                             Frequency frequency = new Frequency();
                                             
                                             // Create a non-Comparable object
                                             Object nonComparableObj = new Object();
                                             
                                             // This should throw IllegalArgumentException
                                             frequency.addValue(nonComparableObj);
                                         }

    @Test
                                         public void testAddValueDetectsMutant() {
                                             // Create a Frequency instance
                                             Frequency frequency = new Frequency();
                                             
                                             // Create a test case that would behave differently if the mutation is present
                                             // Using a String which is Comparable
                                             String testString = "test";
                                             
                                             // Add the value - in original should call addValue(Comparable<?>)
                                             // If mutation is present, might call different overload
                                             frequency.addValue(testString);
                                             
                                             // Verify it was processed as Comparable by checking count
                                             long count = frequency.getCount(testString);
                                             assertEquals("String should be processed as Comparable", 1, count);
                                             
                                             // Add another value to verify behavior consistency
                                             frequency.addValue("another");
                                             assertEquals("Second string should be processed as Comparable", 1, frequency.getCount("another"));
                                         }

    @Test(expected = IllegalArgumentException.class)
                                         public void testAddValueWithNonComparableObject3() {
                                             // Create a Frequency object
                                             Frequency frequency = new Frequency();
                                             
                                             // Create a simple non-comparable object
                                             class NonComparable {}
                                             Object nonComparable = new NonComparable();
                                             
                                             // This should throw IllegalArgumentException
                                             // The original code would catch this during Comparable cast
                                             // The mutant would fail with ClassCastException from TreeMap
                                             frequency.addValue(nonComparable);
                                         }

    @Test
                                         public void testAddValueWithComparableObject1() {
                                             // Initialize Frequency object
                                             Frequency frequency = new Frequency();
                                             
                                             // Test with a comparable object to ensure normal functionality
                                             String comparable = "test";
                                             frequency.addValue(comparable);
                                             
                                             // Verify the frequency count was updated
                                             assertEquals(1L, frequency.getCount(comparable));
                                         }

    @Test
                                         public void testAddValueWithInteger() {
                                             // Create new Frequency instance
                                             Frequency frequency = new Frequency();
                                             
                                             // Test with Integer to ensure autoboxing works
                                             Integer value = 42;
                                             frequency.addValue(value);
                                             
                                             // Verify it was stored as Long and counted
                                             assertEquals(1L, frequency.getCount(value));
                                         }

    @Test
                                     public void testAddValueWithComparableShouldAddToFrequencyTable() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         String testValue = "testValue"; // String implements Comparable
                                         
                                         // Exercise
                                         frequency.addValue(testValue);
                                         
                                         // Verify
                                         // Original behavior: value should be added (count = 1)
                                         // Mutant behavior: null would be passed (count = 0)
                                         assertEquals("Comparable value should be added to frequency table", 
                                                      1, frequency.getCount(testValue));
                                         
                                         // Additional verification that the value exists in the table
                                         assertTrue("Frequency table should contain the added value",
                                                    frequency.getCount(testValue) > 0);
                                     }

    @Test
                                         public void testAddValueLongDetectsNullMutation() {
                                             // Setup
                                             Frequency frequency = new Frequency();
                                             long testValue = 123L;
                                             
                                             // Action - add the value
                                             frequency.addValue(testValue);
                                             
                                             // Verification - check the count increased
                                             // This would fail if mutation to addValue(null) was present
                                             assertEquals("Count should be 1 after adding value", 
                                                          1L, frequency.getCount(testValue));
                                             
                                             // Additional verification - check the sum frequency
                                             assertEquals("Total count should be 1 after adding one value",
                                                         1L, frequency.getSumFreq());
                                         }

    @Test
                                     public void testAddValueDetectsNullMutation() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         Integer testValue = 5;
                                         
                                         // Action - this would call the mutated method if the mutant is present
                                         frequency.addValue(testValue);
                                         
                                         // Verification
                                         // Original behavior: count for 5 should be 1
                                         // Mutant behavior: count for 5 would be 0 (or exception thrown)
                                         assertEquals("Count for added value should be 1", 1, frequency.getCount(testValue));
                                         
                                         // Additional check to ensure null wasn't added
                                         assertEquals("Count for null should be 0", 0, frequency.getCount(null));
                                     }

    @Test
                                     public void testAddValueLongShouldNotPassNull() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         long testValue = 123L;
                                         
                                         // Action
                                         frequency.addValue(testValue);
                                         
                                         // Verification
                                         // Verify the count for our test value is 1 (not null)
                                         assertEquals(1L, frequency.getCount(testValue));
                                         
                                         // Verify the total sum is 1 (not 0 if null was passed)
                                         assertEquals(1L, frequency.getSumFreq());
                                         
                                         // Verify no null was added to the table
                                         assertEquals(0L, frequency.getCount(null));
                                         
                                         // Verify our value exists in the table
                                         assertTrue(frequency.getCount(testValue) > 0);
                                     }

    @Test
                                     public void testAddValueCharShouldNotAddNull() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         char testChar = 'a';
                                         
                                         // Action
                                         frequency.addValue(testChar);
                                         
                                         // Verification
                                         // Original behavior: count for 'a' should be 1
                                         assertEquals(1, frequency.getCount(testChar));
                                         // Mutant behavior would increment null count instead
                                         assertEquals(0, frequency.getCount(null));
                                         
                                         // Additional verification that other counts remain 0
                                         assertEquals(0, frequency.getCount('b'));
                                         assertEquals(0, frequency.getCount(0));
                                     }

    @Test
                                    public void testAddValueWithComparableShouldNotCallWithNull() {
                                        // Initialize frequency object
                                        Frequency frequency = new Frequency();
                                        
                                        // Create a comparable object
                                        Comparable<String> comparableValue = "testValue";
                                        
                                        // This test will fail if the mutant is present because:
                                        // 1. Original code would call addValue(Comparable) with the actual value
                                        // 2. Mutant would call addValue(null) which would either:
                                        //    - Throw NullPointerException (not caught)
                                        //    - Or fail to increment count properly
                                        // Our expected behavior is that it properly handles the comparable
                                        
                                        // First add the value to initialize frequency
                                        frequency.addValue((Object)comparableValue);
                                        
                                        // Verify it was added correctly
                                        assertEquals(1, frequency.getCount(comparableValue));
                                        
                                        // Add again to increment count
                                        frequency.addValue((Object)comparableValue);
                                        
                                        // Verify count was incremented
                                        assertEquals(2, frequency.getCount(comparableValue));
                                        
                                        // The mutant would fail either by:
                                        // 1. Not incrementing count properly
                                        // 2. Throwing wrong exception
                                        // 3. Causing NullPointerException
                                    }

    @Test
                                    public void testAddValueWithNonComparableShouldThrowException1() {
                                        // This tests the original exception handling
                                        Frequency frequency = new Frequency();
                                        Object nonComparable = new Object();
                                        try {
                                            frequency.addValue(nonComparable);
                                            fail("Expected IllegalArgumentException");
                                        } catch (IllegalArgumentException e) {
                                            assertEquals("Value not comparable to existing values.", e.getMessage());
                                        }
                                    }

    @Test
                                public void testAddValueWithComparableObjectShouldUpdateFrequencyTable() {
                                    // Setup
                                    Frequency frequency = new Frequency();
                                    String testValue = "test"; // String implements Comparable
                                    
                                    // Action
                                    frequency.addValue(testValue);
                                    
                                    // Verification
                                    // If the method works correctly, the count should be 1
                                    // If the mutant exists, the count would remain 0
                                    assertEquals("Frequency count should be 1 for added value", 
                                                 1, frequency.getCount(testValue));
                                    
                                    // Additional verification that the value was actually added to the table
                                    assertEquals("Sum of frequencies should be 1", 
                                                 1, frequency.getSumFreq());
                                }

    @Test
                                public void testAddValueWithComparableObjectShouldHandleComparable() {
                                    // Setup
                                    Frequency frequency = new Frequency();
                                    String comparableValue = "test"; // String implements Comparable
                                    
                                    // Test
                                    frequency.addValue(comparableValue);
                                    
                                    // Verify
                                    assertEquals(1L, frequency.getCount(comparableValue));
                                    
                                    // Add again to test increment
                                    frequency.addValue(comparableValue);
                                    assertEquals(2L, frequency.getCount(comparableValue));
                                    
                                    // Test with different comparable
                                    String anotherValue = "another";
                                    frequency.addValue(anotherValue);
                                    assertEquals(1L, frequency.getCount(anotherValue));
                                    assertEquals(2L, frequency.getCount(comparableValue));
                                }

    @Test(expected = IllegalArgumentException.class)
                                public void testAddValueWithNonComparableObjectShouldThrow() {
                                    // Setup
                                    Frequency frequency = new Frequency();
                                    Object nonComparable = new Object(); // Object doesn't implement Comparable
                                    
                                    // Test - should throw
                                    frequency.addValue(nonComparable);
                                }

    @Test
                                public void testAddValueWithComparable1() {
                                    // Setup
                                    Frequency frequency = new Frequency();
                                    String comparableValue = "testString"; // String implements Comparable
                                    
                                    // Action
                                    try {
                                        // This should call addValue(Comparable) in original code
                                        // But will fail in mutated code since the call is commented out
                                        frequency.addValue(comparableValue);
                                    } catch (Exception e) {
                                        // In original code, this shouldn't throw exception
                                        fail("Original code should handle Comparable values");
                                    }
                                    
                                    // Verification
                                    // Original code would have added the String to freqTable
                                    // Mutated code would not have added it
                                    long count = frequency.getCount(comparableValue);
                                    assertEquals("Comparable value should be counted", 1L, count);
                                    
                                    // Additional check for the specific mutation
                                    // Verify the value was actually added to the TreeMap
                                    // This is implementation-specific but necessary to catch the mutation
                                    try {
                                        Field field = Frequency.class.getDeclaredField("freqTable");
                                        field.setAccessible(true);
                                        TreeMap<?, ?> freqTable = (TreeMap<?, ?>) field.get(frequency);
                                        assertTrue("freqTable should contain the comparable value", 
                                                  freqTable.containsKey(comparableValue));
                                    } catch (Exception e) {
                                        fail("Reflection failed: " + e.getMessage());
                                    }
                                }

    @Test
                                public void testAddValueLongShouldAddToFrequencyTable() {
                                    // Setup
                                    Frequency frequency = new Frequency();
                                    long testValue = 12345L;
                                    
                                    // Action
                                    frequency.addValue(testValue);
                                    
                                    // Verification
                                    // Verify the value was added by checking its count
                                    assertEquals("Count should be 1 after adding value", 1, frequency.getCount(testValue));
                                    // Verify the sum frequency increased
                                    assertEquals("Total frequency should be 1", 1, frequency.getSumFreq());
                                    
                                    // Additional verification that the value is in the table
                                    // by checking percentage (should be 100% since it's the only value)
                                    assertEquals(1.0, frequency.getPct(testValue), 0.0001);
                                }

    @Test
                                public void testAddValueCharDetectsMutant1() {
                                    // Setup
                                    Frequency frequency = new Frequency();
                                    char testChar = 'a';
                                    
                                    // Action - add the character
                                    frequency.addValue(testChar);
                                    
                                    // Verification - check count for the character
                                    // Original behavior should have count=1, mutant will have count=0
                                    assertEquals("Character count should be 1 after adding", 1, frequency.getCount(testChar));
                                    
                                    // Additional test to ensure counting works with multiple additions
                                    frequency.addValue(testChar);
                                    assertEquals("Character count should be 2 after adding twice", 2, frequency.getCount(testChar));
                                    
                                    // Test with different character to ensure proper counting
                                    char anotherChar = 'b';
                                    frequency.addValue(anotherChar);
                                    assertEquals("Different character should have count=1", 1, frequency.getCount(anotherChar));
                                    assertEquals("Original character count should remain 2", 2, frequency.getCount(testChar));
                                }

    @Test
                               public void testAddValueWithNonNumberComparable() {
                                   // Setup
                                   Frequency frequency = new Frequency();
                                   Comparable<String> nonNumberComparable = "testString"; // String is Comparable but not Number
                                   
                                   // Action - this should fail with ClassCastException in original, but might work in mutant
                                   try {
                                       frequency.addValue(nonNumberComparable);
                                       
                                       // If we get here, the mutant survived - verify the frequency table
                                       try {
                                           Field field = Frequency.class.getDeclaredField("freqTable");
                                           field.setAccessible(true);
                                           @SuppressWarnings("unchecked")
                                           TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                           assertTrue("Mutant detected - non-Number Comparable was added to frequency table", 
                                                      freqTable.containsKey(nonNumberComparable));
                                       } catch (Exception e) {
                                           fail("Reflection failed: " + e.getMessage());
                                       }
                                   } catch (ClassCastException e) {
                                       // This is expected behavior for original code
                                       assertTrue("Original behavior preserved", true);
                                   }
                               }

    @Test
                               public void testAddValueWithNonComparableObject4() {
                                   Frequency frequency = new Frequency();
                                   Object nonComparable = new Object(); // Object doesn't implement Comparable
                                   
                                   // Set up expectation for the exception
                                   thrown.expect(IllegalArgumentException.class);
                                   thrown.expectMessage("Object must implement Comparable");
                                   
                                   // This should go to the else branch and throw exception
                                   frequency.addValue(nonComparable);
                                   
                                   // The test will fail if the exception isn't thrown
                                   // The mutant would still pass this test since the behavior is the same
                                   // but mutation testing tools would detect that the else branch wasn't properly covered
                               }

    @Test
                               public void testAddValueWithComparableObject2() {
                                   Frequency frequency = new Frequency();
                                   Comparable<String> comparable = "test"; // String implements Comparable
                                   
                                   try {
                                       // This should go to the if branch and not throw exception
                                       frequency.addValue(comparable);
                                   } catch (IllegalArgumentException e) {
                                       fail("Comparable object should not throw IllegalArgumentException");
                                   }
                                   
                                   // Additional verification could be added here to check the value was actually added
                               }

    @Test
                           public void testAddValueLongDetectsElseBranchMutation() {
                               // Setup
                               Frequency frequency = new Frequency();
                               Long testValue = 12345L;
                               
                               // Action - first addition (should go to else branch)
                               frequency.addValue(testValue);
                               
                               // Verification
                               assertEquals("First addition should have count 1", 
                                           1L, frequency.getCount(testValue));
                               
                               // Action - second addition (should increment count)
                               frequency.addValue(testValue);
                               
                               // Verification
                               assertEquals("Second addition should have count 2", 
                                           2L, frequency.getCount(testValue));
                               
                               // Additional verification of map state
                               assertEquals("Total frequency count should be 2", 
                                           2L, frequency.getSumFreq());
                           }

    @Test
                               public void testAddValueLong() {
                                   // Setup
                                   Frequency frequency = new Frequency();
                                   Long value1 = Long.valueOf(5L);
                                   Long value2 = Long.valueOf(5L); // Same value to test increment
                                   Long value3 = Long.valueOf(10L); // Different value
                                   
                                   // Test adding new value (should go to else branch)
                                   frequency.addValue(value1);
                                   assertEquals(1L, frequency.getCount(value1));
                                   
                                   // Test adding same value again (should go to if branch)
                                   frequency.addValue(value2);
                                   assertEquals(2L, frequency.getCount(value1));
                                   
                                   // Test adding different value (should go to else branch)
                                   frequency.addValue(value3);
                                   assertEquals(1L, frequency.getCount(value3));
                                   
                                   // Verify all counts
                                   assertEquals(2L, frequency.getCount(value1));
                                   assertEquals(1L, frequency.getCount(value3));
                               }

    @Test
                               public void testAddValueLongNewEntry() {
                                   // Setup
                                   Frequency frequency = new Frequency();
                                   Long testValue = 12345L;
                                   
                                   // Verify initial state
                                   assertEquals(0, frequency.getCount(testValue));
                                   
                                   // Execute
                                   frequency.addValue(testValue);
                                   
                                   // Verify
                                   assertEquals(1, frequency.getCount(testValue));
                                   
                                   // Add same value again to test increment
                                   frequency.addValue(testValue);
                                   assertEquals(2, frequency.getCount(testValue));
                               }

    @Test
                               public void testAddValueLongExistingEntry() {
                                   // Setup
                                   Frequency frequency = new Frequency();
                                   Long testValue = 67890L;
                                   frequency.addValue(testValue); // First addition
                                   
                                   // Verify initial state
                                   assertEquals(1, frequency.getCount(testValue));
                                   
                                   // Execute
                                   frequency.addValue(testValue); // Second addition
                                   
                                   // Verify
                                   assertEquals(2, frequency.getCount(testValue));
                               }

    @Test
                          public void testAddValueIncrementsCountForExistingValue() {
                              // Setup
                              Frequency frequency = new Frequency();
                              Integer value = 5;
                              
                              // First addition (should go to if branch)
                              frequency.addValue(value);
                              // Verify initial count
                              assertEquals(1L, frequency.getCount(value));
                              
                              // Second addition (should go to else branch - target the mutation)
                              frequency.addValue(value);
                              // Verify count incremented
                              assertEquals(2L, frequency.getCount(value));
                              
                              // Third addition (further verify else branch)
                              frequency.addValue(value);
                              assertEquals(3L, frequency.getCount(value));
                              
                              // Verify the TreeMap state directly
                              try {
                                  Field field = Frequency.class.getDeclaredField("freqTable");
                                  field.setAccessible(true);
                                  TreeMap<Object, Long> freqTable = (TreeMap<Object, Long>) field.get(frequency);
                                  Long storedValue = freqTable.get(5L); // Note: value was converted to Long
                                  assertEquals(3L, storedValue.longValue());
                              } catch (Exception e) {
                                  fail("Failed to access freqTable field: " + e.getMessage());
                              }
                          }

    @Test
                          public void testAddValueCharDetectsElseIfTrueMutant() {
                              // Setup
                              Frequency frequency = new Frequency();
                              char testChar = 'a';
                              
                              // Test initial addition (should go through if branch)
                              frequency.addValue(testChar);
                              assertEquals(1L, frequency.getCount(testChar));
                              
                              // Test subsequent addition (should go through else/else if branch)
                              frequency.addValue(testChar);
                              assertEquals(2L, frequency.getCount(testChar));
                              
                              // Verify the freqTable contains exactly one entry for the character
                              // We can verify this by checking the sum of frequencies equals the count of our test character
                              assertEquals(2L, frequency.getSumFreq());
                              
                              // Test with different character to ensure complete coverage
                              char anotherChar = 'b';
                              frequency.addValue(anotherChar);
                              assertEquals(1L, frequency.getCount(anotherChar));
                              // Verify total count is now 3 (2 for 'a' and 1 for 'b')
                              assertEquals(3L, frequency.getSumFreq());
                          }

    @Test
                          public void testAddValueObjectIsDeprecated() throws Exception {
                              // Test that the method is marked as deprecated
                              Method method = Frequency.class.getMethod("addValue", Object.class);
                              assertTrue("Method should be deprecated", 
                                  method.isAnnotationPresent(Deprecated.class));
                              
                              // Also verify the method still works correctly
                              Frequency frequency = new Frequency();
                              frequency.addValue(5); // Integer input
                              frequency.addValue(10L); // Long input
                              
                              // Verify counts were incremented correctly
                              assertEquals(1L, frequency.getCount(5));
                              assertEquals(1L, frequency.getCount(10L));
                              
                              // Verify non-comparable throws exception
                              try {
                                  frequency.addValue(new Object());
                                  fail("Should throw IllegalArgumentException for non-comparable");
                              } catch (IllegalArgumentException e) {
                                  assertEquals("Value not comparable to existing values.", e.getMessage());
                              }
                          }

    @Test
                     public void testAddValueObjectIsDeprecated1() throws Exception {
                         // Get the Method object for addValue(Object)
                         Method method = org.apache.commons.math.stat.Frequency.class.getMethod("addValue", Object.class);
                         
                         // Check for Deprecated annotation
                         java.lang.annotation.Annotation deprecatedAnnotation = method.getAnnotation(java.lang.Deprecated.class);
                         
                         // Assert that the annotation exists
                         assertNotNull("addValue(Object) method should be marked as @Deprecated", 
                                      deprecatedAnnotation);
                     }

    @Test
                     public void testAddValueLongMethodIsDeprecated() throws NoSuchMethodException {
                         // Get the method using reflection
                         Method method = org.apache.commons.math.stat.Frequency.class.getMethod("addValue", Long.class);
                         
                         // Check if the method has the Deprecated annotation
                         java.lang.annotation.Annotation deprecatedAnnotation = method.getAnnotation(Deprecated.class);
                         
                         // Assert that the annotation is present
                         assertNotNull("addValue(Long) method should be marked as @Deprecated", deprecatedAnnotation);
                     }

    @Test
                     public void testAddValueCharIsDeprecated() throws Exception {
                         // Get the method using reflection
                         Method method = Frequency.class.getMethod("addValue", char.class);
                         
                         // Check if the method has @Deprecated annotation
                         java.lang.annotation.Annotation[] annotations = method.getAnnotations();
                         boolean isDeprecated = false;
                         
                         for (java.lang.annotation.Annotation annotation : annotations) {
                             if (annotation.annotationType().equals(java.lang.Deprecated.class)) {
                                 isDeprecated = true;
                                 break;
                             }
                         }
                         
                         // Assert that the method is deprecated
                         assertTrue("addValue(char) method should be deprecated", isDeprecated);
                     }

    @Test
             public void testAddValueLongIsDeprecated() throws NoSuchMethodException {
                 // Get the method using reflection
                 Method method = org.apache.commons.math.stat.Frequency.class.getMethod("addValue", long.class);
                 
                 // Check if the method has @Deprecated annotation
                 java.lang.annotation.Annotation[] annotations = method.getAnnotations();
                 boolean isDeprecated = false;
                 
                 for (java.lang.annotation.Annotation annotation : annotations) {
                     if (annotation instanceof java.lang.Deprecated) {
                         isDeprecated = true;
                         break;
                     }
                 }
                 
                 // Assert that the method is deprecated
                 assertTrue("addValue(long) method should be marked as @Deprecated", isDeprecated);
             }

    @Test
         public void testAddValueLongIsDeprecated1() throws NoSuchMethodException {
             // Get the method using reflection
             Method method = org.apache.commons.math.stat.Frequency.class.getMethod("addValue", long.class);
             
             // Check if the method has @Deprecated annotation
             boolean isDeprecated = method.isAnnotationPresent(Deprecated.class);
             
             // Assert that the method is deprecated
             assertTrue("addValue(long) method should be marked as @Deprecated", isDeprecated);
         }

    @Test
         public void testAddValueWithNonComparableShouldThrowException2() {
             Frequency frequency = new Frequency();
             Object nonComparable = new Object();
             
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("Object must implement Comparable");
             frequency.addValue(nonComparable);
         }

    @Test
         public void testAddValueWithGenericComparableShouldWork() {
             // Setup
             Frequency frequency = new Frequency();
             String genericComparable = "test"; // String implements Comparable<String>
             
             // This should work fine
             frequency.addValue(genericComparable);
             
             // Verify the value was added
             assertEquals(1L, frequency.getCount(genericComparable));
         }

    @Test
         public void testAddValueWithRawComparable() {
             // Create a raw Comparable implementation
             class RawComparable implements Comparable {
                 private final int value;
                 
                 public RawComparable(int value) {
                     this.value = value;
                 }
                 
                 @Override
                 public int compareTo(Object o) {
                     RawComparable other = (RawComparable) o;
                     return Integer.compare(this.value, other.value);
                 }
             }
             
             Frequency frequency = new Frequency();
             RawComparable raw1 = new RawComparable(1);
             RawComparable raw2 = new RawComparable(1);
             
             // Add the raw comparable objects
             frequency.addValue(raw1);
             frequency.addValue(raw2);
             
             // Verify they were counted properly
             assertEquals(2L, frequency.getCount(raw1));
             
             // Add another distinct raw comparable
             RawComparable raw3 = new RawComparable(2);
             frequency.addValue(raw3);
             assertEquals(1L, frequency.getCount(raw3));
         }

    @Test
         public void testAddValueWithRawComparable1() {
             // Create a test object that implements raw Comparable
             class RawComparable implements Comparable {
                 private final long value;
                 
                 public RawComparable(long value) {
                     this.value = value;
                 }
                 
                 @Override
                 public int compareTo(Object o) {
                     RawComparable other = (RawComparable) o;
                     return Long.compare(this.value, other.value);
                 }
                 
                 @Override
                 public boolean equals(Object obj) {
                     if (!(obj instanceof RawComparable)) return false;
                     return this.value == ((RawComparable) obj).value;
                 }
             }
             
             Frequency frequency = new Frequency();
             RawComparable testValue = new RawComparable(42L);
             
             // This should be handled by the original code but not by the mutant
             frequency.addValue(testValue);
             
             // Verify the value was added to the frequency table
             assertEquals(1L, frequency.getCount(testValue));
             assertEquals(1L, frequency.getSumFreq());
             
             // Add another value to verify comparison works
             RawComparable anotherValue = new RawComparable(42L);
             frequency.addValue(anotherValue);
             assertEquals(2L, frequency.getCount(testValue));
             assertEquals(2L, frequency.getSumFreq());
         }

    @Test
         public void testAddValueWithNonComparableObject5() {
             Frequency frequency = new Frequency();
             
             // Test with null value
             try {
                 frequency.addValue((Object)null);
                 // Should reach here as null check should be handled
             } catch (NullPointerException e) {
                 fail("Null values should be handled gracefully");
             }
             
             // Test with non-Comparable object
             Object nonComparable = new Object();
             try {
                 frequency.addValue(nonComparable);
                 // Should reach here as non-Comparable objects should be handled
             } catch (ClassCastException e) {
                 fail("Non-Comparable objects should be handled gracefully");
             }
             
             // Test with raw Comparable (not generic)
             Comparable rawComparable = new Comparable() {
                 @Override
                 public int compareTo(Object o) {
                     return 0;
                 }
             };
             try {
                 frequency.addValue(rawComparable);
                 // Should pass as it's a Comparable
             } catch (Exception e) {
                 fail("Raw Comparable should be accepted");
             }
             
             // Test with generic Comparable
             Comparable<String> genericComparable = s -> 0;
             try {
                 frequency.addValue(genericComparable);
                 // Should pass as it's a Comparable
             } catch (Exception e) {
                 fail("Generic Comparable should be accepted");
             }
         }

    @Test
    public void testAddValueWithRawComparableShouldBeAccepted() {
        Frequency frequency = new Frequency();
        
        // Create a simple Comparable implementation
        class RawComparable implements Comparable<Object> {
            @Override
            public int compareTo(Object o) {
                return 0; // simple implementation for testing
            }
        }
        
        RawComparable rawComparable = new RawComparable();
        
        // This should pass in both original and mutant, but included for completeness
        frequency.addValue(rawComparable);
        // No exception thrown means test passes
    }

    @Test
    public void testAddValueWithParameterizedComparableShouldBeAccepted() {
        Frequency frequency = new Frequency();
        
        // Create a simple Comparable implementation for testing
        class TestComparable implements Comparable<TestComparable> {
            @Override
            public int compareTo(TestComparable o) {
                return 0;
            }
        }
        
        TestComparable testComparable = new TestComparable();
        
        // This test will fail with the mutant but pass with original
        frequency.addValue(testComparable);
        // No exception thrown means test passes
    }

    @Test
    public void testAddValueWithRawComparableShouldThrow() {
        // Setup
        Frequency frequency = new Frequency();
        
        // Define a simple non-comparable class
        class RawComparable {
            // Intentionally doesn't implement Comparable
        }
        RawComparable rawComparable = new RawComparable();
        
        try {
            // This should throw IllegalArgumentException because RawComparable doesn't implement Comparable<?>
            // The mutant would accept this input, which is wrong
            frequency.addValue(rawComparable);
            
            // If we get here, the test fails (exception wasn't thrown)
            fail("Expected IllegalArgumentException for raw Comparable input");
        } catch (IllegalArgumentException e) {
            // Expected exception
        }
    }

    @Test
    public void testAddValueWithDifferentComparableTypes() {
        // Setup
        Frequency frequency = new Frequency();
        
        // Define test Comparable implementations
        class TestComparable implements Comparable<TestComparable> {
            @Override
            public int compareTo(TestComparable o) {
                return 0;
            }
        }
        
        class RawComparable implements Comparable {
            @Override
            public int compareTo(Object o) {
                return 0;
            }
        }
        
        // Test with raw Comparable
        RawComparable raw = new RawComparable();
        frequency.addValue(raw);
        
        // Test with generic Comparable
        TestComparable generic = new TestComparable();
        frequency.addValue(generic);
        
        // Test with non-Comparable
        Object nonComparable = new Object();
        frequency.addValue(nonComparable);
        
        // Verify only the properly typed Comparable was added
        TreeMap<Comparable<?>, Long> freqTable;
        try {
            Field field = frequency.getClass().getDeclaredField("freqTable");
            field.setAccessible(true);
            freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
        } catch (Exception e) {
            throw new RuntimeException("Failed to access freqTable field", e);
        }
        
        // Raw Comparable should not be in the table (if original code)
        assertFalse("Raw Comparable should not be in frequency table", 
                   freqTable.containsKey(raw));
                   
        // Generic Comparable should be in the table
        assertTrue("Generic Comparable should be in frequency table", 
                  freqTable.containsKey(generic));
                  
        // Non-Comparable should not be in the table
        assertFalse("Non-Comparable should not be in frequency table", 
                   freqTable.containsKey(nonComparable));
    }


}
