package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class ArrayRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                            public void testMapInvToSelf_NormalValues() {
                                                                                double[] input = {1.0, 2.0, 4.0, 0.5};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                
                                                                                // Verify the vector was modified in place
                                                                                assertSame(vector, result);
                                                                                
                                                                                // Verify each element's reciprocal
                                                                                double[] expected = {1.0, 0.5, 0.25, 2.0};
                                                                                assertArrayEquals(expected, result.getData(), 0.0001);
                                                                            }

 @Test
                                                                            public void testMapInvToSelf_NegativeValues() {
                                                                                double[] input = {-1.0, -2.0, -4.0};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                
                                                                                double[] expected = {-1.0, -0.5, -0.25};
                                                                                assertArrayEquals(expected, result.getData(), 0.0001);
                                                                            }

 @Test
                                                                            public void testMapInvToSelf_MixedValues() {
                                                                                double[] input = {1.0, -2.0, 0.5, -0.25};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                RealVector result = vector.mapInvToSelf();
                                                                                
                                                                                double[] expected = {1.0, -0.5, 2.0, -4.0};
                                                                                assertArrayEquals(expected, ((ArrayRealVector)result).getData(), 0.0001);
                                                                            }

 @Test(expected = ArithmeticException.class)
                                                                            public void testMapInvToSelf_ZeroValueThrowsException() {
                                                                                double[] input = {1.0, 0.0, 2.0};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                vector.mapInvToSelf();
                                                                            }

 @Test
                                                                            public void testMapInvToSelf_ExtremeValues() {
                                                                                double[] input = {Double.MIN_VALUE, Double.MAX_VALUE};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                RealVector result = vector.mapInvToSelf();
                                                                                
                                                                                // Verify reciprocals of extreme values
                                                                                assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
                                                                                assertEquals(1.0 / Double.MAX_VALUE, result.getEntry(1), 0.0);
                                                                            }

 @Test
                                                                            public void testMapInvToSelf_SpecialDoubleValues() {
                                                                                double[] input = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NaN};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                
                                                                                assertEquals(0.0, result.getEntry(0), 0.0);
                                                                                assertEquals(0.0, result.getEntry(1), 0.0);
                                                                                assertTrue(Double.isNaN(result.getEntry(2)));
                                                                            }

 @Test
                                                                            public void testMapInvToSelf_EmptyVector() {
                                                                                double[] input = {};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                                assertEquals(0, result.getDimension());
                                                                            }

 @Test
                                                                            public void testMapInvToSelf_Chaining() {
                                                                                double[] input = {1.0, 2.0, 4.0};
                                                                                ArrayRealVector vector = new ArrayRealVector(input);
                                                                                
                                                                                // Test method chaining
                                                                                RealVector result = vector.mapInvToSelf().mapInvToSelf();
                                                                                
                                                                                // Should return to original values
                                                                                assertArrayEquals(input, ((ArrayRealVector)result).getData(), 0.0001);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_EmptyVector() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[0]);
                                                                                assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_SingleElement() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[]{5.0});
                                                                                assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{-3.0});
                                                                                assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{0.0});
                                                                                assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_MultipleElements() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, -2.0, 3.0, -4.0, 5.0});
                                                                                assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{-10.0, 2.5, -3.7, 8.2, -1.1});
                                                                                assertEquals(10.0, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{0.0, 0.0, 0.0, 0.0});
                                                                                assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_ExtremeValues() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[]{Double.MAX_VALUE});
                                                                                assertEquals(Double.MAX_VALUE, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{-Double.MAX_VALUE});
                                                                                assertEquals(Double.MAX_VALUE, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{Double.MIN_VALUE});
                                                                                assertEquals(Double.MIN_VALUE, vector.getLInfNorm(), 0.0);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_WithNaN() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, Double.NaN, 3.0});
                                                                                assertEquals(Double.NaN, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{Double.NaN});
                                                                                assertEquals(Double.NaN, vector.getLInfNorm(), 0.0);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_WithInfiniteValues() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, Double.POSITIVE_INFINITY, 3.0});
                                                                                assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{1.0, 2.0, Double.NEGATIVE_INFINITY, 3.0});
                                                                                assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{Double.POSITIVE_INFINITY});
                                                                                assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_MixedPositiveNegative() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[]{-1.5, 2.3, -3.7, 4.2, -0.5});
                                                                                assertEquals(4.2, vector.getLInfNorm(), 0.0001);
                                                                                
                                                                                vector = new ArrayRealVector(new double[]{-100.0, 99.9, -50.5, 75.2});
                                                                                assertEquals(100.0, vector.getLInfNorm(), 0.0001);
                                                                            }

 @Test
                                                                            public void testGetLInfNorm_AfterModification() {
                                                                                ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, 3.0});
                                                                                assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector.setEntry(1, 5.0); // Change middle element to 5.0
                                                                                assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                                
                                                                                vector.setEntry(0, -6.0); // Change first element to -6.0
                                                                                assertEquals(6.0, vector.getLInfNorm(), 0.0);
                                                                            }

 @Test
                                                                       public void testMapAtanToSelfWithNonEmptyArray() {
                                                                           // Create a vector with some data
                                                                           double[] testData = {1.0, 2.0, 3.0};
                                                                           ArrayRealVector vector = new ArrayRealVector(testData);
                                                                           
                                                                           // This should not throw any exception
                                                                           ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                                           
                                                                           // Verify the vector was modified correctly
                                                                           assertEquals(testData.length, result.getDimension());
                                                                           for (int i = 0; i < testData.length; i++) {
                                                                               assertEquals(Math.atan(testData[i]), result.getEntry(i), 0.0001);
                                                                           }
                                                                       }

 @Test
                                                                       public void testMapAtanToSelfWithEmptyArray() {
                                                                           // Create an empty vector
                                                                           ArrayRealVector vector = new ArrayRealVector();
                                                                           
                                                                           // This should not throw any exception
                                                                           RealVector result = vector.mapAtanToSelf();
                                                                           
                                                                           // Verify the vector remains empty
                                                                           assertEquals(0, result.getDimension());
                                                                       }

 @Test
                                                                  public void testMapAtanToSelfProcessesAllElements() {
                                                                      // Create a test vector with known values
                                                                      double[] testData = {0.0, 0.5, 1.0};  // First element is 0.0 which has known atan value
                                                                      ArrayRealVector vector = new ArrayRealVector(testData);
                                                                      
                                                                      // Apply the transformation
                                                                      ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                                      
                                                                      // Verify the first element was processed (would fail with the mutant)
                                                                      assertEquals(Math.atan(testData[0]), result.getEntry(0), 0.0001);
                                                                      
                                                                      // Also verify other elements for completeness
                                                                      assertEquals(Math.atan(testData[1]), result.getEntry(1), 0.0001);
                                                                      assertEquals(Math.atan(testData[2]), result.getEntry(2), 0.0001);
                                                                      
                                                                      // Verify the vector is returned (fluent interface)
                                                                      assertSame(vector, result);
                                                                  }

 @Test
                                                                  public void testMapAtanToSelfWithSingleElementArray() {
                                                                      // Edge case: array with only one element
                                                                      double[] testData = {1.0};
                                                                      ArrayRealVector vector = new ArrayRealVector(testData);
                                                                      
                                                                      ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                                      
                                                                      // With the mutant, this element would be skipped entirely
                                                                      assertEquals(Math.atan(testData[0]), result.getEntry(0), 0.0001);
                                                                      assertSame(vector, result);
                                                                  }

 @Test
                                                             public void testMapAtanToSelfDetectsLengthMutation() {
                                                                 // Test with array length > 1 to catch the mutant
                                                                 double[] testData = {1.0, 2.0, 3.0}; // length = 3
                                                                 ArrayRealVector vector = new ArrayRealVector(testData);
                                                                 
                                                                 // Apply the operation
                                                                 ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                                 
                                                                 // Verify all elements were processed (mutant would miss last element)
                                                                 assertEquals(Math.atan(1.0), result.getEntry(0), 0.0001);
                                                                 assertEquals(Math.atan(2.0), result.getEntry(1), 0.0001);
                                                                 assertEquals(Math.atan(3.0), result.getEntry(2), 0.0001);
                                                                 
                                                                 // Test with array length = 1 (mutant would process no elements)
                                                                 double[] singleElementData = {1.0};
                                                                 ArrayRealVector singleVector = new ArrayRealVector(singleElementData);
                                                                 
                                                                 ArrayRealVector singleResult = (ArrayRealVector) singleVector.mapAtanToSelf();
                                                                 assertEquals(Math.atan(1.0), singleResult.getEntry(0), 0.0001);
                                                                 
                                                                 // Test with empty array (both versions behave the same)
                                                                 double[] emptyData = {};
                                                                 ArrayRealVector emptyVector = new ArrayRealVector(emptyData);
                                                                 ArrayRealVector emptyResult = (ArrayRealVector) emptyVector.mapAtanToSelf();
                                                                 assertEquals(0, emptyResult.getDimension());
                                                             }

 @Test
                                                        public void testMapAtanToSelfDetectsInfiniteLoopMutant() {
                                                            // Create a vector with some data
                                                            double[] testData = {1.0, 2.0, 3.0};
                                                            ArrayRealVector vector = new ArrayRealVector(testData);
                                                            
                                                            // Store original first element for comparison
                                                            double originalFirstElement = vector.getEntry(0);
                                                            
                                                            // Call the method - if mutant exists, this will timeout
                                                            ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                            
                                                            // Verify the method returns the same object (this)
                                                            assertSame(vector, result);
                                                            
                                                            // Verify at least the first element was processed
                                                            assertNotEquals(originalFirstElement, result.getEntry(0), 0.0001);
                                                            
                                                            // Verify all elements were processed (original behavior)
                                                            for (int i = 0; i < testData.length; i++) {
                                                                assertEquals(Math.atan(testData[i]), result.getEntry(i), 0.0001);
                                                            }
                                                        }

 @Test
                                                   public void testMapAtanToSelfDetectsSkippedElementsMutant() {
                                                       // Create test data with distinct values at all positions
                                                       double[] testData = {1.0, 2.0, 3.0, 4.0, 5.0}; // odd length to test both even and odd indices
                                                       ArrayRealVector vector = new ArrayRealVector(testData);
                                                       
                                                       // Call the method
                                                       RealVector result = vector.mapAtanToSelf();
                                                       
                                                       // Verify the method returns the same object (for chaining)
                                                       assertSame(vector, result);
                                                       
                                                       // Get the modified data
                                                       double[] modifiedData = vector.getData();
                                                       
                                                       // Verify ALL elements were processed (not just every other one)
                                                       // Check even indices (would be processed by both original and mutant)
                                                       assertEquals(Math.atan(1.0), modifiedData[0], 0.0001);
                                                       assertEquals(Math.atan(3.0), modifiedData[2], 0.0001);
                                                       assertEquals(Math.atan(5.0), modifiedData[4], 0.0001);
                                                       
                                                       // Check odd indices (would be skipped by mutant but processed by original)
                                                       assertEquals(Math.atan(2.0), modifiedData[1], 0.0001);
                                                       assertEquals(Math.atan(4.0), modifiedData[3], 0.0001);
                                                       
                                                       // Additional check: verify no element remains unchanged
                                                       for (int i = 0; i < testData.length; i++) {
                                                           assertNotEquals("Element at index " + i + " was not processed", 
                                                                          testData[i], modifiedData[i], 0.0001);
                                                       }
                                                   }

 @Test
                                              public void testMapAtanToSelfDetectsTanMutant() {
                                                  // Create test input where tan(x) is significantly different from atan(x)
                                                  double[] input = {0.0, 0.5, 1.0, -1.0, 2.0};
                                                  ArrayRealVector vector = new ArrayRealVector(input);
                                                  
                                                  // Expected results after applying atan
                                                  double[] expected = new double[input.length];
                                                  for (int i = 0; i < input.length; i++) {
                                                      expected[i] = Math.atan(input[i]);
                                                  }
                                                  
                                                  // Apply the operation
                                                  ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                                                  
                                                  // Verify the vector was modified in place
                                                  assertSame(vector, result);
                                                  
                                                  // Verify each element was correctly transformed
                                                  double[] actual = result.getData();
                                                  assertArrayEquals(expected, actual, 1e-15);
                                                  
                                                  // Additional check that would fail if mutant was present
                                                  // Choose a value where tan(x) is very different from atan(x)
                                                  double testValue = 1.0;
                                                  double atanValue = Math.atan(testValue);
                                                  double tanValue = Math.tan(testValue);
                                                  assertNotEquals("Test would fail if mutant was present (tan instead of atan)", 
                                                                 tanValue, actual[2], 1e-15);
                                              }

 @Test
                                         public void testMapAtanToSelfDetectsAsinMutation() {
                                             // Test with values outside [-1,1] where asin would fail
                                             double[] testData = {2.0, -2.0, 0.5, -0.5, 0.0};
                                             ArrayRealVector vector = new ArrayRealVector(testData);
                                             
                                             // Store original values for comparison
                                             double[] originalValues = testData.clone();
                                             
                                             // Apply the operation and verify it's the same object (for chaining)
                                             assertSame(vector, vector.mapAtanToSelf());
                                             
                                             // Verify each value was properly transformed
                                             for (int i = 0; i < testData.length; i++) {
                                                 // Check that the result matches Math.atan, not Math.asin
                                                 assertEquals(Math.atan(originalValues[i]), vector.getEntry(i), 1e-10);
                                                 
                                                 // Additional check that it's not asin result (for values within [-1,1])
                                                 if (Math.abs(originalValues[i]) <= 1.0) {
                                                     assertNotEquals(Math.asin(originalValues[i]), vector.getEntry(i), 1e-10);
                                                 }
                                             }
                                             
                                             // Additional test with value that would make asin return NaN
                                             double[] edgeData = {1.5};
                                             ArrayRealVector edgeVector = new ArrayRealVector(edgeData);
                                             edgeVector.mapAtanToSelf();
                                             assertFalse(Double.isNaN(edgeVector.getEntry(0))); // atan(1.5) is valid
                                         }

 @Test
                                    public void testMapAtanToSelfDetectsAcosMutation() {
                                        // Test with values outside [-1,1] range where acos would fail
                                        double[] testData1 = {2.0, -2.0, 1.5, -1.5};
                                        ArrayRealVector vector1 = new ArrayRealVector(testData1.clone());
                                        vector1.mapAtanToSelf(); // Should work fine with atan
                                        
                                        // Test with values inside [-1,1] range where results differ
                                        double[] testData2 = {0.5, -0.5, 1.0, -1.0, 0.0};
                                        ArrayRealVector vector2 = new ArrayRealVector(testData2.clone());
                                        ArrayRealVector result = (ArrayRealVector) vector2.mapAtanToSelf();
                                        
                                        // Verify the vector itself is returned for chaining
                                        assertSame(vector2, result);
                                        
                                        // Verify each element was correctly transformed with atan (not acos)
                                        double[] expected = new double[testData2.length];
                                        for (int i = 0; i < testData2.length; i++) {
                                            expected[i] = Math.atan(testData2[i]);
                                        }
                                        assertArrayEquals(expected, result.getData(), 1e-10);
                                        
                                        // Verify edge case of 0
                                        assertEquals(0.0, result.getEntry(4), 1e-10);
                                        
                                        // Verify edge cases of 1 and -1
                                        assertEquals(Math.atan(1.0), result.getEntry(2), 1e-10);
                                        assertEquals(Math.atan(-1.0), result.getEntry(3), 1e-10);
                                    }

 @Test
                               public void testMapAtanToSelf() {
                                   // Create test data with values that will clearly show the difference
                                   // between atan(x) and atan(-x). Using 1.0 since atan(1.0) = π/4 ≈ 0.785
                                   // and atan(-1.0) = -π/4 ≈ -0.785
                                   double[] testData = {1.0, 0.5, -0.5, 0.0};
                                   ArrayRealVector vector = new ArrayRealVector(testData.clone());
                                   
                                   // Apply the operation - modifies the vector in-place
                                   vector.mapAtanToSelf();
                                   
                                   // Verify each element
                                   assertEquals(Math.atan(testData[0]), vector.getEntry(0), 1e-15);
                                   assertEquals(Math.atan(testData[1]), vector.getEntry(1), 1e-15);
                                   assertEquals(Math.atan(testData[2]), vector.getEntry(2), 1e-15);
                                   assertEquals(Math.atan(testData[3]), vector.getEntry(3), 1e-15);
                                   
                                   // The test will fail if the mutation is present because:
                                   // For index 0: 0.785 ≠ -0.785
                                   // For index 1: 0.463 ≠ -0.463
                                   // For index 2: -0.463 ≠ 0.463
                                   // Only index 3 (0.0) would pass since atan(0) = -atan(0) = 0
                               }

 @Test
                          public void testMapAtanToSelfDetectsMutant() {
                              // Create test data with values that will clearly show the difference
                              // between atan(x) and atan(x+1)
                              double[] testData = {0.0, 1.0, -1.0, 0.5, -0.5, 10.0, -10.0};
                              ArrayRealVector vector = new ArrayRealVector(testData.clone());
                              
                              // Expected results using original behavior (atan(x))
                              double[] expected = new double[testData.length];
                              for (int i = 0; i < testData.length; i++) {
                                  expected[i] = Math.atan(testData[i]);
                              }
                              
                              // Call the method
                              ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                              
                              // Verify the vector was modified in-place
                              assertSame(vector, result);
                              
                              // Get the actual results
                              double[] actual = result.getData();
                              
                              // Verify each element matches expected atan(x) value
                              // This will fail if the mutant (atan(x+1)) is present
                              assertArrayEquals(expected, actual, 0.000001);
                              
                              // Additional check: verify at least one value would be different with mutant
                              // This ensures our test data is good enough to catch the mutant
                              double[] mutantExpected = new double[testData.length];
                              for (int i = 0; i < testData.length; i++) {
                                  mutantExpected[i] = Math.atan(testData[i] + 1);
                              }
                              boolean atLeastOneDifferent = false;
                              for (int i = 0; i < expected.length; i++) {
                                  if (Math.abs(expected[i] - mutantExpected[i]) > 0.000001) {
                                      atLeastOneDifferent = true;
                                      break;
                                  }
                              }
                              assertTrue("Test data should produce different results for mutant", atLeastOneDifferent);
                          }

 @Test
                          public void testMapAtanToSelfDetectsMutant1() {
                              // Create test data with values where atan(x) != atan(2x)
                              double[] testData = {0.5, 1.0, 1.5};
                              ArrayRealVector vector = new ArrayRealVector(testData);
                              
                              // Make a copy of original data for comparison
                              double[] originalData = testData.clone();
                              
                              // Apply the method
                              vector.mapAtanToSelf();
                              
                              // Verify each element was transformed correctly
                              for (int i = 0; i < originalData.length; i++) {
                                  double expected = Math.atan(originalData[i]);
                                  double actual = vector.getDataRef()[i];
                                  assertEquals("Element at index " + i + " should be Math.atan of original value",
                                               expected, actual, 1e-15);
                              }
                          }

 @Test
                    public void testMapAtanToSelf_ShouldReturnThis() {
                        // Arrange
                        double[] testData = {1.0, 0.0, -1.0};
                        ArrayRealVector vector = new ArrayRealVector(testData);
                        
                        // Act
                        ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                        
                        // Assert
                        // Verify the array was modified correctly
                        assertEquals(Math.atan(1.0), result.getData()[0], 0.0001);
                        assertEquals(Math.atan(0.0), result.getData()[1], 0.0001);
                        assertEquals(Math.atan(-1.0), result.getData()[2], 0.0001);
                        
                        // Verify the return value is the same object (not null)
                        assertSame("Method should return this", vector, result);
                    }

}
