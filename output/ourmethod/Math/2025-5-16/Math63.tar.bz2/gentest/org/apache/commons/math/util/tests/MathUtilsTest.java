package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.Localizable;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.exception.NonMonotonousSequenceException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                          public void testEquals_IdenticalValues() {
                                              assertTrue(MathUtils.equals(0.0, 0.0));
                                              assertTrue(MathUtils.equals(1.0, 1.0));
                                              assertTrue(MathUtils.equals(-1.0, -1.0));
                                              assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE));
                                              assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
                                          }

 @Test
                                          public void testEquals_WithinDefaultEpsilon() {
                                              // Values within default epsilon (1.0) should be considered equal
                                              assertTrue(MathUtils.equals(5.0, 5.5));
                                              assertTrue(MathUtils.equals(5.5, 5.0));
                                              assertTrue(MathUtils.equals(-5.0, -5.5));
                                              assertTrue(MathUtils.equals(-5.5, -5.0));
                                          }

 @Test
                                          public void testEquals_OutsideDefaultEpsilon() {
                                              // Values outside default epsilon (1.0) should not be considered equal
                                              assertFalse(MathUtils.equals(5.0, 6.1));
                                              assertFalse(MathUtils.equals(6.1, 5.0));
                                              assertFalse(MathUtils.equals(-5.0, -6.1));
                                              assertFalse(MathUtils.equals(-6.1, -5.0));
                                          }

 @Test
                                          public void testEquals_WithNaNValues() {
                                              // NaN should not equal NaN (unless using equalsIncludingNaN)
                                              assertFalse(MathUtils.equals(Double.NaN, Double.NaN));
                                              assertFalse(MathUtils.equals(Double.NaN, 1.0));
                                              assertFalse(MathUtils.equals(1.0, Double.NaN));
                                          }

 @Test
                                          public void testEquals_WithInfiniteValues() {
                                              // Infinity cases
                                              assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
                                              assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY));
                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.MAX_VALUE));
                                              assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE));
                                          }

 @Test
                                          public void testEquals_WithExtremeValues() {
                                              // Test with very large and very small numbers
                                              assertTrue(MathUtils.equals(1.0E20, 1.0E20 + 0.5));
                                              assertFalse(MathUtils.equals(1.0E20, 1.0E20 + 2.0));
                                              
                                              assertTrue(MathUtils.equals(1.0E-20, 1.0E-20 + 1.0E-21));
                                              assertFalse(MathUtils.equals(1.0E-20, 1.0E-20 + 2.0E-20));
                                          }

 @Test
                                          public void testEquals_WithZeroAndNearZero() {
                                              // Special cases around zero
                                              assertTrue(MathUtils.equals(0.0, 0.5));
                                              assertTrue(MathUtils.equals(0.0, -0.5));
                                              assertFalse(MathUtils.equals(0.0, 1.1));
                                              assertFalse(MathUtils.equals(0.0, -1.1));
                                              
                                              // Positive and negative zero should be equal
                                              assertTrue(MathUtils.equals(0.0, -0.0));
                                          }

 @Test
                                          public void testEquals_ExactValues() {
                                              // Test exact equality
                                              assertTrue(MathUtils.equals(1.0, 1.0, 0.0001));
                                              assertTrue(MathUtils.equals(0.0, 0.0, 0.0001));
                                              assertTrue(MathUtils.equals(-1.0, -1.0, 0.0001));
                                          }

 @Test
                                          public void testEquals_WithinEpsilon() {
                                              // Test values within epsilon range
                                              double eps = 0.0001;
                                              assertTrue(MathUtils.equals(1.0, 1.0 + eps/2, eps));
                                              assertTrue(MathUtils.equals(1.0, 1.0 - eps/2, eps));
                                              assertTrue(MathUtils.equals(-1.0, -1.0 + eps/2, eps));
                                              assertTrue(MathUtils.equals(-1.0, -1.0 - eps/2, eps));
                                          }

 @Test
                                          public void testEquals_OutsideEpsilon() {
                                              // Test values outside epsilon range
                                              double eps = 0.0001;
                                              assertFalse(MathUtils.equals(1.0, 1.0 + eps*2, eps));
                                              assertFalse(MathUtils.equals(1.0, 1.0 - eps*2, eps));
                                              assertFalse(MathUtils.equals(-1.0, -1.0 + eps*2, eps));
                                              assertFalse(MathUtils.equals(-1.0, -1.0 - eps*2, eps));
                                          }

 @Test
                                          public void testEquals_EdgeCases() {
                                              // Test edge cases
                                              assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE, 0.0001));
                                              assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE, 0.0001));
                                              assertFalse(MathUtils.equals(Double.MAX_VALUE, Double.MIN_VALUE, 0.0001));
                                              
                                              // Test with very small epsilon
                                              assertTrue(MathUtils.equals(1.0, 1.0, Double.MIN_VALUE));
                                              assertFalse(MathUtils.equals(1.0, 1.0 + Double.MIN_VALUE, Double.MIN_VALUE));
                                          }

 @Test
                                          public void testEquals_SpecialValues() {
                                              // Test with special floating-point values
                                              assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 0.0001));
                                              assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.0001));
                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.0001));
                                              
                                              // NaN should not equal NaN
                                              assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 0.0001));
                                          }

 @Test
                                          public void testEquals_ZeroEpsilon() {
                                              // Test with zero epsilon - should require exact equality
                                              assertTrue(MathUtils.equals(1.0, 1.0, 0.0));
                                              assertFalse(MathUtils.equals(1.0, 1.000000000000001, 0.0));
                                          }

 @Test
                                          public void testEquals_LargeEpsilon() {
                                              // Test with very large epsilon
                                              assertTrue(MathUtils.equals(1.0, 100.0, 100.0));
                                              assertTrue(MathUtils.equals(-1.0, -100.0, 100.0));
                                              assertFalse(MathUtils.equals(1.0, 101.0, 100.0));
                                          }

 @Test
                                          public void testEquals_ULPSFallback() {
                                              // Test cases where the ULPS comparison (equals(x, y, 1)) would pass but epsilon comparison would fail
                                              // This depends on the implementation of equals(x, y, maxUlps) which we don't see
                                              // But we can test that the method returns true when either condition is met
                                              
                                              // Mock the equals(x, y, 1) call to return true
                                              // Note: This is tricky since the method is static, but we can test the behavior
                                              // by choosing values that would make equals(x, y, 1) return true
                                              double x = 1.0;
                                              double y = x + Math.ulp(x); // Next representable number
                                              assertTrue(MathUtils.equals(x, y, 0.0)); // Should pass via ULPS check
                                              
                                              // Test case where ULPS check fails but epsilon check passes
                                              x = 1.0;
                                              y = x + 0.5 * 0.0001;
                                              double eps = 0.0001;
                                              assertTrue(MathUtils.equals(x, y, eps));
                                          }

 @Test
                                          public void testEquals_ExactSameValues() {
                                              assertTrue(MathUtils.equals(1.0, 1.0, 1));
                                              assertTrue(MathUtils.equals(0.0, 0.0, 1));
                                              assertTrue(MathUtils.equals(-1.0, -1.0, 1));
                                          }

 @Test
                                          public void testEquals_WithinUlpsTolerance() {
                                              // Values that differ by exactly maxUlps should be equal
                                              double x = 1.0;
                                              double y = Double.longBitsToDouble(Double.doubleToLongBits(x) + 1);
                                              assertTrue(MathUtils.equals(x, y, 1));
                                      
                                              // Values that differ by less than maxUlps should be equal
                                              x = 1.23456789;
                                              y = 1.2345678900000001;
                                              assertTrue(MathUtils.equals(x, y, 10));
                                          }

 @Test
                                          public void testEquals_OutsideUlpsTolerance() {
                                              // Values that differ by more than maxUlps should not be equal
                                              double x = 1.0;
                                              double y = Double.longBitsToDouble(Double.doubleToLongBits(x) + 2);
                                              assertFalse(MathUtils.equals(x, y, 1));
                                      
                                              x = 123456.789;
                                              y = 123456.78900000001;
                                              assertFalse(MathUtils.equals(x, y, 1));
                                          }

 @Test
                                          public void testEquals_WithNaN() {
                                              // NaN should never equal anything, even another NaN
                                              assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 1));
                                              assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
                                              assertFalse(MathUtils.equals(Double.NaN, 1.0, 1));
                                          }

 @Test
                                          public void testEquals_WithInfinities() {
                                              // Positive infinity
                                              assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1));
                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.MAX_VALUE, 1000));
                                              
                                              // Negative infinity
                                              assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                                              assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE, 1000));
                                              
                                              // Mixed infinities
                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                                          }

 @Test
                                          public void testEquals_WithZeroAndNegativeZero() {
                                              // +0.0 and -0.0 should be considered equal
                                              assertTrue(MathUtils.equals(0.0, -0.0, 1));
                                          }

 @Test(expected = IllegalArgumentException.class)
                                          public void testEquals_InvalidMaxUlpsZero() {
                                              MathUtils.equals(1.0, 1.0, 0);
                                          }

 @Test(expected = IllegalArgumentException.class)
                                          public void testEquals_InvalidMaxUlpsNegative() {
                                              MathUtils.equals(1.0, 1.0, -1);
                                          }

 @Test(expected = IllegalArgumentException.class)
                                          public void testEquals_InvalidMaxUlpsTooLarge() {
                                              // NAN_GAP is a private constant, but we can assume it's larger than any reasonable ULP value
                                              MathUtils.equals(1.0, 1.0, Integer.MAX_VALUE);
                                          }

 @Test
                                          public void testEquals_ExtremeValues() {
                                              // Test with very large numbers
                                              double x = Double.MAX_VALUE;
                                              double y = Double.MAX_VALUE;
                                              assertTrue(MathUtils.equals(x, y, 1));
                                              
                                              y = Double.longBitsToDouble(Double.doubleToLongBits(x) - 1);
                                              assertTrue(MathUtils.equals(x, y, 1));
                                              
                                              // Test with very small numbers
                                              x = Double.MIN_VALUE;
                                              y = Double.MIN_VALUE;
                                              assertTrue(MathUtils.equals(x, y, 1));
                                              
                                              y = Double.longBitsToDouble(Double.doubleToLongBits(x) + 1);
                                              assertTrue(MathUtils.equals(x, y, 1));
                                          }

 @Test
                                          public void testEquals_SubnormalNumbers() {
                                              // Test with subnormal numbers
                                              double x = Double.MIN_VALUE;
                                              double y = x / 2.0;
                                              assertFalse(MathUtils.equals(x, y, 1));
                                          }

 @Test
                                          public void testEquals_BothArraysNull() {
                                              assertTrue(MathUtils.equals(null, null));
                                          }

 @Test
                                          public void testEquals_FirstArrayNull() {
                                              double[] y = {1.0, 2.0};
                                              assertFalse(MathUtils.equals(null, y));
                                          }

 @Test
                                          public void testEquals_SecondArrayNull() {
                                              double[] x = {1.0, 2.0};
                                              assertFalse(MathUtils.equals(x, null));
                                          }

 @Test
                                          public void testEquals_DifferentLengths() {
                                              double[] x = {1.0, 2.0};
                                              double[] y = {1.0};
                                              assertFalse(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_EmptyArrays() {
                                              double[] x = {};
                                              double[] y = {};
                                              assertTrue(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_EqualArrays() {
                                              double[] x = {1.0, 2.0, 3.0};
                                              double[] y = {1.0, 2.0, 3.0};
                                              assertTrue(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_UnequalArrays() {
                                              double[] x = {1.0, 2.0, 3.0};
                                              double[] y = {1.0, 2.0, 4.0};
                                              assertFalse(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_ArraysWithNaN() {
                                              double[] x = {1.0, Double.NaN, 3.0};
                                              double[] y = {1.0, Double.NaN, 3.0};
                                              // Regular equals should return false for NaN values
                                              assertFalse(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_ArraysWithDifferentNaNPositions() {
                                              double[] x = {1.0, Double.NaN, 3.0};
                                              double[] y = {1.0, 2.0, 3.0};
                                              assertFalse(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_ArraysWithInfinities() {
                                              double[] x = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                              double[] y = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                              assertTrue(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_ArraysWithDifferentInfinities() {
                                              double[] x = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                              double[] y = {1.0, Double.NEGATIVE_INFINITY, 3.0};
                                              assertFalse(MathUtils.equals(x, y));
                                          }

 @Test
                                          public void testEquals_LargeArrays() {
                                              double[] x = new double[1000];
                                              double[] y = new double[1000];
                                              for (int i = 0; i < 1000; i++) {
                                                  x[i] = i * 0.1;
                                                  y[i] = i * 0.1;
                                              }
                                              assertTrue(MathUtils.equals(x, y));
                                              
                                              // Change one value
                                              y[500] = 500.1;
                                              assertFalse(MathUtils.equals(x, y));
                                          }

 @Test
                                  public void testEquals_WithNegativeNumbers() {
                                      // Negative numbers should be handled correctly
                                      assertTrue(MathUtils.equals(-1.0, -1.0, 1));
                                      
                                      double x = -1.0;
                                      long xBits = Double.doubleToLongBits(x);
                                      double y = Double.longBitsToDouble(xBits + 1);
                                      assertTrue(MathUtils.equals(x, y, 1));
                                      
                                      y = Double.longBitsToDouble(xBits + 2);
                                      assertFalse(MathUtils.equals(x, y, 1));
                                  }

 @Test
                                  public void testEqualsWithSwappedArgumentsShouldBeDetected() {
                                      // Test case where equals(x,y,1) would differ from equals(y,x,1)
                                      // Using Double.MIN_VALUE and a slightly larger value to test ULP boundaries
                                      double x = Double.MIN_VALUE;
                                      double y = Double.MIN_VALUE * 2; // Exactly 1 ULP apart
                                      
                                      // The original method would return true for equals(x,y,1) 
                                      // because they are within 1 ULP of each other
                                      // The mutant would return the same in this case, so we need a different approach
                                      
                                      // Alternative test case using NaN values
                                      double nan1 = Double.NaN;
                                      double nan2 = Double.longBitsToDouble(Double.doubleToLongBits(Double.NaN) + 1);
                                      
                                      // The original equals(x,y,1) might handle NaN comparison differently than equals(y,x,1)
                                      // depending on the implementation of the underlying equals method
                                      
                                      // Most reliable test case: use numbers where x and y are very close but not equal
                                      // and the epsilon is just slightly smaller than their difference
                                      double a = 1.0000001;
                                      double b = 1.0000002;
                                      double eps = 0.00000005; // smaller than the difference
                                      
                                      // The original should return equals(a,b,1) || FastMath.abs(b - a) <= eps
                                      // equals(a,b,1) might be true while equals(b,a,1) might be false due to ULP comparison direction
                                      
                                      // Since we don't have the implementation of equals(x,y,maxUlps), we'll assume it's
                                      // a standard ULP-based comparison where order might matter for edge cases
                                      
                                      // The most straightforward way to catch this is to test with values where:
                                      // equals(x,y,1) is true but FastMath.abs(y - x) > eps
                                      // and equals(y,x,1) is false
                                      
                                      // Create such a case:
                                      double small = 1.0e-100;
                                      double slightlyLarger = Math.nextUp(small);
                                      double tightEps = 0.9 * (slightlyLarger - small);
                                      
                                      // Test that the method returns true (original behavior)
                                      assertTrue(MathUtils.equals(small, slightlyLarger, tightEps));
                                      
                                      // If the mutant swapped arguments, it might return false if equals(y,x,1) is false
                                      // and the difference is greater than eps
                                  }

 @Test
                              public void testEqualsWithSwappedParametersShouldBeEquivalent() {
                                  // Test with positive and negative zero
                                  double posZero = 0.0;
                                  double negZero = -0.0;
                                  
                                  // Original behavior should be same regardless of parameter order
                                  boolean originalResult1 = MathUtils.equals(posZero, negZero, 1);
                                  boolean originalResult2 = MathUtils.equals(negZero, posZero, 1);
                                  assertEquals("Positive and negative zero should be equal", originalResult1, originalResult2);
                                  
                                  // Test with different NaN representations
                                  double nan1 = Double.NaN;
                                  double nan2 = Double.longBitsToDouble(0x7ff8000000000000L); // different NaN representation
                                  
                                  boolean nanResult1 = MathUtils.equals(nan1, nan2, 1);
                                  boolean nanResult2 = MathUtils.equals(nan2, nan1, 1);
                                  assertEquals("Different NaN representations should be equal", nanResult1, nanResult2);
                                  
                                  // Test with very small denormal numbers
                                  double small1 = Double.MIN_VALUE;
                                  double small2 = Double.longBitsToDouble(Double.doubleToLongBits(Double.MIN_VALUE) + 1);
                                  
                                  boolean smallResult1 = MathUtils.equals(small1, small2, 1);
                                  boolean smallResult2 = MathUtils.equals(small2, small1, 1);
                                  assertEquals("Small denormal numbers comparison should be symmetric", smallResult1, smallResult2);
                                  
                                  // Test with large numbers
                                  double large1 = Double.MAX_VALUE;
                                  double large2 = Double.longBitsToDouble(Double.doubleToLongBits(Double.MAX_VALUE) - 1);
                                  
                                  boolean largeResult1 = MathUtils.equals(large1, large2, 1);
                                  boolean largeResult2 = MathUtils.equals(large2, large1, 1);
                                  assertEquals("Large numbers comparison should be symmetric", largeResult1, largeResult2);
                              }

 @Test
                             public void testEqualsWithSwappedParametersShouldFailWhenOrderMatters() {
                                 // Case 1: NaN vs normal number (order matters)
                                 double nan = Double.NaN;
                                 double normal = 1.0;
                                 
                                 // Case 2: Numbers where ULP comparison order matters
                                 double x = 1.0000000000000002; // 1.0 + 1 ULP
                                 double y = 1.0;
                                 
                                 // Case 3: Special zero case
                                 double posZero = 0.0;
                                 double negZero = -0.0;
                                 
                                 // Test commutative property for ULP comparison
                                 assertTrue("Method should be commutative for these values", 
                                     MathUtils.equals(x, y, 1) == MathUtils.equals(y, x, 1));
                                 
                                 // Create a value that is exactly 1 ULP away from 1.0
                                 double a = Double.longBitsToDouble(Double.doubleToLongBits(1.0) + 1);
                                 double b = 1.0;
                                 
                                 // Test that equals() returns same result regardless of parameter order
                                 assertTrue("Method should return same result regardless of parameter order",
                                     MathUtils.equals(a, b, 1) == MathUtils.equals(b, a, 1));
                             }

 @Test
             public void testEqualsDoubleArraysWithOrderDependentComparison() {
                 // Setup arrays where equals(double, double) is order-sensitive
                 double[] arr1 = new double[]{1.0000001};
                 double[] arr2 = new double[]{1.0000002};
                 
                 // Create a spy for MathUtils class to override equals behavior
                 MathUtils mathUtilsSpy = spy(MathUtils.class);
                 
                 // Override the equals method to be order-sensitive
                 doAnswer(invocation -> {
                     double x = invocation.getArgument(0);
                     double y = invocation.getArgument(1);
                     return x <= y;  // Only true when x <= y
                 }).when(mathUtilsSpy).equals(anyDouble(), anyDouble());
                 
                 // Test with original order (should return true)
                 boolean originalResult = mathUtilsSpy.equals(arr1, arr2);
                 
                 // Test with swapped order (should return false)
                 boolean swappedResult = mathUtilsSpy.equals(arr2, arr1);
                 
                 // Verify the mutant would fail this test
                 // Original method would return true for both cases
                 // Mutant would return false for original order and true for swapped order
                 assertTrue("Original order should be considered equal", originalResult);
                 assertFalse("Swapped order should not be considered equal", swappedResult);
             }

 @Test
             public void testEqualsWithOneUlpDifference() {
                 // Test case where numbers differ by exactly 1 ULP
                 double base = 1.0;
                 double ulp = Math.ulp(base);
                 double x = base;
                 double y = base + ulp;  // exactly 1 ULP difference
                 
                 // Original should return true (1 ULP difference is allowed)
                 // Mutant will also return true (since it allows 2 ULPs)
                 // This case won't catch the mutant
                 assertTrue(MathUtils.equals(x, y));
             }

 @Test
             public void testEqualsWithTwoUlpsDifference() {
                 // Test case where numbers differ by exactly 2 ULPs
                 double base = 1.0;
                 double ulp = Math.ulp(base);
                 double x = base;
                 double y = base + 2 * ulp;  // exactly 2 ULPs difference
                 
                 // Original should return false (only 1 ULP allowed)
                 // Mutant will return true (allows 2 ULPs)
                 assertFalse(MathUtils.equals(x, y));
             }

 @Test
             public void testEqualsWithOnePointFiveUlpsDifference() {
                 // Test case where numbers differ by 1.5 ULPs
                 // This will help catch any rounding issues
                 double base = 1.0;
                 double ulp = Math.ulp(base);
                 double x = base;
                 double y = base + 1.5 * ulp;
                 
                 // Original should return false (1.5 > 1)
                 // Mutant will return true (1.5 <= 2)
                 assertFalse(MathUtils.equals(x, y));
             }

 @Test
             public void testEqualsWithUlpsDifference() {
                 // Test case where numbers differ by exactly 1 ULP
                 double base = 1.0;
                 double oneUlpDiff = base + Math.ulp(base);
                 assertTrue(MathUtils.equals(base, oneUlpDiff, FastMath.ulp(base)));
                 
                 // Test case where numbers differ by exactly 2 ULPs - should fail if mutant exists
                 double twoUlpDiff = base + 2 * Math.ulp(base);
                 assertFalse("Mutant detected: equals() with 2 ULPs difference should return false", 
                            MathUtils.equals(base, twoUlpDiff, FastMath.ulp(base)));
                 
                 // Test case where numbers differ by more than 2 ULPs
                 double threeUlpDiff = base + 3 * Math.ulp(base);
                 assertFalse(MathUtils.equals(base, threeUlpDiff, FastMath.ulp(base)));
                 
                 // Test case where numbers are exactly equal
                 assertTrue(MathUtils.equals(base, base, FastMath.ulp(base)));
                 
                 // Test case where numbers differ by less than epsilon but more than 2 ULPs
                 double smallDiff = base + 0.5 * FastMath.ulp(base);
                 assertTrue(MathUtils.equals(base, smallDiff, FastMath.ulp(base)));
             }

 @Test
             public void testEqualsWithDefaultMaxUlps() {
                 // Create two doubles that are exactly 1 ULP apart
                 long bits1 = Double.doubleToLongBits(1.0);
                 long bits2 = bits1 + 1; // 1 ULP difference
                 
                 double d1 = Double.longBitsToDouble(bits1);
                 double d2 = Double.longBitsToDouble(bits2);
                 
                 // With the original maxUlps=1, these should NOT be equal
                 // With the mutated maxUlps=2, these would be equal
                 assertFalse("Values differing by 1 ULP should not be equal with maxUlps=1", 
                            MathUtils.equals(d1, d2));
                 
                 // Verify that with explicit maxUlps=1 we get false (original behavior)
                 assertFalse(MathUtils.equals(d1, d2, 1));
                 
                 // Verify that with maxUlps=2 we get true (showing what the mutant would do)
                 assertTrue(MathUtils.equals(d1, d2, 2));
             }

 @Test
         public void testEqualsDoubleArrayWithTwoULPsDifference() {
             // Create two double values that are exactly 2 ULPs apart
             double base = 1.0;
             double twoUlpsDiff = base + 2 * Math.ulp(base);
             
             // Create arrays containing these values
             double[] arr1 = {base};
             double[] arr2 = {twoUlpsDiff};
             
             // With the original code (maxUlps=1), these should NOT be equal
             // With the mutant (maxUlps=2), these would be considered equal
             assertFalse("Arrays with 2 ULP difference should not be equal", 
                        MathUtils.equals(arr1, arr2));
             
             // Also test with null cases to maintain full coverage
             assertTrue("Both null arrays should be equal", 
                       MathUtils.equals(null, null));
             assertFalse("One null array should not equal non-null", 
                        MathUtils.equals(null, arr1));
             assertFalse("Non-null array should not equal null", 
                        MathUtils.equals(arr1, null));
             
             // Test with arrays of different lengths
             double[] longerArr = {base, base};
             assertFalse("Arrays of different lengths should not be equal", 
                        MathUtils.equals(arr1, longerArr));
         }

 @Test
            public void testEqualsShouldReturnExactlyWhatThreeArgEqualsReturns() {
                // Test case where equals(x,y,1) returns true
                double x1 = 1.0;
                double y1 = 1.0000000000000002; // Within 1 ULP of 1.0
                assertTrue(MathUtils.equals(x1, y1));
                
                // Test case where equals(x,y,1) returns false
                double x2 = 1.0;
                double y2 = 1.0000000000000004; // Beyond 1 ULP of 1.0
                assertFalse(MathUtils.equals(x2, y2));
                
                // Test with NaN values (should return false)
                double nan1 = Double.NaN;
                double nan2 = Double.NaN;
                assertFalse(MathUtils.equals(nan1, nan2));
                
                // Test with infinity values
                double posInf = Double.POSITIVE_INFINITY;
                double negInf = Double.NEGATIVE_INFINITY;
                assertFalse(MathUtils.equals(posInf, negInf));
                assertTrue(MathUtils.equals(posInf, posInf));
            }

 @Test
        public void testEqualsWithEpsilonTolerance() {
            // Setup test values where:
            // - equals(x, y, 1) will return false
            // - FastMath.abs(y - x) <= eps will return true
            double x = 1.0000001;
            double y = 1.0000002;
            double eps = 0.0000002; // Larger than the actual difference
            
            // The original method should return true because the difference is within epsilon,
            // even though they're not equal within 1 ULP
            boolean expected = true;
            
            // Call the method
            boolean actual = MathUtils.equals(x, y, eps);
            
            // Assert the result
            assertEquals("Values within epsilon tolerance should be considered equal", 
                        expected, actual);
        }

 @Test
        public void testEqualsWithMaxUlpsOneShouldReturnDirectResult() {
            // Test with equal values
            assertTrue(MathUtils.equals(1.0, 1.0, 1));
            
            // Test with values differing by exactly 1 ULP
            double a = 1.0;
            double b = Double.longBitsToDouble(Double.doubleToLongBits(a) + 1);
            assertTrue(MathUtils.equals(a, b, 1));
            
            // Test with values differing by more than 1 ULP
            double c = Double.longBitsToDouble(Double.doubleToLongBits(a) + 2);
            assertFalse(MathUtils.equals(a, c, 1));
            
            // Test with NaN values (should return false regardless of maxUlps)
            assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 1));
            
            // Test with one NaN value
            assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
            
            // Test with very small numbers
            double small1 = Double.MIN_VALUE;
            double small2 = Double.longBitsToDouble(Double.doubleToLongBits(small1) + 1);
            assertTrue(MathUtils.equals(small1, small2, 1));
            
            // Test with very large numbers
            double large1 = Double.MAX_VALUE;
            double large2 = Double.longBitsToDouble(Double.doubleToLongBits(large1) - 1);
            assertTrue(MathUtils.equals(large1, large2, 1));
        }

 @Test
            public void testEqualsDoubleArraysDetectsMutant() {
                // Test case to detect the "&& true" mutant
                double[] arr1 = {1.0, 2.0, Double.NaN};
                double[] arr2 = {1.0, 2.0, 3.0};
                
                // This should return false since the arrays differ at index 2
                // The mutant's "&& true" doesn't change the logic but we can verify
                // the exact return value is false
                assertFalse(MathUtils.equals(arr1, arr2));
                
                // Additional test cases to ensure thorough coverage
                double[] arr3 = {1.0, 2.0, 3.0};
                double[] arr4 = {1.0, 2.0, 3.0};
                assertTrue(MathUtils.equals(arr3, arr4));
                
                double[] arr5 = {Double.NaN};
                double[] arr6 = {Double.NaN};
                // Depending on equals() implementation for NaN, this might be true or false
                // But the important part is that the mutant doesn't affect the result
                assertEquals(MathUtils.equals(new double[0], new double[0]), 
                             MathUtils.equals(new double[0], new double[0]));
                
                // Test with null inputs
                assertTrue(MathUtils.equals(null, null));
                assertFalse(MathUtils.equals(new double[]{1.0}, null));
                assertFalse(MathUtils.equals(null, new double[]{1.0}));
                
                // Test with different length arrays
                assertFalse(MathUtils.equals(new double[]{1.0}, new double[]{1.0, 2.0}));
            }

 @Test
           public void testEqualsWithOneUlps() {
               // Test equal values
               assertTrue(MathUtils.equals(1.0, 1.0));
               
               // Test values within 1 ULP
               double a = 1.0;
               double b = a + Math.ulp(a); // next representable number
               assertTrue(MathUtils.equals(a, b));
               
               // Test values exactly at 1 ULP difference
               double c = b + Math.ulp(b);
               assertFalse(MathUtils.equals(a, c));
               
               // Test NaN cases
               assertFalse(MathUtils.equals(Double.NaN, Double.NaN));
               
               // Test infinity cases
               assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
               assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY));
               
               // Test very small numbers
               double small1 = Double.MIN_VALUE;
               double small2 = small1 + Math.ulp(small1);
               assertTrue(MathUtils.equals(small1, small2));
               
               // Test very large numbers
               double large1 = Double.MAX_VALUE;
               double large2 = large1 - Math.ulp(large1);
               assertTrue(MathUtils.equals(large1, large2));
           }

 @Test
           public void testEqualsWithEpsilonTolerance1() {
               // Test case where values are not equal within 1 ULP but within epsilon tolerance
               double x = 1.0000001;
               double y = 1.0000002;
               double eps = 0.0000002; // Larger than the difference between x and y
               
               // Original should return true because |y-x| <= eps, even though not equal within 1 ULP
               // Mutant will return false because it ignores the epsilon check
               assertTrue(MathUtils.equals(x, y, eps));
               
               // Additional test case with values exactly at epsilon difference
               double a = 2.0;
               double b = 2.0 + eps;
               assertTrue(MathUtils.equals(a, b, eps));
               
               // Edge case: difference exactly equals epsilon
               double c = 3.0;
               double d = 3.0 + eps;
               assertTrue(MathUtils.equals(c, d, eps));
           }

 @Test
       public void testEqualsWithMaxUlpsShouldReturnFalseForUnequalValues() {
           // Test with values that differ by more than 1 ULP
           double x = 1.0;
           double y = 1.0 + 3 * Math.ulp(1.0); // Difference of 3 ULPs
           
           // The original method should return false since difference > 1 ULP
           // The mutant version would still return false, but we're testing the exact behavior
           boolean result = MathUtils.equals(x, y, 1);
           
           assertFalse("Values differing by more than 1 ULP should not be equal", result);
           
           // Additional test case with NaN values which should always return false
           double nan = Double.NaN;
           assertFalse("NaN values should never be equal", MathUtils.equals(nan, nan, 1));
           assertFalse("NaN and regular number should never be equal", MathUtils.equals(nan, x, 1));
           
           // Test with values that are exactly 1 ULP apart
           double z = x + Math.ulp(x);
           assertFalse("Values exactly 1 ULP apart should not be equal with maxUlps=1", 
                      MathUtils.equals(x, z, 1));
       }

 @Test
      public void testEqualsDoubleArrayWithMutantDetection() {
          // Test case where arrays should be equal
          double[] arr1 = {1.0, 2.0, 3.0};
          double[] arr2 = {1.0, 2.0, 3.0};
          assertTrue(MathUtils.equals(arr1, arr2));
          
          // Test case where arrays should not be equal
          double[] arr3 = {1.0, 2.0, 3.0};
          double[] arr4 = {1.0, 2.0, 4.0};
          assertFalse(MathUtils.equals(arr3, arr4));
          
          // Test case with null inputs
          double[] arr5 = {1.0, 2.0, 3.0};
          assertFalse(MathUtils.equals(arr5, null));
          assertFalse(MathUtils.equals(null, arr5));
          assertTrue(MathUtils.equals(null, null));
          
          // Test case with different length arrays
          double[] arr6 = {1.0, 2.0};
          double[] arr7 = {1.0, 2.0, 3.0};
          assertFalse(MathUtils.equals(arr6, arr7));
          
          // Additional test to specifically catch the || false mutant
          // This verifies the exact return value matches expectations
          double[] arr8 = {Double.NaN};
          double[] arr9 = {Double.NaN};
          boolean result = MathUtils.equals(arr8, arr9);
          if (result != MathUtils.equals(arr8[0], arr9[0])) {
              fail("Mutant detected: equals() result doesn't match direct comparison");
          }
      }

 @Test
      public void testCosh() {
          // Test x = 0 (cosh(0) should be 1)
          assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
          
          // Test positive value (cosh(1) ≈ 1.543080634815244)
          assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-15);
          
          // Test negative value (cosh should be even function)
          assertEquals(1.543080634815244, MathUtils.cosh(-1.0), 1e-15);
          
          // Test larger value (cosh(2) ≈ 3.7621956910836314)
          assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 1e-15);
          
          // Test the mutant would fail here since:
          // (exp(1)-exp(-1))/2 ≈ 1.1752011936438014 ≠ 1.543080634815244
      }

 @Test
      public void testCosh1() {
          // Test at x=0 where cosh(0)=1 and sinh(0)=0
          double result1 = MathUtils.cosh(0.0);
          assertEquals("cosh(0) should be 1", 1.0, result1, 0.000001);
          
          // Test at x=1 where cosh(1)≈1.54308 and sinh(1)≈1.17520
          double result2 = MathUtils.cosh(1.0);
          assertEquals("cosh(1) should be approximately 1.54308", 
                       (Math.exp(1) + Math.exp(-1))/2.0, result2, 0.000001);
          
          // Test at x=-1 (cosh is even function, should be same as x=1)
          double result3 = MathUtils.cosh(-1.0);
          assertEquals("cosh(-1) should equal cosh(1)", result2, result3, 0.000001);
          
          // Test at x=2 where difference between cosh and sinh is larger
          double result4 = MathUtils.cosh(2.0);
          assertEquals("cosh(2) should be approximately 3.7622", 
                       (Math.exp(2) + Math.exp(-2))/2.0, result4, 0.000001);
      }

 @Test
      public void testCosh2() {
          // Test known value at 0 (cosh(0) should be 1)
          assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
          
          // Test that cosh is an even function (cosh(x) == cosh(-x))
          double x = 1.5;
          assertEquals(MathUtils.cosh(x), MathUtils.cosh(-x), 1e-15);
          
          // Test with positive value
          double expected = (Math.exp(2.0) + Math.exp(-2.0)) / 2.0;
          assertEquals(expected, MathUtils.cosh(2.0), 1e-15);
          
          // Test with negative value (should be same as positive)
          assertEquals(expected, MathUtils.cosh(-2.0), 1e-15);
      }

 @Test
      public void testCosh3() {
          // Test zero - should be 1.0
          assertEquals(1.0, MathUtils.cosh(0.0), MathUtils.EPSILON);
          
          // Test positive value - should be >1
          double posValue = 1.0;
          double coshPos = MathUtils.cosh(posValue);
          assertTrue(coshPos > 1.0);
          
          // Test negative value - should be same as positive
          assertEquals(coshPos, MathUtils.cosh(-posValue), MathUtils.EPSILON);
          
          // Test large value - should be large positive
          double largeValue = 10.0;
          double coshLarge = MathUtils.cosh(largeValue);
          assertTrue(coshLarge > 10000); // exp(10) is ~22026.465
          
          // Test another positive value where mutant would give negative result
          double testValue = 0.5;
          double expected = (Math.exp(testValue) + Math.exp(-testValue)) / 2.0;
          assertEquals(expected, MathUtils.cosh(testValue), MathUtils.EPSILON);
      }

 @Test
     public void testCosh4() {
         // Test with positive number
         double x = 1.0;
         double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
         assertEquals("Cosh of positive number", expected, MathUtils.cosh(x), 1e-10);
         
         // Test with negative number (cosh is even function)
         x = -1.0;
         expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
         assertEquals("Cosh of negative number", expected, MathUtils.cosh(x), 1e-10);
         
         // Test with zero (boundary case)
         x = 0.0;
         expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
         assertEquals("Cosh of zero", expected, MathUtils.cosh(x), 1e-10);
         
         // Test with larger number
         x = 5.0;
         expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
         assertEquals("Cosh of larger number", expected, MathUtils.cosh(x), 1e-10);
     }

 @Test
     public void testCosh5() {
         // Test with 0 - cosh(0) should be 1.0
         assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
         
         // Test with 1 - known value of cosh(1)
         double expectedCosh1 = (Math.exp(1) + Math.exp(-1)) / 2.0;
         assertEquals(expectedCosh1, MathUtils.cosh(1.0), 1e-15);
         
         // Test with -1 - should be same as cosh(1) since cosh is even function
         assertEquals(expectedCosh1, MathUtils.cosh(-1.0), 1e-15);
         
         // Test with a larger number (5.0)
         double expectedCosh5 = (Math.exp(5) + Math.exp(-5)) / 2.0;
         assertEquals(expectedCosh5, MathUtils.cosh(5.0), 1e-10);
         
         // Test with a small number (0.1)
         double expectedCosh01 = (Math.exp(0.1) + Math.exp(-0.1)) / 2.0;
         assertEquals(expectedCosh01, MathUtils.cosh(0.1), 1e-15);
     }

 @Test
     public void testEqualsDoubleWithUlps() {
         // Test equal values within ulps tolerance
         assertTrue(MathUtils.equals(1.0, 1.0, 1));
         assertTrue(MathUtils.equals(1.0, 1.0 + Math.ulp(1.0), 1));
         
         // Test values just outside ulps tolerance
         assertFalse(MathUtils.equals(1.0, 1.0 + 2 * Math.ulp(1.0), 1));
         
         // Test with NaN values
         assertFalse(MathUtils.equals(Double.NaN, 1.0, 1));
         assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
         assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 1));
         
         // Test with negative values
         assertTrue(MathUtils.equals(-1.0, -1.0, 1));
         assertTrue(MathUtils.equals(-1.0, -1.0 - Math.ulp(1.0), 1));
         
         // Test edge cases around zero
         assertTrue(MathUtils.equals(0.0, 0.0, 1));
         assertTrue(MathUtils.equals(0.0, Math.ulp(0.0), 1));
         assertFalse(MathUtils.equals(0.0, 2 * Math.ulp(0.0), 1));
         
         // Test with very large values
         double large = Double.MAX_VALUE;
         assertTrue(MathUtils.equals(large, large, 1));
         assertFalse(MathUtils.equals(large, large - 2 * Math.ulp(large), 1));
         
         // Test with very small values
         double small = Double.MIN_VALUE;
         assertTrue(MathUtils.equals(small, small, 1));
         assertTrue(MathUtils.equals(small, small + Math.ulp(small), 1));
     }

 @Test
     public void testEqualsDoubleArray() {
         // Test null cases
         assertTrue(MathUtils.equals(null, null));
         assertFalse(MathUtils.equals(new double[]{1.0}, null));
         assertFalse(MathUtils.equals(null, new double[]{1.0}));
         
         // Test different length arrays
         assertFalse(MathUtils.equals(new double[]{1.0}, new double[]{1.0, 2.0}));
         
         // Test empty arrays
         assertTrue(MathUtils.equals(new double[]{}, new double[]{}));
         
         // Test equal arrays
         assertTrue(MathUtils.equals(new double[]{1.0, 2.0}, new double[]{1.0, 2.0}));
         
         // Test unequal arrays
         assertFalse(MathUtils.equals(new double[]{1.0, 2.0}, new double[]{1.0, 3.0}));
         
         // Test with NaN values
         assertTrue(MathUtils.equals(new double[]{Double.NaN}, new double[]{Double.NaN}));
         
         // Test with different NaN representations (if equals() handles them)
         assertTrue(MathUtils.equals(
             new double[]{Double.longBitsToDouble(0x7ff8000000000000L)}, 
             new double[]{Double.longBitsToDouble(0x7ff0000000000001L)}));
         
         // Test with very close values (within epsilon)
         assertTrue(MathUtils.equals(
             new double[]{1.0000001}, 
             new double[]{1.0000002}));
             
         // Test with values just beyond epsilon
         assertFalse(MathUtils.equals(
             new double[]{1.001}, 
             new double[]{1.002}));
     }

}
