package gentest.org.apache.commons.math3.random.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.random.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.FastMath;
 
public class BitsStreamGeneratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                   public void testSetSeed_Int_ShouldStoreSeedValue() {
                                                                                       int testSeed = 12345;
                                                                                       BitsStreamGenerator generator = new Well19937c(); // or any concrete implementation
                                                                                       
                                                                                       // Test the setSeed call
                                                                                       generator.setSeed(testSeed);
                                                                                       
                                                                                       // Verify by checking subsequent random numbers are deterministic
                                                                                       int firstRandom = generator.nextInt();
                                                                                       generator.setSeed(testSeed);
                                                                                       assertEquals(firstRandom, generator.nextInt());
                                                                                   }

 @Test
                                                                                   public void testSetSeed_IntArrayNull_ShouldThrowException() {
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {
                                                                                               if (seed == null) {
                                                                                                   throw new NullPointerException();
                                                                                               }
                                                                                           }
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                           
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0;
                                                                                           }
                                                                                       };
                                                                                       
                                                                                       try {
                                                                                           generator.setSeed((int[]) null);
                                                                                           fail("Expected NullPointerException");
                                                                                       } catch (NullPointerException e) {
                                                                                           // Expected exception
                                                                                       }
                                                                                   }

 @Test
                                                                                   public void testSetSeed_IntArrayEmpty_ShouldStoreEmptyArray() {
                                                                                       // Create mock generator
                                                                                       BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                       
                                                                                       // Test data
                                                                                       int[] testSeed = {};
                                                                                       
                                                                                       // Call method under test
                                                                                       generator.setSeed(testSeed);
                                                                                       
                                                                                       // Verify the seed was stored correctly
                                                                                       verify(generator).setSeed(testSeed);
                                                                                       
                                                                                       // If getArraySeed() is part of the interface, we would also verify it
                                                                                       // But since it's not in the provided methods, we'll just verify setSeed was called
                                                                                   }

 @Test
                                                                                   public void testSetSeed_Long_ShouldStoreSeedValue() {
                                                                                       long testSeed = 1234567890L;
                                                                                       // Create a mock implementation
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           private long seed;
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(long seed) {
                                                                                               this.seed = seed;
                                                                                           }
                                                                                           
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0;
                                                                                           }
                                                                                       };
                                                                                       
                                                                                       generator.setSeed(testSeed);
                                                                                       // Verify the seed was set by checking if next operations work
                                                                                       // (This is a weaker assertion since we can't directly access the seed)
                                                                                       int firstInt = generator.nextInt();
                                                                                       generator.setSeed(testSeed);
                                                                                       int secondInt = generator.nextInt();
                                                                                       assertEquals(firstInt, secondInt);
                                                                                   }

 @Test
                                                                                   public void testSetSeed_LongBoundaryValues() throws Exception {
                                                                                       // Create instance of concrete implementation (using MersenneTwister as example)
                                                                                       BitsStreamGenerator generator = new MersenneTwister();
                                                                                       
                                                                                       // Test minimum long value
                                                                                       generator.setSeed(Long.MIN_VALUE);
                                                                                       // Verify seed was set by checking next generated value isn't null
                                                                                       assertNotNull(generator.nextLong());
                                                                                       
                                                                                       // Test maximum long value
                                                                                       generator.setSeed(Long.MAX_VALUE);
                                                                                       assertNotNull(generator.nextLong());
                                                                                       
                                                                                       // Test zero
                                                                                       generator.setSeed(0L);
                                                                                       assertNotNull(generator.nextLong());
                                                                                       
                                                                                       // Alternative verification using reflection if needed
                                                                                       Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       nextGaussianField.setAccessible(true);
                                                                                       double nextGaussian = (Double) nextGaussianField.get(generator);
                                                                                       assertTrue(Double.isNaN(nextGaussian)); // Verify clear state
                                                                                   }

 @Test
                                                                                   public void testSetSeed_ShouldNotAffectNextGaussian() throws Exception {
                                                                                       // Create a concrete subclass instance since BitsStreamGenerator is abstract
                                                                                       BitsStreamGenerator generator = new MersenneTwister();
                                                                                       
                                                                                       // Use reflection to access private nextGaussian field
                                                                                       Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       nextGaussianField.setAccessible(true);
                                                                                       
                                                                                       // Initial state
                                                                                       assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                       
                                                                                       // After setting seed with different types
                                                                                       generator.setSeed(42);
                                                                                       assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                       
                                                                                       generator.setSeed(new int[]{1, 2, 3});
                                                                                       assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                       
                                                                                       generator.setSeed(123L);
                                                                                       assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                   }

 @Test
                                                                                   public void testSetSeedWithInt() {
                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                       BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           public void setSeed(int seed) {
                                                                                               // Empty implementation for testing
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {
                                                                                               // Empty implementation for testing
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(long seed) {
                                                                                               // Empty implementation for testing
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0; // Empty implementation for testing
                                                                                           }
                                                                                       });
                                                                                       
                                                                                       // Test normal case
                                                                                       generator.setSeed(12345);
                                                                                       verify(generator).setSeed(12345);
                                                                                       
                                                                                       // Test edge case - minimum int value
                                                                                       generator.setSeed(Integer.MIN_VALUE);
                                                                                       verify(generator).setSeed(Integer.MIN_VALUE);
                                                                                       
                                                                                       // Test edge case - maximum int value
                                                                                       generator.setSeed(Integer.MAX_VALUE);
                                                                                       verify(generator).setSeed(Integer.MAX_VALUE);
                                                                                   }

 @Test
                                                                                   public void testSetSeedWithLong() {
                                                                                       // Create a simple concrete implementation of BitsStreamGenerator for testing
                                                                                       BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                           
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0;
                                                                                           }
                                                                                       });
                                                                                       
                                                                                       // Test normal case
                                                                                       generator.setSeed(123456789L);
                                                                                       verify(generator).setSeed(123456789L);
                                                                                       
                                                                                       // Test edge case - minimum long value
                                                                                       generator.setSeed(Long.MIN_VALUE);
                                                                                       verify(generator).setSeed(Long.MIN_VALUE);
                                                                                       
                                                                                       // Test edge case - maximum long value
                                                                                       generator.setSeed(Long.MAX_VALUE);
                                                                                       verify(generator).setSeed(Long.MAX_VALUE);
                                                                                   }

 @Test
                                                                                   public void testSetSeed_Int() {
                                                                                       int seed = 12345;
                                                                                       BitsStreamGenerator generator = new MersenneTwister(); // or other concrete implementation
                                                                                       generator.setSeed(seed);
                                                                                       // Note: This assumes the concrete implementation stores the seed
                                                                                       // If getLastIntSeed() is not available, we might need to test behavior instead
                                                                                       assertEquals(seed, generator.nextInt()); // or other verification of seeded behavior
                                                                                   }

 @Test
                                                                                   public void testSetSeed_IntArrayNull() {
                                                                                       // Create a concrete subclass of BitsStreamGenerator for testing
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {
                                                                                               if (seed == null) {
                                                                                                   throw new NullPointerException();
                                                                                               }
                                                                                           }
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                           
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0;
                                                                                           }
                                                                                       };
                                                                                       
                                                                                       // Set up exception expectation
                                                                                       ExpectedException thrown = ExpectedException.none();
                                                                                       thrown.expect(NullPointerException.class);
                                                                                       generator.setSeed((int[])null);
                                                                                   }

 @Test
                                                                                   public void testSetSeed_IntArrayEmpty() throws Exception {
                                                                                       int[] seed = {};
                                                                                       BitsStreamGenerator generator = new MersenneTwister();
                                                                                       generator.setSeed(seed);
                                                                                       
                                                                                       // Use reflection to verify internal seed state
                                                                                       Field seedField = generator.getClass().getDeclaredField("seed");
                                                                                       seedField.setAccessible(true);
                                                                                       int[] actualSeed = (int[]) seedField.get(generator);
                                                                                       assertArrayEquals(seed, actualSeed);
                                                                                   }

 @Test
                                                                                   public void testSetSeed_Long() {
                                                                                       long seed = 123456789L;
                                                                                       BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                       
                                                                                       generator.setSeed(seed);
                                                                                       
                                                                                       verify(generator).setSeed(seed);
                                                                                   }

 @Test
                                                                                   public void testSetSeed_LongBoundaryValues1() {
                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                       BitsStreamGenerator generator = new MersenneTwister();
                                                                                       
                                                                                       // Test Long.MIN_VALUE
                                                                                       generator.setSeed(Long.MIN_VALUE);
                                                                                       long firstValue = generator.nextLong();
                                                                                       generator.setSeed(Long.MIN_VALUE);
                                                                                       assertEquals(firstValue, generator.nextLong());
                                                                                       
                                                                                       // Test Long.MAX_VALUE
                                                                                       generator.setSeed(Long.MAX_VALUE);
                                                                                       long secondValue = generator.nextLong();
                                                                                       generator.setSeed(Long.MAX_VALUE);
                                                                                       assertEquals(secondValue, generator.nextLong());
                                                                                       
                                                                                       // Test 0L
                                                                                       generator.setSeed(0L);
                                                                                       long thirdValue = generator.nextLong();
                                                                                       generator.setSeed(0L);
                                                                                       assertEquals(thirdValue, generator.nextLong());
                                                                                   }

 @Test
                                                                                   public void testNextGaussianInitialState() throws Exception {
                                                                                       // Create a concrete subclass instance since BitsStreamGenerator is abstract
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                           @Override
                                                                                           protected int next(int bits) { return 0; }
                                                                                       };
                                                                                       
                                                                                       // Use reflection to access private nextGaussian field
                                                                                       Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       nextGaussianField.setAccessible(true);
                                                                                       double nextGaussianValue = (Double) nextGaussianField.get(generator);
                                                                                       
                                                                                       // Verify that nextGaussian is initialized to NaN in constructor
                                                                                       assertTrue(Double.isNaN(nextGaussianValue));
                                                                                   }

 @Test
                                                                                   public void testConstructorInitializesNextGaussian() throws Exception {
                                                                                       BitsStreamGenerator newGenerator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) { return 0; }
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       // Use reflection to access private field
                                                                                       Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       nextGaussianField.setAccessible(true);
                                                                                       double nextGaussianValue = (Double) nextGaussianField.get(newGenerator);
                                                                                       
                                                                                       assertTrue(Double.isNaN(nextGaussianValue));
                                                                                   }

 @Test
                                                                                   public void testNextBoolean() {
                                                                                       // Create a mock or concrete implementation of BitsStreamGenerator
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           private int callCount = 0;
                                                                                           
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               // First call returns 0x000000FF (will produce true)
                                                                                               // Second call returns 0x0000FF00 (will also produce true)
                                                                                               return callCount++ == 0 ? 0x000000FF : 0x0000FF00;
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                   
                                                                                       // Our mock implementation returns 0x000000FF first, which should produce true
                                                                                       assertTrue(generator.nextBoolean());
                                                                                       
                                                                                       // Second call returns 0x0000FF00, which should also produce true
                                                                                       assertTrue(generator.nextBoolean());
                                                                                   }

 @Test
                                                                                   public void testNextBytes() {
                                                                                       // Create a mock of BitsStreamGenerator
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           private int callCount = 0;
                                                                                           
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               // Mock implementation based on test comments
                                                                                               switch (callCount++) {
                                                                                                   case 0: return 0x000000FF;
                                                                                                   case 1: return 0x0000FF00;
                                                                                                   case 2: return 0x00FF0000;
                                                                                                   case 3: return 0xFF000000;
                                                                                                   default: return 0;
                                                                                               }
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       byte[] bytes = new byte[4];
                                                                                       generator.nextBytes(bytes);
                                                                                       
                                                                                       // Based on our mock implementation:
                                                                                       // First call to next(8) returns 0x000000FF -> (byte)0xFF
                                                                                       // Second call returns 0x0000FF00 -> (byte)0x00
                                                                                       // Third call returns 0x00FF0000 -> (byte)0x00
                                                                                       // Fourth call returns 0xFF000000 -> (byte)0x00
                                                                                       assertEquals((byte)0xFF, bytes[0]);
                                                                                       assertEquals((byte)0x00, bytes[1]);
                                                                                       assertEquals((byte)0x00, bytes[2]);
                                                                                       assertEquals((byte)0x00, bytes[3]);
                                                                                   }

 @Test
                                                                                   public void testNextFloat() {
                                                                                       // Create a concrete instance of BitsStreamGenerator (using anonymous class)
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0x000000FF; // Our mock implementation returns 0x000000FF first
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       // The calculation is: 0x000000FF / ((float)(1 << 24))
                                                                                       float expected = 0x000000FF / ((float)(1 << 24));
                                                                                       assertEquals(expected, generator.nextFloat(), 0.000000001);
                                                                                   }

 @Test
                                                                                   public void testNextGaussian() {
                                                                                       // Create a concrete instance of the generator (using a stub class since BitsStreamGenerator is abstract)
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0;
                                                                                           }
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       // First call should return NaN since we haven't generated a Gaussian yet
                                                                                       assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                       
                                                                                       // After first call, it should generate a new pair
                                                                                       double first = generator.nextGaussian();
                                                                                       assertFalse(Double.isNaN(first));
                                                                                       assertFalse(Double.isNaN(generator.nextGaussian()));
                                                                                       
                                                                                       // The next call should use the cached value
                                                                                       double cached = generator.nextGaussian();
                                                                                       assertEquals(cached, generator.nextGaussian(), 0.0);
                                                                                   }

 @Test
                                                                                   public void testNextInt() {
                                                                                       // Create a mock BitsStreamGenerator
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               // Our mock implementation returns 0x000000FF first
                                                                                               return 0x000000FF;
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       assertEquals(0x000000FF, generator.nextInt());
                                                                                   }

 @Test
                                                                                   public void testNextIntWithBoundInvalid() {
                                                                                       org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                       org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.MersenneTwister();
                                                                                       
                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                       thrown.expectMessage("bound must be positive");
                                                                                       generator.nextInt(-1);
                                                                                   }

 @Test
                                                                                   public void testClear() throws Exception {
                                                                                       // Create a concrete instance of BitsStreamGenerator (using a mock or anonymous class)
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0;
                                                                                           }
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       // Use reflection to access the private nextGaussian field
                                                                                       Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       nextGaussianField.setAccessible(true);
                                                                                       
                                                                                       // Set a value
                                                                                       nextGaussianField.set(generator, 1.0);
                                                                                       
                                                                                       // Call clear
                                                                                       generator.clear();
                                                                                       
                                                                                       // Verify the value was reset to NaN
                                                                                       assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                   }

 @Test
                                                                                   public void testNextBytes_EmptyArray() {
                                                                                       // Create a concrete implementation of BitsStreamGenerator for testing
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0; // Not used in this test
                                                                                           }
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       byte[] bytes = new byte[0];
                                                                                       generator.nextBytes(bytes);
                                                                                       // Should not throw any exception
                                                                                       assertEquals(0, bytes.length);
                                                                                   }

 @Test
                                                                                   public void testNextBytes_SingleByte() {
                                                                                       // Create an anonymous implementation of BitsStreamGenerator
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               // Return fixed value 0x78 for testing
                                                                                               return 0x78;
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       byte[] bytes = new byte[1];
                                                                                       generator.nextBytes(bytes);
                                                                                       // Should take first byte from the random value (0x78)
                                                                                       assertEquals((byte)0x78, bytes[0]);
                                                                                   }

 @Test
                                                                                   public void testNextBytes_FourBytes() {
                                                                                       // Create a test implementation of BitsStreamGenerator
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               // Return a fixed value for testing (0x12345678)
                                                                                               return 0x12345678;
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       byte[] bytes = new byte[4];
                                                                                       generator.nextBytes(bytes);
                                                                                       // Should fill all bytes from the random value (0x12345678)
                                                                                       assertArrayEquals(new byte[]{(byte)0x78, (byte)0x56, (byte)0x34, (byte)0x12}, bytes);
                                                                                   }

 @Test
                                                                                   public void testNextBytes_FiveBytes() {
                                                                                       // Create a mock or stub of BitsStreamGenerator that returns predictable values
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           private int callCount = 0;
                                                                                           
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               // First call returns 0x12345678, second call returns 0x78
                                                                                               return callCount++ == 0 ? 0x12345678 : 0x78;
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       byte[] bytes = new byte[5];
                                                                                       generator.nextBytes(bytes);
                                                                                       // First 4 bytes from first random value (0x12345678)
                                                                                       // 5th byte from next random value (0x78 again)
                                                                                       assertArrayEquals(new byte[]{
                                                                                           (byte)0x78, (byte)0x56, (byte)0x34, (byte)0x12, 
                                                                                           (byte)0x78}, bytes);
                                                                                   }

 @Test
                                                                                   public void testNextBytes_LargeArray() {
                                                                                       // Create a test instance of BitsStreamGenerator
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               // Return a fixed pattern 0x12345678
                                                                                               return 0x12345678;
                                                                                           }
                                                                                   
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       
                                                                                       byte[] bytes = new byte[100];
                                                                                       generator.nextBytes(bytes);
                                                                                       // Verify pattern repeats every 4 bytes
                                                                                       for (int i = 0; i < 100; i += 4) {
                                                                                           int remaining = Math.min(4, 100 - i);
                                                                                           if (remaining >= 1) assertEquals((byte)0x78, bytes[i]);
                                                                                           if (remaining >= 2) assertEquals((byte)0x56, bytes[i+1]);
                                                                                           if (remaining >= 3) assertEquals((byte)0x34, bytes[i+2]);
                                                                                           if (remaining >= 4) assertEquals((byte)0x12, bytes[i+3]);
                                                                                       }
                                                                                   }

 @Test(expected = NullPointerException.class)
                                                                                   public void testNextBytes_NullArray() {
                                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                           @Override
                                                                                           protected int next(int bits) {
                                                                                               return 0;
                                                                                           }
                                                                                           @Override
                                                                                           public void setSeed(int seed) {}
                                                                                           @Override
                                                                                           public void setSeed(int[] seed) {}
                                                                                           @Override
                                                                                           public void setSeed(long seed) {}
                                                                                       };
                                                                                       generator.nextBytes(null);
                                                                                   }

 @Test
                                                                               public void testNextGaussian_FirstCallGeneratesNewPair() {
                                                                                   // Create a mock BitsStreamGenerator
                                                                                   BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                   // Mock nextDouble to return known values (0.5 for both x and y)
                                                                                   BitsStreamGenerator spyGenerator = spy(generator);
                                                                                   when(spyGenerator.nextDouble()).thenReturn(0.5);
                                                                                   
                                                                                   double result = spyGenerator.nextGaussian();
                                                                                   
                                                                                   // Verify the calculations:
                                                                                   // alpha = 2 * PI * 0.5 = PI
                                                                                   // r = sqrt(-2 * ln(0.5)) ≈ 1.1774100225154747
                                                                                   // random = r * cos(PI) ≈ 1.1774100225154747 * -1 ≈ -1.1774100225154747
                                                                                   assertEquals(-1.1774100225154747, result, 1e-15);
                                                                                   
                                                                                   // Verify nextGaussian was set to the second value of the pair
                                                                                   // nextGaussian = r * sin(PI) ≈ 1.1774100225154747 * 0 = 0
                                                                                   // But we need to access the private field to verify - this is tricky without reflection
                                                                                   // Instead we can verify the next call behavior
                                                                               }

 @Test
                                                                               public void testNextGaussian_SecondCallUsesStoredValue() {
                                                                                   // Create a concrete instance of a generator (using MersenneTwister as an example)
                                                                                   BitsStreamGenerator generator = new MersenneTwister();
                                                                                   
                                                                                   // First set nextGaussian to a known value
                                                                                   try {
                                                                                       java.lang.reflect.Field field = generator.getClass().getSuperclass().getDeclaredField("nextGaussian");
                                                                                       field.setAccessible(true);
                                                                                       field.set(generator, 2.5);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to set nextGaussian field");
                                                                                   }
                                                                                   
                                                                                   double result = generator.nextGaussian();
                                                                                   
                                                                                   assertEquals(2.5, result, 0.0);
                                                                                   
                                                                                   // Verify nextGaussian was reset to NaN
                                                                                   try {
                                                                                       java.lang.reflect.Field field = generator.getClass().getSuperclass().getDeclaredField("nextGaussian");
                                                                                       field.setAccessible(true);
                                                                                       assertTrue(Double.isNaN((Double)field.get(generator)));
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to verify nextGaussian field");
                                                                                   }
                                                                               }

 @Test
                                                                               public void testNextGaussian_SequenceOfCalls() {
                                                                                   // Create a concrete instance of BitsStreamGenerator
                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                       @Override
                                                                                       public void setSeed(int seed) {}
                                                                                       @Override
                                                                                       public void setSeed(int[] seed) {}
                                                                                       @Override
                                                                                       public void setSeed(long seed) {}
                                                                                       @Override
                                                                                       protected int next(int bits) { return 0; }
                                                                                   };
                                                                                   
                                                                                   // Mock nextDouble to return known values for two calls
                                                                                   BitsStreamGenerator spyGenerator = spy(generator);
                                                                                   when(spyGenerator.nextDouble())
                                                                                       .thenReturn(0.25)  // first x
                                                                                       .thenReturn(0.75); // first y
                                                                                   
                                                                                   // First call - generates new pair
                                                                                   double first = spyGenerator.nextGaussian();
                                                                                   
                                                                                   // Verify calculations:
                                                                                   // alpha = 2 * PI * 0.25 = PI/2
                                                                                   // r = sqrt(-2 * ln(0.75)) ≈ 0.7585276164398386
                                                                                   // first = r * cos(PI/2) ≈ 0.7585276164398386 * 0 = 0
                                                                                   assertEquals(0.0, first, 1e-15);
                                                                                   
                                                                                   // Second call - uses stored value
                                                                                   // nextGaussian should be r * sin(PI/2) ≈ 0.7585276164398386 * 1 ≈ 0.7585276164398386
                                                                                   double second = spyGenerator.nextGaussian();
                                                                                   assertEquals(0.7585276164398386, second, 1e-15);
                                                                                   
                                                                                   // Third call - generates new pair again
                                                                                   when(spyGenerator.nextDouble())
                                                                                       .thenReturn(0.1)  // second x
                                                                                       .thenReturn(0.9); // second y
                                                                                   
                                                                                   double third = spyGenerator.nextGaussian();
                                                                                   
                                                                                   // Verify calculations:
                                                                                   // alpha = 2 * PI * 0.1 ≈ 0.6283185307179586
                                                                                   // r = sqrt(-2 * ln(0.9)) ≈ 0.4590370185604505
                                                                                   // third = r * cos(alpha) ≈ 0.4590370185604505 * 0.8090169943749475 ≈ 0.3713689353593186
                                                                                   assertEquals(0.3713689353593186, third, 1e-15);
                                                                               }

 @Test
                                                                               public void testNextGaussian_WithExtremeValues() {
                                                                                   // Create a concrete instance of a BitsStreamGenerator (using MersenneTwister)
                                                                                   BitsStreamGenerator generator = new MersenneTwister();
                                                                                   BitsStreamGenerator spyGenerator = spy(generator);
                                                                                   
                                                                                   // Test with y very close to 0 (but not 0)
                                                                                   when(spyGenerator.nextDouble())
                                                                                       .thenReturn(0.5)  // x
                                                                                       .thenReturn(1e-300); // y (very small but > 0)
                                                                                   
                                                                                   double result = spyGenerator.nextGaussian();
                                                                                   
                                                                                   // r = sqrt(-2 * ln(1e-300)) ≈ sqrt(1381.5510557964296) ≈ 37.16814751236986
                                                                                   // result = r * cos(PI) ≈ -37.16814751236986
                                                                                   assertEquals(-37.16814751236986, result, 1e-10);
                                                                                   
                                                                                   // Test with y very close to 1 (but not 1)
                                                                                   when(spyGenerator.nextDouble())
                                                                                       .thenReturn(0.5)  // x
                                                                                       .thenReturn(1 - 1e-15); // y (very close to 1)
                                                                                   
                                                                                   result = spyGenerator.nextGaussian();
                                                                                   
                                                                                   // r = sqrt(-2 * ln(1 - 1e-15)) ≈ sqrt(2e-15) ≈ 4.47213595499958e-8
                                                                                   // result = r * cos(PI) ≈ -4.47213595499958e-8
                                                                                   assertEquals(-4.47213595499958e-8, result, 1e-20);
                                                                               }

 @Test
                                                                               public void testNextInt_ThrowsExceptionForNonPositiveInput() {
                                                                                   // Setup
                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                       @Override
                                                                                       protected int next(int bits) {
                                                                                           return 0;
                                                                                       }
                                                                                       @Override
                                                                                       public void setSeed(int seed) {}
                                                                                       @Override
                                                                                       public void setSeed(int[] seed) {}
                                                                                       @Override
                                                                                       public void setSeed(long seed) {}
                                                                                   };
                                                                                   
                                                                                   // Test for zero input
                                                                                   try {
                                                                                       generator.nextInt(0);
                                                                                       fail("Expected NotStrictlyPositiveException");
                                                                                   } catch (NotStrictlyPositiveException e) {
                                                                                       assertEquals(0, e.getArgument());
                                                                                   }
                                                                                   
                                                                                   // Test for negative input
                                                                                   try {
                                                                                       generator.nextInt(-5);
                                                                                       fail("Expected NotStrictlyPositiveException");
                                                                                   } catch (NotStrictlyPositiveException e) {
                                                                                       assertEquals(-5, e.getArgument());
                                                                                   }
                                                                               }

 @Test
                                                                               public void testClear_SetsNextGaussianToNaN() {
                                                                                   // Arrange - create a concrete generator instance and set nextGaussian to a non-NaN value first
                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                       @Override
                                                                                       public void setSeed(int seed) {}
                                                                                       @Override
                                                                                       public void setSeed(int[] seed) {}
                                                                                       @Override
                                                                                       public void setSeed(long seed) {}
                                                                                       @Override
                                                                                       protected int next(int bits) { return 0; }
                                                                                   };
                                                                                   
                                                                                   try {
                                                                                       // Using reflection to set the private field for testing
                                                                                       java.lang.reflect.Field field = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       field.setAccessible(true);
                                                                                       field.set(generator, 1.0); // Set to arbitrary non-NaN value
                                                                                       
                                                                                       // Act
                                                                                       generator.clear();
                                                                                       
                                                                                       // Assert
                                                                                       assertEquals(Double.NaN, field.getDouble(generator), 0.0);
                                                                                   } catch (Exception e) {
                                                                                       fail("Exception occurred during test: " + e.getMessage());
                                                                                   }
                                                                               }

 @Test
                                                                               public void testClear_WhenNextGaussianAlreadyNaN() {
                                                                                   // Arrange - nextGaussian is already NaN from constructor
                                                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                       @Override
                                                                                       public void setSeed(int seed) {}
                                                                                       @Override
                                                                                       public void setSeed(int[] seed) {}
                                                                                       @Override
                                                                                       public void setSeed(long seed) {}
                                                                                       @Override
                                                                                       protected int next(int bits) { return 0; }
                                                                                   };
                                                                                   
                                                                                   // Act
                                                                                   generator.clear();
                                                                                   
                                                                                   // Assert
                                                                                   try {
                                                                                       java.lang.reflect.Field field = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       field.setAccessible(true);
                                                                                       assertTrue(Double.isNaN(field.getDouble(generator)));
                                                                                   } catch (Exception e) {
                                                                                       fail("Exception occurred during test: " + e.getMessage());
                                                                                   }
                                                                               }

 @Test
                                                                               public void testClear_VerifyStateAfterMultipleCalls() {
                                                                                   // Arrange - create generator instance and set nextGaussian to a non-NaN value
                                                                                   BitsStreamGenerator generator = new Well19937c(); // Using concrete implementation
                                                                                   try {
                                                                                       java.lang.reflect.Field field = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                       field.setAccessible(true);
                                                                                       field.set(generator, 42.0);
                                                                                       
                                                                                       // Act - call clear multiple times
                                                                                       generator.clear();
                                                                                       generator.clear();
                                                                                       generator.clear();
                                                                                       
                                                                                       // Assert
                                                                                       assertTrue(Double.isNaN(field.getDouble(generator)));
                                                                                   } catch (Exception e) {
                                                                                       fail("Exception occurred during test: " + e.getMessage());
                                                                                   }
                                                                               }

 @Test
                                                                           public void testSetSeedWithIntArray() {
                                                                               // Create a concrete implementation for testing
                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                                   @Override
                                                                                   protected int next(int bits) { return 0; }
                                                                               }
                                                                               
                                                                               BitsStreamGenerator generator = spy(new TestBitsStreamGenerator());
                                                                               
                                                                               // Test normal case
                                                                               int[] seed1 = {1, 2, 3};
                                                                               generator.setSeed(seed1);
                                                                               verify(generator).setSeed(seed1);
                                                                               
                                                                               // Test empty array
                                                                               int[] emptySeed = {};
                                                                               generator.setSeed(emptySeed);
                                                                               verify(generator).setSeed(emptySeed);
                                                                               
                                                                               // Test single element array
                                                                               int[] singleSeed = {42};
                                                                               generator.setSeed(singleSeed);
                                                                               verify(generator).setSeed(singleSeed);
                                                                               
                                                                               // Test null array
                                                                               try {
                                                                                   generator.setSeed((int[])null);
                                                                                   fail("Expected NullPointerException");
                                                                               } catch (NullPointerException e) {
                                                                                   // expected
                                                                               }
                                                                           }

 @Test
                                                                           public void testConstructorInitializesNextGaussian1() throws Exception {
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                                   @Override
                                                                                   protected int next(int bits) { return 0; }
                                                                               };
                                                                               Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                               nextGaussianField.setAccessible(true);
                                                                               double nextGaussianValue = nextGaussianField.getDouble(generator);
                                                                               assertTrue(Double.isNaN(nextGaussianValue));
                                                                           }

 @Test
                                                                           public void testNextDouble() {
                                                                               // Create test subclass that exposes protected next() method
                                                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       if (bits == 26) {
                                                                                           return 0x000000FF;
                                                                                       } else if (bits == 27) {
                                                                                           return 0x0000FF00;
                                                                                       }
                                                                                       return 0;
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               // Create instance of our testable generator
                                                                               BitsStreamGenerator generator = new TestableBitsStreamGenerator();
                                                                               
                                                                               // The calculation is: ((0x000000FFL << 27) + 0x0000FF00L) / (double)(1L << 53)
                                                                               double expected = (0x000000FFL << 27) + 0x0000FF00L;
                                                                               expected /= (1L << 53);
                                                                               
                                                                               // Call the actual nextDouble() method and verify
                                                                               assertEquals(expected, generator.nextDouble(), 0.000000000000001);
                                                                           }

 @Test
                                                                           public void testNextBoolean_ReturnsTrueWhenNext1IsNotZero() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return 1;
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               // Act
                                                                               boolean result = generator.nextBoolean();
                                                                               
                                                                               // Assert
                                                                               assertTrue(result);
                                                                           }

 @Test
                                                                           public void testNextBoolean_ReturnsFalseWhenNext1IsZero() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return 0; // Return 0 when next(1) is called
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               // Act
                                                                               boolean result = generator.nextBoolean();
                                                                               
                                                                               // Assert
                                                                               assertFalse(result);
                                                                           }

 @Test
                                                                           public void testNextBoolean_HandlesMaxIntReturnFromNext() {
                                                                               // Arrange
                                                                               // Create a test subclass that exposes the protected next() method
                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return Integer.MAX_VALUE;
                                                                                   }
                                                                               }
                                                                               
                                                                               BitsStreamGenerator generator = new TestBitsStreamGenerator();
                                                                               
                                                                               // Act
                                                                               boolean result = generator.nextBoolean();
                                                                               
                                                                               // Assert
                                                                               assertTrue(result);
                                                                           }

 @Test
                                                                           public void testNextBoolean_HandlesMinIntReturnFromNext() {
                                                                               // Arrange
                                                                               // Create a test subclass that exposes the protected next(int) method
                                                                               class TestBitsStreamGenerator extends BitsStreamGenerator {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return Integer.MIN_VALUE;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               TestBitsStreamGenerator generator = new TestBitsStreamGenerator();
                                                                               
                                                                               // Act
                                                                               boolean result = generator.nextBoolean();
                                                                               
                                                                               // Assert
                                                                               assertTrue(result);
                                                                           }

 @Test
                                                                           public void testNextDouble_NominalCase() {
                                                                               // Create a test subclass that exposes the protected next() method
                                                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return 0; // will be mocked
                                                                                   }
                                                                                   public int exposedNext(int bits) {
                                                                                       return next(bits);
                                                                                   }
                                                                               }
                                                                               
                                                                               // Create a mock of our testable subclass
                                                                               TestableBitsStreamGenerator generator = mock(TestableBitsStreamGenerator.class);
                                                                               
                                                                               // Mock the exposed next() calls to return specific values
                                                                               when(generator.exposedNext(26)).thenReturn(1, 1); // high part then low part
                                                                               
                                                                               double result = generator.nextDouble();
                                                                               // (1L << 26 | 1) * 2^-52 = (67108864 + 1) * 2^-52 ≈ 1.490116141589226E-8
                                                                               assertEquals(1.490116141589226E-8, result, 1e-20);
                                                                           }

 @Test
                                                                           public void testNextDouble_MaximumValue() {
                                                                               // Create test subclass that exposes protected next() method
                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                   private int nextValue;
                                                                                   
                                                                                   public void setNextValue(int value) {
                                                                                       this.nextValue = value;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return nextValue;
                                                                                   }
                                                                                   
                                                                                   // Implement abstract methods
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               // Create test generator
                                                                               TestGenerator generator = new TestGenerator();
                                                                               
                                                                               // Set to return all 1s (max values for both parts)
                                                                               generator.setNextValue((1 << 26) - 1); // high part
                                                                               generator.setNextValue((1 << 26) - 1); // low part
                                                                               
                                                                               double result = generator.nextDouble();
                                                                               // ((2^26-1) << 26 | (2^26-1)) * 2^-52 = (2^52 - 1) * 2^-52 ≈ 0.9999999999999999
                                                                               assertEquals(0.9999999999999999, result, 1e-20);
                                                                           }

 @Test
                                                                           public void testNextDouble_MinimumNonZeroValue() throws Exception {
                                                                               // Create a concrete subclass to access protected method
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   private int callCount = 0;
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       // Alternate between returning high and low parts
                                                                                       return (callCount++ == 0) ? 1 : 1;
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                           
                                                                               // Calculate expected value: (1 << 26 | 1) * 2^-52
                                                                               double expected = ((1L << 26) | 1) * 0x1.0p-52d;
                                                                               
                                                                               // Verify the result
                                                                               double result = generator.nextDouble();
                                                                               assertEquals(expected, result, 1e-20);
                                                                           }

 @Test
                                                                           public void testNextDouble_ZeroValue() {
                                                                               // Create test subclass that overrides protected next() method
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return 0; // Always return 0 for both high and low parts
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               double result = generator.nextDouble();
                                                                               assertEquals(0.0, result, 0.0);
                                                                           }

 @Test
                                                                           public void testNextDouble_RandomValues() {
                                                                               // Create a test subclass that exposes the protected next() method
                                                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                   private int nextValue;
                                                                                   
                                                                                   public void setNextValue(int value) {
                                                                                       this.nextValue = value;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return nextValue;
                                                                                   }
                                                                                   
                                                                                   // Other abstract methods need to be implemented
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               // Create test generator
                                                                               TestableBitsStreamGenerator generator = new TestableBitsStreamGenerator();
                                                                               
                                                                               // Test with some random-looking values
                                                                               generator.setNextValue(123456); // high part
                                                                               generator.nextDouble(); // consume first value
                                                                               generator.setNextValue(654321); // low part
                                                                               
                                                                               double result = generator.nextDouble();
                                                                               long combined = (123456L << 26) | 654321;
                                                                               double expected = combined * 0x1.0p-52d;
                                                                               assertEquals(expected, result, 0.0);
                                                                           }

 @Test
                                                                           public void testNextDouble_VerifyBitMasking() {
                                                                               // Create test subclass that exposes protected next() method
                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                   private int bits;
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       this.bits = bits;
                                                                                       return -1; // -1 has all bits set, but only 26 should be used
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               TestGenerator generator = new TestGenerator();
                                                                               
                                                                               double result = generator.nextDouble();
                                                                               
                                                                               // Verify that only 26 bits were requested
                                                                               assertEquals(26, generator.bits);
                                                                               
                                                                               // Only 26 bits should be used, so it's equivalent to (2^26-1) << 26 | (2^26-1)
                                                                               // The expected value is ((2^26-1) << 26 | (2^26-1)) * 2^-52
                                                                               assertEquals(0.9999999999999999, result, 1e-20);
                                                                           }

 @Test
                                                                           public void testNextFloat_ReturnsValueInRange() throws Exception {
                                                                               // Create a mock of BitsStreamGenerator
                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                               
                                                                               // Use reflection to mock the protected next() method
                                                                               Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                               nextMethod.setAccessible(true);
                                                                               when(nextMethod.invoke(generator, 23)).thenReturn(1234567);
                                                                               
                                                                               // Mock nextFloat() to use our implementation
                                                                               when(generator.nextFloat()).thenCallRealMethod();
                                                                               
                                                                               float result = generator.nextFloat();
                                                                               assertTrue("Value should be >= 0.0", result >= 0.0f);
                                                                               assertTrue("Value should be < 1.0", result < 1.0f);
                                                                           }

 @Test
                                                                           public void testNextFloat_Distribution() {
                                                                               // Create test subclass that exposes protected next(int) method
                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                   private int[] values;
                                                                                   private int index = 0;
                                                                                   
                                                                                   TestGenerator(int... values) {
                                                                                       this.values = values;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return values[index++];
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               // Create test generator with sequence of values
                                                                               BitsStreamGenerator generator = new TestGenerator(
                                                                                   0,                          // min value
                                                                                   (1 << 23) - 1,             // max value
                                                                                   1 << 22                     // middle value
                                                                               );
                                                                               
                                                                               float min = generator.nextFloat();
                                                                               float max = generator.nextFloat();
                                                                               float mid = generator.nextFloat();
                                                                               
                                                                               assertEquals(0.0f, min, 0.0f);
                                                                               assertEquals(0.99999994f, max, 0.00000001f);
                                                                               assertEquals(0.5f, mid, 0.00000001f);
                                                                           }

 @Test
                                                                           public void testNextFloat_AllBitsSet() {
                                                                               // Create test subclass that exposes protected next() method
                                                                               class TestGenerator extends BitsStreamGenerator {
                                                                                   private int nextValue;
                                                                                   
                                                                                   public void setNextValue(int value) {
                                                                                       this.nextValue = value;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return nextValue;
                                                                                   }
                                                                                   
                                                                                   // Need to override other abstract methods
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               // Create instance of test generator
                                                                               TestGenerator generator = new TestGenerator();
                                                                               
                                                                               // Set the next value to return when next(23) is called
                                                                               generator.setNextValue(0x7FFFFF);
                                                                               
                                                                               float result = generator.nextFloat();
                                                                               assertEquals(0.99999994f, result, 0.00000001f);
                                                                           }

 @Test
                                                                           public void testNextFloat_OneBitSet() {
                                                                               // Create a test subclass that exposes the protected next() method
                                                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                                   private int[] values;
                                                                                   private int index = 0;
                                                                                   
                                                                                   TestableBitsStreamGenerator(int... values) {
                                                                                       this.values = values;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return values[index++];
                                                                                   }
                                                                                   
                                                                                   // Implement abstract methods (not used in this test)
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               }
                                                                               
                                                                               // Create test generator with predefined values
                                                                               BitsStreamGenerator generator = new TestableBitsStreamGenerator(
                                                                                   1,          // LSB set
                                                                                   1 << 22     // MSB set
                                                                               );
                                                                               
                                                                               float lsb = generator.nextFloat();
                                                                               float msb = generator.nextFloat();
                                                                               
                                                                               assertEquals(1.1920929E-7f, lsb, 0.0000001f);  // 2^-23
                                                                               assertEquals(0.5f, msb, 0.0000001f);           // 2^-1
                                                                           }

 @Test
                                                                           public void testNextGaussian_WithInvalidYValue() {
                                                                               // Create a mock BitsStreamGenerator
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   protected int next(int bits) { return 0; }
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               BitsStreamGenerator spyGenerator = spy(generator);
                                                                               
                                                                               // Test with y = 0 (invalid for log)
                                                                               when(spyGenerator.nextDouble())
                                                                                   .thenReturn(0.5)  // x
                                                                                   .thenReturn(0.0); // y
                                                                               
                                                                               try {
                                                                                   spyGenerator.nextGaussian();
                                                                                   fail("Expected ArithmeticException");
                                                                               } catch (ArithmeticException e) {
                                                                                   // Expected exception
                                                                               }
                                                                           }

 @Test
                                                                           public void testNextInt_ReturnsValueFromNext() throws Exception {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return 123456789;
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               int expectedValue = 123456789;
                                                                               
                                                                               // Act
                                                                               int result = generator.nextInt();
                                                                               
                                                                               // Assert
                                                                               assertEquals(expectedValue, result);
                                                                           }

 @Test
                                                                           public void testNextInt_HandlesMaxIntValue() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                               int maxInt = Integer.MAX_VALUE;
                                                                               when(generator.nextInt()).thenReturn(maxInt);
                                                                               
                                                                               // Act
                                                                               int result = generator.nextInt();
                                                                               
                                                                               // Assert
                                                                               assertEquals(maxInt, result);
                                                                           }

 @Test
                                                                           public void testNextInt_HandlesMinIntValue() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return Integer.MIN_VALUE;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               int minInt = Integer.MIN_VALUE;
                                                                               
                                                                               // Act
                                                                               int result = generator.nextInt();
                                                                               
                                                                               // Assert
                                                                               assertEquals(minInt, result);
                                                                           }

 @Test
                                                                           public void testNextInt_HandlesZeroValue() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                               when(generator.nextInt()).thenReturn(0);
                                                                               
                                                                               // Act
                                                                               int result = generator.nextInt();
                                                                               
                                                                               // Assert
                                                                               assertEquals(0, result);
                                                                           }

 @Test
                                                                           public void testNextInt_VerifiesExactly32BitsRequested() throws Exception {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                               Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                               nextMethod.setAccessible(true);
                                                                               when(nextMethod.invoke(generator, 32)).thenReturn(1);
                                                                               
                                                                               // Act
                                                                               generator.nextInt();
                                                                               
                                                                               // Assert
                                                                               verify(nextMethod).invoke(generator, 32);
                                                                               verify(nextMethod, never()).invoke(generator, anyInt());
                                                                           }

 @Test
                                                                           public void testNextInt_NonPowerOfTwoInput() throws Exception {
                                                                               // Create mock generator
                                                                               BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                               
                                                                               // Get the protected next method via reflection
                                                                               Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                               nextMethod.setAccessible(true);
                                                                               
                                                                               // Test with n = 3
                                                                               // First mock attempt: bits = 7, val = 1 (7 % 3 = 1)
                                                                               // bits - val + (n-1) = 7 - 1 + 2 = 8 >= 0 → accepted
                                                                               when(nextMethod.invoke(generator, 31)).thenReturn(7);
                                                                               assertEquals(1, generator.nextInt(3));
                                                                               
                                                                               // Test rejection case
                                                                               // First mock attempt: bits = Integer.MAX_VALUE - 1, val = 1
                                                                               // bits - val + (n-1) = (MAX-1) - 1 + 2 = MAX >= 0 → accepted
                                                                               when(nextMethod.invoke(generator, 31)).thenReturn(Integer.MAX_VALUE - 1);
                                                                               assertEquals(1, generator.nextInt(3));
                                                                               
                                                                               // Test with n = 5
                                                                               // First mock attempt: bits = 9, val = 4 (9 % 5 = 4)
                                                                               // bits - val + (n-1) = 9 - 4 + 4 = 9 >= 0 → accepted
                                                                               when(nextMethod.invoke(generator, 31)).thenReturn(9);
                                                                               assertEquals(4, generator.nextInt(5));
                                                                           }

 @Test
                                                                           public void testNextInt_DoesNotHang() {
                                                                               // Ensure the method doesn't hang with valid input
                                                                               BitsStreamGenerator generator = spy(new BitsStreamGenerator() {
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return 42;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               });
                                                                               
                                                                               generator.nextInt(100);
                                                                           }

 @Test
                                                                           public void testNextLong_CombinesHighAndLowBitsCorrectly() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   private int callCount = 0;
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       return callCount++ == 0 ? 0x12345678 : 0x9ABCDEF0;
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               // Act
                                                                               long result = generator.nextLong();
                                                                               
                                                                               // Assert
                                                                               assertEquals(0x123456789ABCDEF0L, result);
                                                                           }

 @Test
                                                                           public void testNextLong_MaxValue() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   private int callCount = 0;
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       if (callCount++ < 2) {
                                                                                           return 0xFFFFFFFF; // Return max 32-bit value twice
                                                                                       }
                                                                                       return 0;
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               // Act
                                                                               long result = generator.nextLong();
                                                                               
                                                                               // Assert
                                                                               assertEquals(0xFFFFFFFFFFFFFFFFL, result);
                                                                           }

 @Test
                                                                           public void testNextLong_MixedHighAndLowBits() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   private int callCount = 0;
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       if (callCount++ == 0) {
                                                                                           return 0xFFFF0000;
                                                                                       } else {
                                                                                           return 0x0000FFFF;
                                                                                       }
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               // Act
                                                                               long result = generator.nextLong();
                                                                               
                                                                               // Assert
                                                                               assertEquals(0xFFFF00000000FFFFL, result);
                                                                           }

 @Test
                                                                           public void testNextLong_ProperlyMasksLowBits() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   private int callCount = 0;
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       // Return predefined values for first two calls
                                                                                       return callCount++ == 0 ? 0x00000000 : 0xFFFFFFFF;
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               // Act
                                                                               long result = generator.nextLong();
                                                                               
                                                                               // Assert
                                                                               assertEquals(0x00000000FFFFFFFFL, result);
                                                                           }

 @Test
                                                                           public void testNextLong_ProperlyShiftsHighBits() {
                                                                               // Arrange
                                                                               BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                   private int callCount = 0;
                                                                                   
                                                                                   @Override
                                                                                   protected int next(int bits) {
                                                                                       if (callCount++ == 0) {
                                                                                           return 0xFFFFFFFF; // First call returns high bits
                                                                                       } else {
                                                                                           return 0x00000000;  // Second call returns low bits
                                                                                       }
                                                                                   }
                                                                           
                                                                                   @Override
                                                                                   public void setSeed(int seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(int[] seed) {}
                                                                                   
                                                                                   @Override
                                                                                   public void setSeed(long seed) {}
                                                                               };
                                                                               
                                                                               // Act
                                                                               long result = generator.nextLong();
                                                                               
                                                                               // Assert
                                                                               assertEquals(0xFFFFFFFF00000000L, result);
                                                                           }

 @Test
                                                                       public void testNextIntWithBound() {
                                                                           // Create a test subclass that makes protected method accessible
                                                                           class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                               @Override
                                                                               protected int next(int bits) {
                                                                                   return 0x000000FF; // Fixed value for testing
                                                                               }
                                                                               
                                                                               @Override
                                                                               public void setSeed(int seed) {}
                                                                               
                                                                               @Override
                                                                               public void setSeed(int[] seed) {}
                                                                               
                                                                               @Override
                                                                               public void setSeed(long seed) {}
                                                                           }
                                                                           
                                                                           // Create instance of our testable subclass
                                                                           BitsStreamGenerator generator = new TestableBitsStreamGenerator();
                                                                           
                                                                           // Testing with bound 10
                                                                           int result = generator.nextInt(10);
                                                                           assertTrue(result >= 0);
                                                                           assertTrue(result < 10);
                                                                       }

 @Test
                                                                       public void testNextBoolean_CallsNextWithCorrectBitsParameter() throws Exception {
                                                                           // Arrange
                                                                           BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                               private int nextCalled = 0;
                                                                               
                                                                               @Override
                                                                               protected int next(int bits) {
                                                                                   assertEquals(1, bits);
                                                                                   nextCalled++;
                                                                                   return 1;
                                                                               }
                                                                       
                                                                               @Override
                                                                               public void setSeed(int seed) {}
                                                                               
                                                                               @Override
                                                                               public void setSeed(int[] seed) {}
                                                                               
                                                                               @Override
                                                                               public void setSeed(long seed) {}
                                                                           };
                                                                           
                                                                           // Act
                                                                           generator.nextBoolean();
                                                                           
                                                                           // Assert - The assertion is done in the overridden next() method
                                                                           // We can also verify the call count by adding a counter in the anonymous class
                                                                           Field nextCalledField = generator.getClass().getDeclaredField("nextCalled");
                                                                           nextCalledField.setAccessible(true);
                                                                           assertEquals(1, nextCalledField.getInt(generator));
                                                                       }

 @Test
                                                                       public void testNextBoolean_HandlesNegativeReturnFromNext() {
                                                                           // Arrange
                                                                           BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                               @Override
                                                                               protected int next(int bits) {
                                                                                   return -1;
                                                                               }
                                                                       
                                                                               @Override
                                                                               public void setSeed(int seed) {}
                                                                               
                                                                               @Override
                                                                               public void setSeed(int[] seed) {}
                                                                               
                                                                               @Override
                                                                               public void setSeed(long seed) {}
                                                                           };
                                                                           
                                                                           // Act
                                                                           boolean result = generator.nextBoolean();
                                                                           
                                                                           // Assert
                                                                           assertTrue(result);
                                                                       }

 @Test
                                                                       public void testNextFloat_MinimumValue() {
                                                                           // Create a concrete subclass to test the protected method
                                                                           BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                               @Override
                                                                               protected int next(int bits) {
                                                                                   return 0; // Return minimum value for this test
                                                                               }
                                                                       
                                                                               @Override
                                                                               public void setSeed(int seed) {}
                                                                               @Override
                                                                               public void setSeed(int[] seed) {}
                                                                               @Override
                                                                               public void setSeed(long seed) {}
                                                                           };
                                                                           
                                                                           float result = generator.nextFloat();
                                                                           assertEquals("Minimum value should be 0.0f", 0.0f, result, 0.0f);
                                                                       }

 @Test
                                                                       public void testNextLong_MinValue() {
                                                                           // Arrange
                                                                           BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                           when(generator.nextLong()).thenReturn(0x0000000000000000L);
                                                                           
                                                                           // Act
                                                                           long result = generator.nextLong();
                                                                           
                                                                           // Assert
                                                                           assertEquals(0x0000000000000000L, result);
                                                                       }

 @Test
                                                                   public void testNextLong() {
                                                                       // Create a concrete subclass with controlled behavior
                                                                       BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                           private int callCount = 0;
                                                                           
                                                                           @Override
                                                                           protected int next(int bits) {
                                                                               // First call returns 0x000000FF, second returns 0x0000FF00
                                                                               return callCount++ == 0 ? 0x000000FF : 0x0000FF00;
                                                                           }
                                                                   
                                                                           @Override
                                                                           public void setSeed(int seed) {}
                                                                   
                                                                           @Override
                                                                           public void setSeed(int[] seed) {}
                                                                   
                                                                           @Override
                                                                           public void setSeed(long seed) {}
                                                                       };
                                                                       
                                                                       // Expected value calculation: ((long)0x000000FF << 32) + 0x0000FF00L
                                                                       long expected = ((long)0x000000FF << 32) + 0x0000FF00L;
                                                                       
                                                                       // Verify the nextLong() returns expected value
                                                                       assertEquals(expected, generator.nextLong());
                                                                   }

 @Test
                                                                   public void testNextFloat_MaximumValue() {
                                                                       // Create a concrete subclass to expose the protected method
                                                                       class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                                           @Override
                                                                           protected int next(int bits) {
                                                                               return 0; // Will be overridden by Mockito
                                                                           }
                                                                           
                                                                           @Override
                                                                           public float nextFloat() {
                                                                               return super.nextFloat();
                                                                           }
                                                                           
                                                                           @Override
                                                                           public void setSeed(int seed) {
                                                                               // Empty implementation for testing
                                                                           }
                                                                           
                                                                           @Override
                                                                           public void setSeed(int[] seed) {
                                                                               // Empty implementation for testing
                                                                           }
                                                                           
                                                                           @Override
                                                                           public void setSeed(long seed) {
                                                                               // Empty implementation for testing
                                                                           }
                                                                       }
                                                                       
                                                                       // Create spy of our testable subclass
                                                                       TestableBitsStreamGenerator generator = spy(new TestableBitsStreamGenerator());
                                                                       
                                                                       // Mock next(23) to return (2^23 - 1) (maximum possible value)
                                                                       doReturn((1 << 23) - 1).when(generator).next(23);
                                                                       
                                                                       float result = generator.nextFloat();
                                                                       // The maximum value should be (2^23 - 1)/2^23 = 0.99999994f
                                                                       assertEquals(0.99999994f, result, 0.00000001f);
                                                                   }

 @Test
                                                           public void testNextInt_EdgeCases() throws Exception {
                                                               // Create mock generator subclass with accessible field
                                                               class TestGenerator extends BitsStreamGenerator {
                                                                   private int nextValue;
                                                                   
                                                                   public void setNextValue(int value) {
                                                                       this.nextValue = value;
                                                                   }
                                                                   
                                                                   @Override
                                                                   protected int next(int bits) {
                                                                       return nextValue;
                                                                   }
                                                                   
                                                                   @Override
                                                                   public void setSeed(int seed) {}
                                                                   
                                                                   @Override
                                                                   public void setSeed(int[] seed) {}
                                                                   
                                                                   @Override
                                                                   public void setSeed(long seed) {}
                                                               }
                                                               
                                                               TestGenerator generator = new TestGenerator();
                                                               
                                                               // Test with n = Integer.MAX_VALUE
                                                               generator.setNextValue(Integer.MAX_VALUE - 1);
                                                               assertEquals(Integer.MAX_VALUE - 1, generator.nextInt(Integer.MAX_VALUE));
                                                               
                                                               // Test with n just below power of two
                                                               generator.setNextValue(100);
                                                               assertEquals(100 % 127, generator.nextInt(127));
                                                           }

 @Test
                                               public void testNextLong_CallsNext32Twice() throws Exception {
                                                   // Arrange
                                                   // Create a concrete subclass to spy on
                                                   BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                       private int callCount = 0;
                                                       
                                                       @Override
                                                       protected int next(int bits) {
                                                           // Track calls through this method
                                                           if (bits == 32) {
                                                               if (callCount == 0) {
                                                                   callCount++;
                                                                   return 0x11111111;
                                                               } else {
                                                                   return 0x22222222;
                                                               }
                                                           }
                                                           return 0;
                                                       }
                                                       
                                                       @Override
                                                       public void setSeed(int seed) {}
                                                       
                                                       @Override
                                                       public void setSeed(int[] seed) {}
                                                       
                                                       @Override
                                                       public void setSeed(long seed) {}
                                                   };
                                                   
                                                   // Act
                                                   long result = generator.nextLong();
                                                   
                                                   // Assert
                                                   // Verify the expected result which requires two calls to next(32)
                                                   // 0x11111111 << 32 | 0x22222222
                                                   assertEquals(0x1111111122222222L, result);
                                                   
                                                   // Alternative verification using reflection
                                                   Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                   nextMethod.setAccessible(true);
                                                   
                                                   // Create a new instance to verify calls
                                                   BitsStreamGenerator verifyingGenerator = new BitsStreamGenerator() {
                                                       private int callCount = 0;
                                                       
                                                       @Override
                                                       protected int next(int bits) {
                                                           if (bits == 32) {
                                                               callCount++;
                                                               return callCount == 1 ? 0x11111111 : 0x22222222;
                                                           }
                                                           return 0;
                                                       }
                                                       
                                                       @Override
                                                       public void setSeed(int seed) {}
                                                       
                                                       @Override
                                                       public void setSeed(int[] seed) {}
                                                       
                                                       @Override
                                                       public void setSeed(long seed) {}
                                                   };
                                                   
                                                   verifyingGenerator.nextLong();
                                                   
                                                   // Verify two calls were made to next(32) through reflection
                                                   Field callCountField = verifyingGenerator.getClass().getDeclaredField("callCount");
                                                   callCountField.setAccessible(true);
                                                   assertEquals(2, callCountField.getInt(verifyingGenerator));
                                               }

 @Test
                                           public void testNextInt_RejectionSampling() {
                                               // Define a testable subclass
                                               class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                   @Override
                                                   protected int next(int bits) {
                                                       return 0; // dummy implementation, will be overridden by Mockito
                                                   }
                                                   
                                                   @Override
                                                   public void setSeed(int seed) {}
                                                   
                                                   @Override
                                                   public void setSeed(int[] seed) {}
                                                   
                                                   @Override
                                                   public void setSeed(long seed) {}
                                               }
                                               
                                               // Create a spy of the testable subclass
                                               TestableBitsStreamGenerator generator = spy(new TestableBitsStreamGenerator());
                                               
                                               // Stub the protected next() method using doReturn pattern
                                               doReturn(Integer.MAX_VALUE).doReturn(7).when(generator).next(31);
                                               
                                               // Test case where first attempt is rejected
                                               // First mock attempt: bits = Integer.MAX_VALUE, val = 1 (MAX % 3 = 1)
                                               // bits - val + (n-1) = MAX - 1 + 2 = MIN + 1 < 0 → rejected
                                               // Second mock attempt: bits = 7, val = 1 → accepted
                                               org.junit.Assert.assertEquals(1, generator.nextInt(3));
                                           }

 @Test
                                       public void testNextBytes_VerifyNextCalledCorrectly() {
                                           // Create a concrete subclass to test since BitsStreamGenerator is abstract
                                           class TestGenerator extends BitsStreamGenerator {
                                               private int callCount = 0;
                                               
                                               @Override
                                               protected int next(int bits) {
                                                   callCount++;
                                                   return 0; // dummy implementation
                                               }
                                               
                                               @Override
                                               public void setSeed(int seed) {}
                                               
                                               @Override
                                               public void setSeed(int[] seed) {}
                                               
                                               @Override
                                               public void setSeed(long seed) {}
                                               
                                               public int getCallCount() {
                                                   return callCount;
                                               }
                                           }
                                           
                                           TestGenerator generator = new TestGenerator();
                                           byte[] bytes = new byte[7];
                                           generator.nextBytes(bytes);
                                           
                                           assertEquals(2, generator.getCallCount());
                                       }

 @Test
           public void testNextInt_PowerOfTwoInput() {
               // Test with n = 1 (2^0)
               BitsStreamGenerator generator1 = new BitsStreamGenerator() {
                   @Override
                   protected int next(int bits) {
                       return 31;  // nextValue for n=1 test
                   }
                   
                   @Override
                   public void setSeed(int seed) {}
                   
                   @Override
                   public void setSeed(int[] seed) {}
                   
                   @Override
                   public void setSeed(long seed) {}
               };
               assertEquals(0, generator1.nextInt(1));
               
               // Test with n = 2 (2^1)
               BitsStreamGenerator generator2 = new BitsStreamGenerator() {
                   @Override
                   protected int next(int bits) {
                       return 1 << 30;  // nextValue for n=2 test
                   }
                   
                   @Override
                   public void setSeed(int seed) {}
                   
                   @Override
                   public void setSeed(int[] seed) {}
                   
                   @Override
                   public void setSeed(long seed) {}
               };
               assertEquals(1, generator2.nextInt(2));
               
               // Test with n = 4 (2^2)
               BitsStreamGenerator generator3 = new BitsStreamGenerator() {
                   @Override
                   protected int next(int bits) {
                       return 3 << 29;  // nextValue for n=4 test
                   }
                   
                   @Override
                   public void setSeed(int seed) {}
                   
                   @Override
                   public void setSeed(int[] seed) {}
                   
                   @Override
                   public void setSeed(long seed) {}
               };
               assertEquals(3, generator3.nextInt(4));
               
               // Test with n = 8 (2^3)
               BitsStreamGenerator generator4 = new BitsStreamGenerator() {
                   @Override
                   protected int next(int bits) {
                       return 7 << 28;  // nextValue for n=8 test
                   }
                   
                   @Override
                   public void setSeed(int seed) {}
                   
                   @Override
                   public void setSeed(int[] seed) {}
                   
                   @Override
                   public void setSeed(long seed) {}
               };
               assertEquals(7, generator4.nextInt(8));
           }

 @Test
       public void testSetSeed_IntBoundaryValues() {
           // Create an anonymous subclass of BitsStreamGenerator for testing
           org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
               private int lastIntSeed;
               
               @Override
               public void setSeed(int seed) {
                   this.lastIntSeed = seed;
               }
           
               @Override
               public void setSeed(int[] seed) {
                   // Not used in this test
               }
           
               @Override
               public void setSeed(long seed) {
                   // Not used in this test
               }
           
               @Override
               protected int next(int bits) {
                   return 0; // Not used in this test
               }
               
               public int getLastIntSeed() {
                   return lastIntSeed;
               }
               
               @Override
               public boolean nextBoolean() {
                   return false;
               }
               
               @Override
               public void nextBytes(byte[] bytes) {
                   // Empty implementation
               }
               
               @Override
               public double nextDouble() {
                   return 0;
               }
               
               @Override
               public float nextFloat() {
                   return 0;
               }
               
               @Override
               public double nextGaussian() {
                   return 0;
               }
               
               @Override
               public int nextInt() {
                   return 0;
               }
               
               @Override
               public int nextInt(int n) {
                   return 0;
               }
               
               @Override
               public long nextLong() {
                   return 0;
               }
               
               @Override
               public void clear() {
                   // Empty implementation
               }
           };
           
           generator.setSeed(Integer.MIN_VALUE);
           
           generator.setSeed(Integer.MAX_VALUE);
           
           generator.setSeed(0);
       }

 @Test
       public void testSetSeed_IntArray() {
           // Create a concrete implementation for testing
           org.apache.commons.math3.random.BitsStreamGenerator generator = 
               new org.apache.commons.math3.random.BitsStreamGenerator() {
                   private int[] lastSeed;
                   
                   @Override
                   public void setSeed(int seed) {}
                   
                   @Override
                   public void setSeed(int[] seed) {
                       this.lastSeed = seed.clone(); // Use clone to prevent external modification
                   }
                   
                   @Override
                   public void setSeed(long seed) {}
                   
                   @Override
                   protected int next(int bits) {
                       return 0;
                   }
                   
                   // Make the method public to ensure accessibility
                   public int[] getLastIntArraySeed() {
                       return lastSeed != null ? lastSeed.clone() : null; // Return clone for safety
                   }
                   
                   // Implement remaining abstract methods
                   @Override
                   public boolean nextBoolean() { return false; }
                   
                   @Override
                   public void nextBytes(byte[] bytes) {}
                   
                   @Override
                   public double nextDouble() { return 0; }
                   
                   @Override
                   public float nextFloat() { return 0; }
                   
                   @Override
                   public double nextGaussian() { return 0; }
                   
                   @Override
                   public int nextInt() { return 0; }
                   
                   @Override
                   public int nextInt(int n) { return 0; }
                   
                   @Override
                   public long nextLong() { return 0; }
                   
                   @Override
                   public void clear() {}
               };
           
           int[] seed = {1, 2, 3, 4, 5};
           generator.setSeed(seed);
       }

 @Test
       public void testSetSeed_IntArray_ShouldStoreSeedArray() {
           // Create a concrete subclass instance for testing
           BitsStreamGenerator generator = new BitsStreamGenerator() {
               private int[] seed;
               
               @Override
               public void setSeed(int seed) {}
               
               @Override
               public void setSeed(int[] seed) {
                   this.seed = seed.clone();
               }
               
               @Override
               public void setSeed(long seed) {}
               
               @Override
               protected int next(int bits) {
                   return 0;
               }
               
               public int[] getArraySeed() {
                   return seed;
               }
               
               @Override
               public boolean nextBoolean() {
                   return false;
               }
               
               @Override
               public void nextBytes(byte[] bytes) {}
               
               @Override
               public double nextDouble() {
                   return 0;
               }
               
               @Override
               public float nextFloat() {
                   return 0;
               }
               
               @Override
               public double nextGaussian() {
                   return 0;
               }
               
               @Override
               public int nextInt() {
                   return 0;
               }
               
               @Override
               public int nextInt(int n) {
                   return 0;
               }
               
               @Override
               public long nextLong() {
                   return 0;
               }
               
               @Override
               public void clear() {}
           };
           
           int[] testSeed = {1, 2, 3, 4, 5};
           generator.setSeed(testSeed);
       }

 @Test
       public void testSetSeed_IntBoundaryValues1() {
           // Create an anonymous subclass of BitsStreamGenerator for testing
           org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
               private int lastIntSeed;
               
               @Override
               public void setSeed(int seed) {
                   this.lastIntSeed = seed;
               }
           
               @Override
               public void setSeed(int[] seed) {
                   // Not used in this test
               }
           
               @Override
               public void setSeed(long seed) {
                   // Not used in this test
               }
           
               @Override
               protected int next(int bits) {
                   return 0; // Not used in this test
               }
               
               public int getLastIntSeed() {
                   return lastIntSeed;
               }
               
               @Override
               public boolean nextBoolean() {
                   return false;
               }
               
               @Override
               public void nextBytes(byte[] bytes) {
                   // Empty implementation
               }
               
               @Override
               public double nextDouble() {
                   return 0;
               }
               
               @Override
               public float nextFloat() {
                   return 0;
               }
               
               @Override
               public double nextGaussian() {
                   return 0;
               }
               
               @Override
               public int nextInt() {
                   return 0;
               }
               
               @Override
               public int nextInt(int n) {
                   return 0;
               }
               
               @Override
               public long nextLong() {
                   return 0;
               }
               
               @Override
               public void clear() {
                   // Empty implementation
               }
           };
           
           generator.setSeed(Integer.MIN_VALUE);
           
           generator.setSeed(Integer.MAX_VALUE);
           
           generator.setSeed(0);
       }

}
