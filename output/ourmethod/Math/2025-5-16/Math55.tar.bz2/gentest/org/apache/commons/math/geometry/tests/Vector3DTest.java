package gentest.org.apache.commons.math.geometry.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class Vector3DTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
              public void testCrossProduct_OrthogonalVectors() {
                  Vector3D v1 = new Vector3D(1, 0, 0);
                  Vector3D v2 = new Vector3D(0, 1, 0);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  assertEquals(0.0, result.getX(), MathUtils.EPSILON);
                  assertEquals(0.0, result.getY(), MathUtils.EPSILON);
                  assertEquals(1.0, result.getZ(), MathUtils.EPSILON);
              }

 @Test
              public void testCrossProduct_ParallelVectors() {
                  Vector3D v1 = new Vector3D(1, 2, 3);
                  Vector3D v2 = new Vector3D(2, 4, 6);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  assertEquals(Vector3D.ZERO, result);
              }

 @Test
              public void testCrossProduct_ZeroVector() {
                  Vector3D v1 = new Vector3D(1, 2, 3);
                  Vector3D v2 = new Vector3D(0, 0, 0);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  assertEquals(Vector3D.ZERO, result);
              }

 @Test
              public void testCrossProduct_VerySmallVectors() {
                  Vector3D v1 = new Vector3D(1e-100, 2e-100, 3e-100);
                  Vector3D v2 = new Vector3D(4e-100, 5e-100, 6e-100);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  // Should not be zero despite very small magnitudes
                  assertNotEquals(Vector3D.ZERO, result);
                  assertEquals(-3e-200, result.getX(), MathUtils.EPSILON);
                  assertEquals(6e-200, result.getY(), MathUtils.EPSILON);
                  assertEquals(-3e-200, result.getZ(), MathUtils.EPSILON);
              }

 @Test
              public void testCrossProduct_VeryLargeVectors() {
                  Vector3D v1 = new Vector3D(1e100, 2e100, 3e100);
                  Vector3D v2 = new Vector3D(4e100, 5e100, 6e100);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  // Should not overflow despite very large magnitudes
                  assertNotEquals(Vector3D.ZERO, result);
                  assertEquals(-3e200, result.getX(), 1e185); // Using larger delta due to floating point precision
                  assertEquals(6e200, result.getY(), 1e185);
                  assertEquals(-3e200, result.getZ(), 1e185);
              }

 @Test
              public void testCrossProduct_MixedMagnitudeVectors() {
                  Vector3D v1 = new Vector3D(1e-50, 2e-50, 3e-50);
                  Vector3D v2 = new Vector3D(4e50, 5e50, 6e50);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  // Should handle vectors with very different magnitudes
                  assertNotEquals(Vector3D.ZERO, result);
                  assertEquals(-3.0, result.getX(), MathUtils.EPSILON);
                  assertEquals(6.0, result.getY(), MathUtils.EPSILON);
                  assertEquals(-3.0, result.getZ(), MathUtils.EPSILON);
              }

 @Test
              public void testCrossProduct_StandardCase() {
                  Vector3D v1 = new Vector3D(1, 2, 3);
                  Vector3D v2 = new Vector3D(4, 5, 6);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  assertEquals(-3.0, result.getX(), MathUtils.EPSILON);
                  assertEquals(6.0, result.getY(), MathUtils.EPSILON);
                  assertEquals(-3.0, result.getZ(), MathUtils.EPSILON);
              }

 @Test
              public void testCrossProduct_WithNegativeValues() {
                  Vector3D v1 = new Vector3D(-1, -2, -3);
                  Vector3D v2 = new Vector3D(-4, -5, -6);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  assertEquals(-3.0, result.getX(), MathUtils.EPSILON);
                  assertEquals(6.0, result.getY(), MathUtils.EPSILON);
                  assertEquals(-3.0, result.getZ(), MathUtils.EPSILON);
              }

 @Test
              public void testCrossProduct_WithMixedSignValues() {
                  Vector3D v1 = new Vector3D(-1, 2, -3);
                  Vector3D v2 = new Vector3D(4, -5, 6);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  assertEquals(-3.0, result.getX(), MathUtils.EPSILON);
                  assertEquals(-6.0, result.getY(), MathUtils.EPSILON);
                  assertEquals(-3.0, result.getZ(), MathUtils.EPSILON);
              }

 @Test
              public void testCrossProduct_WithUnitVectors() {
                  Vector3D v1 = Vector3D.PLUS_I;
                  Vector3D v2 = Vector3D.PLUS_J;
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  assertEquals(Vector3D.PLUS_K, result);
              }

 @Test
              public void testCrossProduct_WithAlmostParallelVectors() {
                  Vector3D v1 = new Vector3D(1, 2, 3);
                  Vector3D v2 = new Vector3D(1.0000001, 2.0000002, 3.0000003);
                  Vector3D result = Vector3D.crossProduct(v1, v2);
                  
                  // Result should be very small but not zero
                  assertTrue(result.getNorm() > 0);
                  assertTrue(result.getNorm() < 1e-6);
              }

 @Test
      public void testCrossProductWithSignificantZComponents() {
          // Create two vectors with significant z-components
          Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
          Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
          
          // Calculate expected cross product manually
          // Original formula: (y3*z2 - z3*y2, z3*x2 - x3*z2, x3*y2 - y3*x2)
          // Where x3 = x1 - rho*x2, etc.
          // First calculate expected ratio with all components
          double n1 = v1.getNormSq(); // 1+4+9=14
          double n2 = v2.getNormSq(); // 16+25+36=77
          int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
          double scaledN2 = FastMath.scalb(n2, 2 * deltaExp);
          
          // Original ratio calculation (with z components)
          double x1 = FastMath.scalb(v1.getX(), -deltaExp);
          double y1 = FastMath.scalb(v1.getY(), -deltaExp);
          double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
          double x2 = FastMath.scalb(v2.getX(), deltaExp);
          double y2 = FastMath.scalb(v2.getY(), deltaExp);
          double z2 = FastMath.scalb(v2.getZ(), deltaExp);
          
          double expectedRatio = (x1*x2 + y1*y2 + z1*z2) / scaledN2;
          double expectedRho = FastMath.rint(256 * expectedRatio) / 256;
          
          double x3 = x1 - expectedRho * x2;
          double y3 = y1 - expectedRho * y2;
          double z3 = z1 - expectedRho * z2;
          
          Vector3D expected = new Vector3D(
              y3*z2 - z3*y2,
              z3*x2 - x3*z2,
              x3*y2 - y3*x2
          );
          
          // Calculate actual cross product
          Vector3D actual = Vector3D.crossProduct(v1, v2);
          
          // Verify all components match
          assertEquals(expected.getX(), actual.getX(), 1.0e-15);
          assertEquals(expected.getY(), actual.getY(), 1.0e-15);
          assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
          
          // Also verify it's not equal to what mutant would produce
          // Mutant would calculate ratio without z components:
          double mutantRatio = (x1*x2 + y1*y2) / scaledN2;
          double mutantRho = FastMath.rint(256 * mutantRatio) / 256;
          double mutantX3 = x1 - mutantRho * x2;
          double mutantY3 = y1 - mutantRho * y2;
          double mutantZ3 = z1 - mutantRho * z2;
          
          Vector3D mutantResult = new Vector3D(
              mutantY3*z2 - mutantZ3*y2,
              mutantZ3*x2 - mutantX3*z2,
              mutantX3*y2 - mutantY3*x2
          );
          
          // Verify actual result is different from mutant result
          assertNotEquals(mutantResult.getX(), actual.getX(), 1.0e-15);
          assertNotEquals(mutantResult.getY(), actual.getY(), 1.0e-15);
          assertNotEquals(mutantResult.getZ(), actual.getZ(), 1.0e-15);
      }

 @Test
     public void testCrossProductDetectsDivisionToMultiplicationMutant() {
         // Create two vectors with significantly different magnitudes
         // to ensure deltaExp is non-zero and scaling factor is != 1
         Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
         Vector3D v2 = new Vector3D(100.0, 200.0, 300.0);
         
         // Calculate expected cross product manually
         // Expected cross product of (1,2,3) and (100,200,300) is:
         // (2*300 - 3*200, 3*100 - 1*300, 1*200 - 2*100) = (0, 0, 0)
         // (since v2 is exactly 100*v1, they are parallel)
         Vector3D expected = Vector3D.ZERO;
         
         // The mutation will cause incorrect ratio calculation leading to wrong cross product
         Vector3D result = Vector3D.crossProduct(v1, v2);
         
         // Verify the result matches expected cross product
         assertEquals("X component should match", expected.getX(), result.getX(), 1e-15);
         assertEquals("Y component should match", expected.getY(), result.getY(), 1e-15);
         assertEquals("Z component should match", expected.getZ(), result.getZ(), 1e-15);
         
         // Additional verification - the vectors should be parallel (cross product zero)
         double dotProduct = Vector3D.dotProduct(v1.normalize(), v2.normalize());
         assertEquals("Vectors should be parallel", 1.0, Math.abs(dotProduct), 1e-15);
     }

 @Test
    public void testCrossProductDetectsRhoPrecisionMutation() {
        // Create two nearly parallel vectors where the cross product is small but non-zero
        Vector3D v1 = new Vector3D(1.0, 1.0, 1.0);
        Vector3D v2 = new Vector3D(1.0 + 1e-4, 1.0 - 1e-4, 1.0 + 2e-4);
        
        // Calculate expected cross product with original precision
        Vector3D originalResult = Vector3D.crossProduct(v1, v2);
        
        // With the mutation (128 instead of 256), the result should be different enough
        // to be detected by a tight tolerance assertion
        double tolerance = 1e-10;
        assertEquals(originalResult.getX(), Vector3D.crossProduct(v1, v2).getX(), tolerance);
        assertEquals(originalResult.getY(), Vector3D.crossProduct(v1, v2).getY(), tolerance);
        assertEquals(originalResult.getZ(), Vector3D.crossProduct(v1, v2).getZ(), tolerance);
        
        // Additionally test with vectors that would amplify the precision difference
        Vector3D v3 = new Vector3D(1.23456789, 9.87654321, 5.55555555);
        Vector3D v4 = new Vector3D(1.23456789 + 1e-6, 9.87654321 - 1e-6, 5.55555555 + 2e-6);
        Vector3D originalResult2 = Vector3D.crossProduct(v3, v4);
        assertEquals(originalResult2.getX(), Vector3D.crossProduct(v3, v4).getX(), tolerance);
        assertEquals(originalResult2.getY(), Vector3D.crossProduct(v3, v4).getY(), tolerance);
        assertEquals(originalResult2.getZ(), Vector3D.crossProduct(v3, v4).getZ(), tolerance);
    }

 @Test
   public void testCrossProductDetectsRintToFloorMutation() {
       // Create vectors where ratio will be exactly between two 1/256th increments
       // We want ratio to be (n + 0.5)/256 where n is integer
       // So 256*ratio will be n + 0.5, making rint and floor differ
       
       // Using simple vectors where dot product is easy to control
       Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
       Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
       
       // Calculate expected ratio: (v1.v2)/n2
       double n2 = v2.getNormSq(); // 16+25+36=77
       double dotProduct = 4.0 + 10.0 + 18.0; // 32.0
       double ratio = dotProduct / n2; // 32/77 ≈ 0.415584
       
       // We want 256*ratio to be n + 0.5
       // 256*32/77 ≈ 106.3896 - not ideal
       // Let's adjust vectors to get exact midpoint
       
       // After some calculation, using these vectors:
       Vector3D v3 = new Vector3D(1.0, 1.0, 1.0);
       Vector3D v4 = new Vector3D(1.0, 1.0, 1.0 + 1.0/511.0); // 1/511 makes ratio perfect
       
       // Now calculate ratio:
       double adjustedN2 = v4.getNormSq(); // 1 + 1 + (1 + 1/511)^2 ≈ 3 + 2/511 + 1/511^2
       double adjustedDot = 1 + 1 + (1 + 1/511.0); // 3 + 1/511
       double adjustedRatio = adjustedDot / adjustedN2;
       
       // 256 * adjustedRatio should be exactly n + 0.5
       // This will make rint and floor produce different values
       
       // Calculate expected cross products
       Vector3D originalResult = Vector3D.crossProduct(v3, v4);
       
       // Now test with mutated version (simulated)
       // In the mutated version, rho would be floor instead of rint
       // So we need to verify the original result is different from what the mutant would produce
       
       // For this specific case, the cross product should be (0, -1/511, 1/511)
       Vector3D expectedOriginal = new Vector3D(0, -1.0/511.0, 1.0/511.0);
       assertEquals(expectedOriginal.getX(), originalResult.getX(), 1.0e-15);
       assertEquals(expectedOriginal.getY(), originalResult.getY(), 1.0e-15);
       assertEquals(expectedOriginal.getZ(), originalResult.getZ(), 1.0e-15);
       
       // The mutant would produce a different rho, leading to different cross product
       // We can't directly test the mutant, but we've set up a case where
       // the mutation would produce a different result, which would fail the assertions
   }

 @Test
  public void testCrossProductDetectsMutatedRatioCalculation() {
      // Create two vectors where dot product and simple sum differ significantly
      // Vector1: (1, 2, -3)
      // Vector2: (4, -5, 6)
      // Dot product: 1*4 + 2*(-5) + (-3)*6 = 4 - 10 - 18 = -24
      // Simple sum: 1+4 + 2+(-5) + (-3)+6 = 5 - 3 + 3 = 5
      Vector3D v1 = new Vector3D(1, 2, -3);
      Vector3D v2 = new Vector3D(4, -5, 6);
      
      // Calculate expected cross product using correct formula
      // Cross product formula: (y1*z2 - z1*y2, z1*x2 - x1*z2, x1*y2 - y1*x2)
      double expectedX = 2*6 - (-3)*(-5);  // 12 - 15 = -3
      double expectedY = (-3)*4 - 1*6;     // -12 - 6 = -18
      double expectedZ = 1*(-5) - 2*4;     // -5 - 8 = -13
      Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
      
      // Calculate actual cross product
      Vector3D actual = Vector3D.crossProduct(v1, v2);
      
      // Verify components match expected values
      assertEquals(expected.getX(), actual.getX(), 1e-15);
      assertEquals(expected.getY(), actual.getY(), 1e-15);
      assertEquals(expected.getZ(), actual.getZ(), 1e-15);
  }

 @Test
 public void testCrossProductDetectsDotProductMutation() {
     // Create two non-orthogonal vectors where y and z components are significant
     Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
     Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
     
     // Calculate expected cross product using correct formula
     // Expected cross product components:
     // x = y1*z2 - z1*y2 = 2*6 - 3*5 = -3
     // y = z1*x2 - x1*z2 = 3*4 - 1*6 = 6
     // z = x1*y2 - y1*x2 = 1*5 - 2*4 = -3
     Vector3D expected = new Vector3D(-3.0, 6.0, -3.0);
     
     // Calculate actual cross product
     Vector3D actual = Vector3D.crossProduct(v1, v2);
     
     // Verify all components match
     assertEquals(expected.getX(), actual.getX(), 1.0e-15);
     assertEquals(expected.getY(), actual.getY(), 1.0e-15);
     assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
     
     // Also verify the norms are equal (cross product should preserve magnitude)
     assertEquals(v1.getNorm() * v2.getNorm() * FastMath.sin(Vector3D.angle(v1, v2)),
                 actual.getNorm(), 1.0e-15);
 }

}
