package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                                                         public void testDivide_NaN_Divisor() {
                                                             Complex complex = new Complex(2.0, 3.0);
                                                             Complex result = complex.divide(Double.NaN);
                                                             assertTrue(result.isNaN());
                                                         }

 @Test
                                                         public void testDivide_ComplexIsNaN() {
                                                             Complex complex = new Complex(Double.NaN, Double.NaN);
                                                             Complex result = complex.divide(5.0);
                                                             assertTrue(result.isNaN());
                                                         }

 @Test
                                                         public void testDivide_ZeroDivisor_ComplexIsZero() {
                                                             Complex complex = new Complex(0.0, 0.0);
                                                             Complex result = complex.divide(0.0);
                                                             assertTrue(result.isNaN());
                                                         }

 @Test
                                                         public void testDivide_ZeroDivisor_ComplexNotZero() {
                                                             Complex complex = new Complex(2.0, 3.0);
                                                             Complex result = complex.divide(0.0);
                                                             assertTrue(result.isInfinite());
                                                             assertEquals(Complex.INF, result);
                                                         }

 @Test
                                                         public void testDivide_InfiniteDivisor_ComplexFinite() {
                                                             Complex complex = new Complex(2.0, 3.0);
                                                             Complex result = complex.divide(Double.POSITIVE_INFINITY);
                                                             assertEquals(Complex.ZERO, result);
                                                         }

 @Test
                                                         public void testDivide_InfiniteDivisor_ComplexInfinite() {
                                                             Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                             Complex result = complex.divide(Double.POSITIVE_INFINITY);
                                                             assertTrue(result.isNaN());
                                                         }

 @Test
                                                         public void testDivide_NormalCase() {
                                                             Complex complex = new Complex(4.0, 6.0);
                                                             Complex result = complex.divide(2.0);
                                                             assertEquals(2.0, result.getReal(), 0.0001);
                                                             assertEquals(3.0, result.getImaginary(), 0.0001);
                                                         }

 @Test
                                                         public void testDivide_NegativeDivisor() {
                                                             Complex complex = new Complex(4.0, 6.0);
                                                             Complex result = complex.divide(-2.0);
                                                             assertEquals(-2.0, result.getReal(), 0.0001);
                                                             assertEquals(-3.0, result.getImaginary(), 0.0001);
                                                         }

 @Test
                                                         public void testDivide_ComplexWithZeroImaginary() {
                                                             Complex complex = new Complex(4.0, 0.0);
                                                             Complex result = complex.divide(2.0);
                                                             assertEquals(2.0, result.getReal(), 0.0001);
                                                             assertEquals(0.0, result.getImaginary(), 0.0001);
                                                         }

 @Test
                                                         public void testDivide_ComplexWithZeroReal() {
                                                             Complex complex = new Complex(0.0, 6.0);
                                                             Complex result = complex.divide(2.0);
                                                             assertEquals(0.0, result.getReal(), 0.0001);
                                                             assertEquals(3.0, result.getImaginary(), 0.0001);
                                                         }

 @Test
                                                         public void testDivide_ByOne() {
                                                             Complex complex = new Complex(4.0, 6.0);
                                                             Complex result = complex.divide(1.0);
                                                             assertEquals(complex, result);
                                                         }

 @Test
                                                         public void testDivide_ByNegativeInfinity() {
                                                             Complex complex = new Complex(4.0, 6.0);
                                                             Complex result = complex.divide(Double.NEGATIVE_INFINITY);
                                                             assertEquals(Complex.ZERO, result);
                                                         }

 @Test
                                                         public void testDivide_ComplexWithNegativeValues() {
                                                             Complex complex = new Complex(-4.0, -6.0);
                                                             Complex result = complex.divide(2.0);
                                                             assertEquals(-2.0, result.getReal(), 0.0001);
                                                             assertEquals(-3.0, result.getImaginary(), 0.0001);
                                                         }

 @Test
                                                     public void testDivide_NaN_Cases() {
                                                         // Case 1: Current complex is NaN (real part is NaN)
                                                         Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                         Complex validDivisor = new Complex(1.0, 1.0);
                                                         assertEquals(Complex.NaN, nanComplex.divide(validDivisor));
                                                         
                                                         // Case 2: Divisor is NaN
                                                         Complex validComplex = new Complex(1.0, 1.0);
                                                         Complex nanDivisor = new Complex(Double.NaN, 1.0);
                                                         assertEquals(Complex.NaN, validComplex.divide(nanDivisor));
                                                         
                                                         // Case 3: Both are NaN (should still return NaN)
                                                         assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
                                                     }

 @Test
                                                     public void testDivideWithNaNCases() {
                                                         // Case 1: Complex is NaN, divisor is valid
                                                         Complex nanComplex = new Complex(Double.NaN, Double.NaN);
                                                         double validDivisor = 2.0;
                                                         assertEquals(Complex.NaN, nanComplex.divide(validDivisor));
                                                         
                                                         // Case 2: Complex is valid, divisor is NaN
                                                         Complex validComplex = new Complex(1.0, 1.0);
                                                         double nanDivisor = Double.NaN;
                                                         assertEquals(Complex.NaN, validComplex.divide(nanDivisor));
                                                         
                                                         // Case 3: Both are NaN (should return NaN in both original and mutated)
                                                         assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
                                                         
                                                         // Case 4: Neither is NaN (should proceed with normal division)
                                                         Complex result = validComplex.divide(validDivisor);
                                                         assertEquals(0.5, result.getReal(), 0.0001);
                                                         assertEquals(0.5, result.getImaginary(), 0.0001);
                                                     }

 @Test
                                                    public void testDivide_CurrentIsNaN_DivisorNotNaN_ShouldReturnNaN() {
                                                        // Create a NaN complex number (either real or imaginary part is NaN)
                                                        Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                        
                                                        // Create a valid complex number as divisor
                                                        Complex validDivisor = new Complex(1.0, 1.0);
                                                        
                                                        // Call the method
                                                        Complex result = nanComplex.divide(validDivisor);
                                                        
                                                        // Verify the result is NaN
                                                        assertTrue("Dividing NaN by non-NaN should return NaN", 
                                                                   result.isNaN());
                                                        
                                                        // Alternative verification using the class constant
                                                        assertEquals("Dividing NaN by non-NaN should return NaN constant",
                                                                    Complex.NaN, result);
                                                    }

 @Test
                                                public void testDivideWithNaNComplexNumber() {
                                                    // Create a NaN complex number (with NaN real part)
                                                    Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                    
                                                    // Divide by a valid number
                                                    Complex result = nanComplex.divide(2.0);
                                                    
                                                    // Original would return NaN, mutant would try to divide
                                                    assertEquals(Complex.NaN, result);
                                                    
                                                    // Also test with NaN imaginary part
                                                    Complex nanComplex2 = new Complex(1.0, Double.NaN);
                                                    result = nanComplex2.divide(2.0);
                                                    assertEquals(Complex.NaN, result);
                                                    
                                                    // Test with both parts NaN
                                                    Complex nanComplex3 = new Complex(Double.NaN, Double.NaN);
                                                    result = nanComplex3.divide(2.0);
                                                    assertEquals(Complex.NaN, result);
                                                }

 @Test
                                                   public void testDivideWithNaNDivisorShouldReturnNaN() {
                                                       // Create a valid complex number (not NaN)
                                                       Complex dividend = new Complex(1.0, 2.0);
                                                       
                                                       // Create divisor with NaN real part
                                                       Complex divisorWithNaNReal = new Complex(Double.NaN, 3.0);
                                                       Complex result1 = dividend.divide(divisorWithNaNReal);
                                                       assertTrue("Division by complex with NaN real part should return NaN", 
                                                                 result1.isNaN());
                                                       
                                                       // Create divisor with NaN imaginary part
                                                       Complex divisorWithNaNImaginary = new Complex(3.0, Double.NaN);
                                                       Complex result2 = dividend.divide(divisorWithNaNImaginary);
                                                       assertTrue("Division by complex with NaN imaginary part should return NaN", 
                                                                 result2.isNaN());
                                                       
                                                       // Create divisor with both parts NaN
                                                       Complex divisorWithBothNaN = new Complex(Double.NaN, Double.NaN);
                                                       Complex result3 = dividend.divide(divisorWithBothNaN);
                                                       assertTrue("Division by complex with both parts NaN should return NaN", 
                                                                 result3.isNaN());
                                                   }

 @Test
                                               public void testDivideWithNaNDivisorShouldReturnNaN1() {
                                                   // Create a valid complex number (not NaN)
                                                   Complex complex = new Complex(2.0, 3.0);
                                                   
                                                   // Use NaN as divisor
                                                   double nanDivisor = Double.NaN;
                                                   
                                                   // Call the method
                                                   Complex result = complex.divide(nanDivisor);
                                                   
                                                   // Verify the result is NaN (original behavior)
                                                   // The mutant would skip this check and potentially try to perform division
                                                   assertTrue(Double.isNaN(result.getReal()));
                                                   assertTrue(Double.isNaN(result.getImaginary()));
                                                   
                                                   // Alternative assertion if Complex has isNaN() method
                                                   assertTrue(result.isNaN());
                                               }

 @Test
                                                  public void testDivideByZero() {
                                                      // Test case 1: divisor is zero, dividend is zero -> should return NaN
                                                      Complex zeroDividend = new Complex(0, 0);
                                                      Complex zeroDivisor = new Complex(0, 0);
                                                      Complex result1 = zeroDividend.divide(zeroDivisor);
                                                      assertTrue("Dividing zero by zero should return NaN", result1.isNaN());
                                              
                                                      // Test case 2: divisor is zero, dividend is non-zero -> should return INF
                                                      Complex nonZeroDividend = new Complex(1, 1);
                                                      Complex result2 = nonZeroDividend.divide(zeroDivisor);
                                                      assertEquals("Dividing non-zero by zero should return INF", Complex.INF, result2);
                                              
                                                      // Test case 3: divisor is non-zero -> should perform normal division
                                                      Complex nonZeroDivisor = new Complex(2, 2);
                                                      Complex result3 = nonZeroDividend.divide(nonZeroDivisor);
                                                      assertFalse("Dividing by non-zero should not return NaN", result3.isNaN());
                                                      assertFalse("Dividing by non-zero should not return INF", Complex.INF.equals(result3));
                                                  }

 @Test
                                              public void testDivideByZeroVsNonZero() {
                                                  // Create a non-zero complex number (3 + 4i)
                                                  Complex complex = new Complex(3.0, 4.0);
                                                  
                                                  // Test with zero divisor - should return INF (since complex is not zero)
                                                  Complex resultZeroDivisor = complex.divide(0.0);
                                                  assertEquals(Complex.INF, resultZeroDivisor);
                                                  
                                                  // Test with non-zero divisor - should perform normal division
                                                  Complex resultNonZeroDivisor = complex.divide(2.0);
                                                  // Verify normal division occurred (3/2 + 4i/2) = (1.5 + 2i)
                                                  assertEquals(1.5, resultNonZeroDivisor.getReal(), 0.0001);
                                                  assertEquals(2.0, resultNonZeroDivisor.getImaginary(), 0.0001);
                                                  
                                                  // Additional test case: zero complex divided by zero (should return NaN)
                                                  Complex zeroComplex = new Complex(0.0, 0.0);
                                                  Complex resultZeroByZero = zeroComplex.divide(0.0);
                                                  assertEquals(Complex.NaN, resultZeroByZero);
                                              }

 @Test
                                                 public void testDivideWithNonZeroDivisorShouldNotReturnSpecialCaseValues() {
                                                     // Create a non-zero dividend (1 + 1i)
                                                     Complex dividend = new Complex(1.0, 1.0);
                                                     
                                                     // Create a non-zero divisor (2 + 2i)
                                                     Complex divisor = new Complex(2.0, 2.0);
                                                     
                                                     // Perform the division
                                                     Complex result = dividend.divide(divisor);
                                                     
                                                     // Verify the result is not NaN or INF (which would happen with the mutant)
                                                     assertFalse("Result should not be NaN", result.isNaN());
                                                     assertFalse("Result should not be infinite", result.isInfinite());
                                                     
                                                     // Verify the actual division result (0.5 + 0i)
                                                     assertEquals(0.5, result.getReal(), 0.0001);
                                                     assertEquals(0.0, result.getImaginary(), 0.0001);
                                                 }

 @Test
                                                 public void testDivideWithZeroDivisorAndZeroDividendReturnsNaN() {
                                                     // Create zero dividend (0 + 0i)
                                                     Complex dividend = new Complex(0.0, 0.0);
                                                     
                                                     // Create zero divisor (0 + 0i)
                                                     Complex divisor = new Complex(0.0, 0.0);
                                                     
                                                     // Perform the division
                                                     Complex result = dividend.divide(divisor);
                                                     
                                                     // Verify the result is NaN
                                                     assertTrue("0/0 should return NaN", result.isNaN());
                                                 }

 @Test
                                                 public void testDivideWithZeroDivisorAndNonZeroDividendReturnsINF() {
                                                     // Create non-zero dividend (1 + 1i)
                                                     Complex dividend = new Complex(1.0, 1.0);
                                                     
                                                     // Create zero divisor (0 + 0i)
                                                     Complex divisor = new Complex(0.0, 0.0);
                                                     
                                                     // Perform the division
                                                     Complex result = dividend.divide(divisor);
                                                     
                                                     // Verify the result is INF
                                                     assertTrue("x/0 should return INF", result.isInfinite());
                                                 }

 @Test
                                                 public void testDivideByNonZeroShouldNotReturnInfinity() {
                                                     // Create a complex number (3 + 4i)
                                                     Complex complex = new Complex(3.0, 4.0);
                                                     
                                                     // Divide by a non-zero divisor (2)
                                                     Complex result = complex.divide(2.0);
                                                     
                                                     // Verify the result is not INF (which would happen with the mutant)
                                                     assertNotEquals(Complex.INF, result);
                                                     
                                                     // Verify proper division was performed
                                                     assertEquals(1.5, result.getReal(), 0.0001);
                                                     assertEquals(2.0, result.getImaginary(), 0.0001);
                                                 }

 @Test
                                                 public void testDivideByZeroShouldReturnInfinity() {
                                                     // Create a complex number (3 + 4i)
                                                     Complex complex = new Complex(3.0, 4.0);
                                                     
                                                     // Divide by zero
                                                     Complex result = complex.divide(0.0);
                                                     
                                                     // Should return INF
                                                     assertEquals(Complex.INF, result);
                                                 }

 @Test
                                                 public void testDivideZeroByZeroShouldReturnNaN() {
                                                     // Create a zero complex number (0 + 0i)
                                                     Complex complex = new Complex(0.0, 0.0);
                                                     
                                                     // Divide by zero
                                                     Complex result = complex.divide(0.0);
                                                     
                                                     // Should return NaN
                                                     assertEquals(Complex.NaN, result);
                                                 }

 @Test
                                                public void testDivideByZero1() {
                                                    // Test case 1: dividend is zero (0/0)
                                                    Complex zero = new Complex(0, 0);
                                                    Complex result1 = zero.divide(zero);
                                                    assertTrue("0/0 should return NaN", result1.isNaN());
                                                    
                                                    // Test case 2: dividend is non-zero (1+0i / 0+0i)
                                                    Complex nonZero = new Complex(1, 0);
                                                    Complex result2 = nonZero.divide(zero);
                                                    assertTrue("1/0 should return INF", result2.isInfinite());
                                                }

 @Test
                                                public void testDivideByZero2() {
                                                    // Test case 1: isZero = true (0 + 0i)
                                                    Complex zeroComplex = new Complex(0, 0);
                                                    Complex result1 = zeroComplex.divide(0d);
                                                    assertEquals("Dividing zero complex by zero should return NaN", 
                                                                Complex.NaN, result1);
                                                    
                                                    // Test case 2: isZero = false (1 + 1i)
                                                    Complex nonZeroComplex = new Complex(1, 1);
                                                    Complex result2 = nonZeroComplex.divide(0d);
                                                    assertEquals("Dividing non-zero complex by zero should return INF", 
                                                                Complex.INF, result2);
                                                }

 @Test
                                               public void testDivideByZeroWithZeroDividend() {
                                                   // Test case where both dividend and divisor are zero
                                                   Complex zero = new Complex(0, 0);
                                                   Complex result = zero.divide(zero);
                                                   
                                                   // Original: should return NaN when dividend is zero
                                                   // Mutant: would return INF
                                                   assertTrue("Dividing zero by zero should return NaN", 
                                                              result.isNaN());
                                               }

 @Test
                                               public void testDivideByZeroWithNonZeroDividend() {
                                                   // Test case where divisor is zero but dividend is not zero
                                                   Complex dividend = new Complex(1, 1);
                                                   Complex zero = new Complex(0, 0);
                                                   Complex result = dividend.divide(zero);
                                                   
                                                   // Original: should return INF when dividend is non-zero
                                                   // Mutant: would return NaN
                                                   assertTrue("Dividing non-zero by zero should return INF", 
                                                              result.isInfinite());
                                               }

 @Test
                                               public void testDivideByZero_NonZeroComplex() {
                                                   // Test case where complex number is not zero and divisor is zero
                                                   Complex complex = new Complex(1.0, 1.0); // non-zero complex number
                                                   Complex result = complex.divide(0.0);
                                                   assertEquals(Complex.INF, result); // Both original and mutant pass this
                                               }

 @Test
                                               public void testDivideByZero_ZeroComplex() {
                                                   // Test case where complex number is zero and divisor is zero
                                                   // This will catch the mutant
                                                   Complex complex = new Complex(0.0, 0.0); // zero complex number
                                                   Complex result = complex.divide(0.0);
                                                   
                                                   // Original code should return NaN, mutant would return INF
                                                   assertEquals(Complex.NaN, result);
                                                   
                                                   // Additional check to ensure it's not INF (mutant behavior)
                                                   assertNotEquals(Complex.INF, result);
                                               }

 @Test
                                          public void testDivide_InfiniteByInfinite_ShouldNotReturnZero() {
                                              // Create an infinite complex number (1.0/0.0 = infinity)
                                              Complex infinite = new Complex(1.0, 1.0).divide(Complex.ZERO);
                                              
                                              // Verify both numbers are infinite
                                              assertTrue(infinite.isInfinite());
                                              
                                              // Divide infinite by infinite - should not return ZERO with original code
                                              // But mutant would return ZERO because of the OR condition
                                              Complex result = infinite.divide(infinite);
                                              
                                              // Original behavior: Should not be ZERO (might be NaN or something else)
                                              // Mutant behavior: Would return ZERO
                                              assertNotEquals(Complex.ZERO, result);
                                              
                                              // Additional check to ensure proper behavior
                                              assertTrue(result.isNaN()); // Expected actual behavior for infinite/infinite
                                          }

 @Test
                                          public void testDivideByInfiniteWhenComplexIsInfinite() {
                                              // Create an infinite complex number (real part is infinite)
                                              Complex infiniteComplex = new Complex(Double.POSITIVE_INFINITY, 0);
                                              
                                              // Test dividing by infinite divisor
                                              Complex result = infiniteComplex.divide(Double.POSITIVE_INFINITY);
                                              
                                              // Original should return NaN (since complex is infinite)
                                              // Mutant will return ZERO (because !isInfinite() is false but first condition is true)
                                              assertEquals(Complex.NaN, result);
                                              
                                              // Additional verification that we're testing the right case
                                              assertTrue(Double.isInfinite(infiniteComplex.getReal()));
                                              assertTrue(infiniteComplex.isInfinite());
                                          }

 @Test
                                             public void testDivideByInfiniteDivisorWithFiniteComplex() {
                                                 // Create a finite complex number
                                                 Complex finiteComplex = new Complex(2.0, 3.0);
                                                 
                                                 // Divide by positive infinity
                                                 Complex result = finiteComplex.divide(Double.POSITIVE_INFINITY);
                                                 
                                                 // Original behavior: should return ZERO since complex is finite
                                                 // Mutated behavior: will skip this case and try to do division
                                                 assertEquals(Complex.ZERO, result);
                                             }

 @Test
                                             public void testDivideByInfiniteDivisorWithInfiniteComplex() {
                                                 // Create an infinite complex number
                                                 Complex infiniteComplex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                 
                                                 // Divide by positive infinity
                                                 Complex result = infiniteComplex.divide(Double.POSITIVE_INFINITY);
                                                 
                                                 // Both original and mutated should return NaN in this case
                                                 // (though for different code paths in the mutated version)
                                                 assertEquals(Complex.NaN, result);
                                             }

 @Test
                                    public void testDivide_FiniteDividedByInfinite_ShouldReturnZero() {
                                        // Create a finite complex number
                                        Complex finite = new Complex(2.5, 3.5);
                                        
                                        // Create a mock infinite divisor
                                        Complex infiniteDivisor = mock(Complex.class);
                                        when(infiniteDivisor.isNaN()).thenReturn(false);
                                        when(infiniteDivisor.isInfinite()).thenReturn(true);
                                        when(infiniteDivisor.getReal()).thenReturn(Double.POSITIVE_INFINITY);
                                        when(infiniteDivisor.getImaginary()).thenReturn(Double.POSITIVE_INFINITY);
                                        
                                        // Call the method
                                        Complex result = finite.divide(infiniteDivisor);
                                        
                                        // Verify the result should be ZERO (original behavior)
                                        // Mutant would not enter this branch and would try to perform division
                                        assertEquals(Complex.ZERO, result);
                                        
                                        // Verify the interaction with the mock
                                        verify(infiniteDivisor).isNaN();
                                        verify(infiniteDivisor).isInfinite();
                                        // Should not call getReal/getImaginary in original code
                                        verify(infiniteDivisor, never()).getReal();
                                        verify(infiniteDivisor, never()).getImaginary();
                                    }

 @Test
                                public void testDivideFiniteByInfinite() {
                                    // Create a finite complex number (1.0 + 2.0i)
                                    Complex finite = new Complex(1.0, 2.0);
                                    
                                    // Create an infinite complex number (Double.POSITIVE_INFINITY + any imaginary)
                                    Complex infinite = new Complex(Double.POSITIVE_INFINITY, 0.0);
                                    
                                    // Perform the division
                                    Complex result = finite.divide(infinite);
                                    
                                    // Verify the result is ZERO (not null)
                                    assertNotNull("Result should not be null", result);
                                    assertEquals("Real part should be 0", 0.0, result.getReal(), 0.0001);
                                    assertEquals("Imaginary part should be 0", 0.0, result.getImaginary(), 0.0001);
                                    
                                    // Additional checks to ensure it's exactly ZERO
                                    assertSame("Result should be the ZERO constant", Complex.ZERO, result);
                                    
                                    // Verify it's not NaN or INF
                                    assertFalse("Result should not be NaN", result.isNaN());
                                    assertFalse("Result should not be infinite", result.isInfinite());
                                }

 @Test
                                public void testDivideByInfiniteDivisorReturnsZeroNotnull() {
                                    // Create a finite complex number (real=2.0, imaginary=3.0)
                                    Complex complex = new Complex(2.0, 3.0);
                                    
                                    // Divide by infinite divisor
                                    Complex result = complex.divide(Double.POSITIVE_INFINITY);
                                    
                                    // Verify the result is the ZERO constant, not null
                                    assertNotNull("Result should not be null", result);
                                    assertEquals("Result should be ZERO constant", Complex.ZERO, result);
                                    
                                    // Additional verification that it's actually zero
                                    assertEquals(0.0, result.getReal(), 0.0001);
                                    assertEquals(0.0, result.getImaginary(), 0.0001);
                                }

 @Test
                               public void testDivide_FiniteByInfinite_ShouldReturnZero() {
                                   // Create a finite complex number (dividend)
                                   Complex finite = new Complex(3.0, 4.0);  // 3 + 4i
                                   
                                   // Create an infinite complex number (divisor)
                                   Complex infinite = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                                   
                                   // Perform the division
                                   Complex result = finite.divide(infinite);
                                   
                                   // Verify the result is ZERO (not ONE)
                                   assertEquals(Complex.ZERO, result);
                                   
                                   // Additional verification that it's not ONE (direct check against the mutant)
                                   assertNotEquals(Complex.ONE, result);
                                   
                                   // Verify the real and imaginary parts are both 0
                                   assertEquals(0.0, result.getReal(), 0.0001);
                                   assertEquals(0.0, result.getImaginary(), 0.0001);
                               }

 @Test
                               public void testDivideByInfiniteDivisorReturnsZero() {
                                   // Create a finite complex number (not infinite)
                                   Complex complex = new Complex(5.0, 3.0);
                                   
                                   // Divide by positive infinity
                                   Complex result = complex.divide(Double.POSITIVE_INFINITY);
                                   
                                   // Verify the result is ZERO (0 + 0i) not ONE (1 + 0i)
                                   assertEquals(0.0, result.getReal(), 0.0001);
                                   assertEquals(0.0, result.getImaginary(), 0.0001);
                                   
                                   // Also test with negative infinity
                                   Complex resultNeg = complex.divide(Double.NEGATIVE_INFINITY);
                                   assertEquals(0.0, resultNeg.getReal(), 0.0001);
                                   assertEquals(0.0, resultNeg.getImaginary(), 0.0001);
                               }

 @Test
                              public void testDivideDetectsRealImaginarySwapMutant() {
                                  // Create a complex number where real and imaginary parts are different
                                  // and abs(real) > abs(imaginary) to test the else branch
                                  Complex dividend = new Complex(4.0, 3.0);  // 4 + 3i
                                  Complex divisor = new Complex(5.0, 1.0);   // 5 + 1i (abs(5) > abs(1))
                                  
                                  // Expected result calculation (using correct formula):
                                  // (4 + 3i)/(5 + 1i) = [(4*5 + 3*1) + (3*5 - 4*1)i] / (5² + 1²)
                                  // = (23 + 11i)/26 ≈ (0.8846 + 0.4231i)
                                  Complex expected = new Complex(23.0/26.0, 11.0/26.0);
                                  
                                  // Actual result from original code
                                  Complex actual = dividend.divide(divisor);
                                  
                                  // Verify both real and imaginary parts with delta for floating point precision
                                  assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                                  assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                                  
                                  // The mutant would calculate using swapped real/imaginary in the else branch,
                                  // leading to completely different results that wouldn't match expected values
                              }

 @Test
                              public void testDivideWithDifferentRealAndImaginaryParts() {
                                  // Create a complex number with different real and imaginary parts
                                  Complex dividend = new Complex(4.0, 8.0);  // 4 + 8i
                                  Complex divisor = new Complex(2.0, 4.0);   // 2 + 4i
                                  
                                  // Expected result calculation:
                                  // (4 + 8i) / (2 + 4i) = [(4*2 + 8*4) + i(8*2 - 4*4)] / (2² + 4²)
                                  // = (8 + 32 + i(16 - 16)) / (4 + 16)
                                  // = (40 + 0i) / 20 = 2 + 0i
                                  
                                  Complex result = dividend.divide(divisor);
                                  
                                  // Verify real and imaginary parts separately with delta for floating point precision
                                  assertEquals(2.0, result.getReal(), 1e-15);
                                  assertEquals(0.0, result.getImaginary(), 1e-15);
                                  
                                  // Also test with swapped values to ensure the mutation is caught
                                  Complex dividend2 = new Complex(8.0, 4.0);  // 8 + 4i
                                  Complex divisor2 = new Complex(4.0, 2.0);   // 4 + 2i
                                  
                                  // Expected result calculation:
                                  // (8 + 4i) / (4 + 2i) = [(8*4 + 4*2) + i(4*4 - 8*2)] / (4² + 2²)
                                  // = (32 + 8 + i(16 - 16)) / (16 + 4)
                                  // = (40 + 0i) / 20 = 2 + 0i
                                  
                                  Complex result2 = dividend2.divide(divisor2);
                                  assertEquals(2.0, result2.getReal(), 1e-15);
                                  assertEquals(0.0, result2.getImaginary(), 1e-15);
                              }

 @Test
                             public void testDivide_DetectRealPartZeroMutation() {
                                 // Create a complex number where real part is larger than imaginary part
                                 Complex dividend = new Complex(4.0, 3.0);  // 4 + 3i
                                 Complex divisor = new Complex(2.0, 1.0);   // 2 + i (real part > imaginary part)
                                 
                                 // Expected result: (4 + 3i)/(2 + i) = (11 + 2i)/5 = 2.2 + 0.4i
                                 Complex expected = new Complex(2.2, 0.4);
                                 
                                 // Actual result
                                 Complex result = dividend.divide(divisor);
                                 
                                 // Verify both real and imaginary parts
                                 assertEquals(expected.getReal(), result.getReal(), 1e-10);
                                 assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                                 
                                 // The mutant would incorrectly calculate using c=0.0, taking the wrong branch
                                 // and producing wrong results
                             }

 @Test
                             public void testDivideByNonZeroRealDetectsMutant() {
                                 // Create a complex number (3 + 4i)
                                 Complex complex = new Complex(3.0, 4.0);
                                 
                                 // Test division by 2.0 - should be (1.5 + 2i)
                                 Complex result = complex.divide(2.0);
                                 
                                 // With the mutation (dividing by 0.0), we'd get:
                                 // real/0.0 = Infinity, imaginary/0.0 = Infinity
                                 // So we'd expect INF instead of (1.5 + 2i)
                                 
                                 // Verify real part
                                 assertEquals(1.5, result.getReal(), 0.0001);
                                 // Verify imaginary part
                                 assertEquals(2.0, result.getImaginary(), 0.0001);
                                 
                                 // Also verify it's not infinite (which would be the mutant case)
                                 assertFalse(Double.isInfinite(result.getReal()));
                                 assertFalse(Double.isInfinite(result.getImaginary()));
                                 
                                 // And verify it's not NaN
                                 assertFalse(Double.isNaN(result.getReal()));
                                 assertFalse(Double.isNaN(result.getImaginary()));
                             }

 @Test
                            public void testDivideWithImaginaryDominantDivisor() {
                                // Create a complex number where imaginary part is larger than real part
                                Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
                                Complex divisor = new Complex(1.0, 5.0);   // 1 + 5i (imaginary part dominates)
                                
                                // Expected result calculation for (3 + 4i)/(1 + 5i)
                                // Using complex division formula: (a+bi)/(c+di) = [(ac+bd)/(c²+d²)] + [(bc-ad)/(c²+d²)]i
                                double c = 1.0, d = 5.0;
                                double denominator = c*c + d*d;
                                double expectedReal = (3.0*c + 4.0*d)/denominator;      // (3*1 + 4*5)/26 = 23/26 ≈ 0.8846
                                double expectedImaginary = (4.0*c - 3.0*d)/denominator; // (4*1 - 3*5)/26 = -11/26 ≈ -0.4231
                                
                                Complex result = dividend.divide(divisor);
                                
                                // Verify both real and imaginary parts with delta for floating point precision
                                assertEquals("Real part of division is incorrect", expectedReal, result.getReal(), 1e-10);
                                assertEquals("Imaginary part of division is incorrect", expectedImaginary, result.getImaginary(), 1e-10);
                                
                                // Additional test case with different values
                                Complex dividend2 = new Complex(2.0, 3.0);  // 2 + 3i
                                Complex divisor2 = new Complex(0.5, 2.0);  // 0.5 + 2i
                                
                                // Expected result for (2 + 3i)/(0.5 + 2i)
                                c = 0.5; d = 2.0;
                                denominator = c*c + d*d;
                                expectedReal = (2.0*c + 3.0*d)/denominator;      // (1 + 6)/4.25 ≈ 1.647
                                expectedImaginary = (3.0*c - 2.0*d)/denominator; // (1.5 - 4)/4.25 ≈ -0.588
                                
                                result = dividend2.divide(divisor2);
                                assertEquals("Real part of second division is incorrect", expectedReal, result.getReal(), 1e-10);
                                assertEquals("Imaginary part of second division is incorrect", expectedImaginary, result.getImaginary(), 1e-10);
                            }

 @Test
                            public void testDivideComplexDetectsMutant() {
                                // Create a complex number to be divided (3 + 4i)
                                Complex dividend = new Complex(3.0, 4.0);
                                
                                // Create a complex divisor where real and imaginary parts are different (1 + 2i)
                                Complex divisor = new Complex(1.0, 2.0);
                                
                                // Perform the division
                                Complex result = dividend.divide(divisor);
                                
                                // Verify the calculation is correct
                                // Expected result is (3*1 + 4*2)/(1² + 2²) + (4*1 - 3*2)/(1² + 2²)i
                                // = (3 + 8)/5 + (4 - 6)/5 i = 11/5 - 2/5 i = 2.2 - 0.4i
                                assertEquals(2.2, result.getReal(), 0.0001);
                                assertEquals(-0.4, result.getImaginary(), 0.0001);
                                
                                // This test would fail with the mutant because:
                                // Mutant would use divisor.getReal() (1.0) for both parts
                                // Incorrect calculation would be: (3/1 + 4/1) + (4/1 - 3/1)i = 7 + 1i
                            }

 @Test
                               public void testDivideWithNonZeroImaginaryDivisor() {
                                   // Create a complex number with significant imaginary part (3 + 4i)
                                   Complex dividend = new Complex(1, 1);
                                   Complex divisor = new Complex(3, 4);
                                   
                                   // Expected result calculated manually:
                                   // (1 + i)/(3 + 4i) = (1*3 + 1*4)/(3² + 4²) + (1*4 - 1*3)/(3² + 4²)i
                                   // = (3 + 4)/25 + (4 - 3)/25 i = 7/25 + 1/25 i
                                   double expectedReal = 7.0/25.0;
                                   double expectedImaginary = 1.0/25.0;
                                   
                                   Complex result = dividend.divide(divisor);
                                   
                                   // Verify both real and imaginary parts
                                   assertEquals("Real part of division is incorrect", 
                                       expectedReal, result.getReal(), 1e-10);
                                   assertEquals("Imaginary part of division is incorrect", 
                                       expectedImaginary, result.getImaginary(), 1e-10);
                                   
                                   // Test case where imaginary part is smaller than real part but non-zero
                                   Complex divisor2 = new Complex(4, 3);
                                   // (1 + i)/(4 + 3i) = (1*4 + 1*3)/25 + (1*3 - 1*4)/25 i = 7/25 - 1/25 i
                                   expectedReal = 7.0/25.0;
                                   expectedImaginary = -1.0/25.0;
                                   
                                   result = dividend.divide(divisor2);
                                   
                                   assertEquals("Real part of division is incorrect for second case", 
                                       expectedReal, result.getReal(), 1e-10);
                                   assertEquals("Imaginary part of division is incorrect for second case", 
                                       expectedImaginary, result.getImaginary(), 1e-10);
                                   
                                   // Test case with equal real and imaginary parts
                                   Complex divisor3 = new Complex(1, 1);
                                   // (1 + i)/(1 + i) = 1 + 0i
                                   expectedReal = 1.0;
                                   expectedImaginary = 0.0;
                                   
                                   result = dividend.divide(divisor3);
                                   
                                   assertEquals("Real part of division is incorrect for equal parts", 
                                       expectedReal, result.getReal(), 1e-10);
                                   assertEquals("Imaginary part of division is incorrect for equal parts", 
                                       expectedImaginary, result.getImaginary(), 1e-10);
                               }

 @Test
                           public void testDivideByComplexWithImaginaryPart() {
                               // Setup - create complex numbers with non-zero imaginary parts
                               Complex dividend = new Complex(4.0, 6.0);  // 4 + 6i
                               Complex divisor = new Complex(1.0, 2.0);   // 1 + 2i
                               
                               // Expected result: (4+6i)/(1+2i) = [(4*1 + 6*2) + i(6*1 - 4*2)] / (1² + 2²)
                               //                 = (16 - 2i)/5 = 3.2 - 0.4i
                               double expectedReal = 3.2;
                               double expectedImaginary = -0.4;
                               
                               // Execute
                               Complex result = dividend.divide(divisor);
                               
                               // Verify
                               assertEquals("Real part should be correctly calculated", 
                                            expectedReal, result.getReal(), 0.0001);
                               assertEquals("Imaginary part should be correctly calculated",
                                            expectedImaginary, result.getImaginary(), 0.0001);
                               
                               // Additional check for mutation that ignores imaginary part
                               // If mutation exists, result would be (4/1 + 6i/1) = 4 + 6i
                               assertNotEquals("Should not equal result ignoring imaginary part", 
                                              4.0, result.getReal(), 0.0001);
                               assertNotEquals("Should not equal result ignoring imaginary part",
                                              6.0, result.getImaginary(), 0.0001);
                           }

 @Test
                              public void testDivideDetectsAbsConditionMutant() {
                                  // Case where |c| < |d| (1 < 2)
                                  Complex dividend = new Complex(3, 4);  // 3 + 4i
                                  Complex divisor1 = new Complex(1, 2);   // 1 + 2i (|1| < |2|)
                                  
                                  // Original would take first branch, mutant would take second
                                  Complex result1 = dividend.divide(divisor1);
                                  
                                  // Expected result calculated manually using correct formula
                                  // (3 + 4i)/(1 + 2i) = [(3*1 + 4*2)/(1² + 2²)] + [(4*1 - 3*2)/(1² + 2²)]i
                                  // = (3 + 8)/5 + (4 - 6)/5 i = 11/5 - 2/5 i = 2.2 - 0.4i
                                  double expectedReal1 = 2.2;
                                  double expectedImaginary1 = -0.4;
                                  assertEquals(expectedReal1, result1.getReal(), 1e-10);
                                  assertEquals(expectedImaginary1, result1.getImaginary(), 1e-10);
                                  
                                  // Case where |c| > |d| (2 > 1)
                                  Complex divisor2 = new Complex(2, 1);   // 2 + 1i (|2| > |1|)
                                  
                                  // Original would take second branch, mutant would take first
                                  Complex result2 = dividend.divide(divisor2);
                                  
                                  // Expected result calculated manually using correct formula
                                  // (3 + 4i)/(2 + 1i) = [(3*2 + 4*1)/(2² + 1²)] + [(4*2 - 3*1)/(2² + 1²)]i
                                  // = (6 + 4)/5 + (8 - 3)/5 i = 10/5 + 5/5 i = 2 + 1i
                                  double expectedReal2 = 2.0;
                                  double expectedImaginary2 = 1.0;
                                  assertEquals(expectedReal2, result2.getReal(), 1e-10);
                                  assertEquals(expectedImaginary2, result2.getImaginary(), 1e-10);
                                  
                                  // Case where |c| = |d| (1 = 1)
                                  Complex divisor3 = new Complex(1, 1);   // 1 + 1i (|1| = |1|)
                                  
                                  // Both original and mutant would take second branch
                                  Complex result3 = dividend.divide(divisor3);
                                  
                                  // Expected result calculated manually using correct formula
                                  // (3 + 4i)/(1 + 1i) = [(3*1 + 4*1)/(1² + 1²)] + [(4*1 - 3*1)/(1² + 1²)]i
                                  // = (3 + 4)/2 + (4 - 3)/2 i = 7/2 + 1/2 i = 3.5 + 0.5i
                                  double expectedReal3 = 3.5;
                                  double expectedImaginary3 = 0.5;
                                  assertEquals(expectedReal3, result3.getReal(), 1e-10);
                                  assertEquals(expectedImaginary3, result3.getImaginary(), 1e-10);
                              }

 @Test
                              public void testDivideWithDifferentMagnitudes() {
                                  // Case where |real| < |imaginary|
                                  Complex c1 = new Complex(1.0, 10.0);
                                  Complex result1 = c1.divide(2.0);
                                  assertEquals(0.5, result1.getReal(), 1e-10);
                                  assertEquals(5.0, result1.getImaginary(), 1e-10);
                                  
                                  // Case where |real| > |imaginary|
                                  Complex c2 = new Complex(10.0, 1.0);
                                  Complex result2 = c2.divide(2.0);
                                  assertEquals(5.0, result2.getReal(), 1e-10);
                                  assertEquals(0.5, result2.getImaginary(), 1e-10);
                                  
                                  // Case where |real| == |imaginary|
                                  Complex c3 = new Complex(3.0, 3.0);
                                  Complex result3 = c3.divide(3.0);
                                  assertEquals(1.0, result3.getReal(), 1e-10);
                                  assertEquals(1.0, result3.getImaginary(), 1e-10);
                              }

 @Test
                              public void testDivideEdgeCases() {
                                  // Test NaN cases
                                  Complex nan = new Complex(Double.NaN, 1.0);
                                  assertEquals(Complex.NaN, nan.divide(2.0));
                                  
                                  Complex nanDivisor = new Complex(1.0, 1.0);
                                  assertEquals(Complex.NaN, nanDivisor.divide(Double.NaN));
                                  
                                  // Test division by zero
                                  Complex nonZero = new Complex(1.0, 1.0);
                                  assertEquals(Complex.INF, nonZero.divide(0.0));
                                  
                                  Complex zero = new Complex(0.0, 0.0);
                                  assertEquals(Complex.NaN, zero.divide(0.0));
                                  
                                  // Test division by infinity
                                  Complex finite = new Complex(1.0, 1.0);
                                  assertEquals(Complex.ZERO, finite.divide(Double.POSITIVE_INFINITY));
                                  
                                  Complex infinite = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                  assertEquals(Complex.NaN, infinite.divide(Double.POSITIVE_INFINITY));
                              }

 @Test
                         public void testDivideWhenAbsoluteValuesAreEqual() {
                             // Create a complex number where real and imaginary parts have equal absolute values
                             Complex dividend = new Complex(4.0, 3.0);  // Any non-zero complex number
                             Complex divisor = new Complex(1.0, 1.0);   // |1.0| == |1.0|
                             
                             // Expected result calculated manually using the else branch (original behavior)
                             // Since |1.0| == |1.0|, original code would take else branch
                             double q = 1.0 / 1.0;  // d/c
                             double denominator = 1.0 * q + 1.0;  // d*q + c
                             double expectedReal = (3.0 * q + 4.0) / denominator;
                             double expectedImaginary = (3.0 - 4.0 * q) / denominator;
                             Complex expected = new Complex(expectedReal, expectedImaginary);
                             
                             // Actual result
                             Complex actual = dividend.divide(divisor);
                             
                             // Verify
                             assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                             assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                             
                             // Also test with negative values to ensure absolute value comparison works
                             Complex divisorNeg = new Complex(-2.0, 2.0);  // |-2.0| == |2.0|
                             q = 2.0 / -2.0;  // d/c
                             denominator = 2.0 * q + -2.0;  // d*q + c
                             expectedReal = (3.0 * q + 4.0) / denominator;
                             expectedImaginary = (3.0 - 4.0 * q) / denominator;
                             expected = new Complex(expectedReal, expectedImaginary);
                             
                             actual = dividend.divide(divisorNeg);
                             assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                             assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                         }

 @Test
                         public void testDivideWithEqualMagnitudeComponents() {
                             // Create complex number where real and imaginary have same absolute value
                             Complex c1 = new Complex(3.0, -3.0);  // |3| == |-3|
                             Complex c2 = new Complex(-4.0, 4.0); // |-4| == |4|
                             
                             // Test division by a scalar where the boundary condition would be triggered
                             double divisor = 2.0;
                             
                             // Expected behavior (original code): 
                             // When magnitudes are equal, original code would use one branch
                             Complex result1 = c1.divide(divisor);
                             assertEquals(1.5, result1.getReal(), 1e-10);
                             assertEquals(-1.5, result1.getImaginary(), 1e-10);
                             
                             Complex result2 = c2.divide(divisor);
                             assertEquals(-2.0, result2.getReal(), 1e-10);
                             assertEquals(2.0, result2.getImaginary(), 1e-10);
                             
                             // Additional test with different equal magnitudes
                             Complex c3 = new Complex(5.0, 5.0);
                             Complex result3 = c3.divide(divisor);
                             assertEquals(2.5, result3.getReal(), 1e-10);
                             assertEquals(2.5, result3.getImaginary(), 1e-10);
                             
                             // Test with zero case (0,0) which should be handled by isZero
                             Complex zero = Complex.ZERO;
                             Complex result4 = zero.divide(divisor);
                             assertEquals(0.0, result4.getReal(), 1e-10);
                             assertEquals(0.0, result4.getImaginary(), 1e-10);
                         }

 @Test
                        public void testDivide_DetectsMultiplicationMutant() {
                            // Create a complex number where |real| < |imaginary| in divisor
                            Complex dividend = new Complex(4.0, 3.0);  // 4 + 3i
                            Complex divisor = new Complex(1.0, 2.0);   // 1 + 2i (|1| < |2|)
                            
                            // Expected result calculation (correct division):
                            // (4 + 3i)/(1 + 2i) = [(4*1 + 3*2) + (3*1 - 4*2)i]/(1² + 2²) = (10 -5i)/5 = 2 - i
                            Complex expected = new Complex(2.0, -1.0);
                            
                            // Actual result (with mutant q = c*d instead of c/d):
                            // q would be 1*2=2 instead of 1/2=0.5
                            // denominator would be 1*2 + 2 = 4 instead of 1*0.5 + 2 = 2.5
                            // real part would be (4*2 + 3)/4 = 11/4 = 2.75 (wrong)
                            // imaginary part would be (3*2 - 4)/4 = 2/4 = 0.5 (wrong)
                            // So we'd get 2.75 + 0.5i instead of 2 - i
                            
                            Complex result = dividend.divide(divisor);
                            
                            // Verify both real and imaginary parts
                            assertEquals(expected.getReal(), result.getReal(), 1e-10);
                            assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                        }

 @Test
                        public void testDivideByDoubleDetectsMultiplicationMutant() {
                            // Create a complex number with real=4.0 and imaginary=6.0
                            Complex complex = new Complex(4.0, 6.0);
                            
                            // Divide by 2.0 - should result in (2.0, 3.0)
                            Complex result = complex.divide(2.0);
                            
                            // Verify real part (4.0/2.0=2.0, mutant would do 4.0*2.0=8.0)
                            assertEquals(2.0, result.getReal(), 0.0001);
                            
                            // Verify imaginary part (6.0/2.0=3.0, mutant would do 6.0*2.0=12.0)
                            assertEquals(3.0, result.getImaginary(), 0.0001);
                            
                            // Also test with negative divisor
                            Complex negativeResult = complex.divide(-2.0);
                            assertEquals(-2.0, negativeResult.getReal(), 0.0001);
                            assertEquals(-3.0, negativeResult.getImaginary(), 0.0001);
                        }

 @Test
                       public void testDivideWithSmallerRealPart() {
                           // Create a complex number where real part is smaller than imaginary part
                           Complex dividend = new Complex(4.0, 3.0);  // 4 + 3i
                           Complex divisor = new Complex(1.0, 2.0);  // 1 + 2i (abs(1) < abs(2))
                           
                           // Expected result calculation (using correct formula):
                           // q = c/d = 1/2 = 0.5
                           // denominator = c*q + d = 1*0.5 + 2 = 2.5
                           // real part = (4*0.5 + 3)/2.5 = (2+3)/2.5 = 2.0
                           // imag part = (3*0.5 - 4)/2.5 = (1.5-4)/2.5 = -1.0
                           Complex expected = new Complex(2.0, -1.0);
                           
                           // Mutant would calculate:
                           // q = d/c = 2/1 = 2.0
                           // denominator = c*q + d = 1*2 + 2 = 4.0
                           // real part = (4*2 + 3)/4 = (8+3)/4 = 2.75
                           // imag part = (3*2 - 4)/4 = (6-4)/4 = 0.5
                           // So mutant would return (2.75, 0.5) which is different from expected
                           
                           Complex result = dividend.divide(divisor);
                           
                           assertEquals("Real part not equal", expected.getReal(), result.getReal(), 0.0001);
                           assertEquals("Imaginary part not equal", expected.getImaginary(), result.getImaginary(), 0.0001);
                       }

 @Test
                       public void testDivideDetectsDivisionMutation() {
                           // Create a complex number with distinct real and imaginary parts
                           Complex complex = new Complex(4.0, 2.0);
                           double divisor = 2.0;
                           
                           // Test the division operation
                           Complex result = complex.divide(divisor);
                           
                           // Verify both real and imaginary parts are correctly divided
                           // Original: 4.0/2.0 = 2.0, mutated would be 2.0/4.0 = 0.5
                           assertEquals(2.0, result.getReal(), 0.0001);
                           // Original: 2.0/2.0 = 1.0, mutated would be 2.0/2.0 = 1.0 (same in this case)
                           assertEquals(1.0, result.getImaginary(), 0.0001);
                           
                           // Additional test with different values to catch imaginary part mutation
                           Complex complex2 = new Complex(3.0, 6.0);
                           double divisor2 = 3.0;
                           Complex result2 = complex2.divide(divisor2);
                           
                           // Original: 3.0/3.0 = 1.0, mutated would be 3.0/3.0 = 1.0 (same)
                           assertEquals(1.0, result2.getReal(), 0.0001);
                           // Original: 6.0/3.0 = 2.0, mutated would be 3.0/6.0 = 0.5
                           assertEquals(2.0, result2.getImaginary(), 0.0001);
                       }

 @Test
                      public void testDivide_DetectDenominatorMutation() {
                          // Create test case where abs(c) < abs(d) to trigger the mutated branch
                          // Using (1+2i)/(3+4i) as test case since 3 < 4
                          
                          // Expected calculation:
                          // q = c/d = 3/4 = 0.75
                          // Original denominator: c*q + d = 3*0.75 + 4 = 6.25
                          // Mutated denominator: c*q - d = 3*0.75 - 4 = -1.75
                          // Real part: (real*q + imaginary)/denominator = (1*0.75 + 2)/6.25 = 0.44
                          // Imaginary part: (imaginary*q - real)/denominator = (2*0.75 - 1)/6.25 = 0.08
                          
                          Complex dividend = new Complex(1, 2);  // 1 + 2i
                          Complex divisor = new Complex(3, 4);   // 3 + 4i
                          
                          Complex result = dividend.divide(divisor);
                          
                          // Verify real and imaginary parts with delta for floating point precision
                          assertEquals(0.44, result.getReal(), 0.0001);
                          assertEquals(0.08, result.getImaginary(), 0.0001);
                          
                          // The mutant would calculate:
                          // Real part: (1*0.75 + 2)/-1.75 ≈ -1.5714
                          // Imaginary part: (2*0.75 - 1)/-1.75 ≈ -0.2857
                          // So the assertions would fail for the mutant
                      }

 @Test
                      public void testDivideComplexNumbersDetectsDenominatorMutation() {
                          // Create two complex numbers with non-zero imaginary parts
                          Complex a = new Complex(3.0, 4.0);  // 3 + 4i
                          Complex b = new Complex(1.0, 2.0);  // 1 + 2i
                          
                          // Expected result calculation (using correct denominator formula)
                          // (3 + 4i)/(1 + 2i) = [(3*1 + 4*2) + (4*1 - 3*2)i] / (1² + 2²) = (11 - 2i)/5
                          Complex expected = new Complex(11.0/5.0, -2.0/5.0);
                          
                          // Actual result
                          Complex result = a.divide(b);
                          
                          // Verify real and imaginary parts separately
                          assertEquals(expected.getReal(), result.getReal(), 1e-10);
                          assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                          
                          // Also test with swapped numbers to ensure full coverage
                          Complex c = new Complex(5.0, -3.0);  // 5 - 3i
                          Complex d = new Complex(2.0, 1.0);   // 2 + i
                          
                          // Expected: (5 - 3i)/(2 + i) = [(5*2 + (-3)*1) + (-3*2 - 5*1)i] / (4 + 1) = (7 - 11i)/5
                          expected = new Complex(7.0/5.0, -11.0/5.0);
                          result = c.divide(d);
                          
                          assertEquals(expected.getReal(), result.getReal(), 1e-10);
                          assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                      }

 @Test
                     public void testDivideComplexDetectsMutant1() {
                         // Create complex numbers where c*q + d != c + q*d
                         // Let's choose c=2, q=3, d=4 (real parts)
                         // Original denominator: 2*3 + 4 = 10
                         // Mutated denominator: 2 + 3*4 = 14
                         Complex dividend = new Complex(2, 5);  // real=2, imaginary=5
                         Complex divisor = new Complex(3, 4);   // real=3, imaginary=4
                         
                         // Expected result calculation:
                         // Original formula:
                         // numerator = (2*3 + 5*4) + i(5*3 - 2*4) = (6+20) + i(15-8) = 26 + 7i
                         // denominator = 3*3 + 4*4 = 9 + 16 = 25
                         // result = (26/25) + i(7/25) = 1.04 + 0.28i
                         
                         // Mutated formula would calculate denominator differently
                         Complex result = dividend.divide(divisor);
                         
                         // Verify real part
                         assertEquals(1.04, result.getReal(), 0.0001);
                         // Verify imaginary part
                         assertEquals(0.28, result.getImaginary(), 0.0001);
                         
                         // The mutant would produce:
                         // denominator = 3 + 3*4 = 15 (wrong)
                         // result = 26/15 + 7i/15 = 1.733... + 0.466...i
                         // which would fail the assertions
                     }

 @Test
                    public void testDivide_DenominatorCalculationPrecision() {
                        // Setup values where c is very small compared to d
                        // This will trigger the first branch (FastMath.abs(c) < FastMath.abs(d))
                        double real = 1.0;
                        double imaginary = 1.0;
                        Complex dividend = new Complex(real, imaginary);
                        
                        // Choose values where c is very small compared to d
                        // and where the order of operations affects floating point precision
                        double c = 1.0e-20;
                        double d = 1.0e+20;
                        Complex divisor = new Complex(c, d);
                        
                        // Calculate expected denominator with original operation order
                        double q = c / d;  // q will be 1.0e-40
                        double expectedDenominator = c * q + d;  // Original: (1e-20 * 1e-40) + 1e20
                        double mutatedDenominator = c + q * d;   // Mutated: 1e-20 + (1e-40 * 1e20)
                        
                        // The two calculations should give different results due to floating point precision
                        assertFalse("The mutation should produce different denominator due to floating point precision",
                            Math.abs(expectedDenominator - mutatedDenominator) < 1.0e-30);
                        
                        // Now test the actual division
                        Complex result = dividend.divide(divisor);
                        
                        // Calculate expected result using original denominator calculation
                        double expectedReal = (real * q + imaginary) / expectedDenominator;
                        double expectedImaginary = (imaginary * q - real) / expectedDenominator;
                        
                        assertEquals("Real part should match expected calculation", 
                            expectedReal, result.getReal(), 1.0e-30);
                        assertEquals("Imaginary part should match expected calculation", 
                            expectedImaginary, result.getImaginary(), 1.0e-30);
                    }

 @Test
                public void testDivide_FirstBranch_DetectsSignMutation() {
                    // Setup - create complex numbers that will trigger the first branch (|c| < |d|)
                    // divisor has |real| < |imaginary|
                    Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
                    Complex divisor = new Complex(1.0, 2.0);   // 1 + 2i (|1| < |2|)
                    
                    // Expected result calculation:
                    // (3 + 4i)/(1 + 2i) = [(3*1 + 4*2)/(1² + 2²)] + [(4*1 - 3*2)/(1² + 2²)]i
                    // = [(3 + 8)/5] + [(4 - 6)/5]i = (11/5) + (-2/5)i = 2.2 - 0.4i
                    
                    // Act
                    Complex result = dividend.divide(divisor);
                    
                    // Assert - verify both real and imaginary parts
                    assertEquals(2.2, result.getReal(), 1e-10);       // 11/5 = 2.2
                    assertEquals(-0.4, result.getImaginary(), 1e-10); // -2/5 = -0.4
                    
                    // The mutant would calculate real part as (3*0.5 - 4)/2.5 = (1.5-4)/2.5 = -1.0
                    // which would fail the first assertion
                }

 @Test
                public void testDivideDetectsSignChangeMutant() {
                    // Create a complex number with both real and imaginary parts
                    Complex complex = new Complex(4.0, 2.0);
                    double divisor = 2.0;
                    
                    // Expected result after division: (4 + 2i)/2 = 2 + 1i
                    Complex expected = new Complex(2.0, 1.0);
                    
                    // Actual result
                    Complex result = complex.divide(divisor);
                    
                    // Verify both real and imaginary parts
                    assertEquals("Real part should be 2.0", expected.getReal(), result.getReal(), 0.0001);
                    assertEquals("Imaginary part should be 1.0", expected.getImaginary(), result.getImaginary(), 0.0001);
                    
                    // Additional verification using equals() if implemented properly
                    assertEquals("Divided complex number should equal expected", expected, result);
                }

 @Test
               public void testDivide_DetectsMutantInRealPartCalculation() {
                   // Setup test case where |c| < |d| and both numbers have non-zero parts
                   Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
                   Complex divisor = new Complex(1.0, 2.0);   // 1 + 2i (|1| < |2|)
                   
                   // Calculate expected result manually using correct formula
                   double q = 1.0 / 2.0;  // c/d
                   double denominator = 1.0 * q + 2.0;
                   double expectedReal = (3.0 * q + 4.0) / denominator;
                   double expectedImaginary = (4.0 * q - 3.0) / denominator;
                   
                   // Perform the division
                   Complex result = dividend.divide(divisor);
                   
                   // Verify both real and imaginary parts
                   assertEquals("Real part should match expected calculation", 
                                expectedReal, result.getReal(), 1e-10);
                   assertEquals("Imaginary part should match expected calculation",
                                expectedImaginary, result.getImaginary(), 1e-10);
                   
                   // The mutant would calculate real part as (3.0 + 0.5*4.0)/denominator = 5.0/2.5 = 2.0
                   // While correct is (3.0*0.5 + 4.0)/2.5 = 5.5/2.5 = 2.2
                   // So this test would fail with the mutant
               }

 @Test
               public void testDivideDetectsMutatedComplexDivision() {
                   // Create a complex number with distinct real and imaginary parts
                   Complex complex = new Complex(4.0, 2.0);
                   double divisor = 2.0;
                   
                   // Expected result: (4.0/2.0, 2.0/2.0) = (2.0, 1.0)
                   Complex expected = new Complex(2.0, 1.0);
                   
                   // Actual result (would be wrong with mutation)
                   Complex result = complex.divide(divisor);
                   
                   // Verify both components separately to catch the mutation
                   assertEquals("Real part division incorrect", 
                               expected.getReal(), result.getReal(), 0.0001);
                   assertEquals("Imaginary part division incorrect", 
                               expected.getImaginary(), result.getImaginary(), 0.0001);
                   
                   // Also test with another case where real != imaginary
                   Complex complex2 = new Complex(6.0, 3.0);
                   Complex expected2 = new Complex(3.0, 1.5);
                   Complex result2 = complex2.divide(2.0);
                   
                   assertEquals("Real part division incorrect in second test", 
                               expected2.getReal(), result2.getReal(), 0.0001);
                   assertEquals("Imaginary part division incorrect in second test", 
                               expected2.getImaginary(), result2.getImaginary(), 0.0001);
               }

 @Test
              public void testDivide_DetectsMultiplicationMutant1() {
                  // Setup test case where |c| >= |d| (real part >= imaginary part in divisor)
                  Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
                  Complex divisor = new Complex(2.0, 1.0);   // 2 + i
                  
                  // Expected result: (3+4i)/(2+i) = [(3*2 + 4*1) + (4*2 - 3*1)i] / (2² + 1²)
                  //                 = (10 + 5i)/5 = 2 + i
                  Complex expected = new Complex(2.0, 1.0);
                  
                  // Actual result (with mutant q = d*c instead of d/c)
                  // Mutant would compute q = 1*2 = 2 instead of 1/2 = 0.5
                  // Then denominator = 1*2 + 2 = 4 (wrong)
                  // Result would be [(4*2 + 3)/4, (4 - 3*2)/4] = [11/4, -2/4] = [2.75, -0.5]
                  // Which is different from expected 2 + i
                  
                  Complex result = dividend.divide(divisor);
                  
                  // Verify both real and imaginary parts
                  assertEquals(expected.getReal(), result.getReal(), 1e-10);
                  assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                  
                  // Additional test case with larger difference between c and d
                  Complex dividend2 = new Complex(5.0, 3.0);
                  Complex divisor2 = new Complex(4.0, 0.5);  // |4| > |0.5|
                  
                  // Expected: (5+3i)/(4+0.5i) = [(5*4 + 3*0.5) + (3*4 - 5*0.5)i]/(16 + 0.25)
                  //           = (21.5 + 9.5i)/16.25 ≈ 1.323 + 0.5846i
                  Complex expected2 = new Complex(1.323076923076923, 0.5846153846153846);
                  Complex result2 = dividend2.divide(divisor2);
                  
                  assertEquals(expected2.getReal(), result2.getReal(), 1e-10);
                  assertEquals(expected2.getImaginary(), result2.getImaginary(), 1e-10);
              }

 @Test
              public void testDivideByRealNumberDetectsMultiplicationMutant() {
                  // Create a complex number (4 + 8i)
                  Complex complex = new Complex(4.0, 8.0);
                  double divisor = 2.0;
                  
                  // Test division - should be (2 + 4i)
                  Complex result = complex.divide(divisor);
                  
                  // Verify real part (4/2=2, not 4*2=8)
                  assertEquals(2.0, result.getReal(), 0.0001);
                  
                  // Verify imaginary part (8/2=4, not 8*2=16)
                  assertEquals(4.0, result.getImaginary(), 0.0001);
                  
                  // Also verify with another test case to be thorough
                  Complex complex2 = new Complex(9.0, 3.0);
                  double divisor2 = 3.0;
                  Complex result2 = complex2.divide(divisor2);
                  
                  assertEquals(3.0, result2.getReal(), 0.0001);  // 9/3=3, not 9*3=27
                  assertEquals(1.0, result2.getImaginary(), 0.0001);  // 3/3=1, not 3*3=9
              }

 @Test
             public void testDivide_WhenRealPartLargerThanImaginary_ShouldComputeCorrectly() {
                 // Setup - create complex numbers where |c| > |d|
                 Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
                 Complex divisor = new Complex(5.0, 2.0);   // 5 + 2i (5 > 2)
                 
                 // Expected result calculation (manual computation)
                 // Original correct computation:
                 // q = d/c = 2/5 = 0.4
                 // denominator = d*q + c = 2*0.4 + 5 = 5.8
                 // real part = (imaginary*q + real)/denominator = (4*0.4 + 3)/5.8 = 4.6/5.8 ≈ 0.7931
                 // imaginary part = (imaginary - real*q)/denominator = (4 - 3*0.4)/5.8 = 2.8/5.8 ≈ 0.4828
                 
                 // Mutant would compute:
                 // q = c/d = 5/2 = 2.5 (wrong)
                 // denominator = d*q + c = 2*2.5 + 5 = 10 (wrong)
                 // real part = (4*2.5 + 3)/10 = 13/10 = 1.3 (wrong)
                 // imaginary part = (4 - 3*2.5)/10 = -3.5/10 = -0.35 (wrong)
                 
                 // Execute
                 Complex result = dividend.divide(divisor);
                 
                 // Verify - with tolerance for floating point precision
                 assertEquals(0.7931, result.getReal(), 0.0001);
                 assertEquals(0.4828, result.getImaginary(), 0.0001);
                 
                 // Additional verification with different values
                 Complex dividend2 = new Complex(1.0, 1.0);
                 Complex divisor2 = new Complex(4.0, 1.0);
                 Complex result2 = dividend2.divide(divisor2);
                 
                 // Expected: q = 1/4 = 0.25, denominator = 1*0.25 + 4 = 4.25
                 // real = (1*0.25 + 1)/4.25 = 1.25/4.25 ≈ 0.2941
                 // imaginary = (1 - 1*0.25)/4.25 = 0.75/4.25 ≈ 0.1765
                 assertEquals(0.2941, result2.getReal(), 0.0001);
                 assertEquals(0.1765, result2.getImaginary(), 0.0001);
             }

 @Test
             public void testDivideByDoubleCatchesDivisionMutant() {
                 // Create a complex number with non-zero, non-special values
                 Complex complex = new Complex(4.0, 2.0);
                 double divisor = 2.0;
                 
                 // Test division operation
                 Complex result = complex.divide(divisor);
                 
                 // Verify both real and imaginary parts are divided correctly
                 // Original: 4.0/2.0 = 2.0, mutant would do 2.0/4.0 = 0.5
                 assertEquals(2.0, result.getReal(), 0.0001);
                 // Original: 2.0/2.0 = 1.0, mutant would do 2.0/2.0 = 1.0 (same)
                 assertEquals(1.0, result.getImaginary(), 0.0001);
                 
                 // Additional test with different values where both parts would show difference
                 Complex complex2 = new Complex(3.0, 6.0);
                 double divisor2 = 3.0;
                 Complex result2 = complex2.divide(divisor2);
                 
                 // Original: 3.0/3.0 = 1.0, mutant: 3.0/3.0 = 1.0 (same)
                 assertEquals(1.0, result2.getReal(), 0.0001);
                 // Original: 6.0/3.0 = 2.0, mutant: 3.0/6.0 = 0.5
                 assertEquals(2.0, result2.getImaginary(), 0.0001);
             }

 @Test
            public void testDivideDetectsDenominatorSignMutation() {
                // Create complex numbers that will trigger the else branch (abs(c) >= abs(d))
                Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
                Complex divisor = new Complex(2.0, 1.0);   // 2 + 1i (2 > 1 so else branch)
                
                // Calculate expected result manually using correct formula
                double q = 1.0 / 2.0;  // d/c = 1/2
                double correctDenominator = 1.0 * q + 2.0;  // d*q + c
                double expectedReal = (4.0 * q + 3.0) / correctDenominator;
                double expectedImaginary = (4.0 - 3.0 * q) / correctDenominator;
                
                // Perform the division
                Complex result = dividend.divide(divisor);
                
                // Verify both real and imaginary parts
                assertEquals(expectedReal, result.getReal(), 1e-10);
                assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
                
                // The mutant would calculate denominator as d*q - c = 0.5 - 2.0 = -1.5
                // This would make real part = (4*0.5 + 3)/-1.5 = 5/-1.5 = -3.333...
                // And imaginary part = (4 - 3*0.5)/-1.5 = 2.5/-1.5 = -1.666...
                // Both significantly different from correct values
            }

 @Test
            public void testDivideComplexNumbersDetectsDenominatorMutation1() {
                // Setup complex numbers where the mutation would cause different results
                Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
                Complex divisor = new Complex(1.0, 2.0);   // 1 + 2i
                
                // Expected correct result: (3+4i)/(1+2i) = (3*1 + 4*2)/(1² + 2²) + (4*1 - 3*2)/(1² + 2²)i
                // = (3 + 8)/5 + (4 - 6)/5 i = 11/5 - 2/5 i = 2.2 - 0.4i
                Complex expected = new Complex(2.2, -0.4);
                
                // Actual result (with mutant) would be:
                // denominator would be 1*1 - 2*2 = -3 instead of 1*1 + 2*2 = 5
                // So result would be (3 + 8)/-3 + (4 - 6)/-3 i = -11/3 + 2/3 i
                
                Complex result = dividend.divide(divisor);
                
                // Verify real and imaginary parts separately with delta for floating point comparison
                assertEquals("Real part should match", expected.getReal(), result.getReal(), 1e-10);
                assertEquals("Imaginary part should match", expected.getImaginary(), result.getImaginary(), 1e-10);
            }

 @Test
           public void testDivideComplexDetectsDenominatorMutation() {
               // Setup complex numbers where d*q + c != d + q*c
               Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
               Complex divisor = new Complex(1.0, 2.0);   // 1 + 2i
               
               // Expected calculation:
               // Original denominator = d*q + c = (3*1) + (4*2) = 3 + 8 = 11
               // Mutated denominator = d + q*c = 3 + (1*4) = 7
               // These produce different results
               
               Complex result = dividend.divide(divisor);
               
               // Verify real part (should be (3*1 + 4*2)/11 = 11/11 = 1.0)
               assertEquals(1.0, result.getReal(), 0.0001);
               
               // Verify imaginary part (should be (4*1 - 3*2)/11 = -2/11 ≈ -0.1818)
               assertEquals(-0.1818, result.getImaginary(), 0.0001);
               
               // The mutated version would calculate:
               // real = (3*1 + 4*2)/7 = 11/7 ≈ 1.5714
               // imaginary = (4*1 - 3*2)/7 = -2/7 ≈ -0.2857
               // Both assertions would fail with these values
           }

 @Test
          public void testDivideDenominatorCalculation() {
              // Create a complex number where abs(c) >= abs(d) to trigger the else branch
              // Choose values where d*q + c would be different from d + q*c
              // Let's use c=3.0, d=2.0 (since 3.0 >= 2.0)
              // q = d/c = 2.0/3.0 ≈ 0.666...
              // Original denominator: d*q + c = 2.0*(2.0/3.0) + 3.0 ≈ 4.333...
              // Mutant denominator: d + q*c = 2.0 + (2.0/3.0)*3.0 = 4.0
              Complex dividend = new Complex(5.0, 7.0);  // arbitrary values
              Complex divisor = new Complex(3.0, 2.0);
              
              // Calculate expected result using original formula
              double q = 2.0 / 3.0;
              double expectedDenominator = 2.0 * q + 3.0;
              Complex expected = new Complex(
                  (7.0 * q + 5.0) / expectedDenominator,
                  (7.0 - 5.0 * q) / expectedDenominator
              );
              
              // Actual result
              Complex result = dividend.divide(divisor);
              
              // Verify the result matches expected calculation
              assertEquals(expected.getReal(), result.getReal(), 1e-15);
              assertEquals(expected.getImaginary(), result.getImaginary(), 1e-15);
          }

 @Test
      public void testDivide_DetectsSignMutationInRealPart() {
          // Create complex numbers where |c| >= |d| in divisor
          // Choose values where the mutation would flip the sign of the real part
          Complex dividend = new Complex(3.0, 4.0);  // 3 + 4i
          Complex divisor = new Complex(2.0, 1.0);   // 2 + i (since 2 > 1, we'll hit the else branch)
          
          // Expected result calculation:
          // Original formula: (imaginary*q + real)/denominator
          // q = d/c = 1/2 = 0.5
          // denominator = d*q + c = 1*0.5 + 2 = 2.5
          // real part = (4*0.5 + 3)/2.5 = (2 + 3)/2.5 = 5/2.5 = 2.0
          // Mutated formula would give: (4*0.5 - 3)/2.5 = (2 - 3)/2.5 = -1/2.5 = -0.4
          
          Complex result = dividend.divide(divisor);
          
          // Verify both real and imaginary parts to ensure complete test
          assertEquals(2.0, result.getReal(), 1e-15);  // This will fail if mutation is present
          assertEquals(1.0, result.getImaginary(), 1e-15);
          
          // Additional test case with different values to be thorough
          Complex dividend2 = new Complex(5.0, -2.0);
          Complex divisor2 = new Complex(3.0, 1.0);
          
          // Expected:
          // q = 1/3 ≈ 0.333
          // denominator = 1*0.333 + 3 ≈ 3.333
          // real part = (-2*0.333 + 5)/3.333 ≈ (-0.666 + 5)/3.333 ≈ 4.333/3.333 ≈ 1.3
          // Mutated would be (-0.666 - 5)/3.333 ≈ -5.666/3.333 ≈ -1.7
          
          Complex result2 = dividend2.divide(divisor2);
          assertEquals(1.3, result2.getReal(), 1e-2);
          assertEquals(-0.9, result2.getImaginary(), 1e-2);
      }

 @Test
      public void testDivideDetectsSignChangeMutant1() {
          // Create a complex number with non-zero real and imaginary parts
          Complex complex = new Complex(3.0, 4.0);
          double divisor = 2.0;
          
          // Expected result calculation (using correct formula)
          double expectedReal = 3.0 / 2.0;  // real / divisor
          double expectedImaginary = 4.0 / 2.0;  // imaginary / divisor
          
          // Perform the division
          Complex result = complex.divide(divisor);
          
          // Verify both real and imaginary parts
          assertEquals("Real part should be correctly calculated", 
                      expectedReal, result.getReal(), 0.0001);
          assertEquals("Imaginary part should be correctly calculated",
                      expectedImaginary, result.getImaginary(), 0.0001);
          
          // Additional test with negative values to be thorough
          Complex complex2 = new Complex(-5.0, -7.0);
          divisor = -3.0;
          
          expectedReal = -5.0 / -3.0;
          expectedImaginary = -7.0 / -3.0;
          
          result = complex2.divide(divisor);
          
          assertEquals("Real part with negative values should be correct",
                      expectedReal, result.getReal(), 0.0001);
          assertEquals("Imaginary part with negative values should be correct",
                      expectedImaginary, result.getImaginary(), 0.0001);
      }

 @Test
     public void testDivide_DetectsMutatedComplexMultiplicationOrder() {
         // Setup complex numbers where the multiplication order affects precision
         // Using values where (a*b + c) might give different results than (a + b*c)
         // due to floating point arithmetic
         Complex dividend = new Complex(1.0e-20, 1.0e20);  // very small real, very large imaginary
         Complex divisor = new Complex(1.0e20, 1.0);      // large real, small imaginary
         
         // This will take the else branch (abs(c) >= abs(d))
         // Original: (imaginary * q + real)/denominator
         // Mutant:   (imaginary + q * real)/denominator
         Complex result = dividend.divide(divisor);
         
         // Calculate expected values manually using original formula
         double c = divisor.getReal();
         double d = divisor.getImaginary();
         double q = d / c;
         double denominator = d * q + c;
         double expectedReal = (dividend.getImaginary() * q + dividend.getReal()) / denominator;
         
         // Assert with delta to account for potential floating point differences
         assertEquals("Real part should match original computation", 
                     expectedReal, 
                     result.getReal(), 
                     1.0e-15);
         
         // Also verify the imaginary part for completeness
         double expectedImaginary = (dividend.getImaginary() - dividend.getReal() * q) / denominator;
         assertEquals("Imaginary part should match", 
                     expectedImaginary, 
                     result.getImaginary(), 
                     1.0e-15);
     }

 @Test
     public void testDivideDetectsMutant() {
         // Create a complex number with non-zero real and imaginary parts
         Complex complex = new Complex(3.0, 4.0); // real=3, imaginary=4
         double divisor = 2.0;
         
         // Expected result based on original formula: (3 + 4*q)/2
         // Since this is the divide(double) method, q would be 1/divisor = 0.5
         // Original: (4*0.5 + 3)/2 = (2 + 3)/2 = 2.5
         // Mutant: (4 + 0.5*3)/2 = (4 + 1.5)/2 = 2.75
         
         // Perform the division
         Complex result = complex.divide(divisor);
         
         // Verify both real and imaginary parts
         // Original would give real=1.5 (3/2), imaginary=2.0 (4/2)
         // But mutant would affect the imaginary part calculation
         assertEquals(1.5, result.getReal(), 0.0001); // real part should be real/divisor
         assertEquals(2.0, result.getImaginary(), 0.0001); // imaginary part should be imaginary/divisor
         
         // Additional test with different values to be more thorough
         Complex complex2 = new Complex(5.0, 10.0);
         double divisor2 = 5.0;
         Complex result2 = complex2.divide(divisor2);
         assertEquals(1.0, result2.getReal(), 0.0001);
         assertEquals(2.0, result2.getImaginary(), 0.0001);
     }

 @Test
     public void testDivideDetectsDivisionMutant() {
         // Test case that would catch if the division operations were swapped or modified
         Complex complex = new Complex(6.0, 9.0);
         double divisor = 3.0;
         
         Complex result = complex.divide(divisor);
         
         // Verify both parts are divided correctly
         assertEquals(2.0, result.getReal(), 0.0001);  // 6/3 = 2
         assertEquals(3.0, result.getImaginary(), 0.0001);  // 9/3 = 3
         
         // Also test with negative values
         Complex complex2 = new Complex(-4.0, -8.0);
         double divisor2 = -2.0;
         Complex result2 = complex2.divide(divisor2);
         assertEquals(2.0, result2.getReal(), 0.0001);  // -4/-2 = 2
         assertEquals(4.0, result2.getImaginary(), 0.0001);  // -8/-2 = 4
     }

 @Test
    public void testDivideWithValidDivisorShouldNotThrowException() {
        // Arrange
        Complex dividend = new Complex(4.0, 2.0);  // 4 + 2i
        Complex divisor = new Complex(2.0, 1.0);   // 2 + i
        
        // Act & Assert
        try {
            Complex result = dividend.divide(divisor);
            // If we get here, the test passes (original behavior)
            // We can add additional assertions to verify the division result
            assertEquals(2.0, result.getReal(), 0.0001);
            assertEquals(0.0, result.getImaginary(), 0.0001);
        } catch (NullPointerException e) {
            // If we get here, the mutant survived
            fail("NullPointerException was thrown with valid non-null divisor");
        }
    }

 @Test
        public void testDivideWithNullDivisorShouldThrowException() {
            // Setup
            Complex complex = new Complex(2.0, 3.0); // Any non-special complex number
            
            // Expect NullPointerException to be thrown
            thrown.expect(NullPointerException.class);
            thrown.expectMessage("divisor is null");
            
            // Test
            complex.divide(null); // This should trigger the null check
        }

 @Test(expected = NullPointerException.class)
   public void testDivideWithNullDivisorShouldThrowNullPointerException() {
       // Arrange
       Complex dividend = new Complex(1.0, 2.0);  // Any non-null complex number
       Complex nullDivisor = null;
       
       // Act - This should throw NullPointerException in original code
       dividend.divide(nullDivisor);
       
       // Assert - The expected exception is declared in the @Test annotation
       // If the mutant is present, this test will fail because the null check is bypassed
   }

 @Test(expected = NullPointerException.class)
   public void testDivideWithNullDivisorShouldThrow() {
       Complex complex = new Complex(1.0, 1.0);
       Double nullDivisor = null;
       // This should throw NullPointerException immediately in original code
       // Mutated version would either not throw or throw later
       complex.divide(nullDivisor);
   }

 @Test
      public void testDivideWithOneNaNOperandShouldReturnNaN() {
          // Case 1: Current complex is NaN, divisor is not NaN
          Complex nanComplex = new Complex(Double.NaN, 1.0);
          Complex normalDivisor = new Complex(1.0, 1.0);
          assertEquals(Complex.NaN, nanComplex.divide(normalDivisor));
  
          // Case 2: Current complex is not NaN, divisor is NaN
          Complex normalComplex = new Complex(1.0, 1.0);
          Complex nanDivisor = new Complex(Double.NaN, 1.0);
          assertEquals(Complex.NaN, normalComplex.divide(nanDivisor));
  
          // Case 3: Both are NaN (should also return NaN)
          assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
  
          // Case 4: Neither is NaN (should proceed with normal division)
          Complex result = normalComplex.divide(normalDivisor);
          assertNotEquals(Complex.NaN, result);
          // Additional assertions about the division result could be added here
      }

 @Test
      public void testDivide_ShouldReturnNaN_WhenComplexIsNaN() {
          // Create a NaN complex number (with NaN real part)
          Complex complex = new Complex(Double.NaN, 1.0);
          double validDivisor = 2.0;
          
          // Should return NaN because complex is NaN (even though divisor is valid)
          assertEquals(Complex.NaN, complex.divide(validDivisor));
      }

 @Test
      public void testDivide_ShouldReturnNaN_WhenDivisorIsNaN() {
          // Create a valid complex number
          Complex complex = new Complex(1.0, 1.0);
          double nanDivisor = Double.NaN;
          
          // Should return NaN because divisor is NaN (even though complex is valid)
          assertEquals(Complex.NaN, complex.divide(nanDivisor));
      }

 @Test
      public void testDivide_ShouldReturnNaN_WhenBothAreNaN() {
          // Create a NaN complex number
          Complex complex = new Complex(Double.NaN, Double.NaN);
          double nanDivisor = Double.NaN;
          
          // Should return NaN because both complex and divisor are NaN
          assertEquals(Complex.NaN, complex.divide(nanDivisor));
      }

 @Test
     public void testDivideWithNaNDivisorShouldReturnNaN2() {
         // Create a valid complex number (dividend)
         Complex dividend = new Complex(1.0, 2.0);
         // Create a NaN complex number (divisor)
         Complex divisor = new Complex(Double.NaN, Double.NaN);
         
         // The original method should return NaN when either operand is NaN
         Complex result = dividend.divide(divisor);
         
         // Assert that the result is NaN
         assertTrue(result.isNaN());
     }

 @Test
     public void testDivideWithNaNDividendShouldReturnNaN() {
         // Create a NaN complex number (dividend)
         Complex dividend = new Complex(Double.NaN, Double.NaN);
         // Create a valid complex number (divisor)
         Complex divisor = new Complex(1.0, 2.0);
         
         Complex result = dividend.divide(divisor);
         
         assertTrue(result.isNaN());
     }

 @Test
     public void testDivideWithBothValidShouldReturnNormalResult() {
         Complex dividend = new Complex(4.0, 2.0);
         Complex divisor = new Complex(2.0, 1.0);
         
         Complex result = dividend.divide(divisor);
         
         // Expected result is (4*2 + 2*1)/5 + i(2*2 - 4*1)/5 = 2 + 0i
         assertEquals(2.0, result.getReal(), 0.0001);
         assertEquals(0.0, result.getImaginary(), 0.0001);
     }

 @Test
     public void testDivideWithBothNaNShouldReturnNaN() {
         Complex dividend = new Complex(Double.NaN, Double.NaN);
         Complex divisor = new Complex(Double.NaN, Double.NaN);
         
         Complex result = dividend.divide(divisor);
         
         assertTrue(result.isNaN());
     }

 @Test
 public void testDivideWithNaNDivisorShouldReturnNaN3() {
     // Create a valid complex number (not NaN)
     Complex complex = new Complex(1.0, 2.0);
     
     // Use NaN as divisor
     double nanDivisor = Double.NaN;
     
     // Call the method
     Complex result = complex.divide(nanDivisor);
     
     // Verify the result is NaN (original behavior)
     // The mutant would not return NaN here but proceed to other checks
     assertTrue(result.isNaN());
     
     // Additional verification that we're getting the specific NaN constant
     assertEquals(Complex.NaN, result);
 }

}
