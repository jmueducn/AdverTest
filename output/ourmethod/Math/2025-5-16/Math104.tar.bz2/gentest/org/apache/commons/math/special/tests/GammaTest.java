package gentest.org.apache.commons.math.special.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.special.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.ContinuedFraction;
 
public class GammaTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                   public void testLogGamma_NaNInput() {
                                                                       double result = Gamma.logGamma(Double.NaN);
                                                                       assertTrue(Double.isNaN(result));
                                                                   }

 @Test
                                                                   public void testLogGamma_ZeroInput() {
                                                                       double result = Gamma.logGamma(0.0);
                                                                       assertTrue(Double.isNaN(result));
                                                                   }

 @Test
                                                                   public void testLogGamma_NegativeInput() {
                                                                       double result = Gamma.logGamma(-5.0);
                                                                       assertTrue(Double.isNaN(result));
                                                                   }

 @Test
                                                                   public void testLogGamma_One() {
                                                                       // Gamma(1) = 0, so logGamma(1) should be ln(0) = -Infinity
                                                                       double result = Gamma.logGamma(1.0);
                                                                       assertEquals(Double.NEGATIVE_INFINITY, result, 0.0);
                                                                   }

 @Test
                                                                   public void testLogGamma_Half() {
                                                                       // Gamma(0.5) = sqrt(π), so logGamma(0.5) should be ln(sqrt(π)) ≈ 0.5723649429247001
                                                                       double expected = Math.log(Math.sqrt(Math.PI));
                                                                       double result = Gamma.logGamma(0.5);
                                                                       assertEquals(expected, result, 1e-15);
                                                                   }

 @Test
                                                                   public void testLogGamma_SmallPositiveValue() {
                                                                       // Test with a small positive value
                                                                       double x = 0.1;
                                                                       // Expected value calculated using Wolfram Alpha
                                                                       double expected = 2.2527126517342055;
                                                                       double result = Gamma.logGamma(x);
                                                                       assertEquals(expected, result, 1e-14);
                                                                   }

 @Test
                                                                   public void testLogGamma_MediumValue() {
                                                                       // Test with a medium value
                                                                       double x = 5.0;
                                                                       // Gamma(5) = 4! = 24, so logGamma(5) = ln(24) ≈ 3.1780538303479458
                                                                       double expected = Math.log(24.0);
                                                                       double result = Gamma.logGamma(x);
                                                                       assertEquals(expected, result, 1e-15);
                                                                   }

 @Test
                                                                   public void testLogGamma_LargeValue() {
                                                                       // Test with a large value
                                                                       double x = 100.0;
                                                                       // Expected value calculated using Wolfram Alpha
                                                                       double expected = 359.1342053695754;
                                                                       double result = Gamma.logGamma(x);
                                                                       assertEquals(expected, result, 1e-12);
                                                                   }

 @Test
                                                                   public void testLogGamma_VeryLargeValue() {
                                                                       // Test with a very large value (near Double.MAX_VALUE)
                                                                       double x = 1.0e100;
                                                                       double result = Gamma.logGamma(x);
                                                                       // Verify the result is finite and positive
                                                                       assertTrue(Double.isFinite(result));
                                                                       assertTrue(result > 0);
                                                                   }

 @Test
                                                                   public void testLogGamma_RecurrenceRelation() {
                                                                       // Test the recurrence relation: Gamma(x+1) = x*Gamma(x)
                                                                       // So logGamma(x+1) = log(x) + logGamma(x)
                                                                       double x = 5.4321;
                                                                       double logGammaX = Gamma.logGamma(x);
                                                                       double logGammaXPlus1 = Gamma.logGamma(x + 1.0);
                                                                       double expected = Math.log(x) + logGammaX;
                                                                       assertEquals(expected, logGammaXPlus1, 1e-14);
                                                                   }

 @Test
                                                                   public void testLogGamma_JustAboveZero() {
                                                                       // Test with a value just above zero
                                                                       double x = Double.MIN_VALUE;
                                                                       double result = Gamma.logGamma(x);
                                                                       // Should be finite but very large positive (since Gamma(x) → +∞ as x → 0+)
                                                                       assertTrue(Double.isFinite(result));
                                                                       assertTrue(result > 0);
                                                                   }

 @Test
                   public void testRegularizedGammaP_TypicalValues() throws MathException {
                       // Test with positive values
                       assertEquals(0.6321205588, Gamma.regularizedGammaP(1.0, 1.0), 1e-9);
                       assertEquals(0.9999999999, Gamma.regularizedGammaP(1.0, 10.0), 1e-9);
                       assertEquals(0.0, Gamma.regularizedGammaP(1.0, 0.0), 1e-9);
                       
                       // Test with different 'a' values
                       assertEquals(0.8646647168, Gamma.regularizedGammaP(2.0, 2.0), 1e-9);
                       assertEquals(0.1428765395, Gamma.regularizedGammaP(5.0, 3.0), 1e-9);
                   }

 @Test
                   public void testRegularizedGammaP_EdgeCases() throws Exception {
                       // When x is very small
                       assertEquals(0.0, Gamma.regularizedGammaP(1.0, 1e-10), 1e-9);
                       
                       // When x is very large
                       assertEquals(1.0, Gamma.regularizedGammaP(1.0, 1e10), 1e-9);
                       
                       // When a is very small
                       assertEquals(0.0, Gamma.regularizedGammaP(1e-10, 1e-10), 1e-9);
                       
                       // When a is very large
                       assertEquals(0.0, Gamma.regularizedGammaP(1e10, 1e10-1), 1e-9);
                   }

 @Test(expected = IllegalArgumentException.class)
                   public void testRegularizedGammaP_InvalidInputs() throws MathException {
                       // Negative 'a' should throw exception
                       Gamma.regularizedGammaP(-1.0, 1.0);
                   }

 @Test
                   public void testRegularizedGammaP_NegativeX() throws MathException {
                       // Negative 'x' should throw exception
                       try {
                           Gamma.regularizedGammaP(1.0, -1.0);
                           fail("Expected IllegalArgumentException");
                       } catch (IllegalArgumentException e) {
                           // Expected exception
                       }
                   }

 @Test
                   public void testRegularizedGammaP_ZeroA() throws MathException {
                       // Zero 'a' should throw exception
                       thrown.expect(IllegalArgumentException.class);
                       Gamma.regularizedGammaP(0.0, 1.0);
                   }

 @Test
                   public void testRegularizedGammaP_SpecialCases() throws MathException {
                       // When a = x = 1
                       assertEquals(1 - Math.exp(-1), Gamma.regularizedGammaP(1.0, 1.0), 1e-9);
                       
                       // When x = 0, result should be 0 for any a > 0
                       assertEquals(0.0, Gamma.regularizedGammaP(0.5, 0.0), 1e-9);
                       assertEquals(0.0, Gamma.regularizedGammaP(2.0, 0.0), 1e-9);
                       
                       // When a is very large and x is very small
                       assertEquals(0.0, Gamma.regularizedGammaP(1e6, 1e-6), 1e-9);
                   }

 @Test
                   public void testRegularizedGammaP_Convergence() throws MathException {
                       // Test values that should converge
                       assertEquals(0.9999999999, Gamma.regularizedGammaP(10.0, 20.0), 1e-9);
                       assertEquals(0.0, Gamma.regularizedGammaP(20.0, 10.0), 1e-9);
                   }

 @Test
                   public void testRegularizedGammaP_MaxIterationsExceeded() throws MathException {
                       thrown.expect(MaxIterationsExceededException.class);
                       thrown.expectMessage("100");
                       
                       // Use very small epsilon and low maxIterations to force exception
                       Gamma.regularizedGammaP(0.5, 10.0, 1e-20, 100);
                   }

 @Test
                   public void testRegularizedGammaQ_TypicalValues() throws MathException {
                       // Test cases where a = 1 (exponential distribution case)
                       assertEquals(0.36787944117144233, Gamma.regularizedGammaQ(1.0, 1.0), 1e-10);
                       assertEquals(0.1353352832366127, Gamma.regularizedGammaQ(1.0, 2.0), 1e-10);
                       
                       // Test cases with integer a values
                       assertEquals(0.7357588823428847, Gamma.regularizedGammaQ(2.0, 1.0), 1e-10);
                       assertEquals(0.4060058497098381, Gamma.regularizedGammaQ(2.0, 2.0), 1e-10);
                       
                       // Test cases with non-integer a values
                       assertEquals(0.5724067044708798, Gamma.regularizedGammaQ(1.5, 1.0), 1e-10);
                       assertEquals(0.2614641299491106, Gamma.regularizedGammaQ(1.5, 2.0), 1e-10);
                   }

 @Test
                   public void testRegularizedGammaQ_EdgeCases() throws MathException {
                       // When x approaches 0
                       assertEquals(1.0, Gamma.regularizedGammaQ(1.0, 0.0), 1e-10);
                       assertEquals(1.0, Gamma.regularizedGammaQ(2.0, 0.0), 1e-10);
                       
                       // When x approaches infinity (should approach 0)
                       assertEquals(0.0, Gamma.regularizedGammaQ(1.0, 1000.0), 1e-10);
                       assertEquals(0.0, Gamma.regularizedGammaQ(2.0, 1000.0), 1e-10);
                       
                       // When a approaches 0
                       assertEquals(0.0, Gamma.regularizedGammaQ(0.0001, 1.0), 1e-4);
                   }

 @Test(expected = IllegalArgumentException.class)
                   public void testRegularizedGammaQ_InvalidInputs() throws MathException {
                       Gamma.regularizedGammaQ(-1.0, 1.0);
                   }

 @Test(expected = IllegalArgumentException.class)
                   public void testRegularizedGammaQ_InvalidInputsNegativeX() throws Exception {
                       Gamma.regularizedGammaQ(1.0, -1.0);
                   }

 @Test
                   public void testRegularizedGammaQ_ZeroA() throws MathException {
                       thrown.expect(IllegalArgumentException.class);
                       Gamma.regularizedGammaQ(0.0, 1.0);
                   }

 @Test
                   public void testRegularizedGammaQ_RelationshipWithP() throws MathException {
                       double a = 2.5;
                       double x = 3.0;
                       double p = Gamma.regularizedGammaP(a, x);
                       double q = Gamma.regularizedGammaQ(a, x);
                       assertEquals(1.0, p + q, 1e-10);
                   }

 @Test
                   public void testRegularizedGammaQ_VerySmallValues() throws org.apache.commons.math.MathException {
                       assertEquals(1.0, Gamma.regularizedGammaQ(1.0, 1e-20), 1e-10);
                       assertEquals(1.0, Gamma.regularizedGammaQ(2.0, 1e-20), 1e-10);
                   }

 @Test
                   public void testRegularizedGammaQ_VeryLargeValues() throws MathException {
                       assertEquals(0.0, Gamma.regularizedGammaQ(1.0, 1e20), 1e-10);
                       assertEquals(0.0, Gamma.regularizedGammaQ(2.0, 1e20), 1e-10);
                   }

 @Test
                   public void testRegularizedGammaQ_Convergence() throws org.apache.commons.math.MathException {
                       // Test with very small epsilon to verify convergence
                       double result = Gamma.regularizedGammaQ(2.5, 3.0, 1e-15, 10000);
                       assertFalse(Double.isNaN(result));
                       assertTrue(result > 0 && result < 1);
                   }

 @Test
                   public void testRegularizedGammaP_NaNInputs() throws MathException {
                       // Define epsilon value for the test
                       final double EPSILON = 1e-15;
                       
                       // Test NaN for a
                       assertTrue(Double.isNaN(org.apache.commons.math.special.Gamma.regularizedGammaP(Double.NaN, 1.0, EPSILON, 1000)));
                       
                       // Test NaN for x
                       assertTrue(Double.isNaN(org.apache.commons.math.special.Gamma.regularizedGammaP(1.0, Double.NaN, EPSILON, 1000)));
                       
                       // Test both NaN
                       assertTrue(Double.isNaN(org.apache.commons.math.special.Gamma.regularizedGammaP(Double.NaN, Double.NaN, EPSILON, 1000)));
                   }

 @Test
                   public void testRegularizedGammaP_InvalidParameters() {
                       // Define test constants
                       final double EPSILON = 1e-15;
                       final int MAX_ITERATIONS = 1000;
                       
                       // Test a <= 0
                       try {
                           assertTrue(Double.isNaN(org.apache.commons.math.special.Gamma.regularizedGammaP(0.0, 1.0, EPSILON, MAX_ITERATIONS)));
                       } catch (org.apache.commons.math.MathException e) {
                           fail("Unexpected MathException: " + e.getMessage());
                       }
                       try {
                           assertTrue(Double.isNaN(org.apache.commons.math.special.Gamma.regularizedGammaP(-1.0, 1.0, EPSILON, MAX_ITERATIONS)));
                       } catch (org.apache.commons.math.MathException e) {
                           fail("Unexpected MathException: " + e.getMessage());
                       }
                       
                       // Test x < 0
                       try {
                           assertTrue(Double.isNaN(org.apache.commons.math.special.Gamma.regularizedGammaP(1.0, -1.0, EPSILON, MAX_ITERATIONS)));
                       } catch (org.apache.commons.math.MathException e) {
                           fail("Unexpected MathException: " + e.getMessage());
                       }
                   }

 @Test
                   public void testRegularizedGammaP_XZero() throws Exception {
                       final double EPSILON = 1e-15;
                       assertEquals(0.0, Gamma.regularizedGammaP(1.0, 0.0, EPSILON, 1000), EPSILON);
                       assertEquals(0.0, Gamma.regularizedGammaP(2.5, 0.0, EPSILON, 1000), EPSILON);
                   }

 @Test
                   public void testRegularizedGammaP_SeriesCalculation() throws MathException {
                       // Define epsilon value for comparison
                       final double EPSILON = 1.0e-10;
                       
                       // Test cases where series calculation is used
                       // Known values from mathematical tables
                       assertEquals(0.6321205588, Gamma.regularizedGammaP(1.0, 1.0, EPSILON, 1000), EPSILON);
                       assertEquals(0.8646647168, Gamma.regularizedGammaP(2.0, 2.0, EPSILON, 1000), EPSILON);
                       assertEquals(0.9502129316, Gamma.regularizedGammaP(3.0, 5.0, EPSILON, 1000), EPSILON);
                   }

 @Test
                   public void testRegularizedGammaP_DefaultParameters() throws MathException {
                       // Test the version with default epsilon and maxIterations
                       double EPSILON = 1e-10; // Define epsilon for comparison
                       double result = Gamma.regularizedGammaP(1.0, 1.0, 1e-10, 10000);
                       assertEquals(0.6321205588, result, EPSILON);
                   }

 @Test
                   public void testRegularizedGammaP_BoundaryCases() throws org.apache.commons.math.MathException {
                       // Define test constants
                       final double EPSILON = 1e-15;
                       
                       // Test boundary between series and Q calculation
                       double result1 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0, 0.999, EPSILON, 1000);
                       double result2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0, 1.001, EPSILON, 1000);
                       assertTrue(result2 > result1); // Should be increasing function
                       
                       // Test very small values
                       assertEquals(0.0, org.apache.commons.math.special.Gamma.regularizedGammaP(1e-10, 1e-20, EPSILON, 1000), EPSILON);
                   }

 @Test
                   public void testRegularizedGammaQ_NaNInputs() {
                       // Define epsilon value for the test
                       final double EPSILON = 1e-15;
                       final int MAX_ITERATIONS = 1000;
                       
                       try {
                           // Test NaN for a
                           assertTrue(Double.isNaN(Gamma.regularizedGammaQ(Double.NaN, 1.0, EPSILON, MAX_ITERATIONS)));
                           
                           // Test NaN for x
                           assertTrue(Double.isNaN(Gamma.regularizedGammaQ(1.0, Double.NaN, EPSILON, MAX_ITERATIONS)));
                           
                           // Test both NaN
                           assertTrue(Double.isNaN(Gamma.regularizedGammaQ(Double.NaN, Double.NaN, EPSILON, MAX_ITERATIONS)));
                       } catch (MathException e) {
                           fail("Unexpected MathException: " + e.getMessage());
                       }
                   }

 @Test
                   public void testRegularizedGammaQ_InvalidParameters() throws MathException {
                       // Define epsilon constant inside the method
                       final double EPSILON = 1.0e-15;
                       
                       // Test a <= 0
                       assertTrue(Double.isNaN(Gamma.regularizedGammaQ(0.0, 1.0, EPSILON, 1000)));
                       assertTrue(Double.isNaN(Gamma.regularizedGammaQ(-1.0, 1.0, EPSILON, 1000)));
                       
                       // Test x < 0
                       assertTrue(Double.isNaN(Gamma.regularizedGammaQ(1.0, -1.0, EPSILON, 1000)));
                   }

 @Test
                   public void testRegularizedGammaQ_XEqualsZero() throws org.apache.commons.math.MathException {
                       // For any a > 0, Q(a,0) should be 1.0
                       final double EPSILON = 1.0e-15;
                       assertEquals(1.0, Gamma.regularizedGammaQ(0.5, 0.0, EPSILON, 1000), EPSILON);
                       assertEquals(1.0, Gamma.regularizedGammaQ(1.0, 0.0, EPSILON, 1000), EPSILON);
                       assertEquals(1.0, Gamma.regularizedGammaQ(2.0, 0.0, EPSILON, 1000), EPSILON);
                   }

 @Test
                   public void testRegularizedGammaQ_XLessThanA_Or_ALessThanOne() throws MathException {
                       // Define test constants
                       final double EPSILON = 1e-15;
                       final int MAX_ITERATIONS = 1000;
                       
                       // Mock static methods using PowerMockito
                       Gamma gammaMock = mock(Gamma.class);
                       when(gammaMock.regularizedGammaP(0.5, 0.3, EPSILON, MAX_ITERATIONS)).thenReturn(0.7);
                       when(gammaMock.regularizedGammaP(0.8, 0.5, EPSILON, MAX_ITERATIONS)).thenReturn(0.6);
                       
                       // Test x < a case
                       assertEquals(0.3, Gamma.regularizedGammaQ(0.5, 0.3, EPSILON, MAX_ITERATIONS), EPSILON);
                       
                       // Test a < 1 case
                       assertEquals(0.4, Gamma.regularizedGammaQ(0.8, 0.5, EPSILON, MAX_ITERATIONS), EPSILON);
                   }

 @Test
                   public void testRegularizedGammaQ_DefaultCase() throws org.apache.commons.math.MathException {
                       // Define precision constant
                       final double EPSILON = 1e-15;
                       
                       // For this test, we'll use known mathematical properties:
                       // Q(1,x) = e^-x
                       double x = 2.0;
                       double expected = Math.exp(-x);
                       assertEquals(expected, org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0, x, EPSILON, 1000), EPSILON);
                       
                       // Q(2,x) = e^-x * (1 + x)
                       x = 3.0;
                       expected = Math.exp(-x) * (1 + x);
                       assertEquals(expected, org.apache.commons.math.special.Gamma.regularizedGammaQ(2.0, x, EPSILON, 1000), EPSILON);
                   }

 @Test
                   public void testRegularizedGammaQ_ComplementProperty() throws MathException {
                       // Verify that P(a,x) + Q(a,x) = 1 for various values
                       final double EPSILON = 1.0e-12;
                       double a = 1.5;
                       double x = 2.5;
                       double p = Gamma.regularizedGammaP(a, x, EPSILON, 1000);
                       double q = Gamma.regularizedGammaQ(a, x, EPSILON, 1000);
                       assertEquals(1.0, p + q, EPSILON);
                       
                       a = 3.0;
                       x = 5.0;
                       p = Gamma.regularizedGammaP(a, x, EPSILON, 1000);
                       q = Gamma.regularizedGammaQ(a, x, EPSILON, 1000);
                       assertEquals(1.0, p + q, EPSILON);
                   }

 @Test
                   public void testRegularizedGammaQ_MaxIterations() throws org.apache.commons.math.MathException {
                       // Test with very small maxIterations that might cause non-convergence
                       double epsilon = 1.0e-15; // Define epsilon inside the method
                       double result = Gamma.regularizedGammaQ(10.0, 1.0, epsilon, 10);
                       assertFalse(Double.isNaN(result)); // Should still return a value, even if not fully converged
                   }

 @Test
                   public void testRegularizedGammaP_LargeA() throws MathException {
                       // Define test constants
                       final double EPSILON = 1e-15;
                       
                       // Call the method under test
                       double result = Gamma.regularizedGammaP(2.0, 3.0, EPSILON, 1000);
                       
                       // Verify the result
                       assertEquals(0.7, result, EPSILON); // 1.0 - 0.3
                       
                       // Verify the static method was called
                       Gamma.regularizedGammaQ(2.0, 3.0, EPSILON, 1000);
                   }

}
