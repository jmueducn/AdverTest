package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.util.MathUtils;
 
public class MultidimensionalCounterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testGetCounts_InvalidIndexNegative() {
                                                                                            int[] sizes = {2, 3};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            thrown.expect(OutOfRangeException.class);
                                                                                            thrown.expectMessage("0");
                                                                                            counter.getCounts(-1);
                                                                                        }

    @Test
                                                                                        public void testGetCounts_InvalidIndexTooLarge() {
                                                                                            int[] sizes = {2, 3};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            thrown.expect(OutOfRangeException.class);
                                                                                            thrown.expectMessage("6");
                                                                                            counter.getCounts(6);  // Total size is 2*3=6
                                                                                        }

    @Test
                                                                                        public void testGetCounts_2DimensionalFirstElement() {
                                                                                            int[] sizes = {2, 3};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {0, 0};
                                                                                            assertArrayEquals(expected, counter.getCounts(0));
                                                                                        }

    @Test
                                                                                        public void testGetCounts_2DimensionalLastElement() {
                                                                                            int[] sizes = {2, 3};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {1, 2};
                                                                                            assertArrayEquals(expected, counter.getCounts(5));
                                                                                        }

    @Test
                                                                                        public void testGetCounts_2DimensionalMiddleElement() {
                                                                                            int[] sizes = {2, 3};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {1, 1};
                                                                                            assertArrayEquals(expected, counter.getCounts(4));
                                                                                        }

    @Test
                                                                                        public void testGetCounts_3DimensionalFirstElement() {
                                                                                            int[] sizes = {2, 3, 4};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {0, 0, 0};
                                                                                            assertArrayEquals(expected, counter.getCounts(0));
                                                                                        }

    @Test
                                                                                        public void testGetCounts_3DimensionalLastElement() {
                                                                                            int[] sizes = {2, 3, 4};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {1, 2, 3};
                                                                                            assertArrayEquals(expected, counter.getCounts(23));  // 2*3*4-1 = 23
                                                                                        }

    @Test
                                                                                        public void testGetCounts_3DimensionalMiddleElement() {
                                                                                            int[] sizes = {2, 3, 4};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {1, 1, 2};
                                                                                            assertArrayEquals(expected, counter.getCounts(18));  // 1*(3*4) + 1*4 + 2 = 18
                                                                                        }

    @Test
                                                                                        public void testGetCounts_1DimensionalFirstElement() {
                                                                                            int[] sizes = {5};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {0};
                                                                                            assertArrayEquals(expected, counter.getCounts(0));
                                                                                        }

    @Test
                                                                                        public void testGetCounts_1DimensionalLastElement() {
                                                                                            int[] sizes = {5};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {4};
                                                                                            assertArrayEquals(expected, counter.getCounts(4));
                                                                                        }

    @Test
                                                                                        public void testGetCounts_4DimensionalComplexCase() {
                                                                                            int[] sizes = {2, 3, 2, 2};
                                                                                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                                                                            
                                                                                            int[] expected = {1, 2, 1, 1};
                                                                                            assertArrayEquals(expected, counter.getCounts(23));  // 1*(3*2*2) + 2*(2*2) + 1*2 + 1 = 23
                                                                                        }

                                                                                public void testGetCounts_WithEmptyCounter() {
                                                                                    // Edge case: counter with size 0 (though constructor might prevent this)
                                                                                    new MultidimensionalCounter(new int[]{0});
                                                                                }

    @Test(expected = NotStrictlyPositiveException.class)
                                                                                public void testGetCounts_WithNegativeSize() {
                                                                                    // Edge case: negative size in constructor
                                                                                    new MultidimensionalCounter(new int[]{-1});
                                                                                }

    @Test
                                        public void testGetCounts_ReturnsCopyOfCounter() {
                                            // Initialize a 2D counter (size 2)
                                            MultidimensionalCounter counter = new MultidimensionalCounter(new int[]{2, 2});
                                            
                                            // The counter array should be initialized to zeros
{}
                                            
                                            // Verify it's a copy by modifying the returned array
                                            
                                            // Original counter should remain unchanged
{}
                                        }

    @Test
                                        public void testGetCounts_AfterModifyingInternalState() {
                                            // Create a MultidimensionalCounter with sample dimensions
                                            int[] dimensions = {2, 3}; // Example dimensions
                                            MultidimensionalCounter counter = new MultidimensionalCounter(dimensions);
                                            
                                            // Test the initial state of counts
                                            int[] counts = counter.getCounts(0); // Use index 0 for initial counts
                                            // The initial counts should be all zeros based on the class implementation
                                            assertArrayEquals(new int[]{0, 0}, counts);
                                        }

    @Test
                                        public void testGetCounts_WithDifferentDimensions() {
                                            // Test with 1D counter
                                            MultidimensionalCounter counter1D = new MultidimensionalCounter(new int[]{5});
{}
                                            
                                            // Test with 3D counter
                                            MultidimensionalCounter counter3D = new MultidimensionalCounter(new int[]{2, 3, 4});
{}
                                        }

    @Test
                                        public void testGetCounts_NotSameAsInternalArray() {
                                            // Initialize counter with sample dimensions
                                            int[] dimensions = {2, 3};
                                            MultidimensionalCounter counter = new MultidimensionalCounter(dimensions);
                                            
                                            // Get counts twice to verify they're different instances
                                            
                                            // Verify they're not the same array instance
                                        }


}
