package gentest.org.apache.commons.math3.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.general.*;
import org.apache.commons.math3.analysis.DifferentiableMultivariateVectorFunction;
import org.apache.commons.math3.analysis.FunctionUtils;
import org.apache.commons.math3.analysis.differentiation.DerivativeStructure;
import org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.DecompositionSolver;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.QRDecomposition;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.optimization.OptimizationData;
import org.apache.commons.math3.optimization.InitialGuess;
import org.apache.commons.math3.optimization.Target;
import org.apache.commons.math3.optimization.Weight;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer;
import org.apache.commons.math3.optimization.PointVectorValuePair;
import org.apache.commons.math3.optimization.direct.BaseAbstractMultivariateVectorOptimizer;
import org.apache.commons.math3.util.FastMath;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                                                                                          public void testSquareRoot_DiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                                                                                                                                                                              DiagonalMatrix diagonalMatrix = new DiagonalMatrix(new double[]{4.0, 9.0, 16.0});
                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                              // Create a concrete subclass that implements required abstract methods
                                                                                                                                                                                                                                                                                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                                                                                                                                                                                                  protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                                                                                                                                      return null; // Not needed for this test
                                                                                                                                                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                                                                                                                                              };
                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                              // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                                                                                                                                                                                              Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                                                                                                                              squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                              RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                                                                                                                                                                              assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                                                                                                                                                                                                              assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                                                              assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                                                              assertEquals(4.0, result.getEntry(2, 2), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                              // Verify off-diagonal elements are zero
                                                                                                                                                                                                                                                                                                                                                                                                              assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                                                              assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                                          public void testSquareRoot_EmptyMatrix() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                                                                                                                                                                              DiagonalMatrix emptyMatrix = new DiagonalMatrix(new double[]{});
                                                                                                                                                                                                                                                                                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                                                                                                                                                                                                  protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                                                                                                                                      return null; // Dummy implementation
                                                                                                                                                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                                                                                                                                              };
                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                              // Get the private squareRoot method via reflection
                                                                                                                                                                                                                                                                                                                                                                                                              Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                                                                                                                              squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                              // Execute
                                                                                                                                                                                                                                                                                                                                                                                                              RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, emptyMatrix);
                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                                                                                                                                                                              assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                                                                                                                                                                                                              assertEquals(0, result.getRowDimension());
                                                                                                                                                                                                                                                                                                                                                                                                              assertEquals(0, result.getColumnDimension());
                                                                                                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                                          public void testSquareRoot_NullInput() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                                                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                                                                                                                                                                                                  protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                                                                                                                                      return null; // Simple implementation for test
                                                                                                                                                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                                                                                                                                              };
                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                              // Get the private squareRoot method via reflection
                                                                                                                                                                                                                                                                                                                                                                                                              Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                                                                                                                              squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                                                                                                                                                                                                                                  squareRootMethod.invoke(optimizer, (RealMatrix) null);
                                                                                                                                                                                                                                                                                                                                                                                                                  fail("Expected NullPointerException");
                                                                                                                                                                                                                                                                                                                                                                                                              } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                                                                                                                                                                  assertEquals(NullPointerException.class, e.getCause().getClass());
                                                                                                                                                                                                                                                                                                                                                                                                                  assertEquals("Matrix must not be null", e.getCause().getMessage());
                                                                                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                                                                  public void testSquareRoot_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                                                                                                      RealMatrix nonDiagonalMatrix = mock(RealMatrix.class);
                                                                                                                                                                                                                                                                                                                                                                      when(nonDiagonalMatrix.getRowDimension()).thenReturn(2);
                                                                                                                                                                                                                                                                                                                                                                      when(nonDiagonalMatrix.getColumnDimension()).thenReturn(2);
                                                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                                                      EigenDecomposition mockDecomposition = mock(EigenDecomposition.class);
                                                                                                                                                                                                                                                                                                                          {{}{}}
                                                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                                                      // Create optimizer with proper implementation
                                                                                                                                                                                                                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                                                                                                          protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                                                                                                                                                                                                                                                                                                                                                              return null; // dummy implementation
                                                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                                                                                                          protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                                                                                              return null; // dummy implementation
                                                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                          // Override createEigenDecomposition for testing
                                                                                                                                                                                                                                                                                                                                                                          EigenDecomposition createEigenDecomposition(RealMatrix m) {
                                                                                                                                                                                                                                                                                                                                                                              return mockDecomposition;
                                                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                                                      // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                                                                                                                                                      Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                                                                                      squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                      RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, nonDiagonalMatrix);
                                                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                                                                                                      assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                      assertEquals(2, result.getRowDimension());
                                                                                                                                                                                                                                                                                                                                                                      assertEquals(2, result.getColumnDimension());
                                                                                                                                                                                                                                                                                                                                                                      assertEquals(1.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                      assertEquals(0.5, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                      assertEquals(0.5, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                      assertEquals(1.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                                                                                                  public void testSquareRoot_MatrixWithNegativeDiagonal() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                                                                                                      DiagonalMatrix negativeDiagonal = new DiagonalMatrix(new double[]{4.0, -1.0, 9.0});
                                                                                                                                                                                                                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                                                                                                          protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                                                                                                                                                              OptimizationData... optData) {
                                                                                                                                                                                                                                                                                                                                                                              return null;
                                                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                                                                                                          protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                                                                                              return null;
                                                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                                                      // Get private squareRoot method via reflection
                                                                                                                                                                                                                                                                                                                                                                      Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                                                                                      squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                                                      // Verify exception
                                                                                                                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                                                                                                                          squareRootMethod.invoke(optimizer, negativeDiagonal);
                                                                                                                                                                                                                                                                                                                                                                          fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                                                                                          assertEquals(IllegalArgumentException.class, e.getCause().getClass());
                                                                                                                                                                                                                                                                                                                                                                          assertEquals("Matrix contains negative diagonal element", e.getCause().getMessage());
                                                                                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                                                         public void testSquareRoot_DiagonalMatrix_ShouldReturnDiagonal() throws Exception {
                                                                                                                                                                                                                                                                                                                             // Create a diagonal matrix (2x2)
                                                                                                                                                                                                                                                                                                                             RealMatrix diagonalMatrix = new DiagonalMatrix(new double[] {1.0, 4.0});
                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                             // Create a concrete subclass that implements the abstract method
                                                                                                                                                                                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                                                 protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                                                     return null; // Not needed for this test
                                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                             // Use reflection to access the private squareRoot method
                                                                                                                                                                                                                                                                                                                             Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                                             squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                             RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                             // Verify the result is diagonal
                                                                                                                                                                                                                                                                                                                             assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                                                                                                             assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                             // Verify the diagonal elements are square roots
                                                                                                                                                                                                                                                                                                                             assertEquals(1.0, result.getEntry(0, 0), 1e-10);  // sqrt(1)
                                                                                                                                                                                                                                                                                                                             assertEquals(2.0, result.getEntry(1, 1), 1e-10);   // sqrt(4)
                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                             public void testSquareRoot_NonDiagonalMatrix_ShouldUseEigenDecomposition() throws Exception {
                                                                                                                                                                                                                                                                                                                 // Create a non-diagonal matrix (2x2)
                                                                                                                                                                                                                                                                                                                 RealMatrix nonDiagonalMatrix = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                                                                                                                                                     {1.0, 0.5},
                                                                                                                                                                                                                                                                                                                     {0.5, 1.0}
                                                                                                                                                                                                                                                                                                                 });
                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                 // Create concrete subclass implementing required abstract methods
                                                                                                                                                                                                                                                                                                                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                     protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                                         return null; // Not needed for this test
                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                 // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                                                                                                 Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                                 squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                 RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, nonDiagonalMatrix);
                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                 // Verify the result is not diagonal (mutant would return diagonal)
                                                                                                                                                                                                                                                                                                                 // Check off-diagonal elements are not zero
                                                                                                                                                                                                                                                                                                                 assertNotEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                                                                                                 assertNotEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                 // Verify the diagonal elements are square roots (mutant would still get this right)
                                                                                                                                                                                                                                                                                                                 assertEquals(Math.sqrt(1.0), result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                                                                                 assertEquals(Math.sqrt(1.0), result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                public void testSquareRootWithRectangularDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                                                                    // Create a rectangular diagonal matrix (2 rows x 3 columns)
                                                                                                                                                                                                                                                                                                    DiagonalMatrix rectMatrix = new DiagonalMatrix(new double[] {4.0, 9.0});
                                                                                                                                                                                                                                                                                                    RealMatrix realMatrix = rectMatrix.createMatrix(2, 3); // Resize to 2x3
                                                                                                                                                                                                                                                                                                    realMatrix.setEntry(0, 0, 4.0);  // Only diagonal entries matter
                                                                                                                                                                                                                                                                                                    realMatrix.setEntry(1, 1, 9.0);
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Get the private squareRoot method via reflection
                                                                                                                                                                                                                                                                                                    Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                                    squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Create a mock instance of the optimizer
                                                                                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                        public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                                                                                                                           double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                        protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Invoke the method
                                                                                                                                                                                                                                                                                                    RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, realMatrix);
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Verify correct dimensions (should be same as input)
                                                                                                                                                                                                                                                                                                    assertEquals(2, result.getRowDimension());
                                                                                                                                                                                                                                                                                                    assertEquals(3, result.getColumnDimension());
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Verify correct square roots were calculated
                                                                                                                                                                                                                                                                                                    assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                                                                    assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // Verify non-diagonal entries are zero
                                                                                                                                                                                                                                                                                                    assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                                                                                    assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    // The mutant would either:
                                                                                                                                                                                                                                                                                                    // 1. Throw ArrayIndexOutOfBoundsException when trying to access row 2
                                                                                                                                                                                                                                                                                                    // 2. Produce a 3x3 matrix with incorrect values
                                                                                                                                                                                                                                                                                                    // Both cases would fail the above assertions
                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                       public void testSquareRootForDiagonalMatrixDetectsSqrtToPowMutation() throws Exception {
                                                                                                                                                                                                                                                                                           // Create test data
                                                                                                                                                                                                                                                                                           double[] diagonalValues = {0.0, 1.0, 4.0, 9.0, 1e-10, 1e10};
                                                                                                                                                                                                                                                                                           DiagonalMatrix input = new DiagonalMatrix(diagonalValues);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Create concrete subclass instance for testing
                                                                                                                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                                               public int getJacobianEvaluations() { return 0; }
                                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                                               public double getRMS() { return 0; }
                                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                                               public double getChiSquare() { return 0; }
                                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                                               public RealMatrix getWeightSquareRoot() { return null; }
                                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                                               public double[][] getCovariances() { return null; }
                                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                                               public double[] guessParametersErrors() { return null; }
                                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                                               protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                                   return null; // Simple implementation for testing
                                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                                           };
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                                           squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                           RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, input);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Verify each diagonal entry
                                                                                                                                                                                                                                                                                           for (int i = 0; i < diagonalValues.length; i++) {
                                                                                                                                                                                                                                                                                               double expected = Math.sqrt(diagonalValues[i]);
                                                                                                                                                                                                                                                                                               double actual = result.getEntry(i, i);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Use strict equality check - sqrt and pow may produce slightly different results
                                                                                                                                                                                                                                                                                               // due to different implementations
                                                                                                                                                                                                                                                                                               assertEquals("Diagonal entry " + i + " differs between sqrt and pow implementations", 
                                                                                                                                                                                                                                                                                                           expected, actual, 0.0);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Additional check - verify off-diagonal elements are zero
                                                                                                                                                                                                                                                                                               for (int j = 0; j < diagonalValues.length; j++) {
                                                                                                                                                                                                                                                                                                   if (i != j) {
                                                                                                                                                                                                                                                                                                       assertEquals(0.0, result.getEntry(i, j), 0.0);
                                                                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                          public void testSquareRootNonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                                              // Create a simple non-diagonal matrix
                                                                                                                                                                                                                                                                              double[][] data = {{1, 2}, {3, 4}};
                                                                                                                                                                                                                                                                              org.apache.commons.math3.linear.RealMatrix matrix = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Create a concrete subclass to test the abstract class
                                                                                                                                                                                                                                                                              class TestOptimizer extends org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer {
                                                                                                                                                                                                                                                                                  public TestOptimizer() {
                                                                                                                                                                                                                                                                                      super(null); // Pass null checker since we don't need it for this test
                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                                                                  protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                      // Dummy implementation since we're only testing squareRoot
                                                                                                                                                                                                                                                                                      return null;
                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                              TestOptimizer optimizer = new TestOptimizer();
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              // Get the private squareRoot method via reflection
                                                                                                                                                                                                                                                                              java.lang.reflect.Method squareRootMethod = org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                                  .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                                                              squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                  // Call the method - should throw NPE for mutant
                                                                                                                                                                                                                                                                                  squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // If we get here, the test fails (original code would return a matrix)
                                                                                                                                                                                                                                                                                  fail("Expected NullPointerException for mutated code");
                                                                                                                                                                                                                                                                              } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                                                                                                                                                                                  // Check if the cause is NPE as expected
                                                                                                                                                                                                                                                                                  if (!(e.getCause() instanceof NullPointerException)) {
                                                                                                                                                                                                                                                                                      fail("Expected NullPointerException but got: " + e.getCause());
                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                     public void testSquareRoot_NonSymmetricMatrix_DetectsTransposeMutant() throws Exception {
                                                                                                                                                                                                                                                                         // Create a non-symmetric matrix where m != m.transpose()
                                                                                                                                                                                                                                                                         double[][] data = {
                                                                                                                                                                                                                                                                             {1, 2},
                                                                                                                                                                                                                                                                             {3, 4}
                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix m = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Create concrete optimizer subclass
                                                                                                                                                                                                                                                                         org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                                                                                             new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                 protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                     return null; // dummy implementation
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Calculate expected square root (original behavior)
                                                                                                                                                                                                                                                                         org.apache.commons.math3.linear.EigenDecomposition dec = new org.apache.commons.math3.linear.EigenDecomposition(m);
                                                                                                                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix expected = dec.getSquareRoot();
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                                                         java.lang.reflect.Method squareRootMethod = optimizer.getClass().getDeclaredMethod("squareRoot", 
                                                                                                                                                                                                                                                                             org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                                                         squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix actual = 
                                                                                                                                                                                                                                                                             (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, m);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Verify they match - compare element by element
                                                                                                                                                                                                                                                                         double[][] expectedData = expected.getData();
                                                                                                                                                                                                                                                                         double[][] actualData = actual.getData();
                                                                                                                                                                                                                                                                         for (int i = 0; i < expectedData.length; i++) {
                                                                                                                                                                                                                                                                             org.junit.Assert.assertArrayEquals(expectedData[i], actualData[i], 1e-10);
                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Additional check - verify the matrix is indeed non-symmetric
                                                                                                                                                                                                                                                                         org.junit.Assert.assertFalse(java.util.Arrays.deepEquals(m.getData(), m.transpose().getData()));
                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                        public void testSquareRootNonDiagonalMatrixDetectsMutant() throws Exception {
                                                                                                                                                                                                                                                            // Import classes via fully qualified names
                                                                                                                                                                                                                                                            org.apache.commons.math3.linear.RealMatrix matrix = 
                                                                                                                                                                                                                                                                new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][]{{1, 2}, {3, 4}});
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Mock EigenDecomposition to return known square root
                                                                                                                                                                                                                                                            org.apache.commons.math3.linear.EigenDecomposition dec = 
                                                                                                                                                                                                                                                                mock(org.apache.commons.math3.linear.EigenDecomposition.class);
                                                                                                                                                                                                                                                            org.apache.commons.math3.linear.RealMatrix expectedSqrt = 
                                                                                                                                                                                                                                                                new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][]{{0.5, 1}, {1.5, 2}});
                                                                                                                                                                                                                                                            when(dec.getSquareRoot()).thenReturn(expectedSqrt);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Create concrete subclass for testing
                                                                                                                                                                                                                                                            class TestOptimizer extends org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer {
                                                                                                                                                                                                                                                                public TestOptimizer() {
                                                                                                                                                                                                                                                                    super(null);
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Implement required abstract method
                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                    return null; // Dummy implementation for testing
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            TestOptimizer optimizer = new TestOptimizer();
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Use reflection to inject our mock EigenDecomposition
                                                                                                                                                                                                                                                            java.lang.reflect.Field decField = org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                .getDeclaredField("eigenDecomposition");
                                                                                                                                                                                                                                                            decField.setAccessible(true);
                                                                                                                                                                                                                                                            decField.set(optimizer, dec);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                                            java.lang.reflect.Method squareRootMethod = 
                                                                                                                                                                                                                                                                org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                    .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                                            squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Call the method
                                                                                                                                                                                                                                                            org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                                                                                                (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Verify the result is the square root (not the original matrix)
                                                                                                                                                                                                                                                            assertNotEquals("Mutant detected: returned original matrix instead of square root", 
                                                                                                                                                                                                                                                                           matrix, result);
                                                                                                                                                                                                                                                            assertEquals(expectedSqrt, result);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Additional verification that we're not just returning input
                                                                                                                                                                                                                                                            for (int i = 0; i < result.getRowDimension(); i++) {
                                                                                                                                                                                                                                                                for (int j = 0; j < result.getColumnDimension(); j++) {
                                                                                                                                                                                                                                                                    assertNotEquals(matrix.getEntry(i, j), result.getEntry(i, j), 0.0001);
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                   public void testSquareRootNonDiagonalMatrix1() throws Exception {
                                                                                                                                                                                                                                                       // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                                                                                       double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                                                                                                                       org.apache.commons.math3.linear.RealMatrix matrix = 
                                                                                                                                                                                                                                                           new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Expected square root of the matrix (precomputed mathematically)
                                                                                                                                                                                                                                                       double sqrt2 = org.apache.commons.math3.util.FastMath.sqrt(2);
                                                                                                                                                                                                                                                       double[][] expectedData = {
                                                                                                                                                                                                                                                           {(1 + sqrt2)/2, (1 - sqrt2)/2},
                                                                                                                                                                                                                                                           {(1 - sqrt2)/2, (1 + sqrt2)/2}
                                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                                       org.apache.commons.math3.linear.RealMatrix expected = 
                                                                                                                                                                                                                                                           new org.apache.commons.math3.linear.Array2DRowRealMatrix(expectedData);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Get the private squareRoot method via reflection
                                                                                                                                                                                                                                                       java.lang.reflect.Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                           .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                                       squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                                                                       org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                                                                                           (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(null, matrix);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify the result matches the expected square root
                                                                                                                                                                                                                                                       assertEquals(expected.getRowDimension(), result.getRowDimension());
                                                                                                                                                                                                                                                       assertEquals(expected.getColumnDimension(), result.getColumnDimension());
                                                                                                                                                                                                                                                       for (int i = 0; i < expected.getRowDimension(); i++) {
                                                                                                                                                                                                                                                           for (int j = 0; j < expected.getColumnDimension(); j++) {
                                                                                                                                                                                                                                                               assertEquals(expected.getEntry(i, j), result.getEntry(i, j), 1e-10);
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Additional check: verify the result is indeed a square root
                                                                                                                                                                                                                                                       org.apache.commons.math3.linear.RealMatrix squared = result.multiply(result);
                                                                                                                                                                                                                                                       for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                                                                                                                                                                                           for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                                                                                                                                                                               assertEquals(matrix.getEntry(i, j), squared.getEntry(i, j), 1e-10);
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                      public void testSquareRootWithNonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                          // Create a simple 2x2 test matrix that isn't diagonal
                                                                                                                                                                                                                                          RealMatrix testMatrix = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                                                                              {2, 1},
                                                                                                                                                                                                                                              {1, 2}
                                                                                                                                                                                                                                          });
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Mock the EigenDecomposition and its expected behavior
                                                                                                                                                                                                                                          EigenDecomposition mockDec = mock(EigenDecomposition.class);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Create expected square root matrix (simplified for test)
                                                                                                                                                                                                                                          RealMatrix expectedSquareRoot = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                                                                              {1.5, 0.5},
                                                                                                                                                                                                                                              {0.5, 1.5}
                                                                                                                                                                                                                                          });
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Mock to return our expected square root when getSquareRoot() is called
                                                                                                                                                                                                                                          when(mockDec.getSquareRoot()).thenReturn(expectedSquareRoot);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Mock to return a different matrix for getD() to detect the mutant
                                                                                                                                                                                                                                          RealMatrix diagonalMatrix = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                                                                              {3, 0},
                                                                                                                                                                                                                                              {0, 3}
                                                                                                                                                                                                                                          });
                                                                                                                                                                                                                                          when(mockDec.getD()).thenReturn(diagonalMatrix);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Create concrete subclass for testing
                                                                                                                                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                              protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                                      OptimizationData... optData) {
                                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                              protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                          };
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                          Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                  .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                          squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Call the method and verify
                                                                                                                                                                                                                                          RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, testMatrix);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Verify the result matches expected
                                                                                                                                                                                                                                          for (int i = 0; i < expectedSquareRoot.getRowDimension(); i++) {
                                                                                                                                                                                                                                              for (int j = 0; j < expectedSquareRoot.getColumnDimension(); j++) {
                                                                                                                                                                                                                                                  assertEquals(expectedSquareRoot.getEntry(i, j), 
                                                                                                                                                                                                                                                              result.getEntry(i, j), 
                                                                                                                                                                                                                                                              1e-10);
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                         public void testSquareRootWithNonSymmetricMatrix() throws Exception {
                                                                                                                                                                                                                             // Create a non-symmetric test matrix (2x2)
                                                                                                                                                                                                                             double[][] data = {
                                                                                                                                                                                                                                 {4, 1},
                                                                                                                                                                                                                                 {3, 9}
                                                                                                                                                                                                                             };
                                                                                                                                                                                                                             RealMatrix testMatrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Verify matrix is non-symmetric
                                                                                                                                                                                                                             assertFalse(testMatrix.equals(testMatrix.transpose()));
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Mock EigenDecomposition to return known square root
                                                                                                                                                                                                                             EigenDecomposition dec = mock(EigenDecomposition.class);
                                                                                                                                                                                                                             RealMatrix mockSqrt = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                                                                 {2, 0.5},
                                                                                                                                                                                                                                 {0.3, 3}
                                                                                                                                                                                                                             });
                                                                                                                                                                                                                             when(dec.getSquareRoot()).thenReturn(mockSqrt);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Create test subclass that implements required abstract method
                                                                                                                                                                                                                             AbstractLeastSquaresOptimizer testOptimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                 protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                     // Minimal implementation just to satisfy abstract method requirement
                                                                                                                                                                                                                                     return null;
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             };
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Use reflection to access private squareRoot method
                                                                                                                                                                                                                             Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                             squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Inject our mock EigenDecomposition
                                                                                                                                                                                                                             Field decField = AbstractLeastSquaresOptimizer.class.getDeclaredField("eigenDecomposition");
                                                                                                                                                                                                                             decField.setAccessible(true);
                                                                                                                                                                                                                             decField.set(testOptimizer, dec);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Call the method and get result
                                                                                                                                                                                                                             RealMatrix result = (RealMatrix) squareRootMethod.invoke(testOptimizer, testMatrix);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Verify the result is not transposed
                                                                                                                                                                                                                             // Check diagonal entries (should be same in both)
                                                                                                                                                                                                                             assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                             assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                             // Check non-diagonal entries (would be swapped if transposed)
                                                                                                                                                                                                                             assertEquals(0.5, result.getEntry(0, 1), 1e-10);  // Would fail if transposed (expect 0.3)
                                                                                                                                                                                                                             assertEquals(0.3, result.getEntry(1, 0), 1e-10);  // Would fail if transposed (expect 0.5)
                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                public void testSquareRootForDiagonalMatrix_DetectsDimensionMutation() throws Exception {
                                                                                                                                                                                                                    // Create a 2x2 diagonal matrix with known values
                                                                                                                                                                                                                    double[] diagonalEntries = {4.0, 9.0};
                                                                                                                                                                                                                    DiagonalMatrix inputMatrix = new DiagonalMatrix(diagonalEntries);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create a concrete subclass for testing
                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        public int getJacobianEvaluations() { return 0; }
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        public double getRMS() { return 0; }
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        public double getChiSquare() { return 0; }
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        public RealMatrix getWeightSquareRoot() { return null; }
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        public double[][] getCovariances() { return null; }
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        public double[] guessParametersErrors() { return null; }
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                            throw new UnsupportedOperationException("Not supported for test");
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to access the private squareRoot method
                                                                                                                                                                                                                    Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                    squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                    RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, inputMatrix);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify the result is a DiagonalMatrix with correct dimensions
                                                                                                                                                                                                                    assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                    assertEquals("Output matrix should have same row dimension as input", 
                                                                                                                                                                                                                                 inputMatrix.getRowDimension(), result.getRowDimension());
                                                                                                                                                                                                                    assertEquals("Output matrix should have same column dimension as input",
                                                                                                                                                                                                                                 inputMatrix.getColumnDimension(), result.getColumnDimension());
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify all diagonal entries are square roots of input
                                                                                                                                                                                                                    for (int i = 0; i < inputMatrix.getRowDimension(); i++) {
                                                                                                                                                                                                                        double expected = Math.sqrt(inputMatrix.getEntry(i, i));
                                                                                                                                                                                                                        double actual = result.getEntry(i, i);
                                                                                                                                                                                                                        assertEquals("Diagonal entry " + i + " should be square root of input",
                                                                                                                                                                                                                                     expected, actual, 1e-10);
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                           public void testSquareRoot_NonDiagonalMatrix_ShouldNotUseScalarAddition() throws Exception {
                                                                                                                                                                                                               // Create a simple non-diagonal matrix
                                                                                                                                                                                                               double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                                                                               org.apache.commons.math3.linear.RealMatrix matrix = 
                                                                                                                                                                                                                   new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Calculate expected square root using original behavior
                                                                                                                                                                                                               org.apache.commons.math3.linear.EigenDecomposition dec = 
                                                                                                                                                                                                                   new org.apache.commons.math3.linear.EigenDecomposition(matrix);
                                                                                                                                                                                                               org.apache.commons.math3.linear.RealMatrix expected = dec.getSquareRoot();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create optimizer instance with dummy implementation
                                                                                                                                                                                                               org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                                   new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                       protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                           return null;
                                                                                                                                                                                                                       }
                                                                                                                                                                                                                   };
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Use reflection to access private squareRoot method
                                                                                                                                                                                                               java.lang.reflect.Method method = optimizer.getClass().getDeclaredMethod("squareRoot", 
                                                                                                                                                                                                                   org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                                               org.apache.commons.math3.linear.RealMatrix actual = 
                                                                                                                                                                                                                   (org.apache.commons.math3.linear.RealMatrix) method.invoke(optimizer, matrix);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify the result matches expected decomposition of original matrix
                                                                                                                                                                                                               for (int i = 0; i < expected.getRowDimension(); i++) {
                                                                                                                                                                                                                   for (int j = 0; j < expected.getColumnDimension(); j++) {
                                                                                                                                                                                                                       assertEquals(expected.getEntry(i, j), actual.getEntry(i, j), 1e-10);
                                                                                                                                                                                                                   }
                                                                                                                                                                                                               }
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Additional verification: ensure the result is indeed a square root
                                                                                                                                                                                                               org.apache.commons.math3.linear.RealMatrix squared = actual.multiply(actual);
                                                                                                                                                                                                               for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                                                                                                                                                   for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                                                                                                                                       assertEquals(matrix.getEntry(i, j), squared.getEntry(i, j), 1e-10);
                                                                                                                                                                                                                   }
                                                                                                                                                                                                               }
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                      public void testSquareRootNonDiagonalMatrixReturnsNonZero() throws Exception {
                                                                                                                                                                                          // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                          double[][] data = {{4, 1}, {1, 4}};
                                                                                                                                                                                          RealMatrix inputMatrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock EigenDecomposition to return known square root
                                                                                                                                                                                          EigenDecomposition mockDec = mock(EigenDecomposition.class);
                                                                                                                                                                                          RealMatrix expectedSqrt = MatrixUtils.createRealMatrix(new double[][]{{2, 0.5}, {0.5, 2}});
                                                                                                                                                                                          when(mockDec.getSquareRoot()).thenReturn(expectedSqrt);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create concrete subclass for testing
                                                                                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                              @Override
                                                                                                                                                                                              protected void setUp() {}
                                                                                                                                                                                              
                                                                                                                                                                                              @Override
                                                                                                                                                                                              public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                 double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                                                                  return null;
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              @Override
                                                                                                                                                                                              protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                  return null;
                                                                                                                                                                                              }
                                                                                                                                                                                          };
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to access private squareRoot method
                                                                                                                                                                                          Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                          squareRootMethod.setAccessible(true);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create spy and inject the mock EigenDecomposition
                                                                                                                                                                                          AbstractLeastSquaresOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to set the private eigenDecomposition field
                                                                                                                                                                                          Field eigenDecompositionField = AbstractLeastSquaresOptimizer.class.getDeclaredField("eigenDecomposition");
                                                                                                                                                                                          eigenDecompositionField.setAccessible(true);
                                                                                                                                                                                          eigenDecompositionField.set(spyOptimizer, mockDec);
                                                                                                                                                                                          
                                                                                                                                                                                          // Call the method via reflection
                                                                                                                                                                                          RealMatrix result = (RealMatrix) squareRootMethod.invoke(spyOptimizer, inputMatrix);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify the result is not zero (would fail on mutant)
                                                                                                                                                                                          assertFalse("Result matrix should not be zero", 
                                                                                                                                                                                                     result.equals(MatrixUtils.createRealMatrix(new double[2][2])));
                                                                                                                                                                                          
                                                                                                                                                                                          // Additional verification that values are correct
                                                                                                                                                                                          assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                          assertEquals(0.5, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                          assertEquals(0.5, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                          assertEquals(2.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                             public void testSquareRootNonDiagonalMatrix2() throws Exception {
                                                                                                                                                                                 // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                 double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                                                 RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                 
                                                                                                                                                                                 // Create a concrete subclass of AbstractLeastSquaresOptimizer for testing
                                                                                                                                                                                 class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                                                                                                                                     public TestOptimizer() {
                                                                                                                                                                                         super(null); // Pass null checker since we don't need it for this test
                                                                                                                                                                                     }
                                                                                                                                                                             
                                                                                                                                                                                     @Override
                                                                                                                                                                                     protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                         return null; // Minimal implementation just to satisfy abstract requirement
                                                                                                                                                                                     }
                                                                                                                                                                                 }
                                                                                                                                                                                 TestOptimizer optimizer = new TestOptimizer();
                                                                                                                                                                                 
                                                                                                                                                                                 // Get the square root using reflection since the method is private
                                                                                                                                                                                 Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                 squareRootMethod.setAccessible(true);
                                                                                                                                                                                 RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify that squaring the result gives back original matrix
                                                                                                                                                                                 RealMatrix squaredResult = sqrtMatrix.multiply(sqrtMatrix);
                                                                                                                                                                                 
                                                                                                                                                                                 // Check if squared result equals original matrix (within some tolerance)
                                                                                                                                                                                 double tolerance = 1e-10;
                                                                                                                                                                                 for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                                                                                                                     for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                                                                                                         assertEquals("Squared root should equal original matrix", 
                                                                                                                                                                                                      matrix.getEntry(i, j), 
                                                                                                                                                                                                      squaredResult.getEntry(i, j), 
                                                                                                                                                                                                      tolerance);
                                                                                                                                                                                     }
                                                                                                                                                                                 }
                                                                                                                                                                                 
                                                                                                                                                                                 // Additional check: verify the result is actually a square root
                                                                                                                                                                                 // (not the negative of it which would be the mutant case)
                                                                                                                                                                                 // We can check one diagonal element is positive since principal square root
                                                                                                                                                                                 // should have positive eigenvalues
                                                                                                                                                                                 assertTrue("Square root should have positive diagonal elements",
                                                                                                                                                                                           sqrtMatrix.getEntry(0, 0) > 0);
                                                                                                                                                                             }

    @Test
                                                                                                                                                            public void testSquareRootNonDiagonalMatrix3() throws Exception {
                                                                                                                                                                // Import required classes
                                                                                                                                                                org.apache.commons.math3.linear.RealMatrix matrix = 
                                                                                                                                                                    new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][]{{2, 1}, {1, 2}});
                                                                                                                                                                
                                                                                                                                                                // Mock EigenDecomposition to return known square root
                                                                                                                                                                org.apache.commons.math3.linear.EigenDecomposition dec = 
                                                                                                                                                                    mock(org.apache.commons.math3.linear.EigenDecomposition.class);
                                                                                                                                                                org.apache.commons.math3.linear.RealMatrix sqrtMatrix = 
                                                                                                                                                                    new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][]{{1.5, 0.5}, {0.5, 1.5}});
                                                                                                                                                                when(dec.getSquareRoot()).thenReturn(sqrtMatrix);
                                                                                                                                                                
                                                                                                                                                                // Create concrete subclass for testing
                                                                                                                                                                class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                                                                                                                    public TestOptimizer() {
                                                                                                                                                                        super(null);
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    // Remove the non-existent method override
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    protected PointVectorValuePair doOptimize() {
                                                                                                                                                                        // Dummy implementation
                                                                                                                                                                        return null;
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                TestOptimizer optimizer = new TestOptimizer();
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access private squareRoot method
                                                                                                                                                                Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                                                                                    "squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                squareRootMethod.setAccessible(true);
                                                                                                                                                                org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                    (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                
                                                                                                                                                                // Verify the result is indeed the square root (A*A should equal original)
                                                                                                                                                                org.apache.commons.math3.linear.RealMatrix squaredResult = result.multiply(result);
                                                                                                                                                                assertArrayEquals(new double[]{2, 1}, squaredResult.getRow(0), 1e-10);
                                                                                                                                                                assertArrayEquals(new double[]{1, 2}, squaredResult.getRow(1), 1e-10);
                                                                                                                                                                
                                                                                                                                                                // Additional check that we're not getting 2*sqrt(M)
                                                                                                                                                                // For the mutant, this would be 4*original matrix
                                                                                                                                                                org.apache.commons.math3.linear.RealMatrix fourTimesOriginal = matrix.scalarMultiply(4);
                                                                                                                                                                assertFalse("Result should not be 2*sqrt(M)", 
                                                                                                                                                                           fourTimesOriginal.equals(squaredResult));
                                                                                                                                                            }

    @Test
                                                                                                                                                   public void testSquareRootWithNonSquareMatrix() throws Exception {
                                                                                                                                                       // Create a non-square diagonal matrix (2 rows x 3 columns)
                                                                                                                                                       double[][] nonSquareData = {{1, 0, 0}, {0, 1, 0}};
                                                                                                                                                       DiagonalMatrix nonSquareMatrix = new DiagonalMatrix(nonSquareData[0].length);
                                                                                                                                                       for (int i = 0; i < nonSquareData.length; i++) {
                                                                                                                                                           for (int j = 0; j < nonSquareData[i].length; j++) {
                                                                                                                                                               if (i == j) {
                                                                                                                                                                   nonSquareMatrix.setEntry(i, j, nonSquareData[i][j]);
                                                                                                                                                               }
                                                                                                                                                           }
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       // Mock the getRowDimension and getColumnDimension to return different values
                                                                                                                                                       RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                                                                                       when(mockMatrix.getRowDimension()).thenReturn(2);
                                                                                                                                                       when(mockMatrix.getColumnDimension()).thenReturn(3);
                                                                                                                                                       when(mockMatrix.getEntry(anyInt(), anyInt())).thenAnswer(inv -> {
                                                                                                                                                           int i = inv.getArgument(0);
                                                                                                                                                           int j = inv.getArgument(1);
                                                                                                                                                           return (i == j && i < 2) ? 1.0 : 0.0; // Diagonal entries for first 2 rows
                                                                                                                                                       });
                                                                                                                                                       when(mockMatrix.isSquare()).thenReturn(false);
                                                                                                                                                       
                                                                                                                                                       // Create concrete subclass for testing
                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                           @Override
                                                                                                                                                           public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f,
                                                                                                                                                                   double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                               return null;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           protected PointVectorValuePair doOptimize() {
                                                                                                                                                               return null;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Use reflection to access private squareRoot method
                                                                                                                                                       Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                       squareRootMethod.setAccessible(true);
                                                                                                                                                       
                                                                                                                                                       try {
                                                                                                                                                           squareRootMethod.invoke(optimizer, mockMatrix);
                                                                                                                                                           fail("Mutant survived - method didn't throw exception for non-square matrix");
                                                                                                                                                       } catch (InvocationTargetException e) {
                                                                                                                                                           // Expected - method should throw exception for non-square matrix
                                                                                                                                                           assertTrue(e.getCause() instanceof org.apache.commons.math3.exception.MathIllegalArgumentException);
                                                                                                                                                       }
                                                                                                                                                   }

    @Test
                                                                                                                                              public void testSquareRootWithDiagonalMatrixCatchesMutant() throws Exception {
                                                                                                                                                  // Create a concrete subclass implementing required abstract methods
                                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                      @Override
                                                                                                                                                      protected PointVectorValuePair doOptimize() {
                                                                                                                                                          return null; // dummy implementation
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                                  
                                                                                                                                                  // Get the private squareRoot method via reflection
                                                                                                                                                  Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                      .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                  squareRootMethod.setAccessible(true);
                                                                                                                                                  
                                                                                                                                                  // Test case 1: Very small number where sqrt and pow might differ
                                                                                                                                                  double[] diagonal1 = {Double.MIN_VALUE};
                                                                                                                                                  RealMatrix m1 = new DiagonalMatrix(diagonal1);
                                                                                                                                                  RealMatrix result1 = (RealMatrix) squareRootMethod.invoke(optimizer, m1);
                                                                                                                                                  assertEquals("Square root of Double.MIN_VALUE should match", 
                                                                                                                                                      Math.sqrt(Double.MIN_VALUE), 
                                                                                                                                                      result1.getEntry(0, 0), 
                                                                                                                                                      1e-16);
                                                                                                                                                      
                                                                                                                                                  // Test case 2: Zero value
                                                                                                                                                  double[] diagonal2 = {0.0};
                                                                                                                                                  RealMatrix m2 = new DiagonalMatrix(diagonal2);
                                                                                                                                                  RealMatrix result2 = (RealMatrix) squareRootMethod.invoke(optimizer, m2);
                                                                                                                                                  assertEquals("Square root of 0 should be 0", 
                                                                                                                                                      0.0, 
                                                                                                                                                      result2.getEntry(0, 0), 
                                                                                                                                                      0.0);
                                                                                                                                                      
                                                                                                                                                  // Test case 3: Negative number (should be NaN)
                                                                                                                                                  double[] diagonal3 = {-1.0};
                                                                                                                                                  RealMatrix m3 = new DiagonalMatrix(diagonal3);
                                                                                                                                                  RealMatrix result3 = (RealMatrix) squareRootMethod.invoke(optimizer, m3);
                                                                                                                                                  assertTrue("Square root of negative should be NaN", 
                                                                                                                                                      Double.isNaN(result3.getEntry(0, 0)));
                                                                                                                                                      
                                                                                                                                                  // Test case 4: Large number where precision might differ
                                                                                                                                                  double[] diagonal4 = {Double.MAX_VALUE};
                                                                                                                                                  RealMatrix m4 = new DiagonalMatrix(diagonal4);
                                                                                                                                                  RealMatrix result4 = (RealMatrix) squareRootMethod.invoke(optimizer, m4);
                                                                                                                                                  assertEquals("Square root of Double.MAX_VALUE should match", 
                                                                                                                                                      Math.sqrt(Double.MAX_VALUE), 
                                                                                                                                                      result4.getEntry(0, 0), 
                                                                                                                                                      1e-292);  // Very loose tolerance due to magnitude
                                                                                                                                              }

    @Test
                                                                                                                     public void testSquareRootWithNonSymmetricMatrix1() throws Exception {
                                                                                                                         // Create a non-symmetric matrix where m != m.transpose()
                                                                                                                         double[][] data = {
                                                                                                                             {1, 2},
                                                                                                                             {3, 4}
                                                                                                                         };
                                                                                                                         org.apache.commons.math3.linear.RealMatrix m = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                         
                                                                                                                         // Calculate expected square root using original method logic
                                                                                                                         org.apache.commons.math3.linear.EigenDecomposition dec = new org.apache.commons.math3.linear.EigenDecomposition(m);
                                                                                                                         org.apache.commons.math3.linear.RealMatrix expected = dec.getSquareRoot();
                                                                                                                         
                                                                                                                         // Create concrete subclass to test private method
                                                                                                                         org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                             new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(
                                                                                                                                 (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointVectorValuePair>) null) {
                                                                                                                                     @Override
                                                                                                                                     protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                         // Dummy implementation
                                                                                                                                         return null;
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     @Override
                                                                                                                                     protected void setUp() {
                                                                                                                                         // Dummy implementation
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     @Override
                                                                                                                                     protected double[] computeResiduals(double[] objectiveValue) {
                                                                                                                                         // Dummy implementation
                                                                                                                                         return new double[0];
                                                                                                                                     }
                                                                                                                                 };
                                                                                                                         
                                                                                                                         // Use reflection to access private squareRoot method
                                                                                                                         java.lang.reflect.Method squareRootMethod = org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                             .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                         squareRootMethod.setAccessible(true);
                                                                                                                         org.apache.commons.math3.linear.RealMatrix result = (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, m);
                                                                                                                         
                                                                                                                         // Verify the result matches expected square root
                                                                                                                         assertEquals(expected, result);
                                                                                                                         
                                                                                                                         // Additional verification - check a specific entry that would differ with transpose
                                                                                                                         assertEquals(expected.getEntry(0, 1), result.getEntry(0, 1), 1e-10);
                                                                                                                         
                                                                                                                         // The mutant using m.transpose() would produce different results here
                                                                                                                     }

    @Test
                                                                                                            public void testSquareRootNonDiagonalMatrix4() {
                                                                                                                // Create a non-diagonal test matrix (2x2)
                                                                                                                double[][] data = {{2, 1}, {1, 2}};
                                                                                                                RealMatrix testMatrix = MatrixUtils.createRealMatrix(data);
                                                                                                                
                                                                                                                // Create expected square root using EigenDecomposition (original behavior)
                                                                                                                EigenDecomposition dec = new EigenDecomposition(testMatrix);
                                                                                                                RealMatrix expected = dec.getSquareRoot();
                                                                                                                
                                                                                                                // Create mock of AbstractLeastSquaresOptimizer
                                                                                                                AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                
                                                                                                                // Call the method (using reflection since squareRoot is private)
                                                                                                                try {
                                                                                                                    java.lang.reflect.Method method = AbstractLeastSquaresOptimizer.class
                                                                                                                        .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                    method.setAccessible(true);
                                                                                                                    RealMatrix result = (RealMatrix) method.invoke(optimizer, testMatrix);
                                                                                                                    
                                                                                                                    // Verify the result matches expected square root
                                                                                                                    assertEquals(expected, result);
                                                                                                                    
                                                                                                                    // Additional check that would catch the mutant:
                                                                                                                    // Square root matrix should not equal its transpose for this test case
                                                                                                                    assertNotEquals(result, result.transpose());
                                                                                                                    
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to test private squareRoot method: " + e.getMessage());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                   public void testSquareRootNonDiagonalMatrix5() {
                                                                                                       // Create a 2x2 non-diagonal test matrix
                                                                                                       double[][] data = {{2, 1}, {1, 2}};
                                                                                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                                                                       
                                                                                                       // Create the expected square root (precomputed)
                                                                                                       double[][] expectedSqrtData = {{1.3660254, 0.3660254}, {0.3660254, 1.3660254}};
                                                                                                       RealMatrix expectedSqrt = MatrixUtils.createRealMatrix(expectedSqrtData);
                                                                                                       
                                                                                                       // Create concrete instance of abstract class
                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                           // Implement required abstract methods with empty implementations
                                                                                                           @Override
                                                                                                           public int getJacobianEvaluations() {
                                                                                                               return 0;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public double getRMS() {
                                                                                                               return 0;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public double getChiSquare() {
                                                                                                               return 0;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public RealMatrix getWeightSquareRoot() {
                                                                                                               return null;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public double[][] getCovariances() {
                                                                                                               return null;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public double[][] getCovariances(double threshold) {
                                                                                                               return null;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public double[] guessParametersErrors() {
                                                                                                               return null;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public PointVectorValuePair optimize(int maxEval, DifferentiableMultivariateVectorFunction f, 
                                                                                                                                              double[] target, double[] weights, double[] startPoint) {
                                                                                                               return null;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                              double[] target, double[] weights, double[] startPoint) {
                                                                                                               return null;
                                                                                                           }
                                                                                                           
                                                                                                           @Override
                                                                                                           protected PointVectorValuePair doOptimize() {
                                                                                                               return null;
                                                                                                           }
                                                                                                       };
                                                                                                       
                                                                                                       // Use reflection to access private method (since it's private)
                                                                                                       try {
                                                                                                           java.lang.reflect.Method method = AbstractLeastSquaresOptimizer.class
                                                                                                               .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                           method.setAccessible(true);
                                                                                                           
                                                                                                           // Call the method and get result
                                                                                                           RealMatrix result = (RealMatrix) method.invoke(optimizer, matrix);
                                                                                                           
                                                                                                           // Verify the result matches expected square root
                                                                                                           assertEquals(expectedSqrt, result);
                                                                                                           
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to test private squareRoot method: " + e.getMessage());
                                                                                                       }
                                                                                                   }

    @Test
                                                                                              public void testComputeResidualsArraySize() throws Exception {
                                                                                                  // Setup test data
                                                                                                  double[] objectiveValue = new double[]{1.0, 2.0, 3.0};
                                                                                                  double[] target = new double[]{1.1, 2.1, 3.1};
                                                                                                  
                                                                                                  // Create concrete subclass to test
                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                      @Override
                                                                                                      protected PointVectorValuePair doOptimize() {
                                                                                                          return null; // dummy implementation
                                                                                                      }
                                                                                                  };
                                                                                                  
                                                                                                  // Use reflection to set protected field
                                                                                                  Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                  objectiveField.setAccessible(true);
                                                                                                  objectiveField.set(optimizer, objectiveValue);
                                                                                                  
                                                                                                  // Use reflection to call protected method
                                                                                                  Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                      "computeResiduals", double[].class);
                                                                                                  computeResidualsMethod.setAccessible(true);
                                                                                                  double[] residuals = (double[]) computeResidualsMethod.invoke(optimizer, target);
                                                                                                  
                                                                                                  // Verify the array size matches target length
                                                                                                  assertEquals("Residuals array should have same length as target", 
                                                                                                             target.length, residuals.length);
                                                                                                  
                                                                                                  // Verify calculations for each element
                                                                                                  for (int i = 0; i < target.length; i++) {
                                                                                                      assertEquals(objectiveValue[i] - target[i], residuals[i], 1e-10);
                                                                                                  }
                                                                                                  
                                                                                                  // Verify no ArrayIndexOutOfBoundsException occurs
                                                                                                  try {
                                                                                                      double lastElement = residuals[target.length - 1];
                                                                                                  } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                      fail("Should not throw ArrayIndexOutOfBoundsException");
                                                                                                  }
                                                                                              }

    @Test
                                                                                         public void testComputeResidualsWithNonEmptyTarget() throws Exception {
                                                                                             // Setup test data
                                                                                             double[] target = new double[]{1.0, 2.0, 3.0};
                                                                                             double[] objectiveValue = new double[]{1.1, 2.1, 3.1};
                                                                                             
                                                                                             // Create concrete subclass for testing
                                                                                             class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                                                 public TestOptimizer() {
                                                                                                     super(null);
                                                                                                 }
                                                                                                 
                                                                                                 @Override
                                                                                                 protected PointVectorValuePair doOptimize() {
                                                                                                     return null; // Not needed for this test
                                                                                                 }
                                                                                                 
                                                                                                 public double[] testComputeResiduals(double[] objectiveValue) {
                                                                                                     return computeResiduals(objectiveValue);
                                                                                                 }
                                                                                             }
                                                                                             
                                                                                             // Create test instance and set target
                                                                                             TestOptimizer optimizer = new TestOptimizer();
                                                                                             try {
                                                                                                 Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                                                                 targetField.setAccessible(true);
                                                                                                 targetField.set(optimizer, target);
                                                                                             } catch (Exception e) {
                                                                                                 fail("Failed to set target field: " + e.getMessage());
                                                                                             }
                                                                                             
                                                                                             // Call the method
                                                                                             double[] residuals = optimizer.testComputeResiduals(objectiveValue);
                                                                                             
                                                                                             // Verify results
                                                                                             assertNotNull(residuals);
                                                                                             assertEquals(target.length, residuals.length);
                                                                                             for (int i = 0; i < residuals.length; i++) {
                                                                                                 assertEquals(objectiveValue[i] - target[i], residuals[i], 1e-10);
                                                                                             }
                                                                                         }

    @Test
                                                                                    public void testSquareRootDiagonalMatrixBoundary() throws Exception {
                                                                                        // Create a 2x2 diagonal matrix
                                                                                        double[] diagonal = {4.0, 9.0};
                                                                                        DiagonalMatrix matrix = new DiagonalMatrix(diagonal);
                                                                                        
                                                                                        // Create a concrete subclass of AbstractLeastSquaresOptimizer
                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                            @Override
                                                                                            protected PointVectorValuePair doOptimize() {
                                                                                                return null; // Not needed for this test
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Use reflection to access private squareRoot method
                                                                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                            .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                        squareRootMethod.setAccessible(true);
                                                                                        RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                        
                                                                                        // Verify correct square root values
                                                                                        assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                        assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                        
                                                                                        // Verify non-diagonal elements are zero
                                                                                        assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                        assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                    }

    @Test
                                                                                    public void testSquareRootDiagonalMatrixCatchesMutant() throws Exception {
                                                                                        // Create a mock DiagonalMatrix that throws exception when accessed beyond bounds
                                                                                        DiagonalMatrix matrix = mock(DiagonalMatrix.class);
                                                                                        when(matrix.getRowDimension()).thenReturn(2);
                                                                                        
                                                                                        // Mock to throw exception when i=2 is accessed (mutant case)
                                                                                        when(matrix.getEntry(0, 0)).thenReturn(4.0);
                                                                                        when(matrix.getEntry(1, 1)).thenReturn(9.0);
                                                                                        when(matrix.getEntry(2, 2)).thenThrow(new ArrayIndexOutOfBoundsException());
                                                                                        
                                                                                        // Create anonymous class implementing required abstract method
                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                            @Override
                                                                                            protected PointVectorValuePair doOptimize() {
                                                                                                return null; // Not used in this test
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Use reflection to access private squareRoot method
                                                                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                        squareRootMethod.setAccessible(true);
                                                                                        
                                                                                        try {
                                                                                            // This will throw exception for the mutant
                                                                                            squareRootMethod.invoke(optimizer, matrix);
                                                                                            // Original code would never reach here as it would complete successfully
                                                                                            fail("Original code should not reach here - mutant should have thrown exception");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            // Verify the expected exception is thrown
                                                                                            assertTrue(e.getCause() instanceof ArrayIndexOutOfBoundsException);
                                                                                        }
                                                                                    }

    @Test
                                                                           public void testSquareRootDiagonalMatrixFirstElement() throws Exception {
                                                                               // Create a DiagonalMatrix with known values
                                                                               double[] diagonalValues = {4.0, 9.0, 16.0}; // Square roots should be 2, 3, 4
                                                                               RealMatrix matrix = new DiagonalMatrix(diagonalValues);
                                                                               
                                                                               // Create a mock of AbstractLeastSquaresOptimizer
                                                                               AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                               
                                                                               // Use reflection to access private squareRoot method
                                                                               Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                       .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                               squareRootMethod.setAccessible(true);
                                                                               RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                               
                                                                               // Verify all diagonal elements, especially index 0
                                                                               assertEquals("First element (index 0) should be square rooted", 
                                                                                           2.0, sqrtMatrix.getEntry(0, 0), 1e-10);
                                                                               assertEquals("Second element (index 1) should be square rooted", 
                                                                                           3.0, sqrtMatrix.getEntry(1, 1), 1e-10);
                                                                               assertEquals("Third element (index 2) should be square rooted", 
                                                                                           4.0, sqrtMatrix.getEntry(2, 2), 1e-10);
                                                                               
                                                                               // Additional check: verify matrix dimension is preserved
                                                                               assertEquals("Matrix row dimension should match", 
                                                                                           diagonalValues.length, sqrtMatrix.getRowDimension());
                                                                               assertEquals("Matrix column dimension should match", 
                                                                                           diagonalValues.length, sqrtMatrix.getColumnDimension());
                                                                           }

    @Test
                                                                  public void testComputeResidualsDetectsSignChangeMutant() {
                                                                      // Setup test data
                                                                      final double[] target = {1.0, -2.0, 3.5};
                                                                      final double[] objectiveValue = {0.5, -1.0, 2.0};
                                                                      final double[] expectedResiduals = {0.5, -1.0, 1.5}; // target - objective
                                                                      
                                                                      // Create testable concrete subclass
                                                                      class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                          private double[] testTarget;
                                                                          
                                                                          public TestOptimizer() {
                                                                              super(null); // pass null checker since we don't need it for this test
                                                                              this.testTarget = target;
                                                                          }
                                                                          
                                                                          @Override
                                                                          protected PointVectorValuePair doOptimize() {
                                                                              return null; // dummy implementation
                                                                          }
                                                                          
                                                                          @Override
                                                                          protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                                                              return null; // dummy implementation
                                                                          }
                                                                          
                                                                          public double[] publicComputeResiduals(double[] objectiveValue) {
                                                                              try {
                                                                                  // Use reflection to set the private target field
                                                                                  Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                                                  targetField.setAccessible(true);
                                                                                  targetField.set(this, testTarget);
                                                                              } catch (Exception e) {
                                                                                  throw new RuntimeException("Failed to set target field", e);
                                                                              }
                                                                              return computeResiduals(objectiveValue);
                                                                          }
                                                                          
                                                                          public void setTestTarget(double[] target) {
                                                                              this.testTarget = target;
                                                                          }
                                                                      }
                                                                      
                                                                      TestOptimizer optimizer = new TestOptimizer();
                                                                      
                                                                      // Call the method
                                                                      double[] actualResiduals = optimizer.publicComputeResiduals(objectiveValue);
                                                                      
                                                                      // Verify the results - this will fail if the mutant is present
                                                                      // because mutant would return [1.5, -3.0, 5.5] (target + objective)
                                                                      assertArrayEquals("Residuals calculation is incorrect", 
                                                                                      expectedResiduals, 
                                                                                      actualResiduals, 
                                                                                      1e-15);
                                                                      
                                                                      // Additional test with zeros
                                                                      double[] zeroTarget = {0.0, 0.0};
                                                                      double[] zeroObjective = {0.0, 0.0};
                                                                      double[] zeroExpected = {0.0, 0.0};
                                                                      optimizer.setTestTarget(zeroTarget);
                                                                      double[] zeroActual = optimizer.publicComputeResiduals(zeroObjective);
                                                                      assertArrayEquals("Zero residuals not handled correctly",
                                                                                      zeroExpected,
                                                                                      zeroActual,
                                                                                      1e-15);
                                                                      
                                                                      // Test with opposite signs
                                                                      double[] oppositeTarget = {5.0, -5.0};
                                                                      double[] oppositeObjective = {-5.0, 5.0};
                                                                      double[] oppositeExpected = {10.0, -10.0};
                                                                      optimizer.setTestTarget(oppositeTarget);
                                                                      double[] oppositeActual = optimizer.publicComputeResiduals(oppositeObjective);
                                                                      assertArrayEquals("Opposite sign residuals not handled correctly",
                                                                                      oppositeExpected,
                                                                                      oppositeActual,
                                                                                      1e-15);
                                                                  }

    @Test
                                                         public void testComputeResidualsDetectsSignMutation() {
                                                             // Setup test data
                                                             final double[] target = {1.0, 2.0, 3.0, 4.0};
                                                             final double[] objectiveValue = {1.5, 1.5, 3.5, 4.5};
                                                             final double[] expectedResiduals = {-0.5, 0.5, -0.5, -0.5}; // target - objective
                                                             
                                                             // Create testable subclass
                                                             class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                 public TestOptimizer() {
                                                                     super(null);
                                                                 }
                                                                 
                                                                 @Override
                                                                 protected PointVectorValuePair doOptimize() {
                                                                     return null; // Not needed for this test
                                                                 }
                                                                 
                                                                 public double[] testComputeResiduals(double[] objectiveValue) {
                                                                     try {
                                                                         // Use reflection to set private target field
                                                                         Field targetField = BaseAbstractMultivariateVectorOptimizer.class.getDeclaredField("target");
                                                                         targetField.setAccessible(true);
                                                                         targetField.set(this, target);
                                                                     } catch (Exception e) {
                                                                         throw new RuntimeException("Failed to set target field", e);
                                                                     }
                                                                     return computeResiduals(objectiveValue);
                                                                 }
                                                             }
                                                             
                                                             TestOptimizer optimizer = new TestOptimizer();
                                                             
                                                             // Call the method
                                                             double[] actualResiduals = optimizer.testComputeResiduals(objectiveValue);
                                                             
                                                             // Verify the results
                                                             assertEquals("Residuals array length mismatch", 
                                                                          target.length, actualResiduals.length);
                                                             
                                                             for (int i = 0; i < target.length; i++) {
                                                                 assertEquals("Residual at index " + i + " is incorrect",
                                                                              expectedResiduals[i], 
                                                                              target[i] - objectiveValue[i], 
                                                                              1e-15);
                                                                 // This assertion would fail if the mutant survives
                                                                 assertEquals("Residual sign is incorrect (mutant survived)",
                                                                              expectedResiduals[i], 
                                                                              actualResiduals[i], 
                                                                              1e-15);
                                                             }
                                                             
                                                             // Additional test case with all positive differences
                                                             final double[] target2 = {5.0, 6.0, 7.0};
                                                             final double[] objectiveValue2 = {4.0, 5.0, 6.0};
                                                             final double[] expectedResiduals2 = {1.0, 1.0, 1.0};
                                                             
                                                             // Need to create new optimizer with new target
                                                             TestOptimizer optimizer2 = new TestOptimizer();
                                                             try {
                                                                 Field targetField = BaseAbstractMultivariateVectorOptimizer.class.getDeclaredField("target");
                                                                 targetField.setAccessible(true);
                                                                 targetField.set(optimizer2, target2);
                                                             } catch (Exception e) {
                                                                 throw new RuntimeException("Failed to set target field", e);
                                                             }
                                                             double[] actualResiduals2 = optimizer2.testComputeResiduals(objectiveValue2);
                                                             
                                                             for (int i = 0; i < target2.length; i++) {
                                                                 assertEquals("Positive residual test failed at index " + i,
                                                                              expectedResiduals2[i],
                                                                              actualResiduals2[i],
                                                                              1e-15);
                                                             }
                                                         }

    @Test(expected = NullPointerException.class)
                                                    public void testMutantWithNullTarget() {
                                                        // Create mock optimizer
                                                        AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                        
                                                        // Define required parameters
                                                        DifferentiableMultivariateVectorFunction function = mock(DifferentiableMultivariateVectorFunction.class);
                                                        double[] target = null;  // Explicit null target
                                                        double[] weights = new double[]{1.0};  // Dummy weights
                                                        double[] startPoint = new double[]{0.0};  // Dummy start point
                                                        
                                                        // Simulate the mutant behavior by returning null target
                                                        when(optimizer.getTarget()).thenReturn(null);
                                                        
                                                        // This should throw NullPointerException when trying to compute residuals
                                                        optimizer.optimize(100, function, target, weights, startPoint);
                                                    }

    @Test
                                                public void testSquareRootWithNullMatrix() {
                                                    try {
                                                        // Get the squareRoot method using reflection
                                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                            .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                        squareRootMethod.setAccessible(true);
                                                        
                                                        // Invoke the method on null (static method invocation)
                                                        squareRootMethod.invoke(null, (RealMatrix) null);
                                                        fail("Expected NullPointerException");
                                                    } catch (NullPointerException e) {
                                                        // Expected behavior
                                                    } catch (Exception e) {
                                                        fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                    }
                                                }

    @Test
                                            public void testOptimizeWithValidTarget() {
                                                // Setup test data
                                                double[] target = new double[]{1.0, 2.0, 3.0};
                                                double[] weights = new double[]{1.0, 1.0, 1.0};
                                                double[] startPoint = new double[]{0.0, 0.0, 0.0};
                                                
                                                // Create mock optimizer
                                                AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                when(optimizer.getTarget()).thenReturn(target);
                                                
                                                // Mock the optimize method to return a dummy result
                                                PointVectorValuePair mockResult = new PointVectorValuePair(new double[]{1.0, 2.0, 3.0}, new double[]{0.0, 0.0, 0.0});
                                                when(optimizer.optimize(anyInt(), any(DifferentiableMultivariateVectorFunction.class), 
                                                     eq(target), eq(weights), eq(startPoint))).thenReturn(mockResult);
                                                
                                                // Test that optimization works with proper target values
                                                DifferentiableMultivariateVectorFunction function = mock(DifferentiableMultivariateVectorFunction.class);
                                                PointVectorValuePair result = optimizer.optimize(100, function, target, weights, startPoint);
                                                
                                                // Verify getTarget() was called
                                                verify(optimizer).getTarget();
                                                
                                                // Test squareRoot with DiagonalMatrix
                                                DiagonalMatrix diagMatrix = new DiagonalMatrix(new double[]{4.0, 9.0, 16.0});
                                                
                                                // Use reflection to test private squareRoot method
                                                try {
                                                    Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                    squareRootMethod.setAccessible(true);
                                                    RealMatrix sqrtDiag = (RealMatrix) squareRootMethod.invoke(optimizer, diagMatrix);
                                                    
                                                    // Extract diagonal elements for comparison
                                                    double[] diagonal = new double[]{
                                                        sqrtDiag.getEntry(0, 0),
                                                        sqrtDiag.getEntry(1, 1),
                                                        sqrtDiag.getEntry(2, 2)
                                                    };
                                                    assertArrayEquals(new double[]{2.0, 3.0, 4.0}, diagonal, 1e-10);
                                                    
                                                    // Test squareRoot with non-DiagonalMatrix
                                                    RealMatrix regularMatrix = MatrixUtils.createRealMatrix(new double[][]{{2,1},{1,2}});
                                                    RealMatrix sqrtRegular = (RealMatrix) squareRootMethod.invoke(optimizer, regularMatrix);
                                                    assertNotNull(sqrtRegular);
                                                } catch (Exception e) {
                                                    fail("Failed to test squareRoot method: " + e.getMessage());
                                                }
                                            }

    @Test
                               public void testOptimizeWithTarget() {
                                   // Setup test data
                                   double[] startPoint = new double[]{1.0, 2.0};
                                   double[] target = new double[]{3.0, 4.0};
                                   double[] weights = new double[]{1.0, 1.0};
                                   
                                   // Mock the function
                                   MultivariateDifferentiableVectorFunction f = mock(MultivariateDifferentiableVectorFunction.class);
                                   when(f.value(any(double[].class))).thenReturn(new double[]{2.9, 4.1}); // close to target
                                   
                                   // Create custom convergence checker
                                   ConvergenceChecker<PointVectorValuePair> checker = new ConvergenceChecker<PointVectorValuePair>() {
                                       private final double relativeThreshold = 1e-6;
                                       private final double absoluteThreshold = 1e-6;
                                       
                                       @Override
                                       public boolean converged(int iteration, PointVectorValuePair previous, PointVectorValuePair current) {
                                           double[] p = previous.getValueRef();
                                           double[] c = current.getValueRef();
                                           for (int i = 0; i < p.length; ++i) {
                                               double difference = Math.abs(p[i] - c[i]);
                                               double size = Math.max(Math.abs(p[i]), Math.abs(c[i]));
                                               if (difference > size * relativeThreshold && difference > absoluteThreshold) {
                                                   return false;
                                               }
                                           }
                                           return true;
                                       }
                                   };
                                   
                                   // Create optimizer instance
                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(checker) {
                                       @Override
                                       protected PointVectorValuePair doOptimize() {
                                           double[] params = getStartPoint();
                                           double[] res = computeResiduals(f.value(params));
                                           double cost = computeCost(res);
                                           return new PointVectorValuePair(params, f.value(params));
                                       }
                                   };
                                   
                                   // Run optimization
                                   PointVectorValuePair result = optimizer.optimize(100, f, target, weights, startPoint);
                                   
                                   // Verify results are close to target
                                   double[] optimizedValues = result.getValueRef();
                                   assertEquals(target[0], optimizedValues[0], 0.1); // within tolerance
                                   assertEquals(target[1], optimizedValues[1], 0.1); // within tolerance
                                   
                                   // Verify cost is low (since we're close to target)
                                   // Use reflection to access protected methods
                                   try {
                                       Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("computeResiduals", double[].class);
                                       computeResiduals.setAccessible(true);
                                       Method computeCost = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("computeCost", double[].class);
                                       computeCost.setAccessible(true);
                                       
                                       double[] residuals = (double[]) computeResiduals.invoke(optimizer, optimizedValues);
                                       double cost = (double) computeCost.invoke(optimizer, residuals);
                                       assertTrue(cost < 0.1);
                                   } catch (Exception e) {
                                       fail("Failed to access protected methods via reflection: " + e.getMessage());
                                   }
                               }

    @Test
                      public void testSquareRootWithDiagonalMatrix() throws Exception {
                          // Create a test DiagonalMatrix
                          double[] diagonal = {4.0, 9.0, 16.0};
                          DiagonalMatrix m = new DiagonalMatrix(diagonal);
                          
                          // Create a concrete subclass for testing
                          class TestOptimizer extends AbstractLeastSquaresOptimizer {
                              public TestOptimizer() {
                                  super(null);
                              }
                              
                              @Override
                              protected PointVectorValuePair doOptimize() {
                                  // Dummy implementation since we're only testing squareRoot
                                  return null;
                              }
                          }
                          TestOptimizer optimizer = new TestOptimizer();
                          
                          // Use reflection to access private squareRoot method
                          Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                              .getDeclaredMethod("squareRoot", RealMatrix.class);
                          squareRootMethod.setAccessible(true);
                          RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, m);
                          
                          // Verify it's a diagonal matrix with square roots
                          assertTrue(result instanceof DiagonalMatrix);
                          assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                          assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                          assertEquals(4.0, result.getEntry(2, 2), 1e-10);
                      }

    @Test
                      public void testSquareRootWithNonDiagonalMatrix1() throws Exception {
                          // Create a test non-diagonal matrix
                          double[][] data = {{2, 1}, {1, 2}};
                          RealMatrix m = MatrixUtils.createRealMatrix(data);
                          
                          // Create a concrete subclass of AbstractLeastSquaresOptimizer
                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                              @Override
                              protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                  return null;
                              }
                              
                              @Override
                              protected PointVectorValuePair doOptimize() {
                                  return null;
                              }
                              
                              @Override
                              public int getJacobianEvaluations() {
                                  return 0;
                              }
                              
                              @Override
                              public double getRMS() {
                                  return 0;
                              }
                              
                              @Override
                              public double getChiSquare() {
                                  return 0;
                              }
                              
                              @Override
                              public RealMatrix getWeightSquareRoot() {
                                  return null;
                              }
                          };
                          
                          // Use reflection to access the private squareRoot method
                          Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                          squareRootMethod.setAccessible(true);
                          
                          // Call the method
                          RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, m);
                          
                          // Verify the result is correct (approximately)
                          RealMatrix expected = MatrixUtils.createRealMatrix(new double[][]{{1.5, 0.5}, {0.5, 1.5}});
                          for (int i = 0; i < expected.getRowDimension(); i++) {
                              for (int j = 0; j < expected.getColumnDimension(); j++) {
                                  assertEquals(expected.getEntry(i, j), result.getEntry(i, j), 1e-10);
                              }
                          }
                      }

    @Test
             public void testComputeResidualsWithDifferentLengths() throws Exception {
                 // Setup test object - need to implement abstract methods
                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                     @Override
                     protected PointVectorValuePair doOptimize() {
                         // Dummy implementation
                         return null;
                     }
                     
                     @Override
                     protected void setUp() {
                         // Dummy implementation
                     }
                 };
                 
                 // Test case with valid input
                 double[] objectiveValue = {1.0, 2.0};
                 
                 // Use reflection to access protected method
                 Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                     "computeResiduals", double[].class);
                 computeResidualsMethod.setAccessible(true);
                 double[] residuals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                 
                 assertEquals(objectiveValue.length, residuals.length);
                 
                 // Note: The original test was trying to test behavior with mismatched lengths,
                 // but the actual computeResiduals method only takes one parameter,
                 // so those test cases don't apply to this method
             }

    @Test
    public void testSquareRootThrowsCorrectDimensionMismatch() throws Exception {
        // Create a mock matrix that will throw DimensionMismatchException
        RealMatrix mockMatrix = mock(RealMatrix.class);
        when(mockMatrix.getRowDimension()).thenReturn(3);
        when(mockMatrix.getEntry(anyInt(), anyInt()))
            .thenThrow(new DimensionMismatchException(2, 3)); // Expected length 2, actual 3
        
        // Set up exception expectation
        thrown.expect(DimensionMismatchException.class);
        thrown.expectMessage("3"); // Original would show 3, mutant would show 2 (3-1)
        
        // Create concrete subclass for testing
        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
            // Implement required abstract methods with dummy implementations
            @Override
            public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f,
                                               double[] target, double[] weights, double[] startPoint) {
                return null;
            }
            
            @Override
            protected PointVectorValuePair doOptimize() {
                return null;
            }
        };
        
        // Use reflection to access private squareRoot method
        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
        squareRootMethod.setAccessible(true);
        squareRootMethod.invoke(optimizer, mockMatrix);
    }


}
