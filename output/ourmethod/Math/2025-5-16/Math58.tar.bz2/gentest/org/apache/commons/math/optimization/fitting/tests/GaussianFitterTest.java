package gentest.org.apache.commons.math.optimization.fitting.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.fitting.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.analysis.function.Gaussian;
import org.apache.commons.math.analysis.ParametricUnivariateRealFunction;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.fitting.CurveFitter;
import org.apache.commons.math.optimization.fitting.WeightedObservedPoint;
 
public class GaussianFitterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                             public void testFit_WithValidInitialGuess() {
                                                                                                 // Setup
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // Valid initial guess parameters: norm, mean, sigma
                                                                                                 double[] initialGuess = {1.0, 0.0, 1.0};
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit(initialGuess);
                                                                                                 
                                                                                                 // Verify - basic checks since actual optimization results are complex
                                                                                                 assertNotNull(result);
                                                                                                 assertEquals(3, result.length);
                                                                                                 assertTrue(result[0] > 0); // norm should be positive
                                                                                                 assertTrue(result[2] > 0); // sigma should be positive
                                                                                             }

    @Test
                                                                                             public void testFit_WithInvalidInitialGuess_NegativeSigma() {
                                                                                                 // Setup
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // Invalid initial guess with negative sigma
                                                                                                 double[] initialGuess = {1.0, 0.0, -1.0};
                                                                                                 
                                                                                                 // Execute and verify
                                                                                                 double[] result = fitter.fit(initialGuess);
                                                                                                 assertNotNull(result);
                                                                                                 assertEquals(3, result.length);
                                                                                                 // The method should handle negative sigma by returning infinity values
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[0], 0.0);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[1], 0.0);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[2], 0.0);
                                                                                             }

    @Test
                                                                                             public void testFit_WithNullInitialGuess() {
                                                                                                 // Setup
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // Expect exception
                                                                                                 thrown.expect(NullPointerException.class);
                                                                                                 
                                                                                                 // Execute
                                                                                                 fitter.fit(null);
                                                                                             }

    @Test
                                                                                             public void testFit_WithWrongSizeInitialGuess() {
                                                                                                 // Setup
                                                                                                 DifferentiableMultivariateVectorialOptimizer optimizer = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // Initial guess with wrong size
                                                                                                 double[] initialGuess = {1.0, 0.0}; // needs 3 parameters
                                                                                                 
                                                                                                 // Expect exception
                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                 
                                                                                                 // Execute
                                                                                                 fitter.fit(initialGuess);
                                                                                             }

    @Test
                                                                                             public void testValueMethod_WithValidParameters() {
                                                                                                 // Setup test for the anonymous function's value method
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // This tests the internal anonymous function's behavior
                                                                                                 double x = 0.0;
                                                                                                 double[] params = {1.0, 0.0, 1.0}; // norm, mean, sigma
                                                                                                 
                                                                                                 // Need to get the function to test it
                                                                                                 double[] result = fitter.fit(params);
                                                                                                 
                                                                                                 // The actual test is that it didn't throw exceptions and returned finite values
                                                                                                 assertNotNull(result);
                                                                                                 assertTrue(Double.isFinite(result[0]));
                                                                                                 assertTrue(Double.isFinite(result[1]));
                                                                                                 assertTrue(Double.isFinite(result[2]));
                                                                                             }

    @Test
                                                                                             public void testValueMethod_WithInvalidParameters() {
                                                                                                 // Setup test for the anonymous function's value method with invalid params
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 org.apache.commons.math.optimization.fitting.GaussianFitter fitter = 
                                                                                                     new org.apache.commons.math.optimization.fitting.GaussianFitter(optimizer);
                                                                                                 
                                                                                                 double x = 0.0;
                                                                                                 double[] params = {1.0, 0.0, -1.0}; // negative sigma
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit(params);
                                                                                                 
                                                                                                 // Verify it returns infinity for invalid parameters
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[0], 0.0);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[1], 0.0);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[2], 0.0);
                                                                                             }

    @Test
                                                                                             public void testGradientMethod_WithValidParameters() {
                                                                                                 // Setup test for the anonymous function's gradient method
                                                                                                 DifferentiableMultivariateVectorialOptimizer optimizer = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // Create sample data points for fitting
                                                                                                 WeightedObservedPoint[] points = new WeightedObservedPoint[] {
                                                                                                     new WeightedObservedPoint(1.0, -1.0, 0.1),
                                                                                                     new WeightedObservedPoint(1.0, -0.5, 0.2),
                                                                                                     new WeightedObservedPoint(1.0, 0.0, 0.3),
                                                                                                     new WeightedObservedPoint(1.0, 0.5, 0.2),
                                                                                                     new WeightedObservedPoint(1.0, 1.0, 0.1)
                                                                                                 };
                                                                                                 
                                                                                                 // Add points to fitter
                                                                                                 for (WeightedObservedPoint point : points) {
                                                                                                     fitter.addObservedPoint(point);
                                                                                                 }
                                                                                                 
                                                                                                 double[] params = {1.0, 0.0, 1.0}; // norm, mean, sigma
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit(params);
                                                                                                 
                                                                                                 // Verify the gradient computation didn't fail
                                                                                                 assertNotNull(result);
                                                                                                 assertEquals(3, result.length);
                                                                                                 // We can't predict exact values but they should be finite
                                                                                                 assertTrue(Double.isFinite(result[0]));
                                                                                                 assertTrue(Double.isFinite(result[1]));
                                                                                                 assertTrue(Double.isFinite(result[2]));
                                                                                             }

    @Test
                                                                                             public void testGradientMethod_WithInvalidParameters() {
                                                                                                 // Setup test for the anonymous function's gradient method with invalid params
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 double x = 0.0;
                                                                                                 double[] params = {1.0, 0.0, -1.0}; // negative sigma
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit(params);
                                                                                                 
                                                                                                 // Verify it returns infinity gradients for invalid parameters
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[0], 0.0);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[1], 0.0);
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, result[2], 0.0);
                                                                                             }

    @Test
                                                                                             public void testFit_WithValidObservations() {
                                                                                                 // Setup
                                                                                                 DifferentiableMultivariateVectorialOptimizer optimizer = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // Add some observations
                                                                                                 fitter.addObservedPoint(1.0, 1.0);
                                                                                                 fitter.addObservedPoint(2.0, 4.0);
                                                                                                 fitter.addObservedPoint(3.0, 9.0);
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit();
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertNotNull(result);
                                                                                                 assertEquals(3, result.length); // Assuming Gaussian fit returns 3 parameters
                                                                                                 // Additional assertions could verify reasonable parameter ranges
                                                                                             }

    @Test
                                                                                             public void testFit_WithMockedParameterGuesser() {
                                                                                                 // Setup
                                                                                                 org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser mockGuesser = mock(org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser.class);
                                                                                                 org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = mock(org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                 org.apache.commons.math.optimization.fitting.GaussianFitter fitter = spy(new org.apache.commons.math.optimization.fitting.GaussianFitter(optimizer));
                                                                                                 
                                                                                                 // Mock the ParameterGuesser behavior
                                                                                                 double[] mockGuess = new double[]{1.0, 2.0, 3.0};
                                                                                                 when(mockGuesser.guess()).thenReturn(mockGuess);
                                                                                                 
                                                                                                 // Mock the fit method with parameters
                                                                                                 double[] expectedResult = new double[]{1.5, 2.5, 3.5};
                                                                                                 doReturn(expectedResult).when(fitter).fit(mockGuess);
                                                                                                 
                                                                                                 // Use reflection to inject the mock guesser
                                                                                                 try {
                                                                                                     Field guesserField = org.apache.commons.math.optimization.fitting.GaussianFitter.class.getDeclaredField("guesser");
                                                                                                     guesserField.setAccessible(true);
                                                                                                     guesserField.set(fitter, mockGuesser);
                                                                                                 } catch (Exception e) {
                                                                                                     fail("Failed to inject mock guesser via reflection");
                                                                                                 }
                                                                                                 
                                                                                                 // Add some observations
                                                                                                 fitter.addObservedPoint(1.0, 1.0);
                                                                                                 fitter.addObservedPoint(2.0, 4.0);
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit();
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertArrayEquals(expectedResult, result, 0.0001);
                                                                                             }

    @Test
                                                                                             public void testFit_WithSingleObservation() {
                                                                                                 // Setup
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 fitter.addObservedPoint(1.0, 1.0);
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit();
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertNotNull(result);
                                                                                                 assertEquals(3, result.length);
                                                                                                 // Additional assertions could verify the parameters make sense for a single point
                                                                                             }

    @Test
                                                                                             public void testFit_WithExtremeValues() {
                                                                                                 // Setup
                                                                                                 org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                     new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                 GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                 
                                                                                                 // Add extreme value observations
                                                                                                 fitter.addObservedPoint(Double.MAX_VALUE, Double.MAX_VALUE);
                                                                                                 fitter.addObservedPoint(Double.MIN_VALUE, Double.MIN_VALUE);
                                                                                                 fitter.addObservedPoint(-Double.MAX_VALUE, -Double.MAX_VALUE);
                                                                                                 
                                                                                                 // Execute
                                                                                                 double[] result = fitter.fit();
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertNotNull(result);
                                                                                                 assertEquals(3, result.length);
                                                                                                 // The actual values would depend on the fitting algorithm's behavior with extreme values
                                                                                             }

    @Test
                                                                                         public void testFit_WithNoObservations() {
                                                                                             // Setup
                                                                                             org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                                                 new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                                             org.apache.commons.math.optimization.fitting.GaussianFitter fitter = 
                                                                                                 new org.apache.commons.math.optimization.fitting.GaussianFitter(optimizer);
                                                                                             
                                                                                             // Expect exception
                                                                                             org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                             exception.expect(IllegalStateException.class);
                                                                                             exception.expectMessage("no observations");
                                                                                             
                                                                                             // Execute
                                                                                             fitter.fit();
                                                                                         }

    @Test
                 public void testFit_WithOptimizationFailure() {
                     // Setup
                     org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = 
                         mock(org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer.class);
                     
                     GaussianFitter fitter = new GaussianFitter(optimizer);
                     fitter.addObservedPoint(1.0, 1.0);
                     fitter.addObservedPoint(2.0, 4.0);
                     
                     // Expect exception
                     try {
                         fitter.fit();
                         fail("Expected RuntimeException");
                     } catch (RuntimeException e) {
                         assertEquals("Optimization failed", e.getMessage());
                     }
                 }

    @Test
            public void testFitWithoutParametersShouldPassOriginalArrayNotClone() {
                // Setup
                GaussianFitter fitter = new GaussianFitter(mock(DifferentiableMultivariateVectorialOptimizer.class));
                
                // Mock the ParameterGuesser behavior
                double[] mockGuess = new double[]{1.0, 2.0, 3.0};
                org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser mockGuesser = 
                    mock(org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser.class);
                when(mockGuesser.guess()).thenReturn(mockGuess);
                
                // Use reflection to inject mock guesser since it's created internally
                try {
                    Field observationsField = GaussianFitter.class.getDeclaredField("observations");
                    observationsField.setAccessible(true);
                    observationsField.set(fitter, new WeightedObservedPoint[0]); // empty observations
                    
                    Field guesserField = GaussianFitter.class.getDeclaredField("guesser");
                    guesserField.setAccessible(true);
                    guesserField.set(fitter, mockGuesser);
                } catch (Exception e) {
                    fail("Failed to setup test via reflection: " + e.getMessage());
                }
                
                // Mock the fit(double[]) method to capture the passed array
                GaussianFitter spyFitter = spy(fitter);
                doReturn(new double[]{1.0, 1.0, 1.0}).when(spyFitter).fit(any(double[].class));
                
                // Execute
                spyFitter.fit();
                
                // Verify
                org.mockito.ArgumentCaptor<double[]> arrayCaptor = org.mockito.ArgumentCaptor.forClass(double[].class);
                verify(spyFitter).fit(arrayCaptor.capture());
                
                // Assert that the passed array is exactly the same object (not a clone)
                assertSame("The fit method should receive the original array, not a clone", 
                          mockGuess, arrayCaptor.getValue());
                
                // Additional check: modify the original array and see if it affects the result
                mockGuess[0] = 99.0;
                double[] result = spyFitter.fit();
                assertEquals("Modifying original guess should affect result if array wasn't cloned",
                           99.0, arrayCaptor.getValue()[0], 0.0001);
            }

    @Test
    public void testFitDoesNotModifyInputArray() {
        // Setup
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
            new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        GaussianFitter fitter = new GaussianFitter(optimizer);
        double[] initialGuess = {1.0, 2.0, 3.0};
        double[] originalGuess = initialGuess.clone();
        
        // Action
        double[] result = fitter.fit(initialGuess);
        
        // Verification - mutation would be caught here
        // If fit() uses the original array reference, modifying it would affect the result
        initialGuess[0] = 99.0;
        initialGuess[1] = 99.0;
        initialGuess[2] = 99.0;
        
        // The result should not change even if we modify the input array after fitting
        assertArrayEquals(originalGuess, result, 0.0001);
        
        // Additional verification that the result is not the same array reference
        assertNotSame("Result should not be the same array as input", 
                     initialGuess, result);
    }


}
