package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Pair;
 
public class DiscreteDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                 public void testSample_FirstItemSelected() {
                                                                                                                                     // Setup test data
                                                                                                                                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                     List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                     samples.add(new Pair<>("A", 0.2));
                                                                                                                                     samples.add(new Pair<>("B", 0.8));
                                                                                                                                     
                                                                                                                                     // Create distribution with mock random
                                                                                                                                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                                     
                                                                                                                                     // Random value falls in first probability range (0-0.2)
                                                                                                                                     when(mockRandom.nextDouble()).thenReturn(0.1);
                                                                                                                                     
                                                                                                                                     String result = distribution.sample();
                                                                                                                                     assertEquals("A", result);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_LastItemSelected() {
                                                                                                                                     // Create mock RandomGenerator
                                                                                                                                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                     // Random value falls in last probability range (0.5-1.0)
                                                                                                                                     when(mockRandom.nextDouble()).thenReturn(0.7);
                                                                                                                                     
                                                                                                                                     // Create sample data where "C" is the last item with probability 0.5
                                                                                                                                     List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                     samples.add(new Pair<>("A", 0.2));
                                                                                                                                     samples.add(new Pair<>("B", 0.3));
                                                                                                                                     samples.add(new Pair<>("C", 0.5));
                                                                                                                                     
                                                                                                                                     // Create distribution with mock random and samples
                                                                                                                                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                                     
                                                                                                                                     String result = distribution.sample();
                                                                                                                                     assertEquals("C", result);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_EdgeCaseFirstItem() {
                                                                                                                                     // Setup mock random
                                                                                                                                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                     when(mockRandom.nextDouble()).thenReturn(0.0);
                                                                                                                                     
                                                                                                                                     // Create test distribution with known probabilities
                                                                                                                                     List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                     samples.add(new Pair<>("A", 0.5));
                                                                                                                                     samples.add(new Pair<>("B", 0.5));
                                                                                                                                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                                     
                                                                                                                                     // Test
                                                                                                                                     String result = distribution.sample();
                                                                                                                                     assertEquals("A", result);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_EdgeCaseBetweenItems() {
                                                                                                                                     // Setup test data
                                                                                                                                     List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                     samples.add(new Pair<>("A", 0.2));
                                                                                                                                     samples.add(new Pair<>("B", 0.3));
                                                                                                                                     samples.add(new Pair<>("C", 0.5));
                                                                                                                                     
                                                                                                                                     // Create mock Random
                                                                                                                                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                     // Random value exactly at boundary between items (0.2)
                                                                                                                                     when(mockRandom.nextDouble()).thenReturn(0.2);
                                                                                                                                     
                                                                                                                                     // Create distribution with mock random
                                                                                                                                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                                     
                                                                                                                                     String result = distribution.sample();
                                                                                                                                     assertEquals("B", result);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_FloatingPointEdgeCase() {
                                                                                                                                     // Setup test data - probabilities that sum to 1.0
                                                                                                                                     List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                     samples.add(new Pair<>("A", 0.3));
                                                                                                                                     samples.add(new Pair<>("B", 0.3));
                                                                                                                                     samples.add(new Pair<>("C", 0.4));  // Last bucket should catch values close to 1.0
                                                                                                                                     
                                                                                                                                     // Create mock random generator
                                                                                                                                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                     // Random value very close to 1.0 but due to floating point might miss
                                                                                                                                     when(mockRandom.nextDouble()).thenReturn(0.9999999999999999);
                                                                                                                                     
                                                                                                                                     // Create distribution with mock random
                                                                                                                                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                                     
                                                                                                                                     String result = distribution.sample();
                                                                                                                                     assertEquals("C", result);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_PositiveSize_ReturnsCorrectLength() {
                                                                                                                                     // Create sample data
                                                                                                                                     List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                     samples.add(new Pair<>("A", 0.3));
                                                                                                                                     samples.add(new Pair<>("B", 0.3));
                                                                                                                                     samples.add(new Pair<>("C", 0.4));
                                                                                                                                     
                                                                                                                                     // Create distribution with sample data
                                                                                                                                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                                                                                                                                     
                                                                                                                                     // Mock the random generator to return predictable values
                                                                                                                                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                     when(mockRandom.nextDouble())
                                                                                                                                         .thenReturn(0.2)  // Will select "A"
                                                                                                                                         .thenReturn(0.5)  // Will select "B"
                                                                                                                                         .thenReturn(0.8); // Will select "C"
                                                                                                                                     
                                                                                                                                     // Use reflection to set the random generator
                                                                                                                                     try {
                                                                                                                                         Field randomField = DiscreteDistribution.class.getDeclaredField("random");
                                                                                                                                         randomField.setAccessible(true);
                                                                                                                                         randomField.set(distribution, mockRandom);
                                                                                                                                     } catch (Exception e) {
                                                                                                                                         fail("Failed to set random generator via reflection");
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     Object[] result = distribution.sample(3);
                                                                                                                                     assertEquals(3, result.length);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_CallsSampleMethodCorrectNumberOfTimes() {
                                                                                                                                     // Create mock distribution
                                                                                                                                     DiscreteDistribution<String> distribution = mock(DiscreteDistribution.class);
                                                                                                                                     
                                                                                                                                     // Mock the sample() method
                                                                                                                                     when(distribution.sample()).thenReturn("A");
                                                                                                                                     
                                                                                                                                     // Call the method under test
                                                                                                                                     distribution.sample(5);
                                                                                                                                     
                                                                                                                                     // Verify sample() was called 5 times
                                                                                                                                     verify(distribution, times(5)).sample();
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_ReturnsCorrectValues() {
                                                                                                                                     // Create mock distribution
                                                                                                                                     DiscreteDistribution<String> distribution = mock(DiscreteDistribution.class);
                                                                                                                                     
                                                                                                                                     // Setup mock behavior for sample()
                                                                                                                                     when(distribution.sample())
                                                                                                                                         .thenReturn("A")
                                                                                                                                         .thenReturn("B")
                                                                                                                                         .thenReturn("A");
                                                                                                                                     
                                                                                                                                     // Setup mock behavior for sample(int)
                                                                                                                                     when(distribution.sample(3)).thenCallRealMethod();
                                                                                                                                     
                                                                                                                                     Object[] result = distribution.sample(3);
                                                                                                                                     
                                                                                                                                     assertArrayEquals(new Object[]{"A", "B", "A"}, result);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testSample_WithDifferentSizes() {
                                                                                                                                     // Create sample data
                                                                                                                                     List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                     samples.add(new Pair<>("A", 0.5));
                                                                                                                                     samples.add(new Pair<>("B", 0.5));
                                                                                                                                     
                                                                                                                                     // Create mock distribution
                                                                                                                                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                                                                                                                                     
                                                                                                                                     // Test with various valid sample sizes
                                                                                                                                     assertEquals(1, distribution.sample(1).length);
                                                                                                                                     assertEquals(10, distribution.sample(10).length);
                                                                                                                                     assertEquals(100, distribution.sample(100).length);
                                                                                                                                 }

    @Test
                                                                                                                             public void testSample_ZeroSize_ThrowsException() {
                                                                                                                                 // Setup
                                                                                                                                 List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                                                                 samples.add(new Pair<>("test", 1.0));
                                                                                                                                 DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                                                                                                                                 
                                                                                                                                 try {
                                                                                                                                     // Test
                                                                                                                                     distribution.sample(0);
                                                                                                                                     fail("Expected NotStrictlyPositiveException");
                                                                                                                                 } catch (NotStrictlyPositiveException e) {
                                                                                                                                     // Verify
                                                                                                                                     assertEquals(LocalizedFormats.NUMBER_OF_SAMPLES.toString(), e.getMessage());
                                                                                                                                 }
                                                                                                                             }

    @Test
                                                                                                                             public void testSample_VerifyRandomGeneratorUsage() {
                                                                                                                                 // Create mock objects
                                                                                                                                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                 DiscreteDistribution<Integer> distribution = mock(DiscreteDistribution.class);
                                                                                                                                 
                                                                                                                                 // Set up test data
                                                                                                                                 List<Pair<Integer, Double>> samples = new ArrayList<>();
                                                                                                                                 samples.add(new Pair<>(1, 1.0)); // Use concrete Integer type instead of null
                                                                                                                                 
                                                                                                                                 // Create real instance with mock random generator
                                                                                                                                 DiscreteDistribution<Integer> realDistribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                                                                 
                                                                                                                                 // Mock behavior
                                                                                                                                 when(mockRandom.nextDouble()).thenReturn(0.5);
                                                                                                                                 when(distribution.sample()).thenAnswer(invocation -> realDistribution.sample());
                                                                                                                                 
                                                                                                                                 // Test the method
                                                                                                                                 distribution.sample(2);
                                                                                                                                 
                                                                                                                                 // Verify random generator was used
                                                                                                                                 verify(mockRandom, atLeastOnce()).nextDouble();
                                                                                                                             }

    @Test
                                                                                                                     public void testSample_NegativeSize_ThrowsException() {
                                                                                                                         // Setup
                                                                                                                         List<Pair<Object, Double>> samples = new ArrayList<>();
                                                                                                                         samples.add(new Pair<>("test", 1.0));
                                                                                                                         DiscreteDistribution<Object> distribution = new DiscreteDistribution<>(samples);
                                                                                                                         
                                                                                                                         try {
                                                                                                                             // Test
                                                                                                                             distribution.sample(-1);
                                                                                                                             fail("Expected NotStrictlyPositiveException");
                                                                                                                         } catch (NotStrictlyPositiveException e) {
                                                                                                                             // Verify
                                                                                                                             assertEquals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES.toString(), 
                                                                                                                                        e.getMessage());
                                                                                                                         }
                                                                                                                     }

    @Test
                                                                                                                     public void testSample_SingleItemDistribution() {
                                                                                                                         // Mock the RandomGenerator
                                                                                                                         RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                         
                                                                                                                         // Create single sample list
                                                                                                                         List<org.apache.commons.math3.util.Pair<String, Double>> singleSample = new ArrayList<>();
                                                                                                                         singleSample.add(new org.apache.commons.math3.util.Pair<>("Only", 1.0));
                                                                                                                         
                                                                                                                         // Create distribution with mock random generator
                                                                                                                         DiscreteDistribution<String> singleDist = new DiscreteDistribution<>(mockRandom, singleSample);
                                                                                                                         
                                                                                                                         // Should always return the only item regardless of random value
                                                                                                                         when(mockRandom.nextDouble()).thenReturn(0.0);
                                                                                                                         assertEquals("Only", singleDist.sample());
                                                                                                                         
                                                                                                                         when(mockRandom.nextDouble()).thenReturn(0.5);
                                                                                                                         assertEquals("Only", singleDist.sample());
                                                                                                                         
                                                                                                                         when(mockRandom.nextDouble()).thenReturn(0.999);
                                                                                                                         assertEquals("Only", singleDist.sample());
                                                                                                                     }

    @Test
                                                                                                 public void testSample_SecondItemSelected() {
                                                                                                     // Setup test data
                                                                                                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                     List<Pair<String, Double>> samples = new ArrayList<Pair<String, Double>>();
                                                                                                     samples.add(new Pair<String, Double>("A", 0.2));
                                                                                                     samples.add(new Pair<String, Double>("B", 0.3));
                                                                                                     samples.add(new Pair<String, Double>("C", 0.5));
                                                                                                     
                                                                                                     // Create distribution with mock random
                                                                                                     DiscreteDistribution<String> distribution = 
                                                                                                         new DiscreteDistribution<String>(mockRandom, samples);
                                                                                                     
                                                                                                     // Random value falls in second probability range (0.2-0.5)
                                                                                                     when(mockRandom.nextDouble()).thenReturn(0.3);
                                                                                                     
                                                                                                     String result = distribution.sample();
                                                                                                     assertEquals("B", result);
                                                                                                 }

    @Test
                                                                                         public void testSample_ZeroProbabilityItem() {
                                                                                             // Setup mock random
                                                                                             org.apache.commons.math3.random.RandomGenerator mockRandom = 
                                                                                                 new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                             
                                                                                             // Create test samples
                                                                                             java.util.List<org.apache.commons.math3.util.Pair<String, Double>> zeroProbSamples =
                                                                                                 java.util.Arrays.asList(
                                                                                                     new org.apache.commons.math3.util.Pair<>("Never", 0.0),
                                                                                                     new org.apache.commons.math3.util.Pair<>("Always", 1.0)
                                                                                                 );
                                                                                             
                                                                                             // Create distribution with mock random using public constructor
                                                                                             org.apache.commons.math3.distribution.DiscreteDistribution<String> zeroDist = 
                                                                                                 new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, zeroProbSamples);
                                                                                             
                                                                                             // Should never return the zero probability item
                                                                                             org.junit.Assert.assertEquals("Always", zeroDist.sample());
                                                                                         }

    @Test
                     public void testSample_UnevenProbabilities() {
                         RandomGenerator mockRandom = mock(RandomGenerator.class);
                         
                         // Setup mock to return values that will trigger both cases
                         // First call returns 0.0 (will select first item)
                         // Second call returns 0.99 (will select second item)
                         when(mockRandom.nextDouble())
                             .thenReturn(0.0)
                             .thenReturn(0.99);
                         
                         // Create test samples
                         List<Pair<String, Double>> samples = new ArrayList<>();
                         samples.add(new Pair<>("A", 0.1));
                         samples.add(new Pair<>("B", 0.9));
                         
                         // Create distribution with mock random
                         DiscreteDistribution<String> distribution = 
                             new DiscreteDistribution<>(mockRandom, samples);
                         
                         // Test common case
                         assertEquals("A", distribution.sample());
                         assertEquals("B", distribution.sample());
                     }

    @Test(expected = IllegalArgumentException.class)
                 public void testSampleWithZeroSizeShouldThrowException() {
                     // Setup test data
                     List<Pair<String, Double>> samples = new ArrayList<>();
                     samples.add(new Pair<>("A", 0.5));
                     samples.add(new Pair<>("B", 0.5));
                     
                     // Create distribution
                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                     
                     // This should throw IllegalArgumentException in original code
                     // but would pass in mutated code (sampleSize = 0)
                     distribution.sample(0);
                 }

    @Test(expected = IllegalArgumentException.class)
                 public void testSampleWithNegativeSizeShouldThrowException() {
                     // Setup test data
                     List<Pair<String, Double>> samples = new ArrayList<>();
                     samples.add(new Pair<>("A", 0.5));
                     samples.add(new Pair<>("B", 0.5));
                     
                     // Create distribution
                     DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                     
                     // This should throw IllegalArgumentException in both original and mutated code
                     distribution.sample(-1);
                 }

    @Test(expected = NotStrictlyPositiveException.class)
                 public void testSampleWithZeroSizeShouldThrowException1() {
                     // Setup test data
                     List<Pair<String, Double>> samples = new ArrayList<>();
                     samples.add(new Pair<>("item1", 1.0));
                     
                     // Create instance with mock random generator
                     DiscreteDistribution<String> distribution = 
                         new DiscreteDistribution<>(mock(RandomGenerator.class), samples);
                     
                     // This should throw NotStrictlyPositiveException in original code
                     // But would pass with the mutant (sampleSize < 0 instead of <= 0)
                     distribution.sample(0);
                 }

    @Test
                 public void testSampleWithPositiveSizeReturnsCorrectArray() {
                     // Setup test data
                     List<Pair<String, Double>> samples = new ArrayList<>();
                     samples.add(new Pair<>("item1", 1.0));
                     
                     // Create instance with mock random generator
                     RandomGenerator mockRandom = mock(RandomGenerator.class);
                     when(mockRandom.nextDouble()).thenReturn(0.5); // Ensure consistent sampling
                     DiscreteDistribution<String> distribution = 
                         new DiscreteDistribution<>(mockRandom, samples);
                     
                     // Test normal case
                     Object[] result = distribution.sample(2);
                     assertEquals(2, result.length);
                     assertEquals("item1", result[0]);
                     assertEquals("item1", result[1]);
                 }

    @Test(expected = NotStrictlyPositiveException.class)
                 public void testSampleWithNegativeSizeShouldThrowException1() {
                     // Setup test data
                     List<Pair<String, Double>> samples = new ArrayList<>();
                     samples.add(new Pair<>("item1", 1.0));
                     
                     // Create instance with mock random generator
                     DiscreteDistribution<String> distribution = 
                         new DiscreteDistribution<>(mock(RandomGenerator.class), samples);
                     
                     // This should throw in both original and mutated code
                     distribution.sample(-1);
                 }

    @Test
                public void testSampleDetectsReverseIterationMutant() {
                    // Setup test data where order matters
                    List<Pair<String, Double>> samples = new ArrayList<>();
                    samples.add(new Pair<>("A", 0.3));
                    samples.add(new Pair<>("B", 0.3));
                    samples.add(new Pair<>("C", 0.4));
                    
                    // Mock random to return a value that would be in both first and second probability ranges
                    RandomGenerator mockRandom = mock(RandomGenerator.class);
                    when(mockRandom.nextDouble()).thenReturn(0.3);
                    
                    // Create instance with mocked random
                    DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
                    
                    // Test - original would return "A" (first match), mutant would return "B" (last match in reverse)
                    String result = dist.sample();
                    
                    // Assert that we get the expected first match ("A")
                    assertEquals("A", result);
                    
                    // Additional verification that we didn't get the reverse-iteration result
                    assertNotEquals("B", result);
                }

    @Test
                public void testSampleOrderWithMultipleCalls() {
                    // Setup mock DiscreteDistribution
                    DiscreteDistribution<String> dist = mock(DiscreteDistribution.class);
                    
                    // Mock sample() to return different values for each call
                    when(dist.sample())
                        .thenReturn("first")
                        .thenReturn("second")
                        .thenReturn("third");
                    
                    // Call the method under test
                    Object[] result = dist.sample(3);
                    
                    // Verify the order is maintained (forward iteration)
                    assertEquals("first", result[0]);
                    assertEquals("second", result[1]);
                    assertEquals("third", result[2]);
                    
                    // Verify sample() was called exactly 3 times
                    verify(dist, times(3)).sample();
                }

    @Test
               public void testSampleOrderWithFixedRandomness() {
                   // Setup test data with known probabilities
                   List<Pair<String, Double>> samples = new ArrayList<>();
                   samples.add(new Pair<>("A", 0.3));
                   samples.add(new Pair<>("B", 0.3));
                   samples.add(new Pair<>("C", 0.4));
                   
                   // Mock RandomGenerator to return predictable values
                   RandomGenerator mockRandom = mock(RandomGenerator.class);
                   when(mockRandom.nextDouble())
                       .thenReturn(0.1)  // Will select A (0.1 < 0.3)
                       .thenReturn(0.4)  // Will select B (0.3 <= 0.4 < 0.6)
                       .thenReturn(0.8); // Will select C (0.6 <= 0.8 < 1.0)
                   
                   // Create DiscreteDistribution with our mock
                   DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
                   
                   // Test sample(int) method
                   int sampleSize = 3;
                   Object[] result = dist.sample(sampleSize);
                   
                   // Verify the order is preserved (should be A, B, C)
                   assertEquals("A", result[0]);
                   assertEquals("B", result[1]);
                   assertEquals("C", result[2]);
                   
                   // Also verify the array length
                   assertEquals(sampleSize, result.length);
               }

    @Test
              public void testSampleOrderWhenSampleSizeGreaterThanOne() {
                  // Setup mock behavior
                  DiscreteDistribution<Integer> dist = mock(DiscreteDistribution.class);
                  when(dist.sample()).thenReturn(1, 2, 3); // Return 1, then 2, then 3 on subsequent calls
                  
                  // Mock the sample(int) method behavior
                  when(dist.sample(anyInt())).thenAnswer(invocation -> {
                      int sampleSize = invocation.getArgument(0);
                      Object[] out = new Object[sampleSize];
                      for (int i = 0; i < sampleSize; i++) {
                          out[i] = dist.sample();
                      }
                      return out;
                  });
                  
                  // Call the method
                  Object[] result = dist.sample(3);
                  
                  // Verify the order - original would be [1,2,3], mutant would be [3,2,1]
                  assertEquals(1, result[0]);
                  assertEquals(2, result[1]);
                  assertEquals(3, result[2]);
                  
                  // Verify sample() was called exactly 3 times
                  verify(dist, times(3)).sample();
              }

    @Test
          public void testSampleFallbackReturnsLastElement() {
              // Setup test data
              List<Pair<String, Double>> samples = new ArrayList<>();
              samples.add(new Pair<>("first", 0.3));
              samples.add(new Pair<>("second", 0.3));
              samples.add(new Pair<>("third", 0.4)); // This should be the fallback
              
              // Mock RandomGenerator to return value > 1.0 to force fallback
              RandomGenerator mockRandom = mock(RandomGenerator.class);
              when(mockRandom.nextDouble()).thenReturn(1.1); // Value greater than sum of probabilities
              
              // Create DiscreteDistribution with our mock and test data
              DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
              
              // Call sample() - should return last element ("third") in original,
              // but would return first element ("first") in mutated version
              String result = distribution.sample();
              
              // Verify it returns the last element (original behavior)
              assertEquals("third", result);
              
              // This test will fail if the mutant is present (which returns first element)
              // thus detecting the mutant
          }

    @Test
         public void testSampleReturnsDifferentElements() {
             // Setup test data
             List<Pair<String, Double>> samples = new ArrayList<>();
             samples.add(new Pair<>("A", 0.25));
             samples.add(new Pair<>("B", 0.25));
             samples.add(new Pair<>("C", 0.25));
             samples.add(new Pair<>("D", 0.25));
             
             // Mock random generator to return different indices
             RandomGenerator mockRandom = mock(RandomGenerator.class);
             when(mockRandom.nextDouble()).thenReturn(0.1, 0.4, 0.6, 0.9);
             
             // Create distribution with our mock
             DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
             
             // Call method under test
             Object[] result = dist.sample(4);
             
             // Verify we got different elements (would fail with mutant)
             assertNotEquals("First and second samples should differ", result[0], result[1]);
             assertNotEquals("First and third samples should differ", result[0], result[2]);
             assertNotEquals("First and fourth samples should differ", result[0], result[3]);
             
             // Extract keys from result for verification
             List<String> resultKeys = new ArrayList<>();
             for (Object obj : result) {
                 resultKeys.add((String) obj);
             }
             
             // Verify we got all expected elements
             assertTrue("Result should contain A", resultKeys.contains("A"));
             assertTrue("Result should contain B", resultKeys.contains("B"));
             assertTrue("Result should contain C", resultKeys.contains("C"));
             assertTrue("Result should contain D", resultKeys.contains("D"));
         }

    @Test
     public void testSampleWithFloatingPointPrecisionIssue() {
         // Setup test data with probabilities that might have floating point precision issues
         List<Pair<String, Double>> samples = new ArrayList<>();
         samples.add(new Pair<>("A", 0.1));
         samples.add(new Pair<>("B", 0.2));
         samples.add(new Pair<>("C", 0.3));
         // Sum is 0.6, but after normalization might be slightly less than 1.0
         
         // Mock random generator to return value greater than sum of probabilities
         RandomGenerator mockRandom = mock(RandomGenerator.class);
         when(mockRandom.nextDouble()).thenReturn(0.999999999); // Value that should trigger fallback
         
         // Create DiscreteDistribution with our mock random
         DiscreteDistribution<String> distribution = 
             new DiscreteDistribution<>(mockRandom, samples);
         
         // The original code should return the last element "C"
         // The mutated code would throw IndexOutOfBoundsException
         assertEquals("C", distribution.sample());
     }

    @Test(expected = IndexOutOfBoundsException.class)
         public void testSampleWithEmptySingletons() {
             // Additional test case for empty singletons list
             List<Pair<String, Double>> emptySamples = new ArrayList<>();
             DiscreteDistribution<String> emptyDist = new DiscreteDistribution<>(emptySamples);
             emptyDist.sample(); // Both original and mutant should throw here
         }

    @Test
    public void testSampleReturnsValidElement() {
        // Create sample data
        List<Pair<String, Double>> samples = new ArrayList<>();
        samples.add(new Pair<>("A", 0.5));
        samples.add(new Pair<>("B", 0.5));
        
        // Create distribution with samples
        DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
        
        // This test will pass with original code but fail with mutant
        // as mutant would throw IndexOutOfBoundsException
        try {
            String result = distribution.sample();
            assertTrue(samples.get(0).getKey().equals(result) || 
                       samples.get(1).getKey().equals(result));
        } catch (IndexOutOfBoundsException e) {
            fail("sample() threw IndexOutOfBoundsException - mutant detected");
        }
    }


}
