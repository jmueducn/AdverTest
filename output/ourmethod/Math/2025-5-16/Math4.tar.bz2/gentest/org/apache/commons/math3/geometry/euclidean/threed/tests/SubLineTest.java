package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Region.Location;
 
public class SubLineTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                 public void testIntersection_NoIntersection() {
                                                     // Setup two lines that don't intersect
                                                     Line line1 = mock(Line.class);
                                                     when(line1.intersection(any(Line.class))).thenReturn(null);
                                                     
                                                     IntervalsSet region1 = mock(IntervalsSet.class);
                                                     SubLine subLine1 = new SubLine(line1, region1);
                                                     
                                                     Line line2 = mock(Line.class);
                                                     IntervalsSet region2 = mock(IntervalsSet.class);
                                                     SubLine subLine2 = new SubLine(line2, region2);
                                                     
                                                     assertNull(subLine1.intersection(subLine2, true));
                                                     assertNull(subLine1.intersection(subLine2, false));
                                                 }

 @Test
                                                 public void testIntersection_InsideBothSubLines() {
                                                     // Setup lines that intersect inside both sub-lines
                                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                     
                                                     Line line1 = mock(Line.class);
                                                     Line line2 = mock(Line.class);
                                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                     
                                                     IntervalsSet region1 = mock(IntervalsSet.class);
                                                     when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                     
                                                     IntervalsSet region2 = mock(IntervalsSet.class);
                                                     when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                     
                                                     SubLine subLine1 = new SubLine(line1, region1);
                                                     SubLine subLine2 = new SubLine(line2, region2);
                                                     
                                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                 }

 @Test
                                                 public void testIntersection_AtEndpointsIncludeEndpoints() {
                                                     // Setup lines that intersect at endpoints with includeEndPoints=true
                                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                     
                                                     Line line1 = mock(Line.class);
                                                     Line line2 = mock(Line.class);
                                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                     
                                                     IntervalsSet region1 = mock(IntervalsSet.class);
                                                     when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                     
                                                     IntervalsSet region2 = mock(IntervalsSet.class);
                                                     when(region2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                     
                                                     SubLine subLine1 = new SubLine(line1, region1);
                                                     SubLine subLine2 = new SubLine(line2, region2);
                                                     
                                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                     assertNull(subLine1.intersection(subLine2, false));
                                                 }

 @Test
                                                 public void testIntersection_OneInsideOneOutside() {
                                                     // Setup lines that intersect but one is inside and one is outside
                                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                     
                                                     Line line1 = mock(Line.class);
                                                     Line line2 = mock(Line.class);
                                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                     
                                                     IntervalsSet region1 = mock(IntervalsSet.class);
                                                     when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                     
                                                     IntervalsSet region2 = mock(IntervalsSet.class);
                                                     when(region2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                     
                                                     SubLine subLine1 = new SubLine(line1, region1);
                                                     SubLine subLine2 = new SubLine(line2, region2);
                                                     
                                                     assertNull(subLine1.intersection(subLine2, true));
                                                     assertNull(subLine1.intersection(subLine2, false));
                                                 }

 @Test
                                                 public void testIntersection_ParallelLines() {
                                                     // Setup parallel lines that never intersect
                                                     Line line1 = mock(Line.class);
                                                     when(line1.intersection(any(Line.class))).thenReturn(null);
                                                     
                                                     IntervalsSet region1 = mock(IntervalsSet.class);
                                                     SubLine subLine1 = new SubLine(line1, region1);
                                                     
                                                     Line line2 = mock(Line.class);
                                                     IntervalsSet region2 = mock(IntervalsSet.class);
                                                     SubLine subLine2 = new SubLine(line2, region2);
                                                     
                                                     assertNull(subLine1.intersection(subLine2, true));
                                                     assertNull(subLine1.intersection(subLine2, false));
                                                 }

 @Test
                                                 public void testIntersection_OneBoundaryOneInside() {
                                                     // Setup lines that intersect with one at boundary and one inside
                                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                     
                                                     Line line1 = mock(Line.class);
                                                     Line line2 = mock(Line.class);
                                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                     
                                                     IntervalsSet region1 = mock(IntervalsSet.class);
                                                     when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                     
                                                     IntervalsSet region2 = mock(IntervalsSet.class);
                                                     when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                     
                                                     SubLine subLine1 = new SubLine(line1, region1);
                                                     SubLine subLine2 = new SubLine(line2, region2);
                                                     
                                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                     assertNull(subLine1.intersection(subLine2, false));
                                                 }

 @Test
                                         public void testIntersectionWithDifferentLineOrientations() {
                                             // Create two lines with different orientations
                                             Vector3D p1 = new Vector3D(0, 0, 0);
                                             Vector3D p2 = new Vector3D(1, 0, 0);
                                             Vector3D p3 = new Vector3D(0, 1, 0);
                                             
                                             // First line along x-axis, second line along y-axis
                                             Line line1 = new Line(p1, p2);
                                             Line line2 = new Line(p1, p3);
                                             
                                             // Create regions that include the intersection point (origin)
                                             IntervalsSet region1 = new IntervalsSet(-1, 1);
                                             IntervalsSet region2 = new IntervalsSet(-1, 1);
                                             
                                             // Create sub-lines
                                             SubLine subLine1 = new SubLine(line1, region1);
                                             SubLine subLine2 = new SubLine(line2, region2);
                                             
                                             // The intersection point should be valid (origin)
                                             Vector3D intersection = subLine1.intersection(subLine2, true);
                                             
                                             // With the mutation, this would fail because it would check the point against the wrong coordinate system
                                             assertEquals(p1, intersection);
                                             
                                             // Also test with includeEndPoints=false since the point is exactly at the boundary
                                             intersection = subLine1.intersection(subLine2, false);
                                             // Should be null since the point is exactly at the boundary (not INSIDE)
                                             assertNull(intersection);
                                         }

 @Test
                                       public void testIntersectionWhenPointOutsideFirstSubLine() {
                                           // Setup test objects
                                           Line line1 = mock(Line.class);
                                           Line line2 = mock(Line.class);
                                           Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                           
                                           // Mock line intersection to return a point
                                           when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                           
                                           // Create sublines
                                           IntervalsSet validRegion = mock(IntervalsSet.class);
                                           IntervalsSet invalidRegion = mock(IntervalsSet.class);
                                           
                                           // Mock behavior - first subline's region check returns OUTSIDE
                                           when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                           when(validRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                           
                                           // Second subline's region would return INSIDE (but shouldn't matter)
                                           when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                           when(invalidRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                           
                                           // Create test objects
                                           SubLine subLine1 = new SubLine(line1, validRegion);
                                           SubLine subLine2 = new SubLine(line2, invalidRegion);
                                           
                                           // Test - should return null since point is outside first subline's region
                                           assertNull(subLine1.intersection(subLine2, true));
                                           
                                           // Verify the toSubSpace was called (wouldn't be called in mutant)
                                           verify(line1).toSubSpace(intersectionPoint);
                                       }

 @Test
                                  public void testIntersection_ShouldNotPassNullToToSubSpace() {
                                      // Create mock objects
                                      Line mockLine1 = mock(Line.class);
                                      Line mockLine2 = mock(Line.class);
                                      IntervalsSet mockRegion1 = mock(IntervalsSet.class);
                                      IntervalsSet mockRegion2 = mock(IntervalsSet.class);
                                      
                                      // Create test data
                                      Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                      Vector1D subspacePoint = new Vector1D(0.5);
                                      
                                      // Set up mocks
                                      when(mockLine1.intersection(mockLine2)).thenReturn(intersectionPoint);
                                      when(mockLine1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                      when(mockLine2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                      when(mockRegion1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                      when(mockRegion2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                      
                                      // Create test objects
                                      SubLine subLine1 = new SubLine(mockLine1, mockRegion1);
                                      SubLine subLine2 = new SubLine(mockLine2, mockRegion2);
                                      
                                      // Test the intersection
                                      Vector3D result = subLine1.intersection(subLine2, false);
                                      
                                      // Verify the result is correct
                                      assertEquals(intersectionPoint, result);
                                      
                                      // Verify toSubSpace was called with the intersection point, not null
                                      verify(mockLine1).toSubSpace(intersectionPoint);
                                      verify(mockLine2).toSubSpace(intersectionPoint);
                                      
                                      // Verify checkPoint was called with the subspace point
                                      verify(mockRegion1).checkPoint(subspacePoint);
                                      verify(mockRegion2).checkPoint(subspacePoint);
                                  }

 @Test
                             public void testIntersectionWithDifferentLineOrientations1() {
                                 // Create two lines with different orientations
                                 Line line1 = mock(Line.class);
                                 Line line2 = mock(Line.class);
                                 
                                 // Create mock regions that will accept any point
                                 IntervalsSet region1 = mock(IntervalsSet.class);
                                 IntervalsSet region2 = mock(IntervalsSet.class);
                                 when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                 when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                 
                                 // Create sublines
                                 SubLine subLine1 = new SubLine(line1, region1);
                                 SubLine subLine2 = new SubLine(line2, region2);
                                 
                                 // Mock intersection point
                                 Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                 when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                 
                                 // Mock different toSubSpace behaviors using Vector1D
                                 Vector1D pointInLine1 = new Vector1D(0.5); // Valid in line1's space
                                 Vector1D pointInLine2 = new Vector1D(1.5); // Valid in line2's space
                                 when(line1.toSubSpace(intersectionPoint)).thenReturn(pointInLine1);
                                 when(line2.toSubSpace(intersectionPoint)).thenReturn(pointInLine2);
                                 
                                 // Test intersection - should return the point since it's valid in both spaces
                                 Vector3D result = subLine1.intersection(subLine2, false);
                                 assertEquals(intersectionPoint, result);
                                 
                                 // Verify the correct toSubSpace was called for each sub-line
                                 verify(line1).toSubSpace(intersectionPoint);
                                 verify(line2).toSubSpace(intersectionPoint);
                                 
                                 // The mutant would use line1.toSubSpace for both checks, which this test would catch
                             }

 @Test
                public void testIntersectionWithNonNullPointShouldNotThrowNPE() {
                    // Setup test data
                    org.apache.commons.math3.geometry.euclidean.threed.Vector3D intersectionPoint = 
                        new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(1, 1, 1);
                    
                    // Create mock line that returns our intersection point
                    Line mockLine1 = mock(Line.class);
                    when(mockLine1.intersection(any(Line.class))).thenReturn(intersectionPoint);
                    
                    // Create mock sub-line that will be passed as parameter
                    Line mockLine2 = mock(Line.class);
                    IntervalsSet mockIntervals = mock(IntervalsSet.class);
                    SubLine subLine2 = new SubLine(mockLine2, mockIntervals);
                    
                    // Mock the toSubSpace calls
                    org.apache.commons.math3.geometry.euclidean.oned.Vector1D transformedPoint = 
                        new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.5);
                    when(mockLine1.toSubSpace(eq(intersectionPoint))).thenReturn(transformedPoint);
                    when(mockLine2.toSubSpace(eq(intersectionPoint))).thenReturn(transformedPoint);
                    
                    // Mock region checks
                    when(mockIntervals.checkPoint(any(org.apache.commons.math3.geometry.euclidean.oned.Vector1D.class)))
                        .thenReturn(Location.INSIDE);
                    
                    // Create our test sub-line
                    SubLine subLine1 = new SubLine(mockLine1, mockIntervals);
                    
                    // Test both includeEndPoints cases
                    org.apache.commons.math3.geometry.euclidean.threed.Vector3D result1 = subLine1.intersection(subLine2, true);
                    assertNotNull("Should return intersection point when includeEndPoints is true", result1);
                    assertEquals(intersectionPoint, result1);
                    
                    org.apache.commons.math3.geometry.euclidean.threed.Vector3D result2 = subLine1.intersection(subLine2, false);
                    assertNotNull("Should return intersection point when includeEndPoints is false", result2);
                    assertEquals(intersectionPoint, result2);
                    
                    // Verify the toSubSpace was called with the correct point
                    verify(mockLine2).toSubSpace(intersectionPoint);
                }

}
