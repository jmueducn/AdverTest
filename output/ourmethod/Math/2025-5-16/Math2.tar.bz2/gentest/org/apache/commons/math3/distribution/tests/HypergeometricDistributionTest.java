package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class HypergeometricDistributionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                           public void testGetNumericalMean_ValidInputs() {
                               // Typical case
                               HypergeometricDistribution dist = new HypergeometricDistribution(100, 30, 10);
                               assertEquals(3.0, dist.getNumericalMean(), 0.0001);
                               
                               // All population are successes
                               dist = new HypergeometricDistribution(50, 50, 20);
                               assertEquals(20.0, dist.getNumericalMean(), 0.0001);
                               
                               // No successes in population
                               dist = new HypergeometricDistribution(100, 0, 10);
                               assertEquals(0.0, dist.getNumericalMean(), 0.0001);
                               
                               // Sample size equals population size
                               dist = new HypergeometricDistribution(100, 25, 100);
                               assertEquals(25.0, dist.getNumericalMean(), 0.0001);
                               
                               // Sample size equals number of successes
                               dist = new HypergeometricDistribution(100, 40, 40);
                               assertEquals(16.0, dist.getNumericalMean(), 0.0001);
                           }

 @Test
                           public void testGetNumericalMean_EdgeCases() {
                               // Minimum valid values
                               HypergeometricDistribution dist = new HypergeometricDistribution(1, 0, 1);
                               assertEquals(0.0, dist.getNumericalMean(), 0.0001);
                               
                               dist = new HypergeometricDistribution(1, 1, 1);
                               assertEquals(1.0, dist.getNumericalMean(), 0.0001);
                               
                               // Large numbers
                               dist = new HypergeometricDistribution(1000000, 500000, 100000);
                               assertEquals(50000.0, dist.getNumericalMean(), 0.0001);
                           }

 @Test
                           public void testGetNumericalMean_FractionalResult() {
                               // Cases that result in fractional means
                               HypergeometricDistribution dist = new HypergeometricDistribution(3, 1, 2);
                               assertEquals(0.6666666666666666, dist.getNumericalMean(), 0.0001);
                               
                               dist = new HypergeometricDistribution(7, 3, 5);
                               assertEquals(2.142857142857143, dist.getNumericalMean(), 0.0001);
                           }

 @Test
                           public void testConstructor_InvalidPopulationSize() {
                               thrown.expect(NotStrictlyPositiveException.class);
                               thrown.expectMessage("population size");
                               new HypergeometricDistribution(0, 10, 5);
                           }

 @Test
                           public void testConstructor_InvalidNumberOfSuccesses() {
                               thrown.expect(NotPositiveException.class);
                               thrown.expectMessage("number of successes");
                               new HypergeometricDistribution(100, -1, 50);
                           }

 @Test
                           public void testConstructor_InvalidSampleSize() {
                               thrown.expect(NotPositiveException.class);
                               thrown.expectMessage("number of samples");
                               new HypergeometricDistribution(100, 50, -1);
                           }

 @Test
                           public void testConstructor_NumberOfSuccessesExceedsPopulation() {
                               thrown.expect(NumberIsTooLargeException.class);
                               thrown.expectMessage("number of successes");
                               new HypergeometricDistribution(100, 101, 50);
                           }

 @Test
                           public void testConstructor_SampleSizeExceedsPopulation() {
                               thrown.expect(NumberIsTooLargeException.class);
                               thrown.expectMessage("sample size");
                               new HypergeometricDistribution(100, 50, 101);
                           }

 @Test
                  public void testInnerCumulativeProbabilityDetectsInitialProbabilityMutation() throws Exception {
                      // Setup test parameters
                      int populationSize = 10;
                      int numberOfSuccesses = 5;
                      int sampleSize = 3;
                      int x0 = 1;
                      int x1 = 3;
                      int dx = 1;
                      
                      // Create instance and mock probability values
                      HypergeometricDistribution dist = new HypergeometricDistribution(populationSize, numberOfSuccesses, sampleSize);
                      
                      // Calculate expected values
                      double probX0 = dist.probability(x0);
                      double probX1 = dist.probability(x0 + dx);
                      double probX2 = dist.probability(x0 + 2*dx);
                      double expected = probX0 + probX1 + probX2;
                      
                      // Use reflection to access private method
                      Method innerCumulativeProbability = HypergeometricDistribution.class.getDeclaredMethod(
                          "innerCumulativeProbability", int.class, int.class, int.class);
                      innerCumulativeProbability.setAccessible(true);
                      double actual = (double) innerCumulativeProbability.invoke(dist, x0, x1, dx);
                      
                      // Assertions
                      assertEquals("Cumulative probability should include initial term", 
                                  expected, actual, 1e-10);
                      
                      // Additional assertion to specifically catch the mutant
                      double mutantValue = 0.0 + probX1 + probX2; // What mutant would return
                      assertNotEquals("Test should detect mutant that skips initial probability",
                                      mutantValue, actual, 1e-10);
                  }

 @Test
              public void testInnerCumulativeProbabilityDetectsMutant() {
                  // Create a mock HypergeometricDistribution
                  HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                  
                  // Setup mock behavior - different probabilities for different inputs
                  when(distribution.probability(1)).thenReturn(0.1);
                  when(distribution.probability(2)).thenReturn(0.2);
                  when(distribution.probability(3)).thenReturn(0.3);
                  
                  // Use reflection to access the private method
                  try {
                      Method method = HypergeometricDistribution.class.getDeclaredMethod(
                          "innerCumulativeProbability", int.class, int.class, int.class);
                      method.setAccessible(true);
                      
                      // Test case where x0=1, x1=3, dx=1
                      // Original should return: P(1) + P(2) + P(3) = 0.1 + 0.2 + 0.3 = 0.6
                      // Mutant would return: P(3) + P(2) + P(3) = 0.3 + 0.2 + 0.3 = 0.8 (wrong)
                      double result = (double) method.invoke(distribution, 1, 3, 1);
                      
                      // Verify the correct sum
                      assertEquals(0.6, result, 0.0001);
                      
                  } catch (Exception e) {
                      fail("Failed to test innerCumulativeProbability: " + e.getMessage());
                  }
              }

 @Test
             public void testInnerCumulativeProbabilityDetectsMutant1() {
                 // Create a mock HypergeometricDistribution object
                 HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                 
                 // Setup mock behavior for probability() method
                 when(distribution.probability(anyInt())).thenReturn(0.1);
                 
                 // Test case where x0 != x1 (should show difference between original and mutant)
                 int x0 = 0;
                 int x1 = 2;
                 int dx = 1;
                 
                 // Expected behavior (original code):
                 // Loop executes twice (for x0=0 and x0=1)
                 // Returns 0.1 + 0.1 + 0.1 = 0.3 (initial 0.1 + two loop iterations)
                 double expected = 0.3;
                 
                 // Mutated behavior:
                 // Loop condition is x0 == x1 (false), so loop never executes
                 // Returns just the initial 0.1
                 
                 // Call the method through reflection since it's private
                 try {
                     Method method = HypergeometricDistribution.class.getDeclaredMethod(
                         "innerCumulativeProbability", int.class, int.class, int.class);
                     method.setAccessible(true);
                     double result = (double) method.invoke(distribution, x0, x1, dx);
                     
                     // Assert the expected value that would only be correct for original code
                     assertEquals("Test should detect mutant by checking loop execution", 
                                expected, result, 0.0001);
                 } catch (Exception e) {
                     fail("Failed to test innerCumulativeProbability: " + e.getMessage());
                 }
             }

 @Test
            public void testInnerCumulativeProbabilityDetectsSubtractionMutant() {
                // Create a mock HypergeometricDistribution to control probability() behavior
                HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                
                // Setup mock behavior - return known probabilities for specific x values
                when(distribution.probability(1)).thenReturn(0.1);
                when(distribution.probability(2)).thenReturn(0.2);
                when(distribution.probability(3)).thenReturn(0.3);
                
                // Use reflection to access the private method
                try {
                    Method method = HypergeometricDistribution.class.getDeclaredMethod(
                        "innerCumulativeProbability", int.class, int.class, int.class);
                    method.setAccessible(true);
                    
                    // Test case where x0=1, x1=3, dx=1
                    // Original should calculate: P(1) + P(2) + P(3) = 0.1 + 0.2 + 0.3 = 0.6
                    double result = (double) method.invoke(distribution, 1, 3, 1);
                    
                    // Verify the result matches expected cumulative probability
                    assertEquals(0.6, result, 0.0001);
                    
                    // The mutant would either:
                    // 1. Not terminate (infinite loop) if x1 > x0 and dx > 0
                    // 2. Calculate wrong probabilities if it did terminate
                    // This assertion would fail for the mutant
                } catch (Exception e) {
                    fail("Test failed due to reflection exception: " + e.getMessage());
                }
            }

 @Test
          public void testInnerCumulativeProbabilityDetectsX0EqualsX1Mutant() throws Exception {
              // Create a test instance
              HypergeometricDistribution dist = new HypergeometricDistribution(100, 50, 10);
              
              // Mock the probability method to return predictable values
              HypergeometricDistribution spyDist = spy(dist);
              when(spyDist.probability(anyInt())).thenReturn(0.1, 0.2, 0.3, 0.4);
              
              // Test parameters where we need multiple steps
              int x0 = 0;
              int x1 = 3;
              int dx = 1;
              
              // Calculate expected result (sum of probabilities at 0, 1, 2, 3)
              double expected = 0.1 + 0.2 + 0.3 + 0.4;
              
              // Use reflection to access the private method
              Method method = HypergeometricDistribution.class.getDeclaredMethod(
                  "innerCumulativeProbability", int.class, int.class, int.class);
              method.setAccessible(true);
              
              // Call the method via reflection
              double result = (double) method.invoke(spyDist, x0, x1, dx);
              
              // Verify the result matches expected sum
              assertEquals(expected, result, 0.0001);
              
              // Verify probability was called for each step
              verify(spyDist, times(4)).probability(anyInt());
              verify(spyDist).probability(0);
              verify(spyDist).probability(1);
              verify(spyDist).probability(2);
              verify(spyDist).probability(3);
          }

 @Test
     public void testInnerCumulativeProbabilityDetectsAccumulationMutant() throws Exception {
         // Setup test object
         HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
         
         // Mock probability method to return predictable values
         HypergeometricDistribution spyDist = spy(distribution);
         when(spyDist.probability(anyInt())).thenReturn(0.1, 0.2, 0.3, 0.4);
         
         // Test parameters that will cause multiple iterations
         int x0 = 1;
         int x1 = 4;
         int dx = 1;
         
         // Calculate expected result (sum of probabilities at 1, 2, 3, 4)
         double expected = 0.1 + 0.2 + 0.3 + 0.4;
         
         // Use reflection to access private method
         Method method = HypergeometricDistribution.class.getDeclaredMethod(
             "innerCumulativeProbability", int.class, int.class, int.class);
         method.setAccessible(true);
         
         // Call method and verify
         double actual = (double) method.invoke(spyDist, x0, x1, dx);
         
         // This will fail on the mutant (which would return just 0.4)
         assertEquals(expected, actual, 0.0001);
         
         // Verify probability was called for each expected value
         verify(spyDist, times(4)).probability(anyInt());
     }

 @Test
 public void testInnerCumulativeProbabilityDetectsSubtractionMutant1() {
     // Create a mock HypergeometricDistribution where probability() returns known values
     HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
     
     // Use reflection to test the private method
     try {
         Method method = HypergeometricDistribution.class.getDeclaredMethod(
             "innerCumulativeProbability", int.class, int.class, int.class);
         method.setAccessible(true);
         
         // Test case 1: Single step (x0 to x1)
         // probability(1) = 0.5 (example value), should return 0.5
         double result1 = (double) method.invoke(distribution, 1, 1, 1);
         assertEquals(0.5, result1, 1e-6);
         
         // Test case 2: Multiple steps with known probabilities
         // probability(1) = 0.5, probability(2) = 0.3, probability(3) = 0.2
         // Expected sum: 0.5 + 0.3 + 0.2 = 1.0
         // This will catch the mutant because:
         // Original: 0.5 + 0.3 + 0.2 = 1.0
         // Mutant: 0.5 - 0.3 - 0.2 = 0.0
         double result2 = (double) method.invoke(distribution, 1, 3, 1);
         assertEquals(1.0, result2, 1e-6);
         
         // Test case 3: Reverse direction (x1 < x0)
         double result3 = (double) method.invoke(distribution, 3, 1, -1);
         assertEquals(1.0, result3, 1e-6);
         
     } catch (Exception e) {
         fail("Failed to test innerCumulativeProbability due to reflection error: " + e.getMessage());
     }
 }

}
