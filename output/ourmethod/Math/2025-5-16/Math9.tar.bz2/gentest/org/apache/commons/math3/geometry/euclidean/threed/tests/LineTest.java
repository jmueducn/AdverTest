package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.geometry.Vector;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Embedding;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Precision;
 
public class LineTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                                public void testRevert_ShouldReturnNewLineWithNegatedDirection() {
                                    // Setup original line
                                    Vector3D originalDirection = new Vector3D(1, 2, 3);
                                    Vector3D originPoint = new Vector3D(0, 0, 0);
                                    Line originalLine = new Line(originPoint, originalDirection);
                                    
                                    // Call revert
                                    Line revertedLine = originalLine.revert();
                                    
                                    // Verify it's a new instance
                                    assertNotSame(originalLine, revertedLine);
                                    
                                    // Verify direction is negated
                                    assertEquals(originalDirection.negate(), revertedLine.getDirection());
                                    
                                    // Verify origin point remains the same
                                    assertEquals(originPoint, revertedLine.getOrigin());
                                }

 @Test
                                public void testRevert_ShouldHandleZeroDirection() {
                                    // Setup line with zero direction
                                    Vector3D zeroDirection = new Vector3D(0, 0, 0);
                                    Vector3D originPoint = new Vector3D(1, 1, 1);
                                    Line originalLine = new Line(originPoint, zeroDirection);
                                    
                                    // Call revert
                                    Line revertedLine = originalLine.revert();
                                    
                                    // Verify direction remains zero (negation of zero is zero)
                                    assertEquals(zeroDirection, revertedLine.getDirection());
                                }

 @Test
                                public void testRevert_ShouldHandleNegativeDirection() {
                                    // Setup line with negative direction
                                    Vector3D negativeDirection = new Vector3D(-1, -2, -3);
                                    Vector3D originPoint = new Vector3D(5, 5, 5);
                                    Line originalLine = new Line(originPoint, negativeDirection);
                                    
                                    // Call revert
                                    Line revertedLine = originalLine.revert();
                                    
                                    // Verify direction is properly negated (should become positive)
                                    assertEquals(new Vector3D(1, 2, 3), revertedLine.getDirection());
                                }

 @Test
                                public void testRevert_ShouldMaintainOtherProperties() {
                                    // Setup original line
                                    Vector3D p1 = new Vector3D(1, 0, 0);
                                    Vector3D p2 = new Vector3D(1, 1, 0);
                                    Line originalLine = new Line(p1, p2);
                                    
                                    // Store some original properties
                                    double originalAbscissa = originalLine.getAbscissa(p2);
                                    Vector3D originalPointAt = originalLine.pointAt(1.5);
                                    
                                    // Call revert
                                    Line revertedLine = originalLine.revert();
                                    
                                    // Verify other properties are maintained (just with negated direction)
                                    assertEquals(-originalAbscissa, revertedLine.getAbscissa(p2), 0.0001);
                                    assertEquals(originalPointAt, revertedLine.pointAt(-1.5));
                                }

 @Test
                                public void testRevert_ShouldCreateIndependentCopy() {
                                    // Setup original line
                                    Vector3D direction = new Vector3D(1, 0, 0);
                                    Vector3D origin = new Vector3D(0, 0, 0);
                                    Line originalLine = new Line(origin, direction);
                                    
                                    // Call revert
                                    Line revertedLine = originalLine.revert();
                                    
                                    // Modify original line
                                    originalLine.reset(new Vector3D(0, 1, 0), new Vector3D(0, 2, 0));
                                    
                                    // Verify reverted line remains unchanged
                                    assertEquals(direction.negate(), revertedLine.getDirection());
                                    assertEquals(origin, revertedLine.getOrigin());
                                }

 @Test
                            public void testRvertWithActualVectors() {
                                // Setup original line with actual vectors
                                Vector3D p1 = new Vector3D(0, 0, 0);
                                Vector3D p2 = new Vector3D(1, 1, 1);
                                Line originalLine = new Line(p1, p2);
                                Vector3D originalDirection = originalLine.getDirection();
                                
                                // Test revert
                                Line revertedLine = originalLine.revert();
                                
                                // Verify behavior
                                // 1. Original direction remains unchanged
                                assertEquals(originalDirection, originalLine.getDirection());
                                
                                // 2. New line has negated direction
                                assertEquals(originalDirection.negate(), revertedLine.getDirection());
                                
                                // 3. Different objects
                                assertNotSame(originalLine, revertedLine);
                                
                                // 4. Verify other properties are copied correctly
                                assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
                            }

 @Test
                       public void testRvertShouldCreateNewLineWithNegatedDirectionWithoutChangingOriginal() throws Exception {
                           // Setup original line with mock direction
                           Vector3D originalDirection = mock(Vector3D.class);
                           Vector3D negatedDirection = mock(Vector3D.class);
                           when(originalDirection.negate()).thenReturn(negatedDirection);
                           
                           // Create a line with mock direction using reflection
                           Line originalLine = new Line(mock(Vector3D.class), mock(Vector3D.class));
                           Field directionField = Line.class.getDeclaredField("direction");
                           directionField.setAccessible(true);
                           directionField.set(originalLine, originalDirection);
                           
                           // Test revert
                           Line revertedLine = originalLine.revert();
                           
                           // Verify behavior
                           // 1. Verify original direction wasn't changed
                           assertSame(originalDirection, directionField.get(originalLine));
                           
                           // 2. Verify new line has negated direction
                           assertSame(negatedDirection, directionField.get(revertedLine));
                           
                           // 3. Verify it's a different object
                           assertNotSame(originalLine, revertedLine);
                           
                           // 4. Verify negate() was called exactly once (on the correct object)
                           verify(originalDirection, times(1)).negate();
                       }

 @Test
                       public void testRvertReturnsNewImmutableInstance() {
                           // Setup original line
                           Vector3D p1 = new Vector3D(1, 2, 3);
                           Vector3D p2 = new Vector3D(4, 5, 6);
                           Line original = new Line(p1, p2);
                           
                           // Get original direction for comparison
                           Vector3D originalDirection = original.getDirection();
                           
                           // Call revert
                           Line reverted = original.revert();
                           
                           // Verify it's a new instance
                           assertNotSame("Reverted line should be a new instance", original, reverted);
                           
                           // Verify direction is negated
                           assertEquals("Direction should be negated", 
                                        originalDirection.negate(), 
                                        reverted.getDirection());
                           
                           // Verify original remains unchanged
                           assertEquals("Original direction should remain unchanged",
                                        originalDirection,
                                        original.getDirection());
                           
                           // Try to reassign (would compile without final)
                           try {
                               // This would only compile if the variable wasn't final
                               // We're testing that the original code prevents this
                               // reverted = new Line(p2, p1); // This line would be uncommented in actual mutant detection
                               // If we could do this reassignment, it would indicate the mutant survived
                               fail("Should not be able to reassign reverted variable if final was used");
                           } catch (Exception e) {
                               // Expected - can't actually test compilation in JUnit, 
                               // but this shows the intent of what we're testing
                           }
                       }

 @Test
                      public void testRvertPreservesOriginalDirectionAndCreatesProperReversedLine() {
                          // Create original line with known direction
                          Vector3D originalDirection = new Vector3D(1, 2, 3);
                          Vector3D point1 = new Vector3D(0, 0, 0);
                          Vector3D point2 = originalDirection;
                          Line originalLine = new Line(point1, point2);
                          
                          // Verify original direction is as expected
                          assertEquals(originalDirection, originalLine.getDirection());
                          
                          // Create reverted line
                          Line revertedLine = originalLine.revert();
                          
                          // Verify original line's direction remains unchanged (critical for catching mutant)
                          assertEquals(originalDirection, originalLine.getDirection());
                          
                          // Verify reverted line has properly negated direction
                          assertEquals(originalDirection.negate(), revertedLine.getDirection());
                          
                          // Additional check that zero point was properly copied
                          assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
                      }

 @Test
                 public void testRevertDetectsScalarMultiplyMutant() {
                     // Create original line with a specific direction
                     Vector3D originalDirection = new Vector3D(1.0, 2.0, 3.0);
                     Vector3D origin = new Vector3D(0.0, 0.0, 0.0);
                     Line originalLine = new Line(origin, originalDirection);
                     
                     // Get the reverted line
                     Line revertedLine = originalLine.revert();
                     
                     // Verify the direction is exactly negated, not just multiplied by -1
                     Vector3D expectedNegated = originalDirection.negate();
                     Vector3D actualReverted = revertedLine.getDirection();
                     
                     // Check both the exact vector values and the operation used
                     assertEquals("X component should be exactly negated", 
                                 expectedNegated.getX(), actualReverted.getX(), 0.0);
                     assertEquals("Y component should be exactly negated",
                                 expectedNegated.getY(), actualReverted.getY(), 0.0);
                     assertEquals("Z component should be exactly negated",
                                 expectedNegated.getZ(), actualReverted.getZ(), 0.0);
                     
                     // Additional check that the vectors are exactly equal (not just close)
                     assertTrue("Direction should be exactly equal to negated vector",
                                expectedNegated.equals(actualReverted));
                     
                     // Check that scalarMultiply(-1) would produce a different result
                     // (this would fail if the mutant is present)
                     Vector3D scalarMultiplied = originalDirection.scalarMultiply(-1);
                     assertFalse("Negated vector should not equal scalar multiplied vector when mutant is present",
                                 scalarMultiplied.equals(actualReverted));
                 }

 @Test
                    public void testRevertWithZeroDirectionThrowsCorrectException() {
                        // Create a line with zero direction vector
                        Vector3D zeroVector = Vector3D.ZERO;
                        Vector3D somePoint = new Vector3D(1, 0, 0);
                        Line line = new Line(somePoint, zeroVector); // This should create a line with zero direction
                        
                        // Expect the specific exception with ZERO_NORM format
                        thrown.expect(MathIllegalArgumentException.class);
                        thrown.expectMessage(LocalizedFormats.ZERO_NORM.toString());
                        
                        // This should throw when trying to negate the zero vector
                        line.revert();
                    }

 @Test
                   public void testRevertNegatesDirection() {
                       // Create original line with known direction
                       Vector3D originalDirection = new Vector3D(1, 2, 3);
                       Vector3D origin = new Vector3D(0, 0, 0);
                       Line originalLine = new Line(origin, originalDirection);
                       
                       // Call revert
                       Line revertedLine = originalLine.revert();
                       
                       // Verify reverted line has negated direction
                       Vector3D expectedDirection = new Vector3D(-1, -2, -3);
                       assertEquals("Reverted line direction should be negated",
                                   expectedDirection, revertedLine.getDirection());
                       
                       // Verify original line direction remains unchanged
                       assertEquals("Original line direction should not change",
                                   originalDirection, originalLine.getDirection());
                       
                       // Verify zero point remains the same
                       assertEquals("Zero point should be the same",
                                   origin, revertedLine.getOrigin());
                   }

 @Test
              public void testRevertCreatesIndependentCopy() {
                  // Setup original line
                  Vector3D originalDirection = new Vector3D(1, 0, 0);
                  Vector3D originalZero = new Vector3D(0, 0, 0);
                  Line originalLine = new Line(originalZero, originalDirection);
                  
                  // Get reverted line
                  Line revertedLine = originalLine.revert();
                  
                  // Modify original line's direction
                  Vector3D newDirection = new Vector3D(0, 1, 0);
                  originalLine.reset(originalZero, newDirection);
                  
                  // Verify reverted line's direction wasn't affected by original's modification
                  assertEquals(-1, revertedLine.getDirection().getX(), 0.0001);
                  assertEquals(0, revertedLine.getDirection().getY(), 0.0001);
                  assertEquals(0, revertedLine.getDirection().getZ(), 0.0001);
                  
                  // Also verify zero point wasn't affected
                  assertEquals(0, revertedLine.getOrigin().getX(), 0.0001);
                  assertEquals(0, revertedLine.getOrigin().getY(), 0.0001);
                  assertEquals(0, revertedLine.getOrigin().getZ(), 0.0001);
              }

 @Test
                 public void testRevertWithZeroDirection() {
                     // Create a line with zero direction vector
                     Vector3D zeroVector = Vector3D.ZERO;
                     Vector3D anyPoint = new Vector3D(1, 1, 1);
                     Line line = new Line(anyPoint, zeroVector);
                     
                     // Expect exception when trying to revert
                     thrown.expect(MathIllegalArgumentException.class);
                     thrown.expectMessage(LocalizedFormats.ZERO_NORM.toString());
                     
                     // This should throw exception due to zero direction
                     line.revert();
                 }

 @Test
           public void testRvertShouldCreateNewLineWithNegatedDirectionWithoutChangingOriginal1() {
               // Create original line with mock direction
               Vector3D originalDirection = mock(Vector3D.class);
               Vector3D negatedDirection = mock(Vector3D.class);
               when(originalDirection.negate()).thenReturn(negatedDirection);
               
               // Create a line with mock points and set up the direction through constructor
               Line originalLine = mock(Line.class);
               when(originalLine.getDirection()).thenReturn(originalDirection);
               when(originalLine.revert()).thenCallRealMethod();
               when(originalLine.getOrigin()).thenReturn(mock(Vector3D.class));
               
               // Use reflection to set the private direction field for testing purposes
               try {
                   Field directionField = Line.class.getDeclaredField("direction");
                   directionField.setAccessible(true);
                   directionField.set(originalLine, originalDirection);
               } catch (Exception e) {
                   fail("Failed to set direction field through reflection");
               }
               
               // Call revert
               Line revertedLine = originalLine.revert();
               
               // Verify original direction wasn't changed
               assertEquals(originalDirection, originalLine.getDirection());
               
               // Verify new line has negated direction
               assertEquals(negatedDirection, revertedLine.getDirection());
               
               // Verify the lines are different instances
               assertNotSame(originalLine, revertedLine);
               
               // Verify negate was called exactly once (on the correct direction)
               verify(originalDirection, times(1)).negate();
           }

 @Test
           public void testRvertCreatesNewInstanceAndNegatesDirection() {
               // Setup original line
               Vector3D p1 = new Vector3D(1, 0, 0);
               Vector3D p2 = new Vector3D(2, 0, 0);
               Line originalLine = new Line(p1, p2);
               
               // Call revert
               Line revertedLine = originalLine.revert();
               
               // Verify it's a new instance
               assertNotSame("Reverted line should be a new instance", originalLine, revertedLine);
               
               // Verify direction is negated
               Vector3D originalDirection = originalLine.getDirection();
               Vector3D revertedDirection = revertedLine.getDirection();
               assertEquals("Direction X should be negated", -originalDirection.getX(), revertedDirection.getX(), 0.0001);
               assertEquals("Direction Y should be negated", -originalDirection.getY(), revertedDirection.getY(), 0.0001);
               assertEquals("Direction Z should be negated", -originalDirection.getZ(), revertedDirection.getZ(), 0.0001);
               
               // Verify origin remains the same
               assertEquals("Origin X should remain same", 
                   originalLine.getOrigin().getX(), revertedLine.getOrigin().getX(), 0.0001);
               assertEquals("Origin Y should remain same", 
                   originalLine.getOrigin().getY(), revertedLine.getOrigin().getY(), 0.0001);
               assertEquals("Origin Z should remain same", 
                   originalLine.getOrigin().getZ(), revertedLine.getOrigin().getZ(), 0.0001);
               
               // Test that the returned line can't be reassigned (would fail if not final)
               try {
                   // This would cause compilation error if reverted was final in original code
                   // We can't test this directly, but we can verify behavior is consistent
                   Line testLine = originalLine.revert();
                   testLine = new Line(p1, p2); // Would work if not final
                   // No good way to test this at runtime since final is compile-time
                   // So we rely on the other assertions to verify correct behavior
               } catch (Exception e) {
                   fail("Unexpected exception during reassignment test");
               }
           }

 @Test
          public void testRvertDetectsMutant() {
              // Setup original line with known direction
              Vector3D originalDirection = new Vector3D(1, 2, 3);
              Vector3D origin = new Vector3D(0, 0, 0);
              Line originalLine = new Line(origin, originalDirection);
              
              // Call revert()
              Line revertedLine = originalLine.revert();
              
              // Verify original line's direction wasn't changed
              assertEquals(originalDirection, originalLine.getDirection());
              
              // Verify reverted line has negated direction
              assertEquals(originalDirection.negate(), revertedLine.getDirection());
              
              // Verify other fields were properly copied
              assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
              
              // Additional check: verify the reverted line is properly constructed
              Line revertedAgain = revertedLine.revert();
              assertEquals(originalDirection, revertedAgain.getDirection());
          }

 @Test
     public void testRevertDetectsScalarMultiplyMutant1() {
         // Create original line with specific direction
         Vector3D originalDirection = new Vector3D(1.0, 2.0, 3.0);
         Vector3D origin = new Vector3D(0.0, 0.0, 0.0);
         Line originalLine = new Line(origin, originalDirection);
         
         // Get reverted line
         Line revertedLine = originalLine.revert();
         
         // Verify direction was properly negated
         Vector3D expectedNegated = originalDirection.negate();
         Vector3D actualNegated = revertedLine.getDirection();
         
         // Check exact equality to catch any precision differences
         assertEquals(expectedNegated.getX(), actualNegated.getX(), 0.0);
         assertEquals(expectedNegated.getY(), actualNegated.getY(), 0.0);
         assertEquals(expectedNegated.getZ(), actualNegated.getZ(), 0.0);
         
         // Test with edge case - zero vector
         Vector3D zeroVector = new Vector3D(0.0, 0.0, 0.0);
         Line zeroLine = new Line(origin, zeroVector);
         Line revertedZero = zeroLine.revert();
         
         // Should still be zero vector after revert
         assertEquals(0.0, revertedZero.getDirection().getX(), 0.0);
         assertEquals(0.0, revertedZero.getDirection().getY(), 0.0);
         assertEquals(0.0, revertedZero.getDirection().getZ(), 0.0);
         
         // Test with minimal non-zero values
         Vector3D minimalVector = new Vector3D(Double.MIN_VALUE, Double.MIN_VALUE, Double.MIN_VALUE);
         Line minimalLine = new Line(origin, minimalVector);
         Line revertedMinimal = minimalLine.revert();
         
         // Verify exact negation of minimal values
         assertEquals(-Double.MIN_VALUE, revertedMinimal.getDirection().getX(), 0.0);
         assertEquals(-Double.MIN_VALUE, revertedMinimal.getDirection().getY(), 0.0);
         assertEquals(-Double.MIN_VALUE, revertedMinimal.getDirection().getZ(), 0.0);
     }

 @Test
        public void testRevertWithZeroDirectionShouldThrowZeroNormException() {
            // Create a line with zero direction vector
            Vector3D zeroVector = Vector3D.ZERO;
            Vector3D anyPoint = new Vector3D(1, 1, 1);
            Line line = new Line(anyPoint, zeroVector);
            
            // Expect the specific exception with ZERO_NORM
            thrown.expect(MathIllegalArgumentException.class);
            thrown.expectMessage(LocalizedFormats.ZERO_NORM.toString());
            
            // This should throw when trying to negate the zero vector
            line.revert();
        }

 @Test
   public void testRevertNegatesDirection1() {
       // Create original direction vector
       Vector3D originalDirection = new Vector3D(1, 2, 3);
       
       // Create a line with this direction
       Line originalLine = new Line(Vector3D.ZERO, originalDirection);
       
       // Get the reverted line
       Line revertedLine = originalLine.revert();
       
       // Verify the direction was negated
       Vector3D expectedDirection = originalDirection.negate();
       Vector3D actualDirection = revertedLine.getDirection();
       
       // Assert the direction was properly negated
       assertEquals("X component should be negated", 
                   expectedDirection.getX(), actualDirection.getX(), 1e-10);
       assertEquals("Y component should be negated", 
                   expectedDirection.getY(), actualDirection.getY(), 1e-10);
       assertEquals("Z component should be negated", 
                   expectedDirection.getZ(), actualDirection.getZ(), 1e-10);
       
       // Also verify the original line wasn't modified
       assertEquals("Original line X direction should remain unchanged",
                   originalDirection.getX(), originalLine.getDirection().getX(), 1e-10);
       assertEquals("Original line Y direction should remain unchanged",
                   originalDirection.getY(), originalLine.getDirection().getY(), 1e-10);
       assertEquals("Original line Z direction should remain unchanged",
                   originalDirection.getZ(), originalLine.getDirection().getZ(), 1e-10);
   }

 @Test
  public void testRvert_CopiesAllFieldsAndNegatesDirection() {
      // Setup original line
      Vector3D originalDirection = new Vector3D(1, 2, 3);
      Vector3D originalZero = new Vector3D(4, 5, 6);
      Line originalLine = new Line(originalZero, originalDirection);
      
      // Call revert
      Line revertedLine = originalLine.revert();
      
      // Verify zero point was copied correctly
      assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
      
      // Verify direction was negated
      assertEquals(originalLine.getDirection().negate(), revertedLine.getDirection());
      
      // Additional check that original line wasn't modified
      assertEquals(originalDirection, originalLine.getDirection());
      assertEquals(originalZero, originalLine.getOrigin());
  }

 @Test
     public void testRevertWithZeroDirectionShouldThrowExceptionWithMessage() {
         // Create a line with zero direction vector
         Vector3D zeroVector = Vector3D.ZERO;
         Vector3D anyPoint = new Vector3D(1, 0, 0);
         Line line = new Line(anyPoint, zeroVector);
         
         // Expect exception with non-null message
         thrown.expect(MathIllegalArgumentException.class);
         thrown.expectMessage(LocalizedFormats.ZERO_NORM.getSourceString());
         
         // This should throw the exception
         line.revert();
     }

}
