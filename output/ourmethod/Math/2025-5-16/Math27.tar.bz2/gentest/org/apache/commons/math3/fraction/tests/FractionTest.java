package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                        public void testPercentageValue_WithWholeNumbers() {
                            // Test with whole numbers
                            assertEquals(100.0, new Fraction(1).percentageValue(), 0.00001);
                            assertEquals(200.0, new Fraction(2).percentageValue(), 0.00001);
                            assertEquals(0.0, new Fraction(0).percentageValue(), 0.00001);
                            assertEquals(-100.0, new Fraction(-1).percentageValue(), 0.00001);
                        }

 @Test
                        public void testPercentageValue_WithCommonFractions() {
                            // Test with common fractions
                            assertEquals(50.0, Fraction.ONE_HALF.percentageValue(), 0.00001);
                            assertEquals(25.0, Fraction.ONE_QUARTER.percentageValue(), 0.00001);
                            assertEquals(75.0, Fraction.THREE_QUARTERS.percentageValue(), 0.00001);
                            assertEquals(33.33333, Fraction.ONE_THIRD.percentageValue(), 0.00001);
                            assertEquals(66.66666, Fraction.TWO_THIRDS.percentageValue(), 0.00001);
                        }

 @Test
                        public void testPercentageValue_WithPredefinedConstants() {
                            // Test with all predefined constants
                            assertEquals(100.0, Fraction.ONE.percentageValue(), 0.00001);
                            assertEquals(200.0, Fraction.TWO.percentageValue(), 0.00001);
                            assertEquals(0.0, Fraction.ZERO.percentageValue(), 0.00001);
                            assertEquals(20.0, Fraction.ONE_FIFTH.percentageValue(), 0.00001);
                            assertEquals(40.0, Fraction.TWO_FIFTHS.percentageValue(), 0.00001);
                            assertEquals(60.0, Fraction.THREE_FIFTHS.percentageValue(), 0.00001);
                            assertEquals(80.0, Fraction.FOUR_FIFTHS.percentageValue(), 0.00001);
                            assertEquals(-100.0, Fraction.MINUS_ONE.percentageValue(), 0.00001);
                        }

 @Test
                        public void testPercentageValue_WithDecimalFractions() {
                            // Test with fractions created from decimal values
                            assertEquals(33.33333, new Fraction(1.0/3.0).percentageValue(), 0.00001);
                            assertEquals(66.66666, new Fraction(2.0/3.0).percentageValue(), 0.00001);
                            assertEquals(12.5, new Fraction(0.125).percentageValue(), 0.00001);
                            assertEquals(37.5, new Fraction(0.375).percentageValue(), 0.00001);
                        }

 @Test
                        public void testPercentageValue_WithEdgeCases() {
                            // Test edge cases
                            assertEquals(0.0, new Fraction(0, 1).percentageValue(), 0.00001);
                            assertEquals(Double.POSITIVE_INFINITY, new Fraction(1, 0).percentageValue(), 0.00001);
                            assertEquals(Double.NEGATIVE_INFINITY, new Fraction(-1, 0).percentageValue(), 0.00001);
                        }

 @Test
                        public void testPercentageValue_WithLargeNumbers() {
                            // Test with large numbers
                            assertEquals(1.0E9, new Fraction(10000000, 100).percentageValue(), 0.00001);
                            assertEquals(-2.147483647E9, new Fraction(Integer.MIN_VALUE + 1, 100).percentageValue(), 0.00001);
                        }

 @Test
                        public void testPercentageValue_WithPrecisionLimits() {
                            // Test precision limits
                            Fraction tinyFraction = new Fraction(1, Integer.MAX_VALUE);
                            assertEquals(100.0 / Integer.MAX_VALUE, tinyFraction.percentageValue(), 0.00001);
                        }

 @Test
                    public void testPercentageValueWithLargeNumber() {
                        // Create a fraction with a very large numerator that would cause overflow if multiplied as int
                        Fraction fraction = new Fraction(Integer.MAX_VALUE, 1);
                        
                        // The expected value is Integer.MAX_VALUE * 100.0
                        double expected = Integer.MAX_VALUE * 100.0;
                        
                        // The mutant would produce the correct value while the original might overflow
                        double actual = fraction.percentageValue();
                        
                        // Assert the exact value to catch the difference
                        assertEquals("Percentage value should handle large numbers correctly", 
                                    expected, actual, 0.0001);
                    }

 @Test
                    public void testPercentageValueWithPrecision() {
                        // Test with a fraction that would show floating point precision differences
                        Fraction fraction = new Fraction(1, 3); // 0.333...
                        
                        // Expected: 100 * (1/3) = 33.333...
                        double expected = 100.0 * (1.0/3.0);
                        
                        double actual = fraction.percentageValue();
                        
                        // Assert with high precision to catch any floating point differences
                        assertEquals("Percentage value should maintain floating point precision",
                                    expected, actual, 0.0000001);
                    }

 @Test
               public void testPercentageValueEdgeCases() {
                   // Test with a fraction that would produce Double.MAX_VALUE when multiplied
                   Fraction hugeFraction = new Fraction(Integer.MAX_VALUE, 1);
                   double expected = 100 * hugeFraction.doubleValue();
                   double actual = hugeFraction.percentageValue();
                   
                   // Verify exact bit pattern to catch any floating-point arithmetic differences
                   assertEquals(Double.doubleToLongBits(expected), 
                                Double.doubleToLongBits(actual));
                   
                   // Test with a fraction that would produce Double.MIN_VALUE
                   Fraction tinyFraction = new Fraction(1, Integer.MAX_VALUE);
                   expected = 100 * tinyFraction.doubleValue();
                   actual = tinyFraction.percentageValue();
                   assertEquals(Double.doubleToLongBits(expected), 
                                Double.doubleToLongBits(actual));
                   
                   // Test with zero
                   Fraction zero = Fraction.ZERO;
                   expected = 100 * zero.doubleValue();
                   actual = zero.percentageValue();
                   assertEquals(Double.doubleToLongBits(expected), 
                                Double.doubleToLongBits(actual));
                   
                   // Test with NaN case (though Fraction shouldn't normally produce NaN)
                   Fraction nanFraction = mock(Fraction.class);
                   when(nanFraction.doubleValue()).thenReturn(Double.NaN);
                   when(nanFraction.percentageValue()).thenCallRealMethod();
                   assertTrue(Double.isNaN(nanFraction.percentageValue()));
               }

 @Test
                  public void testPercentageValue() {
                      // Test with simple fraction that would clearly show multiplication vs addition difference
                      Fraction half = new Fraction(1, 2);
                      assertEquals(50.0, half.percentageValue(), 0.0001);
                      
                      // Test with another fraction to ensure it's not a coincidence
                      Fraction quarter = new Fraction(1, 4);
                      assertEquals(25.0, quarter.percentageValue(), 0.0001);
                      
                      // Test with a fraction that would have more significant difference
                      Fraction third = new Fraction(1, 3);
                      assertEquals(33.333333, third.percentageValue(), 0.0001);
                      
                      // Test with whole number
                      Fraction one = new Fraction(1);
                      assertEquals(100.0, one.percentageValue(), 0.0001);
                      
                      // Test with zero
                      Fraction zero = new Fraction(0);
                      assertEquals(0.0, zero.percentageValue(), 0.0001);
                  }

 @Test
                 public void testPercentageValueDetectsMultiplicationMutant() {
                     // Create a fraction that would show different results with the mutation
                     Fraction fraction = new Fraction(1, 4);  // 1/4 = 0.25
                     
                     // Original behavior: percentageValue() returns 100 * (1/4) = 25.0
                     // Mutated behavior (if multiplication was changed): would return different value
                     double expectedPercentage = 25.0;
                     double actualPercentage = fraction.percentageValue();
                     
                     // Assert with delta for floating point precision
                     assertEquals("Percentage value should be 25.0 for 1/4", 
                                 expectedPercentage, actualPercentage, 0.0001);
                     
                     // Test another fraction to be thorough
                     Fraction fraction2 = new Fraction(3, 5);  // 3/5 = 0.6
                     assertEquals("Percentage value should be 60.0 for 3/5",
                                 60.0, fraction2.percentageValue(), 0.0001);
                 }

 @Test
                public void testPercentageValueDetectsMultiplicationMutant1() {
                    // Create a fraction where denominator (5) and multiplier (3) would produce 
                    // different results for * vs - operations
                    Fraction fraction = new Fraction(1, 5);
                    
                    // The correct percentage value should be (1/5)*100 = 20.0
                    // With the mutant (denominator - i), if this affected percentageValue indirectly,
                    // the result would be different
                    double expectedPercentage = 20.0;
                    double actualPercentage = fraction.percentageValue();
                    
                    assertEquals("Percentage value should be 20.0 for 1/5 fraction", 
                                expectedPercentage, actualPercentage, 0.0001);
                    
                    // Additional check to ensure the fraction's double value is correct
                    // since percentageValue depends on it
                    double expectedDoubleValue = 0.2;
                    double actualDoubleValue = fraction.doubleValue();
                    assertEquals("Double value should be 0.2 for 1/5 fraction",
                                expectedDoubleValue, actualDoubleValue, 0.0001);
                }

 @Test
               public void testPercentageValue1() {
                   // Test with a simple fraction that would clearly show the mutation
                   Fraction half = new Fraction(1, 2); // 1/2 = 0.5
                   
                   // Original should return 100 * 0.5 = 50.0
                   // Mutated version would return different value
                   assertEquals(50.0, half.percentageValue(), 0.0001);
                   
                   // Test with another fraction to ensure robustness
                   Fraction quarter = new Fraction(1, 4); // 1/4 = 0.25
                   assertEquals(25.0, quarter.percentageValue(), 0.0001);
                   
                   // Test with whole number
                   Fraction one = new Fraction(1); // 1/1 = 1.0
                   assertEquals(100.0, one.percentageValue(), 0.0001);
                   
                   // Test with negative fraction
                   Fraction minusHalf = new Fraction(-1, 2); // -1/2 = -0.5
                   assertEquals(-50.0, minusHalf.percentageValue(), 0.0001);
               }

 @Test
              public void testPercentageValue2() {
                  // Test with 1/2 which should be 50%
                  Fraction half = new Fraction(1, 2);
                  assertEquals(50.0, half.percentageValue(), 0.0001);
                  
                  // Test with 1/4 which should be 25%
                  Fraction quarter = new Fraction(1, 4);
                  assertEquals(25.0, quarter.percentageValue(), 0.0001);
                  
                  // Test with 3/4 which should be 75%
                  Fraction threeQuarters = new Fraction(3, 4);
                  assertEquals(75.0, threeQuarters.percentageValue(), 0.0001);
                  
                  // Test with 0 which should be 0%
                  Fraction zero = new Fraction(0, 1);
                  assertEquals(0.0, zero.percentageValue(), 0.0001);
                  
                  // Test with 1 which should be 100%
                  Fraction one = new Fraction(1, 1);
                  assertEquals(100.0, one.percentageValue(), 0.0001);
              }

 @Test
         public void testMultiplyIntDetectsMutant() {
             // Create a simple fraction 1/2
             Fraction original = new Fraction(1, 2);
             
             // Multiply by 2 - should become 1/4 (0.25) in original, but becomes 2/2 (1.0) in mutant
             Fraction multiplied = original.multiply(2);
             
             // Verify both numerator and denominator to catch the mutant
             assertEquals("Numerator should be 1 (original keeps numerator same)", 1, multiplied.getNumerator());
             assertEquals("Denominator should be 4 (original multiplies denominator)", 4, multiplied.getDenominator());
             
             // Also verify the actual value to be extra sure
             assertEquals(0.25, multiplied.doubleValue(), 0.0001);
         }

 @Test
        public void testPercentageValueWithLargeNumber1() {
            // Create a fraction with a very large value
            Fraction fraction = new Fraction(Integer.MAX_VALUE, 1);
            
            // Calculate expected value using floating-point multiplication
            double expected = 100.0 * fraction.doubleValue();
            
            // The mutation would show difference if integer multiplication was attempted first
            double actual = fraction.percentageValue();
            
            // Assert exact equality since we're testing the computation path
            assertEquals("Percentage value should be calculated using floating-point multiplication", 
                        expected, actual, 0.0);
            
            // Additional test with a very small fraction to check precision
            Fraction smallFraction = new Fraction(1, Integer.MAX_VALUE);
            expected = 100.0 * smallFraction.doubleValue();
            actual = smallFraction.percentageValue();
            assertEquals("Percentage value should maintain precision for small numbers",
                        expected, actual, 0.0);
        }

 @Test
       public void testPercentageValueWithSpecialDoubleValues() {
           // Create a mock Fraction object
           Fraction fraction = mock(Fraction.class);
           
           // Test case 1: When doubleValue() returns NaN
           when(fraction.doubleValue()).thenReturn(Double.NaN);
           when(fraction.percentageValue()).thenCallRealMethod();
           assertTrue(Double.isNaN(fraction.percentageValue()));
           
           // Test case 2: When doubleValue() returns positive infinity
           when(fraction.doubleValue()).thenReturn(Double.POSITIVE_INFINITY);
           assertEquals(Double.POSITIVE_INFINITY, fraction.percentageValue(), 0.0);
           
           // Test case 3: When doubleValue() returns negative infinity
           when(fraction.doubleValue()).thenReturn(Double.NEGATIVE_INFINITY);
           assertEquals(Double.NEGATIVE_INFINITY, fraction.percentageValue(), 0.0);
           
           // Test case 4: When doubleValue() returns maximum double value
           when(fraction.doubleValue()).thenReturn(Double.MAX_VALUE);
           assertEquals(Double.POSITIVE_INFINITY, fraction.percentageValue(), 0.0);
           
           // Test case 5: When doubleValue() returns minimum double value
           when(fraction.doubleValue()).thenReturn(Double.MIN_VALUE);
           assertEquals(100 * Double.MIN_VALUE, fraction.percentageValue(), 0.0);
           
           // Test case 6: Verify operation ordering with a specific value
           when(fraction.doubleValue()).thenReturn(0.1);
           assertEquals(10.0, fraction.percentageValue(), 0.0001);
       }

 @Test
          public void testMultiplyDetectsDenominatorMutation() {
              // Create a simple fraction 1/2
              Fraction half = new Fraction(1, 2);
              
              // Multiply by 2 - should become 1/4 (1/(2*2))
              Fraction result = half.multiply(2);
              
              // With the mutation (denominator + i), it would become 1/3 (1/(2+2))
              // So we test both numerator and denominator
              assertEquals("Numerator should be 1", 1, result.getNumerator());
              assertEquals("Denominator should be 4", 4, result.getDenominator());
              
              // Also test the actual value
              assertEquals(0.25, result.doubleValue(), 0.0001);
          }

 @Test
          public void testMultiplyWithDifferentValues() {
              // Test with another fraction to be thorough
              Fraction third = new Fraction(1, 3);
              
              // Multiply by 3 - should become 1/9 (1/(3*3))
              Fraction result = third.multiply(3);
              
              // With mutation it would be 1/6 (1/(3+3))
              assertEquals("Numerator should be 1", 1, result.getNumerator());
              assertEquals("Denominator should be 9", 9, result.getDenominator());
              assertEquals(1.0/9, result.doubleValue(), 0.0001);
          }

 @Test
         public void testPercentageValue3() {
             // Test case 1: 1/2 should return 50.0 (0.5 * 100)
             Fraction half = new Fraction(1, 2);
             assertEquals(50.0, half.percentageValue(), 0.0001);
             
             // Test case 2: 1/100 should return 1.0 (0.01 * 100)
             Fraction oneHundredth = new Fraction(1, 100);
             assertEquals(1.0, oneHundredth.percentageValue(), 0.0001);
             
             // Test case 3: 3/2 should return 150.0 (1.5 * 100)
             Fraction threeHalves = new Fraction(3, 2);
             assertEquals(150.0, threeHalves.percentageValue(), 0.0001);
             
             // Test case 4: 0/1 should return 0.0 (0 * 100)
             Fraction zero = new Fraction(0, 1);
             assertEquals(0.0, zero.percentageValue(), 0.0001);
             
             // Test case 5: 1/1 should return 100.0 (1 * 100)
             Fraction one = new Fraction(1, 1);
             assertEquals(100.0, one.percentageValue(), 0.0001);
         }

 @Test
         public void testMultiplyInt() {
             // Original fraction: 1/2
             Fraction half = new Fraction(1, 2);
             
             // Test case 1: Multiply by 2
             // Original: (1)/(2*2) = 1/4
             // Mutated: (1*2)/2 = 2/2 = 1/1
             Fraction result1 = half.multiply(2);
             assertEquals(1, result1.getNumerator());
             assertEquals(4, result1.getDenominator());
             
             // Test case 2: Multiply by -1
             // Original: (1)/(2*-1) = -1/2
             // Mutated: (1*-1)/2 = -1/2
             // (Same result in this case)
             Fraction result2 = half.multiply(-1);
             assertEquals(-1, result2.getNumerator());
             assertEquals(2, result2.getDenominator());
             
             // Test case 3: Multiply by 0
             // Original: (1)/(2*0) - should throw exception (divide by zero)
             // Mutated: (1*0)/2 = 0/2 = 0/1
             try {
                 Fraction result3 = half.multiply(0);
                 fail("Expected ArithmeticException not thrown");
             } catch (ArithmeticException e) {
                 // Expected for original behavior
             }
             
             // Test case 4: Multiply 3/4 by 2
             // Original: (3)/(4*2) = 3/8
             // Mutated: (3*2)/4 = 6/4 = 3/2
             Fraction threeQuarters = new Fraction(3, 4);
             Fraction result4 = threeQuarters.multiply(2);
             assertEquals(3, result4.getNumerator());
             assertEquals(8, result4.getDenominator());
         }

 @Test
        public void testPercentageValue4() {
            // Test simple fraction (1/2 = 0.5 = 50%)
            Fraction half = new Fraction(1, 2);
            assertEquals(50.0, half.percentageValue(), 0.0001);
            
            // Test fraction where numerator > denominator (3/2 = 1.5 = 150%)
            Fraction threeHalves = new Fraction(3, 2);
            assertEquals(150.0, threeHalves.percentageValue(), 0.0001);
            
            // Test zero case (0/1 = 0 = 0%)
            Fraction zero = new Fraction(0, 1);
            assertEquals(0.0, zero.percentageValue(), 0.0001);
            
            // Test whole number (1/1 = 1 = 100%)
            Fraction one = new Fraction(1, 1);
            assertEquals(100.0, one.percentageValue(), 0.0001);
            
            // Test fraction with larger denominator (1/4 = 0.25 = 25%)
            Fraction quarter = new Fraction(1, 4);
            assertEquals(25.0, quarter.percentageValue(), 0.0001);
            
            // Test negative fraction (-1/2 = -0.5 = -50%)
            Fraction negativeHalf = new Fraction(-1, 2);
            assertEquals(-50.0, negativeHalf.percentageValue(), 0.0001);
        }

 @Test
       public void testPercentageValue5() {
           // Test simple fraction (1/1 should be 100%)
           Fraction whole = new Fraction(1, 1);
           assertEquals(100.0, whole.percentageValue(), 0.0001);
           
           // Test fraction where numerator is multiple of denominator (4/2 = 200%)
           Fraction doubleVal = new Fraction(4, 2);
           assertEquals(200.0, doubleVal.percentageValue(), 0.0001);
           
           // Test fraction where denominator is multiple of numerator (1/2 = 50%)
           Fraction half = new Fraction(1, 2);
           assertEquals(50.0, half.percentageValue(), 0.0001);
           
           // Test fraction with negative value (-1/2 = -50%)
           Fraction negative = new Fraction(-1, 2);
           assertEquals(-50.0, negative.percentageValue(), 0.0001);
           
           // Test fraction with large values
           Fraction large = new Fraction(1000000, 2000000);
           assertEquals(50.0, large.percentageValue(), 0.0001);
           
           // Test fraction that would be affected by numerator/denominator mutation
           Fraction complex = new Fraction(3, 4);
           assertEquals(75.0, complex.percentageValue(), 0.0001);
       }

 @Test
      public void testPercentageValueDetectsMultiplicationMutant2() {
          // Create a simple fraction 1/2
          Fraction half = new Fraction(1, 2);
          
          // Multiply by 2 - should result in 2/4 which is still 50% when reduced
          Fraction multiplied = half.multiply(2);
          
          // With original code: 2/4 reduces to 1/2 → 50%
          // With mutant (denominator + i): 2/(2+2) = 2/4 → still 50% in this case
          // Need a case where multiplication and addition differ
          
          // Better test case: multiply by 3
          Fraction multipliedByThree = half.multiply(3);
          
          // Original: (1*3)/(2*3) = 3/6 → 50%
          // Mutant: (1*3)/(2+3) = 3/5 → 60%
          assertEquals("Percentage value should be 50 for 3/6", 
                       50.0, multipliedByThree.percentageValue(), 0.0001);
          
          // Another test case with different fraction
          Fraction third = new Fraction(1, 3);
          Fraction multipliedByFour = third.multiply(4);
          
          // Original: (1*4)/(3*4) = 4/12 → ~33.333%
          // Mutant: (1*4)/(3+4) = 4/7 → ~57.142%
          assertEquals("Percentage value should be ~33.333 for 4/12", 
                       100.0/3, multipliedByFour.percentageValue(), 0.0001);
      }

 @Test
     public void testPercentageValueDetectsMultiplicationMutant3() {
         // Create a fraction where numerator and denominator are different
         // to detect if multiplication is applied to numerator instead of denominator
         Fraction fraction = new Fraction(1, 4); // Represents 0.25
         
         // Original behavior: percentageValue() should return 25.0 (100 * 0.25)
         // Mutated behavior (multiplying numerator): would return 100 * (100/4) = 2500.0
         double expectedPercentage = 25.0;
         double actualPercentage = fraction.percentageValue();
         
         assertEquals("Percentage value calculation is incorrect", 
                     expectedPercentage, actualPercentage, 0.0001);
         
         // Additional test case with different values to be thorough
         Fraction fraction2 = new Fraction(3, 10); // Represents 0.3
         double expectedPercentage2 = 30.0;
         double actualPercentage2 = fraction2.percentageValue();
         
         assertEquals("Percentage value calculation is incorrect for 3/10", 
                     expectedPercentage2, actualPercentage2, 0.0001);
     }

}
