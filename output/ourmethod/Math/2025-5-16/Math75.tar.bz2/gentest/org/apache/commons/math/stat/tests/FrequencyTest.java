package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
import org.apache.commons.math.MathRuntimeException;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                         public void testGetPct_WithCustomComparator() {
                                                                             // Create frequency with custom comparator (case insensitive)
                                                                             Comparator<String> caseInsensitiveComparator = String::compareToIgnoreCase;
                                                                             Frequency customFrequency = new Frequency(caseInsensitiveComparator);
                                                                             
                                                                             // Add values
                                                                             customFrequency.addValue("Apple");
                                                                             customFrequency.addValue("apple");
                                                                             customFrequency.addValue("Banana");
                                                                             
                                                                             // Test that case doesn't matter with our comparator
                                                                             assertEquals(0.6666, customFrequency.getPct("APPLE"), 0.0001);  // 2/3
                                                                             assertEquals(0.3333, customFrequency.getPct("banana"), 0.0001); // 1/3
                                                                         }

 @Test
                                                                         public void testGetPct_ZeroTotalFrequency() {
                                                                             // This case shouldn't normally happen, but should be handled
                                                                             Frequency freqWithMock = new Frequency();
                                                                             TreeMap<Comparable<?>, Long> mockMap = mock(TreeMap.class);
                                                                             when(mockMap.isEmpty()).thenReturn(false);
                                                                             when(mockMap.values()).thenReturn(java.util.Collections.singleton(0L));
                                                                             
                                                                             // Use reflection to set the private field for testing
                                                                             try {
                                                                                 java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                 field.setAccessible(true);
                                                                                 field.set(freqWithMock, mockMap);
                                                                             } catch (Exception e) {
                                                                                 fail("Failed to set mock field");
                                                                             }
                                                                             
                                                                             assertEquals(0.0, freqWithMock.getPct(5L), 0.0001);
                                                                         }

 @Test
                                                                         public void testGetPct_WithComparatorConstructor() {
                                                                             // Test with custom comparator
                                                                             Comparator<Long> comparator = (a, b) -> Long.compare(a, b);
                                                                             Frequency freqWithComparator = new Frequency(comparator);
                                                                             
                                                                             freqWithComparator.addValue(5L);
                                                                             freqWithComparator.addValue(10L);
                                                                             freqWithComparator.addValue(5L);
                                                                             
                                                                             assertEquals(0.6666, freqWithComparator.getPct(5L), 0.0001);
                                                                         }

 @Test
                                                                 public void testGetPct_WithEmptyFrequencyTable() {
                                                                     // Test when frequency table is empty
                                                                     Frequency frequency = new Frequency();
                                                                     assertEquals(0.0, frequency.getPct("anyValue"), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithSingleValue() {
                                                                     // Initialize frequency object
                                                                     org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                                     
                                                                     // Add a single value multiple times
                                                                     frequency.addValue("A");
                                                                     frequency.addValue("A");
                                                                     frequency.addValue("A");
                                                                     
                                                                     // Test percentage for the existing value
                                                                     assertEquals(1.0, frequency.getPct("A"), 0.0001);
                                                                     
                                                                     // Test percentage for non-existing value
                                                                     assertEquals(0.0, frequency.getPct("B"), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithMultipleValues() {
                                                                     // Create frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add multiple values with different frequencies
                                                                     frequency.addValue("A");
                                                                     frequency.addValue("A");
                                                                     frequency.addValue("B");
                                                                     frequency.addValue("C");
                                                                     frequency.addValue("C");
                                                                     frequency.addValue("C");
                                                                     frequency.addValue("C");
                                                                     
                                                                     // Test percentages
                                                                     assertEquals(0.2857, frequency.getPct("A"), 0.0001);  // 2/7
                                                                     assertEquals(0.1428, frequency.getPct("B"), 0.0001);  // 1/7
                                                                     assertEquals(0.5714, frequency.getPct("C"), 0.0001);  // 4/7
                                                                     assertEquals(0.0, frequency.getPct("D"), 0.0001);     // 0/7
                                                                 }

 @Test
                                                                 public void testGetPct_WithNullValue() {
                                                                     // Create frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add some values first
                                                                     frequency.addValue("A");
                                                                     frequency.addValue("B");
                                                                     
                                                                     // Test with null input
                                                                     assertEquals(0.0, frequency.getPct(null), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithDifferentTypes() {
                                                                     // Initialize frequency object
                                                                     org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                                     
                                                                     // Add values of different types
                                                                     frequency.addValue(1);
                                                                     frequency.addValue(2);
                                                                     frequency.addValue(2);
                                                                     frequency.addValue("A");
                                                                     frequency.addValue('b');
                                                                     frequency.addValue('b');
                                                                     frequency.addValue('b');
                                                                     
                                                                     // Test percentages for different types
                                                                     assertEquals(0.1428, frequency.getPct(1), 0.0001);    // 1/7
                                                                     assertEquals(0.2857, frequency.getPct(2), 0.0001);    // 2/7
                                                                     assertEquals(0.1428, frequency.getPct("A"), 0.0001);  // 1/7
                                                                     assertEquals(0.4285, frequency.getPct('b'), 0.0001);  // 3/7
                                                                 }

 @Test
                                                                 public void testGetPct_AfterClear() {
                                                                     // Create frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add some values
                                                                     frequency.addValue("A");
                                                                     frequency.addValue("B");
                                                                     frequency.addValue("B");
                                                                     
                                                                     // Clear the frequency table
                                                                     frequency.clear();
                                                                     
                                                                     // Test after clear
                                                                     assertEquals(0.0, frequency.getPct("A"), 0.0001);
                                                                     assertEquals(0.0, frequency.getPct("B"), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WhenSumFreqIsZero_ShouldReturnNaN() {
                                                                     // Setup - create new Frequency and mock getSumFreq to return 0
                                                                     Frequency frequency = new Frequency();
                                                                     Frequency spyFrequency = spy(frequency);
                                                                     when(spyFrequency.getSumFreq()).thenReturn(0L);
                                                                     
                                                                     // Test with any value
                                                                     double result = spyFrequency.getPct("anyValue");
                                                                     
                                                                     // Verify
                                                                     assertTrue(Double.isNaN(result));
                                                                 }

 @Test
                                                                 public void testGetPct_WhenValueExists_ShouldReturnCorrectPercentage() {
                                                                     // Setup - create frequency object and mock getSumFreq and getCount
                                                                     Frequency frequency = new Frequency();
                                                                     Frequency spyFrequency = spy(frequency);
                                                                     when(spyFrequency.getSumFreq()).thenReturn(100L);
                                                                     when(spyFrequency.getCount("testValue")).thenReturn(25L);
                                                                     
                                                                     // Test
                                                                     double result = spyFrequency.getPct("testValue");
                                                                     
                                                                     // Verify
                                                                     assertEquals(0.25, result, 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WhenValueDoesNotExist_ShouldReturnZero() {
                                                                     // Setup - create frequency object and mock getSumFreq and getCount
                                                                     Frequency frequency = new Frequency();
                                                                     Frequency spyFrequency = spy(frequency);
                                                                     when(spyFrequency.getSumFreq()).thenReturn(100L);
                                                                     when(spyFrequency.getCount("nonExistent")).thenReturn(0L);
                                                                     
                                                                     // Test
                                                                     double result = spyFrequency.getPct("nonExistent");
                                                                     
                                                                     // Verify
                                                                     assertEquals(0.0, result, 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithDifferentValueTypes_ShouldWorkConsistently() {
                                                                     // Setup - create frequency instance and mock getSumFreq and getCount for different types
                                                                     Frequency frequency = new Frequency();
                                                                     Frequency spyFrequency = spy(frequency);
                                                                     when(spyFrequency.getSumFreq()).thenReturn(100L);
                                                                     
                                                                     // Test Integer
                                                                     when(spyFrequency.getCount(42)).thenReturn(20L);
                                                                     assertEquals(0.2, spyFrequency.getPct(42), 0.0001);
                                                                     
                                                                     // Test Long
                                                                     when(spyFrequency.getCount(123L)).thenReturn(30L);
                                                                     assertEquals(0.3, spyFrequency.getPct(123L), 0.0001);
                                                                     
                                                                     // Test Character
                                                                     when(spyFrequency.getCount('A')).thenReturn(5L);
                                                                     assertEquals(0.05, spyFrequency.getPct('A'), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithPrecisionEdgeCases() {
                                                                     // Setup - create Frequency instance and mock getSumFreq and getCount
                                                                     Frequency frequency = new Frequency();
                                                                     Frequency spyFrequency = spy(frequency);
                                                                     
                                                                     // Test very small percentage
                                                                     when(spyFrequency.getSumFreq()).thenReturn(1000000L);
                                                                     when(spyFrequency.getCount("rare")).thenReturn(1L);
                                                                     assertEquals(0.000001, spyFrequency.getPct("rare"), 0.0000001);
                                                                     
                                                                     // Test 100% case
                                                                     when(spyFrequency.getSumFreq()).thenReturn(10L);
                                                                     when(spyFrequency.getCount("all")).thenReturn(10L);
                                                                     assertEquals(1.0, spyFrequency.getPct("all"), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_EmptyFrequencyTable() {
                                                                     // Test when frequency table is empty
                                                                     Frequency frequency = new Frequency();
                                                                     assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_ValueNotPresent() {
                                                                     // Initialize frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add some values but not the one we're testing
                                                                     frequency.addValue(10L);
                                                                     frequency.addValue(20L);
                                                                     frequency.addValue(10L);
                                                                     
                                                                     // Test that percentage for non-existent value is 0.0
                                                                     assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_SingleValue() {
                                                                     // Test with single value added once
                                                                     Frequency frequency = new Frequency();
                                                                     frequency.addValue(5L);
                                                                     assertEquals(1.0, frequency.getPct(5L), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_MultipleValues() {
                                                                     // Create frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Test with multiple values
                                                                     frequency.addValue(5L);
                                                                     frequency.addValue(10L);
                                                                     frequency.addValue(5L);
                                                                     frequency.addValue(15L);
                                                                     
                                                                     // 5 appears twice out of 4 total
                                                                     assertEquals(0.5, frequency.getPct(5L), 0.0001);
                                                                 }

 @Test(expected = NullPointerException.class)
                                                                 public void testGetPct_NullInput() {
                                                                     Frequency frequency = new Frequency();
                                                                     frequency.getPct((Long)null);
                                                                 }

 @Test
                                                                 public void testGetPct_ExtremeValues() {
                                                                     // Create new Frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Test with very large numbers
                                                                     frequency.addValue(Long.MAX_VALUE);
                                                                     frequency.addValue(Long.MAX_VALUE);
                                                                     frequency.addValue(Long.MIN_VALUE);
                                                                     
                                                                     assertEquals(0.6666, frequency.getPct(Long.MAX_VALUE), 0.0001);
                                                                     assertEquals(0.3333, frequency.getPct(Long.MIN_VALUE), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_AfterClear1() {
                                                                     Frequency frequency = new Frequency();
                                                                     frequency.addValue(5L);
                                                                     frequency.addValue(5L);
                                                                     frequency.clear();
                                                                     
                                                                     assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithEmptyFrequencyTable1() {
                                                                     // Test when frequency table is empty
                                                                     Frequency frequency = new Frequency();
                                                                     assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithSingleValue1() {
                                                                     // Create frequency instance
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add single value
                                                                     frequency.addValue(10L);
                                                                     
                                                                     // Test with the existing value
                                                                     assertEquals(1.0, frequency.getPct(10L), 0.0001);
                                                                     
                                                                     // Test with non-existing value
                                                                     assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithMultipleValues1() {
                                                                     // Create frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add multiple values
                                                                     frequency.addValue(10L);
                                                                     frequency.addValue(10L);
                                                                     frequency.addValue(20L);
                                                                     frequency.addValue(30L);
                                                                     
                                                                     // Test percentages
                                                                     assertEquals(0.5, frequency.getPct(10L), 0.0001);  // 2 out of 4
                                                                     assertEquals(0.25, frequency.getPct(20L), 0.0001); // 1 out of 4
                                                                     assertEquals(0.25, frequency.getPct(30L), 0.0001); // 1 out of 4
                                                                     assertEquals(0.0, frequency.getPct(40L), 0.0001); // non-existing
                                                                 }

 @Test
                                                                 public void testGetPct_WithZeroTotalFrequency() {
                                                                     // Create a new Frequency instance
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add zero frequency values (though this shouldn't normally happen)
                                                                     TreeMap<Comparable<?>, Long> mockTable = mock(TreeMap.class);
                                                                     when(mockTable.values()).thenReturn(java.util.Collections.singletonList(0L));
                                                                     
                                                                     // Use reflection to set the freqTable for testing
                                                                     try {
                                                                         java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                                         field.setAccessible(true);
                                                                         field.set(frequency, mockTable);
                                                                         
                                                                         // Test division by zero case
                                                                         assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                 }

 @Test
                                                                 public void testGetPct_WithNullInput() {
                                                                     org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                     org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                                     
                                                                     thrown.expect(NullPointerException.class);
                                                                     frequency.getPct((Object)null);
                                                                 }

 @Test
                                                                 public void testGetPct_WithDifferentValueTypes() {
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add values of different types
                                                                     frequency.addValue(10L);
                                                                     frequency.addValue(20);
                                                                     frequency.addValue('a');
                                                                     
                                                                     // Test percentages for each type
                                                                     assertEquals(1.0/3.0, frequency.getPct(10L), 0.0001);
                                                                     assertEquals(1.0/3.0, frequency.getPct(20), 0.0001);
                                                                     assertEquals(1.0/3.0, frequency.getPct('a'), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_WithExtremeValues() {
                                                                     // Create frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add extreme values
                                                                     frequency.addValue(Long.MAX_VALUE);
                                                                     frequency.addValue(Long.MIN_VALUE);
                                                                     frequency.addValue(0L);
                                                                     
                                                                     // Test percentages
                                                                     assertEquals(1.0/3.0, frequency.getPct(Long.MAX_VALUE), 0.0001);
                                                                     assertEquals(1.0/3.0, frequency.getPct(Long.MIN_VALUE), 0.0001);
                                                                     assertEquals(1.0/3.0, frequency.getPct(0L), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_Char_EmptyFrequencyTable() {
                                                                     // Create a new empty Frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // When table is empty, percentage should be 0 for any character
                                                                     assertEquals(0.0, frequency.getPct('a'), 0.0001);
                                                                     assertEquals(0.0, frequency.getPct('Z'), 0.0001);
                                                                     assertEquals(0.0, frequency.getPct('1'), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_Char_SingleEntry() {
                                                                     // Initialize frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add single character
                                                                     frequency.addValue('a');
                                                                     
                                                                     // Should return 100% for that character, 0% for others
                                                                     assertEquals(1.0, frequency.getPct('a'), 0.0001);
                                                                     assertEquals(0.0, frequency.getPct('b'), 0.0001);
                                                                 }

 @Test
                                                                 public void testGetPct_Char_MultipleEntries() {
                                                                     // Create frequency object
                                                                     Frequency frequency = new Frequency();
                                                                     
                                                                     // Add multiple characters
                                                                     frequency.addValue('a');
                                                                     frequency.addValue('a');
                                                                     frequency.addValue('b');
                                                                     frequency.addValue('c');
                                                                     frequency.addValue('c');
                                                                     frequency.addValue('c');
                                                                     
                                                                     // Verify percentages (a: 2/6, b: 1/6, c: 3/6, d: 0/6)
                                                                     assertEquals(2.0/6, frequency.getPct('a'), 0.0001);
                                                                     assertEquals(1.0/6, frequency.getPct('b'), 0.0001);
                                                                     assertEquals(3.0/6, frequency.getPct('c'), 0.0001);
                                                                     assertEquals(0.0, frequency.getPct('d'), 0.0001);
                                                                 }

 @Test
                                                             public void testGetPct_Char_WithNonCharValues() {
                                                                 Frequency frequency = new Frequency();
                                                                 
                                                                 // Add mixed types (though the method only handles chars)
                                                                 frequency.addValue('a');
                                                                 try {
                                                                     frequency.addValue(1); // This should fail or be ignored for char-specific counting
                                                                 } catch (Exception e) {
                                                                     // Expected if the implementation rejects non-char values
                                                                 }
                                                                 try {
                                                                     frequency.addValue("string"); // This should fail or be ignored for char-specific counting
                                                                 } catch (Exception e) {
                                                                     // Expected if the implementation rejects non-char values
                                                                 }
                                                                 frequency.addValue('a');
                                                                 
                                                                 // Only chars should be counted for this method
                                                                 assertEquals(2.0/2, frequency.getPct('a'), 0.0001); // Denominator is 2 because only chars should count
                                                                 assertEquals(0.0, frequency.getPct('1'), 0.0001);
                                                             }

 @Test
                                                             public void testGetPct_Char_SpecialCharacters() {
                                                                 // Initialize frequency object
                                                                 Frequency frequency = new Frequency();
                                                                 
                                                                 // Test with special characters
                                                                 frequency.addValue('\n');
                                                                 frequency.addValue('\t');
                                                                 frequency.addValue(' ');
                                                                 frequency.addValue('@');
                                                                 frequency.addValue('@');
                                                                 
                                                                 // Verify percentages
                                                                 assertEquals(1.0/5, frequency.getPct('\n'), 0.0001);
                                                                 assertEquals(1.0/5, frequency.getPct('\t'), 0.0001);
                                                                 assertEquals(1.0/5, frequency.getPct(' '), 0.0001);
                                                                 assertEquals(2.0/5, frequency.getPct('@'), 0.0001);
                                                             }

 @Test
                                                             public void testGetPct_Char_AfterClear() {
                                                                 // Create frequency object
                                                                 Frequency frequency = new Frequency();
                                                                 
                                                                 // Add values then clear
                                                                 frequency.addValue('a');
                                                                 frequency.addValue('b');
                                                                 frequency.clear();
                                                                 
                                                                 // After clear, should return 0 for any character
                                                                 assertEquals(0.0, frequency.getPct('a'), 0.0001);
                                                                 assertEquals(0.0, frequency.getPct('b'), 0.0001);
                                                             }

 @Test
                                                             public void testGetPct_Char_UnicodeCharacters() {
                                                                 // Test with Unicode characters
                                                                 Frequency frequency = new Frequency();
                                                                 frequency.addValue('あ');
                                                                 frequency.addValue('あ');
                                                                 frequency.addValue('β');
                                                                 
                                                                 assertEquals(2.0/3, frequency.getPct('あ'), 0.0001);
                                                                 assertEquals(1.0/3, frequency.getPct('β'), 0.0001);
                                                                 assertEquals(0.0, frequency.getPct('你'), 0.0001);
                                                             }

 @Test
                         public void testGetPct_WithNullValue_ShouldHandleGracefully() {
                             // Setup - create frequency object
                             org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                             
                             // Test
                             double result = frequency.getPct(null);
                             
                             // Verify
                             org.junit.Assert.assertEquals(0.0, result, 0.0001);
                         }

}
