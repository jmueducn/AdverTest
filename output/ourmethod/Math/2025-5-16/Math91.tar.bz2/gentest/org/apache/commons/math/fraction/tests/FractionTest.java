package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.math.BigInteger;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                   public void testCompareTo_EqualFractions() {
                       Fraction fraction1 = new Fraction(1, 2);
                       Fraction fraction2 = new Fraction(1, 2);
                       assertEquals(0, fraction1.compareTo(fraction2));
                   }

 @Test
                   public void testCompareTo_SmallerFraction() {
                       Fraction smaller = new Fraction(1, 3);
                       Fraction larger = new Fraction(1, 2);
                       assertTrue(smaller.compareTo(larger) < 0);
                       assertTrue(larger.compareTo(smaller) > 0);
                   }

 @Test
                   public void testCompareTo_LargerFraction() {
                       Fraction smaller = new Fraction(1, 4);
                       Fraction larger = new Fraction(3, 4);
                       assertTrue(smaller.compareTo(larger) < 0);
                       assertTrue(larger.compareTo(smaller) > 0);
                   }

 @Test
                   public void testCompareTo_NegativeFractions() {
                       Fraction negative = new Fraction(-1, 2);
                       Fraction positive = new Fraction(1, 2);
                       assertTrue(negative.compareTo(positive) < 0);
                       assertTrue(positive.compareTo(negative) > 0);
                   }

 @Test
                   public void testCompareTo_EquivalentFractions() {
                       Fraction fraction1 = new Fraction(2, 4);
                       Fraction fraction2 = new Fraction(1, 2);
                       assertEquals(0, fraction1.compareTo(fraction2));
                   }

 @Test
                   public void testCompareTo_WithStaticConstants() {
                       Fraction half = new Fraction(1, 2);
                       assertTrue(Fraction.ZERO.compareTo(half) < 0);
                       assertTrue(Fraction.ONE.compareTo(half) > 0);
                       assertTrue(Fraction.MINUS_ONE.compareTo(half) < 0);
                       assertTrue(Fraction.TWO.compareTo(half) > 0);
                   }

 @Test
                   public void testCompareTo_WithLargeNumbers() {
                       Fraction large1 = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
                       Fraction large2 = new Fraction(Integer.MAX_VALUE - 2, Integer.MAX_VALUE);
                       assertTrue(large2.compareTo(large1) < 0);
                       assertTrue(large1.compareTo(large2) > 0);
                   }

 @Test
                   public void testCompareTo_WithNegativeDenominator() {
                       Fraction fraction1 = new Fraction(1, -2);  // internally becomes -1/2
                       Fraction fraction2 = new Fraction(-1, 2); // -1/2
                       assertEquals(0, fraction1.compareTo(fraction2));
                   }

 @Test
                   public void testCompareTo_WithZeroNumerator() {
                       Fraction zero1 = new Fraction(0, 1);
                       Fraction zero2 = new Fraction(0, 100);
                       Fraction positive = new Fraction(1, 2);
                       assertEquals(0, zero1.compareTo(zero2));
                       assertTrue(zero1.compareTo(positive) < 0);
                       assertTrue(positive.compareTo(zero1) > 0);
                   }

 @Test
                   public void testCompareTo_NullInput() {
                       thrown.expect(NullPointerException.class);
                       Fraction fraction = new Fraction(1, 2);
                       fraction.compareTo(null);
                   }

 @Test
                   public void testCompareTo_CrossProductOverflow() {
                       // These values would cause overflow if multiplied as ints but work as longs
                       Fraction fraction1 = new Fraction(Integer.MAX_VALUE, 1);
                       Fraction fraction2 = new Fraction(1, Integer.MAX_VALUE);
                       assertTrue(fraction1.compareTo(fraction2) > 0);
                       assertTrue(fraction2.compareTo(fraction1) < 0);
                   }

 @Test
                   public void testCompareTo_WithReducedFractions() {
                       Fraction reduced = Fraction.getReducedFraction(1, 2);
                       Fraction nonReduced = new Fraction(2, 4);
                       assertEquals(0, reduced.compareTo(nonReduced));
                   }

 @Test
           public void testAbsNeverReturnsNull() {
               // Test with positive numerator
               Fraction positiveFraction = new Fraction(3, 4);
               Fraction result = positiveFraction.abs();
               assertNotNull("abs() should not return null for positive fraction", result);
               assertEquals(positiveFraction, result); // Should return itself
               
               // Test with negative numerator
               Fraction negativeFraction = new Fraction(-3, 4);
               result = negativeFraction.abs();
               assertNotNull("abs() should not return null for negative fraction", result);
               assertNotSame(negativeFraction, result); // Should return new instance
               assertEquals(3, result.getNumerator()); // Verify it's the absolute value
               assertEquals(4, result.getDenominator());
               
               // Test with zero numerator (edge case)
               Fraction zeroFraction = new Fraction(0, 1);
               result = zeroFraction.abs();
               assertNotNull("abs() should not return null for zero fraction", result);
               assertEquals(zeroFraction, result); // Should return itself
           }

 @Test
          public void testAbsWithZeroNumerator() {
              // Create a fraction with numerator 0 (e.g. 0/1)
              Fraction zeroFraction = new Fraction(0, 1);
              
              // Call abs() and verify it returns the same instance
              Fraction result = zeroFraction.abs();
              
              // Verify it's the same instance (not negated)
              assertSame("For numerator 0, abs() should return same instance", zeroFraction, result);
              
              // Verify numerator is still 0
              assertEquals("Numerator should remain 0", 0, result.getNumerator());
              
              // Verify denominator is unchanged
              assertEquals("Denominator should remain unchanged", 1, result.getDenominator());
          }

 @Test
             public void testAbsDetectsMutant() {
                 // Test case 1: Positive numerator (5/1)
                 Fraction positive = new Fraction(5, 1);
                 Fraction resultPositive = positive.abs();
                 // Original: should return same fraction (5/1)
                 // Mutant: would return negated fraction (-5/1)
                 assertEquals(5, resultPositive.getNumerator());
                 assertEquals(1, resultPositive.getDenominator());
                 
                 // Test case 2: Negative numerator (-3/1)
                 Fraction negative = new Fraction(-3, 1);
                 Fraction resultNegative = negative.abs();
                 // Original: should return negated fraction (3/1)
                 // Mutant: would return same fraction (-3/1)
                 assertEquals(3, resultNegative.getNumerator());
                 assertEquals(1, resultNegative.getDenominator());
                 
                 // Test case 3: Zero numerator (0/1)
                 Fraction zero = new Fraction(0, 1);
                 Fraction resultZero = zero.abs();
                 // Both original and mutant should return same fraction (0/1)
                 assertEquals(0, resultZero.getNumerator());
                 assertEquals(1, resultZero.getDenominator());
             }

 @Test
            public void testAbsWithPositiveNumerator() {
                // Create a fraction with positive numerator
                Fraction fraction = new Fraction(3, 4);
                
                // Call abs() - should return same object
                Fraction result = fraction.abs();
                
                // Verify result is not null (would fail with mutant)
                assertNotNull("abs() should not return null for positive numerator", result);
                
                // Verify it's the same object (would fail with mutant)
                assertSame("abs() should return 'this' for positive numerator", fraction, result);
                
                // Verify numerator remains positive
                assertTrue("Numerator should remain positive", result.getNumerator() > 0);
            }

 @Test
            public void testAbsWithZeroNumerator1() {
                // Create a fraction with zero numerator (edge case)
                Fraction fraction = new Fraction(0, 1);
                
                // Call abs()
                Fraction result = fraction.abs();
                
                // Verify result is not null
                assertNotNull("abs() should not return null for zero numerator", result);
                
                // Verify it's the same object
                assertSame("abs() should return 'this' for zero numerator", fraction, result);
                
                // Verify numerator remains zero
                assertEquals("Numerator should remain zero", 0, result.getNumerator());
            }

 @Test
           public void testAbsWithPositiveNumerator1() {
               // Create a fraction with positive numerator
               Fraction fraction = new Fraction(3, 4);
               
               // Call abs() and verify it returns the same object (since numerator is positive)
               Fraction result = fraction.abs();
               assertSame("abs() should return same object for positive numerator", fraction, result);
           }

 @Test
           public void testAbsWithNegativeNumerator() {
               // Create a fraction with negative numerator
               Fraction fraction = new Fraction(-3, 4);
               
               // Call abs() and verify it returns a different object (the negated version)
               Fraction result = fraction.abs();
               assertNotSame("abs() should return different object for negative numerator", fraction, result);
               assertEquals("Numerator should be positive", 3, result.getNumerator());
               assertEquals("Denominator should remain unchanged", 4, result.getDenominator());
           }

 @Test(expected = RuntimeException.class)
           public void testAbsMutantThrowsException() {
               // This test will fail on the original code (which is good - it means we caught the mutant)
               // and pass on the mutated code (which is bad - but we want to detect this)
               Fraction fraction = new Fraction(1, 2);
               fraction.abs(); // This should throw RuntimeException in the mutated version
           }

 @Test
      public void testAbsWithZeroNumerator2() {
          // Create a fraction with numerator = 0 (should return itself for abs)
          Fraction zeroFraction = new Fraction(0, 1);
          
          // Call abs() and verify it returns the same instance
          Fraction result = zeroFraction.abs();
          
          // For original: should return same instance (numerator >= 0 case)
          // For mutant: would return negated version (numerator != 0 case)
          assertSame("abs() should return same instance for zero numerator", 
                    zeroFraction, result);
          
          // Additional verification that numerator is indeed 0
          assertEquals(0, result.getNumerator());
          assertEquals(1, result.getDenominator());
      }

 @Test
         public void testAbsWithNegativeNumerator1() {
             // Create a fraction with negative numerator
             Fraction negativeFraction = new Fraction(-3, 4);
             
             // Call abs() - original should negate, mutant will return same
             Fraction result = negativeFraction.abs();
             
             // Verify numerator is positive (should be 3 if negated, -3 if mutant)
             assertEquals("Numerator should be positive after abs()", 
                          3, result.getNumerator());
             
             // Verify denominator remains unchanged
             assertEquals(4, result.getDenominator());
         }

 @Test
         public void testAbsWithPositiveNumerator2() {
             // Create a fraction with positive numerator
             Fraction positiveFraction = new Fraction(3, 4);
             
             // Call abs() - both original and mutant should return same
             Fraction result = positiveFraction.abs();
             
             // Verify numerator remains same
             assertEquals(3, result.getNumerator());
             
             // Verify denominator remains unchanged
             assertEquals(4, result.getDenominator());
             
             // Verify it returns the same object (not a new instance)
             assertSame("Should return same instance for positive numerator",
                       positiveFraction, result);
         }

 @Test
    public void testAbsShouldNeverReturnNull() {
        // Test with positive numerator
        Fraction positiveFraction = new Fraction(3, 4);
        Fraction result = positiveFraction.abs();
        assertNotNull("Absolute value of positive fraction should not be null", result);
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
        
        // Test with negative numerator
        Fraction negativeFraction = new Fraction(-3, 4);
        result = negativeFraction.abs();
        assertNotNull("Absolute value of negative fraction should not be null", result);
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
        
        // Test with zero numerator
        Fraction zeroFraction = new Fraction(0, 1);
        result = zeroFraction.abs();
        assertNotNull("Absolute value of zero fraction should not be null", result);
        assertEquals(0, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

 @Test
       public void testAbs() {
           // Test case for positive numerator
           Fraction positive = new Fraction(3, 4);
           Fraction resultPositive = positive.abs();
           assertSame("Positive fraction should return itself", positive, resultPositive);
           
           // Test case for negative numerator
           Fraction negative = new Fraction(-3, 4);
           Fraction resultNegative = negative.abs();
           assertNotSame("Negative fraction should return negated version", negative, resultNegative);
           assertEquals("Numerator should be positive", 3, resultNegative.getNumerator());
           assertEquals("Denominator should remain same", 4, resultNegative.getDenominator());
           
           // Critical test case for numerator = 0 to catch the mutant
           Fraction zero = new Fraction(0, 1);
           Fraction resultZero = zero.abs();
           assertSame("Zero fraction should return itself", zero, resultZero);
           assertEquals("Numerator should remain 0", 0, resultZero.getNumerator());
       }

 @Test
  public void testAbsDetectsMutant1() {
      // Test with negative numerator - should return negated fraction
      Fraction negativeFraction = new Fraction(-3, 4);
      Fraction absNegative = negativeFraction.abs();
      
      // Verify the result is not the same object (since it should be negated)
      assertNotSame("For negative numerator, abs() should return a new negated fraction", 
                   negativeFraction, absNegative);
      
      // Verify the numerator is positive
      assertTrue("Absolute value should have positive numerator", 
                absNegative.getNumerator() > 0);
      
      // Test with positive numerator - should return same fraction
      Fraction positiveFraction = new Fraction(3, 4);
      Fraction absPositive = positiveFraction.abs();
      
      // Verify it returns the same object for positive numerator
      assertSame("For positive numerator, abs() should return same fraction", 
                positiveFraction, absPositive);
      
      // Test with zero numerator - should return same fraction
      Fraction zeroFraction = new Fraction(0, 1);
      Fraction absZero = zeroFraction.abs();
      assertSame("For zero numerator, abs() should return same fraction", 
                zeroFraction, absZero);
  }

 @Test
 public void testAbsDetectsNullReturnMutant() {
     // Test with positive numerator
     Fraction positiveFraction = new Fraction(3, 4);
     Fraction absPositive = positiveFraction.abs();
     assertNotNull("Absolute value of positive fraction should not be null", absPositive);
     assertEquals("Absolute value of positive fraction should equal itself", 
                 positiveFraction, absPositive);
     
     // Test with zero numerator
     Fraction zeroFraction = new Fraction(0, 1);
     Fraction absZero = zeroFraction.abs();
     assertNotNull("Absolute value of zero fraction should not be null", absZero);
     assertEquals("Absolute value of zero fraction should equal itself", 
                 zeroFraction, absZero);
     
     // Test with negative numerator (to verify original functionality still works)
     Fraction negativeFraction = new Fraction(-3, 4);
     Fraction absNegative = negativeFraction.abs();
     assertNotNull("Absolute value of negative fraction should not be null", absNegative);
     assertEquals("Absolute value of negative fraction should equal its negation", 
                 negativeFraction.negate(), absNegative);
 }

}
