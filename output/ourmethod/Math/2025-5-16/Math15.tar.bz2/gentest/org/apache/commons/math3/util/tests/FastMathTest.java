package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                      public void testPow_ZeroExponent() {
                                                                                                                                                                                                                                          // Any number to the power of 0 should be 1
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(0.0, 0.0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, 0.0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(-1.0, 0.0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, 0.0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 0.0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.NaN, 0.0), 1e-15);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_ZeroBase() {
                                                                                                                                                                                                                                          // Positive zero cases
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(0.0, -1.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(0.0, 1.0), 0.0);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Negative zero cases
                                                                                                                                                                                                                                          assertEquals(Double.NEGATIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(-0.0, -3.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(-0.0, org.apache.commons.math3.util.FastMath.pow(-0.0, 3.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(-0.0, -2.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(-0.0, 2.0), 0.0);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_InfinityBase() {
                                                                                                                                                                                                                                          // Positive infinity cases
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, 2.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, -2.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, 0.0), 0.0);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Negative infinity cases
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 2.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.NEGATIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 3.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, -2.0), 0.0);
                                                                                                                                                                                                                                          assertEquals(-0.0, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, -3.0), 0.0);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_NegativeBase() {
                                                                                                                                                                                                                                          // Negative base with integer exponent
                                                                                                                                                                                                                                          assertEquals(4.0, org.apache.commons.math3.util.FastMath.pow(-2.0, 2.0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(-8.0, org.apache.commons.math3.util.FastMath.pow(-2.0, 3.0), 1e-15);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Negative base with non-integer exponent should return NaN
                                                                                                                                                                                                                                          assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(-2.0, 2.5), 1e-15);
                                                                                                                                                                                                                                          assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(-1.0, Double.NaN), 1e-15);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_NaNExponent() {
                                                                                                                                                                                                                                          // NaN exponent should return NaN unless base is 1.0
                                                                                                                                                                                                                                          assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(2.0, Double.NaN), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(0.0, Double.NaN), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, Double.NaN), 0.0);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, Double.NaN), 0.0);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_ZeroExponent1() {
                                                                                                                                                                                                                                          // Any number to the power of 0 should be 1
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(0.0, 0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, 0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(-1.0, 0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.MAX_VALUE, 0), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.MIN_VALUE, 0), 1e-15);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_PositiveExponent() {
                                                                                                                                                                                                                                          // Positive exponents
                                                                                                                                                                                                                                          assertEquals(8.0, org.apache.commons.math3.util.FastMath.pow(2.0, 3), 0.0);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, 100), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.125, org.apache.commons.math3.util.FastMath.pow(2.0, -3), 1e-15);
                                                                                                                                                                                                                                          assertEquals(1e6, org.apache.commons.math3.util.FastMath.pow(10.0, 6), 0.0);
                                                                                                                                                                                                                                          assertEquals(1e-6, org.apache.commons.math3.util.FastMath.pow(10.0, -6), 1e-15);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_LargeExponents() {
                                                                                                                                                                                                                                          // Large exponents
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(2.0, 1024), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(0.5, 1024), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(2.0, -1024), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(0.5, -1024), 0.0);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_SpecialValues() {
                                                                                                                                                                                                                                          // Special values
                                                                                                                                                                                                                                          assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(Double.NaN, 1), 0.0);
                                                                                                                                                                                                                                          assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(Double.NaN, 0), 0.0); // Any number to power 0 is 1, even NaN
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, 2), 0.0);
                                                                                                                                                                                                                                          assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(Double.POSITIVE_INFINITY, -2), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 3), 0.0);
                                                                                                                                                                                                                                          assertEquals(Double.NEGATIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(Double.NEGATIVE_INFINITY, 1), 0.0);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_FractionalBase() {
                                                                                                                                                                                                                                          // Fractional bases
                                                                                                                                                                                                                                          assertEquals(0.25, org.apache.commons.math3.util.FastMath.pow(0.5, 2), 1e-15);
                                                                                                                                                                                                                                          assertEquals(0.7071067811865475, org.apache.commons.math3.util.FastMath.pow(0.5, 0.5), 1e-15);
                                                                                                                                                                                                                                          assertEquals(0.125, org.apache.commons.math3.util.FastMath.pow(0.5, 3), 1e-15);
                                                                                                                                                                                                                                          assertEquals(2.0, org.apache.commons.math3.util.FastMath.pow(0.5, -1), 1e-15);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_NegativeBase1() {
                                                                                                                                                                                                                                          // Negative bases with various exponents
                                                                                                                                                                                                                                          assertEquals(-8.0, org.apache.commons.math3.util.FastMath.pow(-2.0, 3), 1e-15);
                                                                                                                                                                                                                                          assertEquals(16.0, org.apache.commons.math3.util.FastMath.pow(-2.0, 4), 1e-15);
                                                                                                                                                                                                                                          assertEquals(-0.125, org.apache.commons.math3.util.FastMath.pow(-2.0, -3), 1e-15);
                                                                                                                                                                                                                                          assertEquals(0.0625, org.apache.commons.math3.util.FastMath.pow(-2.0, -4), 1e-15);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                      public void testPow_ExtremeValues() {
                                                                                                                                                                                                                                          // Extreme values
                                                                                                                                                                                                                                          org.junit.Assert.assertEquals(java.lang.Double.POSITIVE_INFINITY, 
                                                                                                                                                                                                                                              org.apache.commons.math3.util.FastMath.pow(1.0000001, Integer.MAX_VALUE), 0.0);
                                                                                                                                                                                                                                          org.junit.Assert.assertEquals(0.0, 
                                                                                                                                                                                                                                              org.apache.commons.math3.util.FastMath.pow(0.9999999, Integer.MAX_VALUE), 0.0);
                                                                                                                                                                                                                                          org.junit.Assert.assertEquals(java.lang.Double.POSITIVE_INFINITY, 
                                                                                                                                                                                                                                              org.apache.commons.math3.util.FastMath.pow(2.0, Integer.MAX_VALUE), 0.0);
                                                                                                                                                                                                                                          org.junit.Assert.assertEquals(0.0, 
                                                                                                                                                                                                                                              org.apache.commons.math3.util.FastMath.pow(0.5, Integer.MAX_VALUE), 0.0);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                        public void testPow_NaNBase() {
                                                                                                                            // NaN as base should return NaN
                                                                                                                            assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(Double.NaN, 1.0), 0.0);
                                                                                                                            assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(Double.NaN, -1.0), 0.0);
                                                                                                                            assertEquals(Double.NaN, org.apache.commons.math3.util.FastMath.pow(Double.NaN, 0.0), 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPow_NormalCases() {
                                                                                                                            // Typical cases
                                                                                                                            assertEquals(8.0, org.apache.commons.math3.util.FastMath.pow(2.0, 3.0), 0.0);
                                                                                                                            assertEquals(0.125, org.apache.commons.math3.util.FastMath.pow(2.0, -3.0), 0.0);
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, 100.0), 0.0);
                                                                                                                            assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(0.5, 1000.0), 0.0);
                                                                                                                            
                                                                                                                            // Edge of normal range
                                                                                                                            assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(2.0, 1024.0), 0.0);
                                                                                                                            assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(0.5, 1024.0), 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPow_SpecialCases() {
                                                                                                                            // Very large exponents
                                                                                                                            assertEquals(Double.POSITIVE_INFINITY, org.apache.commons.math3.util.FastMath.pow(1.0000001, 1e300), 0.0);
                                                                                                                            assertEquals(0.0, org.apache.commons.math3.util.FastMath.pow(0.9999999, 1e300), 0.0);
                                                                                                                            
                                                                                                                            // Very small exponents
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(2.0, 1e-300), 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPow_OneBase() {
                                                                                                                            // 1 to any power is 1
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, Double.POSITIVE_INFINITY), 1e-15);
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, Double.NEGATIVE_INFINITY), 1e-15);
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, Double.NaN), 1e-15);
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, 100.0), 1e-15);
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, -100.0), 1e-15);
                                                                                                                        }

    @Test
                                                                                                                        public void testPow_NegativeExponent() {
                                                                                                                            // Negative exponents
                                                                                                                            assertEquals(0.5, org.apache.commons.math3.util.FastMath.pow(2.0, -1), 1e-15);
                                                                                                                            assertEquals(0.25, org.apache.commons.math3.util.FastMath.pow(2.0, -2), 1e-15);
                                                                                                                            assertEquals(1.0, org.apache.commons.math3.util.FastMath.pow(1.0, -100), 0.0);
                                                                                                                            assertEquals(1e-6, org.apache.commons.math3.util.FastMath.pow(10.0, -6), 1e-15);
                                                                                                                        }

    @Test
                                                                                                                        public void testPow_Accuracy() {
                                                                                                                            // Test accuracy with known values for pow()
                                                                                                                            assertEquals(1.0, FastMath.pow(2.0, 0.0), 1e-15); // any number^0 = 1
                                                                                                                            assertEquals(4.0, FastMath.pow(2.0, 2.0), 1e-15); // 2^2 = 4
                                                                                                                            assertEquals(8.0, FastMath.pow(2.0, 3.0), 1e-15); // 2^3 = 8
                                                                                                                            assertEquals(9.0, FastMath.pow(3.0, 2.0), 1e-15); // 3^2 = 9
                                                                                                                            assertEquals(1.4142135623730951, FastMath.pow(2.0, 0.5), 1e-15); // 2^0.5 = sqrt(2)
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithZeroXShouldNotUseNegativeXLogic() {
                                                                                                                            // Test with x=0 (which should be handled by special case, not negative case)
                                                                                                                            // y is positive non-integer
                                                                                                                            assertEquals(0.0, FastMath.pow(0.0, 0.5), 0.0);
                                                                                                                            
                                                                                                                            // y is positive integer
                                                                                                                            assertEquals(0.0, FastMath.pow(0.0, 2.0), 0.0);
                                                                                                                            
                                                                                                                            // y is negative non-integer
                                                                                                                            assertEquals(java.lang.Double.POSITIVE_INFINITY, FastMath.pow(0.0, -0.5), 0.0);
                                                                                                                            
                                                                                                                            // y is negative odd integer (should still be infinity, not use negative x logic)
                                                                                                                            assertEquals(java.lang.Double.POSITIVE_INFINITY, FastMath.pow(0.0, -3.0), 0.0);
                                                                                                                            
                                                                                                                            // y is negative even integer (should still be infinity, not use negative x logic)
                                                                                                                            assertEquals(java.lang.Double.POSITIVE_INFINITY, FastMath.pow(0.0, -4.0), 0.0);
                                                                                                                            
                                                                                                                            // y is zero (special case)
                                                                                                                            assertEquals(1.0, FastMath.pow(0.0, 0.0), 0.0);
                                                                                                                            
                                                                                                                            // Negative zero cases (should be handled by earlier zero logic)
                                                                                                                            assertEquals(java.lang.Double.POSITIVE_INFINITY, FastMath.pow(-0.0, -2.0), 0.0);
                                                                                                                            assertEquals(-0.0, FastMath.pow(-0.0, 3.0), 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithZeroExponentShouldNotInvertBase() {
                                                                                                                            // Test with positive base
                                                                                                                            double positiveBase = 5.0;
                                                                                                                            assertEquals(1.0, FastMath.pow(positiveBase, 0), 0.0);
                                                                                                                            
                                                                                                                            // Test with negative base
                                                                                                                            double negativeBase = -3.0;
                                                                                                                            assertEquals(1.0, FastMath.pow(negativeBase, 0), 0.0);
                                                                                                                            
                                                                                                                            // Test with zero base
                                                                                                                            assertEquals(1.0, FastMath.pow(0.0, 0), 0.0);
                                                                                                                            
                                                                                                                            // Test with fractional base
                                                                                                                            double fractionalBase = 0.5;
                                                                                                                            assertEquals(1.0, FastMath.pow(fractionalBase, 0), 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowNegativeBaseWithExactTwoPower() {
                                                                                                                            // Setup
                                                                                                                            double x = -2.0;
                                                                                                                            double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                                                                                            double y = TWO_POWER_53; // Exactly 2^53
                                                                                                                            
                                                                                                                            // The original code should handle this by returning pow(-x, y)
                                                                                                                            // The mutated code will miss this case and proceed to check if y is integer
                                                                                                                            
                                                                                                                            // Expected result is same as pow(2.0, 2^53)
                                                                                                                            double expected = Math.pow(2.0, TWO_POWER_53);
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            double result = Math.pow(x, y);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals("Power of negative base with y=TWO_POWER_53 should equal pow(-x,y)", 
                                                                                                                                       expected, result, 0.0);
                                                                                                                            
                                                                                                                            // Additional check for the exact case that would fail with mutation
                                                                                                                            double yJustBelow = Math.nextAfter(TWO_POWER_53, Double.NEGATIVE_INFINITY);
                                                                                                                            double resultBelow = Math.pow(x, yJustBelow);
                                                                                                                            assertNotEquals("Results should differ between y=TWO_POWER_53 and y just below",
                                                                                                                                           result, resultBelow, 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowBoundaryAtTwoPower() {
                                                                                                                            // Define constants needed for the test
                                                                                                                            final double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                                                                                            
                                                                                                                            // Test exactly at the boundary (TWO_POWER_53)
                                                                                                                            double boundary = TWO_POWER_53;
                                                                                                                            double result1 = FastMath.pow(2.0, (int)boundary);
                                                                                                                            
                                                                                                                            // Test just above the boundary
                                                                                                                            double aboveBoundary = boundary + 1;
                                                                                                                            double result2 = FastMath.pow(2.0, (int)aboveBoundary);
                                                                                                                            
                                                                                                                            // Test just below the boundary
                                                                                                                            double belowBoundary = boundary - 1;
                                                                                                                            double result3 = FastMath.pow(2.0, (int)belowBoundary);
                                                                                                                            
                                                                                                                            // The original and mutated code should differ at exact boundary
                                                                                                                            // Verify all results are finite numbers (not NaN or infinite)
                                                                                                                            assertFalse(Double.isNaN(result1));
                                                                                                                            assertFalse(Double.isInfinite(result1));
                                                                                                                            assertFalse(Double.isNaN(result2));
                                                                                                                            assertFalse(Double.isInfinite(result2));
                                                                                                                            assertFalse(Double.isNaN(result3));
                                                                                                                            assertFalse(Double.isInfinite(result3));
                                                                                                                            
                                                                                                                            // Additional verification that boundary case is handled correctly
                                                                                                                            // The exact value might be hard to predict, but we can verify it's reasonable
                                                                                                                            assertTrue(result1 > 0);
                                                                                                                            
                                                                                                                            // The key assertion that would catch the mutant:
                                                                                                                            // The result at exact boundary should be different from normal case
                                                                                                                            // (implementation detail might vary, but this is the general approach)
                                                                                                                            assertNotEquals(result2, result1, 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowNegativeXWithLargeY() {
                                                                                                                            // Define the constant locally
                                                                                                                            final double TWO_POWER_53 = 9007199254740992.0;
                                                                                                                            
                                                                                                                            // Test with negative x and very large positive y
                                                                                                                            double x = -2.0;
                                                                                                                            double largePosY = TWO_POWER_53 + 1; // TWO_POWER_53 + 1
                                                                                                                            double result1 = FastMath.pow(x, largePosY);
                                                                                                                            // Should use pow(-x,y) path in original code
                                                                                                                            assertEquals(Math.pow(-x, largePosY), result1, 0.0);
                                                                                                                            
                                                                                                                            // Test with negative x and very large negative y
                                                                                                                            double largeNegY = -TWO_POWER_53 - 1; // -TWO_POWER_53 - 1
                                                                                                                            double result2 = FastMath.pow(x, largeNegY);
                                                                                                                            // Should use pow(-x,y) path in original code
                                                                                                                            assertEquals(Math.pow(-x, largeNegY), result2, 0.0);
                                                                                                                            
                                                                                                                            // Test with negative x and y between -TWO_POWER_53 and TWO_POWER_53
                                                                                                                            double mediumY = TWO_POWER_53 - 1; // TWO_POWER_53 - 1
                                                                                                                            double result3 = FastMath.pow(x, mediumY);
                                                                                                                            // Should use different path since y is not extremely large
                                                                                                                            assertTrue(Double.isNaN(result3) || 
                                                                                                                                      result3 == -Math.pow(-x, mediumY) || 
                                                                                                                                      result3 == Math.pow(-x, mediumY));
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithLargeExponents() {
                                                                                                                            // Test with very large positive exponent
                                                                                                                            double base = 1.5;
                                                                                                                            int largePosExponent = (int)(9007199254740992L + 1); // 2^53 + 1
                                                                                                                            double resultPos = FastMath.pow(base, largePosExponent);
                                                                                                                            // Should not be infinity (original handles large exponents properly)
                                                                                                                            assertFalse(Double.isInfinite(resultPos));
                                                                                                                            
                                                                                                                            // Test with very large negative exponent
                                                                                                                            int largeNegExponent = (int)(-9007199254740992L - 1); // -2^53 - 1
                                                                                                                            double resultNeg = FastMath.pow(base, largeNegExponent);
                                                                                                                            // Should not be zero (original handles large negative exponents properly)
                                                                                                                            assertTrue(resultNeg != 0.0);
                                                                                                                            
                                                                                                                            // Test with exponent exactly at boundary
                                                                                                                            int boundaryExponent = (int)9007199254740992L; // 2^53
                                                                                                                            double resultBoundary = FastMath.pow(base, boundaryExponent);
                                                                                                                            assertTrue(resultBoundary > 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithLargeNegativeExponent() {
                                                                                                                            // Setup
                                                                                                                            double x = -2.0;  // Negative base
                                                                                                                            // Calculate 2^53 ourselves since we can't access the private constant
                                                                                                                            double twoPower53 = Math.pow(2, 53);
                                                                                                                            double y = -twoPower53 - 1;  // Very large negative exponent
                                                                                                                            
                                                                                                                            // The original code would handle this case by calling pow(-x, y)
                                                                                                                            // The mutated code would miss this case since it only checks y >= TWO_POWER_53
                                                                                                                            
                                                                                                                            // Expected behavior: should return same as pow(2.0, -9.007199254740992E15)
                                                                                                                            // Since -x becomes positive, and y is very large negative, result should be 0.0
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            double result = FastMath.pow(x, y);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals(0.0, result, 0.0);
                                                                                                                            
                                                                                                                            // Additional verification with positive x to confirm expected behavior
                                                                                                                            double positiveXResult = FastMath.pow(-x, y);
                                                                                                                            assertEquals(positiveXResult, result, 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithLargeNegativeExponent1() {
                                                                                                                            // Test with a value just below -TWO_POWER_53
                                                                                                                            double base = 2.0;
                                                                                                                            // TWO_POWER_53 is 2^53 = 9007199254740992
                                                                                                                            long twoPower53 = 9007199254740992L;
                                                                                                                            int exponent = (int)(-twoPower53 - 1);
                                                                                                                            
                                                                                                                            // The original should handle this correctly, while mutant would fail
                                                                                                                            double expected = Math.pow(base, exponent);
                                                                                                                            double actual = FastMath.pow(base, exponent);
                                                                                                                            
                                                                                                                            // We use a delta because of floating point precision
                                                                                                                            assertEquals("Power with large negative exponent", expected, actual, 1e-10);
                                                                                                                            
                                                                                                                            // Test with a value just above -TWO_POWER_53
                                                                                                                            exponent = (int)(-twoPower53 + 1);
                                                                                                                            expected = Math.pow(base, exponent);
                                                                                                                            actual = FastMath.pow(base, exponent);
                                                                                                                            assertEquals("Power with exponent near -TWO_POWER_53", expected, actual, 1e-10);
                                                                                                                            
                                                                                                                            // Test with a value above TWO_POWER_53 (both should handle the same)
                                                                                                                            exponent = (int)(twoPower53 + 1);
                                                                                                                            expected = Math.pow(base, exponent);
                                                                                                                            actual = FastMath.pow(base, exponent);
                                                                                                                            assertEquals("Power with large positive exponent", expected, actual, 1e-10);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithLargePositiveY() {
                                                                                                                            // Define constants needed for the test
                                                                                                                            final double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                                                                                            
                                                                                                                            // Setup
                                                                                                                            double x = -2.0;  // Negative to trigger the branch
                                                                                                                            double y = TWO_POWER_53 + 1;  // TWO_POWER_53 + 1 (2^53 + 1)
                                                                                                                            
                                                                                                                            // Test - this should detect the mutant
                                                                                                                            double result = FastMath.pow(x, y);
                                                                                                                            
                                                                                                                            // Verify the behavior
                                                                                                                            // Original code would compute pow(-x, y) because y >= TWO_POWER_53
                                                                                                                            // Mutant would compute different path because it doesn't check y >= TWO_POWER_53
                                                                                                                            double expected = FastMath.pow(-x, y);  // What original code should return
                                                                                                                            assertEquals("Large positive y should be handled specially", expected, result, 0.0);
                                                                                                                            
                                                                                                                            // Additional verification - check that it's not following the non-special path
                                                                                                                            // If mutant is present, result would be different
                                                                                                                            double mutantResultIfPresent = -FastMath.pow(-x, y);  // What mutant might return
                                                                                                                            assertNotEquals("Should not follow the non-special path", mutantResultIfPresent, result, 0.0);
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithLargePositiveExponent() {
                                                                                                                            // Test with a base and exponent where exponent > TWO_POWER_53
                                                                                                                            double base = 1.5;
                                                                                                                            // TWO_POWER_53 is 2^53 = 9007199254740992
                                                                                                                            final long TWO_POWER_53 = 9007199254740992L;
                                                                                                                            int largeExponent = (int)TWO_POWER_53 + 1;
                                                                                                                            
                                                                                                                            // Calculate expected value using Math.pow as reference
                                                                                                                            double expected = Math.pow(base, largeExponent);
                                                                                                                            
                                                                                                                            // The original method should handle large exponents specially
                                                                                                                            // The mutant would fail to handle large positive exponents specially
                                                                                                                            double actual = org.apache.commons.math3.util.FastMath.pow(base, largeExponent);
                                                                                                                            
                                                                                                                            // Verify the result is correct (or at least consistent with Math.pow)
                                                                                                                            assertEquals("Power calculation with large positive exponent failed", 
                                                                                                                                       expected, actual, 1e-10 * Math.abs(expected));
                                                                                                                            
                                                                                                                            // Also test with exponent exactly at TWO_POWER_53 boundary
                                                                                                                            int boundaryExponent = (int)TWO_POWER_53;
                                                                                                                            double boundaryExpected = Math.pow(base, boundaryExponent);
                                                                                                                            double boundaryActual = org.apache.commons.math3.util.FastMath.pow(base, boundaryExponent);
                                                                                                                            assertEquals("Power calculation at TWO_POWER_53 boundary failed",
                                                                                                                                       boundaryExpected, boundaryActual, 1e-10 * Math.abs(boundaryExpected));
                                                                                                                        }

    @Test
                                                                                                                        public void testPowWithNegativeXAndLargeY() {
                                                                                                                            // Test with x = -2 and y = TWO_POWER_53 (2^53)
                                                                                                                            // This should trigger the special case handling in original code
                                                                                                                            double x = -2.0;
                                                                                                                            double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                                                                                            double y = TWO_POWER_53;
                                                                                                                            
                                                                                                                            // Original behavior: should return same as pow(2, 2^53) because |y| >= TWO_POWER_53
                                                                                                                            // Mutant behavior: would try to handle negative x differently since condition is false
                                                                                                                            double result = Math.pow(x, y);
                                                                                                                            
                                                                                                                            // Verify result matches pow(2, 2^53) which is what original code should return
                                                                                                                            double expected = Math.pow(2.0, y);
                                                                                                                            assertEquals(expected, result, 0.0);
                                                                                                                            
                                                                                                                            // Also test with negative y of same magnitude
                                                                                                                            y = -TWO_POWER_53;
                                                                                                                            result = Math.pow(x, y);
                                                                                                                            expected = Math.pow(2.0, y);
                                                                                                                            assertEquals(expected, result, 0.0);
                                                                                                                        }

    @Test
                                                                                                                    public void testPow_InfinityExponent() {
                                                                                                                        // Positive infinity exponent
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, Double.POSITIVE_INFINITY), 0.0);
                                                                                                                        assertEquals(0.0, FastMath.pow(0.5, Double.POSITIVE_INFINITY), 0.0);
                                                                                                                        assertEquals(Double.NaN, FastMath.pow(1.0, Double.POSITIVE_INFINITY), 0.0);
                                                                                                                        
                                                                                                                        // Negative infinity exponent
                                                                                                                        assertEquals(0.0, FastMath.pow(2.0, Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.5, Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                        assertEquals(Double.NaN, FastMath.pow(1.0, Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                    }

    @Test
                                                                                                                    public void testPowWithNegativeBase() {
                                                                                                                        // Test with negative base and odd exponent
                                                                                                                        double negativeBaseOddExp = FastMath.pow(-2.0, 3);
                                                                                                                        assertEquals(-8.0, negativeBaseOddExp, 1e-10);
                                                                                                                        assertTrue(negativeBaseOddExp < 0); // Should be negative
                                                                                                                        
                                                                                                                        // Test with negative base and even exponent
                                                                                                                        double negativeBaseEvenExp = FastMath.pow(-2.0, 4);
                                                                                                                        assertEquals(16.0, negativeBaseEvenExp, 1e-10);
                                                                                                                        assertTrue(negativeBaseEvenExp > 0); // Should be positive
                                                                                                                        
                                                                                                                        // Test with negative base and fractional exponent
                                                                                                                        // (should handle properly or potentially throw exception)
                                                                                                                        try {
                                                                                                                            double negativeBaseFracExp = FastMath.pow(-2.0, 3.5);
                                                                                                                            // If it doesn't throw, verify NaN or proper handling
                                                                                                                            assertTrue(Double.isNaN(negativeBaseFracExp) || 
                                                                                                                                      Math.abs(negativeBaseFracExp - Math.pow(-2.0, 3.5)) < 1e-10);
                                                                                                                        } catch (ArithmeticException e) {
                                                                                                                            // Expected for some fractional exponents with negative base
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test edge case with exponent 0
                                                                                                                        double negativeBaseZeroExp = FastMath.pow(-2.0, 0);
                                                                                                                        assertEquals(1.0, negativeBaseZeroExp, 0.0);
                                                                                                                    }

    @Test
                                                                                                               public void testPowNegativeXWithLargeY1() {
                                                                                                                   // Define our own TWO_POWER_53 constant
                                                                                                                   final double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                                                                                   
                                                                                                                   // Test with negative x and large positive y (>= TWO_POWER_53)
                                                                                                                   double x = -2.0;
                                                                                                                   double y = TWO_POWER_53;
                                                                                                                   double result = FastMath.pow(x, y);
                                                                                                                   // For even y, (-x)^y should be positive
                                                                                                                   assertEquals(Math.pow(-x, y), result, 0.0);
                                                                                                                   
                                                                                                                   // Test with negative x and large negative y (<= -TWO_POWER_53)
                                                                                                                   y = -TWO_POWER_53;
                                                                                                                   result = FastMath.pow(x, y);
                                                                                                                   // For even y, (-x)^y should be positive
                                                                                                                   assertEquals(Math.pow(-x, y), result, 0.0);
                                                                                                                   
                                                                                                                   // Test with negative x and large odd y
                                                                                                                   x = -3.0;
                                                                                                                   y = TWO_POWER_53 + 1; // odd y
                                                                                                                   result = FastMath.pow(x, y);
                                                                                                                   // For odd y, (-x)^y should be negative
                                                                                                                   assertEquals(Math.pow(-x, y), -result, 0.0);
                                                                                                                   
                                                                                                                   // Test with negative x and large negative odd y
                                                                                                                   y = -TWO_POWER_53 - 1;
                                                                                                                   result = FastMath.pow(x, y);
                                                                                                                   // For odd y, (-x)^y should be negative
                                                                                                                   assertEquals(Math.pow(-x, y), -result, 0.0);
                                                                                                               }

    @Test
                                                                                                           public void testPowNegativeBaseDetectsMutant() {
                                                                                                               // Test with negative base and positive exponent
                                                                                                               double x = -2.0;
                                                                                                               int y = 3;
                                                                                                               double originalResult = FastMath.pow(x, y); // Should be -8.0
                                                                                                               double mutantResult = 1.0 / FastMath.pow(x, -y); // What mutant would return
                                                                                                               
                                                                                                               // Verify original behavior is correct and different from mutant
                                                                                                               assertEquals(-8.0, FastMath.pow(x, y), 1e-15);
                                                                                                               assertNotEquals(mutantResult, FastMath.pow(x, y), 1e-15);
                                                                                                               
                                                                                                               // Test with negative base and negative exponent
                                                                                                               y = -3;
                                                                                                               originalResult = FastMath.pow(x, y); // Should be -0.125
                                                                                                               mutantResult = FastMath.pow(x, -y); // What mutant would return (would be -8.0)
                                                                                                               
                                                                                                               // Verify original behavior is correct and different from mutant
                                                                                                               assertEquals(-0.125, FastMath.pow(x, y), 1e-15);
                                                                                                               assertNotEquals(mutantResult, FastMath.pow(x, y), 1e-15);
                                                                                                               
                                                                                                               // Additional test with fractional result
                                                                                                               x = -3.0;
                                                                                                               y = 2;
                                                                                                               assertEquals(9.0, FastMath.pow(x, y), 1e-15); // (-3)^2 = 9
                                                                                                               assertNotEquals(1.0/9.0, FastMath.pow(x, y), 1e-15); // Mutant would return 1/9
                                                                                                           }

    @Test
                                                                                                          public void testPowNegativeXLargeY() {
                                                                                                              // Setup
                                                                                                              double x = -2.0;
                                                                                                              double twoPower53 = 9007199254740992.0; // 2^53
                                                                                                              double y = twoPower53;
                                                                                                              
                                                                                                              // Expected behavior: should calculate pow(-x, y) = pow(2.0, 9.007199254740992E15)
                                                                                                              // Mutated behavior would calculate pow(-x, -y) = pow(2.0, -9.007199254740992E15)
                                                                                                              
                                                                                                              // Action
                                                                                                              double result = FastMath.pow(x, y);
                                                                                                              
                                                                                                              // Verification
                                                                                                              // Original should return a very large positive number (2^large positive)
                                                                                                              // Mutant would return a very small positive number (2^large negative)
                                                                                                              assertTrue("Result should be positive infinity for large exponent", 
                                                                                                                         Double.isInfinite(result) && result > 0);
                                                                                                              
                                                                                                              // Additional verification - compare with Math.pow for the expected calculation
                                                                                                              double expected = Math.pow(-x, y);
                                                                                                              assertEquals(expected, result, 0.0);
                                                                                                              
                                                                                                              // Also test negative large y
                                                                                                              double yNeg = -twoPower53;
                                                                                                              double resultNeg = FastMath.pow(x, yNeg);
                                                                                                              double expectedNeg = Math.pow(-x, yNeg);
                                                                                                              assertEquals(expectedNeg, resultNeg, 0.0);
                                                                                                          }

    @Test
                                                                                                          public void testPowWithNegativeBaseDetectsMutant() {
                                                                                                              // Test with negative base and odd exponent
                                                                                                              double result1 = FastMath.pow(-2.0, 3);
                                                                                                              assertNotEquals("Negative base with odd exponent should not return 0", 0.0, result1, 0.0001);
                                                                                                              assertEquals("pow(-2,3) should be -8", -8.0, result1, 0.0001);
                                                                                                              
                                                                                                              // Test with negative base and even exponent
                                                                                                              double result2 = FastMath.pow(-3.0, 2);
                                                                                                              assertNotEquals("Negative base with even exponent should not return 0", 0.0, result2, 0.0001);
                                                                                                              assertEquals("pow(-3,2) should be 9", 9.0, result2, 0.0001);
                                                                                                              
                                                                                                              // Test with negative base and negative exponent
                                                                                                              double result3 = FastMath.pow(-4.0, -2);
                                                                                                              assertNotEquals("Negative base with negative exponent should not return 0", 0.0, result3, 0.0001);
                                                                                                              assertEquals("pow(-4,-2) should be 0.0625", 0.0625, result3, 0.0001);
                                                                                                              
                                                                                                              // Test edge case with -1 base
                                                                                                              double result4 = FastMath.pow(-1.0, 100);
                                                                                                              assertNotEquals("pow(-1,100) should not return 0", 0.0, result4, 0.0001);
                                                                                                              assertEquals("pow(-1,100) should be 1", 1.0, result4, 0.0001);
                                                                                                              
                                                                                                              // Test edge case with -1 base and odd exponent
                                                                                                              double result5 = FastMath.pow(-1.0, 101);
                                                                                                              assertNotEquals("pow(-1,101) should not return 0", 0.0, result5, 0.0001);
                                                                                                              assertEquals("pow(-1,101) should be -1", -1.0, result5, 0.0001);
                                                                                                          }

    @Test
                                                                                                     public void testPowNegativeXLargeY1() {
                                                                                                         // Setup
                                                                                                         double negativeX = -2.0;
                                                                                                         double largeY = 9007199254740992.0; // 2^53
                                                                                                         
                                                                                                         // Expected behavior - should return pow(2.0, 2^53)
                                                                                                         double expected = FastMath.pow(-negativeX, largeY);
                                                                                                         
                                                                                                         // Test
                                                                                                         double actual = FastMath.pow(negativeX, largeY);
                                                                                                         
                                                                                                         // Verify - mutant would return 0 instead of expected value
                                                                                                         assertEquals("Power of negative x with large y should be calculated properly", 
                                                                                                                    expected, actual, 0.0);
                                                                                                         
                                                                                                         // Additional test case with negative large y
                                                                                                         double negativeLargeY = -9007199254740992.0;
                                                                                                         expected = FastMath.pow(-negativeX, negativeLargeY);
                                                                                                         actual = FastMath.pow(negativeX, negativeLargeY);
                                                                                                         assertEquals("Power of negative x with negative large y should be calculated properly",
                                                                                                                    expected, actual, 0.0);
                                                                                                     }

    @Test
                                                                                                 public void testPowNegativeXWithEvenIntegerY() {
                                                                                                     // Test negative x with even integer y
                                                                                                     double x = -2.0;
                                                                                                     double y = 4.0; // even integer
                                                                                                     
                                                                                                     // Original behavior: should return positive result (pow(-x,y))
                                                                                                     double result = FastMath.pow(x, y);
                                                                                                     assertEquals(16.0, result, 0.0001); // (-2)^4 = 16
                                                                                                     
                                                                                                     // Test negative x with odd integer y
                                                                                                     y = 3.0; // odd integer
                                                                                                     
                                                                                                     // Original behavior: should return negative result (-pow(-x,y))
                                                                                                     result = FastMath.pow(x, y);
                                                                                                     assertEquals(-8.0, result, 0.0001); // (-2)^3 = -8
                                                                                                     
                                                                                                     // Test edge case with large even integer y
                                                                                                     y = 100.0; // large even integer
                                                                                                     double expected = FastMath.pow(-x, y);
                                                                                                     result = FastMath.pow(x, y);
                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                     
                                                                                                     // Test edge case with large odd integer y
                                                                                                     y = 101.0; // large odd integer
                                                                                                     expected = -FastMath.pow(-x, y);
                                                                                                     result = FastMath.pow(x, y);
                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                 }

    @Test
                                                                                                     public void testPowWithEvenAndOddExponents() {
                                                                                                         // Test with even exponent (4)
                                                                                                         double base = 2.0;
                                                                                                         int evenExp = 4;
                                                                                                         double expectedEvenResult = 16.0; // 2^4 = 16
                                                                                                         double actualEvenResult = FastMath.pow(base, evenExp);
                                                                                                         assertEquals("Even exponent calculation failed", 
                                                                                                                     expectedEvenResult, actualEvenResult, 1e-15);
                                                                                                         
                                                                                                         // Test with odd exponent (3)
                                                                                                         int oddExp = 3;
                                                                                                         double expectedOddResult = 8.0; // 2^3 = 8
                                                                                                         double actualOddResult = FastMath.pow(base, oddExp);
                                                                                                         assertEquals("Odd exponent calculation failed",
                                                                                                                     expectedOddResult, actualOddResult, 1e-15);
                                                                                                         
                                                                                                         // Test with larger odd exponent to ensure computation path is correct
                                                                                                         int largeOddExp = 17;
                                                                                                         double expectedLargeOddResult = 131072.0; // 2^17 = 131072
                                                                                                         double actualLargeOddResult = FastMath.pow(base, largeOddExp);
                                                                                                         assertEquals("Large odd exponent calculation failed",
                                                                                                                     expectedLargeOddResult, actualLargeOddResult, 1e-10);
                                                                                                         
                                                                                                         // Test with larger even exponent
                                                                                                         int largeEvenExp = 16;
                                                                                                         double expectedLargeEvenResult = 65536.0; // 2^16 = 65536
                                                                                                         double actualLargeEvenResult = FastMath.pow(base, largeEvenExp);
                                                                                                         assertEquals("Large even exponent calculation failed",
                                                                                                                     expectedLargeEvenResult, actualLargeEvenResult, 1e-10);
                                                                                                     }

    @Test
                                                                                               public void testPowNegativeXWithExactlyTwoPower53Y() {
                                                                                                   // Setup
                                                                                                   double x = -2.0;
                                                                                                   double y = 9007199254740992.0; // Exactly 2^53
                                                                                                   
                                                                                                   // The original code should handle this via pow(-x,y) path
                                                                                                   // The mutant will incorrectly try to handle it via integer check path
                                                                                                   
                                                                                                   // Execute
                                                                                                   double result = FastMath.pow(x, y);
                                                                                                   
                                                                                                   // Verify - should be same as pow(2.0, 2^53)
                                                                                                   double expected = FastMath.pow(-x, y);
                                                                                                   assertEquals(expected, result, 0.0);
                                                                                                   
                                                                                                   // Additional verification that we're testing the right case
                                                                                                   // y should be exactly equal to 2^53
                                                                                                   assertEquals(9007199254740992.0, y, 0.0);
                                                                                                   // y should be exactly representable as a long
                                                                                                   assertEquals((long)y, y, 0.0);
                                                                                               }

    @Test
                                                                                               public void testPowBoundaryConditions() {
                                                                                                   // Test with value exactly equal to TWO_POWER_53 (2^53)
                                                                                                   double twoPower53 = 9007199254740992.0;
                                                                                                   double base1 = 1.0001;
                                                                                                   
                                                                                                   // The original should handle TWO_POWER_53 specially
                                                                                                   double result1 = FastMath.pow(base1, (int)twoPower53);
                                                                                                   double expected1 = Math.pow(base1, twoPower53);
                                                                                                   assertEquals("Power with exponent exactly TWO_POWER_53", expected1, result1, 1e-10);
                                                                                                   
                                                                                                   // Test with value exactly equal to -TWO_POWER_53
                                                                                                   double negativeTwoPower53 = -9007199254740992.0;
                                                                                                   double base2 = 1.0001;
                                                                                                   
                                                                                                   // The original should handle -TWO_POWER_53 specially
                                                                                                   double result2 = FastMath.pow(base2, (int)negativeTwoPower53);
                                                                                                   double expected2 = Math.pow(base2, negativeTwoPower53);
                                                                                                   assertEquals("Power with exponent exactly -TWO_POWER_53", expected2, result2, 1e-10);
                                                                                                   
                                                                                                   // Additional test with exponent just above TWO_POWER_53
                                                                                                   double aboveTwoPower53 = 9007199254740992.0 + 1;
                                                                                                   double result3 = FastMath.pow(base1, (int)aboveTwoPower53);
                                                                                                   double expected3 = Math.pow(base1, aboveTwoPower53);
                                                                                                   assertEquals("Power with exponent just above TWO_POWER_53", expected3, result3, 1e-10);
                                                                                               }

    @Test
                                                                                          public void testPowNegativeBaseWithNegativeTwoPower53Exponent() {
                                                                                              // Setup
                                                                                              double x = -2.0;
                                                                                              double twoPower53 = 9007199254740992.0; // 2^53
                                                                                              double y = -twoPower53;
                                                                                              
                                                                                              // Expected behavior - original should handle this in the first condition
                                                                                              // and return pow(-x, y) which is pow(2.0, -2^53)
                                                                                              double expected = FastMath.pow(2.0, -twoPower53);
                                                                                              
                                                                                              // Test
                                                                                              double result = FastMath.pow(x, y);
                                                                                              
                                                                                              // Verify
                                                                                              assertEquals("Power of negative base with y exactly -2^53 should be handled by first condition",
                                                                                                         expected, result, 0.0);
                                                                                              
                                                                                              // Additional verification that we're testing the boundary case
                                                                                              // The mutant would treat this differently
                                                                                              double slightlyAbove = FastMath.pow(x, -twoPower53 - 1);
                                                                                              double slightlyBelow = FastMath.pow(x, -twoPower53 + 1);
                                                                                              
                                                                                              // These should all be positive since the exponent is even
                                                                                              assertTrue(result > 0);
                                                                                              assertTrue(slightlyAbove > 0);
                                                                                              assertTrue(slightlyBelow > 0);
                                                                                          }

    @Test
                                                                                          public void testPowWithExactNegativeTwoPower() {
                                                                                              // Setup
                                                                                              double base = 2.0;
                                                                                              double exponent = -9007199254740992.0; // -2^53
                                                                                              
                                                                                              // Execute
                                                                                              double result = FastMath.pow(base, exponent);
                                                                                              
                                                                                              // Verify - the exact assertion value might need adjustment based on expected behavior
                                                                                              // The key point is that the original and mutated code will produce different results
                                                                                              // for this exact boundary case
                                                                                              double expected = Math.pow(base, exponent);
                                                                                              assertEquals("Power calculation should handle exact -2^53 exponent correctly", 
                                                                                                         expected, result, 1e-15);
                                                                                              
                                                                                              // Additional verification that we're testing the boundary case
                                                                                              assertTrue("Test should use exact -2^53 value", 
                                                                                                        Double.compare(exponent, -9007199254740992.0) == 0);
                                                                                          }

    @Test
                                                                                      public void testPowWithZeroXShouldNotUseNegativeNumberLogic() {
                                                                                          // Test with x=0 and y as odd integer (should use zero handling, not negative number logic)
                                                                                          assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -3.0), 0.0);
                                                                                          assertEquals(0.0, FastMath.pow(0.0, 3.0), 0.0);
                                                                                          
                                                                                          // Test with x=0 and y as even integer (should use zero handling, not negative number logic)
                                                                                          assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -4.0), 0.0);
                                                                                          assertEquals(0.0, FastMath.pow(0.0, 4.0), 0.0);
                                                                                          
                                                                                          // Test with x=0 and non-integer y (should use zero handling, not return NaN from negative logic)
                                                                                          assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -3.5), 0.0);
                                                                                          assertEquals(0.0, FastMath.pow(0.0, 3.5), 0.0);
                                                                                          
                                                                                          // Test with x=-0.0 to ensure negative zero handling remains correct
                                                                                          assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(-0.0, -3.0), 0.0);
                                                                                          assertEquals(-0.0, FastMath.pow(-0.0, 3.0), 0.0);
                                                                                          
                                                                                          // Test with very small negative x to ensure negative logic still works
                                                                                          assertEquals(-8.0, FastMath.pow(-2.0, 3.0), 0.0);
                                                                                      }

    @Test
                                                                                          public void testPowWithZeroExponent() {
                                                                                              // Test with various base values when exponent is 0
                                                                                              // Should always return 1.0 regardless of base
                                                                                              
                                                                                              // Positive base
                                                                                              assertEquals(1.0, FastMath.pow(2.0, 0), 0.0);
                                                                                              assertEquals(1.0, FastMath.pow(1.5, 0), 0.0);
                                                                                              assertEquals(1.0, FastMath.pow(100.0, 0), 0.0);
                                                                                              
                                                                                              // Negative base
                                                                                              assertEquals(1.0, FastMath.pow(-2.0, 0), 0.0);
                                                                                              assertEquals(1.0, FastMath.pow(-1.5, 0), 0.0);
                                                                                              
                                                                                              // Zero base
                                                                                              assertEquals(1.0, FastMath.pow(0.0, 0), 0.0); // Mathematically debatable but Java's Math.pow returns 1.0
                                                                                              
                                                                                              // Special cases
                                                                                              assertEquals(1.0, FastMath.pow(Double.POSITIVE_INFINITY, 0), 0.0);
                                                                                              assertEquals(1.0, FastMath.pow(Double.NEGATIVE_INFINITY, 0), 0.0);
                                                                                              assertEquals(1.0, FastMath.pow(Double.NaN, 0), 0.0);
                                                                                          }

    @Test
                                                                                    public void testPowNegativeBaseWithExactTwoPower1() {
                                                                                        // Setup
                                                                                        double x = -2.0; // negative base
                                                                                        double y = 9007199254740992.0; // exactly equals 2^53
                                                                                        
                                                                                        // Execute
                                                                                        double result = FastMath.pow(x, y);
                                                                                        
                                                                                        // Verify - original would compute pow(2.0, 2^53) while mutant would treat differently
                                                                                        // We expect the result to be positive since y is even (2^53 is even)
                                                                                        assertEquals(Math.pow(2.0, 9007199254740992.0), result, 0.0);
                                                                                        
                                                                                        // Additional verification that we took the correct branch
                                                                                        // The result should be exactly equal to pow(2.0, 2^53)
                                                                                        // If mutant is present, it would likely return NaN since y wouldn't be considered integer
                                                                                        assertFalse(Double.isNaN(result));
                                                                                    }

    @Test
                                                                                    public void testPowWithExactTwoPower() {
                                                                                        // Test when y exactly equals TWO_POWER_53
                                                                                        double twoPower53 = 9007199254740992.0; // 2^53
                                                                                        double x = 2.0;
                                                                                        
                                                                                        // The original code should handle this as a special case
                                                                                        // The mutated code will process it normally, potentially giving different results
                                                                                        double result = FastMath.pow(x, twoPower53);
                                                                                        
                                                                                        // Calculate expected value using standard Math.pow for comparison
                                                                                        double expected = Math.pow(x, twoPower53);
                                                                                        
                                                                                        // Verify the result matches expected value within reasonable tolerance
                                                                                        assertEquals("Power calculation for exact TWO_POWER_53 failed", 
                                                                                                    expected, result, 1e-10);
                                                                                        
                                                                                        // Also test with negative exponent
                                                                                        double negativeResult = FastMath.pow(x, -twoPower53);
                                                                                        double negativeExpected = Math.pow(x, -twoPower53);
                                                                                        assertEquals("Negative power calculation for exact TWO_POWER_53 failed",
                                                                                                    negativeExpected, negativeResult, 1e-10);
                                                                                    }

    @Test
                                                                               public void testPowNegativeXWithLargeY2() {
                                                                                   // Define TWO_POWER_53 value since we can't access the private constant
                                                                                   final double TWO_POWER_53 = 9007199254740992.0;
                                                                                   
                                                                                   // Test case where y > TWO_POWER_53
                                                                                   double x = -2.0;
                                                                                   double y = TWO_POWER_53 + 1; // Just above the threshold
                                                                                   double expected = FastMath.pow(-x, y); // Should use positive x
                                                                                   double actual = FastMath.pow(x, y);
                                                                                   assertEquals("pow(-x,y) should equal pow(x,y) for y > TWO_POWER_53", expected, actual, 0.0);
                                                                                   
                                                                                   // Test case where y < -TWO_POWER_53
                                                                                   y = -TWO_POWER_53 - 1; // Just below the threshold
                                                                                   expected = FastMath.pow(-x, y); // Should use positive x
                                                                                   actual = FastMath.pow(x, y);
                                                                                   assertEquals("pow(-x,y) should equal pow(x,y) for y < -TWO_POWER_53", expected, actual, 0.0);
                                                                                   
                                                                                   // Test case where y is between -TWO_POWER_53 and TWO_POWER_53
                                                                                   y = TWO_POWER_53 - 1; // Just below the positive threshold
                                                                                   expected = -FastMath.pow(-x, y); // Should use negative result
                                                                                   actual = FastMath.pow(x, y);
                                                                                   assertEquals("pow(-x,y) should equal -pow(x,y) for |y| < TWO_POWER_53", expected, actual, 0.0);
                                                                               }

    @Test
                                                                               public void testPowWithLargeExponents1() {
                                                                                   // 2^53 = 9007199254740992
                                                                                   final long TWO_POWER_53 = 9007199254740992L;
                                                                                   
                                                                                   // Test with positive exponent >= TWO_POWER_53
                                                                                   double base1 = 2.0;
                                                                                   int exponent1 = (int)TWO_POWER_53 + 1;
                                                                                   double result1 = FastMath.pow(base1, exponent1);
                                                                                   // Should not be infinity (proper handling of large exponent)
                                                                                   assertFalse(Double.isInfinite(result1));
                                                                                   
                                                                                   // Test with negative exponent <= -TWO_POWER_53
                                                                                   double base2 = 0.5;
                                                                                   int exponent2 = -(int)TWO_POWER_53 - 1;
                                                                                   double result2 = FastMath.pow(base2, exponent2);
                                                                                   // Should not be zero (proper handling of large negative exponent)
                                                                                   assertNotEquals(0.0, result2, 0.0);
                                                                                   
                                                                                   // Test with exponent exactly TWO_POWER_53
                                                                                   int exponent3 = (int)TWO_POWER_53;
                                                                                   double result3 = FastMath.pow(1.5, exponent3);
                                                                                   assertTrue(result3 > 0 && !Double.isInfinite(result3));
                                                                                   
                                                                                   // Test with exponent exactly -TWO_POWER_53
                                                                                   int exponent4 = -(int)TWO_POWER_53;
                                                                                   double result4 = FastMath.pow(0.75, exponent4);
                                                                                   assertTrue(result4 > 0 && result4 != Double.POSITIVE_INFINITY);
                                                                               }

    @Test
                                                                          public void testPowWithLargeNegativeExponent2() {
                                                                              // Setup
                                                                              double x = -2.0;
                                                                              // TWO_POWER_53 is 2^53 = 9007199254740992
                                                                              double twoPower53 = 9007199254740992.0;
                                                                              double y = -twoPower53 - 1; // y <= -TWO_POWER_53
                                                                              
                                                                              // Expected behavior: should call pow(-x, y) because y <= -TWO_POWER_53
                                                                              double expected = FastMath.pow(2.0, y); // pow(-(-2.0), y)
                                                                              
                                                                              // Test
                                                                              double result = FastMath.pow(x, y);
                                                                              
                                                                              // Verify
                                                                              assertEquals("Pow should handle large negative exponents correctly", 
                                                                                          expected, result, 0.0);
                                                                              
                                                                              // Additional edge case: exactly -TWO_POWER_53
                                                                              y = -twoPower53;
                                                                              expected = FastMath.pow(2.0, y);
                                                                              result = FastMath.pow(x, y);
                                                                              assertEquals("Pow should handle exponent of exactly -TWO_POWER_53",
                                                                                          expected, result, 0.0);
                                                                          }

    @Test
                                                                          public void testPowWithLargeNegativeExponent3() {
                                                                              // Define TWO_POWER_53 value directly since we can't access the private constant
                                                                              final long TWO_POWER_53 = 9007199254740992L;
                                                                              
                                                                              // Test with exponent exactly at -TWO_POWER_53 boundary
                                                                              double base = 2.0;
                                                                              int exponent = (int) -TWO_POWER_53;
                                                                              double expected = Math.pow(base, exponent);
                                                                              double actual = FastMath.pow(base, exponent);
                                                                              assertEquals("Power with exponent at -TWO_POWER_53", expected, actual, 1e-15);
                                                                          
                                                                              // Test with exponent just below -TWO_POWER_53 (should be treated specially in original)
                                                                              exponent = (int) -TWO_POWER_53 - 1;
                                                                              expected = Math.pow(base, exponent);
                                                                              actual = FastMath.pow(base, exponent);
                                                                              assertEquals("Power with exponent just below -TWO_POWER_53", expected, actual, 1e-15);
                                                                          
                                                                              // Test with exponent just above -TWO_POWER_53 (normal processing)
                                                                              exponent = (int) -TWO_POWER_53 + 1;
                                                                              expected = Math.pow(base, exponent);
                                                                              actual = FastMath.pow(base, exponent);
                                                                              assertEquals("Power with exponent just above -TWO_POWER_53", expected, actual, 1e-15);
                                                                          
                                                                              // Test with positive boundary for comparison
                                                                              exponent = (int) TWO_POWER_53;
                                                                              expected = Math.pow(base, exponent);
                                                                              actual = FastMath.pow(base, exponent);
                                                                              assertEquals("Power with exponent at TWO_POWER_53", expected, actual, 1e-15);
                                                                          
                                                                              // Test with exponent above TWO_POWER_53
                                                                              exponent = (int) TWO_POWER_53 + 1;
                                                                              expected = Math.pow(base, exponent);
                                                                              actual = FastMath.pow(base, exponent);
                                                                              assertEquals("Power with exponent above TWO_POWER_53", expected, actual, 1e-15);
                                                                          }

    @Test
                                                                     public void testPowNegativeXWithLargePositiveY() {
                                                                         // Setup
                                                                         double x = -2.0;
                                                                         double twoPower53 = 9007199254740992.0; // 2^53
                                                                         double y = twoPower53; // Exactly the boundary value
                                                                         
                                                                         // The original behavior should handle large positive y same as large negative y
                                                                         // by taking the absolute value of x first
                                                                         double expected = FastMath.pow(-x, y);
                                                                         
                                                                         // Test
                                                                         double result = FastMath.pow(x, y);
                                                                         
                                                                         // Verify
                                                                         assertEquals("pow(-x,y) should equal pow(|x|,y) for large positive y", 
                                                                                    expected, result, 0.0);
                                                                         
                                                                         // Test with even larger y
                                                                         y = twoPower53 + 1;
                                                                         expected = FastMath.pow(-x, y);
                                                                         result = FastMath.pow(x, y);
                                                                         assertEquals("pow(-x,y) should equal pow(|x|,y) for very large positive y", 
                                                                                    expected, result, 0.0);
                                                                     }

    @Test
                                                                     public void testPowWithLargePositiveExponent1() {
                                                                         // TWO_POWER_53 is 2^53 (9007199254740992.0)
                                                                         final double TWO_POWER_53 = 9007199254740992.0;
                                                                         double largePositive = TWO_POWER_53 + 1; // Value just above threshold
                                                                         
                                                                         // Test with base 1 (any number to this power should be 1)
                                                                         double result = FastMath.pow(1.0, (int)largePositive);
                                                                         assertEquals("1.0 to any power should be 1.0", 1.0, result, 0.0);
                                                                         
                                                                         // Test with base 2 (2^largePositive would normally overflow)
                                                                         // The original method should handle this case specially
                                                                         result = FastMath.pow(2.0, (int)largePositive);
                                                                         // We don't care about the exact value here, just that it doesn't throw or return nonsense
                                                                         assertFalse("Result should not be infinite", Double.isInfinite(result));
                                                                         assertFalse("Result should not be NaN", Double.isNaN(result));
                                                                         
                                                                         // Test with base -1 (should be 1 for even exponents, -1 for odd)
                                                                         // Since largePositive is even (2^53 + 1 is odd, but we cast to int which is 2^53 for positive numbers)
                                                                         result = FastMath.pow(-1.0, (int)largePositive);
                                                                         assertEquals("(-1)^even should be 1", 1.0, result, 0.0);
                                                                     }

    @Test
                                                                public void testPowWithNegativeXAndLargeY1() {
                                                                    // Define TWO_POWER_53 constant locally
                                                                    final double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                                    
                                                                    // Test with negative x and y >= TWO_POWER_53
                                                                    double x = -2.0;
                                                                    double y = TWO_POWER_53;
                                                                    double expected = FastMath.pow(-x, y); // Original behavior would return pow(2.0, 2^53)
                                                                    double actual = FastMath.pow(x, y);
                                                                    assertEquals("Pow with negative x and y >= TWO_POWER_53", expected, actual, 0.0);
                                                                    
                                                                    // Test with negative x and y <= -TWO_POWER_53
                                                                    y = -TWO_POWER_53;
                                                                    expected = FastMath.pow(-x, y); // Original behavior would return pow(2.0, -2^53)
                                                                    actual = FastMath.pow(x, y);
                                                                    assertEquals("Pow with negative x and y <= -TWO_POWER_53", expected, actual, 0.0);
                                                                    
                                                                    // Test with negative x, odd integer y >= TWO_POWER_53
                                                                    y = TWO_POWER_53 + 1; // odd integer > 2^53
                                                                    expected = -FastMath.pow(-x, y); // Original behavior would return -pow(2.0, 2^53+1)
                                                                    actual = FastMath.pow(x, y);
                                                                    assertEquals("Pow with negative x and odd y >= TWO_POWER_53", expected, actual, 0.0);
                                                                }

    @Test
                                                                public void testPowWithVeryLargeExponents() {
                                                                    // 2^53 is the largest integer that can be represented exactly in double precision
                                                                    final long TWO_POWER_53 = 9007199254740992L;
                                                                    
                                                                    // Test positive exponent larger than TWO_POWER_53
                                                                    double base1 = 1.5;
                                                                    int exponent1 = (int)TWO_POWER_53 + 1;
                                                                    double result1 = FastMath.pow(base1, exponent1);
                                                                    // Should be infinity for base > 1 with large positive exponent
                                                                    assertEquals(Double.POSITIVE_INFINITY, result1, 0.0);
                                                                    
                                                                    // Test negative exponent smaller than -TWO_POWER_53
                                                                    double base2 = 1.5;
                                                                    int exponent2 = -(int)TWO_POWER_53 - 1;
                                                                    double result2 = FastMath.pow(base2, exponent2);
                                                                    // Should be 0 for base > 1 with large negative exponent
                                                                    assertEquals(0.0, result2, 0.0);
                                                                    
                                                                    // Test with base between 0 and 1 to check the inverse behavior
                                                                    double base3 = 0.5;
                                                                    int exponent3 = (int)TWO_POWER_53 + 1;
                                                                    double result3 = FastMath.pow(base3, exponent3);
                                                                    // Should be 0 for 0 < base < 1 with large positive exponent
                                                                    assertEquals(0.0, result3, 0.0);
                                                                    
                                                                    // Test with base between 0 and 1 and large negative exponent
                                                                    double base4 = 0.5;
                                                                    int exponent4 = -(int)TWO_POWER_53 - 1;
                                                                    double result4 = FastMath.pow(base4, exponent4);
                                                                    // Should be infinity for 0 < base < 1 with large negative exponent
                                                                    assertEquals(Double.POSITIVE_INFINITY, result4, 0.0);
                                                                }

    @Test
                                                            public void testPowWithNegativeXAndEvenIntegerY() {
                                                                // Test with negative x and even integer y
                                                                double negativeX = -2.0;
                                                                double evenY = 4.0;  // even integer
                                                                double oddY = 3.0;   // odd integer
                                                                
                                                                // For even y, result should be positive (since negative^even is positive)
                                                                double resultEven = FastMath.pow(negativeX, evenY);
                                                                assertEquals(16.0, resultEven, 0.0001);
                                                                assertTrue(resultEven > 0);  // Verify it's positive
                                                                
                                                                // For odd y, result should be negative (since negative^odd is negative)
                                                                double resultOdd = FastMath.pow(negativeX, oddY);
                                                                assertEquals(-8.0, resultOdd, 0.0001);
                                                                assertTrue(resultOdd < 0);  // Verify it's negative
                                                                
                                                                // Test with larger even integer
                                                                double largeEvenY = 10.0;
                                                                double largeResult = FastMath.pow(negativeX, largeEvenY);
                                                                assertEquals(1024.0, largeResult, 0.0001);
                                                                assertTrue(largeResult > 0);
                                                                
                                                                // Test with negative even integer
                                                                double negativeEvenY = -4.0;
                                                                double negativeEvenResult = FastMath.pow(negativeX, negativeEvenY);
                                                                assertEquals(0.0625, negativeEvenResult, 0.0001);
                                                                assertTrue(negativeEvenResult > 0);
                                                                
                                                                // Test with negative odd integer
                                                                double negativeOddY = -3.0;
                                                                double negativeOddResult = FastMath.pow(negativeX, negativeOddY);
                                                                assertEquals(-0.125, negativeOddResult, 0.0001);
                                                                assertTrue(negativeOddResult < 0);
                                                            }

    @Test
                                                            public void testPowWithEvenAndOddExponents1() {
                                                                // Test with even exponent (2)
                                                                double base = 2.0;
                                                                int evenExp = 2;
                                                                double expectedEvenResult = 4.0; // 2^2 = 4
                                                                double actualEvenResult = FastMath.pow(base, evenExp);
                                                                assertEquals("Even exponent test failed", expectedEvenResult, actualEvenResult, 0.0001);
                                                                
                                                                // Test with odd exponent (3)
                                                                int oddExp = 3;
                                                                double expectedOddResult = 8.0; // 2^3 = 8
                                                                double actualOddResult = FastMath.pow(base, oddExp);
                                                                assertEquals("Odd exponent test failed", expectedOddResult, actualOddResult, 0.0001);
                                                                
                                                                // Test with larger even exponent (10)
                                                                int largeEvenExp = 10;
                                                                double expectedLargeEvenResult = 1024.0; // 2^10 = 1024
                                                                double actualLargeEvenResult = FastMath.pow(base, largeEvenExp);
                                                                assertEquals("Large even exponent test failed", expectedLargeEvenResult, actualLargeEvenResult, 0.0001);
                                                                
                                                                // Test with larger odd exponent (11)
                                                                int largeOddExp = 11;
                                                                double expectedLargeOddResult = 2048.0; // 2^11 = 2048
                                                                double actualLargeOddResult = FastMath.pow(base, largeOddExp);
                                                                assertEquals("Large odd exponent test failed", expectedLargeOddResult, actualLargeOddResult, 0.0001);
                                                                
                                                                // Test with negative even exponent (-2)
                                                                int negEvenExp = -2;
                                                                double expectedNegEvenResult = 0.25; // 2^-2 = 0.25
                                                                double actualNegEvenResult = FastMath.pow(base, negEvenExp);
                                                                assertEquals("Negative even exponent test failed", expectedNegEvenResult, actualNegEvenResult, 0.0001);
                                                                
                                                                // Test with negative odd exponent (-3)
                                                                int negOddExp = -3;
                                                                double expectedNegOddResult = 0.125; // 2^-3 = 0.125
                                                                double actualNegOddResult = FastMath.pow(base, negOddExp);
                                                                assertEquals("Negative odd exponent test failed", expectedNegOddResult, actualNegOddResult, 0.0001);
                                                            }

    @Test
                                                          public void testPowNegativeBaseWithExactTwoPower53Exponent() {
                                                              // Setup
                                                              double x = -2.0;
                                                              double twoPower53 = 9007199254740992.0; // 2^53
                                                              
                                                              // The original code would treat y=TWO_POWER_53 as a large number and compute pow(2.0, y)
                                                              // The mutated code would treat it as not large enough and check if it's an integer
                                                              
                                                              // Expected behavior (original): should return pow(2.0, TWO_POWER_53) because y equals TWO_POWER_53
                                                              double expected = FastMath.pow(2.0, twoPower53);
                                                              
                                                              // Actual behavior
                                                              double actual = FastMath.pow(x, twoPower53);
                                                              
                                                              // Assert
                                                              assertEquals("Power of negative base with exponent exactly TWO_POWER_53 should equal pow of positive base", 
                                                                          expected, actual, 0.0);
                                                              
                                                              // Additional check to ensure we're testing the boundary case
                                                              double slightlyLess = twoPower53 - 1;
                                                              double slightlyMore = twoPower53 + 1;
                                                              
                                                              // Both original and mutant should handle slightlyMore the same way
                                                              assertEquals(FastMath.pow(2.0, slightlyMore), 
                                                                          FastMath.pow(x, slightlyMore), 0.0);
                                                              
                                                              // Original and mutant differ only at exact TWO_POWER_53
                                                              // This test will fail if the mutant is present because:
                                                              // Mutant would see y=TWO_POWER_53 as not >= TWO_POWER_53+1 and go to integer check
                                                              // Original would see it as >= TWO_POWER_53 and compute pow(-x,y)
                                                          }

    @Test
                                                          public void testPowBoundaryConditions1() {
                                                              // Test with value exactly at TWO_POWER_53 (2^53)
                                                              double twoPower53 = 9007199254740992.0;
                                                              double result1 = FastMath.pow(2.0, twoPower53);
                                                              // Should be handled specially (likely returns infinity)
                                                              assertTrue("Result at TWO_POWER_53 should be infinite", 
                                                                        Double.isInfinite(result1));
                                                              
                                                              // Test with value exactly at -TWO_POWER_53
                                                              double result2 = FastMath.pow(2.0, -twoPower53);
                                                              // Should be handled specially (likely returns 0)
                                                              assertEquals("Result at -TWO_POWER_53 should be 0", 
                                                                          0.0, result2, 0.0);
                                                              
                                                              // Test with value just above TWO_POWER_53 (should be same behavior in both)
                                                              double result3 = FastMath.pow(2.0, twoPower53 + 1);
                                                              assertTrue("Result above TWO_POWER_53 should be infinite",
                                                                        Double.isInfinite(result3));
                                                              
                                                              // Test with value just below -TWO_POWER_53 (should be same behavior in both)
                                                              double result4 = FastMath.pow(2.0, -twoPower53 - 1);
                                                              assertEquals("Result below -TWO_POWER_53 should be 0",
                                                                          0.0, result4, 0.0);
                                                          }

    @Test
                                                     public void testPowNegativeXWithYEqualToNegativeTwoPower() {
                                                         // Setup
                                                         double x = -2.0; // negative x to trigger the code path
                                                         // TWO_POWER_53 is 2^53 = 9007199254740992
                                                         double twoPower53 = 9007199254740992.0;
                                                         double y = -twoPower53; // exact boundary value
                                                         
                                                         // Expected behavior - original code would return pow(2.0, -twoPower53)
                                                         double expected = FastMath.pow(2.0, -twoPower53);
                                                         
                                                         // Test
                                                         double result = FastMath.pow(x, y);
                                                         
                                                         // Verify
                                                         assertEquals("Pow should handle y exactly equal to -TWO_POWER_53 correctly", 
                                                                    expected, result, 0.0);
                                                         
                                                         // Additional verification that we're testing the right case
                                                         assertTrue("Test case should use y == -TWO_POWER_53", 
                                                                   y == -twoPower53);
                                                     }

    @Test
                                                     public void testPowWithNegativeExponentEqualToMinusTwoPower() {
                                                         // Setup
                                                         double base = 2.0;
                                                         // TWO_POWER_53 is 2^53 = 9007199254740992
                                                         final long TWO_POWER_53 = 1L << 53;
                                                         int exponent = -(int)TWO_POWER_53;
                                                         
                                                         // The mutation changes behavior when exponent is exactly -TWO_POWER_53
                                                         // Original code would handle this case specially, mutant would not
                                                         double expected = Math.pow(base, exponent);
                                                         
                                                         // Test
                                                         double actual = FastMath.pow(base, exponent);
                                                         
                                                         // Verify
                                                         assertEquals("Power calculation should handle exact -TWO_POWER_53 exponent correctly",
                                                                     expected, actual, 1e-10);
                                                         
                                                         // Additional verification that we're testing the boundary case
                                                         assertTrue("Test should use exact -TWO_POWER_53 value", 
                                                                   exponent == -TWO_POWER_53);
                                                     }

    @Test
                                                 public void testPowWithZeroXAndOddIntegerY() {
                                                     // Test case where x=0 and y is an odd integer
                                                     // Original behavior: should return positive infinity (from x=0 handling)
                                                     // Mutated behavior: would enter negative number handling and potentially return wrong value
                                                     
                                                     // Test positive odd integer y with x=0
                                                     assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, 3.0));
                                                     
                                                     // Test negative odd integer y with x=0
                                                     assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -3.0));
                                                     
                                                     // Test positive odd integer y with x=-0.0
                                                     assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(-0.0, 3.0));
                                                     
                                                     // Test negative odd integer y with x=-0.0
                                                     assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(-0.0, -3.0));
                                                     
                                                     // Additional edge case: x=0, y=1 (odd integer but should be handled by x=0 case)
                                                     assertEquals(0.0, FastMath.pow(0.0, 1.0));
                                                 }

    @Test
                                                     public void testPowWithZeroExponentShouldAlwaysReturnOne() {
                                                         // Test with positive base
                                                         double result1 = FastMath.pow(2.0, 0);
                                                         assertEquals(1.0, result1, 0.0);
                                                         
                                                         // Test with negative base
                                                         double result2 = FastMath.pow(-3.0, 0);
                                                         assertEquals(1.0, result2, 0.0);
                                                         
                                                         // Test with zero base
                                                         double result3 = FastMath.pow(0.0, 0);
                                                         assertEquals(1.0, result3, 0.0);
                                                         
                                                         // Test with fractional base
                                                         double result4 = FastMath.pow(0.5, 0);
                                                         assertEquals(1.0, result4, 0.0);
                                                         
                                                         // Test with very large base
                                                         double result5 = FastMath.pow(Double.MAX_VALUE, 0);
                                                         assertEquals(1.0, result5, 0.0);
                                                         
                                                         // Test with very small base
                                                         double result6 = FastMath.pow(Double.MIN_VALUE, 0);
                                                         assertEquals(1.0, result6, 0.0);
                                                     }

    @Test
                                               public void testPowNegativeXWithExactTwoPower53Y() {
                                                   // Setup
                                                   double x = -2.0;
                                                   double twoPower53 = 9007199254740992.0; // 2^53
                                                   double y = twoPower53;  // Exact boundary case
                                                   
                                                   // Expected behavior - should use simplified pow(-x, y) calculation
                                                   double expected = FastMath.pow(-x, y);
                                                   
                                                   // Test
                                                   double result = FastMath.pow(x, y);
                                                   
                                                   // Verify
                                                   assertEquals("pow(-2.0, TWO_POWER_53) should equal pow(2.0, TWO_POWER_53)", 
                                                               expected, result, 0.0);
                                                   
                                                   // Additional verification that we're testing the boundary case
                                                   assertTrue("y should exactly equal 2^53", 
                                                              y == twoPower53);
                                               }

    @Test
                                           public void testPowBoundaryAtTwoPower1() {
                                               // Test the boundary case where exponent equals TWO_POWER_53
                                               double base = 1.0001; // Any base > 1 will work to show the difference
                                               long exponent = 9007199254740992L; // Value of 2^53
                                               
                                               // The original method should handle this specially (likely more accurately)
                                               // while the mutant would process it normally, potentially with different results
                                               double result = FastMath.pow(base, exponent);
                                               
                                               // We can't predict the exact value, but we can verify it's a finite, reasonable number
                                               assertTrue("Result should be finite", Double.isFinite(result));
                                               assertTrue("Result should be positive", result > 0);
                                               
                                               // More importantly, compare with Math.pow to detect any significant deviation
                                               double expected = Math.pow(base, exponent);
                                               double relativeError = Math.abs(result - expected) / expected;
                                               assertTrue("Relative error should be small", relativeError < 1e-10);
                                           }

    @Test
                                      public void testPowNegativeXWithLargeY3() {
                                          // Define TWO_POWER_53 constant locally
                                          final double TWO_POWER_53 = 9007199254740992.0;
                                          
                                          // Test with negative x and y >= TWO_POWER_53
                                          double x = -2.0;
                                          double y = TWO_POWER_53;
                                          double expected = FastMath.pow(-x, y); // Should use pow(-x, y) in original
                                          double actual = FastMath.pow(x, y);
                                          assertEquals(expected, actual, 0.0);
                                          
                                          // Test with negative x and y <= -TWO_POWER_53
                                          y = -TWO_POWER_53;
                                          expected = FastMath.pow(-x, y); // Should use pow(-x, y) in original
                                          actual = FastMath.pow(x, y);
                                          assertEquals(expected, actual, 0.0);
                                          
                                          // Test with y between -TWO_POWER_53 and TWO_POWER_53
                                          // This verifies the original code doesn't use pow(-x,y) in this case
                                          y = TWO_POWER_53 - 1;
                                          expected = -FastMath.pow(-x, y); // Should use -pow(-x,y) since y is odd integer
                                          actual = FastMath.pow(x, y);
                                          assertEquals(expected, actual, 0.0);
                                      }

    @Test
                                  public void testPowWithLargeExponents2() {
                                      // Test with exponent > TWO_POWER_53 (should trigger original condition but not mutated one)
                                      double base1 = 2.0;
                                      int largePositiveExp = (int)(9007199254740992L + 1); // TWO_POWER_53 + 1
                                      double result1 = FastMath.pow(base1, largePositiveExp);
                                      // Just verify it computes something (the exact value isn't important for mutant detection)
                                      assertTrue(Double.isFinite(result1));
                                      
                                      // Test with exponent < -TWO_POWER_53 (should trigger original condition but not mutated one)
                                      double base2 = 0.5;
                                      int largeNegativeExp = (int)(-9007199254740992L - 1); // -TWO_POWER_53 - 1
                                      double result2 = FastMath.pow(base2, largeNegativeExp);
                                      assertTrue(Double.isFinite(result2));
                                      
                                      // Test with exponent between -TWO_POWER_53 and TWO_POWER_53 (should behave same in both)
                                      double base3 = 1.5;
                                      int mediumExp = 10;
                                      double result3 = FastMath.pow(base3, mediumExp);
                                      assertEquals(Math.pow(base3, mediumExp), result3, 1e-10);
                                  }

    @Test
                             public void testPowWithNegativeXAndLargeNegativeY() {
                                 // Setup
                                 double x = -2.0;
                                 double twoPower53 = 9007199254740992.0; // 2^53
                                 double largeNegativeY = -twoPower53 - 1; // y <= -TWO_POWER_53
                                 
                                 // Expected behavior - should handle large negative y same as large positive y
                                 double expected = Math.pow(-x, largeNegativeY); // Original behavior
                                 double expectedMutant = Double.NaN; // Mutant behavior (since condition fails)
                                 
                                 // Test
                                 double actual = FastMath.pow(x, largeNegativeY);
                                 
                                 // Verify - this will fail if the mutant is present
                                 assertEquals("Pow with negative x and large negative y should equal pow(-x,y)", 
                                             expected, actual, 0.0);
                                 
                                 // Additional verification that we're not getting mutant behavior
                                 assertNotEquals("Should not return NaN for this case", 
                                                Double.NaN, actual, 0.0);
                             }

    @Test
                             public void testPowWithVeryLargeNegativeExponent() {
                                 // Setup
                                 double base = 2.0;
                                 // TWO_POWER_53 is 2^53 = 9007199254740992
                                 int exponent = (int)(-9007199254740992L - 1); // Just below -2^53
                                 
                                 // Action
                                 double result = FastMath.pow(base, exponent);
                                 
                                 // Verification
                                 // The exact expected value isn't as important as verifying the special case was handled
                                 // We expect a very small positive number since 2^-very_large_number -> 0
                                 assertTrue("Result should be positive and very small", result > 0 && result < Double.MIN_NORMAL);
                                 
                                 // Additionally verify it's not infinity or NaN
                                 assertFalse("Result should not be infinite", Double.isInfinite(result));
                                 assertFalse("Result should not be NaN", Double.isNaN(result));
                             }

    @Test
                        public void testPowWithLargePositiveYAndNegativeX() {
                            // Setup
                            double x = -2.0;  // Negative x
                            double twoPower53 = 9007199254740992.0;  // 2^53
                            double y = twoPower53;  // Exactly the boundary value
                            
                            // The original code should handle this case specially (using pow(-x,y))
                            // The mutant will miss this case and use normal calculation
                            
                            // Expected behavior (original code)
                            double expected = FastMath.pow(-x, y);
                            
                            // Actual result
                            double actual = FastMath.pow(x, y);
                            
                            // Assert
                            assertEquals("Large positive y with negative x should be handled specially", 
                                       expected, actual, 0.0);
                            
                            // Also test a value above the boundary
                            double y2 = twoPower53 + 1.0;
                            double expected2 = FastMath.pow(-x, y2);
                            double actual2 = FastMath.pow(x, y2);
                            assertEquals("Large positive y (>TWO_POWER_53) with negative x should be handled specially",
                                       expected2, actual2, 0.0);
                        }

    @Test
                        public void testPowWithLargePositiveExponent2() {
                            // Test with exponent >= TWO_POWER_53 (9007199254740992.0)
                            double base = 1.0001;
                            long largePositiveExp = 9007199254740992L + 1; // TWO_POWER_53 + 1
                            
                            // This should trigger different behavior between original and mutated code
                            double result = FastMath.pow(base, largePositiveExp);
                            
                            // The exact expected value isn't as important as verifying the special case was handled
                            // We just want to ensure the large exponent case was processed correctly
                            assertFalse("Result should not be infinite", Double.isInfinite(result));
                            assertFalse("Result should not be NaN", Double.isNaN(result));
                            assertTrue("Result should be a very large number", result > 1e100);
                        }

    @Test
                        public void testPowWithLargeNegativeExponent4() {
                            // Test with exponent <= -TWO_POWER_53
                            double base = 1.0001;
                            // TWO_POWER_53 is 2^53 = 9007199254740992
                            int largeNegativeExp = (int) -9007199254740992L - 1;
                            
                            double result = FastMath.pow(base, largeNegativeExp);
                            
                            // Verify the result is a very small positive number
                            assertTrue("Result should be a very small positive number", 
                                      result > 0 && result < 1e-100);
                        }

    @Test
                        public void testPowBoundaryConditions2() {
                            // Test boundary around TWO_POWER_53
                            double base = 1.5;
                            
                            // TWO_POWER_53 is 2^53 = 9007199254740992
                            final long twoPower53 = 9007199254740992L;
                            
                            // Just below TWO_POWER_53 (should be handled normally)
                            int justBelow = (int) twoPower53 - 1;
                            double normalResult = FastMath.pow(base, justBelow);
                            
                            // Just above TWO_POWER_53 (should trigger special case in original)
                            int justAbove = (int) twoPower53 + 1;
                            double specialResult = FastMath.pow(base, justAbove);
                            
                            // In mutated version, these should be different because special case is missed
                            // In original version, they might be similar because both would use special handling
                            double ratio = specialResult / normalResult;
                            
                            // The ratio should be approximately base^2 (since difference is 2 in exponent)
                            // But exact value isn't important - we're checking that both cases were handled
                            assertTrue("Results should show exponential growth", 
                                      ratio > base * base * 0.9 && ratio < base * base * 1.1);
                        }

    @Test
                   public void testPowNegativeXWithLargeY4() {
                       // Setup
                       double negativeX = -2.0;
                       double largeY = 9007199254740992.0; // 2^53 = 9007199254740992.0
                       
                       // Test the special case where |y| >= TWO_POWER_53
                       double expected = FastMath.pow(-negativeX, largeY); // Should be same as pow(2.0, largeY)
                       double actual = FastMath.pow(negativeX, largeY);
                       
                       // Verify
                       assertEquals("pow(-x,y) should equal pow(x,y) when |y| >= 2^53", 
                                   expected, actual, 0.0);
                       
                       // Also test negative large y
                       double negativeLargeY = -9007199254740992.0;
                       expected = FastMath.pow(-negativeX, negativeLargeY);
                       actual = FastMath.pow(negativeX, negativeLargeY);
                       
                       assertEquals("pow(-x,-y) should equal pow(x,-y) when |y| >= 2^53",
                                   expected, actual, 0.0);
                   }

    @Test
               public void testPowWithLargeExponents3() {
                   // Test with exponent equal to TWO_POWER_53 (2^53)
                   double base = 1.0001;
                   long largeExponent = 9007199254740992L; // 2^53
                   int negativeLargeExponent = -(int)largeExponent;
                   
                   // With original code, these should return special values (likely Infinity or 0)
                   // With mutated code, it will try to calculate them normally which may produce wrong results
                   // or take extremely long time
                   
                   // Test positive large exponent
                   try {
                       double result = FastMath.pow(base, (int)largeExponent);
                       // If we get here with original code, it's wrong - should have special handling
                       // With mutated code, it might return some value but likely incorrect
                       assertTrue("Result should be infinity for very large exponent", 
                                  Double.isInfinite(result));
                   } catch (ArithmeticException e) {
                       // This would also be acceptable behavior for original code
                       assertTrue(true);
                   }
                   
                   // Test negative large exponent
                   try {
                       double result = FastMath.pow(base, negativeLargeExponent);
                       // Original code should return 0 for very large negative exponents
                       // Mutated code might return some small value but likely incorrect
                       assertEquals("Result should be 0 for very large negative exponent", 
                                    0.0, result, 0.0);
                   } catch (ArithmeticException e) {
                       // This would also be acceptable behavior for original code
                       assertTrue(true);
                   }
                   
                   // Test with exponent just above TWO_POWER_53
                   int slightlyLarger = (int)largeExponent + 1;
                   try {
                       double result = FastMath.pow(base, slightlyLarger);
                       assertTrue("Result should be infinity for exponents > TWO_POWER_53", 
                                  Double.isInfinite(result));
                   } catch (ArithmeticException e) {
                       assertTrue(true);
                   }
                   
                   // Test with exponent just below -TWO_POWER_53
                   int slightlySmaller = negativeLargeExponent - 1;
                   try {
                       double result = FastMath.pow(base, slightlySmaller);
                       assertEquals("Result should be 0 for exponents < -TWO_POWER_53", 
                                    0.0, result, 0.0);
                   } catch (ArithmeticException e) {
                       assertTrue(true);
                   }
               }

    @Test
           public void testPowWithNegativeXAndEvenIntegerY1() {
               // Test with negative x and even integer y
               double negativeBase = -2.0;
               double evenExponent = 4.0;  // even integer
               
               // Should return positive result since (-2)^4 = 16
               double result = FastMath.pow(negativeBase, evenExponent);
               assertEquals(16.0, result, 0.0);
               assertTrue(result > 0);  // Important check - result should be positive
               
               // Test with negative x and odd integer y for completeness
               double oddExponent = 3.0;  // odd integer
               result = FastMath.pow(negativeBase, oddExponent);
               assertEquals(-8.0, result, 0.0);
               assertTrue(result < 0);  // Should be negative
               
               // Test with large even integer
               double largeEvenExponent = 100.0;
               result = FastMath.pow(negativeBase, largeEvenExponent);
               assertTrue(result > 0);  // Should be positive
               
               // Test with large odd integer
               double largeOddExponent = 101.0;
               result = FastMath.pow(negativeBase, largeOddExponent);
               assertTrue(result < 0);  // Should be negative
           }

    @Test
               public void testPowWithOddExponent() {
                   // Test with odd exponent (3)
                   double base = 2.0;
                   int exponent = 3;
                   double expected = 8.0; // 2^3 = 8
                   double actual = FastMath.pow(base, exponent);
                   assertEquals("Pow with odd exponent failed", expected, actual, 1e-15);
                   
                   // Test with another odd exponent (5)
                   base = 3.0;
                   exponent = 5;
                   expected = 243.0; // 3^5 = 243
                   actual = FastMath.pow(base, exponent);
                   assertEquals("Pow with odd exponent failed", expected, actual, 1e-15);
               }

    @Test
               public void testPowWithEvenExponent() {
                   // Test with even exponent (4)
                   double base = 2.0;
                   int exponent = 4;
                   double expected = 16.0; // 2^4 = 16
                   double actual = FastMath.pow(base, exponent);
                   assertEquals("Pow with even exponent failed", expected, actual, 1e-15);
                   
                   // Test with another even exponent (6)
                   base = 3.0;
                   exponent = 6;
                   expected = 729.0; // 3^6 = 729
                   actual = FastMath.pow(base, exponent);
                   assertEquals("Pow with even exponent failed", expected, actual, 1e-15);
               }

    @Test
               public void testPowWithNegativeOddExponent() {
                   // Test with negative odd exponent (-3)
                   double base = 2.0;
                   int exponent = -3;
                   double expected = 0.125; // 2^-3 = 1/8
                   double actual = FastMath.pow(base, exponent);
                   assertEquals("Pow with negative odd exponent failed", expected, actual, 1e-15);
               }

    @Test
               public void testPowWithNegativeEvenExponent() {
                   // Test with negative even exponent (-4)
                   double base = 2.0;
                   int exponent = -4;
                   double expected = 0.0625; // 2^-4 = 1/16
                   double actual = FastMath.pow(base, exponent);
                   assertEquals("Pow with negative even exponent failed", expected, actual, 1e-15);
               }

    @Test
         public void testPowNegativeBaseWithExactTwoPower53Exponent1() {
             // Setup
             double x = -2.0; // negative base
             double y = 9007199254740992.0; // exactly TWO_POWER_53
             double TWO_POWER_53 = 9007199254740992.0; // value of FastMath.TWO_POWER_53
             
             // Expected behavior - should return pow(-x, y) since y == TWO_POWER_53
             double expected = FastMath.pow(-x, y);
             
             // Test
             double result = FastMath.pow(x, y);
             
             // Verify
             assertEquals("pow(-2.0, TWO_POWER_53) should equal pow(2.0, TWO_POWER_53)", 
                         expected, result, 0.0);
             
             // Additional verification that we're testing the right case
             assertTrue("y should be exactly equal to TWO_POWER_53", 
                        y == TWO_POWER_53);
             assertTrue("x should be negative", x < 0);
         }

    @Test
         public void testPowBoundaryConditions3() {
             // Test exact TWO_POWER_53 boundary - this should detect the mutant
             double twoPower53 = 9007199254740992.0; // 2^53
             double result1 = FastMath.pow(2.0, (int)twoPower53);
             assertEquals(Math.pow(2.0, twoPower53), result1, 1e-10);
             
             // Test negative boundary - should behave same in both
             double result2 = FastMath.pow(2.0, (int)-twoPower53);
             assertEquals(Math.pow(2.0, -twoPower53), result2, 1e-10);
             
             // Test just above boundary - should behave same in both
             double result3 = FastMath.pow(2.0, (int)(twoPower53 + 1));
             assertEquals(Math.pow(2.0, twoPower53 + 1), result3, 1e-10);
             
             // Test just below boundary - should behave same in both
             double result4 = FastMath.pow(2.0, (int)(twoPower53 - 1));
             assertEquals(Math.pow(2.0, twoPower53 - 1), result4, 1e-10);
         }

    @Test
    public void testPowWithNegativeExponentEqualToNegativeTwoPower() {
        // Setup
        double x = -2.0; // negative base
        double twoPower53 = 9007199254740992.0; // 2^53
        double y = -twoPower53; // exactly -2^53
        
        // Expected behavior: original code should return pow(-x, y) because y <= -TWO_POWER_53
        // Mutant behavior: would skip this branch because y is not < -TWO_POWER_53 (it's equal)
        
        // Action
        double result = FastMath.pow(x, y);
        
        // Verification
        // The correct result should be the same as pow(2.0, -TWO_POWER_53) 
        // since we take absolute value of x when y <= -TWO_POWER_53
        double expected = FastMath.pow(2.0, -twoPower53);
        assertEquals("Power result should handle y == -TWO_POWER_53 correctly", 
                   expected, result, 0.0);
        
        // Additional verification that we're testing the right case
        assertTrue("Test should use y == -TWO_POWER_53", 
                  y == -twoPower53);
    }

    @Test
    public void testPowWithExactNegativeTwoPower1() {
        // Test when exponent is exactly -TWO_POWER_53
        double base = 2.0;
        double exponent = -9007199254740992.0; // -2^53
        
        // The original behavior should handle this as a special case
        // We expect either 0 or some other special handling result
        double result = FastMath.pow(base, exponent);
        
        // The exact assertion depends on what the original method does with this case
        // Since we don't have the exact implementation of the special case handling,
        // we'll verify it's either 0 or a very small positive number
        assertTrue("Result should be 0 or very small for large negative exponent", 
                  result == 0.0 || (result > 0.0 && result < Double.MIN_VALUE * 1000));
        
        // Also test with exponent exactly TWO_POWER_53 for completeness
        double positiveResult = FastMath.pow(base, 9007199254740992.0); // 2^53
        assertEquals(Double.POSITIVE_INFINITY, positiveResult, 0.0);
    }


}
