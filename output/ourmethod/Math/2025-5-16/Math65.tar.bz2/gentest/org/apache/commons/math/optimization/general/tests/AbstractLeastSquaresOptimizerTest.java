package gentest.org.apache.commons.math.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.general.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxEvaluationsExceededException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction;
import org.apache.commons.math.analysis.MultivariateMatrixFunction;
import org.apache.commons.math.exception.LocalizedFormats;
import org.apache.commons.math.linear.InvalidMatrixException;
import org.apache.commons.math.linear.LUDecompositionImpl;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.optimization.OptimizationException;
import org.apache.commons.math.optimization.SimpleVectorialValueChecker;
import org.apache.commons.math.optimization.VectorialConvergenceChecker;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.VectorialPointValuePair;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                 public void testGetRMS_PositiveValues() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                     when(optimizer.getChiSquare()).thenReturn(16.0);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set the private rows field
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 4);
                                                                                                                                                                     
                                                                                                                                                                     // Test and verify
                                                                                                                                                                     assertEquals(2.0, optimizer.getRMS(), 1e-15);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetRMS_ZeroChiSquare() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                     when(optimizer.getChiSquare()).thenReturn(0.0);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set the private rows field
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 10);
                                                                                                                                                                     
                                                                                                                                                                     // Test and verify
                                                                                                                                                                     assertEquals(0.0, optimizer.getRMS(), 1e-15);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetRMS_OneRow() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                     when(optimizer.getChiSquare()).thenReturn(9.0);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set the private rows field
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 1);
                                                                                                                                                                     
                                                                                                                                                                     // Test and verify
                                                                                                                                                                     assertEquals(3.0, optimizer.getRMS(), 1e-15);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetRMS_LargeValues() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                     when(optimizer.getChiSquare()).thenReturn(1.0E16);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set the private rows field
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 10000);
                                                                                                                                                                     
                                                                                                                                                                     // Test and verify
                                                                                                                                                                     assertEquals(1.0E6, optimizer.getRMS(), 1e-15);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetRMS_NegativeRows() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                     when(optimizer.getChiSquare()).thenReturn(4.0);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set private rows field
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.setInt(optimizer, -1);
                                                                                                                                                                     
                                                                                                                                                                     // Expect exception
                                                                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                                                                     exception.expectMessage("Number of rows cannot be negative");
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     when(optimizer.getRMS()).thenCallRealMethod();
                                                                                                                                                                     optimizer.getRMS();
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetRMS_Precision() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                     when(optimizer.getChiSquare()).thenReturn(2.0);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set private rows field
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 3);
                                                                                                                                                                     
                                                                                                                                                                     // Test and verify
                                                                                                                                                                     assertEquals(Math.sqrt(2.0/3.0), optimizer.getRMS(), 1e-15);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithPositiveValues() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     double[] residuals = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                     double[] residualsWeights = new double[]{0.5, 1.0, 1.5};
                                                                                                                                                                     int rows = 3;
                                                                                                                                                                     
                                                                                                                                                                     // Create optimizer instance and set fields via reflection
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                         @Override
                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                             return null;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     
                                                                                                                                                                     // Set private fields using reflection
                                                                                                                                                                     Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                     residualsField.setAccessible(true);
                                                                                                                                                                     residualsField.set(optimizer, residuals);
                                                                                                                                                                     
                                                                                                                                                                     Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                     weightsField.setAccessible(true);
                                                                                                                                                                     weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, rows);
                                                                                                                                                                 
                                                                                                                                                                     // Expected calculation: (1²*0.5) + (2²*1.0) + (3²*1.5) = 0.5 + 4 + 13.5 = 18.0
                                                                                                                                                                     double expected = 18.0;
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithNegativeResiduals() {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                             return null;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     double[] residuals = new double[]{-1.0, -2.0, -3.0};
                                                                                                                                                                     double[] residualsWeights = new double[]{0.5, 1.0, 1.5};
                                                                                                                                                                     
                                                                                                                                                                     try {
                                                                                                                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                         rowsField.setAccessible(true);
                                                                                                                                                                         rowsField.set(optimizer, 3);
                                                                                                                                                                         
                                                                                                                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                         residualsField.setAccessible(true);
                                                                                                                                                                         residualsField.set(optimizer, residuals);
                                                                                                                                                                         
                                                                                                                                                                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                         weightsField.setAccessible(true);
                                                                                                                                                                         weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                         fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // Expected calculation: same as positive since squared
                                                                                                                                                                     double expected = 18.0;
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithZeroWeights() {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                             return null;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     double[] residuals = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                     double[] residualsWeights = new double[]{0.0, 0.0, 0.0};
                                                                                                                                                                     
                                                                                                                                                                     try {
                                                                                                                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                         rowsField.setAccessible(true);
                                                                                                                                                                         rowsField.set(optimizer, 3);
                                                                                                                                                                         
                                                                                                                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                         residualsField.setAccessible(true);
                                                                                                                                                                         residualsField.set(optimizer, residuals);
                                                                                                                                                                         
                                                                                                                                                                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                         weightsField.setAccessible(true);
                                                                                                                                                                         weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                         fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // Expected calculation: all terms become zero
                                                                                                                                                                     double expected = 0.0;
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithMixedWeights() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                             return null;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     
                                                                                                                                                                     double[] residuals = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                     double[] residualsWeights = new double[]{0.0, 1.0, 0.5};
                                                                                                                                                                     
                                                                                                                                                                     // Set private fields using reflection
                                                                                                                                                                     java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 3);
                                                                                                                                                                     
                                                                                                                                                                     java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                     residualsField.setAccessible(true);
                                                                                                                                                                     residualsField.set(optimizer, residuals);
                                                                                                                                                                     
                                                                                                                                                                     java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                     weightsField.setAccessible(true);
                                                                                                                                                                     weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     
                                                                                                                                                                     // Expected calculation: (1²*0) + (2²*1) + (3²*0.5) = 0 + 4 + 4.5 = 8.5
                                                                                                                                                                     double expected = 8.5;
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithSingleElement() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     double[] residuals = new double[]{5.0};
                                                                                                                                                                     double[] residualsWeights = new double[]{2.0};
                                                                                                                                                                     
                                                                                                                                                                     // Create optimizer instance
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                         @Override
                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                             return null;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     
                                                                                                                                                                     // Set private fields using reflection
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 1);
                                                                                                                                                                     
                                                                                                                                                                     Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                     residualsField.setAccessible(true);
                                                                                                                                                                     residualsField.set(optimizer, residuals);
                                                                                                                                                                     
                                                                                                                                                                     Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                     residualsWeightsField.setAccessible(true);
                                                                                                                                                                     residualsWeightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     
                                                                                                                                                                     // Expected calculation: 5² * 2 = 50
                                                                                                                                                                     double expected = 50.0;
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithEmptyArrays() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                             return null;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     double[] residuals = new double[]{};
                                                                                                                                                                     double[] residualsWeights = new double[]{};
                                                                                                                                                                     
                                                                                                                                                                     // Set protected fields using reflection
                                                                                                                                                                     java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 0);
                                                                                                                                                                     
                                                                                                                                                                     java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                     residualsField.setAccessible(true);
                                                                                                                                                                     residualsField.set(optimizer, residuals);
                                                                                                                                                                     
                                                                                                                                                                     java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                     weightsField.setAccessible(true);
                                                                                                                                                                     weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     
                                                                                                                                                                     // Expected calculation: sum of nothing is zero
                                                                                                                                                                     double expected = 0.0;
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithInfiniteValues() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     double[] residuals = new double[]{Double.POSITIVE_INFINITY, 2.0};
                                                                                                                                                                     double[] residualsWeights = new double[]{1.0, 1.0};
                                                                                                                                                                     
                                                                                                                                                                     // Create optimizer instance - using concrete implementation since abstract
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                     
                                                                                                                                                                     // Set private fields using reflection
                                                                                                                                                                     Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                     residualsField.setAccessible(true);
                                                                                                                                                                     residualsField.set(optimizer, residuals);
                                                                                                                                                                     
                                                                                                                                                                     Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                     weightsField.setAccessible(true);
                                                                                                                                                                     weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 2);
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(Double.POSITIVE_INFINITY, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testGetChiSquare_WithNegativeWeights() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                         @Override
                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                             return null;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     
                                                                                                                                                                     double[] residuals = new double[]{1.0, 2.0};
                                                                                                                                                                     double[] residualsWeights = new double[]{-1.0, 1.0};
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                                     Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                     rowsField.set(optimizer, 2);
                                                                                                                                                                     
                                                                                                                                                                     Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                     residualsField.setAccessible(true);
                                                                                                                                                                     residualsField.set(optimizer, residuals);
                                                                                                                                                                     
                                                                                                                                                                     Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                     residualsWeightsField.setAccessible(true);
                                                                                                                                                                     residualsWeightsField.set(optimizer, residualsWeights);
                                                                                                                                                                     
                                                                                                                                                                     // Expected calculation: (1²*-1) + (2²*1) = -1 + 4 = 3
                                                                                                                                                                     double expected = 3.0;
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = optimizer.getChiSquare();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals(expected, result, 0.0001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                             public void testGetChiSquare_WithNaNValues() throws Exception {
                                                                                                                                                                 // Setup
                                                                                                                                                                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                     @Override
                                                                                                                                                                     protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                         return null; // Dummy implementation for test
                                                                                                                                                                     }
                                                                                                                                                                 };
                                                                                                                                                                 double[] residuals = new double[]{Double.NaN, 2.0};
                                                                                                                                                                 double[] residualsWeights = new double[]{1.0, 1.0};
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                                                 rowsField.set(optimizer, 2);
                                                                                                                                                                 
                                                                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                                                                 
                                                                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                 weightsField.setAccessible(true);
                                                                                                                                                                 weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                 
                                                                                                                                                                 // Test
                                                                                                                                                                 double result = optimizer.getChiSquare();
                                                                                                                                                                 
                                                                                                                                                                 // Verify
                                                                                                                                                                 assertTrue(Double.isNaN(result));
                                                                                                                                                             }

    @Test
                                                                                                                                                         public void testGetChiSquare_WithArraysLengthMismatch() {
                                                                                                                                                             // Setup
                                                                                                                                                             double[] residuals = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                             double[] residualsWeights = new double[]{1.0, 1.0}; // shorter than residuals
                                                                                                                                                             
                                                                                                                                                             // Create optimizer instance
                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                 @Override
                                                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                     return null;
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Set fields using reflection
                                                                                                                                                             try {
                                                                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                                                 rowsField.set(optimizer, 3);
                                                                                                                                                                 
                                                                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                                                                 
                                                                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                 weightsField.setAccessible(true);
                                                                                                                                                                 weightsField.set(optimizer, residualsWeights);
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 throw new RuntimeException(e);
                                                                                                                                                             }
                                                                                                                                                             
                                                                                                                                                             // Expect ArrayIndexOutOfBoundsException
                                                                                                                                                             ExpectedException exception = ExpectedException.none();
                                                                                                                                                             exception.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                             
                                                                                                                                                             // Test
                                                                                                                                                             optimizer.getChiSquare();
                                                                                                                                                         }

    @Test
                                                                                                                                                         public void testGetRMS_ZeroRows() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                             when(optimizer.getChiSquare()).thenReturn(10.0);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to set private rows field
                                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                                             rowsField.set(optimizer, 0);
                                                                                                                                                             
                                                                                                                                                             try {
                                                                                                                                                                 // Test
                                                                                                                                                                 optimizer.getRMS();
                                                                                                                                                                 fail("Expected ArithmeticException");
                                                                                                                                                             } catch (ArithmeticException e) {
                                                                                                                                                                 // Verify
                                                                                                                                                                 assertEquals("/ by zero", e.getMessage());
                                                                                                                                                             }
                                                                                                                                                         }

    @Test
                                                                                                                                                         public void testGetRMS_NegativeChiSquare() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                             when(optimizer.getChiSquare()).thenReturn(-4.0);
                                                                                                                                                             
                                                                                                                                                             // Set private rows field using reflection
                                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                                             rowsField.set(optimizer, 2);
                                                                                                                                                             
                                                                                                                                                             // Expect exception
                                                                                                                                                             ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                             expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                             expectedException.expectMessage("Chi-square cannot be negative");
                                                                                                                                                             
                                                                                                                                                             // Test
                                                                                                                                                             optimizer.getRMS();
                                                                                                                                                         }

    @Test
                                                                                                                                                     public void testGetChiSquareDetectsIncrementMutation() {
                                                                                                                                                         // Setup test data
                                                                                                                                                         int testRows = 3;
                                                                                                                                                         double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                                                         double[] testWeights = {0.5, 1.0, 1.5};
                                                                                                                                                         
                                                                                                                                                         // Create partial mock of the class
                                                                                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                             @Override
                                                                                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                 return null; // Not needed for this test
                                                                                                                                                             }
                                                                                                                                                         };
                                                                                                                                                         
                                                                                                                                                         // Set protected fields using reflection
                                                                                                                                                         try {
                                                                                                                                                             Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                             residualsField.setAccessible(true);
                                                                                                                                                             residualsField.set(optimizer, testResiduals);
                                                                                                                                                             
                                                                                                                                                             Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                             weightsField.setAccessible(true);
                                                                                                                                                             weightsField.set(optimizer, testWeights);
                                                                                                                                                             
                                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                                             rowsField.set(optimizer, testRows);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Failed to set up test fields via reflection");
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         // Calculate expected value manually
                                                                                                                                                         double expectedChiSquare = 0;
                                                                                                                                                         for (int i = 0; i < testRows; i++) {
                                                                                                                                                             expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         // Test the method
                                                                                                                                                         double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                         
                                                                                                                                                         // Verify the result
                                                                                                                                                         assertEquals("Chi-square calculation should be correct regardless of increment style", 
                                                                                                                                                                     expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                                         
                                                                                                                                                         // Additional edge case: single element
                                                                                                                                                         testRows = 1;
                                                                                                                                                         try {
                                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                                             rowsField.set(optimizer, testRows);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Failed to modify rows field");
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         expectedChiSquare = testResiduals[0] * testResiduals[0] * testWeights[0];
                                                                                                                                                         actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                         assertEquals("Should handle single element correctly",
                                                                                                                                                                     expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                                     }

    @Test
                                                                                                                                                        public void testGetChiSquareDetectsCostMutation() {
                                                                                                                                                            // Create a test instance by mocking the abstract class
                                                                                                                                                            AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                                                                                                                                                                CALLS_REAL_METHODS);
                                                                                                                                                            
                                                                                                                                                            // Set up test data
                                                                                                                                                            int rows = 3;
                                                                                                                                                            double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                                            double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                                                                            
                                                                                                                                                            // Set protected fields using reflection
                                                                                                                                                            try {
                                                                                                                                                                java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                    .getDeclaredField("rows");
                                                                                                                                                                rowsField.setAccessible(true);
                                                                                                                                                                rowsField.set(optimizer, rows);
                                                                                                                                                                
                                                                                                                                                                java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                    .getDeclaredField("residuals");
                                                                                                                                                                residualsField.setAccessible(true);
                                                                                                                                                                residualsField.set(optimizer, residuals);
                                                                                                                                                                
                                                                                                                                                                java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                    .getDeclaredField("residualsWeights");
                                                                                                                                                                weightsField.setAccessible(true);
                                                                                                                                                                weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                
                                                                                                                                                                java.lang.reflect.Field costField = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                    .getDeclaredField("cost");
                                                                                                                                                                costField.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Test case 1: cost > 1 (should detect mutant)
                                                                                                                                                                costField.set(optimizer, 2.0); // cost = 2
                                                                                                                                                                double expectedChiSquare1 = 0.0;
                                                                                                                                                                for (int i = 0; i < rows; i++) {
                                                                                                                                                                    expectedChiSquare1 += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                                                                                }
                                                                                                                                                                expectedChiSquare1 = Math.sqrt(2.0); // Original behavior
                                                                                                                                                                double mutantExpected1 = Math.pow(2.0, 2); // Mutant behavior
                                                                                                                                                                assertNotEquals("Should detect cost mutation for cost > 1", 
                                                                                                                                                                    mutantExpected1, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                assertEquals(expectedChiSquare1, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Test case 2: 0 < cost < 1 (should detect mutant)
                                                                                                                                                                costField.set(optimizer, 0.5); // cost = 0.5
                                                                                                                                                                double expectedChiSquare2 = 0.0;
                                                                                                                                                                for (int i = 0; i < rows; i++) {
                                                                                                                                                                    expectedChiSquare2 += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                                                                                }
                                                                                                                                                                expectedChiSquare2 = Math.sqrt(0.5); // Original behavior
                                                                                                                                                                double mutantExpected2 = Math.pow(0.5, 2); // Mutant behavior
                                                                                                                                                                assertNotEquals("Should detect cost mutation for 0 < cost < 1", 
                                                                                                                                                                    mutantExpected2, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                assertEquals(expectedChiSquare2, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Test case 3: cost = 1 (both same)
                                                                                                                                                                costField.set(optimizer, 1.0); // cost = 1
                                                                                                                                                                double expectedChiSquare3 = 0.0;
                                                                                                                                                                for (int i = 0; i < rows; i++) {
                                                                                                                                                                    expectedChiSquare3 += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                                                                                }
                                                                                                                                                                // Both original and mutant produce same result when cost = 1
                                                                                                                                                                assertEquals(1.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                              public void testCostCalculationDetectsSqrtToAbsMutation() throws FunctionEvaluationException {
                                                                                                                                                  // Create a concrete subclass that exposes protected members
                                                                                                                                                  class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                                                                                                      @Override
                                                                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                                                                          return null;
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      public void setTestData(double[] residuals, double[] weights, int rows) {
                                                                                                                                                          this.residuals = residuals;
                                                                                                                                                          this.residualsWeights = weights;
                                                                                                                                                          this.rows = rows;
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      public void callUpdateResidualsAndCost() throws FunctionEvaluationException {
                                                                                                                                                          updateResidualsAndCost();
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      public double getCostValue() {
                                                                                                                                                          return cost;
                                                                                                                                                      }
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  TestOptimizer optimizer = new TestOptimizer();
                                                                                                                                                  
                                                                                                                                                  // Set up test data where sqrt and abs would produce different results
                                                                                                                                                  optimizer.setTestData(new double[]{0.5, 2.0}, new double[]{1.0, 1.0}, 2);
                                                                                                                                                  
                                                                                                                                                  // Calculate expected chi-square value
                                                                                                                                                  double expectedChiSquare = 0.5 * 0.5 * 1.0 + 2.0 * 2.0 * 1.0; // 0.25 + 4.0 = 4.25
                                                                                                                                                  
                                                                                                                                                  // Call the method
                                                                                                                                                  double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                  
                                                                                                                                                  // Verify chi-square calculation
                                                                                                                                                  assertEquals("Chi-square calculation is incorrect", 
                                                                                                                                                               expectedChiSquare, actualChiSquare, 1e-10);
                                                                                                                                                  
                                                                                                                                                  // Now verify the cost field after update (this is where the mutation would be caught)
                                                                                                                                                  optimizer.callUpdateResidualsAndCost();
                                                                                                                                                  
                                                                                                                                                  // Expected cost is sqrt(chiSquare) = sqrt(4.25) ≈ 2.0615528128
                                                                                                                                                  // Mutated version would be abs(4.25) = 4.25
                                                                                                                                                  double expectedCost = Math.sqrt(expectedChiSquare);
                                                                                                                                                  double actualCost = optimizer.getCostValue();
                                                                                                                                                  
                                                                                                                                                  // This assertion will fail if the mutation is present
                                                                                                                                                  assertEquals("Cost calculation should use sqrt, not abs", 
                                                                                                                                                               expectedCost, actualCost, 1e-10);
                                                                                                                                              }

    @Test
                                                                                                                                          public void testGetChiSquareDetectsLoopBodyMutation() {
                                                                                                                                              // Setup test data
                                                                                                                                              int testRows = 3;
                                                                                                                                              double[] testResiduals = {1.5, 2.0, 3.5};
                                                                                                                                              double[] testWeights = {0.5, 1.0, 1.5};
                                                                                                                                              
                                                                                                                                              // Create instance and set protected fields via reflection
                                                                                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                                                                                      return null; // abstract method implementation
                                                                                                                                                  }
                                                                                                                                              };
                                                                                                                                              
                                                                                                                                              try {
                                                                                                                                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                  rowsField.setAccessible(true);
                                                                                                                                                  rowsField.set(optimizer, testRows);
                                                                                                                                                  
                                                                                                                                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                  residualsField.setAccessible(true);
                                                                                                                                                  residualsField.set(optimizer, testResiduals);
                                                                                                                                                  
                                                                                                                                                  Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                  weightsField.setAccessible(true);
                                                                                                                                                  weightsField.set(optimizer, testWeights);
                                                                                                                                              } catch (Exception e) {
                                                                                                                                                  fail("Failed to set up test fields via reflection");
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // Calculate expected value manually
                                                                                                                                              double expectedChiSquare = 0;
                                                                                                                                              for (int i = 0; i < testRows; i++) {
                                                                                                                                                  expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // Test the method
                                                                                                                                              double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                              
                                                                                                                                              // Assertions
                                                                                                                                              assertNotEquals("Chi-square should not be zero (would indicate loop body was skipped)", 
                                                                                                                                                             0.0, actualChiSquare, 0.0001);
                                                                                                                                              assertEquals("Chi-square calculation is incorrect", 
                                                                                                                                                          expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                          }

    @Test
                                                                                                                                         public void testGetChiSquare_EvaluationBoundary() {
                                                                                                                                             // Setup test data
                                                                                                                                             double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                             double[] residualsWeights = {0.5, 0.5, 0.5};
                                                                                                                                             
                                                                                                                                             // Create instance and set protected fields via reflection
                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                 @Override
                                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                                     return null;
                                                                                                                                                 }
                                                                                                                                             };
                                                                                                                                             
                                                                                                                                             // Set fields via reflection since they're protected
                                                                                                                                             try {
                                                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                                                 
                                                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                 weightsField.setAccessible(true);
                                                                                                                                                 weightsField.set(optimizer, residualsWeights);
                                                                                                                                                 
                                                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                                 rowsField.set(optimizer, residuals.length);
                                                                                                                                                 
                                                                                                                                                 // Set max evaluations to exactly 1
                                                                                                                                                 Field maxEvalField = AbstractLeastSquaresOptimizer.class.getDeclaredField("maxEvaluations");
                                                                                                                                                 maxEvalField.setAccessible(true);
                                                                                                                                                 maxEvalField.set(optimizer, 1);
                                                                                                                                                 
                                                                                                                                                 Field objEvalField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objectiveEvaluations");
                                                                                                                                                 objEvalField.setAccessible(true);
                                                                                                                                                 objEvalField.set(optimizer, 0);
                                                                                                                                             } catch (Exception e) {
                                                                                                                                                 fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                             
                                                                                                                                             // First call should work (evaluations = 1)
                                                                                                                                             double result = optimizer.getChiSquare();
                                                                                                                                             assertEquals(7.0, result, 1e-10); // 1*1*0.5 + 2*2*0.5 + 3*3*0.5 = 7.0
                                                                                                                                             
                                                                                                                                             // Verify evaluation count was incremented
                                                                                                                                             try {
                                                                                                                                                 Field objEvalField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objectiveEvaluations");
                                                                                                                                                 objEvalField.setAccessible(true);
                                                                                                                                                 int evalCount = (int)objEvalField.get(optimizer);
                                                                                                                                                 assertEquals(1, evalCount);
                                                                                                                                             } catch (Exception e) {
                                                                                                                                                 fail("Failed to verify evaluation count: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                             
                                                                                                                                             // Second call should throw if mutant is present (>= instead of >)
                                                                                                                                             try {
                                                                                                                                                 optimizer.getChiSquare();
                                                                                                                                                 // If we get here, mutant was not caught (original behavior)
                                                                                                                                             } catch (Exception e) {
                                                                                                                                                 fail("Original code should allow exactly maxEvaluations calls, but mutant triggers one call earlier");
                                                                                                                                             }
                                                                                                                                         }

    @Test
                                                                                                                                       public void testGetChiSquareVerifiesFunctionCall() throws Exception {
                                                                                                                                           // Setup test data
                                                                                                                                           double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                                           double[] testWeights = {0.5, 0.5, 0.5};
                                                                                                                                           int testRows = 3;
                                                                                                                                           
                                                                                                                                           // Create partial mock of the abstract class
                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                           
                                                                                                                                           // Setup mock behavior
                                                                                                                                           when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                                                                           
                                                                                                                                           // Set private fields via reflection
                                                                                                                                           Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                           residualsField.setAccessible(true);
                                                                                                                                           residualsField.set(optimizer, testResiduals);
                                                                                                                                           
                                                                                                                                           Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                           weightsField.setAccessible(true);
                                                                                                                                           weightsField.set(optimizer, testWeights);
                                                                                                                                           
                                                                                                                                           Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                           rowsField.setAccessible(true);
                                                                                                                                           rowsField.set(optimizer, testRows);
                                                                                                                                           
                                                                                                                                           // Call the method
                                                                                                                                           double result = optimizer.getChiSquare();
                                                                                                                                           
                                                                                                                                           // Verify the calculation is correct
                                                                                                                                           double expectedChiSquare = 0;
                                                                                                                                           for (int i = 0; i < 3; i++) {
                                                                                                                                               expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                                           }
                                                                                                                                           assertEquals(expectedChiSquare, result, 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                  public void testGetChiSquare_ShouldThrowWhenLengthsDiffer() {
                                                                                                                                      // Arrange
                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                          @Override
                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                              return null;
                                                                                                                                          }
                                                                                                                                      };
                                                                                                                                      
                                                                                                                                      // Use reflection to set private fields
                                                                                                                                      try {
                                                                                                                                          Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                          rowsField.setAccessible(true);
                                                                                                                                          rowsField.set(optimizer, 3);
                                                                                                                                          
                                                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                          residualsField.setAccessible(true);
                                                                                                                                          residualsField.set(optimizer, new double[3]); // length matches rows
                                                                                                                                          
                                                                                                                                          Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                          residualsWeightsField.setAccessible(true);
                                                                                                                                          residualsWeightsField.set(optimizer, new double[3]); // length matches rows
                                                                                                                                          
                                                                                                                                          Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                          objectiveField.setAccessible(true);
                                                                                                                                          objectiveField.set(optimizer, new double[4]); // different length to cause exception
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Act & Assert
                                                                                                                                      try {
                                                                                                                                          optimizer.getChiSquare();
                                                                                                                                          fail("Expected exception not thrown");
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          // Expected exception
                                                                                                                                          assertTrue(e instanceof IllegalArgumentException || 
                                                                                                                                                    e instanceof ArrayIndexOutOfBoundsException);
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                                              public void testGetChiSquare_ShouldPassWhenLengthsMatch() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                  
                                                                                                                                  // Set up residuals and weights arrays using reflection
                                                                                                                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                  residualsField.setAccessible(true);
                                                                                                                                  residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                  
                                                                                                                                  Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                  weightsField.setAccessible(true);
                                                                                                                                  weightsField.set(optimizer, new double[]{0.5, 0.5, 0.5});
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  double result = optimizer.getChiSquare();
                                                                                                                                  
                                                                                                                                  // Assert - no exception expected
                                                                                                                                  // Verify calculation is correct
                                                                                                                                  double expected = 1.0*1.0*0.5 + 2.0*2.0*0.5 + 3.0*3.0*0.5;
                                                                                                                                  assertEquals(expected, result, 0.0001);
                                                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                         public void testGetChiSquare_WhenObjectiveLengthLessThanRows_ShouldThrowException() throws Exception {
                                                                                                                             // Create concrete optimizer instance
                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                 @Override
                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                     return null;
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Use reflection to set private fields
                                                                                                                             Class<?> optimizerClass = optimizer.getClass();
                                                                                                                             
                                                                                                                             // Set rows field
                                                                                                                             Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                             rowsField.setAccessible(true);
                                                                                                                             rowsField.setInt(optimizer, 5);
                                                                                                                             
                                                                                                                             // Set objective field (length < rows)
                                                                                                                             Field objectiveField = optimizerClass.getDeclaredField("objective");
                                                                                                                             objectiveField.setAccessible(true);
                                                                                                                             objectiveField.set(optimizer, new double[4]);
                                                                                                                             
                                                                                                                             // Set residuals field
                                                                                                                             Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                             residualsField.setAccessible(true);
                                                                                                                             residualsField.set(optimizer, new double[5]);
                                                                                                                             
                                                                                                                             // Set residualsWeights field
                                                                                                                             Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                             residualsWeightsField.setAccessible(true);
                                                                                                                             residualsWeightsField.set(optimizer, new double[5]);
                                                                                                                             
                                                                                                                             // This should throw IllegalArgumentException
                                                                                                                             optimizer.getChiSquare();
                                                                                                                         }

    @Test
                                                                                                                         public void testGetChiSquare_WhenObjectiveLengthEqualsRows_ShouldCalculateCorrectly() throws Exception {
                                                                                                                             // Setup
                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                 @Override
                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                     return null;
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Use reflection to set private fields
                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                             rowsField.setAccessible(true);
                                                                                                                             rowsField.set(optimizer, 3);
                                                                                                                             
                                                                                                                             Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                             objectiveField.setAccessible(true);
                                                                                                                             objectiveField.set(optimizer, new double[3]);
                                                                                                                             
                                                                                                                             Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                             residualsField.setAccessible(true);
                                                                                                                             residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                             
                                                                                                                             Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                             residualsWeightsField.setAccessible(true);
                                                                                                                             residualsWeightsField.set(optimizer, new double[]{0.5, 0.5, 0.5});
                                                                                                                             
                                                                                                                             // Expected chi-square = (1²*0.5) + (2²*0.5) + (3²*0.5) = 0.5 + 2 + 4.5 = 7.0
                                                                                                                             double expected = 7.0;
                                                                                                                             double actual = optimizer.getChiSquare();
                                                                                                                             
                                                                                                                             assertEquals(expected, actual, 0.0001);
                                                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                     public void testGetChiSquare_WhenObjectiveLengthGreaterThanRows_ShouldThrowException() throws Exception {
                                                                                                                         // Setup
                                                                                                                         // Create an instance of AbstractLeastSquaresOptimizer for testing
                                                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                             @Override
                                                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                                                 return null;
                                                                                                                             }
                                                                                                                         };
                                                                                                                         
                                                                                                                         // Use reflection to set private fields
                                                                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                         rowsField.setAccessible(true);
                                                                                                                         rowsField.setInt(optimizer, 5);
                                                                                                                         
                                                                                                                         Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                         objectiveField.setAccessible(true);
                                                                                                                         objectiveField.set(optimizer, new double[6]); // length > rows
                                                                                                                         
                                                                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                         residualsField.setAccessible(true);
                                                                                                                         residualsField.set(optimizer, new double[5]);
                                                                                                                         
                                                                                                                         Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                         residualsWeightsField.setAccessible(true);
                                                                                                                         residualsWeightsField.set(optimizer, new double[5]);
                                                                                                                         
                                                                                                                         // This should throw IllegalArgumentException
                                                                                                                         optimizer.getChiSquare();
                                                                                                                     }

    @Test
                                                                                                                public void testGetChiSquareThrowsExceptionWithPoint() throws Exception {
                                                                                                                    // Create a test instance of the abstract class
                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                        @Override
                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                            return null; // Not needed for this test
                                                                                                                        }
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Use reflection to set protected fields
                                                                                                                    try {
                                                                                                                        Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                                                                                        pointField.setAccessible(true);
                                                                                                                        pointField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                        
                                                                                                                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                        residualsField.setAccessible(true);
                                                                                                                        residualsField.set(optimizer, new double[3]);
                                                                                                                        
                                                                                                                        Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                        weightsField.setAccessible(true);
                                                                                                                        weightsField.set(optimizer, new double[2]);
                                                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                        throw new RuntimeException("Failed to set protected fields via reflection", e);
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Expect the exception and verify it contains the correct message
                                                                                                                    thrown.expect(FunctionEvaluationException.class);
                                                                                                                    thrown.expectMessage(LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE.toString());
                                                                                                                    
                                                                                                                    // Trigger the method that should throw the exception
                                                                                                                    optimizer.getChiSquare();
                                                                                                                }

    @Test
                                                                                                            public void testGetChiSquareDetectsInitializationMutant() {
                                                                                                                // Setup test data
                                                                                                                double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                double[] residualsWeights = {1.0, 1.0, 1.0};
                                                                                                                int rows = residuals.length;
                                                                                                                
                                                                                                                // Create partial mock of the class under test
                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                    @Override
                                                                                                                    protected VectorialPointValuePair doOptimize() {
                                                                                                                        return null; // Not needed for this test
                                                                                                                    }
                                                                                                                };
                                                                                                                
                                                                                                                // Set protected fields using reflection
                                                                                                                try {
                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                    residualsField.setAccessible(true);
                                                                                                                    residualsField.set(optimizer, residuals);
                                                                                                                    
                                                                                                                    Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                    weightsField.setAccessible(true);
                                                                                                                    weightsField.set(optimizer, residualsWeights);
                                                                                                                    
                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                    rowsField.setAccessible(true);
                                                                                                                    rowsField.set(optimizer, rows);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to set up test fields via reflection");
                                                                                                                }
                                                                                                                
                                                                                                                // Calculate expected value (1²*1 + 2²*1 + 3²*1 = 1 + 4 + 9 = 14)
                                                                                                                double expected = 14.0;
                                                                                                                
                                                                                                                // Call method and verify
                                                                                                                double actual = optimizer.getChiSquare();
                                                                                                                assertEquals("Chi-square calculation should not have initial offset of 1", 
                                                                                                                             expected, actual, 0.0001);
                                                                                                                
                                                                                                                // Additional assertion to specifically catch the mutant
                                                                                                                assertNotEquals("Mutant detection: result should not be expected + 1", 
                                                                                                                               expected + 1, actual, 0.0001);
                                                                                                            }

    @Test
                                                                                                           public void testGetChiSquareDetectsInitializationMutant1() {
                                                                                                               // Setup test data
                                                                                                               int testRows = 3;
                                                                                                               double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                               double[] testWeights = {0.5, 1.0, 1.5};
                                                                                                               
                                                                                                               // Create partial mock of the class
                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                   @Override
                                                                                                                   protected VectorialPointValuePair doOptimize() {
                                                                                                                       return null; // Not needed for this test
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Set protected fields using reflection for testing
                                                                                                               try {
                                                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                   rowsField.setAccessible(true);
                                                                                                                   rowsField.set(optimizer, testRows);
                                                                                                                   
                                                                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                   residualsField.setAccessible(true);
                                                                                                                   residualsField.set(optimizer, testResiduals);
                                                                                                                   
                                                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                   weightsField.setAccessible(true);
                                                                                                                   weightsField.set(optimizer, testWeights);
                                                                                                               } catch (Exception e) {
                                                                                                                   fail("Failed to set up test fields via reflection");
                                                                                                               }
                                                                                                               
                                                                                                               // Calculate expected value manually
                                                                                                               double expectedChiSquare = 0; // Original initialization
                                                                                                               for (int i = 0; i < testRows; i++) {
                                                                                                                   expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                               }
                                                                                                               
                                                                                                               // Test the method
                                                                                                               double actualChiSquare = optimizer.getChiSquare();
                                                                                                               
                                                                                                               // Assert exact equality to catch the -1 initialization mutant
                                                                                                               assertEquals("Chi-square calculation should match expected value", 
                                                                                                                           expectedChiSquare, actualChiSquare, 0.0);
                                                                                                               
                                                                                                               // Additional assertion to specifically catch the -1 mutant
                                                                                                               assertNotEquals("Should detect initialization mutant", 
                                                                                                                              expectedChiSquare - 1, actualChiSquare, 0.0);
                                                                                                           }

    @Test
                                                                                                         public void testGetChiSquareDetectsIndexMutation() {
                                                                                                             // Setup test data - need at least 2 residuals to detect the mutation
                                                                                                             double[] residuals = {2.0, 3.0}; // residuals[0] = 2.0, residuals[1] = 3.0
                                                                                                             double[] residualsWeights = {1.0, 1.0}; // equal weights for simplicity
                                                                                                             
                                                                                                             // Create a partial mock of the class to test
                                                                                                             AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                             
                                                                                                             // Set the mock to use our test data
                                                                                                             // Using reflection to access protected fields since we can't mock them directly
                                                                                                             try {
                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                 residualsField.setAccessible(true);
                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                 
                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                 weightsField.setAccessible(true);
                                                                                                                 weightsField.set(optimizer, residualsWeights);
                                                                                                                 
                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                 rowsField.setAccessible(true);
                                                                                                                 rowsField.set(optimizer, residuals.length);
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Failed to set up test data via reflection: " + e.getMessage());
                                                                                                             }
                                                                                                             
                                                                                                             // Stub the actual method call to use the real implementation
                                                                                                             when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                                             
                                                                                                             // Calculate expected value manually (including all residuals)
                                                                                                             double expectedChiSquare = residuals[0]*residuals[0]*residualsWeights[0] 
                                                                                                                                     + residuals[1]*residuals[1]*residualsWeights[1];
                                                                                                             
                                                                                                             // Call the method and verify
                                                                                                             double actualChiSquare = optimizer.getChiSquare();
                                                                                                             
                                                                                                             // Assert the result matches expected calculation
                                                                                                             assertEquals("Chi-square calculation should include all residuals", 
                                                                                                                         expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                             
                                                                                                             // Additional verification that the first residual was processed
                                                                                                             // If the mutant exists (starting at i=1), the result would be 9.0 instead of 13.0
                                                                                                             assertTrue("First residual must be included in calculation",
                                                                                                                       actualChiSquare > residuals[1]*residuals[1]*residualsWeights[1]);
                                                                                                         }

    @Test
                                                                                                    public void testGetChiSquareWithNegativeIndex() throws Exception {
                                                                                                        // Create a test instance
                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                            @Override
                                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                                return null; // dummy implementation
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Set up test data using reflection
                                                                                                        Class<?> optimizerClass = optimizer.getClass();
                                                                                                        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                        rowsField.setAccessible(true);
                                                                                                        rowsField.set(optimizer, 2);
                                                                                                        
                                                                                                        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                        residualsField.setAccessible(true);
                                                                                                        residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                        
                                                                                                        java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                        residualsWeightsField.setAccessible(true);
                                                                                                        residualsWeightsField.set(optimizer, new double[]{0.5, 0.5});
                                                                                                        
                                                                                                        // This should throw ArrayIndexOutOfBoundsException with the mutant
                                                                                                        // because it will try to access array[-1]
                                                                                                        optimizer.getChiSquare();
                                                                                                        
                                                                                                        // If no exception is thrown, verify the calculation is correct
                                                                                                        // (this part won't be reached if mutant is present)
                                                                                                        double expected = 1.0*1.0*0.5 + 2.0*2.0*0.5; // 0.5 + 2.0 = 2.5
                                                                                                        assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                                                    }

    @Test
                                                                                                    public void testGetChiSquareNormalCase() throws Exception {
                                                                                                        // Create a test instance
                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                            @Override
                                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                                return null; // dummy implementation
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Use reflection to set protected fields
                                                                                                        Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                        rowsField.setAccessible(true);
                                                                                                        rowsField.set(optimizer, 3);
                                                                                                        
                                                                                                        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                        residualsField.setAccessible(true);
                                                                                                        residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                        
                                                                                                        java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                        residualsWeightsField.setAccessible(true);
                                                                                                        residualsWeightsField.set(optimizer, new double[]{1.0, 0.5, 0.1});
                                                                                                        
                                                                                                        // Calculate expected value
                                                                                                        double expected = 1.0*1.0*1.0 + 2.0*2.0*0.5 + 3.0*3.0*0.1;
                                                                                                        expected = 1.0 + 2.0 + 0.9; // 3.9
                                                                                                        
                                                                                                        assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                                                    }

    @Test
                                                                                                    public void testGetChiSquareEmptyArray() throws Exception {
                                                                                                        // Create a test instance
                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                            @Override
                                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                                return null; // dummy implementation
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Use reflection to set protected fields
                                                                                                        Class<?> optimizerClass = optimizer.getClass();
                                                                                                        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                        rowsField.setAccessible(true);
                                                                                                        rowsField.set(optimizer, 0);
                                                                                                        
                                                                                                        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                        residualsField.setAccessible(true);
                                                                                                        residualsField.set(optimizer, new double[0]);
                                                                                                        
                                                                                                        java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                        residualsWeightsField.setAccessible(true);
                                                                                                        residualsWeightsField.set(optimizer, new double[0]);
                                                                                                        
                                                                                                        assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                    }

    @Test
                                                                                                public void testGetChiSquareDetectsArrayBoundaryMutation() {
                                                                                                    // Setup test data
                                                                                                    double[] residuals = {1.0, 2.0, 3.0};
                                                                                                    double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                    int rows = residuals.length;
                                                                                                    
                                                                                                    // Create partial mock of the class under test
                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                        @Override
                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                            return null; // Not needed for this test
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    // Set protected fields using reflection
                                                                                                    try {
                                                                                                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                        residualsField.setAccessible(true);
                                                                                                        residualsField.set(optimizer, residuals);
                                                                                                        
                                                                                                        Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                        weightsField.setAccessible(true);
                                                                                                        weightsField.set(optimizer, residualsWeights);
                                                                                                        
                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                        rowsField.setAccessible(true);
                                                                                                        rowsField.set(optimizer, rows);
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Failed to set up test fields via reflection");
                                                                                                    }
                                                                                                    
                                                                                                    // Calculate expected value (1.0^2*0.5 + 2.0^2*1.0 + 3.0^2*1.5)
                                                                                                    double expected = 0.5 + 4.0 + 13.5;
                                                                                                    
                                                                                                    // Test original behavior
                                                                                                    assertEquals(expected, optimizer.getChiSquare(), 1e-10);
                                                                                                    
                                                                                                    // Now test the mutated version would fail
                                                                                                    try {
                                                                                                        // Simulate the mutated version by setting rows to array length - 1
                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                        rowsField.setAccessible(true);
                                                                                                        rowsField.set(optimizer, rows - 1);
                                                                                                        
                                                                                                        // This should throw ArrayIndexOutOfBoundsException for the mutated version
                                                                                                        optimizer.getChiSquare();
                                                                                                        fail("Mutated version should have thrown ArrayIndexOutOfBoundsException");
                                                                                                    } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                        // Expected for mutated version
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                                                                    }
                                                                                                }

    @Test
                                                                                              public void testGetChiSquareDetectsFirstRowSkippingMutant() throws Exception {
                                                                                                  // Setup test data where first row makes significant contribution
                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                      @Override
                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                          return null; // dummy implementation
                                                                                                      }
                                                                                                  };
                                                                                                  
                                                                                                  // Use reflection to access protected fields
                                                                                                  Class<?> optimizerClass = optimizer.getClass();
                                                                                                  
                                                                                                  // Set rows to 2 to make verification simple
                                                                                                  Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                  rowsField.setAccessible(true);
                                                                                                  rowsField.setInt(optimizer, 2);
                                                                                                  
                                                                                                  // Create residuals where first element is significant
                                                                                                  Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                  residualsField.setAccessible(true);
                                                                                                  residualsField.set(optimizer, new double[]{2.0, 1.0}); // First residual is larger
                                                                                                  
                                                                                                  // Create weights (all 1.0 for simplicity)
                                                                                                  Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                  residualsWeightsField.setAccessible(true);
                                                                                                  residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                  
                                                                                                  // Calculate expected value (including first row)
                                                                                                  double expected = (2.0 * 2.0 * 1.0) + (1.0 * 1.0 * 1.0); // 4 + 1 = 5
                                                                                                  
                                                                                                  // Verify the calculation
                                                                                                  assertEquals("Chi-square should include first row's contribution", 
                                                                                                               expected, optimizer.getChiSquare(), 0.0001);
                                                                                                  
                                                                                                  // This test will fail with the mutant because:
                                                                                                  // Mutant would calculate only (1.0 * 1.0 * 1.0) = 1
                                                                                                  // While original calculates (4 + 1) = 5
                                                                                              }

    @Test
                                                                                         public void testGetChiSquareDetectsResidualCalculationMutant() throws Exception {
                                                                                             // Setup test data that will clearly show the difference between subtraction and addition
                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                 @Override
                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                     return null; // Not needed for this test
                                                                                                 }
                                                                                             };
                                                                                             
                                                                                             // Use reflection to set protected fields
                                                                                             Class<?> optimizerClass = optimizer.getClass();
                                                                                             
                                                                                             // Set rows
                                                                                             Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                             rowsField.setAccessible(true);
                                                                                             rowsField.setInt(optimizer, 2);
                                                                                             
                                                                                             // Set targetValues
                                                                                             Field targetValuesField = optimizerClass.getDeclaredField("targetValues");
                                                                                             targetValuesField.setAccessible(true);
                                                                                             targetValuesField.set(optimizer, new double[]{5.0, 3.0});
                                                                                             
                                                                                             // Set objective
                                                                                             Field objectiveField = optimizerClass.getDeclaredField("objective");
                                                                                             objectiveField.setAccessible(true);
                                                                                             objectiveField.set(optimizer, new double[]{2.0, 1.0});
                                                                                             
                                                                                             // Set residualsWeights
                                                                                             Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                             residualsWeightsField.setAccessible(true);
                                                                                             residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                             
                                                                                             // Calculate expected chi-square using correct subtraction formula
                                                                                             double expectedChiSquare = 0;
                                                                                             double[] targetValues = (double[]) targetValuesField.get(optimizer);
                                                                                             double[] objective = (double[]) objectiveField.get(optimizer);
                                                                                             double[] residualsWeights = (double[]) residualsWeightsField.get(optimizer);
                                                                                             int rows = rowsField.getInt(optimizer);
                                                                                             
                                                                                             for (int i = 0; i < rows; i++) {
                                                                                                 double residual = targetValues[i] - objective[i];
                                                                                                 expectedChiSquare += residual * residual * residualsWeights[i];
                                                                                             }
                                                                                             
                                                                                             // Calculate what mutant would produce (using addition)
                                                                                             double mutantChiSquare = 0;
                                                                                             for (int i = 0; i < rows; i++) {
                                                                                                 double residual = targetValues[i] + objective[i];
                                                                                                 mutantChiSquare += residual * residual * residualsWeights[i];
                                                                                             }
                                                                                             
                                                                                             // Verify the actual result matches expected (not mutant) calculation
                                                                                             double actualChiSquare = optimizer.getChiSquare();
                                                                                             assertEquals("Chi-square calculation should use subtraction for residuals", 
                                                                                                          expectedChiSquare, actualChiSquare, 0.0001);
                                                                                             
                                                                                             // Additional assertion to ensure we're not getting the mutant value
                                                                                             assertNotEquals("Chi-square should not match mutant calculation", 
                                                                                                            mutantChiSquare, actualChiSquare, 0.0001);
                                                                                         }

    @Test
                                                                                     public void testGetChiSquareDetectsResidualSignMutation() {
                                                                                         // Setup test data where target and objective differ
                                                                                         double[] targetValues = {2.0, 3.0, 4.0};
                                                                                         double[] objective = {1.0, 4.0, 3.0};
                                                                                         // Use weights that are different for positive vs negative residuals
                                                                                         double[] residualsWeights = {1.0, 2.0, 1.0}; // Different weight for positive residual
                                                                                         
                                                                                         // Create test instance
                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                             @Override
                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                 return null; // Not needed for this test
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Set protected fields through reflection
                                                                                         try {
                                                                                             Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                                                                             targetField.setAccessible(true);
                                                                                             targetField.set(optimizer, targetValues);
                                                                                             
                                                                                             Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                             objectiveField.setAccessible(true);
                                                                                             objectiveField.set(optimizer, objective);
                                                                                             
                                                                                             Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                             weightsField.setAccessible(true);
                                                                                             weightsField.set(optimizer, residualsWeights);
                                                                                             
                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                             rowsField.setAccessible(true);
                                                                                             rowsField.set(optimizer, targetValues.length);
                                                                                         } catch (Exception e) {
                                                                                             fail("Failed to set up test fields via reflection");
                                                                                         }
                                                                                         
                                                                                         // Calculate expected value manually
                                                                                         double expected = 0;
                                                                                         for (int i = 0; i < targetValues.length; i++) {
                                                                                             double residual = targetValues[i] - objective[i];
                                                                                             expected += residual * residual * residualsWeights[i];
                                                                                         }
                                                                                         
                                                                                         // Test
                                                                                         assertEquals("Chi-square calculation should be sensitive to residual sign", 
                                                                                                     expected, optimizer.getChiSquare(), 1e-10);
                                                                                         
                                                                                         // The mutant would calculate:
                                                                                         // residual = objective[i] - targetValues[i] (sign flipped)
                                                                                         // But since weights are different for positive/negative residuals,
                                                                                         // the mutant would produce a different result
                                                                                     }

    @Test
                                                                                    public void testGetChiSquareDetectsResidualMutation() {
                                                                                        // Setup test data
                                                                                        int testRows = 2;
                                                                                        double[] testResiduals = {1.5, 2.0};  // Non-zero residuals
                                                                                        double[] testWeights = {1.0, 1.0};    // Simple weights for easy calculation
                                                                                        
                                                                                        // Create instance and set protected fields via reflection
                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                            @Override
                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                return null; // dummy implementation
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        try {
                                                                                            // Set protected fields using reflection
                                                                                            Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                            residualsField.setAccessible(true);
                                                                                            residualsField.set(optimizer, testResiduals);
                                                                                            
                                                                                            Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                            weightsField.setAccessible(true);
                                                                                            weightsField.set(optimizer, testWeights);
                                                                                            
                                                                                            Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                            rowsField.setAccessible(true);
                                                                                            rowsField.set(optimizer, testRows);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set up test fields via reflection");
                                                                                        }
                                                                                        
                                                                                        // Calculate expected value: (1.5^2)*1.0 + (2.0^2)*1.0 = 2.25 + 4.0 = 6.25
                                                                                        double expectedChiSquare = 6.25;
                                                                                        
                                                                                        // Test the method
                                                                                        double actualChiSquare = optimizer.getChiSquare();
                                                                                        
                                                                                        // Assert the result - this will fail if mutation is present (would get 0)
                                                                                        assertEquals("Chi-square calculation incorrect", expectedChiSquare, actualChiSquare, 0.0001);
                                                                                    }

    @Test
                                                                                   public void testGetChiSquareDetectsIndexMutation1() {
                                                                                       // Setup test data with distinct values
                                                                                       double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                       double[] testWeights = {0.5, 0.3, 0.2};
                                                                                       
                                                                                       // Create test instance and set protected fields via reflection
                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                           @Override
                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                               return null;
                                                                                           }
                                                                                       };
                                                                                       
                                                                                       try {
                                                                                           // Set protected fields using reflection
                                                                                           Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                           residualsField.setAccessible(true);
                                                                                           residualsField.set(optimizer, testResiduals);
                                                                                           
                                                                                           Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                           weightsField.setAccessible(true);
                                                                                           weightsField.set(optimizer, testWeights);
                                                                                           
                                                                                           Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                           rowsField.setAccessible(true);
                                                                                           rowsField.set(optimizer, testResiduals.length);
                                                                                       } catch (Exception e) {
                                                                                           fail("Failed to set up test fields via reflection");
                                                                                       }
                                                                                       
                                                                                       // Calculate expected value manually
                                                                                       double expected = 0;
                                                                                       for (int i = 0; i < testResiduals.length; i++) {
                                                                                           expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                       }
                                                                                       
                                                                                       // Test and verify
                                                                                       double actual = optimizer.getChiSquare();
                                                                                       assertEquals("Chi-square calculation should use correct residual-weight pairs", 
                                                                                                   expected, actual, 0.0001);
                                                                                       
                                                                                       // Additional verification that wrong pairing would produce different result
                                                                                       double wrongPairingResult = 0;
                                                                                       for (int i = 0; i < testResiduals.length; i++) {
                                                                                           // Simulate wrong pairing that would happen with index -= cols mutation
                                                                                           int wrongIndex = testResiduals.length - 1 - i;
                                                                                           wrongPairingResult += testResiduals[i] * testResiduals[i] * testWeights[wrongIndex];
                                                                                       }
                                                                                       assertNotEquals("Test should detect if wrong pairs are used", 
                                                                                                      wrongPairingResult, actual, 0.0001);
                                                                                   }

    @Test
                                                                                  public void testGetChiSquareWithMultipleRows() {
                                                                                      // Setup test data
                                                                                      int testRows = 3;
                                                                                      int testCols = 2;
                                                                                      double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                      double[] testWeights = {0.5, 1.0, 1.5};
                                                                                      
                                                                                      // Create instance and set test values
                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                          @Override
                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                              return null; // dummy implementation
                                                                                          }
                                                                                      };
                                                                                      
                                                                                      // Use reflection to set protected fields since they're not publicly accessible
                                                                                      try {
                                                                                          Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                          rowsField.setAccessible(true);
                                                                                          rowsField.set(optimizer, testRows);
                                                                                          
                                                                                          Field colsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cols");
                                                                                          colsField.setAccessible(true);
                                                                                          colsField.set(optimizer, testCols);
                                                                                          
                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                          residualsField.setAccessible(true);
                                                                                          residualsField.set(optimizer, testResiduals);
                                                                                          
                                                                                          Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                          weightsField.setAccessible(true);
                                                                                          weightsField.set(optimizer, testWeights);
                                                                                      } catch (Exception e) {
                                                                                          fail("Failed to set test fields via reflection");
                                                                                      }
                                                                                      
                                                                                      // Calculate expected value manually
                                                                                      double expected = 0.0;
                                                                                      for (int i = 0; i < testRows; i++) {
                                                                                          expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                      }
                                                                                      
                                                                                      // Test the method
                                                                                      double actual = optimizer.getChiSquare();
                                                                                      assertEquals("Chi-square calculation should correctly process all rows", 
                                                                                                   expected, actual, 1e-10);
                                                                                      
                                                                                      // Additional test to verify all residuals were processed
                                                                                      // If mutation exists, this would fail as only first residual would be used
                                                                                      assertNotEquals("Should use all residuals, not just first",
                                                                                                     testResiduals[0] * testResiduals[0] * testWeights[0],
                                                                                                     actual, 1e-10);
                                                                                  }

    @Test
                                                                                     public void testGetChiSquareProcessesAllElements() {
                                                                                         // Create a test instance by mocking the abstract class
                                                                                         AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                                                                                             CALLS_REAL_METHODS);
                                                                                         
                                                                                         // Set up test data
                                                                                         int testRows = 3;
                                                                                         double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                         double[] testWeights = {0.5, 1.0, 1.5};
                                                                                         
                                                                                         // Set protected fields using reflection
                                                                                         try {
                                                                                             java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                                                                 .getDeclaredField("rows");
                                                                                             rowsField.setAccessible(true);
                                                                                             rowsField.set(optimizer, testRows);
                                                                                             
                                                                                             java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                                                                                                 .getDeclaredField("residuals");
                                                                                             residualsField.setAccessible(true);
                                                                                             residualsField.set(optimizer, testResiduals);
                                                                                             
                                                                                             java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                                                                                                 .getDeclaredField("residualsWeights");
                                                                                             weightsField.setAccessible(true);
                                                                                             weightsField.set(optimizer, testWeights);
                                                                                         } catch (Exception e) {
                                                                                             fail("Failed to set up test fields via reflection");
                                                                                         }
                                                                                         
                                                                                         // Calculate expected value manually
                                                                                         double expected = 0;
                                                                                         for (int i = 0; i < testRows; i++) {
                                                                                             expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                         }
                                                                                         
                                                                                         // Test the method
                                                                                         double actual = optimizer.getChiSquare();
                                                                                         
                                                                                         // Verify all elements were processed
                                                                                         assertEquals("Chi-square calculation should process all elements", 
                                                                                             expected, actual, 0.0001);
                                                                                     }

    @Test
                                                                                     public void testGetChiSquareWithEmptyArray() {
                                                                                         // Create a test instance by mocking the abstract class
                                                                                         AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                                                                                             CALLS_REAL_METHODS);
                                                                                         
                                                                                         // Set up empty test data
                                                                                         int testRows = 0;
                                                                                         double[] testResiduals = new double[0];
                                                                                         double[] testWeights = new double[0];
                                                                                         
                                                                                         // Set protected fields using reflection
                                                                                         try {
                                                                                             java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                                                                 .getDeclaredField("rows");
                                                                                             rowsField.setAccessible(true);
                                                                                             rowsField.set(optimizer, testRows);
                                                                                             
                                                                                             java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                                                                                                 .getDeclaredField("residuals");
                                                                                             residualsField.setAccessible(true);
                                                                                             residualsField.set(optimizer, testResiduals);
                                                                                             
                                                                                             java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                                                                                                 .getDeclaredField("residualsWeights");
                                                                                             weightsField.setAccessible(true);
                                                                                             weightsField.set(optimizer, testWeights);
                                                                                         } catch (Exception e) {
                                                                                             fail("Failed to set up test fields via reflection");
                                                                                         }
                                                                                         
                                                                                         // Test the method with empty arrays
                                                                                         double result = optimizer.getChiSquare();
                                                                                         
                                                                                         // Verify result is 0 when no elements to process
                                                                                         assertEquals("Chi-square should be 0 for empty arrays", 
                                                                                             0.0, result, 0.0001);
                                                                                     }

    @Test
                                                                               public void testGetChiSquareDetectsSqrtToPowMutation() {
                                                                                   // Setup test data
                                                                                   double[] residuals = {1.0, 2.0, 3.0};
                                                                                   double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                   int rows = residuals.length;
                                                                                   double initialCost = 4.0; // sqrt(4)=2, pow(4,2)=16
                                                                                   
                                                                                   // Create test instance
                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                       @Override
                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                           return null;
                                                                                       }
                                                                                   };
                                                                                   
                                                                                   // Set protected fields via reflection for testing
                                                                                   try {
                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                       residualsField.setAccessible(true);
                                                                                       residualsField.set(optimizer, residuals);
                                                                                       
                                                                                       Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                       weightsField.setAccessible(true);
                                                                                       weightsField.set(optimizer, residualsWeights);
                                                                                       
                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                       rowsField.setAccessible(true);
                                                                                       rowsField.set(optimizer, rows);
                                                                                       
                                                                                       // Set cost to a known value that will show difference between sqrt and pow
                                                                                       Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                       costField.setAccessible(true);
                                                                                       costField.set(optimizer, initialCost);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                   }
                                                                                   
                                                                                   // Calculate expected value manually
                                                                                   double expectedChiSquare = 0;
                                                                                   for (int i = 0; i < rows; i++) {
                                                                                       expectedChiSquare += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                   }
                                                                                   expectedChiSquare += Math.sqrt(initialCost); // Original behavior
                                                                                   
                                                                                   // Get actual value
                                                                                   double actualChiSquare = optimizer.getChiSquare();
                                                                                   
                                                                                   // Assert - this will fail if mutation is present
                                                                                   assertEquals("Chi-square calculation should include square root of cost", 
                                                                                               expectedChiSquare, actualChiSquare, 1e-10);
                                                                                   
                                                                                   // Additional assertion to specifically catch the mutation
                                                                                   double mutatedValue = expectedChiSquare - Math.sqrt(initialCost) + Math.pow(initialCost, 2);
                                                                                   assertNotEquals("Test should detect sqrt->pow mutation", 
                                                                                                  mutatedValue, actualChiSquare, 1e-10);
                                                                               }

    @Test
                                                                          public void testCostCalculationDetectsSqrtToAbsMutation1() throws Exception {
                                                                              // Setup test object
                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                  @Override
                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                      return null; // dummy implementation
                                                                                  }
                                                                              };
                                                                              
                                                                              // Use reflection to set up test data
                                                                              Class<?> optimizerClass = optimizer.getClass();
                                                                              Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                              residualsField.setAccessible(true);
                                                                              residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                              
                                                                              Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                              weightsField.setAccessible(true);
                                                                              weightsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                                                                              
                                                                              Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                              rowsField.setAccessible(true);
                                                                              rowsField.set(optimizer, 3);
                                                                              
                                                                              // Case 1: Verify chi-square calculation
                                                                              double expectedChiSquare = 1.0*1.0*1.0 + 2.0*2.0*1.0 + 3.0*3.0*1.0;
                                                                              assertEquals("Chi-square calculation should sum weighted squared residuals", 
                                                                                          expectedChiSquare, optimizer.getChiSquare(), 1e-10);
                                                                              
                                                                              // Case 2: Verify with different weights
                                                                              weightsField.set(optimizer, new double[]{2.0, 3.0, 4.0});
                                                                              expectedChiSquare = 1.0*1.0*2.0 + 2.0*2.0*3.0 + 3.0*3.0*4.0;
                                                                              assertEquals("Chi-square calculation should respect weights", 
                                                                                          expectedChiSquare, optimizer.getChiSquare(), 1e-10);
                                                                              
                                                                              // Case 3: Verify with zero residuals
                                                                              residualsField.set(optimizer, new double[]{0.0, 0.0, 0.0});
                                                                              assertEquals("Chi-square should be zero with zero residuals", 
                                                                                          0.0, optimizer.getChiSquare(), 1e-10);
                                                                          }

    @Test
                                                                          public void testGetChiSquare() {
                                                                              // Create a test instance by mocking the abstract class
                                                                              AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                                                                                  CALLS_REAL_METHODS);
                                                                              
                                                                              // Set up test data
                                                                              int testRows = 3;
                                                                              double[] testResiduals = {1.0, 2.0, 3.0};
                                                                              double[] testWeights = {0.5, 1.0, 1.5};
                                                                              
                                                                              // Set protected fields using reflection
                                                                              try {
                                                                                  java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                                                      .getDeclaredField("rows");
                                                                                  rowsField.setAccessible(true);
                                                                                  rowsField.set(optimizer, testRows);
                                                                                  
                                                                                  java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                                                                                      .getDeclaredField("residuals");
                                                                                  residualsField.setAccessible(true);
                                                                                  residualsField.set(optimizer, testResiduals);
                                                                                  
                                                                                  java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                                                                                      .getDeclaredField("residualsWeights");
                                                                                  weightsField.setAccessible(true);
                                                                                  weightsField.set(optimizer, testWeights);
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to set up test fields via reflection");
                                                                              }
                                                                              
                                                                              // Calculate expected value
                                                                              double expected = 0;
                                                                              for (int i = 0; i < testRows; i++) {
                                                                                  expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                              }
                                                                              
                                                                              // Test the method
                                                                              double actual = optimizer.getChiSquare();
                                                                              
                                                                              // Verify
                                                                              assertEquals("Chi-square calculation incorrect", expected, actual, 0.0001);
                                                                              
                                                                              // Additional test for empty case
                                                                              try {
                                                                                  java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                                                      .getDeclaredField("rows");
                                                                                  rowsField.setAccessible(true);
                                                                                  rowsField.set(optimizer, 0);
                                                                                  
                                                                                  double zeroResult = optimizer.getChiSquare();
                                                                                  assertEquals("Empty case should return 0", 0.0, zeroResult, 0.0);
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to test empty case");
                                                                              }
                                                                          }

    @Test
                                                                    public void testEvaluationCounterBehaviorAtMaxEvaluations() throws Exception {
                                                                        // Setup test object
                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                            @Override
                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                return null; // dummy implementation
                                                                            }
                                                                        };
                                                                        
                                                                        // Set max evaluations to 1 to easily test boundary
                                                                        optimizer.setMaxEvaluations(1);
                                                                        
                                                                        // Verify initial state
                                                                        assertEquals(0, optimizer.getEvaluations());
                                                                        
                                                                        // Get the protected method via reflection
                                                                        Method updateResidualsAndCost = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("updateResidualsAndCost");
                                                                        updateResidualsAndCost.setAccessible(true);
                                                                        
                                                                        // First evaluation should be allowed
                                                                        updateResidualsAndCost.invoke(optimizer); // This would normally increment counter
                                                                        assertEquals(1, optimizer.getEvaluations());
                                                                        
                                                                        // Second evaluation should be blocked by original code
                                                                        // But mutant would allow it because it does post-increment
                                                                        try {
                                                                            updateResidualsAndCost.invoke(optimizer);
                                                                            // If we get here, the mutant survived (bad)
                                                                            fail("Expected evaluation limit to be exceeded");
                                                                        } catch (InvocationTargetException e) {
                                                                            // Expected behavior - original code would throw here
                                                                            assertEquals(1, optimizer.getEvaluations()); // Counter should stay at 1
                                                                        }
                                                                        
                                                                        // Additional verification
                                                                        assertEquals(1, optimizer.getEvaluations());
                                                                    }

    @Test
                                                               public void testEvaluationLimitBoundary() throws Exception {
                                                                   // Setup test instance
                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                       @Override
                                                                       protected VectorialPointValuePair doOptimize() {
                                                                           return null;
                                                                       }
                                                                   };
                                                                   
                                                                   // Set max evaluations to 1 to test boundary condition
                                                                   optimizer.setMaxEvaluations(1);
                                                                   
                                                                   // Use reflection to access protected incrementIterationsCounter()
                                                                   Method incrementMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("incrementIterationsCounter");
                                                                   incrementMethod.setAccessible(true);
                                                                   
                                                                   // First evaluation should be allowed
                                                                   incrementMethod.invoke(optimizer);
                                                                   
                                                                   // Use reflection to set protected fields
                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                   rowsField.setAccessible(true);
                                                                   rowsField.set(optimizer, 2);
                                                                   
                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                   residualsField.setAccessible(true);
                                                                   residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                   
                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                   weightsField.setAccessible(true);
                                                                   weightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                   
                                                                   // Verify we can still perform operations at exactly maxEvaluations
                                                                   try {
                                                                       double result = optimizer.getChiSquare();
                                                                       assertEquals(5.0, result, 0.0001); // 1^2*1 + 2^2*1 = 5
                                                                   } catch (Exception e) {
                                                                       fail("Mutant detected: Evaluation limit triggered at boundary when it shouldn't have");
                                                                   }
                                                                   
                                                                   // Next evaluation should definitely throw
                                                                   try {
                                                                       incrementMethod.invoke(optimizer);
                                                                       optimizer.getChiSquare();
                                                                       fail("Should have thrown exception when exceeding max evaluations");
                                                                   } catch (Exception e) {
                                                                       // Expected behavior
                                                                   }
                                                               }

    @Test
                                                          public void testGetChiSquareWithNullFunctionEvaluation() throws Exception {
                                                              // Create testable subclass that exposes protected fields
                                                              class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                  public TestOptimizer() {
                                                                      super();
                                                                  }
                                                                  
                                                                  @Override
                                                                  protected VectorialPointValuePair doOptimize() {
                                                                      return null;
                                                                  }
                                                                  
                                                                  public void setTestFields(DifferentiableMultivariateVectorialFunction function, 
                                                                                          double[] point, 
                                                                                          int rows, 
                                                                                          double[] residuals, 
                                                                                          double[] residualsWeights) {
                                                                      // Use reflection to set private function field
                                                                      try {
                                                                          Field functionField = AbstractLeastSquaresOptimizer.class.getDeclaredField("function");
                                                                          functionField.setAccessible(true);
                                                                          functionField.set(this, function);
                                                                      } catch (Exception e) {
                                                                          throw new RuntimeException(e);
                                                                      }
                                                                      
                                                                      this.point = point;
                                                                      this.rows = rows;
                                                                      this.residuals = residuals;
                                                                      this.residualsWeights = residualsWeights;
                                                                  }
                                                              }
                                                              
                                                              // Create optimizer instance
                                                              TestOptimizer optimizer = new TestOptimizer();
                                                              
                                                              // Mock the function (though it's not actually used in getChiSquare())
                                                              DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                              when(function.value(null)).thenThrow(new NullPointerException());
                                                              
                                                              // Set up optimizer state
                                                              optimizer.setTestFields(
                                                                  function,
                                                                  new double[]{1.0, 2.0}, // Valid point
                                                                  2, // rows
                                                                  new double[]{0.1, 0.2}, // residuals
                                                                  new double[]{1.0, 1.0}  // residualsWeights
                                                              );
                                                              
                                                              // Call getChiSquare - should not throw NPE since it doesn't use the function
                                                              double chiSquare = optimizer.getChiSquare();
                                                              assertEquals(0.05, chiSquare, 0.0001); // 0.1^2*1 + 0.2^2*1 = 0.01 + 0.04 = 0.05
                                                          }

    @Test
                                                     public void testGetChiSquareWithMatchingLengths() throws Exception {
                                                         // Create mock optimizer
                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                             @Override
                                                             protected VectorialPointValuePair doOptimize() {
                                                                 return null;
                                                             }
                                                         };
                                                         
                                                         // Set up test data using reflection
                                                         int rows = 3;
                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                         rowsField.setAccessible(true);
                                                         rowsField.set(optimizer, rows);
                                                         
                                                         Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                         objectiveField.setAccessible(true);
                                                         objectiveField.set(optimizer, new double[rows]);
                                                         
                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                         residualsField.setAccessible(true);
                                                         residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                         
                                                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                         weightsField.setAccessible(true);
                                                         weightsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                                                         
                                                         // Should pass in original implementation
                                                         double result = optimizer.getChiSquare();
                                                         
                                                         // Verify calculation (1^2*1 + 2^2*1 + 3^2*1 = 1 + 4 + 9 = 14)
                                                         assertEquals(14.0, result, 0.0001);
                                                     }

    @Test(expected = IllegalArgumentException.class)
                                                     public void testGetChiSquareWithNonMatchingLengths() throws Exception {
                                                         // Create optimizer instance
                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                             protected VectorialPointValuePair doOptimize() {
                                                                 return null;
                                                             }
                                                         };
                                                         
                                                         // Use reflection to set protected fields
                                                         java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                         rowsField.setAccessible(true);
                                                         rowsField.set(optimizer, 5); // Set some number of rows
                                                         
                                                         java.lang.reflect.Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                         objectiveField.setAccessible(true);
                                                         objectiveField.set(optimizer, new double[6]); // Set objective array with length = rows + 1
                                                         
                                                         // Should throw exception
                                                         optimizer.getChiSquare();
                                                     }

    @Test
                                                public void testGetChiSquare_ShouldThrowWhenObjectiveShorterThanRows() throws Exception {
                                                    // Setup test data where objective.length < rows
                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                        @Override
                                                        protected VectorialPointValuePair doOptimize() {
                                                            return null;
                                                        }
                                                    };
                                                    
                                                    // Use reflection to set protected fields
                                                    Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                    
                                                    // Set rows to 3
                                                    Field rowsField = optimizerClass.getDeclaredField("rows");
                                                    rowsField.setAccessible(true);
                                                    rowsField.setInt(optimizer, 3);
                                                    
                                                    // Set objective to length 2 (shorter than rows)
                                                    Field objectiveField = optimizerClass.getDeclaredField("objective");
                                                    objectiveField.setAccessible(true);
                                                    objectiveField.set(optimizer, new double[2]);
                                                    
                                                    // Set residuals and weights arrays (length must match rows)
                                                    Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                    residualsField.setAccessible(true);
                                                    residualsField.set(optimizer, new double[3]);
                                                    
                                                    Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                    residualsWeightsField.setAccessible(true);
                                                    residualsWeightsField.set(optimizer, new double[3]);
                                                    
                                                    // This should throw IllegalArgumentException in original code
                                                    // but would pass in mutated code (objective.length > rows is false)
                                                    optimizer.getChiSquare();
                                                }

    @Test
                               public void testGetChiSquareThrowsExceptionWithCorrectPoint() throws Exception {
                                   // Create a test instance of the optimizer
                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                       @Override
                                       protected VectorialPointValuePair doOptimize() {
                                           return null; // Not needed for this test
                                       }
                                   };
                                   
                                   // Use reflection to set protected fields
                                   java.lang.reflect.Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                   pointField.setAccessible(true);
                                   double[] point = new double[]{1.0, 2.0, 3.0};
                                   pointField.set(optimizer, point);
                                   
                                   java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                   rowsField.setAccessible(true);
                                   rowsField.set(optimizer, 2);
                                   
                                   java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                   residualsField.setAccessible(true);
                                   residualsField.set(optimizer, new double[3]);
                                   
                                   java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                   weightsField.setAccessible(true);
                                   weightsField.set(optimizer, new double[3]);
                                   
                                   // Expect the exception and verify its contents
                                   thrown.expect(org.apache.commons.math.FunctionEvaluationException.class);
                                   thrown.expectMessage("dimensions mismatch");
                                   thrown.expect(new org.hamcrest.TypeSafeMatcher<org.apache.commons.math.FunctionEvaluationException>() {
                                       @Override
                                       protected boolean matchesSafely(org.apache.commons.math.FunctionEvaluationException item) {
                                           return item.getMessage().contains(java.util.Arrays.toString(point));
                                       }
                                       
                                       @Override
                                       public void describeTo(org.hamcrest.Description description) {
                                           description.appendText("exception message should contain the point array");
                                       }
                                   });
                                   
                                   // Trigger the method that should throw the exception
                                   optimizer.getChiSquare();
                               }

    @Test
                           public void testGetChiSquare_DetectsInitializationMutation() {
                               // Setup test data - one row case for simplicity
                               double[] residuals = {2.0};  // residual = 2
                               double[] residualsWeights = {0.5};  // weight = 0.5
                               
                               // Create instance and set protected fields via reflection
                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                   protected VectorialPointValuePair doOptimize() {
                                       return null;  // abstract method implementation
                                   }
                               };
                               
                               // Set protected fields using reflection
                               try {
                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                   residualsField.setAccessible(true);
                                   residualsField.set(optimizer, residuals);
                                   
                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                   weightsField.setAccessible(true);
                                   weightsField.set(optimizer, residualsWeights);
                                   
                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                   rowsField.setAccessible(true);
                                   rowsField.set(optimizer, 1);  // one row
                               } catch (Exception e) {
                                   fail("Failed to set up test via reflection: " + e.getMessage());
                               }
                               
                               // Expected: 2.0 * 2.0 * 0.5 = 2.0
                               double expected = 2.0;
                               double actual = optimizer.getChiSquare();
                               
                               // This will fail if chiSquare was initialized to 1 instead of 0
                               assertEquals("Chi-square calculation incorrect due to initialization mutation", 
                                           expected, actual, 0.0001);
                           }

    @Test
                          public void testGetChiSquare_InitializesCostToZero() {
                              // Setup test data
                              int testRows = 2;
                              double[] testResiduals = {1.0, 2.0};
                              double[] testWeights = {0.5, 0.5};
                              
                              // Create instance and set test data
                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                  @Override
                                  protected VectorialPointValuePair doOptimize() {
                                      return null; // dummy implementation
                                  }
                              };
                              
                              // Use reflection to set protected fields for testing
                              try {
                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                  residualsField.setAccessible(true);
                                  residualsField.set(optimizer, testResiduals);
                                  
                                  Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                  weightsField.setAccessible(true);
                                  weightsField.set(optimizer, testWeights);
                                  
                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                  rowsField.setAccessible(true);
                                  rowsField.set(optimizer, testRows);
                              } catch (Exception e) {
                                  fail("Failed to set test data via reflection");
                              }
                              
                              // Call method under test
                              double result = optimizer.getChiSquare();
                              
                              // Verify cost was initialized to 0 (not -1)
                              try {
                                  Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                  costField.setAccessible(true);
                                  double costValue = costField.getDouble(optimizer);
                                  assertEquals(0.0, costValue, 0.0001);
                              } catch (Exception e) {
                                  fail("Failed to verify cost field");
                              }
                              
                              // Also verify chiSquare calculation is correct
                              double expectedChiSquare = (1.0 * 1.0 * 0.5) + (2.0 * 2.0 * 0.5);
                              assertEquals(expectedChiSquare, result, 0.0001);
                          }

    @Test
                         public void testGetChiSquareShouldIncludeFirstElement() {
                             // Setup test data
                             int testRows = 3;
                             double[] testResiduals = {1.0, 2.0, 3.0};  // residuals[0] = 1.0
                             double[] testWeights = {0.5, 1.0, 1.5};    // weights[0] = 0.5
                             
                             // Create test instance and set required fields
                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                 @Override
                                 protected VectorialPointValuePair doOptimize() {
                                     return null; // Not needed for this test
                                 }
                             };
                             
                             // Use reflection to set protected fields since they're not publicly accessible
                             try {
                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                 residualsField.setAccessible(true);
                                 residualsField.set(optimizer, testResiduals);
                                 
                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                 weightsField.setAccessible(true);
                                 weightsField.set(optimizer, testWeights);
                                 
                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                 rowsField.setAccessible(true);
                                 rowsField.set(optimizer, testRows);
                             } catch (Exception e) {
                                 fail("Failed to set up test fields via reflection");
                             }
                             
                             // Calculate expected value manually (including first element)
                             double expected = 0.0;
                             for (int i = 0; i < testRows; i++) {
                                 expected += testResiduals[i] * testResiduals[i] * testWeights[i];
                             }
                             
                             // Call method and assert
                             double actual = optimizer.getChiSquare();
                             assertEquals("Chi-square calculation should include first element", 
                                          expected, actual, 0.0001);
                             
                             // Additional assertion to specifically check first element was included
                             double firstElementContribution = testResiduals[0] * testResiduals[0] * testWeights[0];
                             assertTrue("Chi-square should be at least as large as first element's contribution",
                                        actual >= firstElementContribution);
                         }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                        public void testGetChiSquareDetectsNegativeIndexMutant() {
                            // Setup test data
                            double[] residuals = {1.0, 2.0, 3.0};
                            double[] residualsWeights = {0.5, 0.5, 0.5};
                            
                            // Create instance and set protected fields via reflection
                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                @Override
                                protected VectorialPointValuePair doOptimize() {
                                    return null;
                                }
                            };
                            
                            // Set protected fields using reflection
                            try {
                                Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                residualsField.setAccessible(true);
                                residualsField.set(optimizer, residuals);
                                
                                Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                weightsField.setAccessible(true);
                                weightsField.set(optimizer, residualsWeights);
                                
                                Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                rowsField.setAccessible(true);
                                rowsField.set(optimizer, residuals.length);
                            } catch (Exception e) {
                                fail("Failed to set up test via reflection: " + e.getMessage());
                            }
                            
                            // This should throw ArrayIndexOutOfBoundsException if mutant is present (i = -1)
                            optimizer.getChiSquare();
                            
                            // If no exception is thrown, verify the calculation is correct
                            double expected = 0;
                            for (int i = 0; i < residuals.length; i++) {
                                expected += residuals[i] * residuals[i] * residualsWeights[i];
                            }
                            assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                        }

    @Test
                       public void testGetChiSquareDetectsMutant() {
                           // Setup test data
                           int rows = 3;
                           double[] residuals = {1.0, 2.0, 3.0};
                           double[] residualsWeights = {0.5, 1.0, 1.5};
                           
                           // Create test instance and set protected fields via reflection
                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                               @Override
                               protected VectorialPointValuePair doOptimize() {
                                   return null;
                               }
                           };
                           
                           try {
                               // Set protected fields using reflection
                               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                               rowsField.setAccessible(true);
                               rowsField.set(optimizer, rows);
                               
                               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                               residualsField.setAccessible(true);
                               residualsField.set(optimizer, residuals);
                               
                               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                               weightsField.setAccessible(true);
                               weightsField.set(optimizer, residualsWeights);
                               
                               // Calculate expected value (1^2*0.5 + 2^2*1.0 + 3^2*1.5 = 0.5 + 4 + 13.5 = 18.0)
                               double expected = 1.0*1.0*0.5 + 2.0*2.0*1.0 + 3.0*3.0*1.5;
                               
                               // Test original behavior
                               assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                               
                               // If the mutant exists (i <= rows), it would either:
                               // 1. Throw ArrayIndexOutOfBoundsException when i=3
                               // 2. Produce incorrect result if somehow the arrays were larger than rows
                               // This test would fail for the mutant version
                               
                           } catch (Exception e) {
                               fail("Test setup failed: " + e.getMessage());
                           }
                       }

    @Test
                      public void testGetChiSquareDetectsFirstRowSkippingMutant1() {
                          // Setup test data where first residual contributes significantly
                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                              @Override
                              protected VectorialPointValuePair doOptimize() {
                                  return null; // Not needed for this test
                              }
                          };
                          
                          // Using reflection to set protected fields since we can't access them directly
                          try {
                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                              residualsField.setAccessible(true);
                              double[] residuals = {10.0, 1.0, 1.0}; // First residual is large
                              residualsField.set(optimizer, residuals);
                              
                              Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                              weightsField.setAccessible(true);
                              double[] weights = {1.0, 1.0, 1.0}; // All weights equal
                              weightsField.set(optimizer, weights);
                              
                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                              rowsField.setAccessible(true);
                              rowsField.setInt(optimizer, 3); // 3 rows
                              
                              // Calculate expected value (includes first residual)
                              double expected = 10.0 * 10.0 * 1.0 + 1.0 * 1.0 * 1.0 + 1.0 * 1.0 * 1.0;
                              
                              // Verify the method returns the correct chi-square including first residual
                              assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                          } catch (Exception e) {
                              fail("Failed to set up test due to reflection error: " + e.getMessage());
                          }
                      }

    @Test
                public void testGetChiSquareDetectsResidualSignMutation1() {
                    // Setup test data where subtraction and addition produce different results
                    double[] targetValues = {5.0, 3.0, 7.0};
                    double[] objective = {2.0, 4.0, 1.0};
                    double[] weights = {1.0, 1.0, 1.0}; // Equal weights for simplicity
                    int rows = targetValues.length;
                    
                    // Create a mock of the class under test
                    AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                    
                    // Calculate residuals based on target - objective
                    double[] residuals = new double[rows];
                    for (int i = 0; i < rows; i++) {
                        residuals[i] = targetValues[i] - objective[i];
                    }
                    
                    // Use reflection to set protected fields
                    try {
                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                        residualsField.setAccessible(true);
                        residualsField.set(optimizer, residuals);
                        
                        Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                        weightsField.setAccessible(true);
                        weightsField.set(optimizer, weights);
                        
                        Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                        costField.setAccessible(true);
                        costField.set(optimizer, 0.0); // Initialize cost
                    } catch (Exception e) {
                        fail("Failed to set up test due to reflection error: " + e.getMessage());
                    }
                    
                    // Stub the method to call real method for getChiSquare()
                    when(optimizer.getChiSquare()).thenCallRealMethod();
                    
                    // Calculate expected value with correct residual calculation (target - objective)
                    double expectedChiSquare = 0;
                    for (int i = 0; i < rows; i++) {
                        double correctResidual = targetValues[i] - objective[i];
                        expectedChiSquare += correctResidual * correctResidual * weights[i];
                    }
                    
                    // Calculate what the mutated version would return (target + objective)
                    double mutatedChiSquare = 0;
                    for (int i = 0; i < rows; i++) {
                        double mutatedResidual = targetValues[i] + objective[i];
                        mutatedChiSquare += mutatedResidual * mutatedResidual * weights[i];
                    }
                    
                    // Verify the actual result matches the expected (not mutated) calculation
                    double actualChiSquare = optimizer.getChiSquare();
                    assertEquals(expectedChiSquare, actualChiSquare, 0.0001);
                    
                    // Additional assertion to ensure we're detecting the mutation
                    // The actual result should NOT equal the mutated calculation
                    assertNotEquals(mutatedChiSquare, actualChiSquare, 0.0001);
                }

    @Test
           public void testGetChiSquareDetectsResidualSignMutation2() {
               // Setup test data that will reveal the mutant
               int rows = 2;
               double[] targetValues = {5.0, 3.0};
               double[] objective = {2.0, 4.0};
               double[] residualsWeights = {1.0, -1.0}; // Include negative weight
               
               // Create a partial mock of the class under test
               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                   @Override
                   protected VectorialPointValuePair doOptimize() {
                       return null; // Not needed for this test
                   }
               };
               
               // Set the required protected fields using reflection
               try {
                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                   rowsField.setAccessible(true);
                   rowsField.set(optimizer, rows);
                   
                   Field targetValuesField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                   targetValuesField.setAccessible(true);
                   targetValuesField.set(optimizer, targetValues);
                   
                   Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                   objectiveField.setAccessible(true);
                   objectiveField.set(optimizer, objective);
                   
                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                   weightsField.setAccessible(true);
                   weightsField.set(optimizer, residualsWeights);
               } catch (Exception e) {
                   fail("Failed to set up test fields via reflection: " + e.getMessage());
               }
               
               // Calculate expected value manually
               double expectedChiSquare = 0;
               for (int i = 0; i < rows; i++) {
                   double residual = targetValues[i] - objective[i];
                   expectedChiSquare += residual * residual * residualsWeights[i];
               }
               
               // Verify the method returns the correct chi-square value
               assertEquals("Chi-square calculation should be sensitive to residual sign with negative weights", 
                          expectedChiSquare, optimizer.getChiSquare(), 1e-10);
               
               // Additional verification that the mutant would fail
               double mutantChiSquare = 0;
               for (int i = 0; i < rows; i++) {
                   double residual = objective[i] - targetValues[i]; // Mutant version
                   mutantChiSquare += residual * residual * residualsWeights[i];
               }
               assertNotEquals("Test should detect mutant by showing different results", 
                              mutantChiSquare, optimizer.getChiSquare(), 1e-10);
           }

    @Test
       public void testGetChiSquareDetectsResidualZeroingMutant() {
           // Create test instance using reflection since constructor is protected
           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
               @Override
               protected VectorialPointValuePair doOptimize() {
                   return null; // dummy implementation
               }
           };
           
           // Set up test data with non-zero residuals and weights
           int testRows = 2;
           double[] testResiduals = {1.5, 2.0}; // non-zero residuals
           double[] testWeights = {1.0, 1.0}; // non-zero weights
           
           // Calculate expected chi-square (sum of squared residuals * weights)
           double expectedChiSquare = 0;
           for (int i = 0; i < testRows; i++) {
               expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
           }
           
           // Set protected fields using reflection
           try {
               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
               rowsField.setAccessible(true);
               rowsField.set(optimizer, testRows);
               
               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
               residualsField.setAccessible(true);
               residualsField.set(optimizer, testResiduals);
               
               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
               weightsField.setAccessible(true);
               weightsField.set(optimizer, testWeights);
           } catch (Exception e) {
               fail("Failed to set up test fields via reflection: " + e.getMessage());
           }
           
           // Test that chi-square is calculated correctly
           double actualChiSquare = optimizer.getChiSquare();
           assertEquals("Chi-square should be sum of squared residuals", 
                       expectedChiSquare, actualChiSquare, 0.0001);
           
           // Additional assertion to specifically catch the mutant
           assertNotEquals("Chi-square should not be zero with non-zero residuals", 
                          0.0, actualChiSquare, 0.0001);
       }

    @Test
      public void testGetChiSquareDetectsIndexMutation2() {
          // Setup test data
          int rows = 3;
          double[] residuals = {1.0, 2.0, 3.0};  // Known residuals
          double[] residualsWeights = {0.5, 1.0, 1.5};  // Known weights
          
          // Create partial mock of the optimizer
          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
              @Override
              protected VectorialPointValuePair doOptimize() {
                  return null; // Not needed for this test
              }
          };
          
          // Use reflection to set protected fields since they're not publicly accessible
          try {
              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
              residualsField.setAccessible(true);
              residualsField.set(optimizer, residuals);
              
              Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
              weightsField.setAccessible(true);
              weightsField.set(optimizer, residualsWeights);
              
              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
              rowsField.setAccessible(true);
              rowsField.set(optimizer, rows);
          } catch (Exception e) {
              fail("Failed to set up test fields via reflection");
          }
          
          // Calculate expected value manually
          double expected = 0;
          for (int i = 0; i < rows; i++) {
              expected += residuals[i] * residuals[i] * residualsWeights[i];
          }
          
          // Test and assert
          assertEquals("Chi-square calculation should match manual computation", 
                      expected, optimizer.getChiSquare(), 1e-10);
          
          // Additional check for mutation where residuals might be incorrectly populated
          // If index was mutated to -= cols, some residuals might be wrong or missing
          // This would cause the sum to be incorrect
          assertTrue("Chi-square should be positive for these inputs", 
                    optimizer.getChiSquare() > 0);
      }

    @Test
    public void testGetChiSquareDetectsIndexMutation3() throws Exception {
        // Setup test data with multiple rows where residuals and weights differ
        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
            @Override
            protected VectorialPointValuePair doOptimize() {
                return null; // dummy implementation
            }
        };
        
        // Use reflection to access protected fields
        Class<?> optimizerClass = optimizer.getClass();
        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
        rowsField.setAccessible(true);
        java.lang.reflect.Field colsField = optimizerClass.getDeclaredField("cols");
        colsField.setAccessible(true);
        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
        residualsField.setAccessible(true);
        java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
        residualsWeightsField.setAccessible(true);
        
        // Final test setup that would expose the mutation
        rowsField.setInt(optimizer, 2);
        colsField.setInt(optimizer, 2); // Now mutation will cause wrong array access
        residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0, 4.0});
        residualsWeightsField.set(optimizer, new double[]{1.0, 2.0, 3.0, 4.0});
        
        // Original behavior:
        // Iteration 0: index=0, residual=1.0, weight=1.0
        // Iteration 1: index=2, residual=3.0, weight=3.0
        // Result: 1*1*1 + 3*3*3 = 1 + 27 = 28
        
        // Mutant behavior:
        // Iteration 0: index=2, residual=3.0, weight=3.0
        // Iteration 1: index=2, residual=3.0, weight=3.0
        // Result: 3*3*3 + 3*3*3 = 27 + 27 = 54
        
        double expected = 28.0;
        double actual = optimizer.getChiSquare();
        assertEquals("Chi-square calculation should properly increment index", 
                    expected, actual, 0.0001);
    }


}
