package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Gamma;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class PoissonDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testConstructor_ZeroMean() {
                                                        // Test with zero mean (should throw exception)
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("must be positive");
                                                        new PoissonDistributionImpl(0.0);
                                                    }

    @Test
                                                    public void testConstructor_NegativeMean() {
                                                        // Test with negative mean (should throw exception)
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("must be positive");
                                                        new PoissonDistributionImpl(-1.0);
                                                    }

    @Test
                                                    public void testConstructor_ZeroMean1() {
                                                        // Test with zero mean (should throw exception)
                                                        thrown.expect(NotStrictlyPositiveException.class);
                                                        thrown.expectMessage("mean (0)");
                                                        
                                                        new PoissonDistributionImpl(0.0, 1e-12, 1000);
                                                    }

    @Test
                                                    public void testConstructor_NegativeMean1() {
                                                        // Test with negative mean (should throw exception)
                                                        thrown.expect(NotStrictlyPositiveException.class);
                                                        thrown.expectMessage("mean (-5)");
                                                        
                                                        new PoissonDistributionImpl(-5.0, 1e-12, 1000);
                                                    }

    @Test
                                                    public void testConstructor_ValidArguments() {
                                                        double mean = 5.0;
                                                        double epsilon = 1e-12;
                                                        
                                                        PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, epsilon);
                                                        
                                                        assertEquals(mean, dist.getMean(), 0.0);
                                                        // Since epsilon is private, we can verify it through probability calculation
                                                        // or test that it's used correctly in other methods (would need mocking)
                                                    }

    @Test
                                                    public void testConstructor_DefaultEpsilon() {
                                                        double mean = 3.0;
                                                        PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, PoissonDistributionImpl.DEFAULT_EPSILON);
                                                        
                                                        assertEquals(mean, dist.getMean(), 0.0);
                                                    }

    @Test
                                                    public void testConstructor_ZeroMean2() {
                                                        double mean = 0.0;
                                                        double epsilon = 1e-10;
                                                        
                                                        PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, epsilon);
                                                        
                                                        assertEquals(mean, dist.getMean(), 0.0);
                                                    }

    @Test
                                                    public void testConstructor_NegativeMean2() {
                                                        double mean = -1.0;
                                                        double epsilon = 1e-12;
                                                        
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("mean must be >= 0");
                                                        
                                                        new PoissonDistributionImpl(mean, epsilon);
                                                    }

    @Test
                                                    public void testConstructor_ZeroEpsilon() {
                                                        double mean = 2.0;
                                                        double epsilon = 0.0;
                                                        
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("epsilon must be > 0");
                                                        
                                                        new PoissonDistributionImpl(mean, epsilon);
                                                    }

    @Test
                                                    public void testConstructor_NegativeEpsilon() {
                                                        double mean = 2.0;
                                                        double epsilon = -1e-12;
                                                        
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("epsilon must be > 0");
                                                        
                                                        new PoissonDistributionImpl(mean, epsilon);
                                                    }

    @Test
                                                    public void testConstructor_VerySmallEpsilon() {
                                                        double mean = 10.0;
                                                        double epsilon = Double.MIN_VALUE;
                                                        
                                                        PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, epsilon);
                                                        
                                                        assertEquals(mean, dist.getMean(), 0.0);
                                                    }

    @Test
                                                    public void testConstructor_LargeEpsilon() {
                                                        double mean = 15.0;
                                                        double epsilon = 1.0;
                                                        
                                                        PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, epsilon);
                                                        
                                                        assertEquals(mean, dist.getMean(), 0.0);
                                                    }

    @Test
                                                    public void testConstructor_MaxMeanValue() {
                                                        double mean = Double.MAX_VALUE;
                                                        double epsilon = 1e-12;
                                                        
                                                        PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, epsilon);
                                                        
                                                        assertEquals(mean, dist.getMean(), 0.0);
                                                    }

    @Test
                                                    public void testConstructor_NegativeMean3() {
                                                        // Test with negative mean (should throw exception)
                                                        double mean = -1.0;
                                                        int maxIterations = 1000;
                                                        
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("mean must be >= 0");
                                                        
                                                        new PoissonDistributionImpl(mean, maxIterations);
                                                    }

    @Test
                                                    public void testConstructor_NegativeMaxIterations() {
                                                        // Test with negative maxIterations (should throw exception)
                                                        double mean = 2.0;
                                                        int maxIterations = -1;
                                                        
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("max iterations must be positive");
                                                        
                                                        new PoissonDistributionImpl(mean, maxIterations);
                                                    }

    @Test
                                                    public void testConstructor_ZeroMaxIterations() {
                                                        // Test with zero maxIterations (should throw exception)
                                                        double mean = 2.0;
                                                        int maxIterations = 0;
                                                        
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("max iterations must be positive");
                                                        
                                                        new PoissonDistributionImpl(mean, maxIterations);
                                                    }

    @Test
                                            public void testConstructor_ValidPositiveMean() {
                                                // Test with typical positive mean value
                                                double mean = 5.0;
                                                PoissonDistributionImpl dist = new PoissonDistributionImpl(mean);
                                                
                                                assertEquals(mean, dist.getMean(), 0.0);
                                                // Removed checks for private fields as they are implementation details
                                                // Only testing through public interface
                                            }

    @Test
                                            public void testConstructor_SmallPositiveMean() throws Exception {
                                                // Test with very small positive mean (boundary case)
                                                double mean = Double.MIN_VALUE;
                                                PoissonDistributionImpl dist = new PoissonDistributionImpl(mean);
                                                
                                                assertEquals(mean, dist.getMean(), 0.0);
                                                
                                                // Use reflection to access private fields
                                                Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                                                epsilonField.setAccessible(true);
                                                double epsilon = epsilonField.getDouble(dist);
                                                assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilon, 0.0);
                                                
                                                Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                maxIterationsField.setAccessible(true);
                                                int maxIterations = maxIterationsField.getInt(dist);
                                                assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterations);
                                            }

    @Test
                                            public void testConstructor_LargeMean() throws Exception {
                                                // Test with large mean value
                                                double mean = 1e6;
                                                PoissonDistributionImpl dist = new PoissonDistributionImpl(mean);
                                                
                                                assertEquals(mean, dist.getMean(), 0.0);
                                                
                                                // Use reflection to access private fields
                                                Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                                                epsilonField.setAccessible(true);
                                                double epsilon = epsilonField.getDouble(dist);
                                                assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilon, 0.0);
                                                
                                                Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                maxIterationsField.setAccessible(true);
                                                int maxIterations = maxIterationsField.getInt(dist);
                                                assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterations);
                                            }

    @Test
                                            public void testConstructor_MeanWithPrecision() {
                                                // Test with mean that has decimal precision
                                                double mean = 3.1415926535;
                                                PoissonDistributionImpl dist = new PoissonDistributionImpl(mean);
                                                
                                                assertEquals(mean, dist.getMean(), 0.0);
                                                
                                                try {
                                                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                                                    epsilonField.setAccessible(true);
                                                    double epsilon = epsilonField.getDouble(dist);
                                                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilon, 0.0);
                                                    
                                                    Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                    maxIterationsField.setAccessible(true);
                                                    int maxIterations = maxIterationsField.getInt(dist);
                                                    assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterations);
                                                } catch (Exception e) {
                                                    fail("Failed to access private fields through reflection: " + e.getMessage());
                                                }
                                            }

    @Test
                                            public void testConstructor_DefaultEpsilonAndMaxIterations() throws Exception {
                                                // Test with only mean specified (using default epsilon and maxIterations)
                                                double mean = 3.0;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, 
                                                    PoissonDistributionImpl.DEFAULT_EPSILON, 
                                                    PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS);
                                                
                                                assertEquals(mean, distribution.getMean(), 0.0);
                                                
                                                // Use reflection to access private fields
                                                Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                                                epsilonField.setAccessible(true);
                                                double actualEpsilon = epsilonField.getDouble(distribution);
                                                assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, actualEpsilon, 0.0);
                                                
                                                Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                maxIterationsField.setAccessible(true);
                                                int actualMaxIterations = maxIterationsField.getInt(distribution);
                                                assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, actualMaxIterations);
                                            }

    @Test
                                            public void testConstructor_ZeroEpsilon1() {
                                                // Test with zero epsilon (should be allowed)
                                                double mean = 2.0;
                                                double epsilon = 0.0;
                                                int maxIterations = 1000;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                                                
                                                try {
                                                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                                                    epsilonField.setAccessible(true);
                                                    double actualEpsilon = epsilonField.getDouble(distribution);
                                                    assertEquals(epsilon, actualEpsilon, 0.0);
                                                } catch (Exception e) {
                                                    fail("Failed to access epsilon field through reflection: " + e.getMessage());
                                                }
                                            }

    @Test
                                            public void testConstructor_NegativeEpsilon1() {
                                                // Test with negative epsilon (should be allowed but might cause issues in calculations)
                                                double mean = 2.0;
                                                double epsilon = -1e-12;
                                                int maxIterations = 1000;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                                                
                                                try {
                                                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                                                    epsilonField.setAccessible(true);
                                                    double actualEpsilon = epsilonField.getDouble(distribution);
                                                    assertEquals(epsilon, actualEpsilon, 0.0);
                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                    fail("Failed to access private epsilon field through reflection");
                                                }
                                            }

    @Test
                                            public void testConstructor_ZeroMaxIterations1() throws Exception {
                                                // Test with zero max iterations (should be allowed but might cause issues in calculations)
                                                double mean = 2.0;
                                                double epsilon = 1e-12;
                                                int maxIterations = 0;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                                                
                                                // Use reflection to access private maxIterations field
                                                Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                maxIterationsField.setAccessible(true);
                                                int actualMaxIterations = (int) maxIterationsField.get(distribution);
                                                
                                                assertEquals(maxIterations, actualMaxIterations);
                                            }

    @Test
                                            public void testConstructor_NegativeMaxIterations1() throws Exception {
                                                // Test with negative max iterations (should be allowed but might cause issues in calculations)
                                                double mean = 2.0;
                                                double epsilon = 1e-12;
                                                int maxIterations = -100;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                                                
                                                // Use reflection to access private maxIterations field
                                                Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                maxIterationsField.setAccessible(true);
                                                int actualMaxIterations = maxIterationsField.getInt(distribution);
                                                
                                                assertEquals(maxIterations, actualMaxIterations);
                                            }

    @Test
                                            public void testConstructor_VerySmallMean() {
                                                // Test with very small positive mean
                                                double mean = Double.MIN_VALUE;
                                                double epsilon = 1e-12;
                                                int maxIterations = 1000;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                                                
                                                assertEquals(mean, distribution.getMean(), 0.0);
                                                // Removed assertion of private field 'normal'
                                            }

    @Test
                                            public void testConstructor_VeryLargeMean() {
                                                // Test with very large mean
                                                double mean = Double.MAX_VALUE;
                                                double epsilon = 1e-12;
                                                int maxIterations = 1000;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                                                
                                                assertEquals(mean, distribution.getMean(), 0.0);
                                                try {
                                                    Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                                                    normalField.setAccessible(true);
                                                    Object normal = normalField.get(distribution);
                                                    assertNotNull(normal);
                                                } catch (Exception e) {
                                                    fail("Failed to access normal field: " + e.getMessage());
                                                }
                                            }

    @Test
                                            public void testConstructor_ValidPositiveMean1() {
                                                // Test with valid positive mean and maxIterations
                                                double mean = 5.0;
                                                int maxIterations = 1000;
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, maxIterations);
                                                
                                                assertEquals(mean, distribution.getMean(), 0.0);
                                                
                                                // Use reflection to verify private fields
                                                try {
                                                    Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                    maxIterationsField.setAccessible(true);
                                                    assertEquals(maxIterations, maxIterationsField.getInt(distribution));
                                                    
                                                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                                                    epsilonField.setAccessible(true);
                                                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilonField.getDouble(distribution), 0.0);
                                                } catch (Exception e) {
                                                    fail("Failed to access private fields via reflection: " + e.getMessage());
                                                }
                                                
                                                // Verify normal distribution is set up by checking probability calculation
                                                assertTrue(distribution.probability(5) > 0);
                                            }

    @Test
                                            public void testConstructor_ZeroMean3() {
                                                // Test with zero mean (edge case)
                                                double mean = 0.0;
                                                int maxIterations = 1000;
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, maxIterations);
                                                
                                                assertEquals(mean, distribution.getMean(), 0.0);
                                                // Removed assertion for private field maxIterations
                                            }

    @Test
                                            public void testConstructor_ValidMaxIterations() throws Exception {
                                                // Test with different valid maxIterations values
                                                double mean = 2.0;
                                                
                                                // Test with maxIterations equal to default
                                                PoissonDistributionImpl dist1 = new PoissonDistributionImpl(mean, PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS);
                                                Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                maxIterationsField.setAccessible(true);
                                                assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterationsField.getInt(dist1));
                                                
                                                // Test with custom maxIterations
                                                PoissonDistributionImpl dist2 = new PoissonDistributionImpl(mean, 500);
                                                assertEquals(500, maxIterationsField.getInt(dist2));
                                            }

    @Test
                                            public void testConstructor_ExtremeValues() {
                                                // Test with very large mean and maxIterations
                                                double mean = Double.MAX_VALUE;
                                                int maxIterations = Integer.MAX_VALUE;
                                                
                                                PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, maxIterations);
                                                
                                                assertEquals(mean, distribution.getMean(), 0.0);
                                                try {
                                                    Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                                                    maxIterationsField.setAccessible(true);
                                                    int actualMaxIterations = maxIterationsField.getInt(distribution);
                                                    assertEquals(maxIterations, actualMaxIterations);
                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                    fail("Failed to access maxIterations field: " + e.getMessage());
                                                }
                                            }

    @Test
                                        public void testConstructor_ValidParameters() throws Exception {
                                            // Test with valid parameters
                                            double mean = 5.0;
                                            double epsilon = 1e-12;
                                            int maxIterations = 1000;
                                            
                                            PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                                            
                                            assertEquals(mean, distribution.getMean(), 0.0);
                                            // Verify normal distribution effects through public methods
                                            // For example, verify probability calculations that would use the normal distribution
                                            double probability = distribution.probability(5);
                                            assertTrue(probability > 0);
                                            assertTrue(probability < 1);
                                            
                                            // Or verify cumulative probability
                                            double cumulativeProb = distribution.cumulativeProbability(5);
                                            assertTrue(cumulativeProb > 0);
                                            assertTrue(cumulativeProb <= 1);
                                        }

    @Test
                                       public void testNormalDistributionInitialization() throws Exception {
                                           // Arrange
                                           double p = 5.0;  // test with a positive mean value
                                           double epsilon = 1e-12;
                                           int maxIterations = 1000000;
                                           
                                           // Act
                                           PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon, maxIterations);
                                           
                                           // Use reflection to access private 'normal' field for verification
                                           Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                                           normalField.setAccessible(true);
                                           NormalDistribution normal = (NormalDistribution) normalField.get(distribution);
                                           
                                           // Assert
                                           // Verify the normal distribution was created with correct mean (p)
                                           assertEquals("Normal distribution mean should equal Poisson mean", 
                                                       p, normal.getMean(), 1e-12);
                                       }

    @Test
                                       public void testNormalDistributionMeanMatchesPoissonMean() throws Exception {
                                           // Arrange
                                           double testMean = 5.0;  // Test with mean = 5
                                           int testMaxIterations = 1000;
                                           
                                           // Act
                                           PoissonDistributionImpl poisson = new PoissonDistributionImpl(testMean, testMaxIterations);
                                           
                                           // Use reflection to access private normal field
                                           Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                                           normalField.setAccessible(true);
                                           NormalDistribution normal = (NormalDistribution) normalField.get(poisson);
                                           
                                           // Assert
                                           assertEquals("Normal distribution mean should match Poisson mean", 
                                                       testMean, normal.getMean(), 0.0001);
                                       }

    @Test
                                  public void testNormalDistributionInitialization1() {
                                      // Arrange
                                      double testMean = 5.0;
                                      double epsilon = 1e-12;
                                      int maxIterations = 10000;
                                      
                                      // Act
                                      PoissonDistributionImpl poisson = new PoissonDistributionImpl(testMean, epsilon, maxIterations);
                                      
                                      // Get the underlying normal distribution using reflection
                                      NormalDistribution normal = null;
                                      try {
                                          Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                                          normalField.setAccessible(true);
                                          normal = (NormalDistribution) normalField.get(poisson);
                                      } catch (NoSuchFieldException | IllegalAccessException e) {
                                          fail("Failed to access normal distribution field: " + e.getMessage());
                                      }
                                      
                                      // Assert
                                      assertEquals("Normal distribution mean should match Poisson mean", 
                                                   testMean, normal.getMean(), epsilon);
                                  }

    @Test
                                  public void testNormalDistributionMeanMatchesPoissonMean1() {
                                      // Arrange
                                      double testMean = 5.0;  // Test with mean = 5
                                      int testMaxIterations = 1000;
                                      
                                      // Act
                                      PoissonDistributionImpl poisson = new PoissonDistributionImpl(testMean, testMaxIterations);
                                      
                                      // Get the internal normal distribution using reflection
                                      NormalDistribution normal = null;
                                      try {
                                          Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                                          normalField.setAccessible(true);
                                          normal = (NormalDistribution) normalField.get(poisson);
                                      } catch (Exception e) {
                                          fail("Failed to access normal distribution field: " + e.getMessage());
                                      }
                                      
                                      // Assert
                                      assertEquals("Normal distribution mean should match Poisson mean", 
                                                  testMean, normal.getMean(), 0.0001);
                                  }

    @Test
                              public void testConstructorSetsCorrectNormalDistributionMean() throws MathException {
                                  // Arrange
                                  double testMean = 5.0; // arbitrary test value
                                  
                                  // Act
                                  PoissonDistributionImpl poisson = new PoissonDistributionImpl(testMean);
                                  
                                  // Get the internal normal distribution (may need reflection if no getter exists)
                                  // For this test, we'll assume there's a way to access it, perhaps through
                                  // a package-private method or reflection
                                  
                                  // Assert that normal distribution has correct mean
                                  // Since we can't directly access the private 'normal' field in the test,
                                  // we'll test it indirectly by checking the behavior of methods that use it
                                  
                                  // Test normal approximation at the mean point
                                  double probabilityAtMean = poisson.normalApproximateProbability((int) testMean);
                                  
                                  // For a normal distribution centered at testMean, the probability should be
                                  // highest near the mean. If the mutant is present (mean=0), this would be wrong
                                  double probabilityAtZero = poisson.normalApproximateProbability(0);
                                  
                                  // The probability at mean should be higher than at 0 when mean > 0
                                  assertTrue("Normal approximation should have higher probability at mean than at 0",
                                            probabilityAtMean > probabilityAtZero);
                                  
                                  // Additional check for another point
                                  double probabilityAt2xMean = poisson.normalApproximateProbability((int) (2 * testMean));
                                  assertTrue("Normal approximation probabilities should decrease as we move away from mean",
                                            probabilityAtMean > probabilityAt2xMean);
                              }

    @Test
                              public void testNormalDistributionInitialization2() throws Exception {
                                  // Test with a specific mean value where the difference between √p and √(p+1) is significant
                                  double p = 4.0; // √4 = 2, √5 ≈ 2.236
                                  PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, 1e-12, 1000);
                                  
                                  // Use reflection to access the private normal field
                                  Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                                  normalField.setAccessible(true);
                                  NormalDistribution normal = (NormalDistribution) normalField.get(distribution);
                                  
                                  // Get the standard deviation from the normal distribution
                                  double actualStdDev = normal.getStandardDeviation();
                                  
                                  // Calculate expected standard deviation (should be √p)
                                  double expectedStdDev = Math.sqrt(p);
                                  
                                  // Assert that the standard deviation matches the expected value
                                  assertEquals("Normal distribution should be initialized with standard deviation √p", 
                                              expectedStdDev, actualStdDev, 1e-10);
                                  
                                  // Additional test using normalApproximateProbability which depends on the normal distribution
                                  int x = 5;
                                  double expectedProbability = normal.cumulativeProbability(x + 0.5) - 
                                                              normal.cumulativeProbability(x - 0.5);
                                  double actualProbability = distribution.normalApproximateProbability(x);
                                  
                                  assertEquals("Probability calculation should match expected normal approximation",
                                              expectedProbability, actualProbability, 1e-10);
                              }

    @Test
                         public void testNormalDistributionInitialization3() {
                             // Test with mean = 4 (should have std dev = 2)
                             double mean = 4.0;
                             double expectedStdDev = Math.sqrt(mean);
                             
                             // Create the Poisson distribution
                             PoissonDistributionImpl poisson = new PoissonDistributionImpl(mean);
                             
                             // Use reflection to access the private normal field
                             try {
                                 Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                                 normalField.setAccessible(true);
                                 NormalDistribution normal = (NormalDistribution) normalField.get(poisson);
                                 
                                 // Verify the standard deviation is correct
                                 assertEquals("Standard deviation should be sqrt(mean)", 
                                             expectedStdDev, 
                                             normal.getStandardDeviation(), 
                                             1e-10);
                                 
                                 // This test will fail on the mutant since:
                                 // Mutant gives sqrt(4+1) = 2.236 vs expected 2.0
                             } catch (NoSuchFieldException | IllegalAccessException e) {
                                 fail("Failed to access private normal field: " + e.getMessage());
                             }
                         }

    @Test
                         public void testNormalDistributionInitializationWithSmallMean() throws Exception {
                             // Test edge case with mean = 0.1 (should have std dev ≈ 0.3162)
                             double mean = 0.1;
                             double expectedStdDev = Math.sqrt(mean);
                             
                             PoissonDistributionImpl poisson = new PoissonDistributionImpl(mean);
                             
                             // Use reflection to access private field 'normal'
                             Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                             normalField.setAccessible(true);
                             NormalDistribution normal = (NormalDistribution) normalField.get(poisson);
                             
                             assertEquals("Standard deviation should be sqrt(mean) for small means",
                                         expectedStdDev,
                                         normal.getStandardDeviation(),
                                         1e-10);
                             
                             // Mutant would give sqrt(1.1) ≈ 1.0488 vs expected 0.3162
                         }

    @Test
                     public void testNormalDistributionStandardDeviation() throws Exception {
                         // Choose a test value where sqrt(p) and sqrt(p+1) are noticeably different
                         double p = 3.0; // sqrt(3) ≈ 1.732, sqrt(4) = 2.0
                         
                         // Create Poisson distribution
                         PoissonDistributionImpl poisson = new PoissonDistributionImpl(p);
                         
                         // Get the internal normal distribution using reflection
                         Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                         normalField.setAccessible(true);
                         NormalDistribution normal = (NormalDistribution) normalField.get(poisson);
                         
                         // Verify the standard deviation is sqrt(p) not sqrt(p+1)
                         double expectedStdDev = Math.sqrt(p);
                         double actualStdDev = normal.getStandardDeviation();
                         
                         assertEquals("Normal distribution standard deviation should be sqrt(p)", 
                                     expectedStdDev, actualStdDev, 1e-10);
                         
                         // Additional verification using probability calculation
                         // The normal approximation should use the correct standard deviation
                         double x = 4.0;
                         
                         // Use reflection to access Erf class
                         Class<?> erfClass = Class.forName("org.apache.commons.math.special.Erf");
                         java.lang.reflect.Method erfMethod = erfClass.getMethod("erf", double.class);
                         double erfValue = (Double) erfMethod.invoke(null, (x - p)/(expectedStdDev * Math.sqrt(2)));
                         double expectedProbability = 0.5 * (1 + erfValue);
                         
                         double actualProbability = poisson.normalApproximateProbability((int)x);
                         
                         assertEquals("Normal approximation probability should match expected value",
                                     expectedProbability, actualProbability, 1e-10);
                     }

    @Test
                 public void testConstructorNormalDistributionStandardDeviation() throws MathException {
                     // Test with mean = 4 (should have std dev = 2)
                     double mean = 4.0;
                     double expectedStdDev = FastMath.sqrt(mean);
                     
                     // Create Poisson distribution
                     PoissonDistributionImpl poisson = new PoissonDistributionImpl(mean);
                     
                     // Verify the normal distribution's standard deviation
                     // Since normal is private, we need to test its effect through normalApproximateProbability
                     // The approximation should be close to exact probability for large enough mean
                     int x = 4; // test around the mean
                     double exactProb = poisson.probability(x);
                     double approxProb = poisson.normalApproximateProbability(x);
                     
                     // The approximation should be reasonably close (within 0.01)
                     assertEquals(exactProb, approxProb, 0.01);
                     
                     // Test another value to be more thorough
                     x = 6;
                     exactProb = poisson.probability(x);
                     approxProb = poisson.normalApproximateProbability(x);
                     assertEquals(exactProb, approxProb, 0.01);
                     
                     // Test with another mean value (9, std dev should be 3)
                     mean = 9.0;
                     expectedStdDev = FastMath.sqrt(mean);
                     poisson = new PoissonDistributionImpl(mean);
                     
                     x = 9;
                     exactProb = poisson.probability(x);
                     approxProb = poisson.normalApproximateProbability(x);
                     assertEquals(exactProb, approxProb, 0.01);
                 }

    @Test
                 public void testConstructorStandardDeviation() throws Exception {
                     // Test case where p > 1 to detect sqrt vs abs difference
                     double p1 = 4.0;
                     PoissonDistributionImpl dist1 = new PoissonDistributionImpl(p1, 100);
                     
                     // Use reflection to access private normal field
                     Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                     normalField.setAccessible(true);
                     NormalDistribution normal1 = (NormalDistribution) normalField.get(dist1);
                     
                     // Verify standard deviation is sqrt(p) not abs(p)
                     assertEquals("Standard deviation should be sqrt(p)", 
                                  Math.sqrt(p1), 
                                  ((NormalDistributionImpl)normal1).getStandardDeviation(), 
                                  1e-10);
                     
                     // Test case where 0 < p < 1 to detect sqrt vs abs difference
                     double p2 = 0.25;
                     PoissonDistributionImpl dist2 = new PoissonDistributionImpl(p2, 100);
                     NormalDistribution normal2 = (NormalDistribution) normalField.get(dist2);
                     
                     assertEquals("Standard deviation should be sqrt(p)", 
                                  Math.sqrt(p2), 
                                  ((NormalDistributionImpl)normal2).getStandardDeviation(), 
                                  1e-10);
                     
                     // Edge case where p = 1 (both would be same)
                     double p3 = 1.0;
                     PoissonDistributionImpl dist3 = new PoissonDistributionImpl(p3, 100);
                     NormalDistribution normal3 = (NormalDistribution) normalField.get(dist3);
                     
                     assertEquals("Standard deviation should be sqrt(p)", 
                                  Math.sqrt(p3), 
                                  ((NormalDistributionImpl)normal3).getStandardDeviation(), 
                                  1e-10);
                 }

    @Test
            public void testNormalDistributionInitialization4() throws Exception {
                // Test with p > 1 where sqrt(p) < p
                double p1 = 4.0;
                PoissonDistributionImpl dist1 = new PoissonDistributionImpl(p1);
                
                // Get private normal field using reflection
                Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                normalField.setAccessible(true);
                NormalDistributionImpl normal1 = (NormalDistributionImpl) normalField.get(dist1);
                
                // Verify standard deviation is sqrt(p) not abs(p)
                assertEquals("Standard deviation should be sqrt(p) for p > 1", 
                    Math.sqrt(p1), normal1.getStandardDeviation(), 1e-10);
                
                // Test with 0 < p < 1 where sqrt(p) > p
                double p2 = 0.25;
                PoissonDistributionImpl dist2 = new PoissonDistributionImpl(p2);
                NormalDistributionImpl normal2 = (NormalDistributionImpl) normalField.get(dist2);
                
                assertEquals("Standard deviation should be sqrt(p) for 0 < p < 1", 
                    Math.sqrt(p2), normal2.getStandardDeviation(), 1e-10);
            }

    @Test
    public void testNormalDistributionStandardDeviation1() throws org.apache.commons.math.MathException {
        // Test with p = 4.0 (easy to compute sqrt)
        double p = 4.0;
        double expectedStdDev = Math.sqrt(p); // Should be 2.0
        
        // Create the Poisson distribution
        PoissonDistributionImpl poisson = new PoissonDistributionImpl(p);
        
        // Verify the standard deviation is sqrt(p) not abs(p)
        // by checking normal approximation at mean + 1 std dev
        
        double x = p + expectedStdDev; // p + sqrt(p) = 6.0
        double expectedProbability = 0.8413; // Approx probability for mean+1std in normal dist
        
        // Get actual probability from the normal approximation
        double actualProbability = poisson.normalApproximateProbability((int) Math.floor(x));
        
        // Allow small tolerance for floating point comparison
        assertEquals("Normal approximation should use sqrt(p) as std dev", 
                    expectedProbability, actualProbability, 0.01);
        
        // If mutant was active (std dev = p = 4), the probability at x=6 would be:
        // (6-4)/4 = 0.5 std devs -> probability ~0.6915 which would fail the test
    }

    @Test
    public void testNormalDistributionInitialization5() throws MathException {
        // Test case 1: p = 0.5 (sqrt(p) = ~0.707, p = 0.5)
        double p1 = 0.5;
        PoissonDistributionImpl dist1 = new PoissonDistributionImpl(p1, 1e-12, 1000);
        double x1 = p1; // mean value
        double expectedProb1 = dist1.normalApproximateProbability((int)x1);
        assertEquals("Normal approximation should match for p=0.5", 
                     expectedProb1, dist1.normalApproximateProbability((int)x1), 1e-10);
        
        // Test case 2: p = 2 (sqrt(p) = ~1.414, p = 2)
        double p2 = 2.0;
        PoissonDistributionImpl dist2 = new PoissonDistributionImpl(p2, 1e-12, 1000);
        double x2 = p2; // mean value
        double expectedProb2 = dist2.normalApproximateProbability((int)x2);
        assertEquals("Normal approximation should match for p=2", 
                     expectedProb2, dist2.normalApproximateProbability((int)x2), 1e-10);
        
        // Test case 3: p = 1 (both give same value)
        double p3 = 1.0;
        PoissonDistributionImpl dist3 = new PoissonDistributionImpl(p3, 1e-12, 1000);
        double x3 = p3; // mean value
        assertEquals("Normal approximation should match for p=1", 
                     1.0, dist3.normalApproximateProbability((int)x3), 1e-10);
    }


}
