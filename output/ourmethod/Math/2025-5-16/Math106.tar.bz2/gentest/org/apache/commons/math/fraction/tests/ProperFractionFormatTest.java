package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import org.apache.commons.math.util.MathUtils;
 
public class ProperFractionFormatTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                    public void testParse_ValidFractionWithoutWholeNumber() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "3/4";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertEquals(3, result.getNumerator());
                        assertEquals(4, result.getDenominator());
                        assertEquals(source.length(), pos.getIndex());
                    }

 @Test
                    public void testParse_ValidFractionWithWholeNumber() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "1 3/4";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertEquals(7, result.getNumerator());  // 1*4 + 3 = 7
                        assertEquals(4, result.getDenominator());
                        assertEquals(source.length(), pos.getIndex());
                    }

 @Test
                    public void testParse_NegativeWholeNumber() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "-2 1/2";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertEquals(-5, result.getNumerator());  // -(2*2 + 1) = -5
                        assertEquals(2, result.getDenominator());
                        assertEquals(source.length(), pos.getIndex());
                    }

 @Test
                    public void testParse_SimpleInteger() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "5";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertEquals(5, result.getNumerator());
                        assertEquals(1, result.getDenominator());
                        assertEquals(source.length(), pos.getIndex());
                    }

 @Test
                    public void testParse_WithWhitespace() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "  2   3  /  4  ";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertEquals(11, result.getNumerator());  // 2*4 + 3 = 11
                        assertEquals(4, result.getDenominator());
                        assertEquals(source.length(), pos.getIndex());
                    }

 @Test
                    public void testParse_InvalidNumerator() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "2 a/4";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertNull(result);
                        assertEquals(0, pos.getIndex());
                        assertTrue(pos.getErrorIndex() > 0);
                    }

 @Test
                    public void testParse_InvalidDenominator() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "2 3/b";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertNull(result);
                        assertEquals(0, pos.getIndex());
                        assertTrue(pos.getErrorIndex() > 0);
                    }

 @Test
                    public void testParse_NegativeNumerator() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "2 -3/4";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertNull(result);
                        assertEquals(0, pos.getIndex());
                    }

 @Test
                    public void testParse_NegativeDenominator() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "2 3/-4";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertNull(result);
                        assertEquals(0, pos.getIndex());
                    }

 @Test
                    public void testParse_MissingSlash() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "2 3 4";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertNull(result);
                        assertEquals(0, pos.getIndex());
                        assertTrue(pos.getErrorIndex() > 0);
                    }

 @Test
                    public void testParse_InvalidWholeNumber() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "a 3/4";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertNull(result);
                        assertEquals(0, pos.getIndex());
                    }

 @Test
                    public void testParse_EmptyString() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        String source = "";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertNull(result);
                        assertEquals(0, pos.getIndex());
                    }

 @Test
                    public void testParse_NullString() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        ParsePosition pos = new ParsePosition(0);
                        
                        thrown.expect(NullPointerException.class);
                        format.parse(null, pos);
                    }

 @Test
                    public void testParse_NullParsePosition() {
                        ProperFractionFormat format = new ProperFractionFormat();
                        String source = "1/2";
                        
                        thrown.expect(NullPointerException.class);
                        format.parse(source, null);
                    }

 @Test
                    public void testParse_WithCustomNumberFormat() {
                        NumberFormat customFormat = NumberFormat.getInstance();
                        ProperFractionFormat format = new ProperFractionFormat(customFormat);
                        ParsePosition pos = new ParsePosition(0);
                        String source = "1,000 250/500";
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertEquals(2250, result.getNumerator());  // 1000*500 + 250 = 500250 / 500
                        assertEquals(500, result.getDenominator());
                        assertEquals(source.length(), pos.getIndex());
                    }

 @Test
                    public void testParse_WithSuperParseSuccess() {
                        // Mock the super.parse() to return a value
                        ProperFractionFormat format = spy(new ProperFractionFormat());
                        ParsePosition pos = new ParsePosition(0);
                        String source = "3/4";
                        Fraction mockFraction = new Fraction(3, 4);
                        
                        when(format.parse(source, pos)).thenCallRealMethod();
                        when(format.parse(source, pos)).thenReturn(mockFraction);
                        
                        Fraction result = format.parse(source, pos);
                        
                        assertEquals(mockFraction, result);
                    }

 @Test
            public void testParseWithNegativeNumeratorShouldReturnNullAndResetPosition() {
                // Setup
                ProperFractionFormat format = new ProperFractionFormat();
                String source = "1 -2/3";  // Negative numerator is invalid
                ParsePosition pos = new ParsePosition(0);
                
                // Execute
                Fraction result = format.parse(source, pos);
                
                // Verify
                assertNull("Should return null for negative numerator", result);
                assertEquals("Position should be reset to initial index", 0, pos.getIndex());
                assertTrue("Error index should be set", pos.getErrorIndex() > 0);
            }

 @Test
            public void testParseWithNegativeDenominatorShouldReturnNullAndResetPosition() {
                // Setup
                ProperFractionFormat format = new ProperFractionFormat();
                String source = "1 2/-3";  // Negative denominator is invalid
                ParsePosition pos = new ParsePosition(0);
                
                // Execute
                Fraction result = format.parse(source, pos);
                
                // Verify
                assertNull("Should return null for negative denominator", result);
                assertEquals("Position should be reset to initial index", 0, pos.getIndex());
                assertTrue("Error index should be set", pos.getErrorIndex() > 0);
            }

 @Test
            public void testParseWithMissingSlashShouldReturnNullAndResetPosition() {
                // Setup
                ProperFractionFormat format = new ProperFractionFormat();
                String source = "1 23";  // Missing '/' is invalid
                ParsePosition pos = new ParsePosition(0);
                
                // Execute
                Fraction result = format.parse(source, pos);
                
                // Verify
                assertNull("Should return null when missing '/'", result);
                assertEquals("Position should be reset to initial index", 0, pos.getIndex());
                assertTrue("Error index should be set", pos.getErrorIndex() > 0);
            }

 @Test
            public void testParseWithInvalidNumberFormatShouldReturnNull() {
                // Setup
                ProperFractionFormat format = new ProperFractionFormat();
                String source = "abc 2/3";  // Invalid whole number format
                ParsePosition pos = new ParsePosition(0);
                
                // Execute
                Fraction result = format.parse(source, pos);
                
                // Verify
                assertNull("Should return null for invalid number format", result);
                assertEquals("Position should be reset to initial index", 0, pos.getIndex());
            }

 @Test
           public void testParseWithZeroDenominatorShouldNotReturnNull() {
               // Setup mocks and test data
               ProperFractionFormat format = new ProperFractionFormat();
               ParsePosition pos = new ParsePosition(0);
               
               // Mock the parsing flow to simulate "1 0/0" input
               // Mock whole number parsing to return 1
               NumberFormat mockWholeFormat = mock(NumberFormat.class);
               when(mockWholeFormat.parse(anyString(), any(ParsePosition.class)))
                   .thenReturn(1);
               format.setWholeFormat(mockWholeFormat);
               
               // Mock numerator parsing to return 0
               NumberFormat mockNumeratorFormat = mock(NumberFormat.class);
               when(mockNumeratorFormat.parse(anyString(), any(ParsePosition.class)))
                   .thenReturn(0);
               // Need to set numerator format through reflection since it's inherited
               
               // Mock denominator parsing to return 0
               NumberFormat mockDenominatorFormat = mock(NumberFormat.class);
               when(mockDenominatorFormat.parse(anyString(), any(ParsePosition.class)))
                   .thenReturn(0);
               // Need to set denominator format through reflection
               
               // Use reflection to set the private numerator and denominator formats
               try {
                   Field numeratorField = FractionFormat.class.getDeclaredField("numeratorFormat");
                   numeratorField.setAccessible(true);
                   numeratorField.set(format, mockNumeratorFormat);
                   
                   Field denominatorField = FractionFormat.class.getDeclaredField("denominatorFormat");
                   denominatorField.setAccessible(true);
                   denominatorField.set(format, mockDenominatorFormat);
               } catch (Exception e) {
                   fail("Failed to set up test due to reflection error");
               }
               
               // Test with input that would produce 0 denominator
               String source = "1 0/0";
               Fraction result = format.parse(source, pos);
               
               // Assert that original behavior returns a Fraction (mutant would return null)
               assertNotNull("Parser should return Fraction even with zero denominator", result);
               assertEquals(1, result.getNumerator());
               assertEquals(0, result.getDenominator());
           }

 @Test
          public void testParseResetsToInitialIndexOnNumeratorError() {
              // Setup
              ProperFractionFormat formatter = new ProperFractionFormat();
              String source = "1 -2/3";  // Invalid numerator (negative)
              ParsePosition pos = new ParsePosition(1);  // Start parsing at index 1
              
              // Record initial index
              int initialIndex = pos.getIndex();
              
              // Execute
              Fraction result = formatter.parse(source, pos);
              
              // Verify
              assertNull("Should return null for invalid numerator", result);
              assertEquals("ParsePosition should be reset to initial index", 
                           initialIndex, pos.getIndex());
              assertNotEquals("ParsePosition should not be reset to 0", 
                             0, pos.getIndex());
          }

 @Test
             public void testParseReturnsNullForInvalidInputs() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Test when whole number parsing fails
                 assertNull(format.parse("abc 1/2", pos));
                 
                 // Reset position
                 pos.setIndex(0);
                 
                 // Test when numerator parsing fails
                 assertNull(format.parse("1 abc/2", pos));
                 
                 // Reset position
                 pos.setIndex(0);
                 
                 // Test when numerator is negative
                 assertNull(format.parse("1 -1/2", pos));
                 
                 // Reset position
                 pos.setIndex(0);
                 
                 // Test when '/' is missing
                 assertNull(format.parse("1 1 2", pos));
                 
                 // Reset position
                 pos.setIndex(0);
                 
                 // Test when '/' is invalid (using different character)
                 assertNull(format.parse("1 1|2", pos));
                 
                 // Reset position
                 pos.setIndex(0);
                 
                 // Test when denominator parsing fails
                 assertNull(format.parse("1 1/abc", pos));
                 
                 // Reset position
                 pos.setIndex(0);
                 
                 // Test when denominator is negative
                 assertNull(format.parse("1 1/-2", pos));
             }

 @Test
        public void testParsePositionResetOnNumeratorError() {
            // Setup
            ProperFractionFormat format = new ProperFractionFormat();
            ParsePosition pos = new ParsePosition(0);
            String source = "1 -2/3"; // Invalid numerator (negative)
            
            // Execute
            Fraction result = format.parse(source, pos);
            
            // Verify
            assertNull("Should return null for invalid numerator", result);
            assertEquals("Parse position should be reset to initial index", 
                         0, pos.getIndex());
            assertNotEquals("Test should detect mutant (position would be 1 if mutant survived)",
                           1, pos.getIndex());
        }

 @Test
        public void testParsePositionResetOnDenominatorError() {
            // Setup
            ProperFractionFormat format = new ProperFractionFormat();
            ParsePosition pos = new ParsePosition(0);
            String source = "1 2/-3"; // Invalid denominator (negative)
            
            // Execute
            Fraction result = format.parse(source, pos);
            
            // Verify
            assertNull("Should return null for invalid denominator", result);
            assertEquals("Parse position should be reset to initial index", 
                         0, pos.getIndex());
            assertNotEquals("Test should detect mutant (position would be 1 if mutant survived)",
                           1, pos.getIndex());
        }

 @Test
        public void testParsePositionResetOnWholeNumberError() {
            // Setup
            ProperFractionFormat format = new ProperFractionFormat();
            ParsePosition pos = new ParsePosition(0);
            String source = "abc 2/3"; // Invalid whole number
            
            // Execute
            Fraction result = format.parse(source, pos);
            
            // Verify
            assertNull("Should return null for invalid whole number", result);
            assertEquals("Parse position should be reset to initial index", 
                         0, pos.getIndex());
            assertNotEquals("Test should detect mutant (position would be 1 if mutant survived)",
                           1, pos.getIndex());
        }

 @Test
        public void testParsePositionResetOnMissingSlash() {
            // Setup
            ProperFractionFormat format = new ProperFractionFormat();
            ParsePosition pos = new ParsePosition(0);
            String source = "1 2 3"; // Missing '/' between numerator and denominator
            
            // Execute
            Fraction result = format.parse(source, pos);
            
            // Verify
            assertNull("Should return null for missing slash", result);
            assertEquals("Parse position should be reset to initial index", 
                         0, pos.getIndex());
            assertNotEquals("Test should detect mutant (position would be 1 if mutant survived)",
                           1, pos.getIndex());
        }

 @Test
       public void testParsePositionResetOnNumeratorError1() {
           // Setup
           ProperFractionFormat formatter = new ProperFractionFormat();
           String source = "  123 -456"; // Valid whole, invalid negative numerator
           ParsePosition pos = new ParsePosition(2); // Start at position 2
           
           // Execute
           Fraction result = formatter.parse(source, pos);
           
           // Verify
           assertNull("Should return null for invalid numerator", result);
           assertEquals("Parse position should be reset to initial index", 
                        2, pos.getIndex()); // This will fail with the mutant
           assertNotEquals("Parse position should not be reset to 0", 
                          0, pos.getIndex()); // Additional check
       }

 @Test
     public void testParseWithInvalidFractionFormat_DetectsErrorIndexMutation() {
         // Setup
         ProperFractionFormat formatter = new ProperFractionFormat();
         String source = "1 2 x"; // Invalid format - 'x' instead of '/'
         ParsePosition pos = mock(ParsePosition.class);
         
         // Mock behavior
         when(pos.getIndex()).thenReturn(0, 2); // Initial index and after parsing numerator
         
         // Execute
         Fraction result = formatter.parse(source, pos);
         
         // Verify
         assertNull("Should return null for invalid format", result);
         
         // The key assertion - verify error index is set to exact position of invalid character (2)
         // This will catch the mutant that sets errorIndex to startIndex+1 (3)
         verify(pos).setErrorIndex(2);
         
         // Also verify position is reset
         verify(pos).setIndex(0);
     }

 @Test
 public void testParseWithInvalidSlashPosition_shouldSetCorrectErrorIndex() {
     // Setup
     ProperFractionFormat formatter = new ProperFractionFormat();
     String source = "1 2 x 3"; // Invalid character 'x' at position 4
     ParsePosition pos = new ParsePosition(0);
     
     // Execute
     Fraction result = formatter.parse(source, pos);
     
     // Verify
     assertNull("Should return null for invalid input", result);
     assertEquals("Error index should point to invalid character", 4, pos.getErrorIndex());
     assertNotEquals("Error index should not be 0 (mutant check)", 0, pos.getErrorIndex());
 }

}
