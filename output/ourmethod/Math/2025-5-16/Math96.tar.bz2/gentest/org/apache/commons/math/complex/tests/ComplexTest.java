package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import org.apache.commons.math.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
          public void testEquals_ReferenceEquality() {
              Complex c1 = new Complex(3.0, 4.0);
              assertTrue(c1.equals(c1));
          }

 @Test
          public void testEquals_NullComparison() {
              Complex c1 = new Complex(3.0, 4.0);
              assertFalse(c1.equals(null));
          }

 @Test
          public void testEquals_DifferentClass() {
              Complex c1 = new Complex(3.0, 4.0);
              assertFalse(c1.equals("Not a complex number"));
          }

 @Test
          public void testEquals_NaNComparison() {
              Complex nan1 = Complex.NaN;
              Complex nan2 = Complex.NaN;
              Complex regular = new Complex(1.0, 1.0);
              
              assertTrue(nan1.equals(nan2));
              assertFalse(nan1.equals(regular));
              assertFalse(regular.equals(nan1));
          }

 @Test
          public void testEquals_RegularNumbersEqual() {
              Complex c1 = new Complex(3.0, 4.0);
              Complex c2 = new Complex(3.0, 4.0);
              assertTrue(c1.equals(c2));
          }

 @Test
          public void testEquals_RegularNumbersDifferentReal() {
              Complex c1 = new Complex(3.0, 4.0);
              Complex c2 = new Complex(3.1, 4.0);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_RegularNumbersDifferentImaginary() {
              Complex c1 = new Complex(3.0, 4.0);
              Complex c2 = new Complex(3.0, 4.1);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_InfinityComparison() {
              Complex inf1 = Complex.INF;
              Complex inf2 = Complex.INF;
              Complex regular = new Complex(1.0, 1.0);
              
              assertTrue(inf1.equals(inf2));
              assertFalse(inf1.equals(regular));
              assertFalse(regular.equals(inf1));
          }

 @Test
          public void testEquals_SpecialConstants() {
              Complex zero1 = Complex.ZERO;
              Complex zero2 = new Complex(0.0, 0.0);
              Complex one1 = Complex.ONE;
              Complex one2 = new Complex(1.0, 0.0);
              Complex i1 = Complex.I;
              Complex i2 = new Complex(0.0, 1.0);
              
              assertTrue(zero1.equals(zero2));
              assertTrue(one1.equals(one2));
              assertTrue(i1.equals(i2));
          }

 @Test
          public void testEquals_FloatingPointPrecision() {
              Complex c1 = new Complex(0.1 + 0.2, 0.3 + 0.4);
              Complex c2 = new Complex(0.3, 0.7);
              assertTrue(c1.equals(c2));
          }

 @Test
      public void testEqualsWithNaN() {
          // Create two NaN Complex numbers
          Complex nan1 = new Complex(Double.NaN, Double.NaN);
          Complex nan2 = new Complex(Double.NaN, Double.NaN);
          
          // Verify they are equal (original behavior)
          // This will fail with the mutant which returns false for NaN comparison
          assertTrue(nan1.equals(nan2));
          
          // Also test non-NaN case to ensure we don't break normal equality
          Complex c1 = new Complex(1.0, 2.0);
          Complex c2 = new Complex(1.0, 2.0);
          assertTrue(c1.equals(c2));
          
          // Test inequality case
          Complex c3 = new Complex(1.0, 3.0);
          assertFalse(c1.equals(c3));
          
          // Test null case
          assertFalse(c1.equals(null));
          
          // Test different class case
          assertFalse(c1.equals("not a complex number"));
      }

 @Test
 public void testEqualsWithNonClassCastException() {
     // Create a real Complex object to test with
     Complex complex = new Complex(1.0, 2.0);
     
     // Create a mock object that throws RuntimeException when cast
     Object throwingObject = mock(Object.class);
     when(throwingObject.getClass()).thenThrow(new RuntimeException("Mock exception"));
     
     try {
         // Test with original code - should throw RuntimeException
         complex.equals(throwingObject);
         fail("Expected RuntimeException to be thrown");
     } catch (RuntimeException e) {
         // This is expected behavior for original code
         assertTrue(true);
     }
     
     // Note: The mutant would catch this exception and return false instead
     // So if this test passes (throws exception), the mutant is not present
     // If it fails (returns false), the mutant is detected
 }

}
