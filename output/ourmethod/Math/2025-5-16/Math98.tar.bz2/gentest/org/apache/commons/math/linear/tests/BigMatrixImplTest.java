package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.math.BigDecimal;
 
public class BigMatrixImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                                         public void testOperate_ValidSquareMatrix() {
                                                                                                                             // Create a 2x2 matrix
                                                                                                                             BigDecimal[][] data = {
                                                                                                                                 {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                                 {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                                             };
                                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                             
                                                                                                                             // Test vector
                                                                                                                             BigDecimal[] vector = {
                                                                                                                                 new BigDecimal("5"),
                                                                                                                                 new BigDecimal("6")
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] expected = {
                                                                                                                                 new BigDecimal("17"),  // 1*5 + 2*6
                                                                                                                                 new BigDecimal("39")   // 3*5 + 4*6
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] result = matrix.operate(vector);
                                                                                                                             
                                                                                                                             assertEquals(expected.length, result.length);
                                                                                                                             for (int i = 0; i < expected.length; i++) {
                                                                                                                                 assertEquals(expected[i], result[i]);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testOperate_ValidRectangularMatrix() {
                                                                                                                             // Create a 3x2 matrix
                                                                                                                             BigDecimal[][] data = {
                                                                                                                                 {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                                 {new BigDecimal("3"), new BigDecimal("4")},
                                                                                                                                 {new BigDecimal("5"), new BigDecimal("6")}
                                                                                                                             };
                                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                             
                                                                                                                             // Test vector
                                                                                                                             BigDecimal[] vector = {
                                                                                                                                 new BigDecimal("7"),
                                                                                                                                 new BigDecimal("8")
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] expected = {
                                                                                                                                 new BigDecimal("23"),  // 1*7 + 2*8
                                                                                                                                 new BigDecimal("53"),  // 3*7 + 4*8
                                                                                                                                 new BigDecimal("83")   // 5*7 + 6*8
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] result = matrix.operate(vector);
                                                                                                                             
                                                                                                                             assertEquals(expected.length, result.length);
                                                                                                                             for (int i = 0; i < expected.length; i++) {
                                                                                                                                 assertEquals(expected[i], result[i]);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testOperate_WithZeroVector() {
                                                                                                                             // Create a 2x2 matrix
                                                                                                                             BigDecimal[][] data = {
                                                                                                                                 {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                                 {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                                             };
                                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                             
                                                                                                                             // Zero vector
                                                                                                                             BigDecimal[] vector = {
                                                                                                                                 BigDecimal.ZERO,
                                                                                                                                 BigDecimal.ZERO
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] expected = {
                                                                                                                                 BigDecimal.ZERO,
                                                                                                                                 BigDecimal.ZERO
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] result = matrix.operate(vector);
                                                                                                                             
                                                                                                                             assertEquals(expected.length, result.length);
                                                                                                                             for (int i = 0; i < expected.length; i++) {
                                                                                                                                 assertEquals(expected[i], result[i]);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testOperate_WithNegativeValues() {
                                                                                                                             // Create a 2x2 matrix with negative values
                                                                                                                             BigDecimal[][] data = {
                                                                                                                                 {new BigDecimal("-1"), new BigDecimal("2")},
                                                                                                                                 {new BigDecimal("3"), new BigDecimal("-4")}
                                                                                                                             };
                                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                             
                                                                                                                             // Test vector with negative values
                                                                                                                             BigDecimal[] vector = {
                                                                                                                                 new BigDecimal("-5"),
                                                                                                                                 new BigDecimal("6")
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] expected = {
                                                                                                                                 new BigDecimal("17"),  // -1*-5 + 2*6
                                                                                                                                 new BigDecimal("-39")   // 3*-5 + -4*6
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] result = matrix.operate(vector);
                                                                                                                             
                                                                                                                             assertEquals(expected.length, result.length);
                                                                                                                             for (int i = 0; i < expected.length; i++) {
                                                                                                                                 assertEquals(expected[i], result[i]);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testOperate_WithDecimalValues() {
                                                                                                                             // Create a 2x2 matrix with decimal values
                                                                                                                             BigDecimal[][] data = {
                                                                                                                                 {new BigDecimal("1.5"), new BigDecimal("2.5")},
                                                                                                                                 {new BigDecimal("3.5"), new BigDecimal("4.5")}
                                                                                                                             };
                                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                             
                                                                                                                             // Test vector with decimal values
                                                                                                                             BigDecimal[] vector = {
                                                                                                                                 new BigDecimal("0.5"),
                                                                                                                                 new BigDecimal("1.5")
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] expected = {
                                                                                                                                 new BigDecimal("4.5"),  // 1.5*0.5 + 2.5*1.5
                                                                                                                                 new BigDecimal("8.5")  // 3.5*0.5 + 4.5*1.5
                                                                                                                             };
                                                                                                                             
                                                                                                                             BigDecimal[] result = matrix.operate(vector);
                                                                                                                             
                                                                                                                             assertEquals(expected.length, result.length);
                                                                                                                             for (int i = 0; i < expected.length; i++) {
                                                                                                                                 assertEquals(expected[i], result[i]);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testOperate_WithIdentityMatrix() {
                                                                                                                             // Create a 3x3 identity matrix
                                                                                                                             BigDecimal[][] data = {
                                                                                                                                 {BigDecimal.ONE, BigDecimal.ZERO, BigDecimal.ZERO},
                                                                                                                                 {BigDecimal.ZERO, BigDecimal.ONE, BigDecimal.ZERO},
                                                                                                                                 {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ONE}
                                                                                                                             };
                                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                             
                                                                                                                             // Test vector
                                                                                                                             BigDecimal[] vector = {
                                                                                                                                 new BigDecimal("5"),
                                                                                                                                 new BigDecimal("6"),
                                                                                                                                 new BigDecimal("7")
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Result should be same as input vector for identity matrix
                                                                                                                             BigDecimal[] result = matrix.operate(vector);
                                                                                                                             
                                                                                                                             assertEquals(vector.length, result.length);
                                                                                                                             for (int i = 0; i < vector.length; i++) {
                                                                                                                                 assertEquals(vector[i], result[i]);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                             public void testOperate_WithExtremeValues() {
                                                                                                                 double[] input = {Double.MAX_VALUE, Double.MIN_VALUE};
                                                                                                                 
                                                                                                                 // Mock the internal operate(BigDecimal[]) method
                                                                                                                 BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                                 BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                 
                                                                                                                 BigDecimal maxVal = new BigDecimal(Double.toString(Double.MAX_VALUE));
                                                                                                                 BigDecimal minVal = new BigDecimal(Double.toString(Double.MIN_VALUE));
                                                                                                                 BigDecimal two = new BigDecimal("2.0");
                                                                                                                 BigDecimal three = new BigDecimal("3.0");
                                                                                                                 BigDecimal four = new BigDecimal("4.0");
                                                                                                                 
                                                                                                                 BigDecimal[] expectedResult = {
                                                                                                                     maxVal.add(two.multiply(minVal)),
                                                                                                                     three.multiply(maxVal).add(four.multiply(minVal))
                                                                                                                 };
                                                                                                                 
                                                                                                                 doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                                 
                                                                                                                 BigDecimal[] result = spyMatrix.operate(input);
                                                                                                                 
                                                                                                                 assertNotNull(result);
                                                                                                                 assertEquals(2, result.length);
                                                                                                                 assertArrayEquals(expectedResult, result);
                                                                                                             }

 @Test
                                                                                                         public void testOperate_ThrowsExceptionWhenVectorLengthMismatch() {
                                                                                                             // Setup exception rule
                                                                                                             org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                             
                                                                                                             // Create a 2x2 matrix
                                                                                                             BigDecimal[][] data = {
                                                                                                                 {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                 {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                             };
                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                             
                                                                                                             // Vector with wrong length (3 instead of 2)
                                                                                                             BigDecimal[] wrongVector = {
                                                                                                                 new BigDecimal("1"),
                                                                                                                 new BigDecimal("2"),
                                                                                                                 new BigDecimal("3")
                                                                                                             };
                                                                                                             
                                                                                                             exception.expect(IllegalArgumentException.class);
                                                                                                             exception.expectMessage("vector has wrong length");
                                                                                                             
                                                                                                             matrix.operate(wrongVector);
                                                                                                         }

 @Test
                                                                                                         public void testOperate_WithEmptyMatrix() {
                                                                                                             // This should actually throw an exception in constructor, but testing for completeness
                                                                                                             ExpectedException exception = ExpectedException.none();
                                                                                                             exception.expect(IllegalArgumentException.class);
                                                                                                             exception.expectMessage("Matrix must have at least one row.");
                                                                                                             
                                                                                                             BigDecimal[][] emptyData = {};
                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(emptyData);
                                                                                                             
                                                                                                             BigDecimal[] vector = {};
                                                                                                             matrix.operate(vector);
                                                                                                         }

 @Test
                                                                                                         public void testOperate_ValidInput() {
                                                                                                             double[] input = {1.5, 2.5};
                                                                                                             
                                                                                                             // Create a matrix with dummy data first
                                                                                                             double[][] matrixData = {{1.0, 2.0}, {3.0, 4.0}};
                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                             
                                                                                                             // Mock the internal operate(BigDecimal[]) method to return expected result
                                                                                                             BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                             BigDecimal[] expectedResult = {new BigDecimal("8.5"), new BigDecimal("14.5")};
                                                                                                             doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                             
                                                                                                             BigDecimal[] result = spyMatrix.operate(input);
                                                                                                             
                                                                                                             assertNotNull(result);
                                                                                                             assertEquals(2, result.length);
                                                                                                             assertArrayEquals(expectedResult, result);
                                                                                                         }

 @Test
                                                                                                         public void testOperate_EmptyArray() {
                                                                                                             // Setup
                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(2, 2); // Create a 2x2 matrix that expects 2-element vectors
                                                                                                             double[] input = {};
                                                                                                             
                                                                                                             // Exception verification
                                                                                                             ExpectedException exception = ExpectedException.none();
                                                                                                             exception.expect(IllegalArgumentException.class);
                                                                                                             exception.expectMessage("vector has wrong length");
                                                                                                             
                                                                                                             // Test
                                                                                                             matrix.operate(input);
                                                                                                         }

 @Test(expected = IllegalArgumentException.class)
                                                                                                         public void testOperate_WrongLengthVector() {
                                                                                                             // Create a 2x2 matrix
                                                                                                             BigDecimal[][] data = {
                                                                                                                 {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                                                 {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                                                             };
                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                             
                                                                                                             // Create input vector with wrong length (3 elements for 2x2 matrix)
                                                                                                             double[] input = {1.0, 2.0, 3.0};
                                                                                                             
                                                                                                             // This should throw IllegalArgumentException
                                                                                                             matrix.operate(input);
                                                                                                         }

 @Test
                                                                                                         public void testOperate_WithSpecialDoubleValues() {
                                                                                                             double[] input = {Double.NaN, Double.POSITIVE_INFINITY};
                                                                                                             
                                                                                                             // Create a new matrix instance and then spy on it
                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                             BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                             
                                                                                                             BigDecimal[] expectedResult = {
                                                                                                                 new BigDecimal("NaN"),
                                                                                                                 new BigDecimal("Infinity")
                                                                                                             };
                                                                                                             doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                             
                                                                                                             BigDecimal[] result = spyMatrix.operate(input);
                                                                                                             
                                                                                                             assertNotNull(result);
                                                                                                             assertEquals(2, result.length);
                                                                                                             assertTrue(result[0].toString().equals("NaN"));
                                                                                                             assertTrue(result[1].toString().equals("Infinity"));
                                                                                                         }

 @Test
                                                                                                         public void testOperate_VerifyConversionAccuracy() {
                                                                                                             // Create test matrix data that matches the expected operation
                                                                                                             BigDecimal[][] testData = {
                                                                                                                 {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                                 {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                             };
                                                                                                             BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                                                             
                                                                                                             double[] input = {0.1, 0.2}; // These have exact decimal representations
                                                                                                             
                                                                                                             // Mock the internal operate(BigDecimal[]) method
                                                                                                             BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                             BigDecimal[] expectedResult = {
                                                                                                                 new BigDecimal("0.5"), // 1*0.1 + 2*0.2
                                                                                                                 new BigDecimal("1.1")  // 3*0.1 + 4*0.2
                                                                                                             };
                                                                                                             doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                             
                                                                                                             BigDecimal[] result = spyMatrix.operate(input);
                                                                                                             
                                                                                                             assertNotNull(result);
                                                                                                             assertEquals(2, result.length);
                                                                                                             assertEquals(new BigDecimal("0.5"), result[0]);
                                                                                                             assertEquals(new BigDecimal("1.1"), result[1]);
                                                                                                         }

 @Test
                                                                                                     public void testOperate_NullInput() {
                                                                                                         ExpectedException exception = ExpectedException.none();
                                                                                                         exception.expect(NullPointerException.class);
                                                                                                         BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                         matrix.operate((BigDecimal[]) null);
                                                                                                     }

 @Test(expected = MatrixIndexException.class)
                                                                        public void testGetRowAsDoubleArrayWithInvalidRow() {
                                                                            // Create a valid matrix first
                                                                            BigDecimal[][] data = {
                                                                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                            };
                                                                            BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                            
                                                                            // This should throw exception in original code but pass in mutated code
                                                                            int invalidRow = -1; // Clearly invalid row index
                                                                            matrix.getRowAsDoubleArray(invalidRow);
                                                                            
                                                                            // If we reach here in mutated version, the test fails
                                                                            // because no exception was thrown for invalid row
                                                                        }

 @Test
                                                                        public void testGetRowAsDoubleArrayWithValidRow() {
                                                                            // Create a test matrix with known values
                                                                            double[][] testData = {{1.0, 2.0}};
                                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                            
                                                                            int validRow = 0; // Valid row index
                                                                            double[] result = matrix.getRowAsDoubleArray(validRow);
                                                                            
                                                                            // Verify correct values are returned
                                                                            assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                                        }

 @Test(expected = MatrixIndexException.class)
                                                                        public void testGetRowAsDoubleArrayWithRowEqualToDimension() {
                                                                            // Boundary case - row equal to dimension is invalid
                                                                            BigDecimal[][] testData = {{new BigDecimal("1"), new BigDecimal("2")}, 
                                                                                                     {new BigDecimal("3"), new BigDecimal("4")}};
                                                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                            int invalidRow = matrix.getRowDimension();
                                                                            matrix.getRowAsDoubleArray(invalidRow);
                                                                        }

 @Test
                                                                   public void testGetRowAsDoubleArrayShouldPassForValidRowWhenColumnDimensionIsOne() {
                                                                       // This test will catch the mutant because:
                                                                       // - Original code checks column=0 (valid)
                                                                       // - Mutant checks column=1 (invalid for 1-column matrix)
                                                                       // - We expect this to work for original, throw exception for mutant
                                                                       
                                                                       // Create a 2x1 matrix (2 rows, 1 column)
                                                                       BigDecimal[][] testData = new BigDecimal[2][1];
                                                                       testData[0][0] = new BigDecimal("1.0");
                                                                       testData[1][0] = new BigDecimal("2.0");
                                                                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                       
                                                                       double[] expected = {2.0};
                                                                       double[] actual = matrix.getRowAsDoubleArray(1); // valid row index
                                                                       
                                                                       assertArrayEquals(expected, actual, 0.0001);
                                                                   }

 @Test(expected = MatrixIndexException.class)
                                                                   public void testGetRowAsDoubleArrayShouldThrowForInvalidRow() {
                                                                       // Create a 1x1 matrix (only row 0 is valid)
                                                                       BigDecimal[][] data = {{new BigDecimal("1.0")}};
                                                                       BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                       
                                                                       // Test with invalid row to ensure validation works in general
                                                                       matrix.getRowAsDoubleArray(2); // row index out of bounds
                                                                   }

 @Test
                                                                   public void testGetRowAsDoubleArrayThrowsMatrixIndexExceptionForInvalidRow() {
                                                                       // Setup - create a matrix with known dimensions
                                                                       BigDecimal[][] testData = {
                                                                           {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                           {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                                       };
                                                                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                       
                                                                       // Expect MatrixIndexException to be thrown
                                                                       thrown.expect(MatrixIndexException.class);
                                                                       thrown.expectMessage("illegal row argument");
                                                                       
                                                                       // Test with invalid row index (negative)
                                                                       matrix.getRowAsDoubleArray(-1);
                                                                       
                                                                       // Alternative test with row index too large
                                                                       // matrix.getRowAsDoubleArray(2); // would also be invalid for this 2x2 matrix
                                                                   }

 @Test
                                                              public void testGetRowAsDoubleArrayDetectsColumnDimensionMutant() {
                                                                  // Create a 2x3 matrix with known values
                                                                  double[][] testData = {
                                                                      {1.0, 2.0, 3.0},
                                                                      {4.0, 5.0, 6.0}
                                                                  };
                                                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                  
                                                                  // Test a valid row
                                                                  int testRow = 0;
                                                                  double[] result = matrix.getRowAsDoubleArray(testRow);
                                                                  
                                                                  // Verify array length matches column dimension (should be 3)
                                                                  assertEquals("Array length should match column dimension", 
                                                                              3, result.length);
                                                                  
                                                                  // Verify array contents match expected row values
                                                                  assertArrayEquals("Array contents should match row values",
                                                                                   testData[testRow], result, 0.0001);
                                                                  
                                                                  // Test another row to be thorough
                                                                  testRow = 1;
                                                                  result = matrix.getRowAsDoubleArray(testRow);
                                                                  assertEquals("Array length should match column dimension", 
                                                                              3, result.length);
                                                                  assertArrayEquals("Array contents should match row values",
                                                                                   testData[testRow], result, 0.0001);
                                                              }

 @Test
                                                             public void testGetRowAsDoubleArray_DetectsColumnDimensionMutation() {
                                                                 // Create a non-square matrix (3 rows x 2 columns)
                                                                 BigDecimal[][] testData = {
                                                                     {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                     {new BigDecimal("3.0"), new BigDecimal("4.0")},
                                                                     {new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                                 };
                                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                 
                                                                 // Test getting a row (row 1)
                                                                 double[] result = matrix.getRowAsDoubleArray(1);
                                                                 
                                                                 // Verify the array length matches column dimension (2), not row dimension (3)
                                                                 assertEquals(2, result.length);
                                                                 
                                                                 // Verify the values are correctly copied from row 1
                                                                 assertEquals(3.0, result[0], 0.0001);
                                                                 assertEquals(4.0, result[1], 0.0001);
                                                                 
                                                                 // Additional test with different row to be thorough
                                                                 double[] resultRow0 = matrix.getRowAsDoubleArray(0);
                                                                 assertEquals(2, resultRow0.length);
                                                                 assertEquals(1.0, resultRow0[0], 0.0001);
                                                                 assertEquals(2.0, resultRow0[1], 0.0001);
                                                             }

 @Test
                                                            public void testGetRowAsDoubleArray_ArraySizeMatchesColumnDimension() {
                                                                // Setup test data - create a 2x3 matrix
                                                                double[][] testData = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}};
                                                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                
                                                                // Get row as double array
                                                                double[] rowArray = matrix.getRowAsDoubleArray(0);
                                                                
                                                                // Verify array size matches column dimension
                                                                assertEquals("Array length should match column dimension", 
                                                                            matrix.getColumnDimension(), 
                                                                            rowArray.length);
                                                                
                                                                // Also verify content is correct (additional check)
                                                                assertArrayEquals(new double[]{1.0, 2.0, 3.0}, rowArray, 0.0001);
                                                            }

 @Test
                                                           public void testGetRowAsDoubleArrayDetectsNullArrayMutant() {
                                                               // Setup test data - create a simple 2x2 matrix
                                                               BigDecimal[][] testData = {
                                                                   {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                               };
                                                               BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                               
                                                               // Expected output for row 0
                                                               double[] expected = {1.0, 2.0};
                                                               
                                                               try {
                                                                   // Call the method
                                                                   double[] result = matrix.getRowAsDoubleArray(0);
                                                                   
                                                                   // Verify the result matches expected
                                                                   assertNotNull("Returned array should not be null", result);
                                                                   assertEquals("Array length should match column dimension", 
                                                                                expected.length, result.length);
                                                                   assertArrayEquals("Array contents should match", expected, result, 0.0001);
                                                               } catch (NullPointerException e) {
                                                                   // This will catch the mutant behavior
                                                                   fail("Method threw NullPointerException - mutant detected");
                                                               }
                                                           }

 @Test
                                                              public void testGetRowAsDoubleArrayDetectsMutant() {
                                                                  // Create a 2x3 matrix for testing
                                                                  BigDecimal[][] testData = {
                                                                      {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                                      {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                                  };
                                                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                  
                                                                  // Test with valid row index
                                                                  double[] row0 = matrix.getRowAsDoubleArray(0);
                                                                  assertEquals(3, row0.length);
                                                                  assertEquals(1.0, row0[0], 0.0001);
                                                                  assertEquals(2.0, row0[1], 0.0001);
                                                                  assertEquals(3.0, row0[2], 0.0001);
                                                                  
                                                                  // The mutated version would throw ArrayIndexOutOfBoundsException here
                                                                  // because it would try to access data[0][3] which is out of bounds
                                                                  double[] row1 = matrix.getRowAsDoubleArray(1);
                                                                  assertEquals(3, row1.length);
                                                                  assertEquals(4.0, row1[0], 0.0001);
                                                                  assertEquals(5.0, row1[1], 0.0001);
                                                                  assertEquals(6.0, row1[2], 0.0001);
                                                              }

 @Test
                                                         public void testMutantWouldFail() {
                                                             // This test shows what the mutant would do
                                                             BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                                                             BigMatrixImpl matrix = new BigMatrixImpl(testData) {
                                                                 // Override method to simulate mutant
                                                                 @Override
                                                                 public double[] getRowAsDoubleArray(int row) {
                                                                     // Skip the validation check to focus on the loop mutation
                                                                     final int ncols = this.getColumnDimension();
                                                                     final double[] out = new double[ncols];
                                                                     for (int i=0; i<=ncols; i++) { // Mutated condition
                                                                         out[i] = data[row][i].doubleValue();
                                                                     }
                                                                     return out;
                                                                 }
                                                             };
                                                             
                                                             // This will throw ArrayIndexOutOfBoundsException with the mutant
                                                             try {
                                                                 matrix.getRowAsDoubleArray(0);
                                                                 fail("Expected ArrayIndexOutOfBoundsException");
                                                             } catch (ArrayIndexOutOfBoundsException e) {
                                                                 // Expected behavior
                                                             }
                                                         }

 @Test
                                                     public void testGetRowAsDoubleArrayDetectsSkippedFirstElement() {
                                                         // Setup test data - create a 2x2 matrix with known values
                                                         BigDecimal[][] testData = {
                                                             {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                                             {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                                         };
                                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                         
                                                         // Test first row
                                                         double[] result = matrix.getRowAsDoubleArray(0);
                                                         
                                                         // Verify all elements are correctly copied
                                                         assertEquals(2, result.length);
                                                         assertEquals(1.1, result[0], 0.0001);  // This will fail with the mutant
                                                         assertEquals(2.2, result[1], 0.0001);
                                                         
                                                         // Test second row for completeness
                                                         result = matrix.getRowAsDoubleArray(1);
                                                         assertEquals(2, result.length);
                                                         assertEquals(3.3, result[0], 0.0001);  // This will fail with the mutant
                                                         assertEquals(4.4, result[1], 0.0001);
                                                     }

 @Test
                                                    public void testGetRowAsDoubleArrayDetectsIntValueMutant() {
                                                        // Setup test matrix with decimal values
                                                        BigDecimal[][] testData = {
                                                            {new BigDecimal("1.5"), new BigDecimal("2.3")},
                                                            {new BigDecimal("3.7"), new BigDecimal("4.1")}
                                                        };
                                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                        
                                                        // Call method under test
                                                        double[] result = matrix.getRowAsDoubleArray(0);
                                                        
                                                        // Verify exact double values (would fail if intValue() was used)
                                                        assertEquals(1.5, result[0], 0.0001);
                                                        assertEquals(2.3, result[1], 0.0001);
                                                        
                                                        // Test another row to be thorough
                                                        result = matrix.getRowAsDoubleArray(1);
                                                        assertEquals(3.7, result[0], 0.0001);
                                                        assertEquals(4.1, result[1], 0.0001);
                                                        
                                                        // Test with more precise decimals
                                                        BigDecimal[][] preciseData = {
                                                            {new BigDecimal("1.23456789"), new BigDecimal("9.87654321")}
                                                        };
                                                        matrix = new BigMatrixImpl(preciseData);
                                                        result = matrix.getRowAsDoubleArray(0);
                                                        assertEquals(1.23456789, result[0], 0.00000001);
                                                        assertEquals(9.87654321, result[1], 0.00000001);
                                                    }

 @Test
                                                   public void testGetRowAsDoubleArrayDetectsMutant1() {
                                                       // Create a non-square 2x3 matrix with distinct values
                                                       double[][] testData = {
                                                           {1.0, 2.0, 3.0},
                                                           {4.0, 5.0, 6.0}
                                                       };
                                                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                       
                                                       // Test getting first row
                                                       double[] expectedRow0 = {1.0, 2.0, 3.0};
                                                       double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                                       assertArrayEquals("First row values incorrect", expectedRow0, actualRow0, 0.0001);
                                                       
                                                       // Test getting second row
                                                       double[] expectedRow1 = {4.0, 5.0, 6.0};
                                                       double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                                       assertArrayEquals("Second row values incorrect", expectedRow1, actualRow1, 0.0001);
                                                       
                                                       // The mutant would fail here because:
                                                       // - For row 0, it would try to access data[0][0], data[1][0], data[2][0]
                                                       //   (last access would be out of bounds)
                                                       // - For row 1, it would try to access data[0][1], data[1][1], data[2][1]
                                                       //   (last access would be out of bounds)
                                                   }

 @Test
                                                  public void testGetRowAsDoubleArrayReturnsCorrectValues() {
                                                      // Setup test data with known non-zero values
                                                      double[][] testData = {
                                                          {1.5, 2.3, 3.7},
                                                          {4.1, 5.9, 6.2}
                                                      };
                                                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                      
                                                      // Call method under test
                                                      double[] result = matrix.getRowAsDoubleArray(0);
                                                      
                                                      // Verify the returned array contains correct values
                                                      assertEquals(3, result.length); // Verify array size
                                                      assertEquals(1.5, result[0], 0.0001); // Verify first element
                                                      assertEquals(2.3, result[1], 0.0001); // Verify second element
                                                      assertEquals(3.7, result[2], 0.0001); // Verify third element
                                                      
                                                      // Test another row for completeness
                                                      result = matrix.getRowAsDoubleArray(1);
                                                      assertEquals(3, result.length);
                                                      assertEquals(4.1, result[0], 0.0001);
                                                      assertEquals(5.9, result[1], 0.0001);
                                                      assertEquals(6.2, result[2], 0.0001);
                                                  }

 @Test
                                                 public void testGetRowAsDoubleArrayShouldReturnExactValues() {
                                                     // Setup test matrix with known values
                                                     double[][] testData = {{1.5, 2.0, 3.5}, {4.0, 5.5, 6.0}};
                                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                     
                                                     // Test row 0
                                                     double[] row0 = matrix.getRowAsDoubleArray(0);
                                                     assertEquals(1.5, row0[0], 0.0001);  // Verify first element
                                                     assertEquals(2.0, row0[1], 0.0001);  // Verify second element
                                                     assertEquals(3.5, row0[2], 0.0001);  // Verify third element
                                                     
                                                     // Test row 1
                                                     double[] row1 = matrix.getRowAsDoubleArray(1);
                                                     assertEquals(4.0, row1[0], 0.0001);  // Verify first element
                                                     assertEquals(5.5, row1[1], 0.0001);  // Verify second element
                                                     assertEquals(6.0, row1[2], 0.0001);  // Verify third element
                                                     
                                                     // Also test with zero values which would make the mutant obvious
                                                     double[][] zeroData = {{0.0, 0.0}, {0.0, 0.0}};
                                                     BigMatrixImpl zeroMatrix = new BigMatrixImpl(zeroData);
                                                     double[] zeroRow = zeroMatrix.getRowAsDoubleArray(0);
                                                     assertEquals(0.0, zeroRow[0], 0.0001);
                                                     assertEquals(0.0, zeroRow[1], 0.0001);
                                                 }

 @Test
                                                public void testGetRowAsDoubleArrayReturnsCorrectArray() {
                                                    // Setup test data - create a 2x3 matrix with known values
                                                    double[][] testData = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}};
                                                    BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                    
                                                    // Expected values for row 0
                                                    double[] expectedRow0 = {1.0, 2.0, 3.0};
                                                    
                                                    // Call method under test
                                                    double[] result = matrix.getRowAsDoubleArray(0);
                                                    
                                                    // Verify array length matches column dimension
                                                    assertEquals("Array length should match column dimension", 
                                                                 matrix.getColumnDimension(), result.length);
                                                    
                                                    // Verify array contents match expected values
                                                    assertArrayEquals("Returned array should contain row values", 
                                                                     expectedRow0, result, 0.0001);
                                                    
                                                    // Test another row for thoroughness
                                                    double[] expectedRow1 = {4.0, 5.0, 6.0};
                                                    result = matrix.getRowAsDoubleArray(1);
                                                    assertEquals("Array length should match column dimension", 
                                                                 matrix.getColumnDimension(), result.length);
                                                    assertArrayEquals("Returned array should contain row values", 
                                                                     expectedRow1, result, 0.0001);
                                                }

 @Test
                                                   public void testGetRowAsDoubleArrayDetectsSyntaxMutant() {
                                                       // Create a simple 2x2 matrix for testing
                                                       BigDecimal[][] testData = {
                                                           {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                           {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                       };
                                                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                       
                                                       // Test getting first row
                                                       double[] expectedRow0 = {1.0, 2.0};
                                                       double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                                       assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                                                       
                                                       // Test getting second row
                                                       double[] expectedRow1 = {3.0, 4.0};
                                                       double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                                       assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                                                       
                                                       // Test invalid row index
                                                       try {
                                                           matrix.getRowAsDoubleArray(-1);
                                                           fail("Expected MatrixIndexException for invalid row");
                                                       } catch (MatrixIndexException e) {
                                                           assertEquals("illegal row argument", e.getMessage());
                                                       }
                                                   }

 @Test
                                             public void testGetRowAsDoubleArray() {
                                                 // Setup test matrix with known values
                                                 BigDecimal[][] testData = {
                                                     {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                                     {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                                 };
                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                 
                                                 // Test valid row access
                                                 double[] row0 = matrix.getRowAsDoubleArray(0);
                                                 assertArrayEquals(new double[]{1.1, 2.2}, row0, 0.0001);
                                                 
                                                 double[] row1 = matrix.getRowAsDoubleArray(1);
                                                 assertArrayEquals(new double[]{3.3, 4.4}, row1, 0.0001);
                                                 
                                                 // Test invalid row access (negative)
                                                 try {
                                                     matrix.getRowAsDoubleArray(-1);
                                                     fail("Expected MatrixIndexException for negative row");
                                                 } catch (MatrixIndexException e) {
                                                     assertEquals("illegal row argument", e.getMessage());
                                                 }
                                                 
                                                 // Test invalid row access (too large)
                                                 try {
                                                     matrix.getRowAsDoubleArray(2);
                                                     fail("Expected MatrixIndexException for out-of-bounds row");
                                                 } catch (MatrixIndexException e) {
                                                     assertEquals("illegal row argument", e.getMessage());
                                                 }
                                                 
                                                 // Test empty matrix (should be prevented by constructor)
                                                 try {
                                                     BigDecimal[][] emptyData = {};
                                                     new BigMatrixImpl(emptyData).getRowAsDoubleArray(0);
                                                     fail("Expected IllegalArgumentException for empty matrix");
                                                 } catch (IllegalArgumentException e) {
                                                     // Expected
                                                 }
                                                 
                                                 // Test matrix with null data
                                                 try {
                                                     new BigMatrixImpl((BigDecimal[][])null).getRowAsDoubleArray(0);
                                                     fail("Expected NullPointerException for null matrix");
                                                 } catch (NullPointerException e) {
                                                     // Expected
                                                 }
                                             }

 @Test
                                             public void testGetRowAsDoubleArrayValidRow() {
                                                 // Setup test matrix with known values
                                                 BigDecimal[][] testData = {
                                                     {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                                     {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                                 };
                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                 
                                                 // Test first row
                                                 double[] row0 = matrix.getRowAsDoubleArray(0);
                                                 assertArrayEquals(new double[]{1.1, 2.2}, row0, 0.0001);
                                                 
                                                 // Test second row
                                                 double[] row1 = matrix.getRowAsDoubleArray(1);
                                                 assertArrayEquals(new double[]{3.3, 4.4}, row1, 0.0001);
                                             }

 @Test(expected = MatrixIndexException.class)
                                             public void testGetRowAsDoubleArrayInvalidRow() {
                                                 BigDecimal[][] testData = {
                                                     {new BigDecimal("1.0"), new BigDecimal("2.0")}
                                                 };
                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                 
                                                 // This should throw MatrixIndexException
                                                 matrix.getRowAsDoubleArray(-1);
                                             }

 @Test
                                             public void testGetRowAsDoubleArrayEmptyRow() {
                                                 BigDecimal[][] testData = {
                                                     {} // empty row
                                                 };
                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                 
                                                 // Should return empty array
                                                 double[] result = matrix.getRowAsDoubleArray(0);
                                                 assertEquals(0, result.length);
                                             }

 @Test
                                        public void testGetRowAsDoubleArray1() {
                                            // Setup test matrix with known values
                                            BigDecimal[][] testData = {
                                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                            };
                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                            
                                            // Test valid row access
                                            double[] row0 = matrix.getRowAsDoubleArray(0);
                                            assertArrayEquals(new double[]{1.0, 2.0}, row0, 0.0001);
                                            
                                            double[] row1 = matrix.getRowAsDoubleArray(1);
                                            assertArrayEquals(new double[]{3.0, 4.0}, row1, 0.0001);
                                            
                                            // Test invalid row indices
                                            try {
                                                matrix.getRowAsDoubleArray(-1);
                                                fail("Expected MatrixIndexException for negative row");
                                            } catch (MatrixIndexException e) {
                                                assertEquals("illegal row argument", e.getMessage());
                                            }
                                            
                                            try {
                                                matrix.getRowAsDoubleArray(2);
                                                fail("Expected MatrixIndexException for row >= row dimension");
                                            } catch (MatrixIndexException e) {
                                                assertEquals("illegal row argument", e.getMessage());
                                            }
                                            
                                            // Test with empty matrix
                                            BigDecimal[][] emptyData = new BigDecimal[0][0];
                                            BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                                            try {
                                                emptyMatrix.getRowAsDoubleArray(0);
                                                fail("Expected MatrixIndexException for empty matrix");
                                            } catch (MatrixIndexException e) {
                                                assertTrue(e.getMessage().contains("row argument"));
                                            }
                                            
                                            // Test with single element matrix
                                            BigDecimal[][] singleData = {{new BigDecimal("5.5")}};
                                            BigMatrixImpl singleMatrix = new BigMatrixImpl(singleData);
                                            double[] singleRow = singleMatrix.getRowAsDoubleArray(0);
                                            assertArrayEquals(new double[]{5.5}, singleRow, 0.0001);
                                        }

 @Test
                                           public void testOperateWithInvalidInputShouldThrowException() {
                                               // Setup
                                               BigDecimal[] invalidVector = null;
                                               BigDecimal[][] matrixData = {
                                                   {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                               };
                                               BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                               
                                               // Expect exception
                                               thrown.expect(IllegalArgumentException.class);
                                               
                                               // Test - this should throw IllegalArgumentException
                                               matrix.operate(invalidVector);
                                           }

 @Test
                                           public void testOperateWithWrongSizeVectorShouldThrowException() {
                                               // Setup
                                               BigDecimal[] wrongSizeVector = {new BigDecimal("1.0")}; // Only 1 element
                                               BigDecimal[][] matrixData = {
                                                   {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                               };
                                               BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                               
                                               // Expect exception
                                               thrown.expect(IllegalArgumentException.class);
                                               
                                               // Test - vector size doesn't match matrix column dimension
                                               matrix.operate(wrongSizeVector);
                                           }

 @Test
                                          public void testGetRowAsDoubleArrayWithDifferentLengthInput() {
                                              // Create a 2x3 matrix for testing
                                              BigDecimal[][] testData = {
                                                  {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                  {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                              };
                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                              
                                              // Test with array of correct length (should pass)
                                              double[] correctLengthArray = {1.0, 2.0, 3.0};
                                              double[] result = matrix.getRowAsDoubleArray(0);
                                              assertArrayEquals(correctLengthArray, result, 0.0001);
                                              
                                              // Test with array of shorter length (should fail)
                                              try {
                                                  double[] shortArray = {1.0, 2.0};
                                                  matrix.getRowAsDoubleArray(0);
                                                  fail("Should have thrown exception for short array");
                                              } catch (IllegalArgumentException e) {
                                                  // Expected
                                              }
                                              
                                              // Test with array of longer length (should fail in original, pass in mutant)
                                              try {
                                                  double[] longArray = {1.0, 2.0, 3.0, 4.0};
                                                  matrix.getRowAsDoubleArray(0);
                                                  // If we get here, the mutant survived
                                                  fail("Should have thrown exception for long array");
                                              } catch (IllegalArgumentException e) {
                                                  // Expected in original implementation
                                              }
                                          }

 @Test
                                    public void testGetRowAsDoubleArrayInvalidRowThrowsCorrectException() {
                                        // Create a test matrix with known dimensions (2x2)
                                        BigDecimal[][] testData = {
                                            {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                            {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                        };
                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                        
                                        try {
                                            // Try to get row with invalid index
                                            matrix.getRowAsDoubleArray(-1);
                                            fail("Expected MatrixIndexException");
                                        } catch (MatrixIndexException e) {
                                            // Verify the exact exception message
                                            assertEquals("illegal row argument", e.getMessage());
                                        }
                                        
                                        try {
                                            // Try to get row with index beyond matrix dimensions
                                            matrix.getRowAsDoubleArray(2);
                                            fail("Expected MatrixIndexException");
                                        } catch (MatrixIndexException e) {
                                            // Verify the exact exception message
                                            assertEquals("illegal row argument", e.getMessage());
                                        }
                                    }

 @Test
                                    public void testGetRowAsDoubleArrayValidRowReturnsCorrectValues() {
                                        // Create test matrix with known values
                                        double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                        
                                        // Test valid row access
                                        double[] row0 = matrix.getRowAsDoubleArray(0);
                                        assertArrayEquals(new double[]{1.0, 2.0}, row0, 0.0001);
                                        
                                        double[] row1 = matrix.getRowAsDoubleArray(1);
                                        assertArrayEquals(new double[]{3.0, 4.0}, row1, 0.0001);
                                    }

 @Test
                                public void testGetRowAsDoubleArray2() {
                                    // Setup test data
                                    BigDecimal[][] testData = {
                                        {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                        {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                    };
                                    BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                    
                                    // Test valid row
                                    double[] result = matrix.getRowAsDoubleArray(0);
                                    assertNotNull(result);
                                    assertEquals(2, result.length);
                                    assertEquals(1.0, result[0], 0.0001);
                                    assertEquals(2.0, result[1], 0.0001);
                                    
                                    // Test another valid row
                                    result = matrix.getRowAsDoubleArray(1);
                                    assertNotNull(result);
                                    assertEquals(2, result.length);
                                    assertEquals(3.0, result[0], 0.0001);
                                    assertEquals(4.0, result[1], 0.0001);
                                    
                                    // Test invalid row (should throw exception)
                                    try {
                                        matrix.getRowAsDoubleArray(-1);
                                        fail("Expected MatrixIndexException for invalid row");
                                    } catch (MatrixIndexException e) {
                                        // Expected
                                    }
                                    
                                    try {
                                        matrix.getRowAsDoubleArray(2);
                                        fail("Expected MatrixIndexException for invalid row");
                                    } catch (MatrixIndexException e) {
                                        // Expected
                                    }
                                }

 @Test
                               public void testGetRowAsDoubleArray3() {
                                   // Setup test matrix with known values
                                   BigDecimal[][] testData = {
                                       {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                       {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                   };
                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                   
                                   // Test normal case
                                   double[] row0 = matrix.getRowAsDoubleArray(0);
                                   assertArrayEquals(new double[]{1.1, 2.2}, row0, 0.0001);
                                   
                                   double[] row1 = matrix.getRowAsDoubleArray(1);
                                   assertArrayEquals(new double[]{3.3, 4.4}, row1, 0.0001);
                                   
                                   // Test invalid row cases
                                   try {
                                       matrix.getRowAsDoubleArray(-1);
                                       fail("Expected MatrixIndexException for negative row");
                                   } catch (MatrixIndexException e) {
                                       assertEquals("illegal row argument", e.getMessage());
                                   }
                                   
                                   try {
                                       matrix.getRowAsDoubleArray(2); // out of bounds
                                       fail("Expected MatrixIndexException for out-of-bounds row");
                                   } catch (MatrixIndexException e) {
                                       assertEquals("illegal row argument", e.getMessage());
                                   }
                                   
                                   // Test empty matrix case
                                   BigMatrixImpl emptyMatrix = new BigMatrixImpl(new BigDecimal[0][0]);
                                   try {
                                       emptyMatrix.getRowAsDoubleArray(0);
                                       fail("Expected MatrixIndexException for empty matrix");
                                   } catch (MatrixIndexException e) {
                                       assertEquals("illegal row argument", e.getMessage());
                                   }
                                   
                                   // Test matrix with null values (should throw NPE when converting)
                                   BigDecimal[][] nullData = {
                                       {new BigDecimal("1.1"), null}
                                   };
                                   BigMatrixImpl nullMatrix = new BigMatrixImpl(nullData);
                                   try {
                                       nullMatrix.getRowAsDoubleArray(0);
                                       fail("Expected NullPointerException");
                                   } catch (NullPointerException e) {
                                       // expected
                                   }
                               }

 @Test
                              public void testGetRowAsDoubleArrayShouldReturnExactArrayStructure() {
                                  // Setup test data
                                  BigDecimal[][] testData = {
                                      {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                      {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                  };
                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                  
                                  // Test first row
                                  double[] expectedRow0 = {1.0, 2.0, 3.0};
                                  double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                  assertArrayEquals("First row should match expected values", expectedRow0, actualRow0, 0.0001);
                                  
                                  // Test second row
                                  double[] expectedRow1 = {4.0, 5.0, 6.0};
                                  double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                  assertArrayEquals("Second row should match expected values", expectedRow1, actualRow1, 0.0001);
                                  
                                  // Verify array length matches column dimension
                                  assertEquals("Array length should match column dimension", 
                                              matrix.getColumnDimension(), actualRow0.length);
                                  
                                  // Verify invalid row throws exception
                                  try {
                                      matrix.getRowAsDoubleArray(-1);
                                      fail("Should throw MatrixIndexException for invalid row");
                                  } catch (MatrixIndexException e) {
                                      assertEquals("Exception message should match", 
                                                  "illegal row argument", e.getMessage());
                                  }
                                  
                                  try {
                                      matrix.getRowAsDoubleArray(2); // row index out of bounds
                                      fail("Should throw MatrixIndexException for out of bounds row");
                                  } catch (MatrixIndexException e) {
                                      assertEquals("Exception message should match", 
                                                  "illegal row argument", e.getMessage());
                                  }
                              }

 @Test
                            public void testGetRowAsDoubleArrayValidRow1() {
                                // Initialize test matrix with 2x2 data
                                double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                
                                // Test first row
                                double[] expected = {1.0, 2.0};
                                double[] actual = matrix.getRowAsDoubleArray(0);
                                assertArrayEquals(expected, actual, 0.0001);
                                
                                // Test second row
                                expected = new double[]{3.0, 4.0};
                                actual = matrix.getRowAsDoubleArray(1);
                                assertArrayEquals(expected, actual, 0.0001);
                            }

 @Test(expected = MatrixIndexException.class)
                            public void testGetRowAsDoubleArrayInvalidRow1() {
                                // Create a sample matrix
                                double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                
                                // This should throw MatrixIndexException
                                matrix.getRowAsDoubleArray(-1);
                            }

 @Test(expected = MatrixIndexException.class)
                            public void testGetRowAsDoubleArrayRowOutOfBounds() {
                                // Create a 2x2 matrix for testing
                                BigDecimal[][] testData = {
                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                };
                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                
                                // Try to access row 2 (should throw exception since valid rows are 0-1)
                                matrix.getRowAsDoubleArray(2);
                            }

 @Test
                            public void testGetRowAsDoubleArrayCompleteExecution() {
                                // This test ensures all code paths including all braces are executed
                                // Create a test matrix with 1 row and 2 columns
                                double[][] testData = {{1.0, 2.0}};
                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                
                                double[] result = matrix.getRowAsDoubleArray(0);
                                assertNotNull(result);
                                assertEquals(2, result.length);
                            }

 @Test
                        public void testGetRowAsDoubleArray_ValidRow_ReturnsCorrectArray() {
                            // Setup test data
                            BigDecimal[][] testData = {
                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                            };
                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                            
                            // Expected result
                            double[] expected = {1.0, 2.0};
                            
                            // Test execution - this will fail to compile if the mutant is present
                            double[] result = matrix.getRowAsDoubleArray(0);
                            
                            // Verification
                            assertArrayEquals(expected, result, 0.0001);
                            
                            // Additional verification for another row
                            double[] expectedRow1 = {3.0, 4.0};
                            double[] resultRow1 = matrix.getRowAsDoubleArray(1);
                            assertArrayEquals(expectedRow1, resultRow1, 0.0001);
                        }

 @Test(expected = NullPointerException.class)
                           public void testGetRowAsDoubleArrayPropagatesNullPointerException() {
                               // Mock the data array to contain null which will cause NPE when converting to double
                               BigDecimal[][] dataWithNull = {
                                   {new BigDecimal("1.0"), null},
                                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
                               };
                               
                               // Use the constructor that doesn't make a copy to allow our null to remain
                               BigMatrixImpl matrixWithNull = new BigMatrixImpl(dataWithNull, false);
                               
                               // This should throw NullPointerException when trying to convert null to double
                               matrixWithNull.getRowAsDoubleArray(0);
                           }

 @Test
                      public void testGetRowAsDoubleArrayValidInput() {
                          // Create test data
                          double[][] testData = {{1.0, 2.0}};
                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                          
                          double[] expected = {1.0, 2.0};
                          double[] actual = matrix.getRowAsDoubleArray(0);
                          assertArrayEquals(expected, actual, 0.0001);
                      }

 @Test(expected = MatrixIndexException.class)
                      public void testGetRowAsDoubleArrayInvalidRow2() {
                          BigDecimal[][] testData = new BigDecimal[][] {
                              {new BigDecimal("1"), new BigDecimal("2")},
                              {new BigDecimal("3"), new BigDecimal("4")}
                          };
                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                          matrix.getRowAsDoubleArray(-1); // Should throw MatrixIndexException
                      }

 @Test
                  public void testOperateWithWrongVectorLength() {
                      // Setup - create a 2x2 matrix
                      BigDecimal[][] data = {
                          {new BigDecimal("1.0"), new BigDecimal("2.0")},
                          {new BigDecimal("3.0"), new BigDecimal("4.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(data);
                      
                      // Create a vector with wrong length (3 elements instead of 2)
                      double[] wrongLengthVector = {1.0, 2.0, 3.0};
                      
                      try {
                          matrix.operate(wrongLengthVector);
                          fail("Expected IllegalArgumentException");
                      } catch (IllegalArgumentException e) {
                          // Verify the exact exception message
                          assertEquals("vector has wrong length", e.getMessage());
                      }
                  }

 @Test
                  public void testGetRowAsDoubleArrayWithInvalidRow1() {
                      // Setup - create a 2x2 matrix
                      BigDecimal[][] data = {
                          {new BigDecimal("1.0"), new BigDecimal("2.0")},
                          {new BigDecimal("3.0"), new BigDecimal("4.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(data);
                      
                      try {
                          // Try to get row with invalid index
                          matrix.getRowAsDoubleArray(-1);
                          fail("Expected MatrixIndexException");
                      } catch (MatrixIndexException e) {
                          // Verify the exact exception message
                          assertEquals("illegal row argument", e.getMessage());
                      }
                      
                      try {
                          // Try to get row with too large index
                          matrix.getRowAsDoubleArray(2);
                          fail("Expected MatrixIndexException");
                      } catch (MatrixIndexException e) {
                          // Verify the exact exception message
                          assertEquals("illegal row argument", e.getMessage());
                      }
                  }

 @Test
                 public void testGetRowAsDoubleArray4() {
                     // Setup test data
                     BigDecimal[][] testData = {
                         {new BigDecimal("1.0"), new BigDecimal("2.0")},
                         {new BigDecimal("3.0"), new BigDecimal("4.0")}
                     };
                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                     
                     // Test valid row
                     double[] result = matrix.getRowAsDoubleArray(0);
                     assertNotNull(result);
                     assertEquals(2, result.length);
                     assertEquals(1.0, result[0], 0.0001);
                     assertEquals(2.0, result[1], 0.0001);
                     
                     // Test another valid row
                     result = matrix.getRowAsDoubleArray(1);
                     assertNotNull(result);
                     assertEquals(2, result.length);
                     assertEquals(3.0, result[0], 0.0001);
                     assertEquals(4.0, result[1], 0.0001);
                     
                     // Test invalid row (negative)
                     try {
                         matrix.getRowAsDoubleArray(-1);
                         fail("Expected MatrixIndexException for negative row");
                     } catch (MatrixIndexException e) {
                         assertEquals("illegal row argument", e.getMessage());
                     }
                     
                     // Test invalid row (out of bounds)
                     try {
                         matrix.getRowAsDoubleArray(2);
                         fail("Expected MatrixIndexException for out-of-bounds row");
                     } catch (MatrixIndexException e) {
                         assertEquals("illegal row argument", e.getMessage());
                     }
                     
                     // Test empty matrix (shouldn't be possible based on constructors)
                     // But included for completeness
                     try {
                         BigDecimal[][] emptyData = {};
                         BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                         fail("Expected IllegalArgumentException for empty matrix");
                     } catch (IllegalArgumentException e) {
                         // Expected
                     }
                 }

 @Test
                public void testGetRowAsDoubleArray5() {
                    // Setup test data
                    BigDecimal[][] testData = {
                        {new BigDecimal("1.0"), new BigDecimal("2.0")},
                        {new BigDecimal("3.0"), new BigDecimal("4.0")}
                    };
                    BigMatrixImpl matrix = new BigMatrixImpl(testData);
                    
                    // Test valid row
                    double[] expected = {1.0, 2.0};
                    double[] actual = matrix.getRowAsDoubleArray(0);
                    assertArrayEquals(expected, actual, 0.0001);
                    
                    // Test another valid row
                    expected = new double[]{3.0, 4.0};
                    actual = matrix.getRowAsDoubleArray(1);
                    assertArrayEquals(expected, actual, 0.0001);
                    
                    // Test invalid row (should throw exception)
                    try {
                        matrix.getRowAsDoubleArray(2);
                        fail("Expected MatrixIndexException");
                    } catch (MatrixIndexException e) {
                        assertEquals("illegal row argument", e.getMessage());
                    }
                }

 @Test
               public void testGetRowAsDoubleArray6() throws Exception {
                   // Setup test matrix with known values
                   BigDecimal[][] testData = {
                       {new BigDecimal("1.1"), new BigDecimal("2.2")},
                       {new BigDecimal("3.3"), new BigDecimal("4.4")}
                   };
                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                   
                   // Test valid row access
                   double[] row0 = matrix.getRowAsDoubleArray(0);
                   assertNotNull(row0);
                   assertEquals(2, row0.length);
                   assertEquals(1.1, row0[0], 0.0001);
                   assertEquals(2.2, row0[1], 0.0001);
                   
                   double[] row1 = matrix.getRowAsDoubleArray(1);
                   assertNotNull(row1);
                   assertEquals(2, row1.length);
                   assertEquals(3.3, row1[0], 0.0001);
                   assertEquals(4.4, row1[1], 0.0001);
                   
                   // Test invalid row indices
                   try {
                       matrix.getRowAsDoubleArray(-1);
                       fail("Expected MatrixIndexException for negative row");
                   } catch (MatrixIndexException e) {
                       assertEquals("illegal row argument", e.getMessage());
                   }
                   
                   try {
                       matrix.getRowAsDoubleArray(2);
                       fail("Expected MatrixIndexException for row >= row dimension");
                   } catch (MatrixIndexException e) {
                       assertEquals("illegal row argument", e.getMessage());
                   }
                   
                   // Test with empty matrix (shouldn't happen due to constructor checks)
                   BigDecimal[][] emptyData = {{}};
                   BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                   double[] emptyRow = emptyMatrix.getRowAsDoubleArray(0);
                   assertNotNull(emptyRow);
                   assertEquals(0, emptyRow.length);
               }

 @Test
              public void testGetRowAsDoubleArray7() {
                  // Setup test data
                  BigDecimal[][] testData = {
                      {new BigDecimal("1.0"), new BigDecimal("2.0")},
                      {new BigDecimal("3.0"), new BigDecimal("4.0")}
                  };
                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                  
                  // Test valid row
                  double[] result = matrix.getRowAsDoubleArray(0);
                  assertEquals(2, result.length); // Verify array size
                  assertEquals(1.0, result[0], 0.0001); // Verify first value
                  assertEquals(2.0, result[1], 0.0001); // Verify second value
                  
                  // Test another valid row
                  result = matrix.getRowAsDoubleArray(1);
                  assertEquals(2, result.length);
                  assertEquals(3.0, result[0], 0.0001);
                  assertEquals(4.0, result[1], 0.0001);
                  
                  // Test invalid row (should throw exception)
                  try {
                      matrix.getRowAsDoubleArray(2);
                      fail("Expected MatrixIndexException for invalid row");
                  } catch (MatrixIndexException e) {
                      // Expected behavior
                  }
                  
                  // Test empty matrix (should throw exception)
                  try {
                      BigMatrixImpl emptyMatrix = new BigMatrixImpl(new BigDecimal[0][0]);
                      emptyMatrix.getRowAsDoubleArray(0);
                      fail("Expected IllegalArgumentException for empty matrix");
                  } catch (IllegalArgumentException e) {
                      // Expected behavior
                  }
              }

 @Test
             public void testGetRowAsDoubleArray8() {
                 // Setup test matrix with known values
                 BigDecimal[][] testData = {
                     {new BigDecimal("1.1"), new BigDecimal("2.2")},
                     {new BigDecimal("3.3"), new BigDecimal("4.4")}
                 };
                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                 
                 // Test valid row
                 double[] expectedRow0 = {1.1, 2.2};
                 double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                 assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                 
                 double[] expectedRow1 = {3.3, 4.4};
                 double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                 assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                 
                 // Test invalid row (should throw exception)
                 try {
                     matrix.getRowAsDoubleArray(2);
                     fail("Expected MatrixIndexException for invalid row");
                 } catch (MatrixIndexException e) {
                     assertEquals("illegal row argument", e.getMessage());
                 }
                 
                 try {
                     matrix.getRowAsDoubleArray(-1);
                     fail("Expected MatrixIndexException for negative row");
                 } catch (MatrixIndexException e) {
                     assertEquals("illegal row argument", e.getMessage());
                 }
                 
                 // Test empty matrix (should throw exception during construction)
                 try {
                     BigDecimal[][] emptyData = {};
                     new BigMatrixImpl(emptyData).getRowAsDoubleArray(0);
                     fail("Expected IllegalArgumentException for empty matrix");
                 } catch (IllegalArgumentException e) {
                     // expected
                 }
             }

 @Test
            public void testGetRowAsDoubleArrayWithDifferentColumnDimensions() {
                // Create a test matrix with 3 columns
                BigDecimal[][] testData = {
                    {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                    {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                
                // Test with valid row index (should pass)
                double[] result = matrix.getRowAsDoubleArray(0);
                assertEquals(3, result.length);
                assertEquals(1.0, result[0], 0.0001);
                assertEquals(2.0, result[1], 0.0001);
                assertEquals(3.0, result[2], 0.0001);
                
                // Test with invalid row index (should throw exception)
                try {
                    matrix.getRowAsDoubleArray(2);
                    fail("Expected MatrixIndexException for invalid row");
                } catch (MatrixIndexException e) {
                    // Expected
                }
                
                // The key test for the mutant - create a matrix with different column dimensions
                BigDecimal[][] unevenData = {
                    {new BigDecimal("1.0"), new BigDecimal("2.0")}, // 2 columns
                    {new BigDecimal("3.0"), new BigDecimal("4.0"), new BigDecimal("5.0")} // 3 columns
                };
                
                try {
                    BigMatrixImpl unevenMatrix = new BigMatrixImpl(unevenData);
                    fail("Expected IllegalArgumentException for uneven columns");
                } catch (IllegalArgumentException e) {
                    // This verifies the constructor validation still works
                    // The mutant would be caught by the fact that the constructor
                    // enforces equal column dimensions, preventing the scenario
                    // where the mutant would allow mismatched dimensions
                }
                
                // Alternative test that would catch the mutant directly if it was in a different method
                // This tests the implicit assumption that all rows have same number of columns
                double[] shortRow = {1.0, 2.0}; // length 2 vs expected 3
                try {
                    // If there was a method that took an array parameter and checked its length
                    // against column dimension, this would catch the mutant
                    // Since we don't see such method in the provided code, we rely on constructor validation
                    fail("Need to test array length validation, but no such method visible");
                } catch (IllegalArgumentException e) {
                    // Expected for original, would not be caught by mutant
                }
            }

 @Test
          public void testGetRowAsDoubleArrayInvalidRow3() {
              // Create a test matrix
              double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
              BigMatrixImpl matrix = new BigMatrixImpl(testData);
              
              try {
                  // Try to get a row with invalid index
                  matrix.getRowAsDoubleArray(-1);
                  fail("Expected MatrixIndexException for invalid row");
              } catch (MatrixIndexException e) {
                  // Verify the exception message matches exactly
                  assertEquals("illegal row argument", e.getMessage());
                  throw e; // rethrow to satisfy expected exception
              }
          }

 @Test
          public void testGetRowAsDoubleArrayValidRow2() {
              // Test with valid row index
              double[][] testData = {{1.0, 2.0}};
              BigMatrixImpl matrix = new BigMatrixImpl(testData);
              double[] result = matrix.getRowAsDoubleArray(0);
              assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
          }

 @Test
          public void testGetRowAsDoubleArrayWithDifferentValues() {
              BigDecimal[][] specialData = {
                  {new BigDecimal("0.0"), new BigDecimal("-1.5"), new BigDecimal("123.456")},
                  {new BigDecimal("1e-10"), new BigDecimal("1e10"), new BigDecimal("0.00001")}
              };
              BigMatrixImpl specialMatrix = new BigMatrixImpl(specialData);
              
              double[] expectedRow1 = {0.0, -1.5, 123.456};
              double[] expectedRow2 = {1e-10, 1e10, 0.00001};
              
              assertArrayEquals(expectedRow1, specialMatrix.getRowAsDoubleArray(0), 0.0001);
              assertArrayEquals(expectedRow2, specialMatrix.getRowAsDoubleArray(1), 0.0001);
          }

 @Test
          public void testGetRowAsDoubleArraySingleElementMatrix() {
              BigDecimal[][] singleData = {{new BigDecimal("42.0")}};
              BigMatrixImpl singleMatrix = new BigMatrixImpl(singleData);
              
              double[] expected = {42.0};
              assertArrayEquals(expected, singleMatrix.getRowAsDoubleArray(0), 0.0001);
          }

 @Test
     public void testGetRowAsDoubleArrayValidRow3() {
         // Create test matrix data
         double[][] testData = {
             {1.0, 2.0, 3.0},
             {4.0, 5.0, 6.0},
             {7.0, 8.0, 9.0}
         };
         BigMatrixImpl matrix = new BigMatrixImpl(testData);
         
         double[] expectedRow1 = {1.0, 2.0, 3.0};
         double[] expectedRow2 = {4.0, 5.0, 6.0};
         double[] expectedRow3 = {7.0, 8.0, 9.0};
         
         assertArrayEquals(expectedRow1, matrix.getRowAsDoubleArray(0), 0.0001);
         assertArrayEquals(expectedRow2, matrix.getRowAsDoubleArray(1), 0.0001);
         assertArrayEquals(expectedRow3, matrix.getRowAsDoubleArray(2), 0.0001);
     }

 @Test(expected = MatrixIndexException.class)
     public void testGetRowAsDoubleArrayNegativeRow() {
         // Create a sample matrix
         double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
         BigMatrixImpl matrix = new BigMatrixImpl(testData);
         
         // Test with negative row index which should throw exception
         matrix.getRowAsDoubleArray(-1);
     }

 @Test(expected = MatrixIndexException.class)
     public void testGetRowAsDoubleArrayRowOutOfBounds1() {
         // Create a 3x3 matrix (rows 0-2)
         BigDecimal[][] data = new BigDecimal[3][3];
         for (int i = 0; i < 3; i++) {
             for (int j = 0; j < 3; j++) {
                 data[i][j] = BigDecimal.ZERO;
             }
         }
         BigMatrixImpl matrix = new BigMatrixImpl(data);
         // Try to access row 3 which should throw exception
         matrix.getRowAsDoubleArray(3);
     }

 @Test
 public void testGetRowAsDoubleArray9() {
     // Setup test data
     BigDecimal[][] testData = {
         {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
         {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
     };
     BigMatrixImpl matrix = new BigMatrixImpl(testData);
     
     // Test normal case
     double[] row0 = matrix.getRowAsDoubleArray(0);
     assertEquals(3, row0.length);
     assertEquals(1.0, row0[0], 0.0001);
     assertEquals(2.0, row0[1], 0.0001);
     assertEquals(3.0, row0[2], 0.0001);
     
     // Test another row
     double[] row1 = matrix.getRowAsDoubleArray(1);
     assertEquals(3, row1.length);
     assertEquals(4.0, row1[0], 0.0001);
     assertEquals(5.0, row1[1], 0.0001);
     assertEquals(6.0, row1[2], 0.0001);
     
     // Test edge case - single element matrix
     BigDecimal[][] singleElement = {{new BigDecimal("9.9")}};
     BigMatrixImpl singleMatrix = new BigMatrixImpl(singleElement);
     double[] singleRow = singleMatrix.getRowAsDoubleArray(0);
     assertEquals(1, singleRow.length);
     assertEquals(9.9, singleRow[0], 0.0001);
     
     // Test invalid row
     try {
         matrix.getRowAsDoubleArray(-1);
         fail("Expected MatrixIndexException for invalid row");
     } catch (MatrixIndexException e) {
         // Expected behavior
     }
     
     try {
         matrix.getRowAsDoubleArray(2); // Only rows 0 and 1 exist
         fail("Expected MatrixIndexException for invalid row");
     } catch (MatrixIndexException e) {
         // Expected behavior
     }
 }

}
