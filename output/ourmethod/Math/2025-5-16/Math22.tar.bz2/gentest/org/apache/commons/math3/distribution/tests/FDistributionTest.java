package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.special.Beta;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class FDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                    public void testGetDenominatorDegreesOfFreedom_ConstructorWithZeroDenominator() {
                        double numeratorDof = 5.0;
                        double denominatorDof = 0.0;
                        
                        thrown.expect(org.apache.commons.math3.exception.NotStrictlyPositiveException.class);
                        thrown.expectMessage("degrees of freedom (0)");
                        
                        new FDistribution(numeratorDof, denominatorDof);
                    }

 @Test
                    public void testGetDenominatorDegreesOfFreedom_ConstructorWithNegativeDenominator() {
                        double numeratorDof = 5.0;
                        double denominatorDof = -1.0;
                        
                        thrown.expect(org.apache.commons.math3.exception.NotStrictlyPositiveException.class);
                        thrown.expectMessage("degrees of freedom (-1)");
                        
                        new FDistribution(numeratorDof, denominatorDof);
                    }

 @Test
                    public void testIsSupportLowerBoundInclusive() {
                        // Test with typical degrees of freedom
                        FDistribution dist1 = new FDistribution(5.0, 10.0);
                        assertFalse(dist1.isSupportLowerBoundInclusive());
                        
                        // Test with different degrees of freedom
                        FDistribution dist2 = new FDistribution(1.0, 1.0);
                        assertFalse(dist2.isSupportLowerBoundInclusive());
                        
                        // Test with large degrees of freedom
                        FDistribution dist3 = new FDistribution(100.0, 200.0);
                        assertFalse(dist3.isSupportLowerBoundInclusive());
                        
                        // Test with random generator constructor
                        FDistribution dist4 = new FDistribution(new Well19937c(), 2.0, 3.0, 1.0e-9);
                        assertFalse(dist4.isSupportLowerBoundInclusive());
                        
                        // Test with minimum valid degrees of freedom (just above 0)
                        FDistribution dist5 = new FDistribution(Double.MIN_VALUE, Double.MIN_VALUE);
                        assertFalse(dist5.isSupportLowerBoundInclusive());
                    }

 @Test
            public void testGetDenominatorDegreesOfFreedom_PositiveValues() {
                double numeratorDof = 5.0;
                double denominatorDof = 10.0;
                FDistribution dist = new FDistribution(numeratorDof, denominatorDof);
                
                assertEquals(denominatorDof, dist.getDenominatorDegreesOfFreedom(), 0.0001);
            }

 @Test
            public void testGetDenominatorDegreesOfFreedom_FractionalValues() {
                double numeratorDof = 2.5;
                double denominatorDof = 7.3;
                FDistribution dist = new FDistribution(numeratorDof, denominatorDof);
                
                assertEquals(denominatorDof, dist.getDenominatorDegreesOfFreedom(), 1e-15);
            }

 @Test
            public void testGetDenominatorDegreesOfFreedom_LargeValues() {
                double numeratorDof = 1000.0;
                double denominatorDof = 2000.0;
                FDistribution dist = new FDistribution(numeratorDof, denominatorDof);
                
                assertEquals(denominatorDof, dist.getDenominatorDegreesOfFreedom(), 1.0E-15);
            }

 @Test
            public void testGetDenominatorDegreesOfFreedom_WithInverseCumAccuracy() {
                double numeratorDof = 3.0;
                double denominatorDof = 8.0;
                double inverseCumAccuracy = 1e-12;
                double EPSILON = 1e-15;
                FDistribution dist = new FDistribution(numeratorDof, denominatorDof, inverseCumAccuracy);
                
                assertEquals(denominatorDof, dist.getDenominatorDegreesOfFreedom(), EPSILON);
            }

 @Test
            public void testGetDenominatorDegreesOfFreedom_WithRandomGenerator() {
                double numeratorDof = 4.0;
                double denominatorDof = 6.0;
                double inverseCumAccuracy = 1e-8;
                double EPSILON = 1e-15;
                FDistribution dist = new FDistribution(new org.apache.commons.math3.random.Well19937c(), 
                                                    numeratorDof, denominatorDof, inverseCumAccuracy);
                
                assertEquals(denominatorDof, dist.getDenominatorDegreesOfFreedom(), EPSILON);
            }

 @Test
            public void testGetSolverAbsoluteAccuracy_DefaultConstructor() throws Exception {
                // Using default accuracy
                FDistribution dist = new FDistribution(5.0, 10.0);
                
                // Use reflection to access protected method
                Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                method.setAccessible(true);
                double accuracy = (Double) method.invoke(dist);
                
                assertEquals(FDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY, accuracy, 0.0);
            }

 @Test
            public void testGetSolverAbsoluteAccuracy_CustomAccuracy() throws Exception {
                // Test with custom accuracy values
                double accuracy1 = 1e-6;
                FDistribution dist1 = new FDistribution(5.0, 10.0, accuracy1);
                // Use reflection to access protected method
                Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                method.setAccessible(true);
                assertEquals(accuracy1, (double) method.invoke(dist1), 0.0);
                
                double accuracy2 = 1e-12;
                FDistribution dist2 = new FDistribution(3.0, 7.0, accuracy2);
                assertEquals(accuracy2, (double) method.invoke(dist2), 0.0);
            }

 @Test
            public void testGetSolverAbsoluteAccuracy_ExtremeValues() throws Exception {
                // Test with very small and very large accuracy values
                double smallAccuracy = Double.MIN_VALUE;
                FDistribution dist1 = new FDistribution(2.0, 5.0, smallAccuracy);
                
                // Use reflection to access protected method
                Method getSolverAbsAccuracy = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                getSolverAbsAccuracy.setAccessible(true);
                double actualSmallAccuracy = (Double) getSolverAbsAccuracy.invoke(dist1);
                assertEquals(smallAccuracy, actualSmallAccuracy, 0.0);
            
                double largeAccuracy = 1.0;
                FDistribution dist2 = new FDistribution(1.0, 1.0, largeAccuracy);
                double actualLargeAccuracy = (Double) getSolverAbsAccuracy.invoke(dist2);
                assertEquals(largeAccuracy, actualLargeAccuracy, 0.0);
            }

 @Test
            public void testGetSolverAbsoluteAccuracy_FullConstructor() throws Exception {
                // Test with the full constructor including RandomGenerator
                double accuracy = 1e-8;
                FDistribution dist = new FDistribution(new Well19937c(), 4.0, 8.0, accuracy);
                
                // Use reflection to access protected method
                Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                method.setAccessible(true);
                double result = (Double) method.invoke(dist);
                
                assertEquals(accuracy, result, 0.0);
            }

 @Test
            public void testGetSolverAbsoluteAccuracy_Consistency() throws Exception {
                // Verify the value remains consistent after multiple calls
                double accuracy = 1e-10;
                FDistribution dist = new FDistribution(10.0, 20.0, accuracy);
                
                // Get the protected method using reflection
                Method getSolverAccuracy = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                getSolverAccuracy.setAccessible(true);
                
                // Multiple calls should return same value
                assertEquals(accuracy, (Double)getSolverAccuracy.invoke(dist), 0.0);
                assertEquals(accuracy, (Double)getSolverAccuracy.invoke(dist), 0.0);
                assertEquals(accuracy, (Double)getSolverAccuracy.invoke(dist), 0.0);
            }

 @Test
            public void testGetDenominatorDegreesOfFreedomReturnsExactValue() {
                // Test with normal value
                double testValue1 = 5.0;
                FDistribution dist1 = new FDistribution(2.0, testValue1);
                assertEquals("Should return exact denominator degrees of freedom", 
                            testValue1, 
                            dist1.getDenominatorDegreesOfFreedom(), 
                            0.0);
                
                // Test with very large value
                double testValue2 = Double.MAX_VALUE;
                FDistribution dist2 = new FDistribution(2.0, testValue2);
                assertEquals("Should handle maximum double value correctly",
                            testValue2,
                            dist2.getDenominatorDegreesOfFreedom(),
                            0.0);
                
                // Test with very small value
                double testValue3 = Double.MIN_VALUE;
                FDistribution dist3 = new FDistribution(2.0, testValue3);
                assertEquals("Should handle minimum double value correctly",
                            testValue3,
                            dist3.getDenominatorDegreesOfFreedom(),
                            0.0);
                
                // Test with non-integer value
                double testValue4 = 3.141592653589793;
                FDistribution dist4 = new FDistribution(2.0, testValue4);
                assertEquals("Should return exact non-integer value",
                            testValue4,
                            dist4.getDenominatorDegreesOfFreedom(),
                            0.0);
            }

 @Test
           public void testGetDenominatorDegreesOfFreedomReturnsExactValue1() {
               // Arrange
               double expectedDenominator = 5.0;
               FDistribution fDist = new FDistribution(2.0, expectedDenominator);
               
               // Act
               double actualDenominator = fDist.getDenominatorDegreesOfFreedom();
               
               // Assert
               // Using delta=0 to ensure exact equality catches any floating-point arithmetic
               assertEquals("Denominator degrees of freedom should return exact stored value",
                           expectedDenominator, actualDenominator, 0.0);
               
               // Additional check to ensure reference equality for primitive double
               assertTrue(Double.doubleToLongBits(expectedDenominator) == 
                        Double.doubleToLongBits(actualDenominator));
           }

 @Test
           public void testGetDenominatorDegreesOfFreedomWithNonIntegerValue() {
               // Arrange
               double expectedDenominator = 3.141592653589793;
               FDistribution fDist = new FDistribution(2.0, expectedDenominator);
               
               // Act
               double actualDenominator = fDist.getDenominatorDegreesOfFreedom();
               
               // Assert
               // Using delta=0 to catch any floating-point arithmetic changes
               assertEquals("Should return exact stored value for non-integer denominators",
                           expectedDenominator, actualDenominator, 0.0);
           }

 @Test
          public void testGetDenominatorDegreesOfFreedomReturnsOriginalValue() {
              // Test with various positive values
              double[] testValues = {1.0, 2.5, 10.0, 100.0, 0.1};
              
              for (double value : testValues) {
                  // Create FDistribution with test value as denominator degrees of freedom
                  FDistribution dist = new FDistribution(1.0, value);
                  
                  // Verify the getter returns exactly what was set
                  assertEquals("Getter should return original denominator degrees of freedom",
                              value, dist.getDenominatorDegreesOfFreedom(), 0.0);
              }
          }

 @Test
          public void testGetDenominatorDegreesOfFreedomWithLargeValue() {
              double largeValue = 1.0e300;
              FDistribution dist = new FDistribution(1.0, largeValue);
              
              assertEquals("Getter should handle very large values correctly",
                         largeValue, dist.getDenominatorDegreesOfFreedom(), 0.0);
          }

 @Test
          public void testGetDenominatorDegreesOfFreedomWithSmallPositiveValue() {
              double smallValue = Double.MIN_VALUE;
              FDistribution dist = new FDistribution(1.0, smallValue);
              
              assertEquals("Getter should handle very small positive values correctly",
                         smallValue, dist.getDenominatorDegreesOfFreedom(), 0.0);
          }

 @Test
         public void testGetDenominatorDegreesOfFreedom() {
             // Test normal case
             FDistribution dist1 = new FDistribution(5.0, 10.0);
             assertEquals(10.0, dist1.getDenominatorDegreesOfFreedom(), 0.0001);
             
             // Test case with very small denominator degrees of freedom
             double smallValue = Double.MIN_VALUE;
             FDistribution dist2 = new FDistribution(5.0, smallValue);
             assertEquals(smallValue, dist2.getDenominatorDegreesOfFreedom(), 0.0);
             
             // Test case with typical non-integer value
             FDistribution dist3 = new FDistribution(3.5, 7.25);
             assertEquals(7.25, dist3.getDenominatorDegreesOfFreedom(), 0.0001);
         }

 @Test
        public void testGetDenominatorDegreesOfFreedom1() {
            // Test with normal positive value
            double testValue1 = 5.0;
            FDistribution dist1 = new FDistribution(2.0, testValue1);
            assertEquals("Should return exact denominator degrees of freedom", 
                        testValue1, 
                        dist1.getDenominatorDegreesOfFreedom(), 
                        0.0);
            
            // Test with very large value
            double testValue2 = 1.0e300;
            FDistribution dist2 = new FDistribution(2.0, testValue2);
            assertEquals("Should return exact denominator degrees of freedom for large values",
                        testValue2,
                        dist2.getDenominatorDegreesOfFreedom(),
                        0.0);
            
            // Test with very small positive value
            double testValue3 = Double.MIN_VALUE;
            FDistribution dist3 = new FDistribution(2.0, testValue3);
            assertEquals("Should return exact denominator degrees of freedom for small values",
                        testValue3,
                        dist3.getDenominatorDegreesOfFreedom(),
                        0.0);
            
            // Test with non-integer value
            double testValue4 = 3.141592653589793;
            FDistribution dist4 = new FDistribution(2.0, testValue4);
            assertEquals("Should return exact denominator degrees of freedom for precise values",
                        testValue4,
                        dist4.getDenominatorDegreesOfFreedom(),
                        0.0);
        }

 @Test
       public void testGetDenominatorDegreesOfFreedomReturnsExactValue2() {
           // Test with normal value
           double testValue = 5.0;
           FDistribution dist = new FDistribution(2.0, testValue);
           // Use == comparison to ensure no arithmetic was performed
           assertTrue(dist.getDenominatorDegreesOfFreedom() == testValue);
           
           // Test with edge cases
           testValue = Double.MAX_VALUE;
           dist = new FDistribution(2.0, testValue);
           assertTrue(dist.getDenominatorDegreesOfFreedom() == testValue);
           
           testValue = Double.MIN_VALUE;
           dist = new FDistribution(2.0, testValue);
           assertTrue(dist.getDenominatorDegreesOfFreedom() == testValue);
           
           // Test with special floating-point value
           testValue = Double.NaN;
           dist = new FDistribution(2.0, testValue);
           assertTrue(Double.isNaN(dist.getDenominatorDegreesOfFreedom()));
       }

 @Test
      public void testGetDenominatorDegreesOfFreedomReturnsOriginalValue1() {
          // Test with positive value
          double positiveValue = 5.0;
          FDistribution distPositive = new FDistribution(2.0, positiveValue);
          assertEquals(positiveValue, distPositive.getDenominatorDegreesOfFreedom(), 0.0001);
          
          // Test with negative value - this will detect the mutant
          // Note: The constructor actually throws exception for negative values,
          // so we need to use reflection to set the negative value
          
          try {
              // Create with positive value first
              FDistribution dist = new FDistribution(2.0, 1.0);
              
              // Use reflection to set negative denominator value
              java.lang.reflect.Field field = FDistribution.class.getDeclaredField("denominatorDegreesOfFreedom");
              field.setAccessible(true);
              double negativeValue = -3.0;
              field.set(dist, negativeValue);
              
              // Test that getter returns the exact negative value
              assertEquals(negativeValue, dist.getDenominatorDegreesOfFreedom(), 0.0001);
          } catch (Exception e) {
              fail("Exception occurred during test: " + e.getMessage());
          }
      }

 @Test
     public void testGetDenominatorDegreesOfFreedom2() {
         // Test with normal positive value
         double testValue = 5.0;
         FDistribution dist = new FDistribution(2.0, testValue);
         assertEquals("Should return exact denominator degrees of freedom", 
                      testValue, 
                      dist.getDenominatorDegreesOfFreedom(), 
                      0.0001);
         
         // Test with another positive value
         testValue = 10.5;
         dist = new FDistribution(3.0, testValue);
         assertEquals("Should return exact denominator degrees of freedom", 
                      testValue, 
                      dist.getDenominatorDegreesOfFreedom(), 
                      0.0001);
         
         // Test with very small positive value (close to 0 but not 0)
         testValue = Double.MIN_VALUE;
         dist = new FDistribution(1.0, testValue);
         assertEquals("Should return exact denominator degrees of freedom even for very small values", 
                      testValue, 
                      dist.getDenominatorDegreesOfFreedom(), 
                      0.0001);
     }

}
