package gentest.org.apache.commons.math3.optim.nonlinear.vector.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.nonlinear.vector.*;
import org.apache.commons.math3.optim.OptimizationData;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.NonSquareMatrixException;
 
public class WeightTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                public void testConstructor_ValidWeights() {
                                                                    double[] weights = {1.0, 2.0, 3.0};
                                                                    Weight weight = new Weight(weights);
                                                                    
                                                                    RealMatrix result = weight.getWeight();
                                                                    assertNotNull(result);
                                                                    assertTrue(result instanceof DiagonalMatrix);
                                                                    
                                                                    // Verify diagonal values
                                                                    assertEquals(1.0, result.getEntry(0, 0), 0.0001);
                                                                    assertEquals(2.0, result.getEntry(1, 1), 0.0001);
                                                                    assertEquals(3.0, result.getEntry(2, 2), 0.0001);
                                                                    
                                                                    // Verify non-diagonal values are zero
                                                                    assertEquals(0.0, result.getEntry(0, 1), 0.0001);
                                                                    assertEquals(0.0, result.getEntry(1, 2), 0.0001);
                                                                }

    @Test
                                                                public void testConstructor_SingleWeight() {
                                                                    double[] weights = {5.0};
                                                                    Weight weight = new Weight(weights);
                                                                    
                                                                    RealMatrix result = weight.getWeight();
                                                                    assertEquals(1, result.getRowDimension());
                                                                    assertEquals(1, result.getColumnDimension());
                                                                    assertEquals(5.0, result.getEntry(0, 0), 0.0001);
                                                                }

    @Test
                                                                public void testConstructor_LargeArray() {
                                                                    double[] weights = new double[1000];
                                                                    for (int i = 0; i < weights.length; i++) {
                                                                        weights[i] = i * 0.1;
                                                                    }
                                                                    
                                                                    Weight weight = new Weight(weights);
                                                                    RealMatrix result = weight.getWeight();
                                                                    
                                                                    assertEquals(1000, result.getRowDimension());
                                                                    assertEquals(1000, result.getColumnDimension());
                                                                    
                                                                    // Verify first, middle and last elements
                                                                    assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                                    assertEquals(499.9, result.getEntry(499, 499), 0.0001);
                                                                    assertEquals(99.9, result.getEntry(999, 999), 0.0001);
                                                                }

    @Test
                                                                public void testConstructor_ZeroWeights() {
                                                                    double[] weights = {0.0, 0.0, 0.0};
                                                                    Weight weight = new Weight(weights);
                                                                    
                                                                    RealMatrix result = weight.getWeight();
                                                                    assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                                    assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                                    assertEquals(0.0, result.getEntry(2, 2), 0.0001);
                                                                }

    @Test
                                                                public void testConstructor_NegativeWeights() {
                                                                    double[] weights = {-1.0, -2.0, -3.0};
                                                                    Weight weight = new Weight(weights);
                                                                    
                                                                    RealMatrix result = weight.getWeight();
                                                                    assertEquals(-1.0, result.getEntry(0, 0), 0.0001);
                                                                    assertEquals(-2.0, result.getEntry(1, 1), 0.0001);
                                                                    assertEquals(-3.0, result.getEntry(2, 2), 0.0001);
                                                                }

    @Test
                                                                public void testConstructor_ValidSquareMatrix() {
                                                                    // Create a 2x2 matrix
                                                                    RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                    when(mockMatrix.getRowDimension()).thenReturn(2);
                                                                    when(mockMatrix.getColumnDimension()).thenReturn(2);
                                                                    when(mockMatrix.copy()).thenReturn(mockMatrix);
                                                            
                                                                    Weight weight = new Weight(mockMatrix);
                                                                    
                                                                    // Verify the matrix was copied
                                                                    verify(mockMatrix).copy();
                                                                    // Verify the stored matrix is the same as the input
                                                                    assertSame(mockMatrix, weight.getWeight());
                                                                }

    @Test
                                                                public void testConstructor_NonSquareMatrix_ThrowsException() {
                                                                    // Create a non-square matrix (2x3)
                                                                    RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                    when(mockMatrix.getRowDimension()).thenReturn(2);
                                                                    when(mockMatrix.getColumnDimension()).thenReturn(3);
                                                            
                                                                    thrown.expect(NonSquareMatrixException.class);
                                                                    thrown.expectMessage("2x3");
                                                                    
                                                                    new Weight(mockMatrix);
                                                                }

    @Test
                                                                public void testConstructor_EmptyMatrix() {
                                                                    // Create a 0x0 matrix (edge case)
                                                                    RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                    when(mockMatrix.getRowDimension()).thenReturn(0);
                                                                    when(mockMatrix.getColumnDimension()).thenReturn(0);
                                                                    when(mockMatrix.copy()).thenReturn(mockMatrix);
                                                            
                                                                    Weight weight = new Weight(mockMatrix);
                                                                    
                                                                    assertSame(mockMatrix, weight.getWeight());
                                                                }

    @Test
                                                                public void testConstructor_MatrixWithSingleElement() {
                                                                    // Create a 1x1 matrix (edge case)
                                                                    RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                    when(mockMatrix.getRowDimension()).thenReturn(1);
                                                                    when(mockMatrix.getColumnDimension()).thenReturn(1);
                                                                    when(mockMatrix.copy()).thenReturn(mockMatrix);
                                                            
                                                                    Weight weight = new Weight(mockMatrix);
                                                                    
                                                                    assertSame(mockMatrix, weight.getWeight());
                                                                }

    @Test
                                                        public void testConstructor_EmptyArray() {
                                                            org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                            exceptionRule.expect(IllegalArgumentException.class);
                                                            exceptionRule.expectMessage("Weight array cannot be empty");
                                                            
                                                            double[] weights = {};
                                                            new Weight(weights);
                                                        }

    @Test
                                                        public void testConstructor_NullInput() {
                                                            ExpectedException exceptionRule = ExpectedException.none();
                                                            exceptionRule.expect(NullPointerException.class);
                                                            exceptionRule.expectMessage("Weight array cannot be null");
                                                            new Weight((double[]) null);
                                                        }

    @Test
                                                        public void testConstructor_ContainsInfinity() {
                                                            ExpectedException exceptionRule = ExpectedException.none();
                                                            exceptionRule.expect(IllegalArgumentException.class);
                                                            exceptionRule.expectMessage("Weight values must be finite numbers");
                                                            
                                                            double[] weights = {1.0, Double.POSITIVE_INFINITY, 2.0};
                                                            new Weight(weights);
                                                        }

    @Test(expected = IllegalArgumentException.class)
            public void testConstructor_ContainsNaN() {
                double[] weights = {1.0, Double.NaN, 2.0};
                new Weight(weights);
            }

    @Test
    public void testConstructor_VerifyDeepCopy() {
        // Test that the constructor makes a deep copy
        double[][] data = {{1.0, 0.0}, {0.0, 1.0}};
        RealMatrix originalMatrix = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
        
        Weight weight = new Weight(originalMatrix);
        RealMatrix storedMatrix = weight.getWeight();
        
        // Verify it's not the same object
        assertNotSame(originalMatrix, storedMatrix);
        // Verify the content is the same
        assertArrayEquals(originalMatrix.getData(), storedMatrix.getData());
    }


}
