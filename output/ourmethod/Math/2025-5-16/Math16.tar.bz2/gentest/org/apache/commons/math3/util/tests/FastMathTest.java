package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                     public void testCosh_TypicalValues() {
                                                         // Values between -20 and 20
                                                         assertEquals(1.0, FastMath.cosh(0.0), 1e-15);
                                                         assertEquals(1.5430806348152437, FastMath.cosh(1.0), 1e-15);
                                                         assertEquals(1.5430806348152437, FastMath.cosh(-1.0), 1e-15);
                                                         assertEquals(3.7621956910836314, FastMath.cosh(2.0), 1e-15);
                                                         assertEquals(10.067661995777765, FastMath.cosh(3.0), 1e-15);
                                                     }

 @Test
                                                     public void testCosh_NaNInput() {
                                                         assertTrue(Double.isNaN(FastMath.cosh(Double.NaN)));
                                                     }

 @Test
                                                     public void testCosh_InfinityInputs() {
                                                         assertEquals(Double.POSITIVE_INFINITY, FastMath.cosh(Double.POSITIVE_INFINITY), 0.0);
                                                         assertEquals(Double.POSITIVE_INFINITY, FastMath.cosh(Double.NEGATIVE_INFINITY), 0.0);
                                                     }

 @Test
                                                     public void testCosh_BoundaryValues() {
                                                         // Just above and below 20
                                                         double expected19 = (Math.exp(19) + Math.exp(-19)) / 2;
                                                         assertEquals(expected19, FastMath.cosh(19), expected19 * 1e-15);
                                                         
                                                         double expected20 = (Math.exp(20) + Math.exp(-20)) / 2;
                                                         assertEquals(expected20, FastMath.cosh(20), expected20 * 1e-15);
                                                         
                                                         double expected21 = 0.5 * Math.exp(21);
                                                         assertEquals(expected21, FastMath.cosh(21), expected21 * 1e-15);
                                                         
                                                         // Negative equivalents
                                                         assertEquals(expected19, FastMath.cosh(-19), expected19 * 1e-15);
                                                         assertEquals(expected20, FastMath.cosh(-20), expected20 * 1e-15);
                                                         assertEquals(expected21, FastMath.cosh(-21), expected21 * 1e-15);
                                                     }

 @Test
                                                     public void testCosh_VerySmallValues() {
                                                         assertEquals(1.0, FastMath.cosh(1e-10), 1e-15);
                                                         assertEquals(1.0, FastMath.cosh(-1e-10), 1e-15);
                                                         assertEquals(1.0, FastMath.cosh(0.0), 1e-15);
                                                     }

 @Test
                                                     public void testCosh_NumericalStability() {
                                                         // Test that small negative values are handled correctly (should be same as positive)
                                                         for (double x = -1.0; x <= 1.0; x += 0.01) {
                                                             assertEquals(FastMath.cosh(x), FastMath.cosh(-x), 1e-15);
                                                         }
                                                     }

 @Test
                                                     public void testSinh_NaN() {
                                                         double result = FastMath.sinh(Double.NaN);
                                                         assertTrue(Double.isNaN(result));
                                                     }

 @Test
                                                     public void testSinh_Zero() {
                                                         assertEquals(0.0, FastMath.sinh(0.0), 0.0);
                                                         assertEquals(-0.0, FastMath.sinh(-0.0), 0.0);
                                                     }

 @Test
                                                     public void testSinh_LargePositiveValue() {
                                                         // Test value above 20 but below LOG_MAX_VALUE
                                                         double x = 25.0;
                                                         double expected = 0.5 * Math.exp(x);
                                                         assertEquals(expected, FastMath.sinh(x), expected * 1.0e-15);
                                                 
                                                         // Test value above LOG_MAX_VALUE (overflow protection)
                                                         x = 1000.0;
                                                         double t = Math.exp(0.5 * x);
                                                         expected = 0.5 * t * t;
                                                         assertEquals(expected, FastMath.sinh(x), expected * 1.0e-15);
                                                     }

 @Test
                                                     public void testSinh_LargeNegativeValue() {
                                                         // Test value below -20 but above -LOG_MAX_VALUE
                                                         double x = -25.0;
                                                         double expected = -0.5 * Math.exp(-x);
                                                         assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1.0e-15);
                                                 
                                                         // Test value below -LOG_MAX_VALUE (overflow protection)
                                                         x = -1000.0;
                                                         double t = Math.exp(-0.5 * x);
                                                         expected = -0.5 * t * t;
                                                         assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1.0e-15);
                                                     }

 @Test
                                                     public void testSinh_SmallPositiveValue() {
                                                         double x = 0.1;
                                                         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                 
                                                         x = 0.25; // Boundary for different algorithm path
                                                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                     }

 @Test
                                                     public void testSinh_SmallNegativeValue() {
                                                         double x = -0.1;
                                                         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                 
                                                         x = -0.25; // Boundary for different algorithm path
                                                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                     }

 @Test
                                                     public void testSinh_MediumPositiveValue() {
                                                         double x = 1.0;
                                                         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                 
                                                         x = 10.0;
                                                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), expected * 1.0e-15);
                                                     }

 @Test
                                                     public void testSinh_MediumNegativeValue() {
                                                         double x = -1.0;
                                                         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                 
                                                         x = -10.0;
                                                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1.0e-15);
                                                     }

 @Test
                                                     public void testSinh_ExtremeValues() {
                                                         // Test with very small values
                                                         double x = 1.0e-20;
                                                         assertEquals(x, FastMath.sinh(x), 0.0);
                                                 
                                                         x = -1.0e-20;
                                                         assertEquals(x, FastMath.sinh(x), 0.0);
                                                     }

 @Test
                                                     public void testSinh_ConsistencyWithMath() {
                                                         // Test consistency with standard Math library for various values
                                                         double[] testValues = {0.01, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, -0.01, -0.1, -0.5, -1.0, -2.0, -5.0, -10.0, -15.0};
                                                         
                                                         for (double x : testValues) {
                                                             double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                             assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1.0e-15);
                                                         }
                                                     }

 @Test
                                                     public void testSinh_AlgorithmBoundary() {
                                                         // Test around the 0.25 boundary where algorithm changes
                                                         double x = 0.24;
                                                         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                 
                                                         x = 0.26;
                                                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                         assertEquals(expected, FastMath.sinh(x), 1.0e-15);
                                                     }

 @Test
                                             public void testCosh_LargePositiveValues() {
                                                 // Values > 20
                                                 double expected1 = 0.5 * Math.exp(25);
                                                 assertEquals(expected1, FastMath.cosh(25), expected1 * 1e-15);
                                                 
                                                 // Very large value that triggers overflow protection
                                                 // Using a value larger than typical LOG_MAX_VALUE (which is around 709.78 for double)
                                                 double veryLarge = 710 * 2;
                                                 double expected2 = 0.5 * Math.exp(veryLarge * 0.5) * Math.exp(veryLarge * 0.5);
                                                 assertEquals(expected2, FastMath.cosh(veryLarge), expected2 * 1e-15);
                                             }

 @Test
                                             public void testCosh_LargeNegativeValues() {
                                                 // Values < -20
                                                 double expected1 = 0.5 * Math.exp(25);  // cosh(-25) same as cosh(25)
                                                 assertEquals(expected1, FastMath.cosh(-25), expected1 * 1e-15);
                                                 
                                                 // Very large negative value that triggers overflow protection
                                                 // Using a sufficiently large negative value (approximately 2*709.78 since Math.exp(709.78) is near Double.MAX_VALUE)
                                                 double veryLargeNegative = -710 * 2;
                                                 double expected2 = 0.5 * Math.exp(-veryLargeNegative * 0.5) * Math.exp(-veryLargeNegative * 0.5);
                                                 assertEquals(expected2, FastMath.cosh(veryLargeNegative), expected2 * 1e-15);
                                             }

 @Test
                                             public void testSinhBoundaryAt() {
                                                 // Test the boundary case x = 20
                                                 double x = 20.0;
                                                 
                                                 // Expected value calculated using precise method (not simplified)
                                                 // For x=20, original method would use precise calculation
                                                 // Mutated method would use simplified calculation (0.5 * exp(x))
                                                 double preciseResult = (Math.exp(x) - Math.exp(-x)) / 2;
                                                 double simplifiedResult = 0.5 * Math.exp(x);
                                                 
                                                 // The difference should be significant
                                                 assertNotEquals("Simplified and precise calculations should differ at x=20", 
                                                                simplifiedResult, preciseResult, 0.0001);
                                                 
                                                 // Now test the actual method - should match precise calculation
                                                 double actualResult = FastMath.sinh(x);
                                                 assertEquals("sinh(20) should use precise calculation", 
                                                             preciseResult, actualResult, 0.0001);
                                             }

 @Test
                                        public void testSinhForValuesBetween10And() {
                                            // Test a value between 10 and 20 where the mutation would cause different behavior
                                            double x = 15.0;
                                            
                                            // Expected value using standard Math.sinh() as reference
                                            double expected = Math.sinh(x);
                                            
                                            // Calculate using FastMath.sinh()
                                            double actual = FastMath.sinh(x);
                                            
                                            // The original implementation should be very close to Math.sinh()
                                            // The mutated version (x>10) would have larger error due to approximation
                                            assertEquals("Sinh calculation for x=15 should be precise", 
                                                        expected, actual, 1e-10);
                                            
                                            // Also test a value just above 20 to ensure original large-value logic still works
                                            x = 20.1;
                                            expected = Math.sinh(x);
                                            actual = FastMath.sinh(x);
                                            assertEquals("Sinh calculation for x=20.1 should use approximation",
                                                        expected, actual, 1e-10);
                                            
                                            // Test a value just below 10 to ensure precise calculation is used
                                            x = 9.9;
                                            expected = Math.sinh(x);
                                            actual = FastMath.sinh(x);
                                            assertEquals("Sinh calculation for x=9.9 should be precise",
                                                        expected, actual, 1e-10);
                                        }

 @Test
                                           public void testSinhForValuesBetween20And() {
                                               // Test a value between 20 and 30 (25 in this case)
                                               double x = 25.0;
                                               
                                               // Expected value calculated using standard math library
                                               double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                               
                                               // The original method should return approximately 0.5 * exp(x) for x > 20
                                               // The mutated version (x > 30) will use the complex calculation path
                                               double result = FastMath.sinh(x);
                                               
                                               // Verify the result matches expected hyperbolic sine
                                               assertEquals("sinh(25) should use simplified calculation", expected, result, 1e-10);
                                               
                                               // Also test the boundary case of 20
                                               double xBoundary = 20.0;
                                               double expectedBoundary = (Math.exp(xBoundary) - Math.exp(-xBoundary)) / 2;
                                               double resultBoundary = FastMath.sinh(xBoundary);
                                               assertEquals("sinh(20) should use simplified calculation", 
                                                           expectedBoundary, resultBoundary, 1e-10);
                                               
                                               // Test a value just above 30 to ensure both versions handle it similarly
                                               double xAboveThreshold = 31.0;
                                               double expectedAbove = (Math.exp(xAboveThreshold) - Math.exp(-xAboveThreshold)) / 2;
                                               double resultAbove = FastMath.sinh(xAboveThreshold);
                                               assertEquals("sinh(31) should use simplified calculation", 
                                                           expectedAbove, resultAbove, 1e-10);
                                           }

 @Test
                                      public void testSinhAtLogMaxValue() {
                                          // Get the LOG_MAX_VALUE constant using reflection since it's private
                                          double logMaxValue = 0;
                                          try {
                                              Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                              field.setAccessible(true);
                                              logMaxValue = field.getDouble(null);
                                          } catch (Exception e) {
                                              fail("Failed to access LOG_MAX_VALUE field");
                                          }
                                          
                                          // Test with x exactly equal to LOG_MAX_VALUE
                                          double x = logMaxValue;
                                          
                                          // Calculate expected value using overflow protection path
                                          double expected = 0.5 * FastMath.exp(0.5 * x);
                                          expected = expected * expected;
                                          
                                          // Actual result
                                          double actual = FastMath.sinh(x);
                                          
                                          // Verify the result matches the overflow-protected calculation
                                          assertEquals("sinh(LOG_MAX_VALUE) should use overflow protection path", 
                                                      expected, actual, 1e-10);
                                          
                                          // Additional verification that we're testing the boundary case
                                          assertTrue("x should be > 20", x > 20);
                                      }

 @Test
                                         public void testSinhLargePositiveValues() {
                                             // Get the LOG_MAX_VALUE constant value through reflection since it's private
                                             double logMaxValue = 0;
                                             try {
                                                 java.lang.reflect.Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                 field.setAccessible(true);
                                                 logMaxValue = field.getDouble(null);
                                             } catch (Exception e) {
                                                 fail("Failed to access LOG_MAX_VALUE field");
                                             }
                                     
                                             // Test value exactly at LOG_MAX_VALUE
                                             double x = logMaxValue;
                                             double expected = 0.5 * Math.exp(x); // Expected normal calculation
                                             assertEquals(expected, FastMath.sinh(x), Math.ulp(expected) * 2);
                                     
                                             // Test value slightly above LOG_MAX_VALUE
                                             x = logMaxValue * 1.001;
                                             double t = Math.exp(0.5 * x);
                                             expected = (0.5 * t) * t; // Expected overflow protection calculation
                                             assertEquals(expected, FastMath.sinh(x), Math.ulp(expected) * 2);
                                     
                                             // Test value slightly below LOG_MAX_VALUE
                                             x = logMaxValue * 0.999;
                                             expected = 0.5 * Math.exp(x); // Expected normal calculation
                                             assertEquals(expected, FastMath.sinh(x), Math.ulp(expected) * 2);
                                     
                                             // Test very large value (definitely above LOG_MAX_VALUE)
                                             x = logMaxValue * 2;
                                             t = Math.exp(0.5 * x);
                                             expected = (0.5 * t) * t; // Expected overflow protection calculation
                                             assertEquals(expected, FastMath.sinh(x), Math.ulp(expected) * 2);
                                         }

 @Test
                                   public void testSinhDetectMutant() {
                                       // Choose a value between 20 and LOG_MAX_VALUE
                                       // Assuming LOG_MAX_VALUE is around 709.78 (natural log of Double.MAX_VALUE)
                                       double testValue = 25.0;
                                       double logMaxValueApprox = 709.78; // Approximation of LOG_MAX_VALUE
                                       
                                       // Calculate expected value using normal path (0.5 * exp(x))
                                       double expected = 0.5 * Math.exp(testValue);
                                       
                                       // Calculate actual value from FastMath.sinh
                                       double actual = FastMath.sinh(testValue);
                                       
                                       // If mutant is present, it will use overflow protection path (0.5*t*t)
                                       // which will give a different result
                                       assertEquals("Test should detect mutant by comparing results", 
                                                   expected, actual, 1e-10);
                                       
                                       // Additional assertion to verify we're in the right range
                                       assertTrue("Test value should be > 20", testValue > 20);
                                       assertTrue("Test value should be < LOG_MAX_VALUE", 
                                                 testValue < logMaxValueApprox);
                                   }

 @Test
                                   public void testSinhLargePositiveValueNearOverflow() {
                                       // Choose a value just above LOG_MAX_VALUE
                                       // Assuming LOG_MAX_VALUE is around 709.78 (natural log of Double.MAX_VALUE)
                                       double x = 710.0;
                                       
                                       // Calculate expected value using original formula: 0.5 * exp(x)
                                       double expected = 0.5 * Math.exp(x);
                                       
                                       // The mutant would return: 0.5 * Math.exp(2*x) which is much larger
                                       // This should be detectable with any reasonable precision
                                       
                                       // Call the method
                                       double actual = FastMath.sinh(x);
                                       
                                       // Verify the result matches expected with some tolerance
                                       assertEquals("Sinh of large positive value near overflow", expected, actual, expected * 1e-10);
                                       
                                       // Additional check to ensure we're not getting the mutant's result
                                       double mutantResult = 0.5 * Math.exp(2*x);
                                       assertNotEquals("Should not match mutant result", mutantResult, actual, mutantResult * 1e-10);
                                   }

 @Test
                                  public void testSinhLargePositiveValueWithOverflowProtection() {
                                      // Choose a value larger than LOG_MAX_VALUE
                                      // Assuming LOG_MAX_VALUE is around 709.78 (natural log of Double.MAX_VALUE)
                                      double x = 710.0;
                                      
                                      // Calculate expected value using the original formula: 0.5 * t * t where t = exp(0.5 * x)
                                      double expectedT = Math.exp(0.5 * x);
                                      double expected = 0.5 * expectedT * expectedT;
                                      
                                      // Calculate actual value
                                      double actual = FastMath.sinh(x);
                                      
                                      // Verify the result
                                      assertEquals("Sinh of large positive value with overflow protection", 
                                                  expected, actual, 1e-10 * Math.abs(expected));
                                      
                                      // Additional verification: ensure the mutant would produce a different result
                                      double mutantT = Math.exp(0.25 * x);
                                      double mutantResult = 0.5 * mutantT * mutantT;
                                      assertNotEquals("Test should detect the mutant", 
                                                    mutantResult, actual, 1e-10 * Math.abs(mutantResult));
                                  }

 @Test
                            public void testSinhLargePositiveValueWithOverflowProtection1() {
                                // Setup
                                double logMaxValue = Math.log(Double.MAX_VALUE); // Calculate ln(MAX_VALUE) instead of using private constant
                                double testValue = logMaxValue; // Exactly at the threshold
                                
                                // Expected calculation
                                double expected = 0.5 * FastMath.exp(testValue);
                                expected = 0.5 * expected * expected; // Original implementation
                                
                                // Mutant would return FastMath.exp(0.5 * testValue) * FastMath.exp(0.5 * testValue)
                                // which equals FastMath.exp(testValue) - twice the expected value
                                
                                // Test
                                double result = FastMath.sinh(testValue);
                                
                                // Verify
                                assertEquals("Sinh of large positive value should handle overflow correctly", 
                                           expected, result, 0.0);
                                
                                // Additional test with value slightly above threshold
                                double testValue2 = logMaxValue + 1;
                                double expected2 = 0.5 * FastMath.exp(testValue2);
                                expected2 = 0.5 * expected2 * expected2;
                                double result2 = FastMath.sinh(testValue2);
                                assertEquals("Sinh of value above LOG_MAX_VALUE should handle overflow correctly",
                                           expected2, result2, 0.0);
                            }

 @Test
                       public void testSinhForLargePositiveValue() {
                           // Setup
                           double x = 710; // Value larger than LOG_MAX_VALUE (~709.78)
                           
                           // Calculate expected value using correct formula
                           double t = FastMath.exp(0.5 * x);
                           double expected = (0.5 * t) * t;
                           
                           // Call method under test
                           double actual = FastMath.sinh(x);
                           
                           // Assert
                           assertEquals("sinh of large positive value should be calculated correctly", 
                                      expected, actual, 0.0);
                       }

 @Test
                       public void testSinhLargePositiveValueOverflowProtection() {
                           // Get LOG_MAX_VALUE through reflection since it's private
                           double logMaxValue = 0;
                           try {
                               java.lang.reflect.Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                               field.setAccessible(true);
                               logMaxValue = field.getDouble(null);
                           } catch (Exception e) {
                               fail("Failed to access LOG_MAX_VALUE");
                           }
                           
                           // Test value just above LOG_MAX_VALUE
                           double x = logMaxValue + 1;
                           
                           // Calculate expected value using original formula
                           double t = Math.exp(0.5 * x);
                           double expected = (0.5 * t) * t;
                           
                           // Actual result from FastMath
                           double actual = FastMath.sinh(x);
                           
                           // Verify the result matches expected calculation
                           assertEquals("sinh of large positive value should use overflow protection formula", 
                                       expected, actual, 1e-10);
                           
                           // Additional verification: compare with alternative calculation
                           // For very large x, sinh(x) ≈ 0.5*exp(x)
                           double alternativeExpected = 0.5 * Math.exp(x);
                           assertEquals("sinh of large positive value should be approximately 0.5*exp(x)",
                                       alternativeExpected, actual, alternativeExpected * 1e-10);
                       }

 @Test
                      public void testSinhBoundaryAtNegative() {
                          // Test exact boundary case that would be affected by the mutation
                          double x = -20.0;
                          
                          // Expected behavior (original): should use general case computation
                          // Mutated behavior: would use large negative value optimization
                          double expected = (Math.exp(x) - Math.exp(-x)) / 2; // Expected general case computation
                          
                          // Test with exact boundary value
                          double result = FastMath.sinh(x);
                          assertEquals("sinh(-20) should use general case computation", 
                                      expected, result, 1e-10);
                          
                          // Test values just above and below the boundary
                          double justAbove = FastMath.sinh(-20 + 1e-10);
                          double justBelow = FastMath.sinh(-20 - 1e-10);
                          
                          // Verify continuity - the result at -20 should be between adjacent values
                          assertTrue("Result at boundary should be between adjacent values",
                                    justBelow < result && result < justAbove);
                          
                          // Verify the computation method by checking against known optimized path
                          double optimizedPathResult = -0.5 * Math.exp(-x);
                          assertNotEquals("sinh(-20) should not equal optimized path result",
                                         optimizedPathResult, result, 1e-10);
                      }

 @Test
                     public void testSinhNegativeBetween20And() {
                         // Test value between -20 and -10 where mutation would change behavior
                         double x = -15.0;
                         
                         // Expected value calculated using precise formula
                         double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                         
                         // Actual value from FastMath
                         double actual = FastMath.sinh(x);
                         
                         // Verify the result matches precise calculation
                         assertEquals("sinh(-15) should use precise calculation", 
                                     expected, actual, 1e-10);
                         
                         // Additional test near the boundary
                         x = -19.9;
                         expected = (Math.exp(x) - Math.exp(-x)) / 2;
                         actual = FastMath.sinh(x);
                         assertEquals("sinh(-19.9) should use precise calculation",
                                     expected, actual, 1e-10);
                         
                         // Test just below the original boundary
                         x = -20.1;
                         expected = -0.5 * Math.exp(-x);  // Simplified formula expected
                         actual = FastMath.sinh(x);
                         assertEquals("sinh(-20.1) should use simplified calculation",
                                     expected, actual, 1e-10);
                     }

 @Test
                    public void testSinhNegativeLogMaxValue() {
                        // Get the LOG_MAX_VALUE constant value through reflection since it's private
                        double logMaxValue = 0;
                        try {
                            java.lang.reflect.Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                            field.setAccessible(true);
                            logMaxValue = field.getDouble(null);
                        } catch (Exception e) {
                            fail("Failed to access LOG_MAX_VALUE field");
                        }
                        
                        // Test with x exactly equal to -LOG_MAX_VALUE
                        double x = -logMaxValue;
                        
                        // Calculate expected value using the overflow prevention path
                        double expected = -0.5 * Math.exp(-x); // This is what the mutant would do
                        double t = Math.exp(-0.5 * x);
                        expected = (-0.5 * t) * t; // This is what the original code does
                        
                        // The test should pass for original code but fail for mutant
                        double actual = FastMath.sinh(x);
                        
                        // Verify the result matches the overflow prevention calculation
                        assertEquals("sinh(-LOG_MAX_VALUE) should use overflow prevention path", 
                                    expected, actual, 1e-15);
                    }

 @Test
                   public void testSinhForLargeNegativeValues() {
                       // Get the actual LOG_MAX_VALUE using reflection since it's private
                       double LOG_MAX_VALUE;
                       try {
                           java.lang.reflect.Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                           field.setAccessible(true);
                           LOG_MAX_VALUE = field.getDouble(null);
                       } catch (Exception e) {
                           fail("Failed to access LOG_MAX_VALUE");
                           return;
                       }
               
                       // Test value just below -LOG_MAX_VALUE
                       double extremeNegative = -LOG_MAX_VALUE - 1.0;
                       double expectedExtreme = -0.5 * Math.exp(-extremeNegative); // Should use the non-overflow path
                       double actualExtreme = FastMath.sinh(extremeNegative);
                       assertEquals("Sinh of extreme negative value", expectedExtreme, actualExtreme, 1e-10);
               
                       // Test value just above -LOG_MAX_VALUE but still < -20
                       double largeNegative = -LOG_MAX_VALUE + 1.0;
                       if (largeNegative < -20) { // Ensure we're in the right range
                           // Should use the overflow prevention path with t*t calculation
                           double expectedLarge = -0.5 * Math.exp(-0.5 * largeNegative);
                           expectedLarge = expectedLarge * expectedLarge;
                           double actualLarge = FastMath.sinh(largeNegative);
                           assertEquals("Sinh of large negative value", expectedLarge, actualLarge, 1e-10);
                       }
                   }

 @Test
                  public void testSinhNegativeBetweenThresholdAnd() {
                      // Choose a value between -LOG_MAX_VALUE and -20
                      // Since we don't know LOG_MAX_VALUE's exact value, we'll use -21 which should be in this range
                      // (LOG_MAX_VALUE is typically around 709.78 for double)
                      double x = -21.0;
                      
                      // Expected behavior (original code):
                      // Since -21 > -LOG_MAX_VALUE, it should use -0.5*exp(-x)
                      double expected = -0.5 * FastMath.exp(-x);
                      
                      // Actual result from the method
                      double actual = FastMath.sinh(x);
                      
                      // The mutant would instead calculate (-0.5*t)*t where t = exp(-0.5*x)
                      // which would be different from expected
                      assertEquals("Sinh of negative value between -LOG_MAX_VALUE and -20 should use simple exp formula", 
                                  expected, actual, 1e-15);
                  }

 @Test
                  public void testSinhVeryLargeNegative() {
                      // Test with a value <= -LOG_MAX_VALUE to ensure both original and mutant handle it correctly
                      // We'll use a very large negative value that would definitely trigger the overflow protection
                      double x = -1000.0;
                      
                      // Both original and mutant should use the same calculation in this case
                      double t = FastMath.exp(-0.5 * x);
                      double expected = (-0.5 * t) * t;
                      
                      double actual = FastMath.sinh(x);
                      
                      assertEquals("Sinh of very large negative value should use overflow-safe calculation",
                                  expected, actual, 1e-15);
                  }

 @Test
             public void testSinhForLargeNegativeValues1() {
                 // Test with a very large negative value that would cause overflow with exp(-x)
                 // but works fine with exp(-0.5*x)
                 double x = -710.0; // exp(-710) would overflow, exp(-355) wouldn't
                 
                 // Calculate expected value using the correct formula
                 double expected = -0.5 * Math.exp(-x);
                 
                 // Call the method (this will use the mutated version if present)
                 double result = FastMath.sinh(x);
                 
                 // Verify the result matches expected behavior
                 assertEquals("Sinh of large negative value should be calculated correctly", 
                             expected, result, 1e-10);
                 
                 // Additional verification that we're testing the right code path
                 assertTrue("Test should verify the x < -20 code path", x < -20);
             }

 @Test
           public void testSinhForVeryLargeNegativeValue() {
               // Setup
               double veryLargeNegativeValue = -1000.0; // Value that satisfies x <= -LOG_MAX_VALUE
               
               // Calculate expected value using original formula
               double expectedT = Math.exp(-0.5 * veryLargeNegativeValue);
               double expectedResult = (-0.5 * expectedT) * expectedT;
               
               // Test
               double actualResult = FastMath.sinh(veryLargeNegativeValue);
               
               // Verify
               assertEquals("Sinh of very large negative value should match expected calculation", 
                           expectedResult, actualResult, 1e-10);
               
               // Additional verification that we're testing the right path
               // Since we can't access LOG_MAX_VALUE directly, we just verify that our test value
               // is indeed very large negative (which we know it is)
               assertTrue("Test should verify the x <= -LOG_MAX_VALUE path",
                         veryLargeNegativeValue < -700); // 700 is safely less than LOG_MAX_VALUE (~709.78)
           }

 @Test
           public void testSinhForLargeNegativeValues2() {
               // Choose a value significantly less than -LOG_MAX_VALUE
               // Assuming LOG_MAX_VALUE is around 709.78 (ln(Double.MAX_VALUE))
               double x = -710.0;
               
               // Calculate expected value using mathematical definition
               double expected = (Math.exp(x) - Math.exp(-x)) / 2;
               
               // Call the method
               double actual = FastMath.sinh(x);
               
               // Verify the result matches expected value with a small tolerance
               assertEquals("sinh of large negative value incorrect", expected, actual, 1.0e-15);
               
               // Additional assertion to specifically catch the mutant
               // The mutant would return -exp(-x) instead of -0.5*exp(-x)
               double mutantValue = -Math.exp(-x);
               assertNotEquals("Mutant not detected - result matches mutant behavior", 
                              mutantValue, actual, 1.0e-15);
           }

 @Test
      public void testSinhForLargeNegativeValues3() {
          // Setup
          double largeNegativeValue = -710.0; // Well below -LOG_MAX_VALUE (which is typically ~709.78)
          
          // Expected behavior: sinh(-x) = -sinh(x), and for large x, sinh(x) ≈ 0.5*exp(x)
          double expected = -0.5 * Math.exp(-largeNegativeValue);
          
          // Action
          double actual = FastMath.sinh(largeNegativeValue);
          
          // Verification
          // Check the result is negative and has correct magnitude
          assertTrue("Result should be negative", actual < 0);
          assertEquals("Result magnitude should match expected", 
                       Math.abs(expected), Math.abs(actual), 1e-10);
          
          // More precise verification using the mathematical definition
          double preciseExpected = (Math.exp(largeNegativeValue) - Math.exp(-largeNegativeValue)) / 2;
          assertEquals("Result should match precise calculation", 
                       preciseExpected, actual, 1e-10);
      }

 @Test
     public void testSinhForVeryLargeNegativeValues() {
         // Get LOG_MAX_VALUE through reflection since it's private
         double LOG_MAX_VALUE;
         try {
             Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
             field.setAccessible(true);
             LOG_MAX_VALUE = field.getDouble(null);
         } catch (Exception e) {
             fail("Failed to access LOG_MAX_VALUE");
             return;
         }
         
         // Choose a test value just below -LOG_MAX_VALUE
         double x = -LOG_MAX_VALUE - 1.0;
         
         // Calculate expected value manually
         double t = Math.exp(-0.5 * x);
         double expected = (-0.5 * t) * t;
         
         // Call the method and verify
         double actual = FastMath.sinh(x);
         assertEquals("Sinh of very large negative value incorrect", expected, actual, 1e-10);
         
         // Additional verification: compare with regular calculation for smaller value
         // to ensure the special case logic is correct
         double smallerX = -LOG_MAX_VALUE + 1.0;
         double expectedSmaller = -0.5 * Math.exp(-smallerX);
         double actualSmaller = FastMath.sinh(smallerX);
         assertEquals("Sinh of large negative value incorrect", expectedSmaller, actualSmaller, 1e-10);
     }

 @Test
        public void testSinhZero() {
            // Test the special case of x=0
            double input = 0.0;
            double expected = 0.0;
            
            // Verify exact equality for zero input
            assertEquals("sinh(0) should return exactly 0", expected, FastMath.sinh(input), 0.0);
            
            // Also test some non-zero values to ensure general functionality
            assertEquals("sinh(1) should be correct", 
                         (Math.exp(1) - Math.exp(-1))/2, 
                         FastMath.sinh(1.0), 
                         1e-15);
            assertEquals("sinh(-1) should be correct", 
                         (Math.exp(-1) - Math.exp(1))/2, 
                         FastMath.sinh(-1.0), 
                         1e-15);
        }

 @Test
       public void testSinhWithNaNInput() {
           // Arrange
           double input = Double.NaN;
           
           // Act
           double result = FastMath.sinh(input);
           
           // Assert
           assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
       }

 @Test
      public void testSinhWithNaNInput1() {
          // Arrange
          double input = Double.NaN;
          
          // Act
          double result = FastMath.sinh(input);
          
          // Assert
          // Using Double.compare because NaN != NaN in normal comparison
          assertEquals(0, Double.compare(input, result));
          
          // Additional check to ensure it's not negated
          assertFalse(Double.doubleToRawLongBits(input) != Double.doubleToRawLongBits(result));
      }

 @Test
 public void testSinhAtZeroDetectsMutant() {
     // Test case specifically designed to catch the x <= 0.0 mutant
     
     // Test regular zero
     double zeroResult = FastMath.sinh(0.0);
     assertEquals(0.0, zeroResult, 0.0);
     // Verify it's positive zero (not negative zero)
     assertTrue(Double.doubleToLongBits(zeroResult) == Double.doubleToLongBits(0.0));
     
     // Test negative zero for completeness
     double negativeZeroResult = FastMath.sinh(-0.0);
     assertEquals(-0.0, negativeZeroResult, 0.0);
     // Verify it's negative zero
     assertTrue(Double.doubleToLongBits(negativeZeroResult) == Double.doubleToLongBits(-0.0));
     
     // Test a small positive value to ensure normal behavior
     double smallPositive = FastMath.sinh(0.1);
     assertTrue(smallPositive > 0);
     
     // Test a small negative value to ensure normal behavior
     double smallNegative = FastMath.sinh(-0.1);
     assertTrue(smallNegative < 0);
 }

}
