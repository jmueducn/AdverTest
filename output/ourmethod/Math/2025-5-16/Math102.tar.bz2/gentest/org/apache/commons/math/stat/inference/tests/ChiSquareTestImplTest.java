package gentest.org.apache.commons.math.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.inference.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.ChiSquaredDistribution;
import org.apache.commons.math.distribution.ChiSquaredDistributionImpl;
import org.apache.commons.math.distribution.DistributionFactory;
 
public class ChiSquareTestImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                            public void testChiSquare_WithMockedDistribution() {
                                                                                                                                ChiSquaredDistribution mockDist = mock(ChiSquaredDistribution.class);
                                                                                                                                ChiSquareTestImpl customTest = new ChiSquareTestImpl(mockDist);
                                                                                                                                
                                                                                                                                long[][] counts = {
                                                                                                                                    {10, 20},
                                                                                                                                    {30, 40}
                                                                                                                                };
                                                                                                                                
                                                                                                                                double result = customTest.chiSquare(counts);
                                                                                                                                
                                                                                                                                // Verify the calculation is still correct regardless of distribution
                                                                                                                                assertEquals(0.7936507937, result, 1e-10);
                                                                                                                            }

 @Test
                                                                                                                    public void testChiSquare_InvalidArrayLengths() {
                                                                                                                        // Initialize test objects
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        ExpectedException thrown = ExpectedException.none();
                                                                                                                        
                                                                                                                        // Test data
                                                                                                                        double[] expected = new double[]{1.0};
                                                                                                                        long[] observed = new long[]{1L};
                                                                                                                        
                                                                                                                        // Expect exception
                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                        thrown.expectMessage("observed, expected array lengths incorrect");
                                                                                                                        
                                                                                                                        // Test the method
                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_UnequalArrayLengths() {
                                                                                                                        org.apache.commons.math.stat.inference.ChiSquareTest chiSquareTest = 
                                                                                                                            new org.apache.commons.math.stat.inference.ChiSquareTestImpl();
                                                                                                                        org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                        
                                                                                                                        double[] expected = new double[]{1.0, 2.0};
                                                                                                                        long[] observed = new long[]{1L};
                                                                                                                        
                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                        thrown.expectMessage("observed, expected array lengths incorrect");
                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_NegativeObservedValues() {
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double[] expected = new double[]{1.0, 2.0};
                                                                                                                        long[] observed = new long[]{-1L, 2L};
                                                                                                                        
                                                                                                                        ExpectedException thrown = ExpectedException.none();
                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                        thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_NonPositiveExpectedValues() {
                                                                                                                        // Create instance of the test class
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        
                                                                                                                        // Setup expected exception
                                                                                                                        ExpectedException thrown = ExpectedException.none();
                                                                                                                        
                                                                                                                        double[] expected = new double[]{0.0, 2.0};
                                                                                                                        long[] observed = new long[]{1L, 2L};
                                                                                                                        
                                                                                                                        // Expect IllegalArgumentException with specific message
                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                        thrown.expectMessage("observed counts must be non-negative and expected counts must be postive");
                                                                                                                        
                                                                                                                        // Perform the test
                                                                                                                        chiSquareTest.chiSquare(expected, observed);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_BasicCalculation() {
                                                                                                                        double[] expected = new double[]{10.0, 10.0, 10.0};
                                                                                                                        long[] observed = new long[]{8L, 12L, 10L};
                                                                                                                        
                                                                                                                        // Create new instance of the test class
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        
                                                                                                                        // Manual calculation of expected chi-square value
                                                                                                                        // (8-10)²/10 + (12-10)²/10 + (10-10)²/10 = 0.4 + 0.4 + 0 = 0.8
                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                        assertEquals(0.8, result, 1E-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_WithRescaling() {
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double[] expected = new double[]{5.0, 10.0, 15.0};
                                                                                                                        long[] observed = new long[]{10L, 20L, 30L};
                                                                                                                        
                                                                                                                        // Sum expected = 30, sum observed = 60
                                                                                                                        // ratio = 60/30 = 2
                                                                                                                        // For first element: (10 - 2*5)²/(2*5) = 0
                                                                                                                        // Second element: (20 - 2*10)²/(2*10) = 0
                                                                                                                        // Third element: (30 - 2*15)²/(2*15) = 0
                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                        assertEquals(0.0, result, 1E-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_ZeroObservedValues() {
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double[] expected = new double[]{1.0, 1.0, 1.0};
                                                                                                                        long[] observed = new long[]{0L, 0L, 0L};
                                                                                                                        
                                                                                                                        // (0-1)²/1 for each element = 1 + 1 + 1 = 3
                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                        assertEquals(3.0, result, 1E-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_LargeNumbers() {
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double[] expected = new double[]{1000000.0, 1000000.0};
                                                                                                                        long[] observed = new long[]{1000001L, 999999L};
                                                                                                                        
                                                                                                                        // (1000001-1000000)²/1000000 + (999999-1000000)²/1000000
                                                                                                                        // = 1/1000000 + 1/1000000 = 2E-6
                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                        assertEquals(2E-6, result, 1E-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_PerfectMatch() {
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double[] expected = new double[]{5.0, 5.0, 5.0, 5.0};
                                                                                                                        long[] observed = new long[]{5L, 5L, 5L, 5L};
                                                                                                                        
                                                                                                                        double result = chiSquareTest.chiSquare(expected, observed);
                                                                                                                        assertEquals(0.0, result, 1E-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_SingleElementArrays() {
                                                                                                                        double[] expected = new double[]{10.0};
                                                                                                                        long[] observed = new long[]{10L};
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        
                                                                                                                        try {
                                                                                                                            chiSquareTest.chiSquare(expected, observed);
                                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                            // Expected exception
                                                                                                                            assertTrue(e.getMessage().contains("observed, expected array lengths incorrect"));
                                                                                                                        }
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_2x2ContingencyTable() {
                                                                                                                        long[][] counts = {
                                                                                                                            {10, 20},
                                                                                                                            {30, 40}
                                                                                                                        };
                                                                                                                        
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                        
                                                                                                                        // Expected calculation:
                                                                                                                        // Row sums: 30, 70
                                                                                                                        // Column sums: 40, 60
                                                                                                                        // Total: 100
                                                                                                                        // Expected values:
                                                                                                                        // (30*40)/100 = 12, (30*60)/100 = 18
                                                                                                                        // (70*40)/100 = 28, (70*60)/100 = 42
                                                                                                                        // Chi-square components:
                                                                                                                        // (10-12)²/12 + (20-18)²/18 + (30-28)²/28 + (40-42)²/42 ≈ 0.7936507937
                                                                                                                        assertEquals(0.7936507937, result, 1e-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_3x3ContingencyTable() {
                                                                                                                        long[][] counts = {
                                                                                                                            {10, 20, 30},
                                                                                                                            {20, 30, 40},
                                                                                                                            {30, 40, 50}
                                                                                                                        };
                                                                                                                        
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                        
                                                                                                                        // Expected calculation:
                                                                                                                        // Row sums: 60, 90, 120
                                                                                                                        // Column sums: 60, 90, 120
                                                                                                                        // Total: 270
                                                                                                                        // Expected values are all (rowSum*colSum)/total
                                                                                                                        // Chi-square calculation would be sum of (observed-expected)²/expected for all cells
                                                                                                                        // Detailed calculation omitted for brevity, but we know the pattern
                                                                                                                        assertTrue(result > 0);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_AllValuesEqual() {
                                                                                                                        long[][] counts = {
                                                                                                                            {5, 5},
                                                                                                                            {5, 5}
                                                                                                                        };
                                                                                                                        
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                        
                                                                                                                        // When all values are equal, chi-square should be 0
                                                                                                                        assertEquals(0.0, result, 1e-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_SingleCell() {
                                                                                                                        long[][] counts = {
                                                                                                                            {42}
                                                                                                                        };
                                                                                                                        
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                        
                                                                                                                        // With single cell, chi-square should be 0 (no variation)
                                                                                                                        assertEquals(0.0, result, 1e-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_NonRectangularArray() {
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        ExpectedException thrown = ExpectedException.none();
                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                        long[][] counts = {
                                                                                                                            {1, 2},
                                                                                                                            {3}  // Different number of columns
                                                                                                                        };
                                                                                                                        chiSquareTest.chiSquare(counts);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_WithZeroValues() {
                                                                                                                        long[][] counts = {
                                                                                                                            {0, 10},
                                                                                                                            {10, 0}
                                                                                                                        };
                                                                                                                        
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                        
                                                                                                                        // Expected calculation:
                                                                                                                        // Row sums: 10, 10
                                                                                                                        // Column sums: 10, 10
                                                                                                                        // Total: 20
                                                                                                                        // Expected values:
                                                                                                                        // (10*10)/20 = 5 for all cells
                                                                                                                        // Chi-square components:
                                                                                                                        // (0-5)²/5 + (10-5)²/5 + (10-5)²/5 + (0-5)²/5 = 20
                                                                                                                        assertEquals(20.0, result, 1e-10);
                                                                                                                    }

 @Test
                                                                                                                    public void testChiSquare_LargeNumbers1() {
                                                                                                                        long[][] counts = {
                                                                                                                            {1000000, 2000000},
                                                                                                                            {3000000, 4000000}
                                                                                                                        };
                                                                                                                        
                                                                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                                                        double result = chiSquareTest.chiSquare(counts);
                                                                                                                        
                                                                                                                        // Should be same as small numbers test but scaled up
                                                                                                                        assertEquals(0.7936507937, result, 1e-10);
                                                                                                                    }

 @Test
                                                                            public void testChiSquareWithDifferentSumsDetectsRatioMutation() {
                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                
                                                                                // Create test data where sums differ (will trigger rescaling)
                                                                                double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
                                                                                long[] observed = {15L, 25L, 35L};       // Sum = 75 (different from expected)
                                                                                
                                                                                // With original ratio=1.0, this should calculate normally
                                                                                double result = chiSquareTest.chiSquare(expected, observed);
                                                                                
                                                                                // Verify the calculation was done (not checking exact value since we're testing for mutation)
                                                                                // If the mutant (ratio=0) was present, this would have thrown ArithmeticException
                                                                                assertTrue("Result should be a valid chi-square value", result >= 0);
                                                                                
                                                                                // Additional verification that the calculation is correct
                                                                                // Expected chi-square value calculation:
                                                                                double ratio = 75.0 / 60.0;  // sumObserved / sumExpected
                                                                                double expectedChiSquare = 0.0;
                                                                                for (int i = 0; i < observed.length; i++) {
                                                                                    double dev = observed[i] - ratio * expected[i];
                                                                                    expectedChiSquare += dev * dev / (ratio * expected[i]);
                                                                                }
                                                                                assertEquals(expectedChiSquare, result, 1E-10);
                                                                            }

 @Test
                                                                            public void testChiSquareDetectsRatioMutation() {
                                                                                // Setup - create a simple 2x2 contingency table
                                                                                long[][] counts = {
                                                                                    {10, 20},
                                                                                    {30, 40}
                                                                                };
                                                                                
                                                                                // Expected calculations:
                                                                                // Row sums: 30, 70
                                                                                // Column sums: 40, 60
                                                                                // Total: 100
                                                                                // Expected values:
                                                                                // [0][0]: (30*40)/100 = 12
                                                                                // [0][1]: (30*60)/100 = 18
                                                                                // [1][0]: (70*40)/100 = 28
                                                                                // [1][1]: (70*60)/100 = 42
                                                                                // Chi-square components:
                                                                                // (10-12)²/12 = 0.333
                                                                                // (20-18)²/18 = 0.222
                                                                                // (30-28)²/28 = 0.143
                                                                                // (40-42)²/42 = 0.095
                                                                                // Total expected chi-square: ~0.7937
                                                                                
                                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                                double result = chiSquareTest.chiSquare(counts);
                                                                                
                                                                                // Verify result isn't 0 (which would happen with ratio=0)
                                                                                assertNotEquals(0.0, result, 0.0001);
                                                                                
                                                                                // Verify exact expected value
                                                                                assertEquals(0.7937, result, 0.0001);
                                                                                
                                                                                // Additional verification that the value makes sense
                                                                                assertTrue(result > 0);
                                                                                assertTrue(result < 10); // Sanity check upper bound
                                                                            }

 @Test
                                                                           public void testChiSquareRescaleBehaviorWhenSumsEqual() {
                                                                               ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                               
                                                                               // Create test data where sums are equal (no rescaling should occur)
                                                                               double[] expected = {10.0, 10.0, 10.0};  // Sum = 30.0
                                                                               long[] observed = {10L, 10L, 10L};       // Sum = 30.0
                                                                               
                                                                               // Calculate expected result without rescaling
                                                                               double expectedSumSq = 0.0;
                                                                               for (int i = 0; i < observed.length; i++) {
                                                                                   double dev = observed[i] - expected[i];
                                                                                   expectedSumSq += dev * dev / expected[i];
                                                                               }
                                                                               
                                                                               // Call method and get actual result
                                                                               double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                                               
                                                                               // Verify result matches non-rescaled calculation
                                                                               assertEquals(expectedSumSq, actualSumSq, 1E-10);
                                                                               
                                                                               // Also verify with different values but equal sums
                                                                               double[] expected2 = {5.0, 15.0, 10.0};  // Sum = 30.0
                                                                               long[] observed2 = {8L, 12L, 10L};       // Sum = 30.0
                                                                               
                                                                               expectedSumSq = 0.0;
                                                                               for (int i = 0; i < observed2.length; i++) {
                                                                                   double dev = observed2[i] - expected2[i];
                                                                                   expectedSumSq += dev * dev / expected2[i];
                                                                               }
                                                                               
                                                                               actualSumSq = chiSquareTest.chiSquare(expected2, observed2);
                                                                               assertEquals(expectedSumSq, actualSumSq, 1E-10);
                                                                           }

 @Test
                                                                           public void testChiSquareRescaleEffect() {
                                                                               ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                               
                                                                               // Create a simple 2x2 contingency table
                                                                               long[][] counts = {
                                                                                   {10, 20},
                                                                                   {30, 40}
                                                                               };
                                                                               
                                                                               // Calculate expected chi-square value manually
                                                                               // Row sums: 30, 70
                                                                               // Column sums: 40, 60
                                                                               // Total: 100
                                                                               // Expected values:
                                                                               // [12, 18]
                                                                               // [28, 42]
                                                                               // Chi-square components:
                                                                               // (10-12)²/12 + (20-18)²/18 + (30-28)²/28 + (40-42)²/42
                                                                               // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.7937
                                                                               
                                                                               double expectedChiSquare = 0.7937;
                                                                               double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                                               
                                                                               // If rescale=true affects the calculation, this assertion would fail
                                                                               assertEquals(expectedChiSquare, actualChiSquare, 0.0001);
                                                                               
                                                                               // Test with another table to be thorough
                                                                               long[][] counts2 = {
                                                                                   {5, 15},
                                                                                   {10, 20}
                                                                               };
                                                                               // Expected chi-square for counts2
                                                                               double expectedChiSquare2 = 0.7576;
                                                                               double actualChiSquare2 = chiSquareTest.chiSquare(counts2);
                                                                               assertEquals(expectedChiSquare2, actualChiSquare2, 0.0001);
                                                                           }

 @Test
                                                                          public void testChiSquareWithExactThresholdDifference() {
                                                                              ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                              
                                                                              // Create a 2x2 contingency table that will produce exact 1e-6 difference
                                                                              // between sumExpected and sumObserved for at least one cell
                                                                              long[][] counts = new long[][] {
                                                                                  {1000000L, 1000000L},
                                                                                  {1000000L, 1000001L}  // This slight difference helps create the boundary case
                                                                              };
                                                                              
                                                                              // Calculate expected chi-square value
                                                                              double result = chiSquareTest.chiSquare(counts);
                                                                              
                                                                              // Verify the result is as expected
                                                                              // The exact expected value would need to be calculated, but we know it should be small
                                                                              assertTrue("Chi-square value should be greater than 0", result > 0);
                                                                              
                                                                              // More precise assertion would require calculating the exact expected value,
                                                                              // but this test is designed to catch the boundary condition mutation
                                                                              assertTrue("Chi-square value should be small", result < 0.1);
                                                                              
                                                                              // The key point is that with the original code, the exact boundary case would be handled
                                                                              // differently than with the mutated code
                                                                          }

 @Test
                                                                         public void testChiSquareRescalingBoundaryCondition() {
                                                                             ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                             
                                                                             // Create inputs where sum difference equals exactly 10E-6
                                                                             // Using whole numbers for observed counts (must be long)
                                                                             long[] observed = {1000000L, 1000000L};      // sum = 2000000
                                                                             // Adjust expected to create exact 10E-6 difference in sums
                                                                             double[] expected = {1000000.0 - 5E-6, 1000000.0 + 5E-6};  // sum = 2000000.0
                                                                             
                                                                             // Difference between sums is exactly 10E-6
                                                                             // Original: should NOT rescale (>)
                                                                             // Mutant: SHOULD rescale (>=)
                                                                             
                                                                             double result = chiSquareTest.chiSquare(expected, observed);
                                                                             
                                                                             // With original code (no rescaling):
                                                                             // dev1 = (1000000.0 - 5E-6 - 1000000) = -5E-6
                                                                             // dev2 = (1000000.0 + 5E-6 - 1000000) = +5E-6
                                                                             // sumSq = (-5E-6)^2/(1000000.0 - 5E-6) + (5E-6)^2/(1000000.0 + 5E-6) ≈ 5E-11
                                                                             
                                                                             // With mutant (rescaling):
                                                                             // ratio = 2000000.0/2000000.0 = 1.0
                                                                             // dev1 = (1000000 - 1.0*(1000000.0 - 5E-6)) ≈ 5E-6
                                                                             // dev2 = (1000000 - 1.0*(1000000.0 + 5E-6)) ≈ -5E-6
                                                                             // sumSq ≈ (5E-6)^2/(1000000.0 - 5E-6) + (-5E-6)^2/(1000000.0 + 5E-6) ≈ 5E-11
                                                                             
                                                                             // Assert original behavior (no rescaling, result should be approximately 5E-11)
                                                                             assertEquals(5E-11, result, 1E-12);
                                                                             
                                                                             // This will fail for the mutant since it will rescale and produce a different value
                                                                         }

 @Test
                                                                     public void testChiSquareWithNearlyEqualSums() {
                                                                         // Create a contingency table where row/column sums are nearly equal
                                                                         // but not exactly equal (difference < 10E-6, sum > 10E-6)
                                                                         long[][] counts = {
                                                                             {1000000L, 1000001L},
                                                                             {1000001L, 1000000L}
                                                                         };
                                                                         
                                                                         ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                         double result = chiSquareTest.chiSquare(counts);
                                                                         
                                                                         // The original implementation would compute a small chi-square value
                                                                         // because the differences are small relative to the counts
                                                                         // The mutant would fail because sumExpected + sumObserved is large
                                                                         assertTrue("Chi-square value should be small for nearly equal distributions", 
                                                                                    result < 0.1);
                                                                         
                                                                         // Additional verification - check that the sums are indeed close
                                                                         double rowSum1 = counts[0][0] + counts[0][1];
                                                                         double rowSum2 = counts[1][0] + counts[1][1];
                                                                         double colSum1 = counts[0][0] + counts[1][0];
                                                                         double colSum2 = counts[0][1] + counts[1][1];
                                                                         
                                                                         assertTrue(Math.abs(rowSum1 - rowSum2) < 10E-6);
                                                                         assertTrue(Math.abs(colSum1 - colSum2) < 10E-6);
                                                                         assertTrue((rowSum1 + rowSum2) > 10E-6);
                                                                         assertTrue((colSum1 + colSum2) > 10E-6);
                                                                     }

 @Test
                                                                    public void testChiSquareRescalingBehavior() {
                                                                        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                        
                                                                        // Case where sums are different (10 vs 20) but their sum is 30 (large)
                                                                        // Original: should rescale (since difference is 10 > 1e-6)
                                                                        // Mutant: should rescale (since sum is 30 > 1e-6)
                                                                        // This case won't detect the mutant
                                                                        
                                                                        // Case where sums are different (1.1 vs 1.0) but their sum is small (2.1)
                                                                        // Original: should rescale (difference 0.1 > 1e-6)
                                                                        // Mutant: should NOT rescale (sum 2.1 < 10E-6? No - need better values)
                                                                        
                                                                        // Better case: sums are different but their sum is below 1e-6
                                                                        double[] expected = {5E-7, 4E-7};  // sum = 9E-7
                                                                        long[] observed = {4L, 4L};        // sum = 8 (adjusted to maintain test intent)
                                                                        
                                                                        // Final case: sums differ by just over 1e-6 but sum is under 1e-6
                                                                        expected = new double[]{1.0005E-6, 0.9995E-6};  // sum = 2E-6
                                                                        observed = new long[]{1, 0};                    // sum = 1
                                                                        
                                                                        // Best case: sums differ significantly but their sum is exactly 0
                                                                        expected = new double[]{1.0, -1.0};  // sum = 0
                                                                        observed = new long[]{1, 0};         // sum = 1
                                                                        
                                                                        // Correct approach: need values where (a-b) > 1e-6 but (a+b) < 1e-6
                                                                        expected = new double[]{0.5001, 0.4999};  // sum=1.0000, difference=0.0002
                                                                        observed = new long[]{5001, 4999};        // sum=10000
                                                                        double ratio = 10000.0 / 1.0;             // Expected ratio if rescaling
                                                                        
                                                                        // Calculate expected value with and without rescaling
                                                                        double noRescaleSumSq = 
                                                                            Math.pow(5001 - 0.5001, 2)/0.5001 + 
                                                                            Math.pow(4999 - 0.4999, 2)/0.4999;
                                                                        
                                                                        double rescaleSumSq = 
                                                                            Math.pow(5001 - ratio*0.5001, 2)/(ratio*0.5001) + 
                                                                            Math.pow(4999 - ratio*0.4999, 2)/(ratio*0.4999);
                                                                        
                                                                        // Final solution: use values where original rescales but mutant wouldn't
                                                                        expected = new double[]{0.500001, 0.499999};  // sum=1.000000, difference=0.000002 (2e-6 > 1e-6)
                                                                        observed = new long[]{500001, 499999};         // sum=1000000
                                                                        
                                                                        double originalResult = chiSquareTest.chiSquare(expected, observed);
                                                                        
                                                                        // Now create a case where sums are equal (so original wouldn't rescale)
                                                                        // but their sum is large (so mutant would rescale)
                                                                        expected = new double[]{1000.0, 1000.0};  // sum=2000.0
                                                                        observed = new long[]{1000, 1000};        // sum=2000
                                                                        
                                                                        double mutantDetectionResult = chiSquareTest.chiSquare(expected, observed);
                                                                        
                                                                        // The key assertion - with equal sums, original should return non-zero
                                                                        // (since we're not rescaling but counts don't exactly match)
                                                                        // While mutant would return different value due to incorrect rescaling
                                                                        assertTrue(mutantDetectionResult > 0);
                                                                        
                                                                        // More precise way: calculate expected value without rescaling
                                                                        double expectedValue = 
                                                                            Math.pow(1000 - 1000.0, 2)/1000.0 + 
                                                                            Math.pow(1000 - 1000.0, 2)/1000.0;
                                                                        assertEquals(expectedValue, mutantDetectionResult, 1e-10);
                                                                    }

 @Test
                                                                public void testChiSquareDevInitialization() {
                                                                    // Setup
                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                    double[] expected = {2.0, 3.0};
                                                                    long[] observed = {1L, 4L};
                                                                    
                                                                    // Expected calculation without mutation:
                                                                    // For first element (i=0):
                                                                    // Original: dev = observed[0] - expected[0] = 1 - 2 = -1
                                                                    // Mutated: dev would start at 1.0 but gets reassigned to -1
                                                                    // However, if the mutation affected the calculation, we'd see different results
                                                                    
                                                                    // For second element (i=1):
                                                                    // dev = observed[1] - expected[1] = 4 - 3 = 1
                                                                    
                                                                    // sumSq = (-1)^2/2 + (1)^2/3 = 0.5 + 0.333... = 0.833...
                                                                    double expectedValue = (1.0/2.0) + (1.0/3.0); // 0.5 + 0.333... = 0.833...
                                                                    
                                                                    // Execute
                                                                    double result = chiSquareTest.chiSquare(expected, observed);
                                                                    
                                                                    // Verify
                                                                    assertEquals(expectedValue, result, 1e-10);
                                                                    
                                                                    // This test will catch the mutant because:
                                                                    // If dev was initialized to 1.0 but properly reassigned, result would be same
                                                                    // If the mutation affected the calculation (e.g., was used before reassignment),
                                                                    // the result would differ
                                                                }

 @Test
                                                                public void testChiSquareWithSimpleContingencyTable() {
                                                                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                    
                                                                    // Simple 2x2 contingency table where row and column sums are equal
                                                                    // This makes expected values easy to calculate manually
                                                                    long[][] counts = {
                                                                        {10, 20},
                                                                        {20, 10}
                                                                    };
                                                                    
                                                                    // Calculate expected values manually:
                                                                    // Row sums: 30, 30
                                                                    // Column sums: 30, 30
                                                                    // Total: 60
                                                                    // Expected for each cell = (rowSum * colSum)/total = (30*30)/60 = 15
                                                                    // Chi-square = sum((observed-expected)^2/expected)
                                                                    // For all cells: (10-15)^2/15 + (20-15)^2/15 + (20-15)^2/15 + (10-15)^2/15
                                                                    // = (25/15)*4 = 6.666...
                                                                    
                                                                    double expectedChiSquare = (25.0/15.0)*4;  // Should be 6.666...
                                                                    double actualChiSquare = chiSquareTest.chiSquare(counts);
                                                                    
                                                                    // Use delta of 0.0001 for floating point comparison
                                                                    assertEquals("Chi-square calculation incorrect", 
                                                                                expectedChiSquare, 
                                                                                actualChiSquare, 
                                                                                0.0001);
                                                                    
                                                                    // Additional assertion to specifically catch the dev=1.0 mutation
                                                                    // If dev was initialized to 1.0 instead of 0.0, the result would be off by 4
                                                                    // (since there are 4 cells and each would add 1 to the sum)
                                                                    assertFalse("Mutation not detected - possible initialization error", 
                                                                               Math.abs(actualChiSquare - (expectedChiSquare + 4)) < 0.0001);
                                                                }

 @Test
                                                               public void testChiSquareWithRescalingDetectsSubtractionMutant() {
                                                                   // Setup
                                                                   ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                   double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
                                                                   long[] observed = {12L, 18L, 30L};       // Sum = 60.00001 (forcing rescale)
                                                                   
                                                                   // Expected calculation:
                                                                   // ratio = 60.00001 / 60 ≈ 1.0000001667
                                                                   // For first element: (12 - 1.0000001667*10)^2/(1.0000001667*10) ≈ 0.3999999
                                                                   // Second element: (18 - 1.0000001667*20)^2/(1.0000001667*20) ≈ 0.1999999
                                                                   // Third element: (30 - 1.0000001667*30)^2/(1.0000001667*30) ≈ 0.0
                                                                   // Expected sumSq ≈ 0.3999999 + 0.1999999 + 0.0 ≈ 0.6
                                                                   
                                                                   // Execute
                                                                   double result = chiSquareTest.chiSquare(expected, observed);
                                                                   
                                                                   // Verify - mutant would subtract instead of add, giving negative result
                                                                   assertEquals(0.6, result, 0.0001);
                                                                   
                                                                   // Additional verification that result is positive (mutant would make it negative)
                                                                   assertTrue(result > 0);
                                                               }

 @Test
                                                               public void testChiSquarePositiveResult() {
                                                                   // Create a simple 2x2 contingency table
                                                                   long[][] counts = {
                                                                       {10, 20},
                                                                       {30, 40}
                                                                   };
                                                                   
                                                                   ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                   double result = chiSquareTest.chiSquare(counts);
                                                                   
                                                                   // The chi-square statistic should always be positive
                                                                   assertTrue("Chi-square result should be positive", result > 0);
                                                                   
                                                                   // Verify against manually calculated expected value
                                                                   // Expected values:
                                                                   // [ (10+20)*(10+30)/100 = 12, (10+20)*(20+40)/100 = 18 ]
                                                                   // [ (30+40)*(10+30)/100 = 28, (30+40)*(20+40)/100 = 42 ]
                                                                   // Chi-square components:
                                                                   // (10-12)^2/12 + (20-18)^2/18 + (30-28)^2/28 + (40-42)^2/42
                                                                   // = 4/12 + 4/18 + 4/28 + 4/42 ≈ 0.7937
                                                                   double expected = (4.0/12) + (4.0/18) + (4.0/28) + (4.0/42);
                                                                   assertEquals(expected, result, 0.0001);
                                                               }

 @Test
                                                              public void testChiSquareWithRescalingDetectsSumAccumulationMutant() {
                                                                  ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                  
                                                                  // Create test data where rescaling will be needed (sums differ)
                                                                  double[] expected = {10.0, 20.0, 30.0};  // Sum = 60.0
                                                                  long[] observed = {15L, 25L, 35L};       // Sum = 75.0
                                                                  
                                                                  // Calculate expected result manually
                                                                  double ratio = 75.0 / 60.0;  // 1.25
                                                                  double dev1 = 15 - (10 * ratio);
                                                                  double dev2 = 25 - (20 * ratio);
                                                                  double dev3 = 35 - (30 * ratio);
                                                                  double expectedSumSq = (dev1*dev1)/(10*ratio) + (dev2*dev2)/(20*ratio) + (dev3*dev3)/(30*ratio);
                                                                  
                                                                  // Call method and assert
                                                                  double result = chiSquareTest.chiSquare(expected, observed);
                                                                  assertEquals(expectedSumSq, result, 1E-10);
                                                                  
                                                                  // The mutant would only compute (dev3*dev3)/(30*ratio) and lose previous terms
                                                                  // So this test would fail for the mutant (result would be much smaller)
                                                              }

 @Test
                                                              public void testChiSquareAccumulatesSquaredDeviations() {
                                                                  // Create a 2x2 contingency table where all cells contribute to sumSq
                                                                  long[][] counts = {
                                                                      {10, 20},
                                                                      {30, 40}
                                                                  };
                                                                  
                                                                  ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                  
                                                                  // Calculate expected result manually
                                                                  // Row sums: 30, 70
                                                                  // Column sums: 40, 60
                                                                  // Total: 100
                                                                  // Expected values:
                                                                  // Cell[0][0]: (30*40)/100 = 12
                                                                  // Cell[0][1]: (30*60)/100 = 18
                                                                  // Cell[1][0]: (70*40)/100 = 28
                                                                  // Cell[1][1]: (70*60)/100 = 42
                                                                  // Squared deviations:
                                                                  // (10-12)²/12 = 0.333...
                                                                  // (20-18)²/18 = 0.222...
                                                                  // (30-28)²/28 = 0.142...
                                                                  // (40-42)²/42 = 0.095...
                                                                  // Total sumSq: ~0.333 + 0.222 + 0.142 + 0.095 = ~0.792
                                                                  
                                                                  double result = chiSquareTest.chiSquare(counts);
                                                                  
                                                                  // Verify the accumulated sum is correct (with delta for floating point precision)
                                                                  assertEquals(0.792, result, 0.001);
                                                                  
                                                                  // The mutant would only keep the last deviation (0.095) and return that instead
                                                                  // So this test would fail if the mutant is present
                                                              }

 @Test
                                                             public void testChiSquareWithRescalingDetectsDivisionMutant() {
                                                                 ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                 
                                                                 // Input arrays where sums differ to trigger rescaling
                                                                 double[] expected = {10.0, 20.0, 30.0};  // Sum = 60.0
                                                                 long[] observed = {15L, 25L, 35L};       // Sum = 75.0
                                                                 
                                                                 // Calculate expected ratio
                                                                 double ratio = 75.0 / 60.0;  // 1.25
                                                                 
                                                                 // Manually calculate expected chi-square value
                                                                 double expectedSumSq = 0.0;
                                                                 for (int i = 0; i < observed.length; i++) {
                                                                     double dev = observed[i] - ratio * expected[i];
                                                                     expectedSumSq += dev * dev / (ratio * expected[i]);
                                                                 }
                                                                 
                                                                 // Call method and assert
                                                                 double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                                 
                                                                 // Use delta of 1E-10 for floating point comparison
                                                                 assertEquals(expectedSumSq, actualSumSq, 1E-10);
                                                                 
                                                                 // Additional check that mutant would fail:
                                                                 // If mutant was active, result would be much larger
                                                                 double mutantSumSq = 0.0;
                                                                 for (int i = 0; i < observed.length; i++) {
                                                                     double dev = observed[i] - ratio * expected[i];
                                                                     mutantSumSq += dev * dev * (ratio * expected[i]);
                                                                 }
                                                                 assertNotEquals(mutantSumSq, actualSumSq, 1E-10);
                                                             }

 @Test
                                                             public void testChiSquareWithSimpleContingencyTable1() {
                                                                 // Create a simple 2x2 contingency table
                                                                 long[][] counts = {
                                                                     {10, 20},
                                                                     {30, 40}
                                                                 };
                                                                 
                                                                 // Expected calculations:
                                                                 // Row sums: 30, 70
                                                                 // Column sums: 40, 60
                                                                 // Total: 100
                                                                 // Expected values:
                                                                 // [0][0]: (30*40)/100 = 12
                                                                 // [0][1]: (30*60)/100 = 18
                                                                 // [1][0]: (70*40)/100 = 28
                                                                 // [1][1]: (70*60)/100 = 42
                                                                 // Chi-square components:
                                                                 // (10-12)²/12 = 0.333
                                                                 // (20-18)²/18 = 0.222
                                                                 // (30-28)²/28 = 0.143
                                                                 // (40-42)²/42 = 0.095
                                                                 // Total expected chi-square: ~0.7937
                                                                 
                                                                 ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                 double result = chiSquareTest.chiSquare(counts);
                                                                 
                                                                 // Allow small delta for floating point precision
                                                                 assertEquals(0.7937, result, 0.0001);
                                                                 
                                                                 // The mutant would calculate:
                                                                 // (10-12)²*(ratio*12) = much larger value
                                                                 // So this assertion would fail for the mutant
                                                             }

 @Test
                                                            public void testChiSquareNoRescalingNeeded() {
                                                                // Setup - create arrays where sums are equal (no rescaling needed)
                                                                double[] expected = {10.0, 20.0, 30.0};  // sum = 60.0
                                                                long[] observed = {10L, 20L, 30L};       // sum = 60.0
                                                                
                                                                // Create instance
                                                                ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                                
                                                                // Calculate expected result without rescaling
                                                                double expectedSumSq = 0.0;
                                                                for (int i = 0; i < observed.length; i++) {
                                                                    double dev = observed[i] - expected[i];
                                                                    expectedSumSq += dev * dev / expected[i];
                                                                }
                                                                
                                                                // Call method and get actual result
                                                                double actualSumSq = chiSquareTest.chiSquare(expected, observed);
                                                                
                                                                // Assert - should match non-rescaled calculation
                                                                assertEquals(expectedSumSq, actualSumSq, 1E-10);
                                                                
                                                                // For mutated version (if (true)), the actualSumSq would be different
                                                                // because it would incorrectly use rescaling
                                                            }

 @Test
                                                           public void testChiSquareWithSumMismatch() {
                                                               ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                               
                                                               // Create test data where row/column sums don't match properly
                                                               // This will make sumExpected != sumObserved by more than 10E-6
                                                               // Modified to have unequal row sums to naturally trigger the sum mismatch
                                                               long[][] counts = {
                                                                   {10, 20, 30},  // sum = 60
                                                                   {20, 10, 20},  // sum = 50
                                                                   {30, 20, 5}    // sum = 55 (changed last value to create sum mismatch)
                                                               };
                                                               
                                                               try {
                                                                   double result = chiSquareTest.chiSquare(counts);
                                                                   // If we get here with the mutant, the test should fail
                                                                   // With original code, this should throw an exception before reaching here
                                                                   fail("Expected an exception due to sum mismatch but got result: " + result);
                                                               } catch (IllegalArgumentException e) {
                                                                   // Expected behavior for original code
                                                                   assertTrue(e.getMessage().contains("sum mismatch"));
                                                               } catch (Exception e) {
                                                                   fail("Unexpected exception type: " + e.getClass().getName());
                                                               }
                                                           }

 @Test
                                                       public void testChiSquareRescaleCondition() {
                                                           // Create test data where sums are equal (no rescaling needed)
                                                           double[] expected = {10.0, 20.0, 30.0};
                                                           long[] observed = {10L, 20L, 30L};
                                                           
                                                           // Create instance of class under test
                                                           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                                                           
                                                           // Calculate expected result (without rescaling)
                                                           double sumSqExpected = 0.0;
                                                           for (int i = 0; i < observed.length; i++) {
                                                               double dev = observed[i] - expected[i];
                                                               sumSqExpected += dev * dev / expected[i];
                                                           }
                                                           
                                                           // Call method and get actual result
                                                           double actual = chiSquareTest.chiSquare(expected, observed);
                                                           
                                                           // Assert that result matches expected calculation (non-rescaled version)
                                                           assertEquals(sumSqExpected, actual, 1E-10);
                                                           
                                                           // The mutant would calculate using rescaling (ratio=1) which would give same result
                                                           // numerically, but is logically wrong. To catch this, we need to verify the rescaling
                                                           // flag isn't set when sums are equal
                                                           
                                                           // Alternative test with values that would show difference if rescaling was forced
                                                           double[] expected2 = {10.0, 20.0, 30.00001}; // tiny difference that shouldn't trigger rescaling
                                                           long[] observed2 = {10L, 20L, 30L};
                                                           
                                                           // Calculate what result should be without rescaling
                                                           double sumSqExpected2 = 0.0;
                                                           for (int i = 0; i < observed2.length; i++) {
                                                               double dev = observed2[i] - expected2[i];
                                                               sumSqExpected2 += dev * dev / expected2[i];
                                                           }
                                                           
                                                           // Call method and verify it matches non-rescaled calculation
                                                           double actual2 = chiSquareTest.chiSquare(expected2, observed2);
                                                           assertEquals(sumSqExpected2, actual2, 1E-10);
                                                       }

 @Test
                      public void testChiSquareRescaleMutant() throws Exception {
                          // Setup test data where rescaling would make a difference
                          long[][] counts = {
                              {10, 20, 30},
                              {20, 10, 30},
                              {30, 30, 10}
                          };
                          
                          // Mock the distribution to return known values
                          final ChiSquaredDistribution mockDist = mock(ChiSquaredDistribution.class);
                          when(mockDist.cumulativeProbability(anyDouble())).thenReturn(0.95);
                          
                          // Create test instance with mocked distribution
                          ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl(mockDist);
                          
                          // Calculate chi-square with original behavior (would use rescale condition)
                          double originalResult = chiSquareTest.chiSquare(counts);
                          
                          // Force rescale to true (simulate mutant behavior)
                          // Since we can't directly modify the mutant, we'll test by ensuring
                          // the distribution is always used (which would happen with rescale=true)
                          verify(mockDist, atLeastOnce()).cumulativeProbability(anyDouble());
                          
                          // Alternative approach - test that results are different when rescaling is forced
                          // This would catch if rescaling was always on (mutant behavior)
                          ChiSquareTestImpl mutantInstance = new ChiSquareTestImpl(mockDist) {
                              @Override
                              public double chiSquare(long[][] counts) {
                                  try {
                                      // Force rescale=true behavior by calling super and then applying distribution
                                      double sumSq = super.chiSquare(counts);
                                      // Use the mock distribution directly
                                      return mockDist.cumulativeProbability(sumSq);
                                  } catch (Exception e) {
                                      throw new RuntimeException(e);
                                  }
                              }
                          };
                          
                          double mutantResult = mutantInstance.chiSquare(counts);
                          assertNotEquals("Mutant should produce different result due to forced rescaling", 
                                         originalResult, mutantResult, 0.0001);
                      }

 @Test
                  public void testChiSquareWithRescalingDetectsMutant() {
                      // Setup
                      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                      double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
                      long[] observed = {15L, 25L, 35L};        // Sum = 75 (different from expected)
                      
                      // Expected calculation:
                      // ratio = 75/60 = 1.25
                      // For first element: (15 - 1.25*10)^2/(1.25*10) = (2.5)^2/12.5 = 6.25/12.5 = 0.5
                      // For second element: (25 - 1.25*20)^2/(1.25*20) = 0/25 = 0
                      // For third element: (35 - 1.25*30)^2/(1.25*30) = (-2.5)^2/37.5 = 6.25/37.5 ≈ 0.166666
                      // Total expected sumSq ≈ 0.5 + 0 + 0.166666 ≈ 0.666666
                      
                      // Mutant would calculate: 
                      // For first element: 6.25/(12.5*2) = 0.25
                      // Second element: 0
                      // Third element: 6.25/(37.5*2) ≈ 0.083333
                      // Total mutant sumSq ≈ 0.333333
                      
                      // Action
                      double result = chiSquareTest.chiSquare(expected, observed);
                      
                      // Assert - using delta of 0.0001 for floating point precision
                      assertEquals(0.666666, result, 0.0001);
                      
                      // This assertion will fail for the mutant (which would return ~0.333333)
                      // but pass for the original implementation
                  }

 @Test
                  public void testChiSquareDetectsMutant() {
                      // Create a simple 2x2 contingency table where we can manually calculate expected chi-square
                      long[][] counts = {
                          {10, 20},
                          {30, 40}
                      };
                      
                      // Manually calculate expected chi-square value
                      // Row sums: 30, 70
                      // Column sums: 40, 60
                      // Total: 100
                      // Expected values:
                      // [0][0]: (30*40)/100 = 12
                      // [0][1]: (30*60)/100 = 18
                      // [1][0]: (70*40)/100 = 28
                      // [1][1]: (70*60)/100 = 42
                      // Chi-square contributions:
                      // [0][0]: (10-12)²/12 = 0.333
                      // [0][1]: (20-18)²/18 = 0.222
                      // [1][0]: (30-28)²/28 = 0.143
                      // [1][1]: (40-42)²/42 = 0.095
                      // Total expected chi-square: 0.333 + 0.222 + 0.143 + 0.095 = 0.793 (approx)
                      
                      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                      double result = chiSquareTest.chiSquare(counts);
                      
                      // The mutant would return half of this value (0.793/2 = 0.3965)
                      // So we assert the result is greater than the mutant would produce
                      assertEquals(0.793, result, 0.001);
                      
                      // Also verify it's not approximately half the expected value
                      assertFalse(Math.abs(result - 0.3965) < 0.001);
                  }

 @Test
                 public void testChiSquareRescalingThreshold() {
                     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                     
                     // Create test data where difference is 5E-6 (between 10E-6 and 10E-5)
                     double[] expected = {1.000000, 1.000000};
                     long[] observed = {1, 1}; // Sum = 2
                     expected[0] = 1.0000025; // Expected sum = 2.0000025, difference = 2.5E-6
                     
                     // Original would rescale (difference > 1E-6), mutant would not (difference < 1E-5)
                     double result = chiSquareTest.chiSquare(expected, observed);
                     
                     // Calculate expected results for both cases
                     double noRescaleSumSq = 
                         Math.pow(1 - 1.0000025, 2)/1.0000025 + 
                         Math.pow(1 - 1.0000000, 2)/1.0000000;
                     
                     double ratio = 2.0 / 2.0000025;
                     double rescaledSumSq = 
                         Math.pow(1 - ratio*1.0000025, 2)/(ratio*1.0000025) + 
                         Math.pow(1 - ratio*1.0000000, 2)/(ratio*1.0000000);
                     
                     // Assert the result matches the rescaled calculation (original behavior)
                     // Mutant would match noRescaleSumSq instead
                     assertEquals(rescaledSumSq, result, 1E-10);
                     
                     // Additional test with difference = 1.1E-5 (should rescale in both)
                     expected[0] = 1.0000055; // Expected sum = 2.0000055, difference = 5.5E-6
                     result = chiSquareTest.chiSquare(expected, observed);
                     ratio = 2.0 / 2.0000055;
                     rescaledSumSq = 
                         Math.pow(1 - ratio*1.0000055, 2)/(ratio*1.0000055) + 
                         Math.pow(1 - ratio*1.0000000, 2)/(ratio*1.0000000);
                     assertEquals(rescaledSumSq, result, 1E-10);
                 }

 @Test
                 public void testChiSquareWithPrecisionDifference() {
                     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                     
                     // Create a contingency table where the difference between expected and observed
                     // is between 10E-6 and 10E-5 to catch the mutant
                     long[][] counts = new long[][] {
                         {1000000, 1000001},  // Very close values to create small difference
                         {1000000, 1000000}
                     };
                     
                     // Calculate expected chi-square value manually
                     double expectedChiSquare = 0.0;
                     
                     // Compute row sums, column sums and total
                     double[] rowSum = new double[2];
                     double[] colSum = new double[2];
                     double total = 0.0;
                     for (int row = 0; row < 2; row++) {
                         for (int col = 0; col < 2; col++) {
                             rowSum[row] += counts[row][col];
                             colSum[col] += counts[row][col];
                             total += counts[row][col];
                         }
                     }
                     
                     // Compute expected chi-square value
                     for (int row = 0; row < 2; row++) {
                         for (int col = 0; col < 2; col++) {
                             double expected = (rowSum[row] * colSum[col]) / total;
                             expectedChiSquare += Math.pow(counts[row][col] - expected, 2) / expected;
                         }
                     }
                     
                     // The actual value should be very close to our manual calculation
                     double actualChiSquare = chiSquareTest.chiSquare(counts);
                     
                     // Assert that the difference is within 10E-6 (original would pass, mutant might fail)
                     assertEquals(expectedChiSquare, actualChiSquare, 1E-6);
                     
                     // Additional assertion to specifically catch the mutant
                     // The difference should be more than 1E-6 but less than 1E-5
                     double difference = Math.abs(expectedChiSquare - actualChiSquare);
                     assertTrue("Difference should be detectable at 1E-6 precision", 
                                difference > 1E-6 && difference <= 1E-5);
                 }

 @Test
                public void testChiSquareRescalingThreshold1() {
                    ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
                    
                    // Create test data where difference is 5E-7 (between 10E-7 and 10E-6)
                    double[] expected = new double[]{1.0000005, 1.0000000};
                    long[] observed = new long[]{1, 1};
                    
                    // Calculate expected results for both scenarios
                    // Without rescaling (original behavior)
                    double dev1 = observed[0] - expected[0];
                    double dev2 = observed[1] - expected[1];
                    double expectedOriginal = (dev1 * dev1 / expected[0]) + (dev2 * dev2 / expected[1]);
                    
                    // With rescaling (mutant behavior)
                    double sumExpected = expected[0] + expected[1];
                    double sumObserved = observed[0] + observed[1];
                    double ratio = sumObserved / sumExpected;
                    double dev1Rescaled = observed[0] - ratio * expected[0];
                    double dev2Rescaled = observed[1] - ratio * expected[1];
                    double expectedMutant = (dev1Rescaled * dev1Rescaled / (ratio * expected[0])) + 
                                           (dev2Rescaled * dev2Rescaled / (ratio * expected[1]));
                    
                    // Actual result
                    double actual = chiSquareTest.chiSquare(expected, observed);
                    
                    // Assert that the result matches the original behavior (no rescaling)
                    // This will fail if the mutant is present (which would use rescaling)
                    assertEquals(expectedOriginal, actual, 1E-10);
                    
                    // Additional assertion to ensure we're testing the right scenario
                    double diff = Math.abs(sumExpected - sumObserved);
                    assertTrue(diff > 1E-7 && diff < 1E-6);
                }

 @Test
           public void testChiSquareWithSmallDifference() {
               ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
               
               // Create a contingency table where row/column sums will create
               // expected values that differ slightly from observed
               long[][] counts = {
                   {1000000, 1000001},
                   {1000000, 1000000}
               };
               
               // Calculate expected sum and observed sum difference
               // The difference should be between 10E-7 and 10E-6
               double result = chiSquareTest.chiSquare(counts);
               
               // Verify the result is as expected
               // The exact expected value would need to be calculated manually,
               // but we know it should be a small positive number
               assertTrue("Chi-square value should be positive", result > 0);
               
               // The key assertion that would catch the mutant:
               // The original would pass this test while the mutant would fail
               // because the difference would be > 10E-7 but < 10E-6
               assertTrue("Chi-square value should be relatively small", result < 0.00001);
               
               // Additional verification that the calculation is reasonable
               double expectedChiSquare = 
                   (Math.pow(1000000 - 999999.5, 2)/999999.5 + 
                   Math.pow(1000001 - 1000001.5, 2)/1000001.5 +
                   Math.pow(1000000 - 1000000.5, 2)/1000000.5 +
                   Math.pow(1000000 - 999999.5, 2)/999999.5);
               
               assertEquals("Chi-square calculation should match expected", 
                          expectedChiSquare, result, 1E-10);
           }

 @Test
       public void testChiSquareWithRescalingDetectsNegativeRatioMutant() {
           // Setup
           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
           double[] expected = new double[]{10.0, 20.0, 30.0};  // Sum = 60
           long[] observed = new long[]{15, 25, 35};            // Sum = 75 (different from expected)
           
           // Expected behavior: ratio should be positive (75/60 = 1.25)
           // With mutant (ratio = -1.0), calculations will be incorrect
           
           // Execute and verify
           double result = chiSquareTest.chiSquare(expected, observed);
           
           // Original should return positive chi-square value
           // Mutant would produce wrong negative values in intermediate calculations
           assertTrue("Result should be positive", result > 0);
           
           // Additional verification - calculate expected value
           double expectedRatio = 75.0 / 60.0;
           double expectedSumSq = 0.0;
           for (int i = 0; i < observed.length; i++) {
               double dev = observed[i] - expectedRatio * expected[i];
               expectedSumSq += dev * dev / (expectedRatio * expected[i]);
           }
           
           assertEquals("Chi-square value incorrect", expectedSumSq, result, 1E-10);
       }

 @Test
       public void testChiSquareWithPositiveRatio() {
           // Create test data - simple 2x2 contingency table
           long[][] counts = {
               {10, 20},
               {30, 40}
           };
           
           // Expected calculations:
           // Row sums: 30, 70
           // Column sums: 40, 60
           // Total: 100
           // Expected values:
           // [0][0]: (30*40)/100 = 12
           // [0][1]: (30*60)/100 = 18
           // [1][0]: (70*40)/100 = 28
           // [1][1]: (70*60)/100 = 42
           // Chi-square components:
           // (10-12)^2/12 = 0.333
           // (20-18)^2/18 = 0.222
           // (30-28)^2/28 = 0.143
           // (40-42)^2/42 = 0.095
           // Total chi-square: ~0.793
           
           ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
           double result = chiSquareTest.chiSquare(counts);
           
           // Verify result is positive and matches expected value
           assertTrue("Chi-square value should be positive", result > 0);
           assertEquals(0.793, result, 0.001);
           
           // Additional check to ensure ratio wasn't negative
           // If ratio was negative, result would be negative or NaN
           assertFalse("Result should not be NaN", Double.isNaN(result));
       }

 @Test
      public void testChiSquareWithRescalingDetectsRatioMutation() {
          // Setup - create arrays where sums differ to trigger rescaling
          double[] expected = {10.0, 20.0, 30.0};  // sum = 60
          long[] observed = {15L, 25L, 35L};       // sum = 75 (diff > 10E-6)
          
          // Expected ratio would be 75/60 = 1.25
          // With mutant ratio=Double.MAX_VALUE, calculations would overflow
          
          ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
          
          // Calculate expected value manually
          double manualSumSq = 0.0;
          double manualRatio = 75.0 / 60.0;
          for (int i = 0; i < observed.length; i++) {
              double manualDev = observed[i] - manualRatio * expected[i];
              manualSumSq += manualDev * manualDev / (manualRatio * expected[i]);
          }
          
          // Test - should get same result as manual calculation
          double result = chiSquareTest.chiSquare(expected, observed);
          
          // Verify result is finite and matches expected calculation
          assertTrue(Double.isFinite(result));
          assertEquals(manualSumSq, result, 1E-10);
          
          // Additional check that result isn't extreme (which would happen with MAX_VALUE ratio)
          assertTrue(result < 1000);  // Actual value should be small for this input
      }

 @Test
      public void testChiSquareWithSmallInputDetectsRatioMutation() {
          // Create a simple 2x2 contingency table
          long[][] counts = {
              {10, 20},
              {30, 40}
          };
          
          // Expected chi-square value calculated manually
          double expectedChiSquare = 1.8518518518518519;
          
          // Create instance of class under test
          ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
          
          // Call method and get actual result
          double actualResult = chiSquareTest.chiSquare(counts);
          
          // Assert the result matches expected value with delta for floating point precision
          assertEquals("Chi-square value should match expected calculation", 
                      expectedChiSquare, 
                      actualResult, 
                      0.0000001);
          
          // Additional assertion to ensure result isn't extremely large (would catch the MAX_VALUE mutation)
          assertTrue("Chi-square value should be reasonable magnitude", 
                     actualResult < 1000.0);
      }

 @Test
     public void testChiSquareRescaleFlagMutation() {
         ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
         
         // Test case where sums are equal (no rescaling needed)
         double[] expected = {10.0, 10.0, 10.0};  // Sum = 30.0
         long[] observed = {10L, 10L, 10L};       // Sum = 30.0
         
         // Calculate expected result without rescaling
         double expectedSumSq = 0.0;
         for (int i = 0; i < observed.length; i++) {
             double dev = observed[i] - expected[i];
             expectedSumSq += dev * dev / expected[i];
         }
         
         // Call method - should use non-rescaled path
         double result = chiSquareTest.chiSquare(expected, observed);
         
         // Assert equals with delta for floating point comparison
         assertEquals("Should calculate chi-square without rescaling", 
                     expectedSumSq, result, 1E-10);
         
         // The mutant would incorrectly use rescaled path (ratio=1.0) 
         // which would give same result in this case, so we need another test
         
         // Test case where sums are equal but values differ (non-zero chi-square)
         expected = new double[]{10.0, 20.0, 30.0};  // Sum = 60.0
         observed = new long[]{15L, 20L, 25L};       // Sum = 60.0
         
         // Calculate expected non-rescaled result
         expectedSumSq = 0.0;
         for (int i = 0; i < observed.length; i++) {
             double dev = observed[i] - expected[i];
             expectedSumSq += dev * dev / expected[i];
         }
         
         result = chiSquareTest.chiSquare(expected, observed);
         
         // The mutant would calculate with rescaling (ratio=1.0) which would give same result,
         // so we need a case where sums are exactly equal but ratio would affect calculation
         
         // Final test case where sums are exactly equal but rescaling would affect calculation
         // if incorrectly applied
         expected = new double[]{1.0, 2.0, 3.0};  // Sum = 6.0
         observed = new long[]{2L, 2L, 2L};       // Sum = 6.0
         
         // Correct non-rescaled calculation
         expectedSumSq = 0.0;
         for (int i = 0; i < observed.length; i++) {
             double dev = observed[i] - expected[i];
             expectedSumSq += dev * dev / expected[i];
         }
         
         // Mutant's incorrect rescaled calculation (with ratio=1.0)
         double mutantSumSq = 0.0;
         double ratio = 1.0;
         for (int i = 0; i < observed.length; i++) {
             double dev = observed[i] - ratio * expected[i];
             mutantSumSq += dev * dev / (ratio * expected[i]);
         }
         
         // Verify they're different (would be same if ratio was not 1.0)
         assertNotEquals("Mutant would produce different result", 
                        mutantSumSq, expectedSumSq, 1E-10);
         
         // Now test actual method
         result = chiSquareTest.chiSquare(expected, observed);
         assertEquals("Should calculate chi-square without rescaling", 
                     expectedSumSq, result, 1E-10);
     }

 @Test
     public void testChiSquareWithRescaleMutation() {
         // Create test input where rescaling would affect results if enabled
         long[][] counts = {
             {10, 20, 30},
             {20, 10, 20}
         };
         
         // Expected chi-square value calculated manually
         double expectedChiSquare = 8.333333333333334;
         
         // Create instance and calculate
         ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
         double result = chiSquareTest.chiSquare(counts);
         
         // Verify exact match - if rescaling were happening, this would fail
         assertEquals(expectedChiSquare, result, 1e-10);
         
         // Additional verification that row/column sums are unchanged
         double[] rowSums = new double[counts.length];
         double[] colSums = new double[counts[0].length];
         double total = 0;
         
         for (int row = 0; row < counts.length; row++) {
             for (int col = 0; col < counts[0].length; col++) {
                 rowSums[row] += counts[row][col];
                 colSums[col] += counts[row][col];
                 total += counts[row][col];
             }
         }
         
         // Verify first row sum
         assertEquals(60.0, rowSums[0], 1e-10);
         // Verify first column sum
         assertEquals(30.0, colSums[0], 1e-10);
         // Verify total
         assertEquals(110.0, total, 1e-10);
     }

 @Test
    public void testChiSquareRescalingBehavior1() {
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        
        // Test case where rescaling should occur (sums differ significantly)
        double[] expected1 = {10.0, 20.0, 30.0};
        long[] observed1 = {15L, 25L, 35L}; // Sums differ by 15
        double result1 = chiSquareTest.chiSquare(expected1, observed1);
        
        // Verify rescaling was applied by checking the result against manually calculated value
        double ratio = 75.0/60.0; // sumObserved/sumExpected
        double manualSumSq = 0.0;
        for (int i = 0; i < observed1.length; i++) {
            double dev = observed1[i] - ratio * expected1[i];
            manualSumSq += dev * dev / (ratio * expected1[i]);
        }
        assertEquals(manualSumSq, result1, 1E-10);
        
        // Test case where rescaling should NOT occur (sums are nearly equal)
        double[] expected2 = {10.0, 20.0, 30.0000001}; // Sum = 60.0000001
        long[] observed2 = {10L, 20L, 30L}; // Sum = 60
        double result2 = chiSquareTest.chiSquare(expected2, observed2);
        
        // Verify no rescaling was applied
        double manualSumSq2 = 0.0;
        for (int i = 0; i < observed2.length; i++) {
            double dev = observed2[i] - expected2[i];
            manualSumSq2 += dev * dev / expected2[i];
        }
        assertEquals(manualSumSq2, result2, 1E-10);
    }

 @Test
    public void testChiSquareWithMutantRescale() {
        ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
        
        // Test with simple 2x2 contingency table
        long[][] counts1 = {{10, 20}, {30, 40}};
        double result1 = chiSquareTest.chiSquare(counts1);
        assertTrue(result1 > 0); // Should be positive
        
        // Test with rectangular but non-square table
        long[][] counts2 = {{5, 10, 15}, {20, 25, 30}};
        double result2 = chiSquareTest.chiSquare(counts2);
        assertTrue(result2 > 0);
        
        // Test with minimum values
        long[][] counts3 = {{1, 1}, {1, 1}};
        double result3 = chiSquareTest.chiSquare(counts3);
        assertEquals(0.0, result3, 1e-10); // Should be 0 for perfect fit
        
        // Test with larger table
        long[][] counts4 = {{10, 20, 30}, {40, 50, 60}, {70, 80, 90}};
        double result4 = chiSquareTest.chiSquare(counts4);
        assertTrue(result4 > 0);
        
        // Test edge case with zeros (though checkArray should prevent this)
        try {
            long[][] counts5 = {{0, 0}, {0, 0}};
            chiSquareTest.chiSquare(counts5);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected
        }
        
        // Test non-rectangular array (should throw exception)
        try {
            long[][] counts6 = {{1, 2}, {3}};
            chiSquareTest.chiSquare(counts6);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected
        }
    }

 @Test
   public void testChiSquareRescalingThreshold2() {
       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
       
       // Test case where difference is exactly at threshold (10E-6)
       double[] expected = {1000000.0, 1000000.0};
       long[] observed = {1000001, 999999}; // difference of exactly 2 (1 and -1)
       
       // Should rescale in original, might not in mutant
       double result = chiSquareTest.chiSquare(expected, observed);
       
       // Calculate what result should be with rescaling
       double sumExpected = 2000000.0;
       double sumObserved = 2000000.0;
       double ratio = sumObserved / sumExpected;
       double expectedRescaledValue = 
           Math.pow(1000001 - ratio * 1000000.0, 2) / (ratio * 1000000.0) +
           Math.pow(999999 - ratio * 1000000.0, 2) / (ratio * 1000000.0);
       
       // Verify rescaling occurred by checking against expected rescaled value
       assertEquals(expectedRescaledValue, result, 1E-10);
       
       // Test case where difference is just below threshold
       expected = new double[]{1000000.0, 1000000.0};
       observed = new long[]{1000000, 1000000}; // difference of 0
       
       result = chiSquareTest.chiSquare(expected, observed);
       // Should be 0 since observed exactly matches expected
       assertEquals(0.0, result, 1E-10);
       
       // Test case where difference is just above threshold
       expected = new double[]{1000000.0, 1000000.0};
       observed = new long[]{1000002, 999998}; // difference of 4
       
       sumExpected = 2000000.0;
       sumObserved = 2000000.0;
       ratio = sumObserved / sumExpected;
       expectedRescaledValue = 
           Math.pow(1000002 - ratio * 1000000.0, 2) / (ratio * 1000000.0) +
           Math.pow(999998 - ratio * 1000000.0, 2) / (ratio * 1000000.0);
       
       result = chiSquareTest.chiSquare(expected, observed);
       assertEquals(expectedRescaledValue, result, 1E-10);
   }

 @Test
   public void testChiSquareWithPreciseThreshold() {
       ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
       
       // Create a contingency table where the difference is exactly at threshold
       long[][] counts = new long[][] {
           {1000000, 1000000},
           {1000000, 1000000 + 1}  // Very small difference
       };
       
       double result = chiSquareTest.chiSquare(counts);
       
       // Verify the result is calculated properly (not zero)
       assertTrue(result > 0.0);
       
       // Create another table with difference just below threshold
       long[][] counts2 = new long[][] {
           {1000000, 1000000},
           {1000000, 1000000}  // No difference
       };
       
       double result2 = chiSquareTest.chiSquare(counts2);
       assertEquals(0.0, result2, 0.0);
       
       // Create table with difference just above threshold
       long[][] counts3 = new long[][] {
           {1000000, 1000000},
           {1000000, 1000000 + 2}  // Slightly larger difference
       };
       
       double result3 = chiSquareTest.chiSquare(counts3);
       assertTrue(result3 > 0.0);
   }

 @Test
  public void testChiSquareWithSingleElementArrayToDetectDevInitializationMutant() {
      // Setup
      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
      double[] expected = {10.0};
      long[] observed = {8L};
      
      // Expected calculation:
      // Original: dev starts at 0.0, then becomes (8 - 10) = -2
      // sumSq = (-2)^2 / 10 = 0.4
      // Mutant: dev starts at -1.0, then becomes (8 - 10) = -2
      // sumSq still 0.4 since initial value is overwritten
      // Wait - this won't detect the mutant
      
      // Need a case where initial value affects result - perhaps when observed[0] equals expected[0]
      double[] expected2 = {5.0};
      long[] observed2 = {5L};
      
      // Original: dev starts at 0.0, then becomes (5 - 5) = 0
      // sumSq = 0^2 / 5 = 0
      // Mutant: dev starts at -1.0, then becomes (5 - 5) = 0
      // sumSq = (-1)^2 / 5 = 0.2 (wrong)
      double result = chiSquareTest.chiSquare(expected2, observed2);
      
      // Assert
      assertEquals(0.0, result, 1e-10);
      
      // Additional test case where observed != expected to ensure general correctness
      double result2 = chiSquareTest.chiSquare(expected, observed);
      assertEquals(0.4, result2, 1e-10);
  }

 @Test
  public void testChiSquareDevInitializationDoesNotAffectResult() {
      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
      
      // Test case where observed equals expected - result should be 0 regardless of initial dev
      double[] expected = {5.0};
      long[] observed = {5L};
      
      double result = chiSquareTest.chiSquare(expected, observed);
      assertEquals(0.0, result, 1e-10);
      
      // Test case with multiple elements to ensure initial value doesn't persist
      double[] expectedMulti = {2.0, 3.0, 5.0};
      long[] observedMulti = {2L, 3L, 5L};
      
      double resultMulti = chiSquareTest.chiSquare(expectedMulti, observedMulti);
      assertEquals(0.0, resultMulti, 1e-10);
  }

 @Test
  public void testChiSquareWithSimpleContingencyTable2() {
      // Setup
      ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
      long[][] counts = {{10, 10}, {20, 20}}; // Simple 2x2 table
      
      // Expected calculation:
      // Row sums: [20, 40]
      // Col sums: [30, 30]
      // Total: 60
      // Expected values:
      // [0][0]: (20*30)/60 = 10
      // [0][1]: (20*30)/60 = 10
      // [1][0]: (40*30)/60 = 20
      // [1][1]: (40*30)/60 = 20
      // Chi-square components:
      // All (observed-expected)^2/expected = 0
      // Sum should be 0
      
      // Execute
      double result = chiSquareTest.chiSquare(counts);
      
      // Verify
      assertEquals(0.0, result, 1e-10);
      
      // This test would catch the mutation because:
      // Original code would return 0.0 (correct)
      // Mutated code would return -1.0 (incorrect)
      // The assertion would fail for the mutated version
  }

 @Test
 public void testChiSquareWithRescalingDetectsDevInitializationMutant() {
     // Setup
     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
     double[] expected = {10.0, 20.0, 30.0};  // Sum = 60
     long[] observed = {15L, 25L, 35L};       // Sum = 75 (different from expected)
     
     // Expected calculation:
     // ratio = 75/60 = 1.25
     // For first element: dev = 15 - 1.25*10 = 2.5
     // sumSq += 2.5²/(1.25*10) = 6.25/12.5 = 0.5
     // Second element: dev = 25 - 1.25*20 = 0
     // sumSq += 0
     // Third element: dev = 35 - 1.25*30 = -2.5
     // sumSq += 6.25/37.5 ≈ 0.166666
     // Total expected sumSq ≈ 0.5 + 0 + 0.166666 ≈ 0.666666
     
     // Execute
     double result = chiSquareTest.chiSquare(expected, observed);
     
     // Verify
     // With original code, result should be ≈0.666666
     // With mutant (dev=Double.MAX_VALUE), result would be corrupted
     assertEquals(0.666666, result, 1E-5);
     
     // Additional verification that rescaling occurred
     // If rescaling didn't occur, result would be different
     double noRescaleExpected = 
         Math.pow(15-10, 2)/10 + 
         Math.pow(25-20, 2)/20 + 
         Math.pow(35-30, 2)/30; // = 2.5 + 1.25 + 0.83333 ≈ 4.58333
     assertTrue(Math.abs(result - noRescaleExpected) > 1.0);
 }

 @Test
 public void testChiSquareWithKnownValues() {
     // Setup
     ChiSquareTestImpl chiSquareTest = new ChiSquareTestImpl();
     long[][] counts = {{10, 10}, {20, 20}}; // Simple 2x2 table
     
     // Expected calculation:
     // Row sums: 20, 40
     // Col sums: 30, 30
     // Total: 60
     // Expected values: 
     // (20*30)/60 = 10, (20*30)/60 = 10
     // (40*30)/60 = 20, (40*30)/60 = 20
     // Chi-square = (10-10)²/10 + (10-10)²/10 + (20-20)²/20 + (20-20)²/20 = 0
     
     // Execute
     double result = chiSquareTest.chiSquare(counts);
     
     // Verify
     assertEquals("Chi-square should be 0 for perfect fit", 0.0, result, 0.0001);
     
     // This test would fail if the mutation added Double.MAX_VALUE to the result
 }

}
