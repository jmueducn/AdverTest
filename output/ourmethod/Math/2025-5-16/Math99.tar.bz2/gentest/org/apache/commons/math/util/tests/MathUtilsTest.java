package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                          public void testGcd_TypicalPositiveValues() {
                                                              assertEquals(6, MathUtils.gcd(12, 18));
                                                              assertEquals(1, MathUtils.gcd(13, 17));
                                                              assertEquals(5, MathUtils.gcd(15, 25));
                                                              assertEquals(7, MathUtils.gcd(7, 14));
                                                          }

 @Test
                                                          public void testGcd_TypicalNegativeValues() {
                                                              assertEquals(6, MathUtils.gcd(-12, 18));
                                                              assertEquals(6, MathUtils.gcd(12, -18));
                                                              assertEquals(6, MathUtils.gcd(-12, -18));
                                                              assertEquals(1, MathUtils.gcd(-13, -17));
                                                          }

 @Test
                                                          public void testGcd_OneZeroValue() {
                                                              assertEquals(5, MathUtils.gcd(5, 0));
                                                              assertEquals(5, MathUtils.gcd(0, 5));
                                                              assertEquals(7, MathUtils.gcd(-7, 0));
                                                              assertEquals(7, MathUtils.gcd(0, -7));
                                                          }

 @Test
                                                          public void testGcd_BothZeroValues() {
                                                              assertEquals(0, MathUtils.gcd(0, 0));
                                                          }

 @Test
                                                          public void testGcd_EqualValues() {
                                                              assertEquals(42, MathUtils.gcd(42, 42));
                                                              assertEquals(42, MathUtils.gcd(-42, 42));
                                                              assertEquals(42, MathUtils.gcd(42, -42));
                                                              assertEquals(42, MathUtils.gcd(-42, -42));
                                                          }

 @Test
                                                          public void testGcd_OneIsMultipleOfOther() {
                                                              assertEquals(3, MathUtils.gcd(3, 9));
                                                              assertEquals(3, MathUtils.gcd(9, 3));
                                                              assertEquals(4, MathUtils.gcd(4, 16));
                                                              assertEquals(4, MathUtils.gcd(16, 4));
                                                          }

 @Test
                                                          public void testGcd_PrimeNumbers() {
                                                              assertEquals(1, MathUtils.gcd(11, 13));
                                                              assertEquals(1, MathUtils.gcd(17, 19));
                                                              assertEquals(1, MathUtils.gcd(23, 29));
                                                          }

 @Test
                                                          public void testGcd_LargeNumbers() {
                                                              assertEquals(1000, MathUtils.gcd(1000, 1000000));
                                                              assertEquals(12345, MathUtils.gcd(12345, 123450));
                                                              assertEquals(1, MathUtils.gcd(1234567, 7654321));
                                                          }

 @Test
                                                          public void testGcd_EdgeCaseMinimumInteger() {
                                                              // Test with Integer.MIN_VALUE and other values
                                                              assertEquals(1 << 30, MathUtils.gcd(Integer.MIN_VALUE, 1 << 30));
                                                              assertEquals(1, MathUtils.gcd(Integer.MIN_VALUE, Integer.MAX_VALUE));
                                                          }

 @Test
                                                          public void testGcd_ConsecutiveNumbers() {
                                                              assertEquals(1, MathUtils.gcd(8, 9));
                                                              assertEquals(1, MathUtils.gcd(15, 16));
                                                              assertEquals(1, MathUtils.gcd(24, 25));
                                                          }

 @Test
                                                          public void testGcd_OddEvenCombinations() {
                                                              assertEquals(1, MathUtils.gcd(9, 16));
                                                              assertEquals(3, MathUtils.gcd(9, 15));
                                                              assertEquals(2, MathUtils.gcd(4, 6));
                                                          }

 @Test
                                                          public void testLcm_ZeroInputs() {
                                                              assertEquals(0, MathUtils.lcm(0, 5));
                                                              assertEquals(0, MathUtils.lcm(5, 0));
                                                              assertEquals(0, MathUtils.lcm(0, 0));
                                                          }

 @Test
                                                          public void testLcm_PositiveNumbers() {
                                                              assertEquals(12, MathUtils.lcm(3, 4));
                                                              assertEquals(36, MathUtils.lcm(12, 18));
                                                              assertEquals(60, MathUtils.lcm(15, 20));
                                                          }

 @Test
                                                          public void testLcm_NegativeNumbers() {
                                                              assertEquals(12, MathUtils.lcm(-3, 4));
                                                              assertEquals(36, MathUtils.lcm(12, -18));
                                                              assertEquals(60, MathUtils.lcm(-15, -20));
                                                          }

 @Test
                                                          public void testLcm_EqualNumbers() {
                                                              assertEquals(5, MathUtils.lcm(5, 5));
                                                              assertEquals(17, MathUtils.lcm(-17, -17));
                                                          }

 @Test
                                                          public void testLcm_OneIsMultipleOfOther() {
                                                              assertEquals(15, MathUtils.lcm(3, 15));
                                                              assertEquals(24, MathUtils.lcm(24, 8));
                                                          }

 @Test
                                                          public void testLcm_PrimeNumbers() {
                                                              assertEquals(35, MathUtils.lcm(5, 7));
                                                              assertEquals(143, MathUtils.lcm(11, 13));
                                                          }

 @Test
                                                          public void testLcm_LargeNumbers() {
                                                              assertEquals(1071, MathUtils.lcm(153, 119));
                                                              assertEquals(2147483646, MathUtils.lcm(2147483646, 715827882));
                                                          }

 @Test
                                                          public void testLcm_BoundaryValues() {
                                                              assertEquals(2147483646, MathUtils.lcm(2147483646, 1));
                                                              assertEquals(2147483646, MathUtils.lcm(1, 2147483646));
                                                              assertEquals(2147483647, MathUtils.lcm(2147483647, 1));
                                                          }

 @Test
                                                  public void testLcm_OverflowCondition() {
                                                      try {
                                                          MathUtils.lcm(Integer.MIN_VALUE, 1);
                                                          fail("Expected ArithmeticException");
                                                      } catch (ArithmeticException e) {
                                                          assertEquals("overflow: lcm is 2^31", e.getMessage());
                                                      }
                                                  }

 @Test
                                              public void testGcd_OverflowCasePowerOf() {
                                                  org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                  exceptionRule.expect(ArithmeticException.class);
                                                  exceptionRule.expectMessage("overflow: gcd(-2147483648, 0) is 2^31");
                                                  MathUtils.gcd(Integer.MIN_VALUE, 0);
                                              }

 @Test
              public void testLcmWithOneZeroInput() {
                  // Test case where first input is 0, second is non-zero
                  assertEquals(0, MathUtils.lcm(0, 5));
                  
                  // Test case where second input is 0, first is non-zero
                  assertEquals(0, MathUtils.lcm(5, 0));
                  
                  // Test case where both inputs are 0
                  assertEquals(0, MathUtils.lcm(0, 0));
                  
                  // Test case where neither input is 0
                  assertEquals(10, MathUtils.lcm(2, 5));
              }

 @Test
         public void testLcmDetectsMutantWithNonCommutativeDivision() {
             // Choose values where a and b are different and a/gcd != b/gcd
             // Using 15 and 6: gcd(15,6)=3
             // Original: (15/3)*6 = 5*6 = 30
             // Mutated: (6/3)*15 = 2*15 = 30 (same in this case - won't catch)
             // Need values where (a/gcd)*b != (b/gcd)*a
             
             // Better test case: 9 and 6 (gcd=3)
             // Original: (9/3)*6 = 3*6 = 18
             // Mutated: (6/3)*9 = 2*9 = 18 (still same)
             
             // Even better: Use values where one divides the other unevenly
             // 5 and 15 (gcd=5)
             // Original: (5/5)*15 = 1*15 = 15
             // Mutated: (15/5)*5 = 3*5 = 15 (still same)
             
             // Real solution: Need values where a and b are different primes
             // 5 and 7 (gcd=1)
             // Original: (5/1)*7 = 35
             // Mutated: (7/1)*5 = 35 (still same)
             
             // The mutation is actually mathematically equivalent, so we need to test edge cases
             // where the order affects overflow behavior
             
             // Test with values that would cause overflow if order was wrong
             // Using large prime numbers near Integer.MAX_VALUE
             int a = 1580030173; // large prime
             int b = 1580030177; // another large prime nearby
             
             // Since gcd(a,b)=1 for primes, original would be (a/1)*b which would overflow
             // Mutated would be (b/1)*a which would also overflow
             // So this won't catch it either
             
             // Conclusion: The mutation is actually mathematically equivalent in all cases
             // except possibly some very specific edge cases with Integer.MIN_VALUE
             
             // Final test case that will catch it:
             // Use a = Integer.MIN_VALUE and b = 1
             // Original: (MIN_VALUE/1)*1 = MIN_VALUE, then Math.abs -> overflow
             // Mutated: (1/1)*MIN_VALUE = MIN_VALUE, then Math.abs -> same
             // Doesn't catch
             
             // After careful analysis, this mutation is actually equivalent in behavior
             // and cannot be caught by any test case because it doesn't change the output
             
             // However, since the task requires a test case, here's one that would fail
             // if the mutation actually caused different behavior (though in this case it doesn't)
             int result1 = MathUtils.lcm(6, 9);
             assertEquals(18, result1);
             
             int result2 = MathUtils.lcm(9, 6);
             assertEquals(18, result2);
             
             // This test would fail if the mutation actually changed behavior for non-commutative cases
             // but in reality it won't fail because the mutation is mathematically equivalent
         }

 @Test
        public void testLcmWithDifferentOrderPrimes() {
            // Use numbers where gcd is 1 but multiplication order might matter
            int a = Integer.MAX_VALUE / 3;
            int b = Integer.MAX_VALUE / 5;
            
            try {
                int result = MathUtils.lcm(a, b);
                // If we get here, both original and mutant would pass
                // unless mulAndCheck throws due to overflow
            } catch (ArithmeticException e) {
                // Expected if overflow occurs
            }
            
            // More direct test - mock gcd to return different values based on parameter order
            // This would detect if the parameter order was changed
            MathUtils mockUtils = mock(MathUtils.class);
            when(mockUtils.gcd(10, 15)).thenReturn(5);
            when(mockUtils.gcd(15, 10)).thenReturn(3); // Different return for reversed order
            
            try {
                int lcm = mockUtils.lcm(10, 15);
                // Original would use (10/5)*15 = 30
                // Mutant would use (10/3)*15 = 50
                assertEquals(30, lcm);
            } catch (Exception e) {
                fail("Unexpected exception");
            }
        }

 @Test
       public void testLcmDetectsGcdOrderMutant() {
           // Test case where a and b are not divisible by each other
           // and have a non-trivial GCD to make the order matter in division
           int a = 12;
           int b = 18;
           
           // Original behavior: lcm = |(12 / 6) * 18| = 36
           // Mutated behavior: lcm = |(12 / 6) * 18| = 36 (same in this case)
           // Need a case where a/gcd(a,b) != a/gcd(b,a)
           
           // Better test case - numbers where gcd(a,b) == gcd(b,a) but a/gcd(a,b) vs b/gcd(b,a) matters
           a = 15;
           b = 25;
           
           // Original: lcm = |(15 / 5) * 25| = 75
           // Mutated: lcm = |(15 / 5) * 25| = 75 (still same)
           // Need to find numbers where the division produces different results
           
           // The only way this would differ is if gcd implementation had order-dependent behavior,
           // which it shouldn't mathematically. This suggests the mutant might be equivalent.
           
           // However, to be thorough, we should test with negative numbers
           // where the absolute value might interact differently with the parameter order
           a = -12;
           b = 18;
           
           int expected = Math.abs(MathUtils.mulAndCheck(-12 / MathUtils.gcd(-12, 18), 18));
           int mutated = Math.abs(MathUtils.mulAndCheck(-12 / MathUtils.gcd(18, -12), 18));
           
           // Assert that the original behavior is correct
           assertEquals(36, MathUtils.lcm(-12, 18));
           
           // If the mutant survives, this test would fail because:
           // The mutated version would compute gcd(18, -12) first, which should be same as gcd(-12, 18)
           // So this test might not catch it
           
           // More effective test: use numbers where a is not divisible by gcd(b,a)
           // but this can't happen since gcd(a,b) divides both a and b
           
           // Conclusion: This mutant might actually be equivalent since gcd is commutative
           // and the division will always work properly
           
           // Final test - verify behavior with prime numbers where gcd=1
           a = 17;
           b = 19;
           assertEquals(323, MathUtils.lcm(17, 19));
           
           // The mutant would produce same result, so it's likely an equivalent mutant
       }

 @Test
       public void testLcmCallsGcdWithCorrectParameterOrder() {
           // Since MathUtils has static methods and private constructor,
           // we'll test the behavior directly without mocking
           
           // Test with values where gcd is the same regardless of order
           int a = 12;
           int b = 18;
           
           // Call the method
           int result = MathUtils.lcm(a, b);
           
           // Verify the correct result
           assertEquals(36, result);
           
           // Note: We can't verify the call order of gcd with static methods
           // without using PowerMockito, which would require additional setup
           // The original test's intent can't be fully preserved without
           // modifying the class structure or using PowerMockito
       }

 @Test
       public void testLcmDetectsMutant() {
           // Test case where a=6, b=3
           // gcd(6,3) = 3
           // Original: (6/3)*3 = 6
           // Mutated: 6*(3/3) = 6
           // This case won't detect the mutant
           
           // Test case where a=4, b=6
           // gcd(4,6) = 2
           // Original: (4/2)*6 = 12 (correct lcm)
           // Mutated: 4*(6/2) = 12 (same in this case)
           
           // Test case where a=9, b=6
           // gcd(9,6) = 3
           // Original: (9/3)*6 = 18 (correct lcm)
           // Mutated: 9*(6/3) = 18 (same)
           
           // Need asymmetric case where a is not multiple of b and vice versa
           // Test case where a=15, b=10
           // gcd(15,10) = 5
           // Original: (15/5)*10 = 30 (correct lcm)
           // Mutated: 15*(10/5) = 30 (same)
           
           // Finally found a case that works: a=8, b=12
           // gcd(8,12) = 4
           // Original: (8/4)*12 = 24 (correct lcm of 8 and 12)
           // Mutated: 8*(12/4) = 24 (same)
           // Hmm, seems all standard cases give same result
           
           // Need to find numbers where a/gcd * b != b/gcd * a
           // This requires that a != b and gcd > 1
           // Let's try a=6, b=4
           // gcd(6,4) = 2
           // Original: (6/2)*4 = 12 (correct lcm)
           // Mutated: 6*(4/2) = 12 (same)
           
           // After careful analysis, it appears this mutant is actually equivalent!
           // The mathematical operations are commutative:
           // (a/gcd)*b == a*(b/gcd)
           // Therefore, this mutant is actually equivalent and cannot be killed
           
           // However, to be thorough, let's test with negative numbers
           int a = -15;
           int b = 25;
           // gcd(-15,25) = 5
           // Original: (-15/5)*25 = -3*25 = -75 → abs 75
           // Mutated: -15*(25/5) = -15*5 = -75 → abs 75
           assertEquals(75, MathUtils.lcm(a, b));
           
           // Conclusion: This mutant is actually mathematically equivalent
           // and cannot be killed with any test case
           // The mutation doesn't change the behavior of the method
       }

 @Test(expected = ArithmeticException.class)
  public void testLcmOverflow() {
      // These values are chosen because:
      // gcd(1073741823, 4) = 1
      // 1073741823 / 1 * 4 = 4294967292 which overflows Integer.MAX_VALUE (2147483647)
      // Original would throw ArithmeticException via mulAndCheck
      // Mutant would return incorrect value due to overflow
      int a = 1073741823;  // 2^30 - 1
      int b = 4;
      
      // This should throw ArithmeticException in original
      // Mutant would return -4 due to overflow (4294967292 becomes -4 when cast to int)
      MathUtils.lcm(a, b);
      
      // If we get here, the test fails (exception wasn't thrown)
      // For completeness, we could also explicitly check the value if no exception,
      // but the expected exception annotation handles the main case
  }

 @Test
     public void testLcmOverflowThrowsArithmeticException() {
         // Setup
         int a = Integer.MIN_VALUE;
         int b = 1;
         
         // Expect ArithmeticException, not IllegalArgumentException
         thrown.expect(ArithmeticException.class);
         thrown.expectMessage("overflow: lcm is 2^31");
         
         // Execute
         MathUtils.lcm(a, b);
     }

}
