package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                              public void testComputeShiftIncrement_Case() throws Exception {
                                                                                                                                                                                                  // Create instance with dummy data
                                                                                                                                                                                                  double[] main = new double[10];
                                                                                                                                                                                                  double[] secondary = new double[9];
                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to access private fields
                                                                                                                                                                                                  Class<?> clazz = eigenDecomposition.getClass();
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Set required fields
                                                                                                                                                                                                  Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                  dMinField.setDouble(eigenDecomposition, 5.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dNField = clazz.getDeclaredField("dN");
                                                                                                                                                                                                  dNField.setAccessible(true);
                                                                                                                                                                                                  dNField.setDouble(eigenDecomposition, 5.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                                                                                  dMin1Field.setAccessible(true);
                                                                                                                                                                                                  dMin1Field.setDouble(eigenDecomposition, 4.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                  dN1Field.setDouble(eigenDecomposition, 4.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                                                                                  dMin2Field.setAccessible(true);
                                                                                                                                                                                                  dMin2Field.setDouble(eigenDecomposition, 3.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                  pingPongField.setInt(eigenDecomposition, 1);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                  tTypeField.setInt(eigenDecomposition, 0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Initialize work array
                                                                                                                                                                                                  Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  int nn = 4 * 10 + 1 - 1; // end=10, pingPong=1
                                                                                                                                                                                                  double[] work = new double[nn];
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Setup work array for case 2
                                                                                                                                                                                                  work[nn - 3] = 4.0;
                                                                                                                                                                                                  work[nn - 5] = 9.0;
                                                                                                                                                                                                  work[nn - 7] = 16.0;
                                                                                                                                                                                                  work[nn - 9] = 25.0;
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                  Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                  computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                                  computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                  // Should fall into case 2 with gap1 > b1
                                                                                                                                                                                                  assertEquals(-2, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                  assertTrue((Double)tauField.get(eigenDecomposition) > 0.0);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testComputeShiftIncrement_Case1() throws Exception {
                                                                                                                                                                                                  // Create EigenDecompositionImpl instance with dummy parameters
                                                                                                                                                                                                  double[] main = new double[0];
                                                                                                                                                                                                  double[] secondary = new double[0];
                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to access private fields
                                                                                                                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                  dMinField.set(eigenDecomposition, 5.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                                                  dNField.setAccessible(true);
                                                                                                                                                                                                  dNField.set(eigenDecomposition, 5.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                                                                  dMin1Field.setAccessible(true);
                                                                                                                                                                                                  dMin1Field.set(eigenDecomposition, 4.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                  dN1Field.set(eigenDecomposition, 4.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                                  dMin2Field.setAccessible(true);
                                                                                                                                                                                                  dMin2Field.set(eigenDecomposition, 3.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 1);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                  tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Initialize work array
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  double[] work = new double[4 * 10 + 1 - 1];
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Setup work array to force gap1 <= b1
                                                                                                                                                                                                  int nn = 4 * 10 + 1 - 1;
                                                                                                                                                                                                  work[nn - 3] = 1.0;
                                                                                                                                                                                                  work[nn - 5] = 1.0;
                                                                                                                                                                                                  work[nn - 7] = 1.0;
                                                                                                                                                                                                  work[nn - 9] = 1.0;
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                  Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                  computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                                  computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                  assertEquals(-3, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                  assertTrue((Double)tauField.get(eigenDecomposition) > 0.0);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testComputeShiftIncrement_Case4_DMinEqualsDN() throws Exception {
                                                                                                                                                                                                  // Create eigen decomposition with dummy parameters
                                                                                                                                                                                                  double[] main = new double[0];
                                                                                                                                                                                                  double[] secondary = new double[0];
                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                  dMinField.set(eigenDecomposition, 5.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                                                  dNField.setAccessible(true);
                                                                                                                                                                                                  dNField.set(eigenDecomposition, 5.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                                                                  dMin1Field.setAccessible(true);
                                                                                                                                                                                                  dMin1Field.set(eigenDecomposition, 4.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                  dN1Field.set(eigenDecomposition, 3.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 1);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                  tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Setup work array
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  double[] work = new double[4 * 10 + 1];
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  int nn = 4 * 10 + 1 - 1;
                                                                                                                                                                                                  work[nn - 5] = 1.0;
                                                                                                                                                                                                  work[nn - 7] = 2.0; // nn-5 < nn-7 to avoid early return
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                  Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                  computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                                  computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                  assertEquals(-4, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                  double tau = tauField.getDouble(eigenDecomposition);
                                                                                                                                                                                                  assertTrue(tau > 0.0);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                          public void testComputeShiftIncrement_Case2() throws Exception {
                                                                                                                                                                                              // Initialize eigenDecomposition with dummy values
                                                                                                                                                                                              double[] main = new double[10];
                                                                                                                                                                                              double[] secondary = new double[9];
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                                                              Class<?> clazz = eigenDecomposition.getClass();
                                                                                                                                                                                              
                                                                                                                                                                                              // Set dMin1
                                                                                                                                                                                              Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                                                                              dMin1Field.setAccessible(true);
                                                                                                                                                                                              dMin1Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set dN1
                                                                                                                                                                                              Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                                                                                                              dN1Field.setAccessible(true);
                                                                                                                                                                                              dN1Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set dMin2
                                                                                                                                                                                              Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                                                                              dMin2Field.setAccessible(true);
                                                                                                                                                                                              dMin2Field.set(eigenDecomposition, 4.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set dN2
                                                                                                                                                                                              Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                              dN2Field.setAccessible(true);
                                                                                                                                                                                              dN2Field.set(eigenDecomposition, 3.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set pingPong
                                                                                                                                                                                              Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                                              pingPongField.set(eigenDecomposition, 1);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set tType
                                                                                                                                                                                              Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                              tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Execute
                                                                                                                                                                                              Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                              computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 1);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify tType
                                                                                                                                                                                              assertEquals(-9, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify tau
                                                                                                                                                                                              Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                              assertEquals(2.5, tauField.getDouble(eigenDecomposition), 0.0001);
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeShiftIncrement_Case3() throws Exception {
                                                                                                                                                                                              // Initialize eigenDecomposition with dummy values
                                                                                                                                                                                              double[] main = new double[0];
                                                                                                                                                                                              double[] secondary = new double[0];
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to access private fields
                                                                                                                                                                                              java.lang.reflect.Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                              dMin2Field.setAccessible(true);
                                                                                                                                                                                              dMin2Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                              
                                                                                                                                                                                              java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                              dN2Field.setAccessible(true);
                                                                                                                                                                                              dN2Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                              
                                                                                                                                                                                              java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                                              pingPongField.set(eigenDecomposition, 1);
                                                                                                                                                                                              
                                                                                                                                                                                              java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                              tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Setup work array
                                                                                                                                                                                              int nn = 4 * 10 + 1 - 1;
                                                                                                                                                                                              double[] work = new double[nn];
                                                                                                                                                                                              work[nn - 5] = 1.0;
                                                                                                                                                                                              work[nn - 7] = 3.0; // 2*1 < 3
                                                                                                                                                                                              work[nn - 9] = 2.0;
                                                                                                                                                                                              work[nn - 11] = 1.0;
                                                                                                                                                                                              
                                                                                                                                                                                              // Set work array via reflection
                                                                                                                                                                                              java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                              workField.set(eigenDecomposition, work);
                                                                                                                                                                                              
                                                                                                                                                                                              // Execute
                                                                                                                                                                                              java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                              method.setAccessible(true);
                                                                                                                                                                                              method.invoke(eigenDecomposition, 0, 10, 2);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify
                                                                                                                                                                                              assertEquals(-10, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                              
                                                                                                                                                                                              java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                              assertTrue((Double)tauField.get(eigenDecomposition) > 0.0);
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeShiftIncrement_Case4() throws Exception {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              double[] main = new double[11]; // size needs to be > end index (10)
                                                                                                                                                                                              double[] secondary = new double[10];
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                                              pingPongField.setInt(eigenDecomposition, 1);
                                                                                                                                                                                              
                                                                                                                                                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                              tTypeField.setInt(eigenDecomposition, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Execute
                                                                                                                                                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                              computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify
                                                                                                                                                                                              assertEquals(-12, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                              
                                                                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                              assertEquals(0.0, tauField.getDouble(eigenDecomposition), 0.0001);
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeGershgorinCircles_TypicalCase() {
                                                                                                                                                                                              // Setup test data
                                                                                                                                                                                              double[] main = {1.0, 2.0, 3.0};
                                                                                                                                                                                              double[] secondary = {0.5, 1.5};
                                                                                                                                                                                              double splitTolerance = 1.0e-10;
                                                                                                                                                                                              
                                                                                                                                                                                              // Create eigen decomposition instance
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = 
                                                                                                                                                                                                  new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                              
                                                                                                                                                                                              // Access private work array through reflection
                                                                                                                                                                                              double[] work;
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  throw new RuntimeException("Failed to access work array", e);
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Invoke the private method under test using reflection
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                                                  method.invoke(eigenDecomposition);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  throw new RuntimeException("Failed to invoke computeGershgorinCircles", e);
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify results
                                                                                                                                                                                              // For main = [1.0, 2.0, 3.0] and secondary = [0.5, 1.5]
                                                                                                                                                                                              // Expected lower bounds:
                                                                                                                                                                                              // 1st element: 1.0 - (0 + 0.5) = 0.5
                                                                                                                                                                                              // 2nd element: 2.0 - (0.5 + 1.5) = 0.0
                                                                                                                                                                                              // 3rd element: 3.0 - 1.5 = 1.5
                                                                                                                                                                                              // Expected upper bounds:
                                                                                                                                                                                              // 1st element: 1.0 + (0 + 0.5) = 1.5
                                                                                                                                                                                              // 2nd element: 2.0 + (0.5 + 1.5) = 4.0
                                                                                                                                                                                              // 3rd element: 3.0 + 1.5 = 4.5
                                                                                                                                                                                              
                                                                                                                                                                                              // Check work array contents
                                                                                                                                                                                              int m = main.length;
                                                                                                                                                                                              assertEquals(0.5, work[4*m + 0], 1e-10); // lower[0]
                                                                                                                                                                                              assertEquals(0.0, work[4*m + 1], 1e-10); // lower[1]
                                                                                                                                                                                              assertEquals(1.5, work[4*m + 2], 1e-10); // lower[2]
                                                                                                                                                                                              
                                                                                                                                                                                              assertEquals(1.5, work[5*m + 0], 1e-10); // upper[0]
                                                                                                                                                                                              assertEquals(4.0, work[5*m + 1], 1e-10); // upper[1]
                                                                                                                                                                                              assertEquals(4.5, work[5*m + 2], 1e-10); // upper[2]
                                                                                                                                                                                              
                                                                                                                                                                                              // Check spectra bounds using reflection
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                  lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                  double lowerSpectra = lowerSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                  assertEquals(0.0, lowerSpectra, 1e-10); // min of lower bounds
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                  upperSpectraField.setAccessible(true);
                                                                                                                                                                                                  double upperSpectra = upperSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                  assertEquals(4.5, upperSpectra, 1e-10); // max of upper bounds
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  throw new RuntimeException("Failed to access spectra fields", e);
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Check minPivot using reflection
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                  minPivotField.setAccessible(true);
                                                                                                                                                                                                  double minPivot = minPivotField.getDouble(eigenDecomposition);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // eMax is max of secondary elements (1.5)
                                                                                                                                                                                                  double expectedMinPivot = MathUtils.SAFE_MIN * Math.max(1.0, 1.5 * 1.5);
                                                                                                                                                                                                  assertEquals(expectedMinPivot, minPivot, 1e-10);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  throw new RuntimeException("Failed to access minPivot field", e);
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeGershgorinCircles_SingleElementMatrix() {
                                                                                                                                                                                              // Setup for 1x1 matrix
                                                                                                                                                                                              double[] main = new double[]{5.0};
                                                                                                                                                                                              double[] secondary = new double[0];
                                                                                                                                                                                              double[] work = new double[6 * main.length];
                                                                                                                                                                                              
                                                                                                                                                                                              // Create eigen decomposition instance with test data
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-10);
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  java.lang.reflect.Field mainField = EigenDecompositionImpl.class.getDeclaredField("main");
                                                                                                                                                                                                  mainField.setAccessible(true);
                                                                                                                                                                                                  mainField.set(eigenDecomposition, main);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field secondaryField = EigenDecompositionImpl.class.getDeclaredField("secondary");
                                                                                                                                                                                                  secondaryField.setAccessible(true);
                                                                                                                                                                                                  secondaryField.set(eigenDecomposition, secondary);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Get and invoke the private method
                                                                                                                                                                                                  java.lang.reflect.Method computeGershgorinCirclesMethod = 
                                                                                                                                                                                                      EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                  computeGershgorinCirclesMethod.setAccessible(true);
                                                                                                                                                                                                  computeGershgorinCirclesMethod.invoke(eigenDecomposition);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify results
                                                                                                                                                                                              // For single element matrix, radius is 0
                                                                                                                                                                                              assertEquals(5.0, work[4*1 + 0], 1e-10); // lower[0] = 5.0 - 0
                                                                                                                                                                                              assertEquals(5.0, work[5*1 + 0], 1e-10); // upper[0] = 5.0 + 0
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  java.lang.reflect.Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                  lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                  double lowerSpectra = (Double)lowerSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                  assertEquals(5.0, lowerSpectra, 1e-10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                  upperSpectraField.setAccessible(true);
                                                                                                                                                                                                  double upperSpectra = (Double)upperSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                  assertEquals(5.0, upperSpectra, 1e-10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // eMax is 0 (no secondary elements)
                                                                                                                                                                                                  java.lang.reflect.Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                  minPivotField.setAccessible(true);
                                                                                                                                                                                                  double minPivot = (Double)minPivotField.get(eigenDecomposition);
                                                                                                                                                                                                  double expectedMinPivot = MathUtils.SAFE_MIN * 1.0;
                                                                                                                                                                                                  assertEquals(expectedMinPivot, minPivot, 1e-10);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to verify results due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeGershgorinCircles_AllZeroMatrix() {
                                                                                                                                                                                              // Initialize test data
                                                                                                                                                                                              double[] main = new double[]{0.0, 0.0, 0.0};
                                                                                                                                                                                              double[] secondary = new double[]{0.0, 0.0};
                                                                                                                                                                                              double[] work = new double[6 * main.length];
                                                                                                                                                                                              
                                                                                                                                                                                              // Create eigen decomposition instance with test data
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-10);
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                                                  java.lang.reflect.Field mainField = EigenDecompositionImpl.class.getDeclaredField("main");
                                                                                                                                                                                                  mainField.setAccessible(true);
                                                                                                                                                                                                  mainField.set(eigenDecomposition, main);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field secondaryField = EigenDecompositionImpl.class.getDeclaredField("secondary");
                                                                                                                                                                                                  secondaryField.setAccessible(true);
                                                                                                                                                                                                  secondaryField.set(eigenDecomposition, secondary);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Invoke private method
                                                                                                                                                                                                  java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                                                  method.invoke(eigenDecomposition);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify results
                                                                                                                                                                                                  int m = main.length;
                                                                                                                                                                                                  assertEquals(0.0, work[4*m + 0], 1e-10); // lower[0]
                                                                                                                                                                                                  assertEquals(0.0, work[4*m + 1], 1e-10); // lower[1]
                                                                                                                                                                                                  assertEquals(0.0, work[4*m + 2], 1e-10); // lower[2]
                                                                                                                                                                                                  
                                                                                                                                                                                                  assertEquals(0.0, work[5*m + 0], 1e-10); // upper[0]
                                                                                                                                                                                                  assertEquals(0.0, work[5*m + 1], 1e-10); // upper[1]
                                                                                                                                                                                                  assertEquals(0.0, work[5*m + 2], 1e-10); // upper[2]
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Access private fields via reflection
                                                                                                                                                                                                  Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                  lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                  assertEquals(0.0, (Double)lowerSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                  upperSpectraField.setAccessible(true);
                                                                                                                                                                                                  assertEquals(0.0, (Double)upperSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // eMax is 0
                                                                                                                                                                                                  double expectedMinPivot = MathUtils.SAFE_MIN * 1.0;
                                                                                                                                                                                                  Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                  minPivotField.setAccessible(true);
                                                                                                                                                                                                  assertEquals(expectedMinPivot, (Double)minPivotField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeGershgorinCircles_NegativeValues() {
                                                                                                                                                                                              // Initialize test data
                                                                                                                                                                                              double[] main = new double[]{-1.0, -2.0, -3.0};
                                                                                                                                                                                              double[] secondary = new double[]{0.5, 1.5};
                                                                                                                                                                                              double[] work = new double[6 * main.length];
                                                                                                                                                                                              
                                                                                                                                                                                              // Create EigenDecompositionImpl instance with dummy values
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[3], new double[2], 1.0e-12);
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  java.lang.reflect.Field mainField = EigenDecompositionImpl.class.getDeclaredField("main");
                                                                                                                                                                                                  mainField.setAccessible(true);
                                                                                                                                                                                                  mainField.set(eigenDecomposition, main);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field secondaryField = EigenDecompositionImpl.class.getDeclaredField("secondary");
                                                                                                                                                                                                  secondaryField.setAccessible(true);
                                                                                                                                                                                                  secondaryField.set(eigenDecomposition, secondary);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to access and invoke the private method
                                                                                                                                                                                                  java.lang.reflect.Method computeGershgorinCirclesMethod = 
                                                                                                                                                                                                      EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                  computeGershgorinCirclesMethod.setAccessible(true);
                                                                                                                                                                                                  computeGershgorinCirclesMethod.invoke(eigenDecomposition);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify results
                                                                                                                                                                                              int m = main.length;
                                                                                                                                                                                              // Lower bounds:
                                                                                                                                                                                              // 1st: -1.0 - (0 + 0.5) = -1.5
                                                                                                                                                                                              // 2nd: -2.0 - (0.5 + 1.5) = -4.0
                                                                                                                                                                                              // 3rd: -3.0 - 1.5 = -4.5
                                                                                                                                                                                              assertEquals(-1.5, work[4*m + 0], 1e-10);
                                                                                                                                                                                              assertEquals(-4.0, work[4*m + 1], 1e-10);
                                                                                                                                                                                              assertEquals(-4.5, work[4*m + 2], 1e-10);
                                                                                                                                                                                              
                                                                                                                                                                                              // Upper bounds:
                                                                                                                                                                                              // 1st: -1.0 + (0 + 0.5) = -0.5
                                                                                                                                                                                              // 2nd: -2.0 + (0.5 + 1.5) = 0.0
                                                                                                                                                                                              // 3rd: -3.0 + 1.5 = -1.5
                                                                                                                                                                                              assertEquals(-0.5, work[5*m + 0], 1e-10);
                                                                                                                                                                                              assertEquals(0.0, work[5*m + 1], 1e-10);
                                                                                                                                                                                              assertEquals(-1.5, work[5*m + 2], 1e-10);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify spectra fields
                                                                                                                                                                                              try {
                                                                                                                                                                                                  java.lang.reflect.Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                  lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                  assertEquals(-4.5, (Double)lowerSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                  upperSpectraField.setAccessible(true);
                                                                                                                                                                                                  assertEquals(0.0, (Double)upperSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                  minPivotField.setAccessible(true);
                                                                                                                                                                                                  double expectedMinPivot = MathUtils.SAFE_MIN * Math.max(1.0, 1.5 * 1.5);
                                                                                                                                                                                                  assertEquals(expectedMinPivot, (Double)minPivotField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to verify results due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeGershgorinCircles_LargeValues() {
                                                                                                                                                                                              // Initialize test data
                                                                                                                                                                                              double[] main = new double[]{1e20, -1e20, 0.0};
                                                                                                                                                                                              double[] secondary = new double[]{1e10, 1e10};
                                                                                                                                                                                              double[] work = new double[6 * main.length];
                                                                                                                                                                                              
                                                                                                                                                                                              // Create eigen decomposition instance with dummy data
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(
                                                                                                                                                                                                  new double[main.length], new double[secondary.length], 1.0);
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  // Set private fields using reflection
                                                                                                                                                                                                  java.lang.reflect.Field mainField = EigenDecompositionImpl.class.getDeclaredField("main");
                                                                                                                                                                                                  mainField.setAccessible(true);
                                                                                                                                                                                                  mainField.set(eigenDecomposition, main);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field secondaryField = EigenDecompositionImpl.class.getDeclaredField("secondary");
                                                                                                                                                                                                  secondaryField.setAccessible(true);
                                                                                                                                                                                                  secondaryField.set(eigenDecomposition, secondary);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Invoke private method using reflection
                                                                                                                                                                                                  java.lang.reflect.Method computeGershgorinCircles = 
                                                                                                                                                                                                      EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                  computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                                  computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify results
                                                                                                                                                                                              int m = main.length;
                                                                                                                                                                                              // Lower bounds:
                                                                                                                                                                                              // 1st: 1e20 - (0 + 1e10) ≈ 1e20
                                                                                                                                                                                              // 2nd: -1e20 - (1e10 + 1e10) = -1e20 - 2e10
                                                                                                                                                                                              // 3rd: 0.0 - 1e10 = -1e10
                                                                                                                                                                                              assertEquals(1e20, work[4*m + 0], 1e5); // Using relative tolerance
                                                                                                                                                                                              assertEquals(-1e20 - 2e10, work[4*m + 1], 1e5);
                                                                                                                                                                                              assertEquals(-1e10, work[4*m + 2], 1e-10);
                                                                                                                                                                                              
                                                                                                                                                                                              // Upper bounds:
                                                                                                                                                                                              // 1st: 1e20 + (0 + 1e10) ≈ 1e20
                                                                                                                                                                                              // 2nd: -1e20 + (1e10 + 1e10) = -1e20 + 2e10
                                                                                                                                                                                              // 3rd: 0.0 + 1e10 = 1e10
                                                                                                                                                                                              assertEquals(1e20, work[5*m + 0], 1e5);
                                                                                                                                                                                              assertEquals(-1e20 + 2e10, work[5*m + 1], 1e5);
                                                                                                                                                                                              assertEquals(1e10, work[5*m + 2], 1e-10);
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  // Verify spectra fields
                                                                                                                                                                                                  java.lang.reflect.Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                  lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                  double lowerSpectra = lowerSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                  
                                                                                                                                                                                                  java.lang.reflect.Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                  upperSpectraField.setAccessible(true);
                                                                                                                                                                                                  double upperSpectra = upperSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                  
                                                                                                                                                                                                  assertEquals(-1e20 - 2e10, lowerSpectra, 1e5);
                                                                                                                                                                                                  assertEquals(1e20, upperSpectra, 1e5);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify minPivot
                                                                                                                                                                                                  java.lang.reflect.Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                  minPivotField.setAccessible(true);
                                                                                                                                                                                                  double minPivot = minPivotField.getDouble(eigenDecomposition);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // eMax is 1e10
                                                                                                                                                                                                  double expectedMinPivot = MathUtils.SAFE_MIN * Math.max(1.0, 1e10 * 1e10);
                                                                                                                                                                                                  assertEquals(expectedMinPivot, minPivot, 1e-10);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to verify results due to reflection error: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testProcessGeneralBlock_DiagonalMatrix() {
                                                                                                                                                                                              // Define test constants
                                                                                                                                                                                              final double TOLERANCE = 1e-10;
                                                                                                                                                                                              
                                                                                                                                                                                              // Setup diagonal matrix (all off-diagonal elements zero)
                                                                                                                                                                                              double[] main = {1.0, 1.0, 1.0, 1.0};
                                                                                                                                                                                              double[] secondary = {0.0, 0.0, 0.0};
                                                                                                                                                                                              double[] work = new double[4 * 4]; // Assuming 4x4 matrix
                                                                                                                                                                                              
                                                                                                                                                                                              // Initialize work array with diagonal values
                                                                                                                                                                                              for (int i = 0; i < 4; i++) {
                                                                                                                                                                                                  work[4 * i] = 1.0; // diagonal elements
                                                                                                                                                                                                  if (i < 3) {
                                                                                                                                                                                                      work[4 * i + 2] = 0.0; // off-diagonal elements
                                                                                                                                                                                                  }
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Create decomposition object
                                                                                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, TOLERANCE);
                                                                                                                                                                                              
                                                                                                                                                                                              // Store initial state
                                                                                                                                                                                              double[] initialWork = work.clone();
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to set the work array and invoke private method
                                                                                                                                                                                              try {
                                                                                                                                                                                                  // Set work array
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(decomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Get and invoke private processGeneralBlock method
                                                                                                                                                                                                  Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                  processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                  processGeneralBlockMethod.invoke(decomposition, 4);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to access private members via reflection: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify matrix wasn't modified (since it was already diagonal)
                                                                                                                                                                                              assertArrayEquals(initialWork, work, TOLERANCE);
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testProcessGeneralBlock_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                                              // Create decomposition instance with dummy parameters
                                                                                                                                                                                              double[] main = new double[4];
                                                                                                                                                                                              double[] secondary = new double[3];
                                                                                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                                              
                                                                                                                                                                                              // Get work array through reflection
                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                              double[] work = (double[]) workField.get(decomposition);
                                                                                                                                                                                              
                                                                                                                                                                                              // Setup non-diagonal matrix
                                                                                                                                                                                              work[2] = 0.5;  // e1
                                                                                                                                                                                              work[6] = 0.6;   // e2
                                                                                                                                                                                              work[10] = 0.7;  // e3
                                                                                                                                                                                              
                                                                                                                                                                                              // Get and invoke private processGeneralBlock method
                                                                                                                                                                                              Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                              processGeneralBlock.setAccessible(true);
                                                                                                                                                                                              processGeneralBlock.invoke(decomposition, 4);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify some expected state changes
                                                                                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                                                                              double dMin = dMinField.getDouble(decomposition);
                                                                                                                                                                                              
                                                                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                              double tau = tauField.getDouble(decomposition);
                                                                                                                                                                                              
                                                                                                                                                                                              assertTrue("dMin should be updated", dMin != 0);
                                                                                                                                                                                              assertTrue("tau should be updated", tau != 0);
                                                                                                                                                                                              // Additional assertions would depend on specific algorithm behavior
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testProcessGeneralBlock_MaxIterationsExceeded() {
                                                                                                                                                                                              // Setup test data
                                                                                                                                                                                              double[] main = new double[16]; // size should be sufficient for the test
                                                                                                                                                                                              double[] secondary = new double[15];
                                                                                                                                                                                              double splitTolerance = 1.0e-6;
                                                                                                                                                                                              
                                                                                                                                                                                              // Initialize work array (which is likely a field in the class)
                                                                                                                                                                                              double[] work = new double[4 * main.length]; // Assuming work array is 4 times main length
                                                                                                                                                                                              
                                                                                                                                                                                              // Setup a matrix that will require many iterations
                                                                                                                                                                                              for (int i = 0; i < work.length; i += 4) {
                                                                                                                                                                                                  work[i] = 1.0;   // diagonal
                                                                                                                                                                                                  if (i+2 < work.length) {
                                                                                                                                                                                                      work[i+2] = 0.9; // large off-diagonal
                                                                                                                                                                                                  }
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Create decomposition instance
                                                                                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to set the work array since it's likely private
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(decomposition, work);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  throw new RuntimeException("Failed to set work array via reflection", e);
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Setup exception expectation
                                                                                                                                                                                              ExpectedException expectedEx = ExpectedException.none();
                                                                                                                                                                                              expectedEx.expect(InvalidMatrixException.class);
                                                                                                                                                                                              expectedEx.expectMessage("MaxIterationsExceededException");
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to access the private method
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                  processGeneralBlock.setAccessible(true);
                                                                                                                                                                                                  processGeneralBlock.invoke(decomposition, 4);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  throw new RuntimeException("Failed to invoke processGeneralBlock via reflection", e);
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testProcessGeneralBlock_SmallMatrix() throws Exception {
                                                                                                                                                                                              // Test with 2x2 matrix
                                                                                                                                                                                              double[] main = {1.0, 2.0};
                                                                                                                                                                                              double[] secondary = {0.5, 0.0};
                                                                                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set up test data using reflection
                                                                                                                                                                                              double[] smallWork = {1.0, 0, 0.5, 0,   // first row
                                                                                                                                                                                                                   2.0, 0, 0, 0};    // second row
                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                              workField.set(decomposition, smallWork);
                                                                                                                                                                                              
                                                                                                                                                                                              // Call the method to test
                                                                                                                                                                                              Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                              processGeneralBlock.setAccessible(true);
                                                                                                                                                                                              processGeneralBlock.invoke(decomposition, 2);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify basic state
                                                                                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                                                                              assertTrue("dMin should be set", ((Double)dMinField.get(decomposition)) != 0);
                                                                                                                                                                                              
                                                                                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                                              assertEquals("pingPong should be toggled", 1, ((Integer)pingPongField.get(decomposition)).intValue());
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testProcessGeneralBlock_WithSplits() throws Exception {
                                                                                                                                                                                              // Setup test data
                                                                                                                                                                                              final double TOLERANCE_2 = 1.0e-15; // typical tolerance value for eigenvalue computations
                                                                                                                                                                                              
                                                                                                                                                                                              // Create decomposition object with dummy data
                                                                                                                                                                                              double[] main = new double[4];
                                                                                                                                                                                              double[] secondary = new double[3];
                                                                                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, TOLERANCE_2);
                                                                                                                                                                                              
                                                                                                                                                                                              // Access private work array via reflection
                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                              double[] work = (double[]) workField.get(decomposition);
                                                                                                                                                                                              
                                                                                                                                                                                              // Resize work array if needed (assuming it needs at least 16 elements for n=4)
                                                                                                                                                                                              if (work.length < 16) {
                                                                                                                                                                                                  work = new double[16];
                                                                                                                                                                                                  workField.set(decomposition, work);
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Setup matrix that will cause splits
                                                                                                                                                                                              work[0] = 1.0; work[2] = 0.1;
                                                                                                                                                                                              work[4] = 2.0; work[6] = TOLERANCE_2/2; // will cause split
                                                                                                                                                                                              work[8] = 3.0; work[10] = 0.2;
                                                                                                                                                                                              work[12] = 4.0;
                                                                                                                                                                                              
                                                                                                                                                                                              // Access private i0 field for assertion
                                                                                                                                                                                              Field i0Field = EigenDecompositionImpl.class.getDeclaredField("i0");
                                                                                                                                                                                              i0Field.setAccessible(true);
                                                                                                                                                                                              
                                                                                                                                                                                              // Access and invoke private processGeneralBlock method
                                                                                                                                                                                              Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                              processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                              processGeneralBlockMethod.invoke(decomposition, 4);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify splits were processed
                                                                                                                                                                                              int i0 = (int) i0Field.get(decomposition);
                                                                                                                                                                                              assertTrue("i0 should be updated", i0 > 0);
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testProcessGeneralBlock_EdgeCaseValues() {
                                                                                                                                                                                              // Initialize test data
                                                                                                                                                                                              double[] main = new double[4];
                                                                                                                                                                                              double[] secondary = new double[3];
                                                                                                                                                                                              double splitTolerance = 1.0e-6;
                                                                                                                                                                                              
                                                                                                                                                                                              // Create decomposition instance
                                                                                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                              
                                                                                                                                                                                              // Initialize work array (size needs to be at least 13 for the test)
                                                                                                                                                                                              double[] work = new double[16];
                                                                                                                                                                                              
                                                                                                                                                                                              // Test with very small/large values
                                                                                                                                                                                              work[0] = Double.MIN_VALUE; work[2] = Double.MIN_VALUE;
                                                                                                                                                                                              work[4] = Double.MAX_VALUE; work[6] = Double.MAX_VALUE/2;
                                                                                                                                                                                              work[8] = 1.0; work[10] = 1e-100;
                                                                                                                                                                                              work[12] = 1.0;
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to set private work array
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(decomposition, work);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to set work array via reflection: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to call private processGeneralBlock method
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Method method = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                                                  method.invoke(decomposition, 4);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to invoke processGeneralBlock via reflection: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify no exceptions and basic state using reflection
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                  double dMin = (Double) dMinField.get(decomposition);
                                                                                                                                                                                                  assertTrue("dMin should be set", !Double.isNaN(dMin));
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                  double tau = (Double) tauField.get(decomposition);
                                                                                                                                                                                                  assertTrue("tau should be set", !Double.isNaN(tau));
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to verify state via reflection: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testComputeShiftIncrement_NegativeDMin() throws Exception {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              double[] main = {1.0, 1.0, 1.0, 1.0};
                                                                                                                                                                                              double[] secondary = {0.0, 0.0, 0.0};
                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to access private fields
                                                                                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                                                                              dMinField.set(eigenDecomposition, -1.0);
                                                                                                                                                                                              
                                                                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                              tauField.set(eigenDecomposition, 0.0);
                                                                                                                                                                                              
                                                                                                                                                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                              tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Execute
                                                                                                                                                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                              computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify
                                                                                                                                                                                              assertEquals(1.0, ((Double)tauField.get(eigenDecomposition)).doubleValue(), 0.0001);
                                                                                                                                                                                              assertEquals(-1, ((Integer)tTypeField.get(eigenDecomposition)).intValue());
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                      public void testComputeShiftIncrement_Case5() throws Exception {
                                                                                                                                                                                          // Create instance with dummy parameters
                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = 
                                                                                                                                                                                              new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                          Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                                                          dMin1Field.setAccessible(true);
                                                                                                                                                                                          dMin1Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                          
                                                                                                                                                                                          Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                          dN1Field.setAccessible(true);
                                                                                                                                                                                          dN1Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                          
                                                                                                                                                                                          Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                          dMin2Field.setAccessible(true);
                                                                                                                                                                                          dMin2Field.set(eigenDecomposition, 4.0);
                                                                                                                                                                                          
                                                                                                                                                                                          Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                          dN2Field.setAccessible(true);
                                                                                                                                                                                          dN2Field.set(eigenDecomposition, 3.0);
                                                                                                                                                                                          
                                                                                                                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                                                                                          pingPongField.set(eigenDecomposition, 1);
                                                                                                                                                                                          
                                                                                                                                                                                          Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                          tTypeField.setAccessible(true);
                                                                                                                                                                                          tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                          
                                                                                                                                                                                          // Execute
                                                                                                                                                                                          Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                              "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                          computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                          computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 1);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify
                                                                                                                                                                                          assertEquals(-9, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                          
                                                                                                                                                                                          Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                          tauField.setAccessible(true);
                                                                                                                                                                                          assertEquals(2.5, tauField.getDouble(eigenDecomposition), 0.0001); // 0.5 * dMin1
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                      public void testComputeShiftIncrement_Case6() {
                                                                                                                                                                                          // Create eigen decomposition with dummy data
                                                                                                                                                                                          double[] main = new double[10];
                                                                                                                                                                                          double[] secondary = new double[9];
                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0);
                                                                                                                                                                                          
                                                                                                                                                                                          // Setup for case 10 (deflated=2, dMin2 == dN2 && 2*work[nn-5] < work[nn-7])
                                                                                                                                                                                          try {
                                                                                                                                                                                              Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                              dMin2Field.setAccessible(true);
                                                                                                                                                                                              dMin2Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                              
                                                                                                                                                                                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                              dN2Field.setAccessible(true);
                                                                                                                                                                                              dN2Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                              
                                                                                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                                              pingPongField.set(eigenDecomposition, 1);
                                                                                                                                                                                              
                                                                                                                                                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                              tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Setup work array
                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                              int nn = 4 * 10 + 1 - 1;
                                                                                                                                                                                              double[] work = new double[nn];
                                                                                                                                                                                              workField.set(eigenDecomposition, work);
                                                                                                                                                                                              
                                                                                                                                                                                              work[nn - 5] = 1.0;
                                                                                                                                                                                              work[nn - 7] = 3.0; // 2*1 < 3
                                                                                                                                                                                              work[nn - 9] = 2.0;
                                                                                                                                                                                              work[nn - 11] = 1.0;
                                                                                                                                                                                              
                                                                                                                                                                                              // Execute
                                                                                                                                                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                              computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 2);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify
                                                                                                                                                                                              assertEquals(-10, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                              
                                                                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                              assertTrue((Double)tauField.get(eigenDecomposition) > 0.0);
                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                              fail("Failed due to reflection error: " + e.getMessage());
                                                                                                                                                                                          }
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                      public void testComputeShiftIncrement_Case7() throws Exception {
                                                                                                                                                                                          // Setup for case 12 (deflated > 2)
                                                                                                                                                                                          double[] main = {1.0, 2.0, 3.0};
                                                                                                                                                                                          double[] secondary = {0.5, 1.5};
                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to access private fields
                                                                                                                                                                                          Class<?> clazz = eigenDecomposition.getClass();
                                                                                                                                                                                          Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                                                                                          pingPongField.setInt(eigenDecomposition, 1);
                                                                                                                                                                                          
                                                                                                                                                                                          Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                          tTypeField.setAccessible(true);
                                                                                                                                                                                          tTypeField.setInt(eigenDecomposition, 0);
                                                                                                                                                                                          
                                                                                                                                                                                          // Execute
                                                                                                                                                                                          Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                          computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                          computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify
                                                                                                                                                                                          assertEquals(-12, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                          
                                                                                                                                                                                          Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                          tauField.setAccessible(true);
                                                                                                                                                                                          assertEquals(0.0, tauField.getDouble(eigenDecomposition), 0.0001);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testComputeShiftIncrementCase5DetectsMutant() throws Exception {
                                                                                                                                                                                     // Setup test case for case 5 (dMin == dN2)
                                                                                                                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                                                     Class<?> clazz = eigen.getClass();
                                                                                                                                                                                     
                                                                                                                                                                                     // Set required field values to trigger case 5
                                                                                                                                                                                     Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                     dMinField.setAccessible(true);
                                                                                                                                                                                     dMinField.set(eigen, 4.0);
                                                                                                                                                                                     
                                                                                                                                                                                     Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                     dN2Field.setAccessible(true);
                                                                                                                                                                                     dN2Field.set(eigen, 4.0);  // dMin == dN2
                                                                                                                                                                                     
                                                                                                                                                                                     Field deflatedField = clazz.getDeclaredField("deflated");
                                                                                                                                                                                     deflatedField.setAccessible(true);
                                                                                                                                                                                     deflatedField.set(eigen, 0);
                                                                                                                                                                                     
                                                                                                                                                                                     Field endField = clazz.getDeclaredField("end");
                                                                                                                                                                                     endField.setAccessible(true);
                                                                                                                                                                                     endField.set(eigen, 10);
                                                                                                                                                                                     
                                                                                                                                                                                     Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                     pingPongField.setAccessible(true);
                                                                                                                                                                                     pingPongField.set(eigen, 1);
                                                                                                                                                                                     
                                                                                                                                                                                     Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                     tTypeField.setAccessible(true);
                                                                                                                                                                                     tTypeField.set(eigen, 0);
                                                                                                                                                                                     
                                                                                                                                                                                     // Setup work array values that will make the mutation visible
                                                                                                                                                                                     // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*10 + 1 - 1 - 2 = 38
                                                                                                                                                                                     // So we need to set work[30] (np-8), work[34] (np-4), work[36] (np-2), work[32] (np-6)
                                                                                                                                                                                     double[] work = new double[100];
                                                                                                                                                                                     work[30] = 2.0;  // work[np-8]
                                                                                                                                                                                     work[32] = 1.0;  // b2 = work[np-6]
                                                                                                                                                                                     work[34] = 0.5;  // work[np-4]
                                                                                                                                                                                     work[36] = 1.0;  // b1 = work[np-2]
                                                                                                                                                                                     
                                                                                                                                                                                     // Also need to set some other work values that are checked
                                                                                                                                                                                     work[37] = 1.0;  // work[nn-3] where nn = 4*10 + 1 - 1 = 40
                                                                                                                                                                                     work[35] = 1.0;  // work[nn-5]
                                                                                                                                                                                     work[33] = 1.0;  // work[nn-7]
                                                                                                                                                                                     work[31] = 1.0;  // work[nn-9]
                                                                                                                                                                                     work[29] = 1.0;  // work[nn-11]
                                                                                                                                                                                     work[27] = 1.0;  // work[nn-13]
                                                                                                                                                                                     work[25] = 1.0;  // work[nn-15]
                                                                                                                                                                                     
                                                                                                                                                                                     Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                     workField.setAccessible(true);
                                                                                                                                                                                     workField.set(eigen, work);
                                                                                                                                                                                     
                                                                                                                                                                                     // Calculate expected a2 value from original formula
                                                                                                                                                                                     double expectedA2 = (work[30] / work[32]) * (1 + work[34] / work[36]);
                                                                                                                                                                                     double expectedTau;
                                                                                                                                                                                     if (expectedA2 < 0.563) {  // cnst1
                                                                                                                                                                                         expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                                                                     } else {
                                                                                                                                                                                         expectedTau = 0.25 * 4.0;
                                                                                                                                                                                     }
                                                                                                                                                                                     
                                                                                                                                                                                     // Execute the method using reflection
                                                                                                                                                                                     Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                     computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                     computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify results using reflection
                                                                                                                                                                                     assertEquals(-5, tTypeField.getInt(eigen));  // Should be case 5
                                                                                                                                                                                     Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                     tauField.setAccessible(true);
                                                                                                                                                                                     assertEquals(expectedTau, tauField.getDouble(eigen), 1e-10);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                            public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant() throws Exception {
                                                                                                                                                                                // Setup test data to trigger case 5 (dMin == dN2)
                                                                                                                                                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                
                                                                                                                                                                                // Get field references via reflection
                                                                                                                                                                                Class<?> clazz = decomposition.getClass();
                                                                                                                                                                                Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                
                                                                                                                                                                                // Make fields accessible
                                                                                                                                                                                dMinField.setAccessible(true);
                                                                                                                                                                                dN2Field.setAccessible(true);
                                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                                tTypeField.setAccessible(true);
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                tauField.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Set fields needed for case 5
                                                                                                                                                                                dMinField.setDouble(decomposition, 4.0);
                                                                                                                                                                                dN2Field.setDouble(decomposition, 4.0);  // dMin == dN2 triggers case 5
                                                                                                                                                                                pingPongField.setInt(decomposition, 0);
                                                                                                                                                                                tTypeField.setInt(decomposition, 0);
                                                                                                                                                                                
                                                                                                                                                                                // Setup work array values that will make division vs multiplication produce different results
                                                                                                                                                                                // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*end - pingPong - 1
                                                                                                                                                                                // For end=3, pingPong=0: np = 11
                                                                                                                                                                                // So we need indices: np-8=3, np-6=5, np-4=7, np-2=9
                                                                                                                                                                                // Also need nn-13=-1 (won't be accessed due to end-start>3 check)
                                                                                                                                                                                double[] work = new double[20];
                                                                                                                                                                                work[3] = 2.0;  // work[np-8]
                                                                                                                                                                                work[5] = 4.0;  // b2
                                                                                                                                                                                work[7] = 3.0;  // work[np-4]
                                                                                                                                                                                work[9] = 6.0;  // b1
                                                                                                                                                                                workField.set(decomposition, work);
                                                                                                                                                                                
                                                                                                                                                                                // Calculate expected a2 value with original division
                                                                                                                                                                                double expectedB1 = work[9];
                                                                                                                                                                                double expectedB2 = work[5];
                                                                                                                                                                                double expectedA2 = (work[3] / expectedB2) * (1 + work[7] / expectedB1);
                                                                                                                                                                                
                                                                                                                                                                                // Calculate expected tau
                                                                                                                                                                                double expectedTau;
                                                                                                                                                                                if (expectedA2 < 0.563) {  // cnst1
                                                                                                                                                                                    expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);  // dN2 is 4.0
                                                                                                                                                                                } else {
                                                                                                                                                                                    expectedTau = 0.25 * 4.0;  // dMin is 4.0
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // Get and call private method via reflection
                                                                                                                                                                                Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                computeShiftIncrement.invoke(decomposition, 0, 3, 0);
                                                                                                                                                                                
                                                                                                                                                                                // Verify results
                                                                                                                                                                                assertEquals("Tau should match expected calculation", expectedTau, tauField.getDouble(decomposition), 1e-10);
                                                                                                                                                                                assertEquals("Type should be set to -5 for case 5", -5, tTypeField.getInt(decomposition));
                                                                                                                                                                            }

    @Test
                                                                                                                                                                        public void testComputeShiftIncrementCase5DetectsMutant1() {
                                                                                                                                                                            // Setup test data to reach case 5
                                                                                                                                                                            EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set private fields since we need specific conditions
                                                                                                                                                                            try {
                                                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                double[] work = new double[20];
                                                                                                                                                                                // Setup values that will make the multiplication and addition produce different results
                                                                                                                                                                                work[4] = 2.0;  // work[np-8] when np = 12 (nn=16, pingPong=2)
                                                                                                                                                                                work[8] = 3.0;  // work[np-4]
                                                                                                                                                                                workField.set(decomposition, work);
                                                                                                                                                                                
                                                                                                                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                dMinField.setAccessible(true);
                                                                                                                                                                                dMinField.set(decomposition, 1.0);
                                                                                                                                                                                
                                                                                                                                                                                Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                dN2Field.setAccessible(true);
                                                                                                                                                                                dN2Field.set(decomposition, 1.0);
                                                                                                                                                                                
                                                                                                                                                                                Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                endField.setAccessible(true);
                                                                                                                                                                                endField.set(decomposition, 4); // nn = 4*4 + 2 - 1 = 17, np = 17 - 2*2 = 13
                                                                                                                                                                                
                                                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                                pingPongField.set(decomposition, 2);
                                                                                                                                                                                
                                                                                                                                                                                // Call the method with deflated=0 to reach case 5
                                                                                                                                                                                Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                                                    int.class, int.class, int.class);
                                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                                method.invoke(decomposition, 0, 4, 0);
                                                                                                                                                                                
                                                                                                                                                                                // Get the calculated tau value
                                                                                                                                                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                tauField.setAccessible(true);
                                                                                                                                                                                double tau = tauField.getDouble(decomposition);
                                                                                                                                                                                
                                                                                                                                                                                // Calculate expected value with original formula
                                                                                                                                                                                double b1 = 1.0; // work[np-2] = work[11] which we didn't set, defaults to 0.0 but division protected
                                                                                                                                                                                double b2 = 1.0; // work[np-6] = work[7] which we didn't set, defaults to 0.0 but division protected
                                                                                                                                                                                double a2 = (2.0 / b2) * (1 + 3.0 / b1); // Original formula
                                                                                                                                                                                double expectedTau = a2 < 0.563 ? 1.0 * (1 - Math.sqrt(a2)) / (1 + a2) : 0.25 * 1.0;
                                                                                                                                                                                
                                                                                                                                                                                // Verify the calculation
                                                                                                                                                                                assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                                                                                                                                
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                       public void testComputeShiftIncrementCase5BoundaryCondition() {
                                                                                                                                                                           // Setup test data for case 5 (deflated=0, dMin=dN2)
                                                                                                                                                                           EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                           
                                                                                                                                                                           // Use reflection to set private fields since we need specific conditions
                                                                                                                                                                           try {
                                                                                                                                                                               Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                               dMinField.setAccessible(true);
                                                                                                                                                                               dMinField.set(decomposition, 1.0); // any positive value
                                                                                                                                                                               
                                                                                                                                                                               Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                               dN2Field.setAccessible(true);
                                                                                                                                                                               dN2Field.set(decomposition, 1.0); // same as dMin to trigger case 5
                                                                                                                                                                               
                                                                                                                                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                               workField.setAccessible(true);
                                                                                                                                                                               double[] work = new double[100]; // large enough array
                                                                                                                                                                               // Set values needed for case 5 calculations
                                                                                                                                                                               work[94] = 1.0; // work[nn-6] where nn=100 (4*end + pingPong -1)
                                                                                                                                                                               work[96] = 1.0; // work[nn-4]
                                                                                                                                                                               work[98] = 1.0; // work[nn-2]
                                                                                                                                                                               workField.set(decomposition, work);
                                                                                                                                                                               
                                                                                                                                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                               pingPongField.setAccessible(true);
                                                                                                                                                                               pingPongField.set(decomposition, 1); // set pingPong to 1
                                                                                                                                                                               
                                                                                                                                                                               // Test boundary condition where end - start = 3
                                                                                                                                                                               int start = 0;
                                                                                                                                                                               int end = 3;
                                                                                                                                                                               
                                                                                                                                                                               // Call the method
                                                                                                                                                                               Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                   "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                               computeShiftIncrement.setAccessible(true);
                                                                                                                                                                               computeShiftIncrement.invoke(decomposition, start, end, 0); // deflated=0
                                                                                                                                                                               
                                                                                                                                                                               // Verify results - in original code, the inner block shouldn't execute for end-start=3
                                                                                                                                                                               // but in mutated code it would
                                                                                                                                                                               Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                               tauField.setAccessible(true);
                                                                                                                                                                               double tau = tauField.getDouble(decomposition);
                                                                                                                                                                               
                                                                                                                                                                               // In original code, tau should be gam*(1-sqrt(a2))/(1+a2) or s (0.25*dMin)
                                                                                                                                                                               // Since we didn't set up complete conditions for a2 calculation,
                                                                                                                                                                               // we can verify it's one of these expected values
                                                                                                                                                                               assertTrue("Tau value is not as expected", 
                                                                                                                                                                                   tau == 0.25 * 1.0 || // s value
                                                                                                                                                                                   tau == 1.0 * (1 - Math.sqrt(0.0)) / (1 + 0.0)); // gam*(1-sqrt(a2))/(1+a2) when a2=0
                                                                                                                                                                               
                                                                                                                                                                               // Additional verification that the inner block didn't execute (original behavior)
                                                                                                                                                                               // We can check if the calculation matches the simple case (not the complex one)
                                                                                                                                                                               assertEquals("Tau should be 0.25*dMin when end-start=3", 0.25, tau, 1e-10);
                                                                                                                                                                               
                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                               fail("Exception during test: " + e.getMessage());
                                                                                                                                                                           }
                                                                                                                                                                       }

    @Test
                                                                                                                                                                     public void testComputeShiftIncrementCase5BoundaryCondition1() throws Exception {
                                                                                                                                                                         // Setup test case where end - start = 3 (boundary condition)
                                                                                                                                                                         int start = 0;
                                                                                                                                                                         int end = 3;
                                                                                                                                                                         int deflated = 0; // case 0 in switch
                                                                                                                                                                         int pingPong = 0;
                                                                                                                                                                         
                                                                                                                                                                         // Create instance
                                                                                                                                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                         
                                                                                                                                                                         // Use reflection to set private fields
                                                                                                                                                                         Class<?> clazz = eigen.getClass();
                                                                                                                                                                         
                                                                                                                                                                         // Set dMin = 1.0, dN2 = 1.0 (makes dMin == dN2), dMin2 = 2.0
                                                                                                                                                                         Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                         dMinField.setAccessible(true);
                                                                                                                                                                         dMinField.set(eigen, 1.0);
                                                                                                                                                                         
                                                                                                                                                                         Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                         dN2Field.setAccessible(true);
                                                                                                                                                                         dN2Field.set(eigen, 1.0);
                                                                                                                                                                         
                                                                                                                                                                         Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                                                         dMin2Field.setAccessible(true);
                                                                                                                                                                         dMin2Field.set(eigen, 2.0);
                                                                                                                                                                         
                                                                                                                                                                         Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                         pingPongField.setAccessible(true);
                                                                                                                                                                         pingPongField.set(eigen, pingPong);
                                                                                                                                                                         
                                                                                                                                                                         // Setup work array (size needs to be at least 4*end + pingPong - 1 = 11)
                                                                                                                                                                         double[] work = new double[12];
                                                                                                                                                                         // Set values that will pass the other conditions in case 5
                                                                                                                                                                         work[4] = 1.0;  // work[np-8] where np = nn-2*pingPong = 10
                                                                                                                                                                         work[8] = 1.0;  // work[np-4]
                                                                                                                                                                         work[6] = 2.0;  // work[np-6] (b2)
                                                                                                                                                                         work[10] = 2.0; // work[np-2] (b1)
                                                                                                                                                                         
                                                                                                                                                                         Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                         workField.setAccessible(true);
                                                                                                                                                                         workField.set(eigen, work);
                                                                                                                                                                         
                                                                                                                                                                         // Call the private method using reflection
                                                                                                                                                                         Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                                             int.class, int.class, int.class);
                                                                                                                                                                         computeShiftIncrement.setAccessible(true);
                                                                                                                                                                         computeShiftIncrement.invoke(eigen, start, end, deflated);
                                                                                                                                                                         
                                                                                                                                                                         // Verify the result using reflection
                                                                                                                                                                         Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                         tauField.setAccessible(true);
                                                                                                                                                                         double tau = (Double)tauField.get(eigen);
                                                                                                                                                                         assertEquals(0.25, tau, 1e-10);
                                                                                                                                                                         
                                                                                                                                                                         Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                         tTypeField.setAccessible(true);
                                                                                                                                                                         int tType = (Integer)tTypeField.get(eigen);
                                                                                                                                                                         assertEquals(-5, tType); // case 5
                                                                                                                                                                     }

    @Test
                                                                                                                                                                public void testComputeShiftIncrementCase5SmallRange() throws Exception {
                                                                                                                                                                    // Setup test data for case 5 (dMin == dN2) with small range (end-start <= 3)
                                                                                                                                                                    EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                                                    
                                                                                                                                                                    // Helper method to set private fields
                                                                                                                                                                    Class<?> clazz = decomposition.getClass();
                                                                                                                                                                    
                                                                                                                                                                    // Set required fields through reflection
                                                                                                                                                                    Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                    dMinField.setAccessible(true);
                                                                                                                                                                    dMinField.set(decomposition, 1.0);
                                                                                                                                                                    
                                                                                                                                                                    Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                    dN2Field.setAccessible(true);
                                                                                                                                                                    dN2Field.set(decomposition, 1.0);  // Triggers case 5
                                                                                                                                                                    
                                                                                                                                                                    Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                    pingPongField.setAccessible(true);
                                                                                                                                                                    pingPongField.set(decomposition, 0);
                                                                                                                                                                    
                                                                                                                                                                    Field endField = clazz.getDeclaredField("end");
                                                                                                                                                                    endField.setAccessible(true);
                                                                                                                                                                    endField.set(decomposition, 2);    // end index
                                                                                                                                                                    
                                                                                                                                                                    Field startField = clazz.getDeclaredField("start");
                                                                                                                                                                    startField.setAccessible(true);
                                                                                                                                                                    startField.set(decomposition, 0);  // start index (range = 2 <= 3)
                                                                                                                                                                    
                                                                                                                                                                    Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                    workField.setAccessible(true);
                                                                                                                                                                    workField.set(decomposition, new double[]{
                                                                                                                                                                        0.0, 0.0, 0.0, 0.0, 0.0,  // nn-13 to nn-9 (case 5 calculations)
                                                                                                                                                                        1.0, 2.0, 3.0, 4.0,        // nn-8 to nn-5
                                                                                                                                                                        5.0, 6.0, 7.0, 8.0, 9.0    // nn-4 to nn
                                                                                                                                                                    });
                                                                                                                                                                    
                                                                                                                                                                    // Call the private method using reflection
                                                                                                                                                                    Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                    computeShiftIncrement.setAccessible(true);
                                                                                                                                                                    computeShiftIncrement.invoke(decomposition, 0, 2, 0);
                                                                                                                                                                    
                                                                                                                                                                    // Get the results using reflection
                                                                                                                                                                    Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                    tauField.setAccessible(true);
                                                                                                                                                                    double tau = (Double)tauField.get(decomposition);
                                                                                                                                                                    
                                                                                                                                                                    Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                    tTypeField.setAccessible(true);
                                                                                                                                                                    int tType = (Integer)tTypeField.get(decomposition);
                                                                                                                                                                    
                                                                                                                                                                    // Verify results
                                                                                                                                                                    // Original code would skip inner calculations since range <=3, resulting in tau=0.25*dMin
                                                                                                                                                                    assertEquals(0.25, tau, 1e-10);  // 0.25 * dMin (1.0)
                                                                                                                                                                    assertEquals(-5, tType);
                                                                                                                                                                    
                                                                                                                                                                    // The mutant would execute the inner calculations anyway, producing different tau
                                                                                                                                                                    // This assertion would fail if the mutant is present
                                                                                                                                                                }

    @Test
                                                                                                                                                           public void testComputeShiftIncrementCase5DetectsDivisionMutant() throws Exception {
                                                                                                                                                               // Setup test case for case 5 (dMin == dN2)
                                                                                                                                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                               
                                                                                                                                                               // Helper method to set private fields
                                                                                                                                                               Class<?> clazz = eigen.getClass();
                                                                                                                                                               
                                                                                                                                                               // Set required fields through reflection
                                                                                                                                                               Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                               dMinField.setAccessible(true);
                                                                                                                                                               dMinField.set(eigen, 4.0);
                                                                                                                                                               
                                                                                                                                                               Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                               dN2Field.setAccessible(true);
                                                                                                                                                               dN2Field.set(eigen, 4.0);
                                                                                                                                                               
                                                                                                                                                               Field deflatedField = clazz.getDeclaredField("deflated");
                                                                                                                                                               deflatedField.setAccessible(true);
                                                                                                                                                               deflatedField.set(eigen, 2);
                                                                                                                                                               
                                                                                                                                                               Field endField = clazz.getDeclaredField("end");
                                                                                                                                                               endField.setAccessible(true);
                                                                                                                                                               endField.set(eigen, 5);  // nn = 4*5 + 0 -1 = 19
                                                                                                                                                               
                                                                                                                                                               Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                               pingPongField.setAccessible(true);
                                                                                                                                                               pingPongField.set(eigen, 0);
                                                                                                                                                               
                                                                                                                                                               Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                               tTypeField.setAccessible(true);
                                                                                                                                                               tTypeField.set(eigen, -5);
                                                                                                                                                               
                                                                                                                                                               // Create work array with specific values that will expose the mutation
                                                                                                                                                               // nn = 19, so nn-13=6 and nn-15=4
                                                                                                                                                               double[] work = new double[20];
                                                                                                                                                               work[6] = 2.0;  // work[nn-13]
                                                                                                                                                               work[4] = 4.0;  // work[nn-15]
                                                                                                                                                               // Original: b2 = 2.0/4.0 = 0.5
                                                                                                                                                               // Mutant: b2 = 2.0*4.0 = 8.0
                                                                                                                                                               
                                                                                                                                                               Field workField = clazz.getDeclaredField("work");
                                                                                                                                                               workField.setAccessible(true);
                                                                                                                                                               workField.set(eigen, work);
                                                                                                                                                               
                                                                                                                                                               // Call the private method using reflection
                                                                                                                                                               Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                               computeShiftIncrement.setAccessible(true);
                                                                                                                                                               computeShiftIncrement.invoke(eigen, 0, 5, 2);
                                                                                                                                                               
                                                                                                                                                               // Verify results
                                                                                                                                                               Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                               tauField.setAccessible(true);
                                                                                                                                                               double tau = (Double)tauField.get(eigen);
                                                                                                                                                               assertNotEquals("Tau should not match mutant value", 0.25 * 4.0, tau, 0.0001);
                                                                                                                                                               
                                                                                                                                                               // More precise verification would require full calculation, but this is sufficient
                                                                                                                                                               // to detect the division->multiplication mutation
                                                                                                                                                           }

    @Test
                                                                                                                                                      public void testComputeShiftIncrementCase5DetectsDivisionMutant1() throws Exception {
                                                                                                                                                          // Setup test to reach case 5 where dMin == dN2 and deflated == 0
                                                                                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                          
                                                                                                                                                          // Get field references via reflection
                                                                                                                                                          Class<?> clazz = eigen.getClass();
                                                                                                                                                          Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                          dMinField.setAccessible(true);
                                                                                                                                                          Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                          dN2Field.setAccessible(true);
                                                                                                                                                          Field deflatedField = clazz.getDeclaredField("deflated");
                                                                                                                                                          deflatedField.setAccessible(true);
                                                                                                                                                          Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                                                          Field endField = clazz.getDeclaredField("end");
                                                                                                                                                          endField.setAccessible(true);
                                                                                                                                                          Field workField = clazz.getDeclaredField("work");
                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                          Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                          tauField.setAccessible(true);
                                                                                                                                                          
                                                                                                                                                          // Set class variables to reach case 5
                                                                                                                                                          dMinField.setDouble(eigen, 4.0);
                                                                                                                                                          dN2Field.setDouble(eigen, 4.0);  // dMin == dN2
                                                                                                                                                          deflatedField.setInt(eigen, 0);
                                                                                                                                                          pingPongField.setInt(eigen, 0);
                                                                                                                                                          endField.setInt(eigen, 5);     // nn = 4*end + pingPong - 1 = 19
                                                                                                                                                          
                                                                                                                                                          // Initialize work array with values that will make division and subtraction different
                                                                                                                                                          double[] work = new double[20];
                                                                                                                                                          work[6] = 8.0;   // work[nn-13] = work[6]
                                                                                                                                                          work[4] = 2.0;    // work[nn-15] = work[4]
                                                                                                                                                          work[8] = 1.0;    // work[nn-8] = work[11] (must be <= b2)
                                                                                                                                                          work[4] = 1.0;    // work[np-4] = work[8] (must be <= b1)
                                                                                                                                                          
                                                                                                                                                          // Set other required work array values
                                                                                                                                                          work[11] = 1.0;   // work[nn-8]
                                                                                                                                                          work[9] = 1.0;    // work[nn-10]
                                                                                                                                                          work[7] = 1.0;    // work[nn-12]
                                                                                                                                                          work[5] = 1.0;    // work[nn-14]
                                                                                                                                                          work[3] = 1.0;    // work[nn-16]
                                                                                                                                                          work[1] = 1.0;    // work[nn-18]
                                                                                                                                                          
                                                                                                                                                          workField.set(eigen, work);
                                                                                                                                                          
                                                                                                                                                          // Get method reference via reflection
                                                                                                                                                          Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                          computeShiftIncrement.setAccessible(true);
                                                                                                                                                          
                                                                                                                                                          // Call the method
                                                                                                                                                          computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                                                                                          
                                                                                                                                                          // To make the test more sensitive, adjust values so the difference is more pronounced
                                                                                                                                                          work[6] = 6.0;
                                                                                                                                                          work[4] = 3.0;
                                                                                                                                                          workField.set(eigen, work);
                                                                                                                                                          computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                                                                                          
                                                                                                                                                          // Let's make end-start > 3 to go into the inner loop
                                                                                                                                                          work = new double[40];
                                                                                                                                                          endField.setInt(eigen, 8);  // nn = 4*8 + 0 - 1 = 31
                                                                                                                                                          work[18] = 8.0; // work[nn-13] = work[18]
                                                                                                                                                          work[16] = 2.0; // work[nn-15] = work[16]
                                                                                                                                                          work[23] = 1.0; // work[nn-8]
                                                                                                                                                          work[19] = 1.0; // work[nn-12]
                                                                                                                                                          work[15] = 1.0; // work[nn-16]
                                                                                                                                                          work[11] = 1.0; // work[nn-20]
                                                                                                                                                          work[7] = 1.0;  // work[nn-24]
                                                                                                                                                          work[3] = 1.0;  // work[nn-28]
                                                                                                                                                          workField.set(eigen, work);
                                                                                                                                                          
                                                                                                                                                          computeShiftIncrement.invoke(eigen, 0, 8, 0);
                                                                                                                                                          
                                                                                                                                                          // Verify tau is calculated correctly
                                                                                                                                                          assertEquals(1.0, tauField.getDouble(eigen), 1e-10);  // Expected tau value for original code
                                                                                                                                                      }

    @Test
                                                                                                                                                 public void testComputeShiftIncrementCase4DetectsA2Mutation() throws Exception {
                                                                                                                                                     // Setup test case for case 4 scenario
                                                                                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                     
                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                     Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                     dMinField.setAccessible(true);
                                                                                                                                                     dMinField.set(eigen, 1.0);
                                                                                                                                                     
                                                                                                                                                     Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                     dNField.setAccessible(true);
                                                                                                                                                     dNField.set(eigen, 1.0);  // dMin == dN
                                                                                                                                                     
                                                                                                                                                     Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                     dMin1Field.setAccessible(true);
                                                                                                                                                     dMin1Field.set(eigen, 2.0); // != dN1 to avoid case 2/3
                                                                                                                                                     
                                                                                                                                                     Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                     dN1Field.setAccessible(true);
                                                                                                                                                     dN1Field.set(eigen, 3.0);
                                                                                                                                                     
                                                                                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                     pingPongField.setAccessible(true);
                                                                                                                                                     pingPongField.set(eigen, 0);
                                                                                                                                                     
                                                                                                                                                     Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                     tTypeField.setAccessible(true);
                                                                                                                                                     tTypeField.set(eigen, 0);
                                                                                                                                                     
                                                                                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                     workField.setAccessible(true);
                                                                                                                                                     
                                                                                                                                                     // Setup work array to trigger the loop with non-zero b2 values
                                                                                                                                                     int pingPong = (Integer) pingPongField.get(eigen);
                                                                                                                                                     int nn = 4 * 10 + pingPong - 1; // end=10
                                                                                                                                                     double[] work = new double[nn + 1];
                                                                                                                                                     workField.set(eigen, work);
                                                                                                                                                     
                                                                                                                                                     // Values that will be used in calculations
                                                                                                                                                     work[nn - 3] = 4.0;  // sqrt(4)*sqrt(16) = 2*4=8
                                                                                                                                                     work[nn - 5] = 16.0;
                                                                                                                                                     work[nn - 7] = 9.0;  // sqrt(9)*sqrt(25) = 3*5=15
                                                                                                                                                     work[nn - 9] = 25.0;
                                                                                                                                                     
                                                                                                                                                     // Values for the loop
                                                                                                                                                     for (int i = 4 * 2 + 2; i <= nn - 9; i += 4) {
                                                                                                                                                         work[i] = 1.0;    // work[i4]
                                                                                                                                                         work[i - 2] = 2.0; // work[i4-2] (work[i4] < work[i4-2])
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     // Call the private method using reflection
                                                                                                                                                     Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                         "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                     computeShiftIncrement.setAccessible(true);
                                                                                                                                                     computeShiftIncrement.invoke(eigen, 2, 10, 0);
                                                                                                                                                     
                                                                                                                                                     // Verify results
                                                                                                                                                     assertEquals(-4, tTypeField.get(eigen));
                                                                                                                                                     
                                                                                                                                                     Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                     tauField.setAccessible(true);
                                                                                                                                                     double tau = (Double) tauField.get(eigen);
                                                                                                                                                     assertTrue("Tau should be positive", tau > 0);
                                                                                                                                                     
                                                                                                                                                     // More precise verification
                                                                                                                                                     double b1 = Math.sqrt(work[nn - 3]) * Math.sqrt(work[nn - 5]); // 8
                                                                                                                                                     double b2 = Math.sqrt(work[nn - 7]) * Math.sqrt(work[nn - 9]); // 15
                                                                                                                                                     double a2 = work[nn - 7] + work[nn - 5]; // 9 + 16 = 25
                                                                                                                                                     
                                                                                                                                                     // Simulate the loop accumulation (original version)
                                                                                                                                                     double simulatedA2 = a2 + b2; // initial accumulation
                                                                                                                                                     for (int i4 = nn - 9; i4 >= 4 * 2 + 2; i4 -= 4) {
                                                                                                                                                         b1 = b2;
                                                                                                                                                         b2 = b2 * (work[i4] / work[i4 - 2]); // b2 *= 0.5
                                                                                                                                                         simulatedA2 = simulatedA2 + b2;
                                                                                                                                                         if (100 * Math.max(b2, b1) < simulatedA2 || 0.563 < simulatedA2) {
                                                                                                                                                             break;
                                                                                                                                                         }
                                                                                                                                                     }
                                                                                                                                                     simulatedA2 = 1.05 * simulatedA2;
                                                                                                                                                     
                                                                                                                                                     double expectedTauValue;
                                                                                                                                                     if (simulatedA2 < 0.563) {
                                                                                                                                                         double dN = (Double) dNField.get(eigen);
                                                                                                                                                         expectedTauValue = dN * (1 - Math.sqrt(simulatedA2)) / (1 + simulatedA2);
                                                                                                                                                     } else {
                                                                                                                                                         double dMin = (Double) dMinField.get(eigen);
                                                                                                                                                         expectedTauValue = 0.25 * dMin;
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     assertEquals(expectedTauValue, tau, 1e-10);
                                                                                                                                                 }

    @Test
                                                                                                                                             public void testComputeShiftIncrementDetectsA2Mutation() {
                                                                                                                                                 // Setup test data to trigger case 4 where dMin == dN but dMin1 != dN1
                                                                                                                                                 EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                 
                                                                                                                                                 // Use reflection to set private fields since we need specific conditions
                                                                                                                                                 try {
                                                                                                                                                     Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                     dMinField.setAccessible(true);
                                                                                                                                                     dMinField.set(decomposition, 1.0);
                                                                                                                                                     
                                                                                                                                                     Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                     dNField.setAccessible(true);
                                                                                                                                                     dNField.set(decomposition, 1.0);
                                                                                                                                                     
                                                                                                                                                     Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                     dMin1Field.setAccessible(true);
                                                                                                                                                     dMin1Field.set(decomposition, 2.0); // Different from dN1 to trigger case 4
                                                                                                                                                     
                                                                                                                                                     Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                     dN1Field.setAccessible(true);
                                                                                                                                                     dN1Field.set(decomposition, 3.0);
                                                                                                                                                     
                                                                                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                     workField.setAccessible(true);
                                                                                                                                                     // Setup work array values that will make addition vs multiplication produce different results
                                                                                                                                                     double[] work = new double[100];
                                                                                                                                                     work[91] = 2.0; // nn-9 when pingPong=0, end=23
                                                                                                                                                     work[93] = 3.0; // nn-7
                                                                                                                                                     work[95] = 4.0; // nn-5
                                                                                                                                                     work[97] = 5.0; // nn-3
                                                                                                                                                     workField.set(decomposition, work);
                                                                                                                                                     
                                                                                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                     pingPongField.setAccessible(true);
                                                                                                                                                     pingPongField.set(decomposition, 0);
                                                                                                                                                     
                                                                                                                                                     Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                     endField.setAccessible(true);
                                                                                                                                                     endField.set(decomposition, 23);
                                                                                                                                                     
                                                                                                                                                     // Call the method with deflated=0 to trigger the path with the mutation
                                                                                                                                                     Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                         int.class, int.class, int.class);
                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                     method.invoke(decomposition, 0, 23, 0);
                                                                                                                                                     
                                                                                                                                                     // Verify the results
                                                                                                                                                     Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                     tauField.setAccessible(true);
                                                                                                                                                     double tau = tauField.getDouble(decomposition);
                                                                                                                                                     
                                                                                                                                                     // With original code (a2 = a2 + b2), tau should be approximately 0.563
                                                                                                                                                     // With mutated code (a2 = a2 * b2), tau would be different
                                                                                                                                                     assertEquals(0.563, tau, 0.001);
                                                                                                                                                     
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Failed to test due to reflection issues: " + e.getMessage());
                                                                                                                                                 }
                                                                                                                                             }

    @Test
                                                                                                                                           public void testComputeShiftIncrement_Case5_LoopDirection() throws Exception {
                                                                                                                                               // Setup test case that will trigger case 5 (dMin == dN2)
                                                                                                                                               EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                               
                                                                                                                                               // Set required fields through reflection
                                                                                                                                               Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                               dMinField.setAccessible(true);
                                                                                                                                               dMinField.set(decomposition, 1.0);
                                                                                                                                               
                                                                                                                                               Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                               dN2Field.setAccessible(true);
                                                                                                                                               dN2Field.set(decomposition, 1.0);  // dMin == dN2
                                                                                                                                               
                                                                                                                                               Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                                               deflatedField.setAccessible(true);
                                                                                                                                               deflatedField.set(decomposition, 0);
                                                                                                                                               
                                                                                                                                               Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                               endField.setAccessible(true);
                                                                                                                                               endField.set(decomposition, 10);    // Large enough to ensure loop executes
                                                                                                                                               
                                                                                                                                               Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                                               startField.setAccessible(true);
                                                                                                                                               startField.set(decomposition, 1);
                                                                                                                                               
                                                                                                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                               pingPongField.setAccessible(true);
                                                                                                                                               pingPongField.set(decomposition, 0);
                                                                                                                                               
                                                                                                                                               // Setup work array with values that will affect the calculation
                                                                                                                                               double[] work = new double[100];
                                                                                                                                               // Initialize work array elements that will be accessed
                                                                                                                                               work[4*10 - 2] = 1.0;    // work[np-2] where np = nn-2*pingPong
                                                                                                                                               work[4*10 - 6] = 1.0;     // work[np-6]
                                                                                                                                               work[4*10 - 8] = 0.5;     // work[np-8]
                                                                                                                                               work[4*10 - 4] = 0.5;     // work[np-4]
                                                                                                                                               work[4*10 - 13] = 0.5;    // work[nn-13]
                                                                                                                                               work[4*10 - 15] = 1.0;    // work[nn-15]
                                                                                                                                               // Initialize other required elements in the work array
                                                                                                                                               for (int i = 4*10 - 17; i >= 4*1 + 2; i -= 4) {
                                                                                                                                                   work[i] = 0.5;        // work[i4]
                                                                                                                                                   work[i-2] = 1.0;      // work[i4-2]
                                                                                                                                               }
                                                                                                                                               
                                                                                                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                               workField.setAccessible(true);
                                                                                                                                               workField.set(decomposition, work);
                                                                                                                                               
                                                                                                                                               // Call the private method using reflection
                                                                                                                                               Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                   "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                               computeShiftIncrement.setAccessible(true);
                                                                                                                                               computeShiftIncrement.invoke(decomposition, 1, 10, 0);
                                                                                                                                               
                                                                                                                                               // Verify the results
                                                                                                                                               Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                               tauField.setAccessible(true);
                                                                                                                                               double tau = (Double)tauField.get(decomposition);
                                                                                                                                               assertTrue("Tau should be calculated correctly", tau > 0);
                                                                                                                                               
                                                                                                                                               // The mutant would either:
                                                                                                                                               // 1. Not execute the loop at all (tau would be 0.25*dMin)
                                                                                                                                               // 2. Run infinitely (test would timeout)
                                                                                                                                               // 3. Calculate wrong tau value
                                                                                                                                               // So we verify tau is not the initial value (0.25*dMin)
                                                                                                                                               assertNotEquals("Tau should be modified by loop calculations", 
                                                                                                                                                              0.25 * 1.0, tau, 0.0001);
                                                                                                                                           }

    @Test
                                                                                                                                      public void testComputeShiftIncrementCase5DetectsLoopIncrementMutation() throws Exception {
                                                                                                                                          // Setup test case for case 5 (dMin == dN2)
                                                                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                          
                                                                                                                                          // Helper method to set private fields
                                                                                                                                          Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                          dMinField.setAccessible(true);
                                                                                                                                          dMinField.set(eigen, 5.0);
                                                                                                                                          
                                                                                                                                          Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                          dN2Field.setAccessible(true);
                                                                                                                                          dN2Field.set(eigen, 5.0);
                                                                                                                                          
                                                                                                                                          Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                          tTypeField.setAccessible(true);
                                                                                                                                          tTypeField.set(eigen, 0);
                                                                                                                                          
                                                                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                                          pingPongField.set(eigen, 0);
                                                                                                                                          
                                                                                                                                          Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                          endField.setAccessible(true);
                                                                                                                                          endField.set(eigen, 10);
                                                                                                                                          
                                                                                                                                          Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                                          startField.setAccessible(true);
                                                                                                                                          startField.set(eigen, 1);
                                                                                                                                          
                                                                                                                                          Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                                          deflatedField.setAccessible(true);
                                                                                                                                          deflatedField.set(eigen, 0);
                                                                                                                                          
                                                                                                                                          // Create work array with carefully constructed values
                                                                                                                                          // The values are set so processing every 4th vs 2nd element will produce different results
                                                                                                                                          double[] work = new double[100];
                                                                                                                                          int nn = 4 * 10 + 0 - 1; // nn = 39
                                                                                                                                          work[nn - 2] = 1.0;  // work[37]
                                                                                                                                          work[nn - 6] = 1.0;  // work[33]
                                                                                                                                          work[nn - 8] = 2.0;  // work[31]
                                                                                                                                          work[nn - 4] = 2.0;  // work[35]
                                                                                                                                          work[nn - 13] = 3.0; // work[26]
                                                                                                                                          work[nn - 15] = 1.0; // work[24]
                                                                                                                                          
                                                                                                                                          // Set values that will be different when processed every 2 vs 4 elements
                                                                                                                                          for (int i = 24; i >= 8; i -= 2) {
                                                                                                                                              work[i] = (i % 4 == 0) ? 1.0 : 2.0;
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                          workField.setAccessible(true);
                                                                                                                                          workField.set(eigen, work);
                                                                                                                                          
                                                                                                                                          // Execute the private method using reflection
                                                                                                                                          Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                              "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                          computeShiftIncrement.setAccessible(true);
                                                                                                                                          computeShiftIncrement.invoke(eigen, 1, 10, 0);
                                                                                                                                          
                                                                                                                                          // Verify results
                                                                                                                                          assertEquals(-5, tTypeField.getInt(eigen));
                                                                                                                                          Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                          tauField.setAccessible(true);
                                                                                                                                          assertEquals(1.25, tauField.getDouble(eigen), 1e-10);
                                                                                                                                      }

    @Test
                                                                                                                                 public void testComputeShiftIncrementCase5DetectsMutant2() throws Exception {
                                                                                                                                     // Setup
                                                                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                     
                                                                                                                                     // Use reflection to access private fields
                                                                                                                                     Class<?> clazz = eigen.getClass();
                                                                                                                                     Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                     dMinField.setAccessible(true);
                                                                                                                                     Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                     dMin2Field.setAccessible(true);
                                                                                                                                     Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                     dN2Field.setAccessible(true);
                                                                                                                                     Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                     pingPongField.setAccessible(true);
                                                                                                                                     Field workField = clazz.getDeclaredField("work");
                                                                                                                                     workField.setAccessible(true);
                                                                                                                                     Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                     tauField.setAccessible(true);
                                                                                                                                     Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                     tTypeField.setAccessible(true);
                                                                                                                                     
                                                                                                                                     // Set conditions for case 5 (tType = -5)
                                                                                                                                     dMinField.setDouble(eigen, 1.0);
                                                                                                                                     dMin2Field.setDouble(eigen, 1.0);
                                                                                                                                     dN2Field.setDouble(eigen, 1.0);
                                                                                                                                     pingPongField.setInt(eigen, 0);
                                                                                                                                     
                                                                                                                                     // Setup work array to trigger the loop with specific values
                                                                                                                                     // The array indices are based on nn = 4*end + pingPong - 1 = 19
                                                                                                                                     // So nn-13 = 6, nn-15 = 4, nn-17 = 2
                                                                                                                                     double[] work = new double[20];
                                                                                                                                     work[6] = 1.0;  // work[nn-13]
                                                                                                                                     work[4] = 2.0;  // work[nn-15]
                                                                                                                                     work[2] = 3.0;  // work[i4] in first iteration
                                                                                                                                     work[0] = 4.0;  // work[i4-2] in first iteration
                                                                                                                                     workField.set(eigen, work);
                                                                                                                                     
                                                                                                                                     // Call method via reflection
                                                                                                                                     Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                     computeShiftIncrement.setAccessible(true);
                                                                                                                                     computeShiftIncrement.invoke(eigen, 1, 5, 2);  // start=1, end=5, deflated=2
                                                                                                                                     
                                                                                                                                     // Verify results
                                                                                                                                     double tau = tauField.getDouble(eigen);
                                                                                                                                     int tType = tTypeField.getInt(eigen);
                                                                                                                                     double dMin = dMinField.getDouble(eigen);
                                                                                                                                     
                                                                                                                                     assertEquals(0.25 * dMin, tau, 1e-10);
                                                                                                                                     assertEquals(-5, tType);
                                                                                                                                 }

    @Test
                                                                                                                             public void testComputeShiftIncrementDetectsLoopBoundaryMutant() {
                                                                                                                                 // Setup test data to reach case 5 where the mutated loop exists
                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                 
                                                                                                                                 // Use reflection to set private fields since we need specific conditions
                                                                                                                                 try {
                                                                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                     workField.setAccessible(true);
                                                                                                                                     double[] work = new double[100]; // Large enough array
                                                                                                                                     // Setup work array values to trigger case 5 and make loop execute at boundary
                                                                                                                                     work[83] = 1.0;  // nn-17 (when nn=100)
                                                                                                                                     work[81] = 1.0;  // nn-15
                                                                                                                                     workField.set(eigen, work);
                                                                                                                                     
                                                                                                                                     Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                     dMinField.setAccessible(true);
                                                                                                                                     dMinField.set(eigen, 1.0);
                                                                                                                                     
                                                                                                                                     Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                     dN2Field.setAccessible(true);
                                                                                                                                     dN2Field.set(eigen, 1.0); // dMin == dN2
                                                                                                                                     
                                                                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                     pingPongField.setAccessible(true);
                                                                                                                                     pingPongField.set(eigen, 0); // Simple pingPong value
                                                                                                                                     
                                                                                                                                     Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                                     startField.setAccessible(true);
                                                                                                                                     startField.set(eigen, 20); // start = 20, so boundary is 4*20+2+0=82
                                                                                                                                     
                                                                                                                                     // Call the method with deflated=0 to reach case 5
                                                                                                                                     Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                         int.class, int.class, int.class);
                                                                                                                                     method.setAccessible(true);
                                                                                                                                     method.invoke(eigen, 20, 25, 0); // start=20, end=25, deflated=0
                                                                                                                                     
                                                                                                                                     // Get the tau value to verify
                                                                                                                                     Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                     tauField.setAccessible(true);
                                                                                                                                     double tau = tauField.getDouble(eigen);
                                                                                                                                     
                                                                                                                                     // In original code, the loop would execute one more time (when i4=82)
                                                                                                                                     // compared to mutated code, leading to different tau values
                                                                                                                                     // We can't predict exact value due to complexity, but we know it should be > 0
                                                                                                                                     assertTrue("Tau should be positive when loop executes boundary case", tau > 0);
                                                                                                                                     
                                                                                                                                 } catch (Exception e) {
                                                                                                                                     fail("Failed to test due to reflection issues: " + e.getMessage());
                                                                                                                                 }
                                                                                                                             }

    @Test
                                                                                                                            public void testComputeShiftIncrementCase5DetectsMutant3() {
                                                                                                                                // Setup test data to trigger case 5
                                                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                
                                                                                                                                // Use reflection to set private fields since we need to test a private method
                                                                                                                                try {
                                                                                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                    dMinField.setAccessible(true);
                                                                                                                                    dMinField.set(eigen, 10.0); // dMin = 10.0
                                                                                                                                    
                                                                                                                                    Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                    dN2Field.setAccessible(true);
                                                                                                                                    dN2Field.set(eigen, 10.0); // dN2 = 10.0 (so dMin == dN2)
                                                                                                                                    
                                                                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                    pingPongField.setAccessible(true);
                                                                                                                                    pingPongField.set(eigen, 0); // pingPong = 0
                                                                                                                                    
                                                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                    workField.setAccessible(true);
                                                                                                                                    // Setup work array values that will make the difference between + and - noticeable
                                                                                                                                    double[] work = new double[100];
                                                                                                                                    work[92] = 8.0;  // np-8 when nn=100 (4*25 + 0 - 1 = 99), np=99-2*0=99
                                                                                                                                    work[95] = 4.0;  // np-4
                                                                                                                                    work[93] = 4.0;  // np-6 (b2)
                                                                                                                                    work[97] = 2.0;  // np-2 (b1)
                                                                                                                                    workField.set(eigen, work);
                                                                                                                                    
                                                                                                                                    Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                    endField.setAccessible(true);
                                                                                                                                    endField.set(eigen, 25); // end = 25
                                                                                                                                    
                                                                                                                                    Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                                    startField.setAccessible(true);
                                                                                                                                    startField.set(eigen, 0); // start = 0
                                                                                                                                    
                                                                                                                                    // Call the method (case 5)
                                                                                                                                    Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                        int.class, int.class, int.class);
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    method.invoke(eigen, 0, 25, 0); // deflated = 0
                                                                                                                                    
                                                                                                                                    // Verify results
                                                                                                                                    Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                    tauField.setAccessible(true);
                                                                                                                                    double tau = (Double)tauField.get(eigen);
                                                                                                                                    
                                                                                                                                    // Calculate expected value with original formula
                                                                                                                                    double b1 = 2.0; // work[97]
                                                                                                                                    double b2 = 4.0; // work[93]
                                                                                                                                    double a2 = (8.0/4.0) * (1 + 4.0/2.0); // (work[92]/b2)*(1 + work[95]/b1)
                                                                                                                                    double expectedTau = a2 < 0.563 ? 10.0 * (1 - Math.sqrt(a2)) / (1 + a2) : 2.5; // 0.25*dMin
                                                                                                                                    
                                                                                                                                    assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                                                                                    
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Exception during test: " + e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                           public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant1() {
                                                                                                                               // Setup test data to reach case 5
                                                                                                                               EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0}, new double[]{1.0}, 1.0);
                                                                                                                               
                                                                                                                               // Use reflection to set private fields since we need to test a private method
                                                                                                                               try {
                                                                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                   workField.setAccessible(true);
                                                                                                                                   double[] work = new double[20];
                                                                                                                                   
                                                                                                                                   // Set values to trigger case 5 and make division vs multiplication produce different results
                                                                                                                                   work[12] = 2.0;  // np-8 (when nn=20, pingPong=0, np=nn-2*pingPong=20)
                                                                                                                                   work[16] = 4.0;  // np-4
                                                                                                                                   work[18] = 2.0;  // np-2 (b1)
                                                                                                                                   work[14] = 3.0;  // np-6 (b2)
                                                                                                                                   workField.set(decomposition, work);
                                                                                                                                   
                                                                                                                                   Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                   dMinField.setAccessible(true);
                                                                                                                                   dMinField.setDouble(decomposition, 1.0);
                                                                                                                                   
                                                                                                                                   Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                   dN2Field.setAccessible(true);
                                                                                                                                   dN2Field.setDouble(decomposition, 1.0);  // dMin == dN2
                                                                                                                                   
                                                                                                                                   Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                   endField.setAccessible(true);
                                                                                                                                   endField.setInt(decomposition, 5);  // end > start + 3
                                                                                                                                   
                                                                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                   pingPongField.setInt(decomposition, 0);
                                                                                                                                   
                                                                                                                                   // Calculate expected value with original division operation
                                                                                                                                   double b1 = 2.0;  // work[np-2]
                                                                                                                                   double b2 = 3.0;  // work[np-6]
                                                                                                                                   double expectedA2 = (2.0 / 3.0) * (1 + 4.0 / 2.0);  // original calculation
                                                                                                                                   expectedA2 = expectedA2 + (work[7] / work[5]);  // from the loop
                                                                                                                                   expectedA2 = 1.05 * expectedA2;  // cnst3 multiplication
                                                                                                                                   
                                                                                                                                   double expectedTau;
                                                                                                                                   if (expectedA2 < 0.563) {  // cnst1
                                                                                                                                       expectedTau = 1.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                   } else {
                                                                                                                                       expectedTau = 0.25 * 1.0;  // 0.25 * dMin
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // Invoke the method
                                                                                                                                   Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                       int.class, int.class, int.class);
                                                                                                                                   method.setAccessible(true);
                                                                                                                                   method.invoke(decomposition, 0, 5, 0);  // start=0, end=5, deflated=0
                                                                                                                                   
                                                                                                                                   // Verify results
                                                                                                                                   Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                   tauField.setAccessible(true);
                                                                                                                                   double actualTau = tauField.getDouble(decomposition);
                                                                                                                                   
                                                                                                                                   assertEquals("Tau value should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                                                                                   
                                                                                                                                   Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                   tTypeField.setAccessible(true);
                                                                                                                                   int tType = tTypeField.getInt(decomposition);
                                                                                                                                   assertEquals("tType should be -5 for case 5", -5, tType);
                                                                                                                                   
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                               }
                                                                                                                           }

    @Test
                                                                                                                          public void testComputeShiftIncrementCase5DetectsMutant4() {
                                                                                                                              // Setup test data to trigger case 5
                                                                                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                              
                                                                                                                              // Use reflection to set private fields since we need to test a private method
                                                                                                                              try {
                                                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                  dMinField.set(eigen, 4.0); // dMin = 4.0
                                                                                                                                  
                                                                                                                                  Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                  dN2Field.set(eigen, 4.0); // dN2 = 4.0 (so dMin == dN2)
                                                                                                                                  
                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                  workField.setAccessible(true);
                                                                                                                                  // Setup work array values that will make multiplication and addition produce different results
                                                                                                                                  double[] work = new double[20];
                                                                                                                                  work[12] = 2.0; // np-8 when nn=20, pingPong=0
                                                                                                                                  work[16] = 3.0; // np-4
                                                                                                                                  work[14] = 4.0; // b2 (np-6)
                                                                                                                                  work[18] = 5.0; // b1 (np-2)
                                                                                                                                  workField.set(eigen, work);
                                                                                                                                  
                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                  pingPongField.set(eigen, 0);
                                                                                                                                  
                                                                                                                                  // Get the method and make it accessible
                                                                                                                                  Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                  computeShiftIncrement.setAccessible(true);
                                                                                                                                  
                                                                                                                                  // Invoke the method (deflated=0 to trigger case 5)
                                                                                                                                  computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                                                                  
                                                                                                                                  // Get the tau value to verify
                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                  double tau = tauField.getDouble(eigen);
                                                                                                                                  
                                                                                                                                  // Calculate expected value based on original formula
                                                                                                                                  double b1 = 5.0; // work[18]
                                                                                                                                  double b2 = 4.0; // work[14]
                                                                                                                                  double a2 = (2.0/4.0) * (1 + 3.0/5.0); // original formula
                                                                                                                                  double expectedTau = 0.25 * 4.0; // s = 0.25 * dMin
                                                                                                                                  if (a2 < 0.563) { // cnst1
                                                                                                                                      expectedTau = 4.0 * (1 - Math.sqrt(a2)) / (1 + a2);
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Assert that tau matches expected value
                                                                                                                                  assertEquals("Tau value should match expected calculation", 
                                                                                                                                              expectedTau, tau, 1e-10);
                                                                                                                                  
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Exception during test: " + e.getMessage());
                                                                                                                              }
                                                                                                                          }

    @Test
                                                                                                                         public void testComputeShiftIncrementCase5BoundaryCondition2() {
                                                                                                                             // Setup test case where deflated=0 and dMin=dN2 (case 5)
                                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                             
                                                                                                                             // Use reflection to set private fields since we need specific conditions
                                                                                                                             try {
                                                                                                                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                 dMinField.set(eigen, 1.0); // Some positive value
                                                                                                                                 
                                                                                                                                 Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                 dN2Field.set(eigen, 1.0); // Same as dMin to trigger case 5
                                                                                                                                 
                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                 workField.setAccessible(true);
                                                                                                                                 double[] work = new double[100]; // Large enough array
                                                                                                                                 // Set values needed for case 5 calculations
                                                                                                                                 work[94] = 1.0; // work[np-8] (nn=100, pingPong=0, np=100-0=100)
                                                                                                                                 work[96] = 1.0; // work[np-6]
                                                                                                                                 work[97] = 1.0; // work[np-5]
                                                                                                                                 work[98] = 1.0; // work[np-4]
                                                                                                                                 work[99] = 1.0; // work[np-2]
                                                                                                                                 workField.set(eigen, work);
                                                                                                                                 
                                                                                                                                 // Test boundary condition where end - start = 3
                                                                                                                                 Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                     int.class, int.class, int.class);
                                                                                                                                 method.setAccessible(true);
                                                                                                                                 
                                                                                                                                 // Call with start=0, end=3 (so end-start=3)
                                                                                                                                 method.invoke(eigen, 0, 3, 0);
                                                                                                                                 
                                                                                                                                 // Verify the behavior - in original code, the inner loop wouldn't execute
                                                                                                                                 // In mutated code, it would execute and potentially change tau
                                                                                                                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                 double tau = tauField.getDouble(eigen);
                                                                                                                                 
                                                                                                                                 // The exact value depends on the implementation, but we can verify it's not the default
                                                                                                                                 // Case 5 sets tau to either gam*(1-sqrt(a2))/(1+a2) or 0.25*dMin
                                                                                                                                 // Since we set up conditions where a2 should be >= cnst1, it should be 0.25*dMin
                                                                                                                                 assertEquals(0.25, tau, 1e-10);
                                                                                                                                 
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Failed to test due to reflection issues: " + e.getMessage());
                                                                                                                             }
                                                                                                                         }

    @Test
                                                                                                                   public void testComputeShiftIncrementCase5WithEndStartDifference() throws Exception {
                                                                                                                       // Setup
                                                                                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                       
                                                                                                                       // Get field references via reflection
                                                                                                                       Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                       deflatedField.setAccessible(true);
                                                                                                                       Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                       dMinField.setAccessible(true);
                                                                                                                       Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                       dN2Field.setAccessible(true);
                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                       workField.setAccessible(true);
                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                       Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                       tauField.setAccessible(true);
                                                                                                                       Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                       tTypeField.setAccessible(true);
                                                                                                                       
                                                                                                                       // Set up case 5 conditions (deflated=0, dMin=dN2)
                                                                                                                       deflatedField.setInt(eigen, 0);
                                                                                                                       dMinField.setDouble(eigen, 1.0);
                                                                                                                       dN2Field.setDouble(eigen, 1.0);
                                                                                                                       
                                                                                                                       // Set end - start = 3 (4 elements)
                                                                                                                       int start = 0;
                                                                                                                       int end = 3;
                                                                                                                       
                                                                                                                       // Setup work array with required values
                                                                                                                       double[] work = new double[20]; // Large enough for nn-15 access
                                                                                                                       workField.set(eigen, work);
                                                                                                                       pingPongField.setInt(eigen, 0);
                                                                                                                       
                                                                                                                       // Set values that will be checked in the condition
                                                                                                                       int np = 4 * end + (Integer)pingPongField.get(eigen) - 1 - 2 * (Integer)pingPongField.get(eigen); // nn - 2*pingPong
                                                                                                                       work[np - 2] = 1.0; // b1
                                                                                                                       work[np - 6] = 1.0; // b2
                                                                                                                       work[np - 8] = 0.5; // must be <= b2
                                                                                                                       work[np - 4] = 0.5; // must be <= b1
                                                                                                                       
                                                                                                                       // Set values for the additional calculations when block is executed
                                                                                                                       work[np - 13] = 0.5;
                                                                                                                       work[np - 15] = 1.0;
                                                                                                                       
                                                                                                                       // Call method
                                                                                                                       Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                           "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                       computeShiftIncrement.setAccessible(true);
                                                                                                                       computeShiftIncrement.invoke(eigen, start, end, deflatedField.getInt(eigen));
                                                                                                                       
                                                                                                                       // Verify - with end-start=3, original should use simple calculation (s=0.25*dMin)
                                                                                                                       // If mutant is present, it would execute the additional block and get different tau
                                                                                                                       assertEquals(0.25 * ((Double)dMinField.get(eigen)).doubleValue(), ((Double)tauField.get(eigen)).doubleValue(), 1e-10);
                                                                                                                       
                                                                                                                       // Also verify tType is set correctly for case 5
                                                                                                                       assertEquals(-5, ((Integer)tTypeField.get(eigen)).intValue());
                                                                                                                   }

    @Test
                                                                                                               public void testComputeShiftIncrementDetectsEndStartConditionMutant() {
                                                                                                                   // Setup test case where deflated=0 and dMin=dN2 (case 5)
                                                                                                                   // and end-start <= 3 to expose the mutant
                                                                                                                   
                                                                                                                   // Create test instance - using constructor with main/secondary arrays
                                                                                                                   double[] main = {1.0, 2.0, 3.0, 4.0};
                                                                                                                   double[] secondary = {0.5, 1.5, 2.5};
                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 1.0e-10);
                                                                                                                   
                                                                                                                   // Set required field values through reflection since they're private
                                                                                                                   try {
                                                                                                                       // Set deflated=0 (case 0)
                                                                                                                       Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                       deflatedField.setAccessible(true);
                                                                                                                       deflatedField.setInt(eigen, 0);
                                                                                                                       
                                                                                                                       // Set dMin=dN2 (case 5)
                                                                                                                       Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                       dMinField.setAccessible(true);
                                                                                                                       dMinField.setDouble(eigen, 1.0);
                                                                                                                       
                                                                                                                       Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                       dN2Field.setAccessible(true);
                                                                                                                       dN2Field.setDouble(eigen, 1.0);
                                                                                                                       
                                                                                                                       // Set work array values that will be used in calculations
                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                       workField.setAccessible(true);
                                                                                                                       double[] work = new double[20];
                                                                                                                       // Setup values that would be used in case 5 calculations
                                                                                                                       work[6] = 2.0;  // work[np-6]
                                                                                                                       work[2] = 3.0;   // work[np-2]
                                                                                                                       work[8] = 1.0;   // work[np-8]
                                                                                                                       work[4] = 1.0;   // work[np-4]
                                                                                                                       workField.set(eigen, work);
                                                                                                                       
                                                                                                                       // Set pingPong
                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                       pingPongField.setInt(eigen, 0);
                                                                                                                       
                                                                                                                       // Set end and start values where end-start <= 3
                                                                                                                       Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                           "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                       computeShiftIncrement.setAccessible(true);
                                                                                                                       
                                                                                                                       // Call with start=0, end=3 (end-start=3)
                                                                                                                       computeShiftIncrement.invoke(eigen, 0, 3, 0);
                                                                                                                       
                                                                                                                       // Get tau value to verify
                                                                                                                       Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                       tauField.setAccessible(true);
                                                                                                                       double tau = tauField.getDouble(eigen);
                                                                                                                       
                                                                                                                       // In original code, with end-start=3, the inner loop wouldn't execute
                                                                                                                       // and a2 would just be (work[np-8]/b2)*(1 + work[np-4]/b1)
                                                                                                                       // In mutated code, the loop would execute and modify a2
                                                                                                                       // So we can verify tau isn't calculated with the loop results
                                                                                                                       double expectedA2 = (1.0/2.0) * (1 + 1.0/3.0); // (work[8]/work[6])*(1 + work[4]/work[2])
                                                                                                                       double expectedTau = 0.25 * 1.0; // s = 0.25 * dMin
                                                                                                                       if (expectedA2 < 0.563) { // cnst1
                                                                                                                           expectedTau = 1.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                       }
                                                                                                                       
                                                                                                                       assertEquals("Tau should be calculated without inner loop results", 
                                                                                                                           expectedTau, tau, 1.0e-10);
                                                                                                                       
                                                                                                                   } catch (Exception e) {
                                                                                                                       fail("Failed to test due to reflection: " + e.getMessage());
                                                                                                                   }
                                                                                                               }

    @Test
                                                                                                              public void testComputeShiftIncrementDetectsDivisionToMultiplicationMutant() {
                                                                                                                  // Setup test data to trigger case 5 (dMin == dN2 and deflated == 2)
                                                                                                                  EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                  
                                                                                                                  // Use reflection to set private fields since we need specific conditions
                                                                                                                  try {
                                                                                                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                      dMinField.setAccessible(true);
                                                                                                                      dMinField.set(decomposition, 1.0); // Any positive value
                                                                                                                      
                                                                                                                      Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                      dN2Field.setAccessible(true);
                                                                                                                      dN2Field.set(decomposition, 1.0); // dMin == dN2
                                                                                                                      
                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                      workField.setAccessible(true);
                                                                                                                      
                                                                                                                      // Create work array large enough for nn-15 index
                                                                                                                      // We'll set values that produce different results for division vs multiplication
                                                                                                                      double[] work = new double[100];
                                                                                                                      work[work.length - 13] = 4.0; // work[nn-13]
                                                                                                                      work[work.length - 15] = 2.0; // work[nn-15]
                                                                                                                      // Expected b2 = 4.0 / 2.0 = 2.0 (would be 8.0 with mutation)
                                                                                                                      workField.set(decomposition, work);
                                                                                                                      
                                                                                                                      Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                      endField.setAccessible(true);
                                                                                                                      endField.set(decomposition, 20); // Large enough to avoid array bounds
                                                                                                                      
                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                      pingPongField.set(decomposition, 0);
                                                                                                                      
                                                                                                                      // Call the method with deflated=2 to trigger case 5
                                                                                                                      Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                          "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                      computeShiftIncrement.setAccessible(true);
                                                                                                                      computeShiftIncrement.invoke(decomposition, 0, 20, 2);
                                                                                                                      
                                                                                                                      // Verify tau was calculated correctly
                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                      tauField.setAccessible(true);
                                                                                                                      double tau = tauField.getDouble(decomposition);
                                                                                                                      
                                                                                                                      // With original division, tau should be approximately 0.16666 (1/6)
                                                                                                                      // With mutated multiplication, it would be different
                                                                                                                      assertEquals(0.16666, tau, 0.0001);
                                                                                                                      
                                                                                                                  } catch (Exception e) {
                                                                                                                      fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                  }
                                                                                                              }

    @Test
                                                                                                             public void testComputeShiftIncrementDetectsDivisionToSubtractionMutant() {
                                                                                                                 // Setup test data to trigger case 5 (dMin == dN2)
                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                 
                                                                                                                 // Use reflection to set private fields since we need specific conditions
                                                                                                                 try {
                                                                                                                     Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                     dMinField.setAccessible(true);
                                                                                                                     dMinField.set(eigen, 4.0); // dMin value
                                                                                                                     
                                                                                                                     Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                     dN2Field.setAccessible(true);
                                                                                                                     dN2Field.set(eigen, 4.0); // dMin == dN2
                                                                                                                     
                                                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                     workField.setAccessible(true);
                                                                                                                     // Setup work array to make division and subtraction produce different results
                                                                                                                     // nn = 4*end + pingPong - 1 (we'll use end=5, pingPong=0 => nn=19)
                                                                                                                     // Need values at positions: 
                                                                                                                     // nn-13=6 (4.0), nn-15=4 (2.0) => 4/2=2 vs 4-2=2 (same, won't detect)
                                                                                                                     // So let's use values that produce different results: 6/3=2 vs 6-3=3
                                                                                                                     double[] work = new double[20];
                                                                                                                     work[6] = 6.0;  // nn-13
                                                                                                                     work[4] = 3.0;  // nn-15
                                                                                                                     // Also need to set other required positions:
                                                                                                                     work[19-5] = 1.0;  // nn-5
                                                                                                                     work[19-7] = 2.0;  // nn-7 (work[nn-5] < work[nn-7] condition)
                                                                                                                     work[19-8] = 1.0;  // nn-8
                                                                                                                     work[19-6] = 1.0;  // nn-6
                                                                                                                     work[19-4] = 1.0;  // nn-4
                                                                                                                     workField.set(eigen, work);
                                                                                                                     
                                                                                                                     Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                     endField.setAccessible(true);
                                                                                                                     endField.set(eigen, 5); // nn = 4*5 + 0 - 1 = 19
                                                                                                                     
                                                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                     pingPongField.setAccessible(true);
                                                                                                                     pingPongField.set(eigen, 0);
                                                                                                                     
                                                                                                                     Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                     startField.setAccessible(true);
                                                                                                                     startField.set(eigen, 0);
                                                                                                                     
                                                                                                                     // Call the method with deflated=0 to reach case 5
                                                                                                                     Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                         int.class, int.class, int.class);
                                                                                                                     method.setAccessible(true);
                                                                                                                     method.invoke(eigen, 0, 5, 0);
                                                                                                                     
                                                                                                                     // Verify tau value - should be based on division result
                                                                                                                     Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                     tauField.setAccessible(true);
                                                                                                                     double tau = tauField.getDouble(eigen);
                                                                                                                     
                                                                                                                     // Calculate expected value based on original division operation
                                                                                                                     // Original code path would do: b2 = 6.0/3.0 = 2.0
                                                                                                                     // Then a2 = (1.0/1.0)*(1 + 1.0/1.0) + 2.0 = 4.0
                                                                                                                     // Then a2 = 1.05 * 4.0 = 4.2
                                                                                                                     // Since 4.2 > 0.563, tau = 0.25 * dMin = 1.0
                                                                                                                     assertEquals(1.0, tau, 1e-10);
                                                                                                                     
                                                                                                                 } catch (Exception e) {
                                                                                                                     fail("Failed to test due to reflection: " + e.getMessage());
                                                                                                                 }
                                                                                                             }

    @Test
                                                                                                            public void testComputeShiftIncrementCase4DetectsAMinusBMutant() {
                                                                                                                // Setup test data to trigger case 4
                                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                
                                                                                                                // Use reflection to set private fields since we need specific conditions
                                                                                                                try {
                                                                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                    dMinField.setAccessible(true);
                                                                                                                    dMinField.set(eigen, 1.0);  // dMin == dN
                                                                                                                    
                                                                                                                    Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                    dNField.setAccessible(true);
                                                                                                                    dNField.set(eigen, 1.0);    // dMin == dN
                                                                                                                    
                                                                                                                    Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                    dMin1Field.setAccessible(true);
                                                                                                                    dMin1Field.set(eigen, 2.0); // dMin1 != dN1
                                                                                                                    
                                                                                                                    Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                    dN1Field.setAccessible(true);
                                                                                                                    dN1Field.set(eigen, 3.0);   // dMin1 != dN1
                                                                                                                    
                                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                    workField.setAccessible(true);
                                                                                                                    // Setup work array to trigger the loop with multiple iterations
                                                                                                                    // Values chosen so work[i4] < work[i4-2] and b2 != 0
                                                                                                                    double[] work = new double[100];
                                                                                                                    work[0] = 1.0;  // nn-7 (when nn=9)
                                                                                                                    work[2] = 0.5;  // nn-5
                                                                                                                    work[4] = 0.25; // nn-3
                                                                                                                    work[6] = 0.125; // nn-1
                                                                                                                    work[8] = 0.0625; // nn+1
                                                                                                                    workField.set(eigen, work);
                                                                                                                    
                                                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                    pingPongField.setAccessible(true);
                                                                                                                    pingPongField.set(eigen, 0);
                                                                                                                    
                                                                                                                    Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                    endField.setAccessible(true);
                                                                                                                    endField.set(eigen, 10); // Large enough to allow loop iterations
                                                                                                                    
                                                                                                                    // Call the method with deflated=0 to trigger case 4
                                                                                                                    Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                        "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                    computeShiftIncrement.setAccessible(true);
                                                                                                                    computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                    
                                                                                                                    // Verify tau was calculated correctly
                                                                                                                    Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                    tauField.setAccessible(true);
                                                                                                                    double tau = tauField.getDouble(eigen);
                                                                                                                    
                                                                                                                    // The expected value depends on the exact calculation, but with the mutation,
                                                                                                                    // tau would be much smaller than expected due to a2 being subtracted
                                                                                                                    assertTrue("Tau value should be greater than 0.1 with original code", 
                                                                                                                              tau > 0.1);
                                                                                                                    
                                                                                                                    // Also verify tType is set correctly
                                                                                                                    Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                    tTypeField.setAccessible(true);
                                                                                                                    int tType = tTypeField.getInt(eigen);
                                                                                                                    assertEquals("tType should be -4 for case 4", -4, tType);
                                                                                                                    
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                  public void testComputeShiftIncrementCase4DetectsAdditionMutation() throws Exception {
                                                                                                      // Setup test data to trigger case 4
                                                                                                      EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                                                                                                          new double[]{1.0, 1.0, 1.0, 1.0},  // main
                                                                                                          new double[]{0.5, 0.5, 0.5},        // secondary
                                                                                                          1.0e-10                             // splitTolerance
                                                                                                      );
                                                                                                      
                                                                                                      // Use reflection to set private fields
                                                                                                      Class<?> clazz = decomposition.getClass();
                                                                                                      
                                                                                                      // Helper code inlined where needed
                                                                                                      Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                      dMinField.setAccessible(true);
                                                                                                      dMinField.setDouble(decomposition, 1.0);
                                                                                                      
                                                                                                      Field dNField = clazz.getDeclaredField("dN");
                                                                                                      dNField.setAccessible(true);
                                                                                                      dNField.setDouble(decomposition, 1.0);
                                                                                                      
                                                                                                      Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                      dN1Field.setAccessible(true);
                                                                                                      dN1Field.setDouble(decomposition, 2.0);  // Different from dMin to avoid case 2/3
                                                                                                      
                                                                                                      Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                      dMin1Field.setAccessible(true);
                                                                                                      dMin1Field.setDouble(decomposition, 3.0);
                                                                                                      
                                                                                                      Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                      dMin2Field.setAccessible(true);
                                                                                                      dMin2Field.setDouble(decomposition, 4.0);
                                                                                                      
                                                                                                      Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                      dN2Field.setAccessible(true);
                                                                                                      dN2Field.setDouble(decomposition, 5.0);
                                                                                                      
                                                                                                      Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                      pingPongField.setAccessible(true);
                                                                                                      pingPongField.setInt(decomposition, 0);
                                                                                                      
                                                                                                      Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                      tTypeField.setAccessible(true);
                                                                                                      tTypeField.setInt(decomposition, 0);
                                                                                                      
                                                                                                      // Setup work array to control the calculations
                                                                                                      // nn = 4*end + pingPong - 1 = 4*4 + 0 - 1 = 15 (since end is 4 for length 4 main array)
                                                                                                      // We need work[nn-5] (work[10]) <= work[nn-7] (work[8]) to enter the branch
                                                                                                      double[] work = new double[16]; // index 0-15
                                                                                                      work[8] = 2.0;  // work[nn-7]
                                                                                                      work[10] = 1.0; // work[nn-5]
                                                                                                      work[9] = 1.0;  // work[nn-6]
                                                                                                      work[11] = 1.0; // work[nn-4]
                                                                                                      work[12] = 0.5; // work[nn-3] - will be used in loop
                                                                                                      
                                                                                                      // Set values for the loop iterations
                                                                                                      for (int i = 4; i < work.length; i += 4) {
                                                                                                          work[i] = 0.5;    // current
                                                                                                          work[i-2] = 1.0;  // previous (work[i] <= work[i-2] condition)
                                                                                                      }
                                                                                                      
                                                                                                      Field workField = clazz.getDeclaredField("work");
                                                                                                      workField.setAccessible(true);
                                                                                                      workField.set(decomposition, work);
                                                                                                      
                                                                                                      // Call the private method using reflection
                                                                                                      Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                      computeShiftIncrement.setAccessible(true);
                                                                                                      computeShiftIncrement.invoke(decomposition, 0, 4, 0);
                                                                                                      
                                                                                                      // Verify results using reflection
                                                                                                      assertEquals(-4, tTypeField.getInt(decomposition));
                                                                                                      
                                                                                                      Field tauField = clazz.getDeclaredField("tau");
                                                                                                      tauField.setAccessible(true);
                                                                                                      double tau = tauField.getDouble(decomposition);
                                                                                                      assertEquals(0.25 * 1.0 * (1 - Math.sqrt(1.05 * 2.0)) / (1 + 1.05 * 2.0), 
                                                                                                                  tau, 1.0e-10);
                                                                                                  }

    @Test
                                                                                             public void testComputeShiftIncrementCase5DetectsLoopIncrementMutant() throws Exception {
                                                                                                 // Setup test case for case 5 (dMin == dN2)
                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                 
                                                                                                 // Helper method to set private fields
                                                                                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                 dMinField.setAccessible(true);
                                                                                                 dMinField.set(eigen, 1.0);
                                                                                                 
                                                                                                 Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                 dN2Field.setAccessible(true);
                                                                                                 dN2Field.set(eigen, 1.0);  // Triggers case 5
                                                                                                 
                                                                                                 Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                 dMin2Field.setAccessible(true);
                                                                                                 dMin2Field.set(eigen, 2.0);
                                                                                                 
                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                 pingPongField.setAccessible(true);
                                                                                                 pingPongField.set(eigen, 0);
                                                                                                 
                                                                                                 Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                 endField.setAccessible(true);
                                                                                                 endField.set(eigen, 10);   // Large enough to make nn-17 valid
                                                                                                 
                                                                                                 Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                 startField.setAccessible(true);
                                                                                                 startField.set(eigen, 1);  // Small enough to make loop execute
                                                                                                 
                                                                                                 // Setup work array with values that will pass initial conditions
                                                                                                 double[] work = new double[100];
                                                                                                 work[80 - 8] = 1.0;  // work[np-8]
                                                                                                 work[80 - 6] = 2.0;  // work[np-6] (b2)
                                                                                                 work[80 - 4] = 1.0;  // work[np-4]
                                                                                                 work[80 - 2] = 2.0;  // work[np-2] (b1)
                                                                                                 work[80 - 13] = 1.0; // work[nn-13]
                                                                                                 work[80 - 15] = 2.0; // work[nn-15]
                                                                                                 
                                                                                                 // Fill in values that will allow loop to execute
                                                                                                 for (int i = 4; i < 80; i += 4) {
                                                                                                     work[i] = 1.0;
                                                                                                     work[i-2] = 2.0; // Ensure work[i4] > work[i4-2] is false
                                                                                                 }
                                                                                                 
                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                 workField.setAccessible(true);
                                                                                                 workField.set(eigen, work);
                                                                                                 
                                                                                                 // Get private method and make it accessible
                                                                                                 Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                     "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                 
                                                                                                 // Call the method - with mutant this would either:
                                                                                                 // 1. Return immediately (wrong tau)
                                                                                                 // 2. Infinite loop
                                                                                                 // 3. ArrayIndexOutOfBounds
                                                                                                 computeShiftIncrement.invoke(eigen, 1, 10, 0);
                                                                                                 
                                                                                                 // Verify results
                                                                                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                 tauField.setAccessible(true);
                                                                                                 double tau = (Double) tauField.get(eigen);
                                                                                                 
                                                                                                 Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                 tTypeField.setAccessible(true);
                                                                                                 int tType = (Integer) tTypeField.get(eigen);
                                                                                                 
                                                                                                 // Original code would have processed the loop and set tau accordingly
                                                                                                 // Mutant would either skip processing or throw exception
                                                                                                 assertEquals(-5, tType);
                                                                                                 assertTrue(tau > 0); // Exact value depends on calculations
                                                                                             }

    @Test
                                                                                    public void testComputeShiftIncrementCase5DetectsLoopIncrementMutant1() throws Exception {
                                                                                        // Setup test case for case 5 (dMin == dN2)
                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                        
                                                                                        // Set required fields through reflection since they're private
                                                                                        java.lang.reflect.Field dMinField = eigen.getClass().getDeclaredField("dMin");
                                                                                        dMinField.setAccessible(true);
                                                                                        dMinField.set(eigen, 1.0);
                                                                                        
                                                                                        java.lang.reflect.Field dN2Field = eigen.getClass().getDeclaredField("dN2");
                                                                                        dN2Field.setAccessible(true);
                                                                                        dN2Field.set(eigen, 1.0);
                                                                                        
                                                                                        java.lang.reflect.Field deflatedField = eigen.getClass().getDeclaredField("deflated");
                                                                                        deflatedField.setAccessible(true);
                                                                                        deflatedField.set(eigen, 2);
                                                                                        
                                                                                        java.lang.reflect.Field endField = eigen.getClass().getDeclaredField("end");
                                                                                        endField.setAccessible(true);
                                                                                        endField.set(eigen, 10);
                                                                                        
                                                                                        java.lang.reflect.Field startField = eigen.getClass().getDeclaredField("start");
                                                                                        startField.setAccessible(true);
                                                                                        startField.set(eigen, 1);
                                                                                        
                                                                                        java.lang.reflect.Field pingPongField = eigen.getClass().getDeclaredField("pingPong");
                                                                                        pingPongField.setAccessible(true);
                                                                                        pingPongField.set(eigen, 0);
                                                                                        
                                                                                        java.lang.reflect.Field tTypeField = eigen.getClass().getDeclaredField("tType");
                                                                                        tTypeField.setAccessible(true);
                                                                                        tTypeField.set(eigen, 0);
                                                                                        
                                                                                        // Create work array where processing every 2nd vs 4th element makes a difference
                                                                                        double[] work = new double[100];
                                                                                        int nn = 4 * 10 + 0 - 1; // nn = 39
                                                                                        work[nn - 2] = 1.0;  // work[37]
                                                                                        work[nn - 6] = 1.0;  // work[33]
                                                                                        work[nn - 8] = 2.0;  // work[31]
                                                                                        work[nn - 4] = 2.0;  // work[35]
                                                                                        work[nn - 13] = 3.0; // work[26]
                                                                                        work[nn - 15] = 1.0; // work[24]
                                                                                        
                                                                                        // Fill elements that would be processed differently
                                                                                        for (int i = 17; i >= 6; i -= 4) {
                                                                                            work[i] = i;
                                                                                            work[i-2] = i-2;
                                                                                        }
                                                                                        
                                                                                        java.lang.reflect.Field workField = eigen.getClass().getDeclaredField("work");
                                                                                        workField.setAccessible(true);
                                                                                        workField.set(eigen, work);
                                                                                        
                                                                                        // Call the private method via reflection
                                                                                        java.lang.reflect.Method method = eigen.getClass().getDeclaredMethod(
                                                                                            "computeShiftIncrement", int.class, int.class, int.class);
                                                                                        method.setAccessible(true);
                                                                                        method.invoke(eigen, 1, 10, 2);
                                                                                        
                                                                                        // Verify results - these values are specific to the original 4-step processing
                                                                                        java.lang.reflect.Field tauField = eigen.getClass().getDeclaredField("tau");
                                                                                        tauField.setAccessible(true);
                                                                                        double tau = (Double) tauField.get(eigen);
                                                                                        
                                                                                        java.lang.reflect.Field tTypeField2 = eigen.getClass().getDeclaredField("tType");
                                                                                        tTypeField2.setAccessible(true);
                                                                                        int tType = (Integer) tTypeField2.get(eigen);
                                                                                        
                                                                                        // The exact expected values would depend on the precise calculations,
                                                                                        // but we know the mutant would process different elements and produce different results
                                                                                        assertEquals(-5, tType);
                                                                                        assertEquals(0.25, tau, 1e-10); // Expected tau for this setup
                                                                                    }

    @Test
                                                                               public void testComputeShiftIncrementDetectsLoopConditionMutant() throws Exception {
                                                                                   // Setup test data for case 5 (tType = -5)
                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                   
                                                                                   // Use reflection to set private fields
                                                                                   Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                   dMinField.setAccessible(true);
                                                                                   dMinField.set(eigen, 1.0);
                                                                                   
                                                                                   Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                   dMin2Field.setAccessible(true);
                                                                                   dMin2Field.set(eigen, 1.0);
                                                                                   
                                                                                   Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                   dN2Field.setAccessible(true);
                                                                                   dN2Field.set(eigen, 1.0);
                                                                                   
                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                   pingPongField.setAccessible(true);
                                                                                   pingPongField.set(eigen, 0);
                                                                                   
                                                                                   Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                   tTypeField.setAccessible(true);
                                                                                   tTypeField.set(eigen, 0);
                                                                                   
                                                                                   // Setup work array to ensure the loop executes and values change
                                                                                   // nn = 4 * end + pingPong - 1 = 19
                                                                                   // Loop runs from nn-17=2 down to 4*start+2+pingPong=2 (original) or 0 (mutant)
                                                                                   double[] work = new double[20];
                                                                                   work[2] = 2.0;  // work[i4]
                                                                                   work[0] = 1.0;  // work[i4-2]
                                                                                   work[6] = 1.0;  // work[np-6]
                                                                                   work[2] = 1.0;  // work[np-2]
                                                                                   work[4] = 1.0;  // work[np-4]
                                                                                   work[8] = 1.0;  // work[np-8]
                                                                                   work[13] = 1.0; // work[nn-13]
                                                                                   work[15] = 1.0; // work[nn-15]
                                                                                   work[17] = 1.0; // work[nn-17]
                                                                                   
                                                                                   // Set values so the loop condition matters
                                                                                   for (int i = 0; i < work.length; i++) {
                                                                                       work[i] = 1.0 + i * 0.1;  // Varying values
                                                                                   }
                                                                                   
                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                   workField.setAccessible(true);
                                                                                   workField.set(eigen, work);
                                                                                   
                                                                                   // Call the private method using reflection
                                                                                   Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                       "computeShiftIncrement", int.class, int.class, int.class);
                                                                                   computeShiftIncrementMethod.setAccessible(true);
                                                                                   computeShiftIncrementMethod.invoke(eigen, 0, 5, 0);
                                                                                   
                                                                                   // Verify the results using reflection
                                                                                   assertEquals(-5, tTypeField.getInt(eigen));
                                                                                   
                                                                                   Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                   tauField.setAccessible(true);
                                                                                   double tau = tauField.getDouble(eigen);
                                                                                   assertTrue(tau >= 0.0);
                                                                                   assertTrue(tau <= 0.25 * dMinField.getDouble(eigen));  // tau should be <= s (0.25*dMin)
                                                                                   
                                                                                   // The key assertion - verify the loop boundary condition by checking
                                                                                   // if the last iteration was at the correct index
                                                                                   double expectedTau = 0.25 * dMinField.getDouble(eigen);  // Expected when work[0] isn't accessed
                                                                                   assertNotEquals(expectedTau, tau, 1e-10);
                                                                               }

    @Test
                                                                          public void testComputeShiftIncrementCase5BoundaryCondition3() throws Exception {
                                                                              // Setup test data to trigger case 5 with boundary condition
                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                              
                                                                              // Use reflection to set private fields
                                                                              Class<?> clazz = decomposition.getClass();
                                                                              
                                                                              // Set up case 5 conditions
                                                                              Field dMinField = clazz.getDeclaredField("dMin");
                                                                              dMinField.setAccessible(true);
                                                                              dMinField.set(decomposition, 1.0);
                                                                              
                                                                              Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                              dMin2Field.setAccessible(true);
                                                                              dMin2Field.set(decomposition, 1.0);
                                                                              
                                                                              Field dN2Field = clazz.getDeclaredField("dN2");
                                                                              dN2Field.setAccessible(true);
                                                                              dN2Field.set(decomposition, 1.0);
                                                                              
                                                                              Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                              pingPongField.setAccessible(true);
                                                                              pingPongField.set(decomposition, 0);
                                                                              
                                                                              Field endField = clazz.getDeclaredField("end");
                                                                              endField.setAccessible(true);
                                                                              endField.set(decomposition, 5);
                                                                              
                                                                              Field startField = clazz.getDeclaredField("start");
                                                                              startField.setAccessible(true);
                                                                              startField.set(decomposition, 1);
                                                                              
                                                                              // Setup work array to trigger the boundary condition case
                                                                              Field workField = clazz.getDeclaredField("work");
                                                                              workField.setAccessible(true);
                                                                              double[] work = new double[20];
                                                                              work[2] = 1.0;  // work[np-8] = work[2]
                                                                              work[6] = 1.0;  // work[np-4] = work[6]
                                                                              work[4] = 2.0;  // b2 = work[np-6] = work[4]
                                                                              work[8] = 2.0;  // b1 = work[np-2] = work[8]
                                                                              workField.set(decomposition, work);
                                                                              
                                                                              // Call the method via reflection
                                                                              Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                              computeShiftIncrement.setAccessible(true);
                                                                              computeShiftIncrement.invoke(decomposition, 1, 5, 0);
                                                                              
                                                                              // Verify results
                                                                              Field tTypeField = clazz.getDeclaredField("tType");
                                                                              tTypeField.setAccessible(true);
                                                                              assertEquals(-5, tTypeField.getInt(decomposition));
                                                                              
                                                                              Field tauField = clazz.getDeclaredField("tau");
                                                                              tauField.setAccessible(true);
                                                                              assertTrue((Double)tauField.get(decomposition) > 0);
                                                                          }

    @Test
                                                                      public void testComputeShiftIncrementCase5DetectsMutant5() {
                                                                          // Setup test data to trigger case 5 (dMin == dN2)
                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                          
                                                                          // Use reflection to set private fields since we need specific conditions
                                                                          try {
                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                              dMinField.setAccessible(true);
                                                                              dMinField.set(eigen, 10.0); // arbitrary value > 0
                                                                              
                                                                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                              dN2Field.setAccessible(true);
                                                                              dN2Field.set(eigen, 10.0); // dMin == dN2 to trigger case 5
                                                                              
                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                              workField.setAccessible(true);
                                                                              
                                                                              // Create work array with specific values that will show the mutation effect
                                                                              // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*end - pingPong - 1
                                                                              // For simplicity, set end=5, pingPong=0, so np=19
                                                                              // Need work[19-8]=work[11], work[19-4]=work[15], work[19-2]=work[17], work[19-6]=work[13]
                                                                              double[] work = new double[20];
                                                                              work[11] = 4.0;  // work[np-8]
                                                                              work[15] = 3.0;  // work[np-4]
                                                                              work[17] = 2.0;  // b1 = work[np-2]
                                                                              work[13] = 1.0;  // b2 = work[np-6]
                                                                              workField.set(eigen, work);
                                                                              
                                                                              Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                              endField.setAccessible(true);
                                                                              endField.set(eigen, 5);
                                                                              
                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                              pingPongField.setAccessible(true);
                                                                              pingPongField.set(eigen, 0);
                                                                              
                                                                              // Call the method - deflated=0 to reach case 5
                                                                              Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                  int.class, int.class, int.class);
                                                                              method.setAccessible(true);
                                                                              method.invoke(eigen, 0, 5, 0);
                                                                              
                                                                              // Verify results
                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                              tauField.setAccessible(true);
                                                                              double tau = tauField.getDouble(eigen);
                                                                              
                                                                              // Calculate expected value based on original formula
                                                                              double b1 = 2.0;  // work[17]
                                                                              double b2 = 1.0;  // work[13]
                                                                              double a2 = (work[11]/b2) * (1 + work[15]/b1);  // (4/1)*(1 + 3/2) = 4*2.5 = 10
                                                                              double expectedTau;
                                                                              if (a2 < 0.563) {  // cnst1
                                                                                  expectedTau = 10.0 * (1 - Math.sqrt(a2)) / (1 + a2);  // gam = dN2 = 10
                                                                              } else {
                                                                                  expectedTau = 0.25 * 10.0;  // s = 0.25 * dMin
                                                                              }
                                                                              
                                                                              // Assert the calculated tau matches expected value
                                                                              assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                              
                                                                          } catch (Exception e) {
                                                                              fail("Test failed due to reflection exception: " + e.getMessage());
                                                                          }
                                                                      }

    @Test
                                                                public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant2() throws Exception {
                                                                    // Setup test data to reach case 5 (dMin == dN2)
                                                                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                    
                                                                    // Use reflection to set private fields
                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                    dMinField.setAccessible(true);
                                                                    dMinField.set(eigen, 4.0);
                                                                    
                                                                    Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                    dN2Field.setAccessible(true);
                                                                    dN2Field.set(eigen, 4.0);
                                                                    
                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                    pingPongField.setAccessible(true);
                                                                    pingPongField.set(eigen, 1);
                                                                    
                                                                    Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                    tTypeField.setAccessible(true);
                                                                    tTypeField.set(eigen, 0);
                                                                    
                                                                    int deflated = 0;
                                                                    int end = 10;
                                                                    
                                                                    // Create work array with specific values that will make the division/multiplication difference obvious
                                                                    double[] work = new double[100];
                                                                    int np = 4 * end + (Integer)pingPongField.get(eigen) - 1 - 2 * (Integer)pingPongField.get(eigen);
                                                                    
                                                                    // Set values that will produce different results for division vs multiplication
                                                                    work[np - 2] = 2.0;  // b1
                                                                    work[np - 6] = 3.0;  // b2
                                                                    work[np - 4] = 1.0;  // work[np-4]
                                                                    work[np - 8] = 6.0;  // work[np-8]
                                                                    
                                                                    // Set other required work array values
                                                                    work[np - 13] = 1.0;
                                                                    work[np - 15] = 1.0;
                                                                    work[np - 17] = 1.0;
                                                                    
                                                                    // Set the work array
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    workField.set(eigen, work);
                                                                    
                                                                    // Call the method through reflection
                                                                    Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                        "computeShiftIncrement", int.class, int.class, int.class);
                                                                    computeShiftIncrement.setAccessible(true);
                                                                    computeShiftIncrement.invoke(eigen, 0, end, deflated);
                                                                    
                                                                    // Calculate expected a2 value with original division
                                                                    double expectedB1 = 2.0;
                                                                    double expectedB2 = 3.0;
                                                                    double expectedA2 = (6.0 / expectedB2) * (1 + 1.0 / expectedB1);
                                                                    
                                                                    // Verify the calculated tau matches expected behavior
                                                                    double expectedTau;
                                                                    final double cnst1 = 0.563;
                                                                    final double cnst3 = 1.05;
                                                                    
                                                                    if (expectedA2 < cnst1) {
                                                                        expectedTau = (Double)dN2Field.get(eigen) * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                    } else {
                                                                        expectedTau = 0.25 * (Double)dMinField.get(eigen);
                                                                    }
                                                                    
                                                                    // Get tau value through reflection
                                                                    Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                    tauField.setAccessible(true);
                                                                    double actualTau = (Double)tauField.get(eigen);
                                                                    
                                                                    assertEquals("Tau value should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                    assertEquals("Type should be set to -5 for case 5", -5, ((Number)tTypeField.get(eigen)).intValue());
                                                                }

    @Test
                                                            public void testComputeShiftIncrementCase5DetectsMultiplicationMutant() {
                                                                // Setup test data to reach case 5 (dMin == dN2)
                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                
                                                                // Use reflection to set private fields since they are not accessible directly
                                                                try {
                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                    dMinField.setAccessible(true);
                                                                    dMinField.set(eigen, 10.0); // dMin = 10.0
                                                                    
                                                                    Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                    dN2Field.setAccessible(true);
                                                                    dN2Field.set(eigen, 10.0); // dN2 = 10.0 (so dMin == dN2)
                                                                    
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    // Setup work array with specific values that will show difference between * and +
                                                                    // np = nn - 2 * pingPong (assuming pingPong=0, nn=20, so np=20)
                                                                    // We need to set work[12], work[16], work[18] (np-8, np-4, np-2)
                                                                    double[] work = new double[30];
                                                                    work[12] = 4.0;  // work[np-8]
                                                                    work[16] = 3.0;  // work[np-4]
                                                                    work[18] = 2.0;  // b1 = work[np-2]
                                                                    work[14] = 5.0;  // b2 = work[np-6]
                                                                    workField.set(eigen, work);
                                                                    
                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                    pingPongField.setAccessible(true);
                                                                    pingPongField.set(eigen, 0); // pingPong = 0
                                                                    
                                                                    Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                    endField.setAccessible(true);
                                                                    endField.set(eigen, 5); // end = 5 (so nn = 4*5 + 0 -1 = 19, np = 19 - 0 = 19)
                                                                    
                                                                    // Call the method with deflated=0 to reach case 5
                                                                    Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                        int.class, int.class, int.class);
                                                                    method.setAccessible(true);
                                                                    method.invoke(eigen, 0, 5, 0);
                                                                    
                                                                    // Verify the tau value
                                                                    Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                    tauField.setAccessible(true);
                                                                    double tau = tauField.getDouble(eigen);
                                                                    
                                                                    // Calculate expected value with original multiplication
                                                                    double b1 = 2.0;
                                                                    double b2 = 5.0;
                                                                    double a2 = (4.0 / 5.0) * (1 + 3.0 / 2.0);
                                                                    double expectedTau;
                                                                    if (a2 < 0.563) { // cnst1
                                                                        expectedTau = 10.0 * (1 - Math.sqrt(a2)) / (1 + a2);
                                                                    } else {
                                                                        expectedTau = 0.25 * 10.0;
                                                                    }
                                                                    
                                                                    assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                    
                                                                } catch (Exception e) {
                                                                    fail("Test failed due to reflection exception: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                          public void testComputeShiftIncrementCase5BoundaryCondition4() throws Exception {
                                                              // Setup test case where end - start == 3 to detect the mutant
                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                              
                                                              // Reflection helper methods
                                                              java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                              dMinField.setAccessible(true);
                                                              dMinField.set(eigen, 1.0);  // dMin > 0 to skip first condition
                                                              
                                                              java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                              dN2Field.setAccessible(true);
                                                              dN2Field.set(eigen, 1.0);   // dMin == dN2 to enter case 5
                                                              
                                                              java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                              deflatedField.setAccessible(true);
                                                              deflatedField.set(eigen, 0); // case 0 in switch
                                                              
                                                              java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                              pingPongField.setAccessible(true);
                                                              pingPongField.set(eigen, 0); // affects nn calculation
                                                              
                                                              java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                              workField.setAccessible(true);
                                                              workField.set(eigen, new double[100]); // large enough array
                                                              
                                                              // Initialize work array with values that won't trigger early returns
                                                              double[] work = (double[]) workField.get(eigen);
                                                              Arrays.fill(work, 1.0);
                                                              
                                                              // Set start and end such that end - start == 3
                                                              int start = 0;
                                                              int end = 3;
                                                              
                                                              // Call the private method using reflection
                                                              java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                  int.class, int.class, int.class);
                                                              method.setAccessible(true);
                                                              method.invoke(eigen, start, end, 0);
                                                              
                                                              // Get the results using reflection
                                                              java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                              tauField.setAccessible(true);
                                                              double tau = (double) tauField.get(eigen);
                                                              
                                                              java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                              tTypeField.setAccessible(true);
                                                              int tType = (int) tTypeField.get(eigen);
                                                              
                                                              // Verify tType is set correctly for case 5
                                                              assertEquals(-5, tType);
                                                              
                                                              // Verify tau is calculated without the block's contribution
                                                              assertEquals(0.25, tau, 1e-10);
                                                          }

    @Test
                                                     public void testComputeShiftIncrementDetectsEndStartBoundaryMutation() throws Exception {
                                                         // Setup test case where end-start = 3 (should not enter the if block in original)
                                                         EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                         
                                                         // Helper method to set private fields
                                                         Class<?> clazz = decomposition.getClass();
                                                         
                                                         // Set required fields through reflection
                                                         Field dMinField = clazz.getDeclaredField("dMin");
                                                         dMinField.setAccessible(true);
                                                         dMinField.set(decomposition, 1.0);
                                                         
                                                         Field dN2Field = clazz.getDeclaredField("dN2");
                                                         dN2Field.setAccessible(true);
                                                         dN2Field.set(decomposition, 1.0); // triggers case 5
                                                         
                                                         Field pingPongField = clazz.getDeclaredField("pingPong");
                                                         pingPongField.setAccessible(true);
                                                         pingPongField.set(decomposition, 0);
                                                         
                                                         Field workField = clazz.getDeclaredField("work");
                                                         workField.setAccessible(true);
                                                         double[] work = new double[20]; // large enough array
                                                         workField.set(decomposition, work);
                                                         
                                                         Field tTypeField = clazz.getDeclaredField("tType");
                                                         tTypeField.setAccessible(true);
                                                         tTypeField.set(decomposition, 0);
                                                         
                                                         // Set work array values to avoid early returns
                                                         work[14] = 1.0; // nn-6 (np-6)
                                                         work[10] = 1.0; // nn-10 (np-10)
                                                         
                                                         // Call the private method using reflection
                                                         Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                         computeShiftIncrement.setAccessible(true);
                                                         computeShiftIncrement.invoke(decomposition, 0, 3, 0);
                                                         
                                                         // Get the results using reflection
                                                         Field tauField = clazz.getDeclaredField("tau");
                                                         tauField.setAccessible(true);
                                                         double tau = (Double)tauField.get(decomposition);
                                                         
                                                         int tType = (Integer)tTypeField.get(decomposition);
                                                         
                                                         // In original code, the if block shouldn't execute, so tau should be 0.25*dMin
                                                         assertEquals(0.25, tau, 1e-10);
                                                         assertEquals(-5, tType);
                                                         
                                                         // If the mutant is present (end-start > 2), the if block would execute
                                                         // and tau would be calculated differently (likely smaller due to additional calculations)
                                                         // So this test would fail for the mutant
                                                     }

    @Test
                                                public void testComputeShiftIncrementCase5WithSmallRange() throws Exception {
                                                    // Setup test case where deflated=0, dMin=dN2, and end-start <= 3
                                                    EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                    
                                                    // Reflection helper methods
                                                    java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                    deflatedField.setAccessible(true);
                                                    deflatedField.set(decomposition, 0);
                                                    
                                                    java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                    dMinField.setAccessible(true);
                                                    dMinField.set(decomposition, 1.0);
                                                    
                                                    java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                    dN2Field.setAccessible(true);
                                                    dN2Field.set(decomposition, 1.0);
                                                    
                                                    java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                    tTypeField.setAccessible(true);
                                                    tTypeField.set(decomposition, 0);
                                                    
                                                    java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                    pingPongField.setAccessible(true);
                                                    pingPongField.set(decomposition, 0);
                                                    
                                                    // Create work array with required values for case 5
                                                    double[] work = new double[20];
                                                    work[12] = 1.0;  // np-8 (when nn=16)
                                                    work[14] = 1.0;  // np-6
                                                    work[10] = 1.0;  // np-4
                                                    work[8] = 1.0;   // np-2
                                                    
                                                    java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                    workField.setAccessible(true);
                                                    workField.set(decomposition, work);
                                                    
                                                    // Call private method via reflection
                                                    java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod(
                                                        "computeShiftIncrement", int.class, int.class, int.class);
                                                    method.setAccessible(true);
                                                    method.invoke(decomposition, 0, 3, 0);
                                                    
                                                    // Get results via reflection
                                                    double tau = (Double) tTypeField.get(decomposition);
                                                    int tType = (Integer) tTypeField.get(decomposition);
                                                    
                                                    // Verify tType is set correctly
                                                    assertEquals(-5, tType);
                                                    
                                                    // Verify tau is calculated without inner loop contribution
                                                    // Expected value is gam*(1-Math.sqrt(a2))/(1+a2) where a2 is initial calculation
                                                    double expectedTau = 0.25 * 1.0; // Since a2 will be >= cnst1 (1.0 >= 0.563)
                                                    assertEquals(expectedTau, tau, 1e-10);
                                                }

    @Test
                                           public void testComputeShiftIncrementCase5DetectsDivisionMutant2() throws Exception {
                                               // Setup test data to reach case 5
                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                               
                                               // Use reflection to set private fields
                                               Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                               dMinField.setAccessible(true);
                                               dMinField.set(eigen, 4.0);
                                               
                                               Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                               dN2Field.setAccessible(true);
                                               dN2Field.set(eigen, 4.0);  // dMin == dN2
                                               
                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                               pingPongField.setAccessible(true);
                                               pingPongField.set(eigen, 1);
                                               
                                               int end = 10;  // nn = 4*10 + 1 - 1 = 40
                                               
                                               // Setup work array with specific values that will show the mutation
                                               double[] work = new double[40];
                                               work[25] = 2.0;  // work[nn-15]
                                               work[27] = 3.0;  // work[nn-13]
                                               work[28] = 1.0;  // work[np-8] must be <= b2 (work[np-6] = work[28])
                                               work[24] = 1.0;  // work[np-4] must be <= b1 (work[np-2] = work[26])
                                               
                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                               workField.setAccessible(true);
                                               workField.set(eigen, work);
                                               
                                               // Call the private method using reflection
                                               Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                   "computeShiftIncrement", int.class, int.class, int.class);
                                               computeShiftIncrement.setAccessible(true);
                                               computeShiftIncrement.invoke(eigen, 0, end, 0);
                                               
                                               // Verify results - calculate expected value with division
                                               double expectedB2 = 3.0 / 2.0;  // original uses division
                                               double expectedA2 = (1.0/1.0) * (1 + 1.0/1.0) + expectedB2;  // simplified case
                                               expectedA2 = 1.05 * expectedA2;  // cnst3 multiplication
                                               double expectedTau;
                                               if (expectedA2 < 0.563) {  // cnst1
                                                   expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                               } else {
                                                   expectedTau = 0.25 * 4.0;
                                               }
                                               
                                               // Get tau field value using reflection
                                               Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                               tauField.setAccessible(true);
                                               double actualTau = (Double)tauField.get(eigen);
                                               
                                               // Assert the calculated tau matches expected
                                               assertEquals("Tau should match expected calculation with division", 
                                                           expectedTau, actualTau, 1e-10);
                                               
                                               // Also verify tType is set correctly for case 5
                                               Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                               tTypeField.setAccessible(true);
                                               int actualTType = (Integer)tTypeField.get(eigen);
                                               assertEquals("tType should be -5 for case 5", -5, actualTType);
                                           }

    @Test
                                      public void testComputeShiftIncrementCase5DetectsDivisionMutant3() throws Exception {
                                          // Setup test data to trigger case 5
                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                          
                                          // Use reflection to access private fields
                                          Class<?> eigenClass = eigen.getClass();
                                          Field dMinField = eigenClass.getDeclaredField("dMin");
                                          dMinField.setAccessible(true);
                                          Field dN2Field = eigenClass.getDeclaredField("dN2");
                                          dN2Field.setAccessible(true);
                                          Field pingPongField = eigenClass.getDeclaredField("pingPong");
                                          pingPongField.setAccessible(true);
                                          Field workField = eigenClass.getDeclaredField("work");
                                          workField.setAccessible(true);
                                          Field tauField = eigenClass.getDeclaredField("tau");
                                          tauField.setAccessible(true);
                                          Field tTypeField = eigenClass.getDeclaredField("tType");
                                          tTypeField.setAccessible(true);
                                          
                                          // Set fields to enter case 5
                                          dMinField.setDouble(eigen, 4.0);
                                          dN2Field.setDouble(eigen, 4.0);  // dMin == dN2
                                          pingPongField.setInt(eigen, 0);
                                          
                                          // Setup work array with values that will show difference between division and subtraction
                                          // For nn=19, we need indices:
                                          // nn-13=6 and nn-15=4 (for the mutated line)
                                          // Also need to satisfy conditions:
                                          // work[np-8] > b2 || work[np-4] > b1 (np=nn-2*pingPong=19)
                                          // So work[11] > b2 || work[15] > b1
                                          double[] work = new double[20];
                                          work[4] = 2.0;    // work[nn-15]
                                          work[6] = 6.0;    // work[nn-13] (6/2=3 vs 6-2=4)
                                          work[11] = 0.0;   // work[np-8] (19-8=11)
                                          work[15] = 0.0;   // work[np-4] (19-4=15)
                                          work[17] = 1.0;   // b1 = work[np-2] = work[17]
                                          work[13] = 1.0;   // b2 = work[np-6] = work[13]
                                          
                                          // Set other required work array values
                                          work[11] = 0.5;   // work[11] - must be <= b2 (1.0)
                                          work[15] = 0.5;   // work[15] - must be <= b1 (1.0)
                                          
                                          workField.set(eigen, work);
                                          
                                          // Call the private method using reflection
                                          Method computeShiftIncrement = eigenClass.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                          computeShiftIncrement.setAccessible(true);
                                          computeShiftIncrement.invoke(eigen, 0, 5, 2);
                                          
                                          // More sensitive test with different values
                                          work[4] = 3.0;
                                          work[6] = 1.5;
                                          workField.set(eigen, work);
                                          computeShiftIncrement.invoke(eigen, 0, 5, 2);
                                          
                                          // Verify the tau value is as expected for original code
                                          assertEquals(1.0, tauField.getDouble(eigen), 1e-10);
                                          
                                          // Also verify tType is set correctly
                                          assertEquals(-5, tTypeField.getInt(eigen));
                                      }

    @Test
                                 public void testComputeShiftIncrementCase4DetectsMutant() throws Exception {
                                     // Setup test data for case 4
                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1.0, 2.0, 3.0}, 
                                                                                            new double[]{0.5, 1.5}, 
                                                                                            1.0e-10);
                                     
                                     // Use reflection to set private fields
                                     Class<?> clazz = eigen.getClass();
                                     
                                     // Set required field values for case 4
                                     Field dMinField = clazz.getDeclaredField("dMin");
                                     dMinField.setAccessible(true);
                                     dMinField.set(eigen, 1.0);
                                     
                                     Field dNField = clazz.getDeclaredField("dN");
                                     dNField.setAccessible(true);
                                     dNField.set(eigen, 1.0);  // dMin == dN
                                     
                                     Field dMin1Field = clazz.getDeclaredField("dMin1");
                                     dMin1Field.setAccessible(true);
                                     dMin1Field.set(eigen, 2.0);  // != dN1 to avoid case 2/3
                                     
                                     Field dN1Field = clazz.getDeclaredField("dN1");
                                     dN1Field.setAccessible(true);
                                     dN1Field.set(eigen, 3.0);
                                     
                                     Field pingPongField = clazz.getDeclaredField("pingPong");
                                     pingPongField.setAccessible(true);
                                     pingPongField.set(eigen, 1);
                                     
                                     // Setup work array values that will be used in calculations
                                     // These values are chosen to make b2 significant in the calculation
                                     Field workField = clazz.getDeclaredField("work");
                                     workField.setAccessible(true);
                                     double[] work = new double[100];
                                     work[4*3 + 1 - 5] = 4.0;  // work[nn-5] where nn = 4*end + pingPong - 1 = 12
                                     work[4*3 + 1 - 7] = 2.0;  // work[nn-7]
                                     work[4*3 + 1 - 9] = 1.0;  // work[nn-9]
                                     work[4*3 + 1 - 11] = 0.5; // work[nn-11]
                                     workField.set(eigen, work);
                                     
                                     // Call the private method using reflection
                                     Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                     computeShiftIncrement.setAccessible(true);
                                     computeShiftIncrement.invoke(eigen, 0, 3, 0);
                                     
                                     // Calculate expected value manually with correct a2 accumulation
                                     double b1 = Math.sqrt(4.0) * Math.sqrt(1.0);  // sqrt(work[8])*sqrt(work[6])
                                     double b2 = Math.sqrt(2.0) * Math.sqrt(0.5);  // sqrt(work[6])*sqrt(work[4])
                                     double a2 = 2.0 + 1.0;  // work[6] + work[4]
                                     a2 = a2 + b2;  // This is the correct operation that would be mutated
                                     
                                     // Expected tau calculation
                                     double expectedTau;
                                     if (a2 < 0.563) {  // cnst1
                                         expectedTau = 1.0 * (1 - Math.sqrt(a2)) / (1 + a2);  // gam = dN = 1.0
                                     } else {
                                         expectedTau = 0.25 * 1.0;  // dMin = 1.0
                                     }
                                     
                                     // Get private fields for assertion
                                     Field tauField = clazz.getDeclaredField("tau");
                                     tauField.setAccessible(true);
                                     double tau = (Double)tauField.get(eigen);
                                     
                                     Field tTypeField = clazz.getDeclaredField("tType");
                                     tTypeField.setAccessible(true);
                                     int tType = (Integer)tTypeField.get(eigen);
                                     
                                     // Verify the result would catch the mutation
                                     assertEquals("Tau value should match expected calculation", 
                                                 expectedTau, tau, 1.0e-10);
                                     assertEquals("Type should be -4 for case 4", -4, tType);
                                 }

    @Test
                            public void testComputeShiftIncrementDetectsA2Mutation1() throws Exception {
                                // Setup test data to trigger case 4
                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0}, new double[]{1.0}, 1.0);
                                
                                // Use reflection to set private fields
                                Class<?> clazz = decomposition.getClass();
                                
                                // Set fields to enter case 4
                                Field dMinField = clazz.getDeclaredField("dMin");
                                dMinField.setAccessible(true);
                                dMinField.setDouble(decomposition, 1.0);
                                
                                Field dNField = clazz.getDeclaredField("dN");
                                dNField.setAccessible(true);
                                dNField.setDouble(decomposition, 1.0);
                                
                                Field dMin1Field = clazz.getDeclaredField("dMin1");
                                dMin1Field.setAccessible(true);
                                dMin1Field.setDouble(decomposition, 2.0); // Different from dN1 to avoid case 2/3
                                
                                Field dN1Field = clazz.getDeclaredField("dN1");
                                dN1Field.setAccessible(true);
                                dN1Field.setDouble(decomposition, 3.0);
                                
                                Field deflatedField = clazz.getDeclaredField("deflated");
                                deflatedField.setAccessible(true);
                                deflatedField.setInt(decomposition, 0);
                                
                                Field endField = clazz.getDeclaredField("end");
                                endField.setAccessible(true);
                                endField.setInt(decomposition, 10);
                                
                                Field pingPongField = clazz.getDeclaredField("pingPong");
                                pingPongField.setAccessible(true);
                                pingPongField.setInt(decomposition, 0);
                                
                                Field tTypeField = clazz.getDeclaredField("tType");
                                tTypeField.setAccessible(true);
                                tTypeField.setInt(decomposition, 0);
                                
                                // Setup work array values that will produce non-zero b2
                                // nn = 4*end + pingPong - 1 = 39
                                double[] work = new double[40];
                                work[36] = 4.0; // work[nn-3] = work[36]
                                work[34] = 9.0; // work[nn-5] = work[34]
                                work[32] = 16.0; // work[nn-7] = work[32]
                                work[30] = 25.0; // work[nn-9] = work[30]
                                work[28] = 1.0; // work[nn-11] = work[28]
                                
                                Field workField = clazz.getDeclaredField("work");
                                workField.setAccessible(true);
                                workField.set(decomposition, work);
                                
                                // Call the private method using reflection
                                Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                computeShiftIncrement.setAccessible(true);
                                computeShiftIncrement.invoke(decomposition, 0, 10, 0);
                                
                                // Calculate expected values
                                double expectedB1 = Math.sqrt(work[36]) * Math.sqrt(work[34]); // 2*3 = 6
                                double expectedB2 = Math.sqrt(work[32]) * Math.sqrt(work[30]); // 4*5 = 20
                                double expectedA2 = work[32] + work[34]; // 16 + 9 = 25 (original)
                                // In mutated version: a2 would be 16 * (9/16) = 9 (wrong)
                                
                                // The final tau depends on a2, so we can verify it
                                // For case 4, when work[nn-5] <= work[nn-7] (9 <= 16 is true)
                                // b2 becomes work[nn-5]/work[nn-7] = 9/16
                                // Then a2 accumulates through the loop (but with our setup, it will break immediately)
                                // So final a2 should be 9/16 (0.5625)
                                // Then cnst3 * a2 = 1.05 * 0.5625 = 0.590625
                                // Since this is < cnst1 (0.563), we calculate s = gam*(1-sqrt(a2))/(1+a2)
                                // gam = dN = 1.0
                                // s = 1.0*(1-sqrt(0.590625))/(1+0.590625) ≈ 0.15625
                                double expectedTau = 1.0 * (1 - Math.sqrt(0.590625)) / (1 + 0.590625);
                                
                                // Verify tau is calculated correctly (would be different if mutation was present)
                                Field tauField = clazz.getDeclaredField("tau");
                                tauField.setAccessible(true);
                                double actualTau = tauField.getDouble(decomposition);
                                assertEquals(expectedTau, actualTau, 1e-10);
                                
                                // Also verify tType was set correctly
                                int actualTType = tTypeField.getInt(decomposition);
                                assertEquals(-4, actualTType);
                            }

    @Test
                   public void testComputeShiftIncrementDetectsLoopIncrementMutant() throws Exception {
                       // Setup test case for case 5 (dMin == dN2)
                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                       
                       // Set required fields through reflection since they're private
                       java.lang.reflect.Field field = eigen.getClass().getDeclaredField("dMin");
                       field.setAccessible(true);
                       field.set(eigen, 1.0);  // dMin > 0 to avoid early return
                       
                       field = eigen.getClass().getDeclaredField("dN2");
                       field.setAccessible(true);
                       field.set(eigen, 1.0);   // dMin == dN2 for case 5
                       
                       field = eigen.getClass().getDeclaredField("deflated");
                       field.setAccessible(true);
                       field.set(eigen, 0); // case 0 in switch
                       
                       field = eigen.getClass().getDeclaredField("pingPong");
                       field.setAccessible(true);
                       field.set(eigen, 0); // simple case
                       
                       field = eigen.getClass().getDeclaredField("end");
                       field.setAccessible(true);
                       field.set(eigen, 10);     // ensure end-start > 3
                       
                       field = eigen.getClass().getDeclaredField("start");
                       field.setAccessible(true);
                       field.set(eigen, 1);    // start at 1
                       
                       // Setup work array with values that won't trigger early returns
                       double[] work = new double[100];
                       Arrays.fill(work, 1.0);  // simple values that won't trigger returns
                       field = eigen.getClass().getDeclaredField("work");
                       field.setAccessible(true);
                       field.set(eigen, work);
                       
                       // Get and call the private method via reflection
                       java.lang.reflect.Method method = eigen.getClass().getDeclaredMethod(
                           "computeShiftIncrement", int.class, int.class, int.class);
                       method.setAccessible(true);
                       method.invoke(eigen, 1, 10, 0);
                       
                       // Verify results
                       field = eigen.getClass().getDeclaredField("tType");
                       field.setAccessible(true);
                       int tType = (int) field.get(eigen);
                       
                       field = eigen.getClass().getDeclaredField("tau");
                       field.setAccessible(true);
                       double tau = (double) field.get(eigen);
                       
                       // In case of mutant (i4 += 4), either:
                       // - Test would timeout (infinite loop)
                       // - Or produce wrong tau value
                       assertEquals(-5, tType);  // Verify we're in case 5
                       assertTrue(tau > 0);      // Verify reasonable tau value
                   }

    @Test
              public void testComputeShiftIncrementDetectsLoopIncrementMutant1() throws Exception {
                  // Setup test case for scenario where dMin == dN2 (case 5)
                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                  
                  // Reflection helper to set private fields
                  Class<?> clazz = eigen.getClass();
                  
                  // Set required private fields
                  Field dMinField = clazz.getDeclaredField("dMin");
                  dMinField.setAccessible(true);
                  dMinField.set(eigen, 1.0);
                  
                  Field dN2Field = clazz.getDeclaredField("dN2");
                  dN2Field.setAccessible(true);
                  dN2Field.set(eigen, 1.0);
                  
                  Field pingPongField = clazz.getDeclaredField("pingPong");
                  pingPongField.setAccessible(true);
                  pingPongField.set(eigen, 0);
                  
                  Field endField = clazz.getDeclaredField("end");
                  endField.setAccessible(true);
                  endField.set(eigen, 5); // Needs to be >3 to enter the affected loop
                  
                  Field startField = clazz.getDeclaredField("start");
                  startField.setAccessible(true);
                  startField.set(eigen, 0);
                  
                  // Create work array where processing every 2 vs 4 elements makes a difference
                  // Values carefully chosen so the loop will process multiple elements
                  double[] work = new double[100];
                  work[4*5 + 0 - 2] = 2.0;  // nn-2
                  work[4*5 + 0 - 6] = 3.0;  // nn-6
                  work[4*5 + 0 - 8] = 4.0;  // nn-8
                  work[4*5 + 0 - 4] = 5.0;  // nn-4
                  work[4*5 + 0 - 13] = 6.0; // nn-13
                  work[4*5 + 0 - 15] = 7.0; // nn-15
                  work[4*5 + 0 - 17] = 8.0; // nn-17
                  work[4*5 + 0 - 19] = 9.0; // nn-19
                  
                  Field workField = clazz.getDeclaredField("work");
                  workField.setAccessible(true);
                  workField.set(eigen, work);
                  
                  // Call the private method using reflection
                  Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                  computeShiftIncrement.setAccessible(true);
                  computeShiftIncrement.invoke(eigen, 0, 5, 0);
                  
                  // Get the computed tau value
                  Field tauField = clazz.getDeclaredField("tau");
                  tauField.setAccessible(true);
                  double tau = (Double)tauField.get(eigen);
                  
                  // Verify the correct tau was computed
                  // Expected value calculated based on original behavior (i4 -= 4)
                  double expectedTau = 0.25; // This should be the expected value from correct calculations
                  assertEquals("Mutant not detected - loop increment changed behavior", 
                              expectedTau, tau, 1e-10);
              }

    @Test
         public void testComputeShiftIncrementCase5BoundaryCondition5() throws Exception {
             // Setup
             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
             
             // Use reflection to set private fields
             Class<?> clazz = eigen.getClass();
             
             // Set fields to trigger case 5 (tType = -5)
             Field dMinField = clazz.getDeclaredField("dMin");
             dMinField.setAccessible(true);
             dMinField.set(eigen, 1.0);
             
             Field dMin2Field = clazz.getDeclaredField("dMin2");
             dMin2Field.setAccessible(true);
             dMin2Field.set(eigen, 1.0);
             
             Field dN2Field = clazz.getDeclaredField("dN2");
             dN2Field.setAccessible(true);
             dN2Field.set(eigen, 1.0);
             
             Field pingPongField = clazz.getDeclaredField("pingPong");
             pingPongField.setAccessible(true);
             pingPongField.set(eigen, 1);
             
             int deflated = 2;
             int end = 5;
             int start = 1;
             
             // Setup work array to be sensitive to boundary conditions
             // nn = 4 * end + pingPong - 1 = 4*5 + 1 - 1 = 20
             // np = nn - 2*pingPong = 20 - 2 = 18
             // The loop starts at nn-17 = 3 and should stop at 4*start + 2 + pingPong = 4*1 + 2 + 1 = 7
             // With mutant, it would stop at 4*1 + 1 = 5
             double[] work = new double[20];
             work[18-2] = 1.0;  // np-2 = 16
             work[18-6] = 1.0;   // np-6 = 12
             work[18-8] = 0.5;   // np-8 = 10
             work[18-4] = 0.5;   // np-4 = 14
             work[20-13] = 0.5;  // nn-13 = 7
             work[20-15] = 1.0;  // nn-15 = 5
             
             // Set values that will cause different behavior when extra elements are processed
             for (int i = 4; i < 20; i += 4) {
                 work[i] = 0.4;
                 work[i-2] = 1.0;
             }
             
             Field workField = clazz.getDeclaredField("work");
             workField.setAccessible(true);
             workField.set(eigen, work);
             
             // Expected tau value based on correct boundary
             double expectedTau = 0.25 * (Double)dMinField.get(eigen);
             
             // Execute computeShiftIncrement via reflection
             Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
             computeShiftIncrement.setAccessible(true);
             computeShiftIncrement.invoke(eigen, start, end, deflated);
             
             // Verify results via reflection
             Field tauField = clazz.getDeclaredField("tau");
             tauField.setAccessible(true);
             double actualTau = (Double)tauField.get(eigen);
             
             Field tTypeField = clazz.getDeclaredField("tType");
             tTypeField.setAccessible(true);
             int actualTType = (Integer)tTypeField.get(eigen);
             
             assertEquals("Tau value should match expected calculation", expectedTau, actualTau, 1e-10);
             assertEquals("Should be case 5", -5, actualTType);
         }

    @Test
    public void testComputeShiftIncrementCase5BoundaryCondition6() throws Exception {
        // Setup test data to hit the boundary condition
        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
        
        // Helper method to set private fields via reflection
        java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
        dMinField.setAccessible(true);
        dMinField.set(eigen, 1.0);
        
        java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
        dN2Field.setAccessible(true);
        dN2Field.set(eigen, 1.0); // dMin == dN2 to enter case 5
        
        java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
        deflatedField.setAccessible(true);
        deflatedField.set(eigen, 0);
        
        java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
        pingPongField.setAccessible(true);
        pingPongField.set(eigen, 0);
        
        java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
        endField.setAccessible(true);
        endField.set(eigen, 5); // end > 3 to enter the loop
        
        java.lang.reflect.Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
        startField.setAccessible(true);
        startField.set(eigen, 1);
        
        // Setup work array to ensure loop executes with boundary condition
        double[] work = new double[100];
        work[83] = 1.0;  // nn-17 = 4*5*4 + 0 -1 -17 = 83-17=66
        work[81] = 1.0;  // nn-15 = 81
        work[79] = 1.0;  // nn-13 = 79
        work[77] = 1.0;  // nn-11 = 77
        work[75] = 1.0;  // nn-9 = 75
        work[73] = 1.0;  // nn-7 = 73
        work[71] = 1.0;  // nn-5 = 71
        work[69] = 1.0;  // nn-3 = 69
        work[67] = 1.0;  // nn-1 = 67
        
        // Set values to ensure loop executes exactly to boundary
        for (int i = 6; i <= 66; i += 4) {
            work[i] = 0.5;  // work[i4]
            work[i-2] = 1.0; // work[i4-2]
        }
        
        java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
        workField.setAccessible(true);
        workField.set(eigen, work);
        
        // Call the private method via reflection
        java.lang.reflect.Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
            "computeShiftIncrement", int.class, int.class, int.class);
        computeShiftIncrement.setAccessible(true);
        computeShiftIncrement.invoke(eigen, 1, 5, 0);
        
        // Get results via reflection
        java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
        tauField.setAccessible(true);
        double tau = (Double)tauField.get(eigen);
        
        java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
        tTypeField.setAccessible(true);
        int tType = (Integer)tTypeField.get(eigen);
        
        // Verify results - mutant would skip last iteration and produce different tau
        assertEquals(-5, tType);
        // Exact value depends on full calculation, but we know it should be > 0
        assertTrue(tau > 0);
    }


}
