package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
 
public class FastMathTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                 public void testMaxInt() {
                     // Typical cases
                     assertEquals(5, FastMath.max(2, 5));
                     assertEquals(5, FastMath.max(5, 2));
                     assertEquals(-1, FastMath.max(-1, -5));
                     assertEquals(-1, FastMath.max(-5, -1));
                     
                     // Edge cases
                     assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, 0));
                     assertEquals(0, FastMath.max(Integer.MIN_VALUE, 0));
                     assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
                     
                     // Equal values
                     assertEquals(10, FastMath.max(10, 10));
                     assertEquals(0, FastMath.max(0, 0));
                     assertEquals(-5, FastMath.max(-5, -5));
                 }

 @Test
                 public void testMaxLong() {
                     // Typical cases
                     assertEquals(5000000000L, FastMath.max(2000000000L, 5000000000L));
                     assertEquals(5000000000L, FastMath.max(5000000000L, 2000000000L));
                     assertEquals(-100L, FastMath.max(-100L, -500L));
                     assertEquals(-100L, FastMath.max(-500L, -100L));
                     
                     // Edge cases
                     assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, 0L));
                     assertEquals(0L, FastMath.max(Long.MIN_VALUE, 0L));
                     assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
                     
                     // Equal values
                     assertEquals(10000000000L, FastMath.max(10000000000L, 10000000000L));
                     assertEquals(0L, FastMath.max(0L, 0L));
                     assertEquals(-500L, FastMath.max(-500L, -500L));
                 }

 @Test
                 public void testMaxFloat() {
                     // Typical cases
                     assertEquals(5.5f, FastMath.max(2.2f, 5.5f), 0.0001f);
                     assertEquals(5.5f, FastMath.max(5.5f, 2.2f), 0.0001f);
                     assertEquals(-1.1f, FastMath.max(-1.1f, -5.5f), 0.0001f);
                     assertEquals(-1.1f, FastMath.max(-5.5f, -1.1f), 0.0001f);
                     
                     // Edge cases
                     assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
                     assertEquals(Float.MAX_VALUE, FastMath.max(Float.MIN_VALUE, Float.MAX_VALUE), 0.0f);
                     assertEquals(0.0f, FastMath.max(Float.NEGATIVE_INFINITY, 0.0f), 0.0f);
                     
                     // Special float values
                     assertEquals(Float.NaN, FastMath.max(Float.NaN, 5.0f), 0.0f);
                     assertEquals(Float.NaN, FastMath.max(5.0f, Float.NaN), 0.0f);
                     assertEquals(Float.NaN, FastMath.max(Float.NaN, Float.NaN), 0.0f);
                     
                     // Equal values
                     assertEquals(10.0f, FastMath.max(10.0f, 10.0f), 0.0001f);
                     assertEquals(0.0f, FastMath.max(0.0f, 0.0f), 0.0f);
                     assertEquals(-5.5f, FastMath.max(-5.5f, -5.5f), 0.0001f);
                 }

 @Test
                 public void testMaxDouble() {
                     // Typical cases
                     assertEquals(5.55555, FastMath.max(2.22222, 5.55555), 0.00001);
                     assertEquals(5.55555, FastMath.max(5.55555, 2.22222), 0.00001);
                     assertEquals(-1.11111, FastMath.max(-1.11111, -5.55555), 0.00001);
                     assertEquals(-1.11111, FastMath.max(-5.55555, -1.11111), 0.00001);
                     
                     // Edge cases
                     assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
                     assertEquals(Double.MAX_VALUE, FastMath.max(Double.MIN_VALUE, Double.MAX_VALUE), 0.0);
                     assertEquals(0.0, FastMath.max(Double.NEGATIVE_INFINITY, 0.0), 0.0);
                     
                     // Special double values
                     assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
                     assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
                     assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
                     
                     // Equal values
                     assertEquals(10.0, FastMath.max(10.0, 10.0), 0.00001);
                     assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0);
                     assertEquals(-5.55555, FastMath.max(-5.55555, -5.55555), 0.00001);
                 }

 @Test
                 public void testMax_Int_TypicalValues() {
                     // Test with typical positive values
                     assertEquals(5, FastMath.max(3, 5));
                     assertEquals(5, FastMath.max(5, 3));
                     
                     // Test with negative values
                     assertEquals(-1, FastMath.max(-3, -1));
                     assertEquals(-1, FastMath.max(-1, -3));
                     
                     // Test with zero
                     assertEquals(0, FastMath.max(0, -5));
                     assertEquals(5, FastMath.max(5, 0));
                 }

 @Test
                 public void testMax_Int_EqualValues() {
                     // Test with equal values
                     assertEquals(5, FastMath.max(5, 5));
                     assertEquals(0, FastMath.max(0, 0));
                     assertEquals(-3, FastMath.max(-3, -3));
                 }

 @Test
                 public void testMax_Int_EdgeCases() {
                     // Test with Integer.MAX_VALUE and Integer.MIN_VALUE
                     assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, 0));
                     assertEquals(Integer.MAX_VALUE, FastMath.max(0, Integer.MAX_VALUE));
                     assertEquals(0, FastMath.max(Integer.MIN_VALUE, 0));
                     assertEquals(0, FastMath.max(0, Integer.MIN_VALUE));
                     
                     // Test both extremes
                     assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MAX_VALUE));
                     assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
                 }

 @Test
                 public void testMax_Long_TypicalValues() {
                     // Test with typical positive values
                     assertEquals(5000000000L, FastMath.max(3000000000L, 5000000000L));
                     assertEquals(5000000000L, FastMath.max(5000000000L, 3000000000L));
                     
                     // Test with negative values
                     assertEquals(-1000000000L, FastMath.max(-3000000000L, -1000000000L));
                     assertEquals(-1000000000L, FastMath.max(-1000000000L, -3000000000L));
                 }

 @Test
                 public void testMax_Long_EdgeCases() {
                     // Test with Long.MAX_VALUE and Long.MIN_VALUE
                     assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, 0L));
                     assertEquals(Long.MAX_VALUE, FastMath.max(0L, Long.MAX_VALUE));
                     assertEquals(0L, FastMath.max(Long.MIN_VALUE, 0L));
                     assertEquals(0L, FastMath.max(0L, Long.MIN_VALUE));
                     
                     // Test both extremes
                     assertEquals(Long.MAX_VALUE, FastMath.max(Long.MIN_VALUE, Long.MAX_VALUE));
                     assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
                 }

 @Test
                 public void testMax_Float_TypicalValues() {
                     // Test with typical positive values
                     assertEquals(5.5f, FastMath.max(3.2f, 5.5f), 0.0001f);
                     assertEquals(5.5f, FastMath.max(5.5f, 3.2f), 0.0001f);
                     
                     // Test with negative values
                     assertEquals(-1.1f, FastMath.max(-3.3f, -1.1f), 0.0001f);
                     assertEquals(-1.1f, FastMath.max(-1.1f, -3.3f), 0.0001f);
                     
                     // Test with zero
                     assertEquals(0.0f, FastMath.max(0.0f, -5.5f), 0.0001f);
                     assertEquals(5.5f, FastMath.max(5.5f, 0.0f), 0.0001f);
                 }

 @Test
                 public void testMax_Float_SpecialValues() {
                     // Test with Float.NaN
                     assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.5f)));
                     assertTrue(Float.isNaN(FastMath.max(5.5f, Float.NaN)));
                     assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
                     
                     // Test with Float.POSITIVE_INFINITY
                     assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, 5.5f), 0.0f);
                     assertEquals(Float.POSITIVE_INFINITY, FastMath.max(5.5f, Float.POSITIVE_INFINITY), 0.0f);
                     
                     // Test with Float.NEGATIVE_INFINITY
                     assertEquals(5.5f, FastMath.max(Float.NEGATIVE_INFINITY, 5.5f), 0.0f);
                     assertEquals(5.5f, FastMath.max(5.5f, Float.NEGATIVE_INFINITY), 0.0f);
                 }

 @Test
                 public void testMax_Double_TypicalValues() {
                     // Test with typical positive values
                     assertEquals(5.55555, FastMath.max(3.22222, 5.55555), 0.000001);
                     assertEquals(5.55555, FastMath.max(5.55555, 3.22222), 0.000001);
                     
                     // Test with negative values
                     assertEquals(-1.11111, FastMath.max(-3.33333, -1.11111), 0.000001);
                     assertEquals(-1.11111, FastMath.max(-1.11111, -3.33333), 0.000001);
                     
                     // Test with zero
                     assertEquals(0.0, FastMath.max(0.0, -5.55555), 0.000001);
                     assertEquals(5.55555, FastMath.max(5.55555, 0.0), 0.000001);
                 }

 @Test
                 public void testMax_Double_SpecialValues() {
                     // Test with Double.NaN
                     assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.55555)));
                     assertTrue(Double.isNaN(FastMath.max(5.55555, Double.NaN)));
                     assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
                     
                     // Test with Double.POSITIVE_INFINITY
                     assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, 5.55555), 0.0);
                     assertEquals(Double.POSITIVE_INFINITY, FastMath.max(5.55555, Double.POSITIVE_INFINITY), 0.0);
                     
                     // Test with Double.NEGATIVE_INFINITY
                     assertEquals(5.55555, FastMath.max(Double.NEGATIVE_INFINITY, 5.55555), 0.0);
                     assertEquals(5.55555, FastMath.max(5.55555, Double.NEGATIVE_INFINITY), 0.0);
                 }

 @Test
                 public void testMax_RegularValues() {
                     // Test typical cases where a < b
                     assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
                     assertEquals(0.0f, FastMath.max(-1.0f, 0.0f), 0.0f);
                     assertEquals(100.0f, FastMath.max(100.0f, 50.0f), 0.0f);
                     
                     // Test cases where a > b
                     assertEquals(10.0f, FastMath.max(10.0f, 5.0f), 0.0f);
                     assertEquals(-1.0f, FastMath.max(-1.0f, -2.0f), 0.0f);
                     
                     // Test equal values
                     assertEquals(7.0f, FastMath.max(7.0f, 7.0f), 0.0f);
                     assertEquals(0.0f, FastMath.max(0.0f, 0.0f), 0.0f);
                     assertEquals(-3.0f, FastMath.max(-3.0f, -3.0f), 0.0f);
                 }

 @Test
                 public void testMax_EdgeCases() {
                     // Test with Float.MAX_VALUE and Float.MIN_VALUE
                     assertEquals(Float.MAX_VALUE, FastMath.max(Float.MAX_VALUE, Float.MIN_VALUE), 0.0f);
                     assertEquals(Float.MAX_VALUE, FastMath.max(Float.MIN_VALUE, Float.MAX_VALUE), 0.0f);
                     
                     // Test with positive and negative zero
                     assertEquals(0.0f, FastMath.max(0.0f, -0.0f), 0.0f);
                     assertEquals(0.0f, FastMath.max(-0.0f, 0.0f), 0.0f);
                     assertEquals(-0.0f, FastMath.max(-0.0f, -0.0f), 0.0f);
                 }

 @Test
                 public void testMax_NaNHandling() {
                     // Test cases where one operand is NaN
                     assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
                     assertTrue(Float.isNaN(FastMath.max(3.0f, Float.NaN)));
                     
                     // Test case where both operands are NaN
                     assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
                     
                     // Test case where sum is NaN but individual values aren't
                     // This can happen with opposite infinities
                     float posInf = Float.POSITIVE_INFINITY;
                     float negInf = Float.NEGATIVE_INFINITY;
                     assertTrue(Float.isNaN(FastMath.max(posInf, negInf)));
                     assertTrue(Float.isNaN(FastMath.max(negInf, posInf)));
                 }

 @Test
                 public void testMax_InfinityCases() {
                     // Test with positive infinity
                     assertEquals(Float.POSITIVE_INFINITY, 
                                  FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
                     assertEquals(Float.POSITIVE_INFINITY, 
                                  FastMath.max(Float.MAX_VALUE, Float.POSITIVE_INFINITY), 0.0f);
                     
                     // Test with negative infinity
                     assertEquals(0.0f, FastMath.max(Float.NEGATIVE_INFINITY, 0.0f), 0.0f);
                     assertEquals(Float.MIN_VALUE, 
                                  FastMath.max(Float.MIN_VALUE, Float.NEGATIVE_INFINITY), 0.0f);
                     
                     // Test both infinities (covered in NaN test)
                 }

 @Test
                 public void testMax_SubnormalNumbers() {
                     // Test with subnormal numbers
                     float smallestSubnormal = Float.MIN_VALUE;
                     float nextToSmallest = Math.nextUp(smallestSubnormal);
                     
                     assertEquals(nextToSmallest, FastMath.max(smallestSubnormal, nextToSmallest), 0.0f);
                     assertEquals(nextToSmallest, FastMath.max(nextToSmallest, smallestSubnormal), 0.0f);
                 }

 @Test
                 public void testMax_FirstArgumentGreater() {
                     double result = FastMath.max(5.0, 3.0);
                     assertEquals(5.0, result, 0.0);
                 }

 @Test
                 public void testMax_SecondArgumentGreater() {
                     double result = FastMath.max(2.0, 4.0);
                     assertEquals(4.0, result, 0.0);
                 }

 @Test
                 public void testMax_EqualValues() {
                     double result = FastMath.max(3.5, 3.5);
                     assertEquals(3.5, result, 0.0);
                 }

 @Test
                 public void testMax_FirstArgumentNegative() {
                     double result = FastMath.max(-2.0, 1.0);
                     assertEquals(1.0, result, 0.0);
                 }

 @Test
                 public void testMax_SecondArgumentNegative() {
                     double result = FastMath.max(3.0, -1.0);
                     assertEquals(3.0, result, 0.0);
                 }

 @Test
                 public void testMax_BothArgumentsNegative() {
                     double result = FastMath.max(-5.0, -3.0);
                     assertEquals(-3.0, result, 0.0);
                 }

 @Test
                 public void testMax_FirstArgumentNaN() {
                     double result = FastMath.max(Double.NaN, 2.0);
                     assertTrue(Double.isNaN(result));
                 }

 @Test
                 public void testMax_SecondArgumentNaN() {
                     double result = FastMath.max(1.0, Double.NaN);
                     assertTrue(Double.isNaN(result));
                 }

 @Test
                 public void testMax_BothArgumentsNaN() {
                     double result = FastMath.max(Double.NaN, Double.NaN);
                     assertTrue(Double.isNaN(result));
                 }

 @Test
                 public void testMax_FirstArgumentPositiveInfinity() {
                     double result = FastMath.max(Double.POSITIVE_INFINITY, 1000.0);
                     assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                 }

 @Test
                 public void testMax_SecondArgumentPositiveInfinity() {
                     double result = FastMath.max(1000.0, Double.POSITIVE_INFINITY);
                     assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                 }

 @Test
                 public void testMax_FirstArgumentNegativeInfinity() {
                     double result = FastMath.max(Double.NEGATIVE_INFINITY, -1000.0);
                     assertEquals(-1000.0, result, 0.0);
                 }

 @Test
                 public void testMax_SecondArgumentNegativeInfinity() {
                     double result = FastMath.max(-1000.0, Double.NEGATIVE_INFINITY);
                     assertEquals(-1000.0, result, 0.0);
                 }

 @Test
                 public void testMax_ZeroAndNegativeZero() {
                     double result1 = FastMath.max(0.0, -0.0);
                     assertEquals(0.0, result1, 0.0);
                     
                     double result2 = FastMath.max(-0.0, 0.0);
                     assertEquals(0.0, result2, 0.0);
                 }

 @Test
                 public void testMax_VeryLargeNumbers() {
                     double large1 = Double.MAX_VALUE;
                     double large2 = Double.MAX_VALUE / 2;
                     double result = FastMath.max(large1, large2);
                     assertEquals(large1, result, 0.0);
                 }

 @Test
                 public void testMax_VerySmallNumbers() {
                     double small1 = Double.MIN_VALUE;
                     double small2 = Double.MIN_VALUE * 2;
                     double result = FastMath.max(small1, small2);
                     assertEquals(small2, result, 0.0);
                 }

 @Test
         public void testMaxFloat1() {
             // Test equal values - this will catch the mutant
             float equal1 = 5.0f;
             float equal2 = 5.0f;
             assertEquals("Equal values should return second parameter", 
                         equal2, 
                         FastMath.max(equal1, equal2), 
                         0.0f);
             
             // Test a < b
             float smaller = 4.0f;
             float larger = 5.0f;
             assertEquals("When first is smaller should return second", 
                         larger, 
                         FastMath.max(smaller, larger), 
                         0.0f);
             
             // Test a > b
             assertEquals("When first is larger should return first", 
                         larger, 
                         FastMath.max(larger, smaller), 
                         0.0f);
             
             // Test with NaN values
             float nan = Float.NaN;
             float normal = 1.0f;
             assertTrue("NaN with normal should return NaN", 
                        Float.isNaN(FastMath.max(nan, normal)));
             assertTrue("Normal with NaN should return NaN", 
                        Float.isNaN(FastMath.max(normal, nan)));
             assertTrue("NaN with NaN should return NaN", 
                        Float.isNaN(FastMath.max(nan, nan)));
         }

 @Test
             public void testMaxFloat2() {
                 // Test case where a > b
                 assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
                 
                 // Test case where a < b
                 assertEquals(7.0f, FastMath.max(2.0f, 7.0f), 0.0f);
                 
                 // Test case where a equals b - this will catch the mutant
                 float equalValue = 4.0f;
                 assertEquals(equalValue, FastMath.max(equalValue, equalValue), 0.0f);
                 
                 // Test NaN cases (though original didn't handle them)
                 assertTrue(Float.isNaN(FastMath.max(Float.NaN, 3.0f)));
                 assertTrue(Float.isNaN(FastMath.max(2.0f, Float.NaN)));
                 assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
             }

 @Test
             public void testMaxFloat3() {
                 // Test case where a == b to catch the mutation
                 float equal1 = 5.0f;
                 float equal2 = 5.0f;
                 assertEquals("When a == b, should return b", 
                              equal2, 
                              FastMath.max(equal1, equal2), 
                              0.0f);
                 
                 // Normal cases
                 float smaller = 3.0f;
                 float larger = 7.0f;
                 assertEquals("When a < b, should return b", 
                              larger, 
                              FastMath.max(smaller, larger), 
                              0.0f);
                 assertEquals("When a > b, should return a", 
                              larger, 
                              FastMath.max(larger, smaller), 
                              0.0f);
                 
                 // NaN cases
                 float nan = Float.NaN;
                 float normal = 10.0f;
                 assertTrue("When a is NaN, should return NaN", 
                            Float.isNaN(FastMath.max(nan, normal)));
                 assertTrue("When b is NaN, should return NaN", 
                            Float.isNaN(FastMath.max(normal, nan)));
                 assertTrue("When both are NaN, should return NaN", 
                            Float.isNaN(FastMath.max(nan, nan)));
             }

 @Test
             public void testMaxDouble1() {
                 // Test case where a equals b - this will catch the mutant
                 double equal1 = 5.0;
                 double equal2 = 5.0;
                 assertEquals(equal2, FastMath.max(equal1, equal2), 0.0);
                 
                 // Additional test cases for completeness
                 // a < b
                 assertEquals(10.0, FastMath.max(5.0, 10.0), 0.0);
                 // a > b
                 assertEquals(10.0, FastMath.max(10.0, 5.0), 0.0);
                 // a is NaN
                 assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
                 // b is NaN
                 assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
                 // both are NaN
                 assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
                 // a + b is NaN (infinity cases)
                 assertTrue(Double.isNaN(FastMath.max(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY)));
             }

 @Test
        public void testMaxWithNaNAndInfinity() {
            // Test case where a is positive infinity and b is negative infinity
            // Original would check isNaN(inf + -inf) = isNaN(NaN) = true → return NaN
            // Mutant checks isNaN(inf - -inf) = isNaN(inf) = false → return a (inf)
            float posInf = Float.POSITIVE_INFINITY;
            float negInf = Float.NEGATIVE_INFINITY;
            assertEquals(Float.NaN, FastMath.max(posInf, negInf), 0.0f);
            
            // Test case where a is NaN and b is infinity
            float nan = Float.NaN;
            assertEquals(Float.NaN, FastMath.max(nan, posInf), 0.0f);
            
            // Test case where b is NaN and a is infinity
            assertEquals(Float.NaN, FastMath.max(posInf, nan), 0.0f);
            
            // Test case where both are NaN
            assertEquals(Float.NaN, FastMath.max(nan, nan), 0.0f);
            
            // Additional test case where a is negative infinity and b is positive infinity
            assertEquals(Float.NaN, FastMath.max(negInf, posInf), 0.0f);
        }

 @Test
            public void testMaxWithNaN() {
                // Test case where a is NaN and b is finite
                float a = Float.NaN;
                float b = 5.0f;
                // Original would return NaN because a+b is NaN
                // Mutant would return NaN because a-b is NaN
                // So this case wouldn't detect the mutation
                
                // Test case where b is NaN and a is finite
                float c = 10.0f;
                float d = Float.NaN;
                // Original would return NaN because c+d is NaN
                // Mutant would return NaN because c-d is NaN
                // So this case wouldn't detect the mutation
                
                // Test case where both are NaN
                float e = Float.NaN;
                float f = Float.NaN;
                // Both versions would return NaN
                
                // The mutation can only be detected when we have a case where:
                // a > b (so we reach the else branch)
                // and Float.isNaN(a + b) is true but Float.isNaN(a - b) is false
                // This can happen when one operand is infinite and the other is NaN
                
                // Test case that will detect the mutation:
                float inf = Float.POSITIVE_INFINITY;
                float nan = Float.NaN;
                
                // Original behavior: inf > nan is false (special float comparison rules)
                // So original would return inf (since inf <= nan is false)
                // Mutant behavior: same as original in this case
                
                // Need to find case where a > b is true but a+b is NaN while a-b is not
                // This is impossible because:
                // - If either a or b is NaN, a > b is false
                // - For a > b to be true, neither can be NaN
                // - So a+b and a-b would both be non-NaN
                
                // After careful analysis, the mutation is actually undetectable through
                // normal input values because:
                // 1. If either input is NaN, a <= b will be false (special float comparison)
                //    and we'll take the else branch where both versions return NaN
                // 2. If neither is NaN, then a+b and a-b will both be non-NaN
                //    so both versions will return the same value
                
                // Therefore, the mutation is equivalent and cannot be killed by any test case
                // This suggests the mutation doesn't actually change the method's behavior
                
                // However, if we assume the original code was:
                // return (a <= b) ? b : (Float.isNaN(a + b) ? Float.NaN : a);
                // and mutant is:
                // return (a <= b) ? b : (Float.isNaN(a - b) ? Float.NaN : a);
                // then the only way to detect it is if a > b and isNaN(a+b) != isNaN(a-b)
                // which as discussed is impossible with normal float values
                
                // Conclusion: This is an equivalent mutant that cannot be killed
                // No test case can be written to detect this mutation
            }

 @Test
            public void testMaxWithInfiniteValues() {
                // Test case that catches the mutant
                float posInf = Float.POSITIVE_INFINITY;
                float negInf = Float.NEGATIVE_INFINITY;
                
                // Case 1: One positive infinity, one negative infinity
                // Original would return posInf (since posInf + negInf is NaN)
                // Mutant would return NaN (since posInf - negInf is +Inf - -Inf = +Inf + +Inf = +Inf, not NaN)
                // Wait, actually posInf - negInf = posInf + posInf = posInf (not NaN)
                // So this case wouldn't catch the mutant
                
                // Correct test case that catches the mutant:
                // When both are positive infinity
                // Original: posInf + posInf = posInf (not NaN) -> returns posInf
                // Mutant: posInf - posInf = NaN -> returns NaN
                assertEquals(Float.POSITIVE_INFINITY, FastMath.max(posInf, posInf), 0.0f);
                
                // When both are negative infinity
                // Original: negInf + negInf = negInf (not NaN) -> returns negInf
                // Mutant: negInf - negInf = NaN -> returns NaN
                assertEquals(Float.NEGATIVE_INFINITY, FastMath.max(negInf, negInf), 0.0f);
                
                // Additional test cases for completeness
                // Regular numbers
                assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
                assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
                
                // NaN cases
                assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
                assertTrue(Float.isNaN(FastMath.max(5.0f, Float.NaN)));
                assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
                
                // Mixed infinity and regular number
                assertEquals(posInf, FastMath.max(posInf, 5.0f), 0.0f);
                assertEquals(posInf, FastMath.max(5.0f, posInf), 0.0f);
            }

 @Test
            public void testMaxWithOppositeInfinities() {
                // Test case that will catch the mutant
                double posInf = Double.POSITIVE_INFINITY;
                double negInf = Double.NEGATIVE_INFINITY;
                
                // Original behavior: (∞ + -∞) = NaN → should return NaN
                // Mutant behavior: (∞ - -∞) = ∞ → would return ∞
                double result = FastMath.max(posInf, negInf);
                
                // Assert that the result is NaN as expected by original behavior
                assertTrue("max(∞, -∞) should be NaN", Double.isNaN(result));
                
                // Additional test case where a is larger but sum would be NaN
                double largeValue = Double.MAX_VALUE;
                double smallValue = -Double.MAX_VALUE;
                result = FastMath.max(largeValue, smallValue);
                assertTrue("max(MAX_VALUE, -MAX_VALUE) should be MAX_VALUE", 
                          Double.compare(largeValue, result) == 0);
            }

 @Test
            public void testMaxWithNaN1() {
                // Test regular NaN cases
                double nan = Double.NaN;
                double normal = 5.0;
                
                // When first argument is NaN
                assertTrue("max(NaN, x) should be NaN", 
                          Double.isNaN(FastMath.max(nan, normal)));
                
                // When second argument is NaN
                assertTrue("max(x, NaN) should be NaN", 
                          Double.isNaN(FastMath.max(normal, nan)));
                
                // When both arguments are NaN
                assertTrue("max(NaN, NaN) should be NaN", 
                          Double.isNaN(FastMath.max(nan, nan)));
            }

 @Test
       public void testMaxWithNaN2() {
           // Test case where a is NaN and b is valid
           float a = Float.NaN;
           float b = 5.0f;
           
           // Original should return NaN (since a + b is NaN)
           // Mutant would return a (NaN) only if b is NaN (which it's not)
           // So both would return NaN in this case - need a different test
           
           // Better test case: a is valid, b is NaN
           a = 5.0f;
           b = Float.NaN;
           
           // Original should return NaN (since a + b is NaN)
           // Mutant would return NaN (since b is NaN)
           // So this still doesn't catch the difference
           
           // Best test case: a is NaN, b is valid
           a = Float.NaN;
           b = 5.0f;
           
           // Original: a + b is NaN, so returns NaN
           // Mutant: b is not NaN, so returns a (which is NaN)
           // Both return NaN - can't distinguish
           
           // Need to test the internal behavior - since both return same value,
           // we need to verify the exact NaN propagation
           
           // Alternative approach: test with both NaN
           a = Float.NaN;
           b = Float.NaN;
           float result = FastMath.max(a, b);
           assertTrue(Float.isNaN(result));
           
           // The key test that catches the mutant:
           // When a is NaN and b is not NaN
           a = Float.NaN;
           b = 5.0f;
           result = FastMath.max(a, b);
           // Original would compute a + b = NaN and return NaN
           // Mutant would check b (5.0) is not NaN and return a (NaN)
           // Same result, but different path - need to verify the exact NaN
           
           // The only way to catch this is to verify the NaN propagation
           // is from the sum, not just from a
           // Since we can't directly test the implementation,
           // we need to test with signaling NaN
           
           // Final test case that would catch the mutant:
           try {
               a = Float.intBitsToFloat(0x7f800001); // signaling NaN
               b = 5.0f;
               result = FastMath.max(a, b);
               // Original would trigger NaN from sum
               // Mutant would just return a (signaling NaN)
               // The behavior difference might be detectable
               assertTrue(Float.isNaN(result));
           } catch (Exception e) {
               // Original might throw due to signaling NaN
               // Mutant would return NaN
               fail("Original might throw with signaling NaN");
           }
       }

 @Test
       public void testMaxWithOneNaN() {
           // Case where a is NaN and b is valid
           float a = Float.NaN;
           float b = 5.0f;
           float result = FastMath.max(a, b);
           
           // Both implementations return NaN, but for different reasons
           // Original: because a + b is NaN
           // Mutant: because a is NaN
           assertTrue(Float.isNaN(result));
           
           // This test can't actually detect the mutant since the observable
           // behavior is identical - the mutant survives
       }

 @Test
       public void testMaxWithNaNAndNumber() {
           // Test case where a is NaN and b is a normal number
           float a = Float.NaN;
           float b = 5.0f;
           
           // The original code would return Float.NaN through explicit check (a + b is NaN)
           // The mutant would return a (which is NaN) but through different logic path
           float result = FastMath.max(a, b);
           
           // Verify the result is NaN (both implementations return NaN but for different reasons)
           assertTrue(Float.isNaN(result));
           
           // Additional test to ensure the mutant is caught - check when b is NaN
           float c = 10.0f;
           float d = Float.NaN;
           float result2 = FastMath.max(c, d);
           assertTrue(Float.isNaN(result2));
           
           // Test case where both are NaN
           float result3 = FastMath.max(Float.NaN, Float.NaN);
           assertTrue(Float.isNaN(result3));
           
           // Test case where neither is NaN
           float result4 = FastMath.max(10.0f, 5.0f);
           assertEquals(10.0f, result4, 0.0f);
       }

 @Test
       public void testMaxWithFirstArgumentNaN() {
           // Setup
           float a = Float.NaN;
           float b = 5.0f;
           
           // Execute
           float result = FastMath.max(a, b);
           
           // Verify
           // Original would return NaN (since a+b is NaN)
           // Mutated would return a (NaN value) which is different from Float.NaN
           assertTrue("Should return Float.NaN when first argument is NaN", 
                      Float.isNaN(result));
           
           // Additional verification that it's not just any NaN but the standard one
           assertEquals(Float.floatToRawIntBits(Float.NaN), 
                        Float.floatToRawIntBits(result));
       }

 @Test
           public void testMaxWithNaN3() {
               // Test case where a is NaN and b is valid
               double nanA = Double.NaN;
               double validB = 5.0;
               assertEquals("When a is NaN and b is valid, should return NaN", 
                           Double.NaN, 
                           FastMath.max(nanA, validB), 
                           0.0);
               
               // Test case where b is NaN and a is valid
               double validA = 5.0;
               double nanB = Double.NaN;
               assertEquals("When b is NaN and a is valid, should return NaN",
                           Double.NaN,
                           FastMath.max(validA, nanB),
                           0.0);
               
               // Test case where both are NaN
               assertEquals("When both a and b are NaN, should return NaN",
                           Double.NaN,
                           FastMath.max(nanA, nanB),
                           0.0);
               
               // Additional test case where a is valid and greater than b
               double a = 10.0;
               double b = 5.0;
               assertEquals("When a > b, should return a",
                           a,
                           FastMath.max(a, b),
                           0.0);
               
               // Test case where b is valid and greater than a
               double a2 = 5.0;
               double b2 = 10.0;
               assertEquals("When b > a, should return b",
                           b2,
                           FastMath.max(a2, b2),
                           0.0);
           }

 @Test
          public void testMaxWithZeroAndInfinity() {
              // Test cases where a * b is NaN but a + b isn't
              float positiveInfinity = Float.POSITIVE_INFINITY;
              float negativeInfinity = Float.NEGATIVE_INFINITY;
              float positiveZero = 0.0f;
              float negativeZero = -0.0f;
              
              // Original would return infinity (since a + b = infinity which is not NaN)
              // Mutant would return NaN (since a * b = NaN)
              assertEquals("Positive zero and positive infinity should return infinity", 
                  positiveInfinity, 
                  FastMath.max(positiveZero, positiveInfinity), 
                  0.0f);
                  
              assertEquals("Negative zero and positive infinity should return infinity", 
                  positiveInfinity, 
                  FastMath.max(negativeZero, positiveInfinity), 
                  0.0f);
                  
              assertEquals("Positive zero and negative infinity should return zero", 
                  positiveZero, 
                  FastMath.max(positiveZero, negativeInfinity), 
                  0.0f);
                  
              assertEquals("Negative zero and negative infinity should return negative zero", 
                  negativeZero, 
                  FastMath.max(negativeZero, negativeInfinity), 
                  0.0f);
                  
              // Also test the reverse order (b is zero, a is infinity)
              assertEquals("Positive infinity and positive zero should return infinity", 
                  positiveInfinity, 
                  FastMath.max(positiveInfinity, positiveZero), 
                  0.0f);
                  
              assertEquals("Positive infinity and negative zero should return infinity", 
                  positiveInfinity, 
                  FastMath.max(positiveInfinity, negativeZero), 
                  0.0f);
                  
              assertEquals("Negative infinity and positive zero should return zero", 
                  positiveZero, 
                  FastMath.max(negativeInfinity, positiveZero), 
                  0.0f);
                  
              assertEquals("Negative infinity and negative zero should return negative zero", 
                  negativeZero, 
                  FastMath.max(negativeInfinity, negativeZero), 
                  0.0f);
          }

 @Test
          public void testMaxWithNaN4() {
              // Test case that will catch the mutant
              float zero = 0.0f;
              float nan = Float.NaN;
              float infinity = Float.POSITIVE_INFINITY;
              
              // Original behavior should return NaN when either argument is NaN
              // This will fail with the mutant because:
              // - Original: isNaN(a + b) would return true for (0, NaN)
              // - Mutant: isNaN(a * b) would return true for (0, NaN)
              // But also:
              // - For (0, infinity):
              //   - Original: isNaN(0 + infinity) = false
              //   - Mutant: isNaN(0 * infinity) = true
              
              // Test with zero and NaN
              assertTrue("Should return NaN when first argument is NaN", 
                  Float.isNaN(FastMath.max(nan, zero)));
              assertTrue("Should return NaN when second argument is NaN",
                  Float.isNaN(FastMath.max(zero, nan)));
                  
              // Test with zero and infinity - this will catch the mutant
              assertEquals("Should return infinity for (0, infinity)",
                  infinity, FastMath.max(zero, infinity), 0.0f);
              assertEquals("Should return infinity for (infinity, 0)",
                  infinity, FastMath.max(infinity, zero), 0.0f);
                  
              // Additional edge cases
              assertTrue("Should return NaN when both arguments are NaN",
                  Float.isNaN(FastMath.max(nan, nan)));
              assertEquals("Should handle negative infinity",
                  zero, FastMath.max(zero, Float.NEGATIVE_INFINITY), 0.0f);
          }

 @Test
          public void testMaxWithNaNInput() {
              // Case where a is NaN - sum and product are both NaN
              double a = Double.NaN;
              double b = 5.0;
              assertEquals(Double.NaN, FastMath.max(a, b), 0.0);
              
              // Case where b is NaN - sum and product are both NaN
              a = 5.0;
              b = Double.NaN;
              assertEquals(Double.NaN, FastMath.max(a, b), 0.0);
          }

 @Test
          public void testMaxWithInfinity() {
              // Case where sum is NaN but product is -Infinity
              double a = Double.POSITIVE_INFINITY;
              double b = Double.NEGATIVE_INFINITY;
              assertEquals(Double.NaN, FastMath.max(a, b), 0.0);
              
              // Case where product is NaN but sum is 0.0
              a = 0.0;
              b = Double.NaN;
              assertEquals(Double.NaN, FastMath.max(a, b), 0.0);
          }

 @Test
          public void testMaxRegularNumbers() {
              // Regular case where neither sum nor product is NaN
              double a = 3.0;
              double b = 5.0;
              assertEquals(5.0, FastMath.max(a, b), 0.0);
              
              a = 5.0;
              b = 3.0;
              assertEquals(5.0, FastMath.max(a, b), 0.0);
          }

 @Test
     public void testMaxWithInfinities() {
         // Test case that catches the mutant
         float a = Float.POSITIVE_INFINITY;
         float b = Float.NEGATIVE_INFINITY;
         
         // Original behavior: should return NaN because a + b is NaN
         // Mutant behavior: would return NEGATIVE_INFINITY because a * b is -Infinity
         assertTrue("Should return NaN for INFINITY + -INFINITY", 
                   Float.isNaN(FastMath.max(a, b)));
         
         // Additional edge cases for completeness
         assertEquals("Should return POSITIVE_INFINITY when both are POSITIVE_INFINITY",
                     Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY), 0.0f);
         assertEquals("Should return POSITIVE_INFINITY when comparing POSITIVE_INFINITY and finite",
                     Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, 100.0f), 0.0f);
         assertEquals("Should return POSITIVE_INFINITY when comparing finite and POSITIVE_INFINITY",
                     Float.POSITIVE_INFINITY, FastMath.max(100.0f, Float.POSITIVE_INFINITY), 0.0f);
         assertEquals("Should return finite value when comparing NEGATIVE_INFINITY and finite",
                     100.0f, FastMath.max(Float.NEGATIVE_INFINITY, 100.0f), 0.0f);
     }

 @Test
     public void testMaxFloatWithNaNCase() {
         // Test case where a + b is NaN but a / b is not NaN
         float posInf = Float.POSITIVE_INFINITY;
         float negInf = Float.NEGATIVE_INFINITY;
         
         // Original would return NaN, mutant would return posInf
         assertEquals(Float.NaN, FastMath.max(posInf, negInf), 0.0f);
         
         // Test with zero and infinity cases
         float zero = 0.0f;
         assertEquals(Float.NaN, FastMath.max(posInf, -posInf), 0.0f);
         assertEquals(Float.NaN, FastMath.max(posInf, zero), 0.0f);
         assertEquals(Float.NaN, FastMath.max(negInf, zero), 0.0f);
         
         // Regular number cases should work the same
         assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
         assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
         assertEquals(5.0f, FastMath.max(5.0f, 5.0f), 0.0f);
         
         // Test with actual NaN values
         float nan = Float.NaN;
         assertEquals(nan, FastMath.max(nan, 5.0f), 0.0f);
         assertEquals(nan, FastMath.max(5.0f, nan), 0.0f);
         assertEquals(nan, FastMath.max(nan, nan), 0.0f);
     }

 @Test
     public void testMaxFloatWithNaN() {
         // Test case where a is NaN and b is 0
         float a = Float.NaN;
         float b = 0.0f;
         // Original would check a+b (NaN+0=NaN) and return NaN
         // Mutant checks a/b (NaN/0=NaN) and returns NaN - same behavior
         // So this case doesn't detect the mutant
         
         // Test case where a is 0 and b is NaN
         a = 0.0f;
         b = Float.NaN;
         // Original: a+b = NaN -> returns NaN
         // Mutant: a/b = 0/NaN = NaN -> returns NaN
         // Still same behavior
         
         // Test case where a is 0 and b is 0
         a = 0.0f;
         b = 0.0f;
         // Original: a+b = 0 -> returns a (0)
         // Mutant: a/b = 0/0 = NaN -> returns NaN
         // This will detect the difference!
         assertEquals(0.0f, FastMath.max(a, b), 0.0f);
         
         // Additional test case where a is very large and b is very small
         a = Float.MAX_VALUE;
         b = Float.MIN_VALUE;
         // Original: a+b = MAX_VALUE (no change) -> returns a
         // Mutant: a/b = infinity -> not NaN -> returns a
         // Same behavior, but good to include for completeness
         assertEquals(Float.MAX_VALUE, FastMath.max(a, b), 0.0f);
     }

 @Test
     public void testMaxWithZeroAndNaN() {
         // This test will catch the mutant
         float nan = Float.NaN;
         float zero = 0.0f;
         
         // Case 1: a is NaN, b is zero
         // Original: a+b is NaN → returns NaN
         // Mutant: a/b is NaN → returns NaN
         // This case won't catch the mutant
         assertEquals(Float.NaN, FastMath.max(nan, zero), 0.0f);
         
         // Case 2: a is zero, b is NaN
         // Original: a+b is NaN → returns NaN
         // Mutant: a/b is 0 → returns NaN (since zero <= NaN is false and a is zero)
         // This case won't catch the mutant
         
         // Case 3: both are zero
         // Original: a+b is 0 → returns 0 (since zero <= zero is true, returns b which is zero)
         // Mutant: a/b is NaN → returns NaN
         assertEquals(0.0f, FastMath.max(zero, zero), 0.0f);
         
         // Case 4: a is infinity, b is zero
         float inf = Float.POSITIVE_INFINITY;
         // Original: a+b is infinity → returns infinity
         // Mutant: a/b is infinity → returns infinity
         // This case won't catch the mutant
         
         // Case 5: a is zero, b is infinity
         // Original: a+b is infinity → returns infinity (since zero <= infinity is true)
         // Mutant: a/b is zero → returns infinity (same as original)
         // This case won't catch the mutant
         
         // Case that will catch the mutant:
         // When a is not NaN, b is NaN, and a > b
         float nonZero = 1.0f;
         // Original: a+b is NaN → returns NaN
         // Mutant: a/b is NaN → returns NaN
         // Still same behavior
         
         // Another case that will catch the mutant:
         // When a is negative zero, b is positive zero
         float negZero = -0.0f;
         float posZero = 0.0f;
         // Original: a+b is 0 → returns posZero (since -0.0 <= 0.0 is true)
         // Mutant: a/b is NaN → returns NaN
         assertEquals(posZero, FastMath.max(negZero, posZero), 0.0f);
     }

 @Test
 public void testMaxWithNaNDetection() {
     // Test case where a+b is NaN but a/b is not (will catch the mutant)
     double a = Double.POSITIVE_INFINITY;
     double b = Double.POSITIVE_INFINITY;
     
     // Original would return NaN (since inf + inf is NaN)
     // Mutant would return Infinity (since inf/inf is NaN, but the condition is reversed)
     assertEquals(Double.NaN, FastMath.max(a, b));
     
     // Test case with regular numbers where a > b
     assertEquals(5.0, FastMath.max(5.0, 3.0));
     
     // Test case with regular numbers where b > a
     assertEquals(5.0, FastMath.max(3.0, 5.0));
     
     // Test case with one NaN
     assertEquals(Double.NaN, FastMath.max(Double.NaN, 5.0));
     assertEquals(Double.NaN, FastMath.max(5.0, Double.NaN));
     
     // Test case with both NaN
     assertEquals(Double.NaN, FastMath.max(Double.NaN, Double.NaN));
     
     // Test case with zero and infinity
     assertEquals(Double.POSITIVE_INFINITY, FastMath.max(0.0, Double.POSITIVE_INFINITY));
     
     // Test case with zero and NaN
     assertEquals(Double.NaN, FastMath.max(0.0, Double.NaN));
 }

}
