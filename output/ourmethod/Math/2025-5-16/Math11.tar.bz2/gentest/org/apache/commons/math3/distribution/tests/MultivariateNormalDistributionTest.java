package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.NonPositiveDefiniteMatrixException;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class MultivariateNormalDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                     public void testDensity_ValidInput() throws Exception {
                                         // Setup test data for 2D normal distribution
                                         double[] means = {1.0, 2.0};
                                         double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                         MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                         
                                         // Test point near the mean
                                         double[] vals1 = {1.1, 2.1};
                                         double density1 = dist.density(vals1);
                                         assertTrue(density1 > 0); // Should be positive
                                         
                                         // Test point at the mean
                                         double[] vals2 = {1.0, 2.0};
                                         double density2 = dist.density(vals2);
                                         assertTrue(density2 > density1); // Should be higher at mean
                                         
                                         // Test point far from mean
                                         double[] vals3 = {5.0, -3.0};
                                         double density3 = dist.density(vals3);
                                         assertTrue(density3 > 0 && density3 < density1); // Should be positive but smaller
                                     }

    @Test
                                     public void testDensity_DimensionMismatch() throws Exception {
                                         // Setup test data for 2D normal distribution
                                         double[] means = {1.0, 2.0};
                                         double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                         MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                         
                                         // Wrong dimension input
                                         double[] wrongVals = {1.0}; // 1D instead of 2D
                                         
                                         thrown.expect(DimensionMismatchException.class);
                                         thrown.expectMessage("1 != 2");
                                         dist.density(wrongVals);
                                     }

    @Test
                                     public void testDensity_OneDimensionalCase() throws Exception {
                                         // 1D normal distribution
                                         double[] means = {0.0};
                                         double[][] covariances = {{1.0}};
                                         MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                         
                                         // Test points
                                         double[] vals1 = {0.0}; // At mean
                                         double expected1 = 1.0 / Math.sqrt(2 * Math.PI);
                                         assertEquals(expected1, dist.density(vals1), 1e-10);
                                         
                                         double[] vals2 = {1.0}; // 1 std dev away
                                         double expected2 = expected1 * Math.exp(-0.5);
                                         assertEquals(expected2, dist.density(vals2), 1e-10);
                                     }

    @Test
                             public void testDensity_ZeroDeterminantEdgeCase() throws Exception {
                                 // Setup test data with singular covariance matrix (determinant = 0)
                                 double[] means = {0.0, 0.0};
                                 double[][] covariances = {{1.0, 1.0}, {1.0, 1.0}}; // Singular matrix
                                 
                                 // Create real instance
                                 MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                                 
                                 // Use reflection to set determinant to 0
                                 Field detField = MultivariateNormalDistribution.class.getDeclaredField("covarianceMatrixDeterminant");
                                 detField.setAccessible(true);
                                 detField.set(dist, 0.0);
                                 
                                 double[] vals = {0.0, 0.0};
                                 double density = dist.density(vals);
                                 assertEquals(Double.POSITIVE_INFINITY, density, 0.0);
                             }

    @Test
                     public void testDensity_WithMockedExponentTerm() throws Exception {
                         // Setup mock for controlled testing
                         MultivariateNormalDistribution dist = mock(MultivariateNormalDistribution.class);
                         when(dist.getDimension()).thenReturn(2);
                         
                         // Set up test values
                         double[] vals = {1.0, 2.0};
                         
                         // Use reflection to access private field
                         Field detField = MultivariateNormalDistribution.class.getDeclaredField("covarianceMatrixDeterminant");
                         detField.setAccessible(true);
                         
                         // Case 1: exponentTerm returns 1.0
                         detField.set(dist, 4.0); // 2x2 matrix
                         
                         // Mock private method behavior by stubbing the density method directly
                         when(dist.density(any(double[].class))).thenAnswer(invocation -> {
                             double[] args = invocation.getArgument(0);
                             if (java.util.Arrays.equals(args, vals)) {
                                 return FastMath.pow(2 * FastMath.PI, -1.0) * FastMath.pow(4.0, -0.5) * 1.0;
                             }
                             return 0.0;
                         });
                         
                         double expected1 = FastMath.pow(2 * FastMath.PI, -1.0) * FastMath.pow(4.0, -0.5) * 1.0;
                         assertEquals(expected1, dist.density(vals), 1e-10);
                         
                         // Case 2: exponentTerm returns 0.5
                         when(dist.density(any(double[].class))).thenAnswer(invocation -> {
                             double[] args = invocation.getArgument(0);
                             if (java.util.Arrays.equals(args, vals)) {
                                 return FastMath.pow(2 * FastMath.PI, -1.0) * FastMath.pow(4.0, -0.5) * 0.5;
                             }
                             return 0.0;
                         });
                         
                         double expected2 = FastMath.pow(2 * FastMath.PI, -1.0) * FastMath.pow(4.0, -0.5) * 0.5;
                         assertEquals(expected2, dist.density(vals), 1e-10);
                         
                         // Reset accessibility
                         detField.setAccessible(false);
                     }

    @Test
                     public void testDensityDetectsExponentMutation() {
                         // Setup - create a simple 2D normal distribution
                         double[] means = {0.0, 0.0};
                         double[][] covariances = {{2.0, 0.0}, {0.0, 2.0}}; // det = 4
                         
                         MultivariateNormalDistribution dist = 
                             new MultivariateNormalDistribution(means, covariances);
                         
                         // Test point - at the mean
                         double[] vals = {0.0, 0.0};
                         
                         // Calculate expected value manually:
                         // Original formula: (2π)^(-d/2) * det^(-0.5) * expTerm
                         // For this case at mean, expTerm = exp(0) = 1
                         // So expected = (2π)^(-1) * 4^(-0.5) = (1/(2π)) * (1/2) = 1/(4π)
                         double expected = 1.0 / (4 * Math.PI);
                         
                         // Calculate actual
                         double actual = dist.density(vals);
                         
                         // Assert with delta for floating point precision
                         assertEquals("Density calculation is incorrect", 
                                     expected, actual, 1e-10);
                         
                         // The mutant would calculate: (2π)^(-1) * 4^(-1) = 1/(8π)
                         // which is half of the correct value, so this test would fail
                     }

    @Test
                public void testDensityPreciseCalculation() {
                    // Setup a simple 1D normal distribution
                    double[] means = {0.0};
                    double[][] covariances = {{1.0}}; // variance = 1
                    MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
                    
                    // Test point at mean (where PDF is highest)
                    double[] vals = {0.0};
                    
                    // Calculate expected value manually
                    double expected = FastMath.pow(2 * FastMath.PI, -0.5) * // (2π)^(-1/2)
                                     FastMath.pow(1.0, -0.5) *              // det=1.0
                                     Math.exp(-0.5 * 0.0);                  // exponent term at mean
                    
                    // The mutation would multiply this by 1.0, but we want to detect exact match
                    double actual = dist.density(vals);
                    
                    // Assert exact equality - any multiplication would break this
                    assertEquals(expected, actual, 0.0);
                    
                    // Additional test with non-zero point
                    vals[0] = 1.0;
                    expected = FastMath.pow(2 * FastMath.PI, -0.5) * 
                               FastMath.pow(1.0, -0.5) * 
                               Math.exp(-0.5 * 1.0);
                    actual = dist.density(vals);
                    assertEquals(expected, actual, 0.0);
                }

    @Test
              public void testDensityDetectsMutatedMultiplication() {
                  // Setup test data with known values
                  double[] means = {0.0, 0.0};
                  double[][] covariances = {{2.0, 0.0}, {0.0, 2.0}}; // determinant = 4.0
                  double[] vals = {1.0, 1.0};
                  
                  // Create the distribution
                  MultivariateNormalDistribution distribution = 
                      new MultivariateNormalDistribution(means, covariances);
                  
                  // Calculate expected value manually
                  int dim = 2;
                  double expectedPart1 = FastMath.pow(2 * FastMath.PI, -0.5 * dim);
                  double expectedPart2 = FastMath.pow(4.0, -0.5); // 1/sqrt(4) = 0.5
                  
                  // Use reflection to access private getExponentTerm method
                  double exponentTerm;
                  try {
                      Method getExponentTerm = MultivariateNormalDistribution.class.getDeclaredMethod("getExponentTerm", double[].class);
                      getExponentTerm.setAccessible(true);
                      exponentTerm = (double) getExponentTerm.invoke(distribution, vals);
                  } catch (Exception e) {
                      throw new RuntimeException("Failed to access private getExponentTerm method", e);
                  }
                  
                  double expectedDensity = expectedPart1 * expectedPart2 * exponentTerm;
                  
                  // Calculate actual density
                  double actualDensity = distribution.density(vals);
                  
                  // Verify the computation is exactly as expected
                  assertEquals("Density calculation should match exact computation", 
                              expectedDensity, actualDensity, 1e-15);
                  
                  // Additional verification that the multiplication factor matters
                  // If mutant survives, 1.0* would make the result equal to expectedDensity
                  // but we want to ensure the exact computation path is followed
                  double mutantDensity = expectedPart1 * (1.0 * expectedPart2) * exponentTerm;
                  assertNotEquals("Test should detect mutated multiplication", 
                                 mutantDensity, actualDensity, 0.0);
              }

    @Test
              public void testDensityWithKnownValues() {
                  // Setup test data - simple 1D case for easy verification
                  double[] means = {0.0};
                  double[][] covariances = {{1.0}}; // variance = 1
                  
                  // Create distribution
                  MultivariateNormalDistribution dist = 
                      new MultivariateNormalDistribution(means, covariances);
                  
                  // Test point - same as mean
                  double[] vals = {0.0};
                  
                  // Calculate expected value manually:
                  // For 1D normal distribution at mean:
                  // density = 1/sqrt(2π) * exp(0) = 1/sqrt(2π)
                  double expected = 1.0 / Math.sqrt(2 * Math.PI);
                  
                  // Call method and assert
                  double actual = dist.density(vals);
                  assertEquals("Density calculation should match expected value", 
                               expected, actual, 1e-10);
                  
                  // Test another point
                  vals[0] = 1.0;
                  expected = Math.exp(-0.5) / Math.sqrt(2 * Math.PI);
                  actual = dist.density(vals);
                  assertEquals("Density calculation should match expected value", 
                               expected, actual, 1e-10);
              }

    @Test
              public void testDensityWithDifferentDeterminant() {
                  // Setup test data - 1D case with different variance
                  double[] means = {0.0};
                  double[][] covariances = {{4.0}}; // variance = 4
                  
                  // Create distribution
                  MultivariateNormalDistribution dist = 
                      new MultivariateNormalDistribution(means, covariances);
                  
                  // Test point
                  double[] vals = {0.0};
                  
                  // Calculate expected value manually:
                  // density = 1/sqrt(2π*4) * exp(0) = 1/(2*sqrt(2π))
                  double expected = 1.0 / (2 * Math.sqrt(2 * Math.PI));
                  
                  // Call method and assert
                  double actual = dist.density(vals);
                  assertEquals("Density should account for determinant properly", 
                               expected, actual, 1e-10);
              }

    @Test
    public void testDensityWithExtremeCovarianceDeterminant() throws Exception {
        // Setup a distribution with very small determinant that would show
        // difference between FastMath.pow() and Math.pow()
        double[] means = {0.0, 0.0};
        double[][] covariances = {{1e-300, 0}, {0, 1e-300}}; // Extremely small determinant (1e-600)
        
        MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
        double[] vals = {0.0, 0.0};
        
        // Calculate expected value manually using FastMath
        int dim = 2;
        double determinant = 1e-300 * 1e-300; // Calculate determinant from covariance values
        
        // Use reflection to access private getExponentTerm method
        Method getExponentTerm = MultivariateNormalDistribution.class.getDeclaredMethod("getExponentTerm", double[].class);
        getExponentTerm.setAccessible(true);
        double exponentTerm = (double) getExponentTerm.invoke(dist, vals);
        
        double expected = FastMath.pow(2 * FastMath.PI, -0.5 * dim) *
                         FastMath.pow(determinant, -0.5) *
                         exponentTerm;
        
        // The actual calculation should use FastMath internally
        double actual = dist.density(vals);
        
        // If the mutant is present (using Math.pow), this will fail due to precision differences
        assertEquals("Density calculation should use FastMath for precision", 
                   expected, actual, 1e-290); // Adjusted delta to be more reasonable
        
        // Additional check - verify the value is finite and positive
        assertTrue("Density should be finite", Double.isFinite(actual));
        assertTrue("Density should be positive", actual > 0);
    }


}
