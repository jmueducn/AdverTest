package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                            public void testCumulativeProbability_MaxIterationsExceeded() throws Exception {
                                                                                                                                                                                                                                                                // Create a mock Erf class that throws MaxIterationsExceededException
                                                                                                                                                                                                                                                                Erf mockErf = mock(Erf.class);
                                                                                                                                                                                                                                                                when(mockErf.erf(anyDouble())).thenThrow(new MaxIterationsExceededException(100));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to replace the Erf class with our mock
                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                    java.lang.reflect.Field field = NormalDistributionImpl.class.getDeclaredField("erf");
                                                                                                                                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                                                                                                                                    Object originalErf = field.get(null);
                                                                                                                                                                                                                                                                    field.set(null, mockErf);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // This should throw MaxIterationsExceededException since x is within 20 standard deviations
                                                                                                                                                                                                                                                                    thrown.expect(MaxIterationsExceededException.class);
                                                                                                                                                                                                                                                                    dist.cumulativeProbability(0.5);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Restore original Erf
                                                                                                                                                                                                                                                                    field.set(null, originalErf);
                                                                                                                                                                                                                                                                } catch (NoSuchFieldException e) {
                                                                                                                                                                                                                                                                    fail("Erf field not found in NormalDistributionImpl");
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                    public void testCumulativeProbability_TypicalValues() throws MathException {
                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0); // Standard normal distribution
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Values from standard normal distribution table
                                                                                                                                                                                                                                                        assertEquals(0.5, dist.cumulativeProbability(0.0), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(0.8413, dist.cumulativeProbability(1.0), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(0.1587, dist.cumulativeProbability(-1.0), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(0.9772, dist.cumulativeProbability(2.0), 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testCumulativeProbability_ExtremeValues() throws MathException {
                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 2.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test values more than 20 standard deviations from mean
                                                                                                                                                                                                                                                        assertEquals(0.0, dist.cumulativeProbability(-30.0), 0.0001); // mean - 20*sd = -30
                                                                                                                                                                                                                                                        assertEquals(1.0, dist.cumulativeProbability(50.0), 0.0001);  // mean + 20*sd = 50
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test values exactly at 20 standard deviations
                                                                                                                                                                                                                                                        assertEquals(0.0, dist.cumulativeProbability(-30.0), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(1.0, dist.cumulativeProbability(50.0), 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testCumulativeProbability_DifferentParameters() throws MathException {
                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(5.0, 0.5);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(0.5, dist.cumulativeProbability(5.0), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(0.9772, dist.cumulativeProbability(6.0), 0.0001); // 2 standard deviations above
                                                                                                                                                                                                                                                        assertEquals(0.0228, dist.cumulativeProbability(4.0), 0.0001); // 2 standard deviations below
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testCumulativeProbability_ZeroStandardDeviation() throws MathException {
                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(5.0, 0.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(0.0, dist.cumulativeProbability(4.9), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(1.0, dist.cumulativeProbability(5.0), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(1.0, dist.cumulativeProbability(5.1), 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testCumulativeProbability_SmallStandardDeviation() throws MathException {
                                                                                                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(5.0, 0.0001);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(0.0, dist.cumulativeProbability(4.9999), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(0.5, dist.cumulativeProbability(5.0), 0.0001);
                                                                                                                                                                                                                                                        assertEquals(1.0, dist.cumulativeProbability(5.0001), 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSetStandardDeviation_ZeroValue_ShouldThrowException() {
                                                                                                                                                                                                                                                        NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                                        normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSetStandardDeviation_NegativeValue_ShouldThrowException() {
                                                                                                                                                                                                                                                        NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                                        normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSetStandardDeviation_PositiveValue_ShouldSetValue() {
                                                                                                                                                                                                                                                        NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                                        normalDistribution.setStandardDeviation(1.0);
                                                                                                                                                                                                                                                        assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                              public void testSetStandardDeviation_NegativeValue_ShouldThrowException1() {
                                                                                                                                                                                                                                                  // This test will catch the mutant because the original code throws for sd <= 0.0,
                                                                                                                                                                                                                                                  // but the mutant only throws for sd == 0.0
                                                                                                                                                                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                                  normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                                                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                              public void testSetStandardDeviation_ZeroValue_ShouldThrowException1() {
                                                                                                                                                                                                                                                  // This test ensures the original behavior for sd == 0.0 is preserved
                                                                                                                                                                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                                  normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                              public void testSetStandardDeviation_PositiveValue_ShouldSetValue1() {
                                                                                                                                                                                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                                  double validSd = 1.0;
                                                                                                                                                                                                                                                  normalDistribution.setStandardDeviation(validSd);
                                                                                                                                                                                                                                                  assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                         public void testSetStandardDeviation_ZeroValue() {
                                                                                                                                                                                                                                             // This should throw IllegalArgumentException for original code
                                                                                                                                                                                                                                             // Will pass if original code is correct
                                                                                                                                                                                                                                             // Will fail (detect mutant) if mutant is present (since mutant won't throw)
                                                                                                                                                                                                                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                             normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                         public void testSetStandardDeviation_NegativeValue() {
                                                                                                                                                                                                                                             // This should throw IllegalArgumentException for original code
                                                                                                                                                                                                                                             // Will pass if original code is correct
                                                                                                                                                                                                                                             // Will fail (detect mutant) if mutant is present (since mutant won't throw)
                                                                                                                                                                                                                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                             normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                         public void testSetStandardDeviation_PositiveValue() {
                                                                                                                                                                                                                                             // Test that valid positive value is set correctly
                                                                                                                                                                                                                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                             double validSd = 2.5;
                                                                                                                                                                                                                                             normalDistribution.setStandardDeviation(validSd);
                                                                                                                                                                                                                                             assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                         public void testSetStandardDeviation_NegativeValue_ThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                                                                                             NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                             thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                             distribution.setStandardDeviation(-1.0);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                         public void testSetStandardDeviation_ZeroValue_ThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                                                                                             NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                             thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                             distribution.setStandardDeviation(0.0);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                         public void testSetStandardDeviation_PositiveValue_SetsCorrectly() {
                                                                                                                                                                                                                                             NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                             distribution.setStandardDeviation(1.5);
                                                                                                                                                                                                                                             assertEquals(1.5, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                        public void testSetStandardDeviation_NonPositiveValue_ThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                            double invalidSd = -1.0;
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Set expectation for exception
                                                                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                                            distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                  public void testSetStandardDeviation_NonPositiveValue() {
                                                                                                                                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                      normalDistribution.setStandardDeviation(0.0); // Should throw IllegalArgumentException
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                  public void testSetStandardDeviation_ValidValue() {
                                                                                                                                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                                                      normalDistribution.setStandardDeviation(1.5);
                                                                                                                                                                                                                                      assertEquals(1.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                  public void testExceptionHandling_NotCatchingGenericException() {
                                                                                                                                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl(); // Create instance
                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                          // Create a situation where IllegalArgumentException might occur
                                                                                                                                                                                                                                          normalDistribution.setStandardDeviation(Double.NaN); // Should trigger exception
                                                                                                                                                                                                                                          fail("Expected exception was not thrown");
                                                                                                                                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                          // This is expected - test passes
                                                                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                                                                          fail("Unexpected exception type caught: " + e.getClass());
                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                             public void testCumulativeProbabilityForExtremeValues() throws Exception {
                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                 double mean = 0.0;
                                                                                                                                                                                                                                 double sd = 1.0;
                                                                                                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Test value between -20 and -10 standard deviations from mean
                                                                                                                                                                                                                                 double x = -15.0;
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Original should return near 0 probability for x < mean - 20*sd
                                                                                                                                                                                                                                 // Mutant would return slightly higher probability for x < mean - 10*sd
                                                                                                                                                                                                                                 double probability = dist.cumulativeProbability(x);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Verify the probability is extremely small (original behavior)
                                                                                                                                                                                                                                 // The exact value might vary, but it should be very close to 0
                                                                                                                                                                                                                                 assertEquals(0.0, probability, 1e-20);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Additional test case exactly at the boundary
                                                                                                                                                                                                                                 double boundaryValue = -10.0;
                                                                                                                                                                                                                                 double boundaryProbability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                                                                                 assertTrue(boundaryProbability > 0.0);
                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                             public void testSetStandardDeviation() {
                                                                                                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Test valid positive value
                                                                                                                                                                                                                                 dist.setStandardDeviation(1.5);
                                                                                                                                                                                                                                 assertEquals(1.5, dist.getStandardDeviation(), 0.0);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Test zero value (should throw exception)
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     dist.setStandardDeviation(0.0);
                                                                                                                                                                                                                                     fail("Expected IllegalArgumentException for zero standard deviation");
                                                                                                                                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                     assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Test negative value (should throw exception)
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     dist.setStandardDeviation(-1.0);
                                                                                                                                                                                                                                     fail("Expected IllegalArgumentException for negative standard deviation");
                                                                                                                                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                     assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                        public void testCumulativeProbabilityBoundaryCondition() throws MathException {
                                                                                                                                                                                                                            // Setup test with mean=0 and standard deviation=1 for simplicity
                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test value that is between -30 and -20 standard deviations from mean
                                                                                                                                                                                                                            // This should be affected by the mutation
                                                                                                                                                                                                                            double testValue = -25.0;
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Get the cumulative probability
                                                                                                                                                                                                                            double probability = dist.cumulativeProbability(testValue);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // The original implementation would treat -25 differently than the mutated one
                                                                                                                                                                                                                            // We know that for extreme values, the probability should be very close to 0
                                                                                                                                                                                                                            // The exact value isn't important, just that it's consistent with the boundary condition
                                                                                                                                                                                                                            assertTrue("Probability should be very small for extreme values", 
                                                                                                                                                                                                                                      probability < 1e-20);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Additional test case right at the original boundary (-20)
                                                                                                                                                                                                                            double boundaryValue = -20.0;
                                                                                                                                                                                                                            double boundaryProbability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                                                                            assertTrue("Probability at -20σ should be extremely small",
                                                                                                                                                                                                                                      boundaryProbability < 1e-20);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test case just inside the original boundary (-19)
                                                                                                                                                                                                                            double insideValue = -19.0;
                                                                                                                                                                                                                            double insideProbability = dist.cumulativeProbability(insideValue);
                                                                                                                                                                                                                            assertTrue("Probability at -19σ should be extremely small",
                                                                                                                                                                                                                                      insideProbability < 1e-20);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testSetStandardDeviation1() {
                                                                                                                                                                                                                            // Test valid input
                                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                            dist.setStandardDeviation(2.5);
                                                                                                                                                                                                                            assertEquals(2.5, dist.getStandardDeviation(), 0.0);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test invalid input
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                dist.setStandardDeviation(0.0);
                                                                                                                                                                                                                                fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                dist.setStandardDeviation(-1.0);
                                                                                                                                                                                                                                fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                   public void testCumulativeProbabilityAtLowerBoundary() throws Exception {
                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                       double mean = 0.0;
                                                                                                                                                                                                                       double sd = 1.0;
                                                                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Test value 20σ below mean
                                                                                                                                                                                                                       double x = mean - 20 * sd;
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Original should return very small probability (effectively 0)
                                                                                                                                                                                                                       // Mutant would return higher probability since it doesn't treat this as extreme
                                                                                                                                                                                                                       double probability = dist.cumulativeProbability(x);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Verify probability is effectively 0 (using epsilon for double comparison)
                                                                                                                                                                                                                       assertEquals(0.0, probability, 1e-10);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Also test a value slightly above the boundary
                                                                                                                                                                                                                       double x2 = mean - 19 * sd;
                                                                                                                                                                                                                       double probability2 = dist.cumulativeProbability(x2);
                                                                                                                                                                                                                       assertTrue(probability2 > 0.0);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testSetStandardDeviationWithPositiveValue() {
                                                                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                       dist.setStandardDeviation(2.5);
                                                                                                                                                                                                                       assertEquals(2.5, dist.getStandardDeviation(), 0.0);
                                                                                                                                                                                                                   }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                   public void testSetStandardDeviationWithZeroValue() {
                                                                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                       dist.setStandardDeviation(0.0);
                                                                                                                                                                                                                   }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                   public void testSetStandardDeviationWithNegativeValue() {
                                                                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                       dist.setStandardDeviation(-1.0);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                              public void testCumulativeProbabilityDetectsMutant() throws Exception {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  double mean = 0.0;
                                                                                                                                                                                                                  double sd = 1.0;
                                                                                                                                                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test with x value that should NOT satisfy original condition
                                                                                                                                                                                                                  // mean - 20*sd = 0 - 20*1 = -20
                                                                                                                                                                                                                  // So we'll test with x = -19 which is > -20
                                                                                                                                                                                                                  double x = -19.0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // In original code, this should NOT take the if branch
                                                                                                                                                                                                                  // But with mutant (if(true)), it will always take the branch
                                                                                                                                                                                                                  double result = distribution.cumulativeProbability(x);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify the result is not what the mutant would produce
                                                                                                                                                                                                                  // For normal distribution, P(X <= -19) should be very close to 0
                                                                                                                                                                                                                  // If mutant is present, it might return a different value
                                                                                                                                                                                                                  assertTrue("Mutant detected: condition always true", 
                                                                                                                                                                                                                            result < 1e-20); // Should be extremely small
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                         public void testSetStandardDeviation_PositiveValue_ShouldSetCorrectly() {
                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                             double validSd = 1.5;
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Act
                                                                                                                                                                                                             normalDistribution.setStandardDeviation(validSd);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Assert
                                                                                                                                                                                                             assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                         public void testSetStandardDeviation_NegativeValue_ShouldThrowException2() {
                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                             double invalidSd = -0.5;
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Assert exception
                                                                                                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                             thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Act
                                                                                                                                                                                                             normalDistribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                     public void testSetStandardDeviation_ZeroValue_ShouldThrowException2() {
                                                                                                                                                                                                         // Arrange
                                                                                                                                                                                                         double invalidSd = 0.0;
                                                                                                                                                                                                         NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Assert exception
                                                                                                                                                                                                         ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                         expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                         expectedException.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Act
                                                                                                                                                                                                         normalDistribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                public void testSetStandardDeviationWithValidSmallPositiveValue() {
                                                                                                                                                                                                    // This test will catch the mutant because it uses a value between 0.0 and 0.5
                                                                                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0); // Initialize with default values
                                                                                                                                                                                                    double smallPositive = 0.1;
                                                                                                                                                                                                    normalDistribution.setStandardDeviation(smallPositive);
                                                                                                                                                                                                    assertEquals(smallPositive, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                public void testSetStandardDeviationWithZeroShouldThrow() {
                                                                                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                    normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                public void testSetStandardDeviationWithNegativeShouldThrow() {
                                                                                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                    normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testSetStandardDeviationWithValidLargePositiveValue() {
                                                                                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                    double largePositive = 1.5;
                                                                                                                                                                                                    normalDistribution.setStandardDeviation(largePositive);
                                                                                                                                                                                                    assertEquals(largePositive, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testSetStandardDeviationWithBoundaryValue() {
                                                                                                                                                                                                    // Test with smallest possible positive value
                                                                                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                                                    double epsilon = Double.MIN_VALUE;
                                                                                                                                                                                                    normalDistribution.setStandardDeviation(epsilon);
                                                                                                                                                                                                    assertEquals(epsilon, normalDistribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testConstructorWithZeroStandardDeviation() {
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        new NormalDistributionImpl(0.0, 0.0);
                                                                                                                                                                                                        fail("Expected IllegalArgumentException for zero standard deviation");
                                                                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                                                                        assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                    }
                                                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                           public void testSetStandardDeviation_ZeroValueShouldThrowException() {
                                                                                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                               normalDist.setStandardDeviation(0.0);
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testSetStandardDeviation_PositiveValueShouldBeSet() {
                                                                                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                               double testValue = 1.5;
                                                                                                                                                                                               normalDist.setStandardDeviation(testValue);
                                                                                                                                                                                               assertEquals(testValue, normalDist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                           }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                           public void testSetStandardDeviation_NegativeValueShouldThrowException() {
                                                                                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                               normalDist.setStandardDeviation(-1.0);
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                      public void testCumulativeProbabilityForLargeXValues() throws MathException {
                                                                                                                                                                                          // Setup normal distribution with mean=0, sd=1
                                                                                                                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                          
                                                                                                                                                                                          // Test value between 10 and 20 standard deviations from mean
                                                                                                                                                                                          double x = 15.0; // 15 is between 10 and 20
                                                                                                                                                                                          
                                                                                                                                                                                          // Expected value should be very close to 1 (practically 1.0 for normal distribution)
                                                                                                                                                                                          double expected = 1.0;
                                                                                                                                                                                          double actual = dist.cumulativeProbability(x);
                                                                                                                                                                                          
                                                                                                                                                                                          // The original implementation should return practically 1.0
                                                                                                                                                                                          // The mutant might return something different if it treats x>10*sd specially
                                                                                                                                                                                          assertEquals("Cumulative probability for x=15 should be practically 1.0", 
                                                                                                                                                                                                       expected, actual, 1e-10);
                                                                                                                                                                                          
                                                                                                                                                                                          // Additional test case exactly at the mutant boundary
                                                                                                                                                                                          x = 10.0;
                                                                                                                                                                                          actual = dist.cumulativeProbability(x);
                                                                                                                                                                                          assertEquals("Cumulative probability for x=10 should be practically 1.0",
                                                                                                                                                                                                       expected, actual, 1e-10);
                                                                                                                                                                                          
                                                                                                                                                                                          // Test value just above 20 standard deviations
                                                                                                                                                                                          x = 21.0;
                                                                                                                                                                                          actual = dist.cumulativeProbability(x);
                                                                                                                                                                                          assertEquals("Cumulative probability for x=21 should be practically 1.0",
                                                                                                                                                                                                       expected, actual, 1e-10);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testCumulativeProbabilityAtExtremeValues() throws MathException {
                                                                                                                                                                                     // Setup normal distribution with mean=0, sd=1
                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test values around the original boundary (20*sd)
                                                                                                                                                                                     double x1 = 20.0;  // exactly at original boundary
                                                                                                                                                                                     double x2 = 20.1;  // just above original boundary
                                                                                                                                                                                     double x3 = 30.0;  // exactly at mutant boundary
                                                                                                                                                                                     double x4 = 30.1;  // just above mutant boundary
                                                                                                                                                                                     
                                                                                                                                                                                     // For standard normal distribution, probability >20sd should be extremely small
                                                                                                                                                                                     // (practically 1.0 when represented as cumulative probability)
                                                                                                                                                                                     double probAt20 = dist.cumulativeProbability(x1);
                                                                                                                                                                                     double probJustAbove20 = dist.cumulativeProbability(x2);
                                                                                                                                                                                     double probAt30 = dist.cumulativeProbability(x3);
                                                                                                                                                                                     double probJustAbove30 = dist.cumulativeProbability(x4);
                                                                                                                                                                                     
                                                                                                                                                                                     // All these probabilities should be effectively 1.0 for practical purposes
                                                                                                                                                                                     // The original would treat x>20sd as extreme, mutant would only treat x>30sd as extreme
                                                                                                                                                                                     assertEquals(1.0, probAt20, 1e-10);
                                                                                                                                                                                     assertEquals(1.0, probJustAbove20, 1e-10);
                                                                                                                                                                                     assertEquals(1.0, probAt30, 1e-10);
                                                                                                                                                                                     assertEquals(1.0, probJustAbove30, 1e-10);
                                                                                                                                                                                     
                                                                                                                                                                                     // More precise test - the difference between probJustAbove20 and probAt20 
                                                                                                                                                                                     // should be extremely small (original would have bigger difference)
                                                                                                                                                                                     double diff20 = probJustAbove20 - probAt20;
                                                                                                                                                                                     assertTrue(diff20 < 1e-20);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testSetStandardDeviationWithInvalidValue() {
                                                                                                                                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                     try {
                                                                                                                                                                                         distribution.setStandardDeviation(0.0);
                                                                                                                                                                                         fail("Expected IllegalArgumentException");
                                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                                         assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                     }
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testSetStandardDeviationWithValidValue() {
                                                                                                                                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                     double validSd = 2.5;
                                                                                                                                                                                     distribution.setStandardDeviation(validSd);
                                                                                                                                                                                     assertEquals(validSd, distribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                            public void testCumulativeProbabilityForExtremeRightTail() throws MathException {
                                                                                                                                                                                // Setup
                                                                                                                                                                                double mean = 0.0;
                                                                                                                                                                                double sd = 1.0;
                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                
                                                                                                                                                                                // Test value that is > mean + 20*sd (extreme right tail)
                                                                                                                                                                                double extremeValue = mean + 21 * sd;
                                                                                                                                                                                
                                                                                                                                                                                // In original code, this should be treated as extreme right tail (probability ~1.0)
                                                                                                                                                                                // In mutated code, it would be treated differently since boundary is now mean - 20*sd
                                                                                                                                                                                double probability = distribution.cumulativeProbability(extremeValue);
                                                                                                                                                                                
                                                                                                                                                                                // Assert that probability is very close to 1.0 (as per original behavior)
                                                                                                                                                                                assertEquals(1.0, probability, 1e-10);
                                                                                                                                                                                
                                                                                                                                                                                // Also test a value between mean - 20*sd and mean + 20*sd
                                                                                                                                                                                double midValue = mean + 10 * sd;
                                                                                                                                                                                double midProbability = distribution.cumulativeProbability(midValue);
                                                                                                                                                                                assertTrue(midProbability > 0.0 && midProbability < 1.0);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                       public void testCumulativeProbabilityForExtremePositiveValue() throws MathException {
                                                                                                                                                                           // Setup with mean 0 and standard deviation 1
                                                                                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                           
                                                                                                                                                                           // Test with a value 21 standard deviations above mean
                                                                                                                                                                           // Original should return 1.0 (or very close to it) for such extreme values
                                                                                                                                                                           // Mutant would return a different value since it skips the special case
                                                                                                                                                                           double extremeValue = 0.0 + 21 * 1.0;
                                                                                                                                                                           double probability = dist.cumulativeProbability(extremeValue);
                                                                                                                                                                           
                                                                                                                                                                           // The original should return approximately 1.0 for values this far out
                                                                                                                                                                           assertEquals(1.0, probability, 0.0001);
                                                                                                                                                                           
                                                                                                                                                                           // Alternative test: verify it's greater than the value at 20 standard deviations
                                                                                                                                                                           double valueAt20StdDev = dist.cumulativeProbability(20.0);
                                                                                                                                                                           assertTrue(probability > valueAt20StdDev);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                       public void testSetStandardDeviation_ZeroValue_ShouldThrowException3() {
                                                                                                                                                                           // Arrange
                                                                                                                                                                           NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                           double invalidSd = 0.0;
                                                                                                                                                                           
                                                                                                                                                                           // Expect exception
                                                                                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                           thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                           
                                                                                                                                                                           // Act
                                                                                                                                                                           distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                           
                                                                                                                                                                           // Assert - exception should be thrown before reaching here
                                                                                                                                                                           // Additional check to ensure field wasn't modified
                                                                                                                                                                           assertEquals(1.0, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                       public void testSetStandardDeviation_PositiveValue_ShouldSetCorrectly1() {
                                                                                                                                                                           // Arrange
                                                                                                                                                                           NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                           double validSd = 2.5;
                                                                                                                                                                           
                                                                                                                                                                           // Act
                                                                                                                                                                           distribution.setStandardDeviation(validSd);
                                                                                                                                                                           
                                                                                                                                                                           // Assert
                                                                                                                                                                           assertEquals(validSd, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                       public void testSetStandardDeviation_NegativeValue_ShouldThrowException3() {
                                                                                                                                                                           // Arrange
                                                                                                                                                                           NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                           double invalidSd = -1.0;
                                                                                                                                                                           
                                                                                                                                                                           // Expect exception
                                                                                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                           thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                           
                                                                                                                                                                           // Act
                                                                                                                                                                           distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                           
                                                                                                                                                                           // Assert - exception should be thrown before reaching here
                                                                                                                                                                           // Additional check to ensure field wasn't modified
                                                                                                                                                                           assertEquals(1.0, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                 public void testSetStandardDeviationBoundaryConditions() {
                                                                                                                                                                     NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                     
                                                                                                                                                                     // Test original boundary (0.0)
                                                                                                                                                                     try {
                                                                                                                                                                         normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                         fail("Should have thrown IllegalArgumentException for 0.0");
                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                         assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // Test values around mutated boundary (0.5)
                                                                                                                                                                     try {
                                                                                                                                                                         normalDistribution.setStandardDeviation(0.4);
                                                                                                                                                                         fail("Should have thrown IllegalArgumentException for 0.4 if mutant exists");
                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                         // This will only pass if mutant exists
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // Test acceptance of small positive value
                                                                                                                                                                     normalDistribution.setStandardDeviation(0.1);
                                                                                                                                                                     assertEquals(0.1, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                     
                                                                                                                                                                     // Test acceptance of value just above mutated boundary
                                                                                                                                                                     normalDistribution.setStandardDeviation(0.6);
                                                                                                                                                                     assertEquals(0.6, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                 }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                            public void testSetStandardDeviation_ZeroValue_ShouldThrowException4() {
                                                                                                                                                                // This test will fail on the mutated version (which would accept 0.0)
                                                                                                                                                                NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSetStandardDeviation_ZeroValue_ShouldNotSetField() {
                                                                                                                                                                NormalDistributionImpl normalDistribution = new NormalDistributionImpl(); // Default constructor sets mean=0.0, sd=1.0
                                                                                                                                                                try {
                                                                                                                                                                    normalDistribution.setStandardDeviation(0.0);
                                                                                                                                                                    fail("Expected IllegalArgumentException for zero standard deviation");
                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                    // Verify field wasn't changed
                                                                                                                                                                    assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                }
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSetStandardDeviation_PositiveValue_ShouldSetField() {
                                                                                                                                                                NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                normalDistribution.setStandardDeviation(2.5);
                                                                                                                                                                assertEquals(2.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                            public void testSetStandardDeviation_NegativeValue_ShouldThrowException4() {
                                                                                                                                                                NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                                                normalDistribution.setStandardDeviation(-1.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException() {
                                                                                                                                                                // Arrange
                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                double invalidSd = 0.0; // non-positive value
                                                                                                                                                                
                                                                                                                                                                // Expect
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                
                                                                                                                                                                // Act
                                                                                                                                                                distribution.setStandardDeviation(invalidSd);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSetStandardDeviation_NegativeValue_ThrowsIllegalArgumentException() {
                                                                                                                                                                // Arrange
                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                double invalidSd = -1.0; // negative value
                                                                                                                                                                
                                                                                                                                                                // Expect
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                
                                                                                                                                                                // Act
                                                                                                                                                                distribution.setStandardDeviation(invalidSd);
                                                                                                                                                            }

    @Test
                                                                                                                                                           public void testSetStandardDeviation_NonPositiveValue_ShouldThrowException() {
                                                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                               
                                                                                                                                                               // Set expectation for original behavior
                                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                                               thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                               
                                                                                                                                                               // Try to set invalid standard deviation
                                                                                                                                                               distribution.setStandardDeviation(-1.0);
                                                                                                                                                               
                                                                                                                                                               // If we reach here (no exception), the test will fail
                                                                                                                                                               // Additional check to ensure standard deviation wasn't set to 0.5 (mutant behavior)
                                                                                                                                                               assertNotEquals("Standard deviation should not be set to 0.5 for invalid input", 
                                                                                                                                                                               0.5, distribution.getStandardDeviation(), 0.0);
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testSetStandardDeviation_ZeroValue_ShouldThrowException5() {
                                                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                               
                                                                                                                                                               // Set expectation for original behavior
                                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                                               thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                               
                                                                                                                                                               // Try to set invalid standard deviation
                                                                                                                                                               distribution.setStandardDeviation(0.0);
                                                                                                                                                               
                                                                                                                                                               // Additional check to ensure standard deviation wasn't set to 0.5 (mutant behavior)
                                                                                                                                                               assertNotEquals("Standard deviation should not be set to 0.5 for invalid input", 
                                                                                                                                                                               0.5, distribution.getStandardDeviation(), 0.0);
                                                                                                                                                           }

    @Test
                                                                                                                                                          public void testSetStandardDeviation_positiveValue() {
                                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                              double testValue = 1.5;
                                                                                                                                                              dist.setStandardDeviation(testValue);
                                                                                                                                                              assertEquals("Positive value should be set as-is", 
                                                                                                                                                                           testValue, dist.getStandardDeviation(), 0.0);
                                                                                                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                          public void testSetStandardDeviation_zeroValue() {
                                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                              dist.setStandardDeviation(0.0);
                                                                                                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                          public void testSetStandardDeviation_negativeValue() {
                                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                              dist.setStandardDeviation(-1.0);
                                                                                                                                                          }

    @Test
                                                                                                                                                          public void testSetStandardDeviation_negativeValueGreaterThanZero() {
                                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                              double testValue = -0.5;
                                                                                                                                                              try {
                                                                                                                                                                  dist.setStandardDeviation(testValue);
                                                                                                                                                                  // This should fail for original implementation (should throw exception)
                                                                                                                                                                  fail("Expected IllegalArgumentException for negative value");
                                                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                                                  // Expected for original implementation
                                                                                                                                                              }
                                                                                                                                                              
                                                                                                                                                              // For mutated version that passes the check, verify stored value
                                                                                                                                                              if (dist.getStandardDeviation() != 0.0) { // Only if exception wasn't thrown
                                                                                                                                                                  assertEquals("Mutated version should store absolute value", 
                                                                                                                                                                               Math.abs(testValue), dist.getStandardDeviation(), 0.0);
                                                                                                                                                              }
                                                                                                                                                          }

    @Test
                                                                                                                                                    public void testCumulativeProbabilityForExtremeLeftTail() throws MathException {
                                                                                                                                                        // Setup normal distribution with mean 0 and SD 1
                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                        
                                                                                                                                                        // Test value between -20 and -10 SDs from mean
                                                                                                                                                        double testValue = -15.0;
                                                                                                                                                        
                                                                                                                                                        // Calculate expected probability (should be very close to 0)
                                                                                                                                                        // In original version, -15 would be considered in extreme left tail
                                                                                                                                                        // In mutated version, -15 would be processed normally
                                                                                                                                                        double originalProbability = 0.0; // Expected to be treated as extreme left
                                                                                                                                                        double mutatedProbability = dist.cumulativeProbability(testValue);
                                                                                                                                                        
                                                                                                                                                        // Assert that the probability is 0 (original behavior)
                                                                                                                                                        // This will fail if the mutant is present (where it would calculate actual probability)
                                                                                                                                                        assertEquals("Probability for extreme left tail should be 0", 
                                                                                                                                                                    originalProbability, mutatedProbability, 0.0001);
                                                                                                                                                        
                                                                                                                                                        // Additional check for value just below -10 SD to ensure boundary
                                                                                                                                                        double boundaryValue = -10.1;
                                                                                                                                                        double boundaryProbability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                        assertEquals("Probability just below -10 SD should be 0",
                                                                                                                                                                    0.0, boundaryProbability, 0.0001);
                                                                                                                                                        
                                                                                                                                                        // Check value just above -10 SD should have non-zero probability
                                                                                                                                                        double aboveBoundaryValue = -9.9;
                                                                                                                                                        double aboveBoundaryProb = dist.cumulativeProbability(aboveBoundaryValue);
                                                                                                                                                        assertTrue("Probability just above -10 SD should be > 0",
                                                                                                                                                                  aboveBoundaryProb > 0.0);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testSetStandardDeviation2() {
                                                                                                                                                        // Test valid positive value
                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                        dist.setStandardDeviation(2.5);
                                                                                                                                                        assertEquals(2.5, dist.getStandardDeviation(), 0.0);
                                                                                                                                                        
                                                                                                                                                        // Test zero value
                                                                                                                                                        try {
                                                                                                                                                            dist.setStandardDeviation(0.0);
                                                                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                            assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        // Test negative value
                                                                                                                                                        try {
                                                                                                                                                            dist.setStandardDeviation(-1.0);
                                                                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                            assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                        }
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testCumulativeProbabilityAtLowerBoundary1() throws Exception {
                                                                                                                                                   // Setup
                                                                                                                                                   double mean = 0.0;
                                                                                                                                                   double sd = 1.0;
                                                                                                                                                   NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                   
                                                                                                                                                   // Test value between -30 and -20 standard deviations from mean
                                                                                                                                                   double x = -25.0;
                                                                                                                                                   
                                                                                                                                                   // The original should return a very small probability (effectively 0)
                                                                                                                                                   // The mutant would return a different value since it uses -30*sd as boundary
                                                                                                                                                   double probability = dist.cumulativeProbability(x);
                                                                                                                                                   
                                                                                                                                                   // Assert that the probability is effectively 0 (original behavior)
                                                                                                                                                   assertEquals(0.0, probability, 1e-20);
                                                                                                                                                   
                                                                                                                                                   // Additional test case exactly at -20*sd
                                                                                                                                                   double x2 = -20.0;
                                                                                                                                                   double probability2 = dist.cumulativeProbability(x2);
                                                                                                                                                   assertEquals(0.0, probability2, 1e-20);
                                                                                                                                                   
                                                                                                                                                   // Test case just above -20*sd
                                                                                                                                                   double x3 = -19.999;
                                                                                                                                                   double probability3 = dist.cumulativeProbability(x3);
                                                                                                                                                   assertTrue(probability3 > 0.0);
                                                                                                                                               }

    @Test
                                                                                                                                          public void testCumulativeProbabilityExtremeValues() throws MathException {
                                                                                                                                              // Setup with mean=0 and sd=1 for simplicity
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                              
                                                                                                                                              // Test value far below mean (20 SDs below)
                                                                                                                                              double extremeLow = -20.0;
                                                                                                                                              // Original would treat this as extreme, mutant wouldn't
                                                                                                                                              double probLow = dist.cumulativeProbability(extremeLow);
                                                                                                                                              
                                                                                                                                              // Test value far above mean (20 SDs above)
                                                                                                                                              double extremeHigh = 20.0;
                                                                                                                                              // Mutant would treat this as extreme, original wouldn't
                                                                                                                                              double probHigh = dist.cumulativeProbability(extremeHigh);
                                                                                                                                              
                                                                                                                                              // For extreme low value, original would return very small probability
                                                                                                                                              // (close to 0), mutant would return higher probability
                                                                                                                                              assertTrue("Extreme low value probability should be very small", 
                                                                                                                                                        probLow < 1e-100);
                                                                                                                                              
                                                                                                                                              // For extreme high value, original would return high probability
                                                                                                                                              // (close to 1), mutant would return lower probability
                                                                                                                                              assertTrue("Extreme high value probability should be very close to 1",
                                                                                                                                                        probHigh > 1 - 1e-100);
                                                                                                                                              
                                                                                                                                              // Also test a value that's not extreme for both
                                                                                                                                              double normalValue = 0.5;
                                                                                                                                              double normalProb = dist.cumulativeProbability(normalValue);
                                                                                                                                              assertTrue("Normal value probability should be reasonable",
                                                                                                                                                        normalProb > 0.3 && normalProb < 0.7);
                                                                                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                          public void testSetStandardDeviationWithNonPositiveValue() {
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                              dist.setStandardDeviation(0.0); // Should throw exception
                                                                                                                                          }

    @Test
                                                                                                                                          public void testSetStandardDeviationWithPositiveValue1() {
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                              dist.setStandardDeviation(1.5);
                                                                                                                                              assertEquals(1.5, dist.getStandardDeviation(), 0.0);
                                                                                                                                          }

    @Test
                                                                                                                                     public void testCumulativeProbabilityBoundaryCheck() throws MathException {
                                                                                                                                         // Setup normal distribution with mean 0 and sd 1
                                                                                                                                         NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                         
                                                                                                                                         // Test point that would be outside original boundary (mean - 20*sd)
                                                                                                                                         double x = -21.0; // Original boundary would be -20
                                                                                                                                         
                                                                                                                                         // In original code, this should be handled by boundary check
                                                                                                                                         // With mutation (if(true)), it will always use the boundary logic
                                                                                                                                         double prob = dist.cumulativeProbability(x);
                                                                                                                                         
                                                                                                                                         // Assert that probability is very small but not exactly 0
                                                                                                                                         assertTrue("Probability should be very small for extreme values", 
                                                                                                                                                   prob > 0.0 && prob < 1e-20);
                                                                                                                                         
                                                                                                                                         // Test another point just inside original boundary
                                                                                                                                         double x2 = -19.0;
                                                                                                                                         double prob2 = dist.cumulativeProbability(x2);
                                                                                                                                         
                                                                                                                                         // Should be small but significantly larger than first case
                                                                                                                                         assertTrue("Probability should be larger for values inside boundary",
                                                                                                                                                   prob2 > prob && prob2 < 0.5);
                                                                                                                                     }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                public void testSetStandardDeviation_ZeroValue_ShouldThrowException6() {
                                                                                                                                    // This test will catch the mutant because:
                                                                                                                                    // Original: throws exception for 0.0
                                                                                                                                    // Mutated: will accept 0.0 and not throw exception
                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                    normalDistribution.setStandardDeviation(0.0);
                                                                                                                                }

    @Test
                                                                                                                                public void testSetStandardDeviation_PositiveValue_ShouldSetCorrectly2() {
                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                    double testValue = 1.5;
                                                                                                                                    normalDistribution.setStandardDeviation(testValue);
                                                                                                                                    assertEquals(testValue, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                public void testSetStandardDeviation_NegativeValue_ShouldThrowException5() {
                                                                                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                                    normalDistribution.setStandardDeviation(-0.1);
                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                           public void testSetStandardDeviation_ZeroShouldThrowException() {
                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                               normalDist.setStandardDeviation(0.0);
                                                                                                                           }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                           public void testSetStandardDeviation_NegativeShouldThrowException() {
                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                               normalDist.setStandardDeviation(-0.5);
                                                                                                                           }

    @Test
                                                                                                                           public void testSetStandardDeviation_PositiveValueShouldBeSet1() {
                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                               double validSd = 1.5;
                                                                                                                               normalDist.setStandardDeviation(validSd);
                                                                                                                               assertEquals(validSd, normalDist.getStandardDeviation(), 0.0001);
                                                                                                                           }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                           public void testSetStandardDeviation_BoundaryNegativeOneShouldThrow() {
                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                               normalDist.setStandardDeviation(-1.0); // Mutant's boundary case
                                                                                                                           }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                           public void testSetStandardDeviation_VeryNegativeShouldThrow() {
                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                               normalDist.setStandardDeviation(-2.0); // Well below boundary
                                                                                                                           }

    @Test
                                                                                                                           public void testSetStandardDeviationWithInvalidInput() {
                                                                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                               
                                                                                                                               try {
                                                                                                                                   dist.setStandardDeviation(0.0);
                                                                                                                                   fail("Expected IllegalArgumentException for sd=0.0");
                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                   assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                               }
                                                                                                                               
                                                                                                                               try {
                                                                                                                                   dist.setStandardDeviation(-1.0);
                                                                                                                                   fail("Expected IllegalArgumentException for sd=-1.0");
                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                   assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                               }
                                                                                                                           }

    @Test
                                                                                                                           public void testSetStandardDeviationWithValidInput() {
                                                                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                               
                                                                                                                               dist.setStandardDeviation(2.5);
                                                                                                                               assertEquals(2.5, dist.getStandardDeviation(), 0.0);
                                                                                                                               
                                                                                                                               dist.setStandardDeviation(1e-10); // very small but positive
                                                                                                                               assertEquals(1e-10, dist.getStandardDeviation(), 0.0);
                                                                                                                           }

    @Test
                                                                                                                      public void testCumulativeProbabilityForLargeXValues1() throws MathException {
                                                                                                                          // Setup normal distribution with mean=0, sd=1
                                                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                          
                                                                                                                          // Test value between 10 and 20 standard deviations above mean
                                                                                                                          double x = 15.0;
                                                                                                                          
                                                                                                                          // In original code, this should return a value very close to 1 (since 15 < 20)
                                                                                                                          // In mutated code, this would return a different value since 15 > 10
                                                                                                                          double probability = dist.cumulativeProbability(x);
                                                                                                                          
                                                                                                                          // For a normal distribution, P(X ≤ 15σ) should be extremely close to 1
                                                                                                                          // The mutation would make it return a smaller value
                                                                                                                          assertEquals(1.0, probability, 1e-10);
                                                                                                                          
                                                                                                                          // Also test exactly at the boundary (x = 10)
                                                                                                                          double boundaryProbability = dist.cumulativeProbability(10.0);
                                                                                                                          // Original would process normally, mutated would treat as upper tail
                                                                                                                          assertEquals(1.0, boundaryProbability, 1e-10);
                                                                                                                      }

    @Test
                                                                                                                 public void testCumulativeProbabilityForExtremeValues1() throws MathException {
                                                                                                                     // Setup
                                                                                                                     double mean = 0.0;
                                                                                                                     double sd = 1.0;
                                                                                                                     NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                     
                                                                                                                     // Test value between mean+20*sd and mean+30*sd
                                                                                                                     double testValue = mean + 25 * sd;
                                                                                                                     
                                                                                                                     // In original code, this should return ~1.0 (probability at extreme right tail)
                                                                                                                     // Mutant would return a different value since it doesn't treat this as extreme
                                                                                                                     double probability = distribution.cumulativeProbability(testValue);
                                                                                                                     
                                                                                                                     // Assert the probability is effectively 1.0 (with some tolerance for floating point)
                                                                                                                     assertEquals(1.0, probability, 1e-10);
                                                                                                                     
                                                                                                                     // Also test a value beyond the new threshold to ensure both paths work
                                                                                                                     double extremeValue = mean + 31 * sd;
                                                                                                                     assertEquals(1.0, distribution.cumulativeProbability(extremeValue), 1e-10);
                                                                                                                 }

    @Test
                                                                                                            public void testCumulativeProbabilityForExtremeValues2() throws MathException {
                                                                                                                // Setup with mean 0 and standard deviation 1
                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                
                                                                                                                // Test value that is > mean + 20*sd (20 in this case)
                                                                                                                double extremeRightValue = 21.0;
                                                                                                                
                                                                                                                // In original code, this should be treated as extreme right tail (probability ~1.0)
                                                                                                                // In mutant code, it won't be treated as extreme since 21 > (0 - 20*1) is true
                                                                                                                double originalProbability = dist.cumulativeProbability(extremeRightValue);
                                                                                                                
                                                                                                                // The probability should be very close to 1.0 for such an extreme value
                                                                                                                assertEquals(1.0, originalProbability, 1e-10);
                                                                                                                
                                                                                                                // Test value that is < mean - 20*sd (-20 in this case)
                                                                                                                double extremeLeftValue = -21.0;
                                                                                                                double leftProbability = dist.cumulativeProbability(extremeLeftValue);
                                                                                                                
                                                                                                                // This should be very close to 0.0
                                                                                                                assertEquals(0.0, leftProbability, 1e-10);
                                                                                                                
                                                                                                                // Test value within bounds (between -20 and +20)
                                                                                                                double normalValue = 10.0;
                                                                                                                double normalProbability = dist.cumulativeProbability(normalValue);
                                                                                                                
                                                                                                                // Should be a normal probability value between 0 and 1
                                                                                                                assertTrue(normalProbability > 0.0 && normalProbability < 1.0);
                                                                                                            }

    @Test
                                                                                                       public void testCumulativeProbabilityForExtremePositiveValue1() throws MathException {
                                                                                                           // Setup normal distribution with mean=0, sd=1
                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                           
                                                                                                           // Test value 20 standard deviations above mean (20*1 + 0 = 20)
                                                                                                           double extremeValue = 20.0;
                                                                                                           
                                                                                                           // The cumulative probability should be very close to 1.0
                                                                                                           // (actual value should be > 0.999999999)
                                                                                                           double probability = dist.cumulativeProbability(extremeValue);
                                                                                                           
                                                                                                           // Assert the probability is as expected for extreme positive value
                                                                                                           // Using delta of 1e-10 for double comparison
                                                                                                           assertEquals(1.0, probability, 1e-10);
                                                                                                           
                                                                                                           // For even more extreme value (30 standard deviations)
                                                                                                           double moreExtremeValue = 30.0;
                                                                                                           probability = dist.cumulativeProbability(moreExtremeValue);
                                                                                                           assertEquals(1.0, probability, 1e-10);
                                                                                                       }

    @Test
                                                                                                  public void testSetStandardDeviationPositiveValue() {
                                                                                                      NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                      double validSd = 2.5;
                                                                                                      normalDist.setStandardDeviation(validSd);
                                                                                                      assertEquals(validSd, normalDist.getStandardDeviation(), 0.0001);
                                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                                  public void testSetStandardDeviationNegativeValue() {
                                                                                                      NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                      normalDist.setStandardDeviation(-1.0);
                                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                                  public void testSetStandardDeviationZeroValue() {
                                                                                                      // This test specifically catches the mutant
                                                                                                      NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                      normalDist.setStandardDeviation(0.0);
                                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                             public void testSetStandardDeviation_ZeroValue1() {
                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                 normalDistribution.setStandardDeviation(0.0);
                                                                                             }

    @Test(expected = IllegalArgumentException.class)
                                                                                             public void testSetStandardDeviation_NegativeValue1() {
                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                 normalDistribution.setStandardDeviation(-1.0);
                                                                                             }

    @Test
                                                                                             public void testSetStandardDeviation_PositiveValue1() {
                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                 normalDistribution.setStandardDeviation(1.0);
                                                                                                 assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                             }

    @Test
                                                                                             public void testSetStandardDeviation_SmallPositiveValue() {
                                                                                                 // Create a new normal distribution instance
                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                 // This value (0.1) should be accepted as it's positive
                                                                                                 normalDistribution.setStandardDeviation(0.1);
                                                                                                 // Verify the value was set correctly
                                                                                                 assertEquals(0.1, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                             }

    @Test
                                                                                             public void testSetStandardDeviation_BoundaryValue() {
                                                                                                 // Create a new NormalDistributionImpl object
                                                                                                 NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                 
                                                                                                 // Test value just above mutant's threshold (0.5)
                                                                                                 normalDistribution.setStandardDeviation(0.6);
                                                                                                 assertEquals(0.6, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                             }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testSetStandardDeviation_ZeroValue_ThrowsException() {
                                                                                            // This test will catch the mutant because:
                                                                                            // Original: throws exception for 0.0
                                                                                            // Mutant: allows 0.0 to pass
                                                                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                            normalDistribution.setStandardDeviation(0.0);
                                                                                        }

    @Test
                                                                                        public void testSetStandardDeviation_NegativeValue_ThrowsException() {
                                                                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                            try {
                                                                                                normalDistribution.setStandardDeviation(-1.0);
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testSetStandardDeviation_PositiveValue_SetsField() {
                                                                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                            normalDistribution.setStandardDeviation(1.5);
                                                                                            assertEquals(1.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testSetStandardDeviation_InvalidValue_DoesNotSetField() {
                                                                                            NormalDistributionImpl normalDistribution = new NormalDistributionImpl(); // Default constructor sets mean=0.0, sd=1.0
                                                                                            try {
                                                                                                normalDistribution.setStandardDeviation(-2.0);
                                                                                                fail("Expected IllegalArgumentException");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                // Verify field wasn't changed
                                                                                                assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testSetStandardDeviation_ThrowsIllegalArgumentExceptionForNonPositiveValues() {
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                            
                                                                                            // Test with negative value
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                            distribution.setStandardDeviation(-1.0);
                                                                                        }

    @Test
                                                                                        public void testSetStandardDeviation_ThrowsIllegalArgumentExceptionForZero() {
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                            
                                                                                            // Test with zero
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                            distribution.setStandardDeviation(0.0);
                                                                                        }

    @Test
                                                                                  public void testSetStandardDeviation_ValidInput() {
                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                      double validSd = 1.5;
                                                                                      normalDistribution.setStandardDeviation(validSd);
                                                                                      assertEquals("Standard deviation should be set to the provided positive value",
                                                                                                  validSd, normalDistribution.getStandardDeviation(), 0.0);
                                                                                  }

    @Test
                                                                                  public void testSetStandardDeviation_ZeroInput() {
                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                      thrown.expectMessage("Standard deviation must be positive.");
                                                                                      normalDistribution.setStandardDeviation(0.0);
                                                                                      // If mutant is present, this will fail because it would set sd to 0.5 instead of throwing
                                                                                  }

    @Test
                                                                                  public void testSetStandardDeviation_AfterMutationCheck() {
                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                      try {
                                                                                          normalDistribution.setStandardDeviation(-1.0);
                                                                                          // If we get here, the mutant is present (no exception thrown)
                                                                                          assertEquals("Mutant detected: Should have thrown exception but set sd to 0.5 instead",
                                                                                                      0.5, normalDistribution.getStandardDeviation(), 0.0);
                                                                                      } catch (IllegalArgumentException e) {
                                                                                          // Original behavior - test passes
                                                                                          assertTrue(true);
                                                                                      }
                                                                                  }

    @Test
                                                                              public void testSetStandardDeviation_NegativeInput() {
                                                                                  NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                  
                                                                                  try {
                                                                                      normalDistribution.setStandardDeviation(-1.0);
                                                                                      fail("Expected IllegalArgumentException for negative standard deviation");
                                                                                  } catch (IllegalArgumentException e) {
                                                                                      assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                  }
                                                                                  // If mutant is present, this will fail because it would set sd to 0.5 instead of throwing
                                                                              }

    @Test
                                                                              public void testSetStandardDeviationStoresExactValue() {
                                                                                  // Setup
                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                  double testValue = 2.5; // Positive test value
                                                                                  
                                                                                  // Exercise
                                                                                  distribution.setStandardDeviation(testValue);
                                                                                  
                                                                                  // Verify
                                                                                  assertEquals("Standard deviation should be stored exactly as input", 
                                                                                              testValue, 
                                                                                              distribution.getStandardDeviation(), 
                                                                                              0.0001);
                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                              public void testSetStandardDeviationRejectsZero() {
                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                  distribution.setStandardDeviation(0.0);
                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                              public void testSetStandardDeviationRejectsNegative() {
                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                  distribution.setStandardDeviation(-1.0);
                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                             public void testSetStandardDeviation_NonPositiveValue_ThrowsException() {
                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                 dist.setStandardDeviation(0.0); // Should throw IllegalArgumentException
                                                                             }

    @Test
                                                                             public void testSetStandardDeviation_PositiveValue_SetsCorrectly1() {
                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                 double testValue = 1.5;
                                                                                 dist.setStandardDeviation(testValue);
                                                                                 assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                                                                             }

    @Test(expected = IllegalArgumentException.class)
                                                                             public void testSetStandardDeviation_NegativeValue_ThrowsException1() {
                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                 dist.setStandardDeviation(-1.0); // Should throw IllegalArgumentException
                                                                             }

    @Test
                                                                       public void testCumulativeProbabilityForExtremeLeftTail1() throws org.apache.commons.math.MathException {
                                                                           // Setup
                                                                           double mean = 0.0;
                                                                           double sd = 1.0;
                                                                           NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                           
                                                                           // Test value between -20σ and -10σ (-15 in this case)
                                                                           double x = -15.0;
                                                                           
                                                                           // In original code, x < (mean - 20*sd) would be false (-15 < -20 is false)
                                                                           // In mutated code, x < (mean - 10*sd) would be true (-15 < -10 is true)
                                                                           // Therefore the cumulative probability should be different
                                                                           
                                                                           // Get actual result
                                                                           double result = dist.cumulativeProbability(x);
                                                                           
                                                                           // Verify it's not treating it as extreme left tail (original behavior)
                                                                           // The exact value isn't important, just that it's not 0.0
                                                                           assertTrue("Value should not be treated as extreme left tail", 
                                                                                     result > 0.0);
                                                                           
                                                                           // Additional verification that it's a very small probability
                                                                           assertTrue("Value should have very small probability", 
                                                                                     result < 1e-10);
                                                                       }

    @Test
                                                                       public void testCumulativeProbabilityForVeryExtremeLeftTail() throws org.apache.commons.math.MathException {
                                                                           // Setup
                                                                           double mean = 0.0;
                                                                           double sd = 1.0;
                                                                           NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                           
                                                                           // Test value below -20σ (-25 in this case)
                                                                           double x = -25.0;
                                                                           
                                                                           // Both original and mutated code should treat this as extreme left tail
                                                                           double result = dist.cumulativeProbability(x);
                                                                           
                                                                           // Should be treated as 0 probability in both cases
                                                                           assertEquals(0.0, result, 0.0);
                                                                       }

    @Test
                                                                  public void testCumulativeProbabilityBoundaryCondition1() throws Exception {
                                                                      // Setup
                                                                      double mean = 100.0;
                                                                      double sd = 5.0;
                                                                      NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                      
                                                                      // Calculate boundary values
                                                                      double originalBoundary = mean - 20 * sd;  // 100 - 20*5 = 0
                                                                      double mutatedBoundary = mean - 30 * sd;   // 100 - 30*5 = -50
                                                                      
                                                                      // Test value between the original and mutated boundaries
                                                                      double testValue = -25.0;  // between -50 and 0
                                                                      
                                                                      // The original code would consider this value as extreme (x < mean-20*sd)
                                                                      // The mutated code would NOT consider this as extreme (x >= mean-30*sd)
                                                                      
                                                                      // Verify the behavior
                                                                      double probability = distribution.cumulativeProbability(testValue);
                                                                      
                                                                      // For values below mean-20*sd, the original would return very small probability
                                                                      // The mutated version would return a higher probability since it's above its threshold
                                                                      // So we can detect the mutant by checking if probability is very small
                                                                      assertTrue("Should detect mutant by checking probability value", 
                                                                                 probability < 1e-20);
                                                                  }

    @Test
                                                                  public void testSetStandardDeviationWithValidValue1() {
                                                                      NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                      dist.setStandardDeviation(2.5);
                                                                      assertEquals(2.5, dist.getStandardDeviation(), 0.0);
                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                  public void testSetStandardDeviationWithZero() {
                                                                      NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                      dist.setStandardDeviation(0.0);
                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                  public void testSetStandardDeviationWithNegative() {
                                                                      NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                      dist.setStandardDeviation(-1.0);
                                                                  }

    @Test
                                                             public void testCumulativeProbabilityForExtremeLeftTail2() throws org.apache.commons.math.MathException {
                                                                 // Setup normal distribution with mean=0, sd=1
                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                 
                                                                 // Test extreme left tail value (mean - 25*sd)
                                                                 double x = 0.0 - 25 * 1.0;
                                                                 
                                                                 // Original should give very small probability (but > 0)
                                                                 // Mutant would give much higher probability since it checks wrong tail
                                                                 double probability = dist.cumulativeProbability(x);
                                                                 
                                                                 // Verify probability is very small (original behavior)
                                                                 assertTrue("Probability for extreme left tail should be very small", 
                                                                           probability < 1e-100);
                                                                 
                                                                 // Also verify it's not zero (mathematically should be > 0)
                                                                 assertTrue("Probability should be greater than 0", probability > 0);
                                                             }

    @Test
                                                        public void testCumulativeProbabilityBoundaryCondition2() throws MathException {
                                                            // Setup normal distribution with mean 0 and sd 1
                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                            
                                                            // Test value far below mean (more than 20 standard deviations)
                                                            double x = -21.0; // 21 standard deviations below mean
                                                            
                                                            // Calculate cumulative probability
                                                            double probability = dist.cumulativeProbability(x);
                                                            
                                                            // For x values far below mean, probability should be extremely close to 0
                                                            // The original implementation would handle this properly
                                                            // The mutant (if (true)) would bypass the boundary check and return incorrect value
                                                            assertEquals(0.0, probability, 1e-20);
                                                            
                                                            // Also test a value just above the boundary
                                                            double x2 = -19.0; // 19 standard deviations below mean
                                                            double probability2 = dist.cumulativeProbability(x2);
                                                            // Should be very small but not exactly 0
                                                            assertTrue(probability2 > 0);
                                                        }

    @Test
                                                   public void testSetStandardDeviation_positiveValue1() {
                                                       NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                       double validSd = 1.0;
                                                       normalDistribution.setStandardDeviation(validSd);
                                                       assertEquals(validSd, normalDistribution.getStandardDeviation(), 0.0001);
                                                   }

    @Test
                                                   public void testSetStandardDeviation_negativeValue1() {
                                                       NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                       double invalidSd = -1.0;
                                                       thrown.expect(IllegalArgumentException.class);
                                                       thrown.expectMessage("Standard deviation must be positive.");
                                                       normalDistribution.setStandardDeviation(invalidSd);
                                                   }

    @Test
                                                   public void testSetStandardDeviation_zeroValue1() {
                                                       NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                       double zeroSd = 0.0;
                                                       thrown.expect(IllegalArgumentException.class);
                                                       thrown.expectMessage("Standard deviation must be positive.");
                                                       normalDistribution.setStandardDeviation(zeroSd);
                                                   }

    @Test
                                              public void testSetStandardDeviation_ShouldRejectZero() {
                                                  org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                  org.apache.commons.math.distribution.NormalDistributionImpl normalDist = 
                                                      new org.apache.commons.math.distribution.NormalDistributionImpl();
                                                  
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("Standard deviation must be positive.");
                                                  normalDist.setStandardDeviation(0.0);
                                              }

    @Test
                                              public void testSetStandardDeviation_ShouldRejectNegative() {
                                                  ExpectedException thrown = ExpectedException.none();
                                                  NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                  
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("Standard deviation must be positive.");
                                                  normalDist.setStandardDeviation(-0.1);
                                              }

    @Test
                                              public void testSetStandardDeviation_ShouldRejectSmallPositive() {
                                                  org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                  org.apache.commons.math.distribution.NormalDistributionImpl normalDist = 
                                                      new org.apache.commons.math.distribution.NormalDistributionImpl();
                                                  
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("Standard deviation must be positive.");
                                                  // This test will catch the mutant as it accepts 0.1 when it shouldn't
                                                  normalDist.setStandardDeviation(0.1);
                                              }

    @Test
                                              public void testSetStandardDeviation_ShouldAcceptValidValue() {
                                                  NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                  normalDist.setStandardDeviation(0.6);
                                                  assertEquals(0.6, normalDist.getStandardDeviation(), 0.0001);
                                              }

    @Test
                                              public void testSetStandardDeviation_ShouldAcceptBoundaryValue() {
                                                  // This test ensures the boundary case works correctly
                                                  NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                  normalDist.setStandardDeviation(Double.MIN_VALUE);
                                                  assertEquals(Double.MIN_VALUE, normalDist.getStandardDeviation(), 0.0);
                                              }

    @Test(expected = IllegalArgumentException.class)
                                         public void testSetStandardDeviation_ZeroShouldThrowException1() {
                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                             normalDistribution.setStandardDeviation(0.0);
                                         }

    @Test(expected = IllegalArgumentException.class)
                                         public void testSetStandardDeviation_NegativeShouldThrowException1() {
                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                             normalDistribution.setStandardDeviation(-0.5);
                                         }

    @Test
                                         public void testSetStandardDeviation_PositiveValueShouldBeSet2() {
                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                             double testValue = 1.5;
                                             normalDistribution.setStandardDeviation(testValue);
                                             assertEquals(testValue, normalDistribution.getStandardDeviation(), 0.0001);
                                         }

    @Test(expected = IllegalArgumentException.class)
                                         public void testSetStandardDeviation_BoundaryNegativeValue() {
                                             NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                             normalDistribution.setStandardDeviation(-1.0); // Boundary case for mutant
                                         }

    @Test
                                    public void testCumulativeProbabilityForLargeX() throws MathException {
                                        // Setup with mean=0 and sd=1 for simplicity
                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                        
                                        // Test a value between 10σ and 20σ (15σ in this case)
                                        double x = 15.0;
                                        double result = dist.cumulativeProbability(x);
                                        
                                        // Original should return a value very close to but less than 1.0
                                        // Mutant would return exactly 1.0
                                        assertTrue("Probability should be very close to 1 but not exactly 1", 
                                                  result < 1.0 && result > 0.999999999);
                                        
                                        // Additional test for x > 20σ to ensure both original and mutant return 1.0
                                        double x2 = 25.0;
                                        assertEquals(1.0, dist.cumulativeProbability(x2), 0.0);
                                        
                                        // Test for x < -10σ to check lower bound behavior
                                        double x3 = -15.0;
                                        double result3 = dist.cumulativeProbability(x3);
                                        assertTrue("Probability should be very close to 0 but not exactly 0",
                                                  result3 > 0.0 && result3 < 0.000000001);
                                    }

    @Test
                               public void testCumulativeProbabilityForExtremeValues3() throws Exception {
                                   // Setup with mean=0 and sd=1 for simplicity
                                   NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                   
                                   // Test value that is between 20 and 30 standard deviations from mean
                                   double testValue = 25.0;
                                   
                                   // In original code, this should be extremely close to 1.0 (practically 1.0)
                                   double probability = dist.cumulativeProbability(testValue);
                                   
                                   // The mutant would return a different value since 25 < 30
                                   // Assert that probability is effectively 1.0 (with some tolerance)
                                   assertEquals(1.0, probability, 1e-16);
                                   
                                   // Additional test case exactly at 20 standard deviations
                                   testValue = 20.0;
                                   probability = dist.cumulativeProbability(testValue);
                                   assertEquals(1.0, probability, 1e-16);
                                   
                                   // Test case just above 30 standard deviations
                                   testValue = 30.1;
                                   probability = dist.cumulativeProbability(testValue);
                                   assertEquals(1.0, probability, 1e-16);
                               }

    @Test
                          public void testCumulativeProbabilityForExtremeValues4() throws MathException {
                              // Setup
                              double mean = 0.0;
                              double sd = 1.0;
                              NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                              
                              // Test values that would be affected by the mutation
                              double valueJustAboveUpperBound = mean + 20 * sd + 0.1; // Original would treat this specially
                              double valueJustBelowUpperBound = mean + 20 * sd - 0.1; // Should be treated normally
                              double valueJustAboveMutantBound = mean - 20 * sd + 0.1; // Mutant would treat this specially
                              
                              // Original behavior - value above +20sd should be handled differently
                              double originalProbForUpper = distribution.cumulativeProbability(valueJustAboveUpperBound);
                              double originalProbForBelow = distribution.cumulativeProbability(valueJustBelowUpperBound);
                              
                              // These assertions would fail if the mutant is present
                              assertNotEquals("Values above +20sd should be handled differently", 
                                             originalProbForUpper, originalProbForBelow, 0.0001);
                              
                              // Additional test for the mutant's changed condition
                              double probForMutantBound = distribution.cumulativeProbability(valueJustAboveMutantBound);
                              double probForNormalValue = distribution.cumulativeProbability(mean); // A normal value
                              
                              // This assertion would fail if the mutant is present
                              assertEquals("Values above -20sd should be treated normally", 
                                          probForNormalValue, probForMutantBound, 0.0001);
                          }

    @Test
                     public void testCumulativeProbabilityForLargeX1() throws Exception {
                         // Setup normal distribution with mean=0 and sd=1
                         NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                         
                         // Test value that is more than 20 standard deviations above mean
                         double x = 21.0; // 21 > 0 + 20*1
                         
                         // The original should return very close to 1.0 for this case
                         double probability = dist.cumulativeProbability(x);
                         
                         // Assert the probability is very close to 1 (within small epsilon)
                         assertEquals(1.0, probability, 1e-10);
                         
                         // The mutant would return something else since it skips this case
                     }

    @Test(expected = IllegalArgumentException.class)
                public void testSetStandardDeviation_ZeroValueShouldThrowException1() {
                    NormalDistributionImpl normalDist = new NormalDistributionImpl();
                    normalDist.setStandardDeviation(0.0);
                }

    @Test
                public void testSetStandardDeviation_ZeroValueShouldNotSetField() {
                    NormalDistributionImpl normalDist = new NormalDistributionImpl(); // Default constructor sets mean=0.0, sd=1.0
                    try {
                        normalDist.setStandardDeviation(0.0);
                        fail("Expected IllegalArgumentException");
                    } catch (IllegalArgumentException e) {
                        // Expected exception
                    }
                    // Verify field wasn't changed
                    assertEquals(1.0, normalDist.getStandardDeviation(), 0.0001);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testSetStandardDeviation_NegativeValueShouldThrowException1() {
                    NormalDistributionImpl normalDist = new NormalDistributionImpl();
                    normalDist.setStandardDeviation(-1.0);
                }

    @Test
                public void testSetStandardDeviation_PositiveValueShouldSetField() {
                    NormalDistributionImpl normalDist = new NormalDistributionImpl();
                    normalDist.setStandardDeviation(2.5);
                    assertEquals(2.5, normalDist.getStandardDeviation(), 0.0001);
                }

    @Test
                public void testSetStandardDeviation_ShouldRejectNonPositiveValues() {
                    NormalDistributionImpl dist = new NormalDistributionImpl();
                    
                    // Test that 0.0 is rejected
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Standard deviation must be positive.");
                    dist.setStandardDeviation(0.0);
                    
                    // Test that negative values are rejected
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Standard deviation must be positive.");
                    dist.setStandardDeviation(-1.0);
                }

    @Test
                public void testSetStandardDeviation_ShouldRejectValuesBelowThreshold() {
                    NormalDistributionImpl dist = new NormalDistributionImpl();
                    
                    // Test values between 0.0 and 0.5 that should be rejected
                    // This will catch the mutant since original would reject these
                    try {
                        dist.setStandardDeviation(0.1);
                        fail("Should have thrown IllegalArgumentException for 0.1");
                    } catch (IllegalArgumentException e) {
                        assertEquals("Standard deviation must be positive.", e.getMessage());
                    }
                    
                    try {
                        dist.setStandardDeviation(0.49);
                        fail("Should have thrown IllegalArgumentException for 0.49");
                    } catch (IllegalArgumentException e) {
                        assertEquals("Standard deviation must be positive.", e.getMessage());
                    }
                }

    @Test
                public void testSetStandardDeviation_ShouldAcceptValidValues() {
                    NormalDistributionImpl dist = new NormalDistributionImpl();
                    
                    // Test valid positive values
                    dist.setStandardDeviation(0.5);
                    assertEquals(0.5, dist.getStandardDeviation(), 0.0);
                    
                    dist.setStandardDeviation(1.0);
                    assertEquals(1.0, dist.getStandardDeviation(), 0.0);
                    
                    dist.setStandardDeviation(100.0);
                    assertEquals(100.0, dist.getStandardDeviation(), 0.0);
                }

    @Test(expected = IllegalArgumentException.class)
          public void testSetStandardDeviation_ZeroValue2() {
              // This should throw exception for original code
              // But will pass silently for mutated code
              NormalDistributionImpl normalDist = new NormalDistributionImpl();
              normalDist.setStandardDeviation(0.0);
          }

    @Test
          public void testSetStandardDeviation_NegativeValue2() {
              NormalDistributionImpl normalDist = new NormalDistributionImpl();
              try {
                  normalDist.setStandardDeviation(-1.0);
                  fail("Expected IllegalArgumentException for negative value");
              } catch (IllegalArgumentException e) {
                  // Expected behavior
                  assertEquals("Standard deviation must be positive.", e.getMessage());
              }
          }

    @Test
          public void testSetStandardDeviation_PositiveValue2() {
              NormalDistributionImpl normalDist = new NormalDistributionImpl();
              double testValue = 1.5;
              normalDist.setStandardDeviation(testValue);
              assertEquals(testValue, normalDist.getStandardDeviation(), 0.0001);
          }

    @Test
          public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException1() {
              NormalDistributionImpl distribution = new NormalDistributionImpl();
              
              // Expect IllegalArgumentException when setting non-positive standard deviation
              thrown.expect(IllegalArgumentException.class);
              thrown.expectMessage("Standard deviation must be positive.");
              
              // Test with 0.0 (boundary case)
              distribution.setStandardDeviation(0.0);
          }

    @Test
          public void testSetStandardDeviation_NegativeValue_ThrowsIllegalArgumentException1() {
              NormalDistributionImpl distribution = new NormalDistributionImpl();
              
              // Expect IllegalArgumentException when setting negative standard deviation
              thrown.expect(IllegalArgumentException.class);
              thrown.expectMessage("Standard deviation must be positive.");
              
              // Test with negative value
              distribution.setStandardDeviation(-1.0);
          }

    @Test
          public void testSetStandardDeviation_PositiveValue_SetsCorrectly2() {
              NormalDistributionImpl distribution = new NormalDistributionImpl();
              double validSd = 1.5;
              
              // Test with positive value
              distribution.setStandardDeviation(validSd);
              
              // Verify the value was set correctly
              assertEquals(validSd, distribution.getStandardDeviation(), 0.0);
          }

    @Test(expected = IllegalArgumentException.class)
    public void testSetStandardDeviation_NonPositiveValue_ShouldThrowException1() {
        // Arrange - create new distribution with default values (mean=0.0, sd=1.0)
        NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
        double originalSd = normalDistribution.getStandardDeviation();
        double invalidSd = -0.5;
        
        try {
            // Act
            normalDistribution.setStandardDeviation(invalidSd);
            // If we get here, the mutation survived (returned 0.5 instead of throwing)
            fail("Expected IllegalArgumentException but none was thrown");
        } catch (IllegalArgumentException e) {
            // Assert exception message
            assertEquals("Standard deviation must be positive.", e.getMessage());
            // Assert field wasn't changed
            assertEquals(originalSd, normalDistribution.getStandardDeviation(), 0.0);
            throw e; // rethrow to satisfy @Test(expected)
        }
    }

    @Test
    public void testSetStandardDeviation_ZeroValue_ShouldThrowException7() {
        // Arrange - create new distribution with default standard deviation (1.0)
        NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
        double originalSd = normalDistribution.getStandardDeviation();
        double invalidSd = 0.0;
        
        try {
            // Act
            normalDistribution.setStandardDeviation(invalidSd);
            // If we get here, the mutation survived (returned 0.5 instead of throwing)
            fail("Expected IllegalArgumentException but none was thrown");
        } catch (IllegalArgumentException e) {
            // Assert exception message
            assertEquals("Standard deviation must be positive.", e.getMessage());
            // Assert field wasn't changed
            assertEquals(originalSd, normalDistribution.getStandardDeviation(), 0.0);
        }
    }


}
