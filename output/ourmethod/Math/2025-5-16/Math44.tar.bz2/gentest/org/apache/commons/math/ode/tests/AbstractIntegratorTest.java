package gentest.org.apache.commons.math.ode.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.ode.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver;
import org.apache.commons.math.analysis.solvers.UnivariateRealSolver;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.MaxCountExceededException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.ode.events.EventHandler;
import org.apache.commons.math.ode.events.EventState;
import org.apache.commons.math.ode.sampling.AbstractStepInterpolator;
import org.apache.commons.math.ode.sampling.StepHandler;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.Incrementor;
import org.apache.commons.math.util.Precision;
 
public class AbstractIntegratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                                                             public void testAcceptStep_EventRequestsStop() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                                                                                                                 double previousT = 1.0;
                                                                                                                                                                                                                                                                                                                                                                                 double eventT = 1.5;
                                                                                                                                                                                                                                                                                                                                                                                 double currentT = 2.0;
                                                                                                                                                                                                                                                                                                                                                                                 double tEnd = 3.0;
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Create mock interpolator
                                                                                                                                                                                                                                                                                                                                                                                 org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                                                                                                                                                     mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                                                                                                                 when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                                                                                                                                                                                                                                                                                                                                                                 when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                                                                                                                                                                                                                                                                                                                                                                 when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Create mock event state
                                                                                                                                                                                                                                                                                                                                                                                 org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                                                                                                                                                                                                                                                                                                     mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                                                                                                                                                                                                                 when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                                 when(eventState.getEventTime()).thenReturn(eventT);
                                                                                                                                                                                                                                                                                                                                                                                 when(eventState.stop()).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Initialize integrator and required fields
                                                                                                                                                                                                                                                                                                                                                                                 org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                                                                                                                                                                                                                     new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                                                                                                                                                                         public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                                                                                                             // dummy implementation for test
                                                                                                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                                                                                                 java.lang.reflect.Field eventsStatesField = 
                                                                                                                                                                                                                                                                                                                                                                                     org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                                                                                                                                                                                 eventsStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                 @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                                                                                                                                 java.util.Collection<org.apache.commons.math.ode.events.EventState> eventsStates = 
                                                                                                                                                                                                                                                                                                                                                                                     new java.util.ArrayList<org.apache.commons.math.ode.events.EventState>();
                                                                                                                                                                                                                                                                                                                                                                                 eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                                                                                                                                                                                                                                 eventsStates.add(eventState);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 java.lang.reflect.Field isLastStepField = 
                                                                                                                                                                                                                                                                                                                                                                                     org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                                                                                                                                 isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                 isLastStepField.setBoolean(integrator, false);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 java.lang.reflect.Field resetOccurredField = 
                                                                                                                                                                                                                                                                                                                                                                                     org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                                                                                                                                                 resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                 resetOccurredField.setBoolean(integrator, false);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Initialize state arrays
                                                                                                                                                                                                                                                                                                                                                                                 double[] y = new double[1];
                                                                                                                                                                                                                                                                                                                                                                                 double[] yDot = new double[1];
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Get protected acceptStep method through reflection
                                                                                                                                                                                                                                                                                                                                                                                 java.lang.reflect.Method acceptStepMethod = 
                                                                                                                                                                                                                                                                                                                                                                                     org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                                                                         "acceptStep", 
                                                                                                                                                                                                                                                                                                                                                                                         org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                                                                                                                                         double[].class, 
                                                                                                                                                                                                                                                                                                                                                                                         double[].class, 
                                                                                                                                                                                                                                                                                                                                                                                         double.class
                                                                                                                                                                                                                                                                                                                                                                                     );
                                                                                                                                                                                                                                                                                                                                                                                 acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                                                                                                                                                 double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                                                                                                                 assertEquals(eventT, result, 0.0001);
                                                                                                                                                                                                                                                                                                                                                                                 assertTrue(isLastStepField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                                                                                                 assertFalse(resetOccurredField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                      public void testAcceptStepArrayCopyCorrectness() throws Exception {
                                                                                                                                                                                                                                                          // Setup test data
                                                                                                                                                                                                                                                          double[] y = new double[3]; // destination array
                                                                                                                                                                                                                                                          double[] yDot = new double[3];
                                                                                                                                                                                                                                                          double[] eventY = {1.0, 2.0, 3.0}; // source array
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Mock interpolator
                                                                                                                                                                                                                                                          org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                              mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                          when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                          when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                                          when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create an event state that will trigger the array copy
                                                                                                                                                                                                                                                          org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                                                                                                                                                                              mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                                                                                          when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                          when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                          when(eventState.stop()).thenReturn(false);
                                                                                                                                                                                                                                                          when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create test integrator that extends AbstractIntegrator
                                                                                                                                                                                                                                                          org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                                                                                              new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                                                  public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                      // dummy implementation
                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                              };
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Inject our test event state
                                                                                                                                                                                                                                                          java.util.Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new java.util.ArrayList<>();
                                                                                                                                                                                                                                                          eventsStates.add(eventState);
                                                                                                                                                                                                                                                          // Use reflection to set private field since there's no setter
                                                                                                                                                                                                                                                          java.lang.reflect.Field field = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                                                                                                                          field.set(integrator, eventsStates);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Get the protected acceptStep method and make it accessible
                                                                                                                                                                                                                                                          java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                              "acceptStep", 
                                                                                                                                                                                                                                                              org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                              double[].class, 
                                                                                                                                                                                                                                                              double[].class, 
                                                                                                                                                                                                                                                              double.class
                                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                                          acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Call the protected method through reflection
                                                                                                                                                                                                                                                          acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Verify array was copied correctly (this will fail with the mutant)
                                                                                                                                                                                                                                                          org.junit.Assert.assertArrayEquals("Array copy should be exact", eventY, y, 0.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Additional verification that no elements were shifted
                                                                                                                                                                                                                                                          org.junit.Assert.assertEquals("First element should match", 1.0, y[0], 0.0);
                                                                                                                                                                                                                                                          org.junit.Assert.assertEquals("Second element should match", 2.0, y[1], 0.0);
                                                                                                                                                                                                                                                          org.junit.Assert.assertEquals("Third element should match", 3.0, y[2], 0.0);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testAcceptStepArrayCopyPosition() throws Exception {
                                                                                                                                                                                                                                                          // Setup test data
                                                                                                                                                                                                                                                          double[] y = new double[3]; // Original state
                                                                                                                                                                                                                                                          double[] yDot = new double[3];
                                                                                                                                                                                                                                                          double[] eventY = {1.0, 2.0, 3.0}; // Event state
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Mock interpolator
                                                                                                                                                                                                                                                          org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                              mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                          when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                          when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                                                          when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                                          when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Mock event state that triggers the array copy
                                                                                                                                                                                                                                                          org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                                                                                                                                                                              mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                                                                                          when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                          when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                          when(eventState.stop()).thenReturn(false);
                                                                                                                                                                                                                                                          when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Setup integrator
                                                                                                                                                                                                                                                          org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                                                                                              new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                                                  public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                      // Not used in this test
                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                              };
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Set private fields via reflection
                                                                                                                                                                                                                                                          Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                                                          eventsStatesField.setAccessible(true);
                                                                                                                                                                                                                                                          Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                                                                                                          eventsStates.add(eventState);
                                                                                                                                                                                                                                                          eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                                                          statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                                                          statesInitializedField.set(integrator, true);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Get and invoke the protected acceptStep method via reflection
                                                                                                                                                                                                                                                          Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                              "acceptStep", 
                                                                                                                                                                                                                                                              org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                              double[].class, 
                                                                                                                                                                                                                                                              double[].class, 
                                                                                                                                                                                                                                                              double.class
                                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                                          acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                          acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Verify the array copy was correct
                                                                                                                                                                                                                                                          assertEquals("First element should be copied from eventY", 1.0, y[0], 1e-10);
                                                                                                                                                                                                                                                          assertEquals("Second element should be copied from eventY", 2.0, y[1], 1e-10);
                                                                                                                                                                                                                                                          assertEquals("Third element should be copied from eventY", 3.0, y[2], 1e-10);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Verify the reset occurred (as we mocked reset to return true)
                                                                                                                                                                                                                                                          Field resetOccurredField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                          resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                                                          assertTrue("Reset should have occurred", resetOccurredField.getBoolean(integrator));
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                            public void testAcceptStepProcessesAllOccurringEvents() {
                                                                                                                                                                                // Setup test data
                                                                                                                                                                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                    mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                
                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                double tEnd = 1.0;
                                                                                                                                                                                
                                                                                                                                                                                // Create multiple event states
                                                                                                                                                                                org.apache.commons.math.ode.events.EventState event1 = 
                                                                                                                                                                                    mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                org.apache.commons.math.ode.events.EventState event2 = 
                                                                                                                                                                                    mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                when(event1.getEventTime()).thenReturn(0.3);
                                                                                                                                                                                when(event2.getEventTime()).thenReturn(0.6);
                                                                                                                                                                                
                                                                                                                                                                                // First event will trigger stop condition
                                                                                                                                                                                when(event1.stop()).thenReturn(true);
                                                                                                                                                                                
                                                                                                                                                                                // Setup interpolator responses
                                                                                                                                                                                double[] eventY = new double[]{1.0, 1.0};
                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                
                                                                                                                                                                                // Create test instance
                                                                                                                                                                                org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                                                                                                    new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                        @Override
                                                                                                                                                                                        public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                            // Not needed for this test
                                                                                                                                                                                        }
                                                                                                                                                                                    };
                                                                                                                                                                                
                                                                                                                                                                                // Set private fields via reflection
                                                                                                                                                                                try {
                                                                                                                                                                                    Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                    eventsStatesField.setAccessible(true);
                                                                                                                                                                                    Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                                    eventsStates.add(event1);
                                                                                                                                                                                    eventsStates.add(event2);
                                                                                                                                                                                    eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                                    
                                                                                                                                                                                    Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                    statesInitializedField.setAccessible(true);
                                                                                                                                                                                    statesInitializedField.set(integrator, true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get and invoke the protected acceptStep method via reflection
                                                                                                                                                                                    Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                        "acceptStep", 
                                                                                                                                                                                        org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                        double[].class, 
                                                                                                                                                                                        double[].class, 
                                                                                                                                                                                        double.class
                                                                                                                                                                                    );
                                                                                                                                                                                    acceptStepMethod.setAccessible(true);
                                                                                                                                                                                    double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify all events were processed
                                                                                                                                                                                    verify(event1).stepAccepted(0.3, eventY);
                                                                                                                                                                                    verify(event2).stepAccepted(0.3, eventY);
                                                                                                                                                                                    assertEquals(0.3, result, 1e-10);
                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                    fail("Failed to setup or execute test via reflection: " + e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testAcceptStep_DetectsMutatedEventTime() throws Exception {
                                                                                                                                                                                // Create concrete integrator subclass for testing
                                                                                                                                                                                org.apache.commons.math.ode.AbstractIntegrator integrator = new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                                                                                    @Override
                                                                                                                                                                                    public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                        // empty implementation for testing
                                                                                                                                                                                    }
                                                                                                                                                                                };
                                                                                                                                                                                
                                                                                                                                                                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(10.0);
                                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                
                                                                                                                                                                                // Create two event states that will trigger during the step
                                                                                                                                                                                org.apache.commons.math.ode.events.EventState event1 = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                when(event1.getEventTime()).thenReturn(5.0);
                                                                                                                                                                                when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                when(event1.stop()).thenReturn(false);
                                                                                                                                                                                when(event1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                                
                                                                                                                                                                                org.apache.commons.math.ode.events.EventState event2 = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                                when(event2.getEventTime()).thenReturn(7.0);
                                                                                                                                                                                when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                when(event2.stop()).thenReturn(false);
                                                                                                                                                                                when(event2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                                
                                                                                                                                                                                // Set up integrator state using reflection
                                                                                                                                                                                java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                eventsStatesField.setAccessible(true);
                                                                                                                                                                                eventsStatesField.set(integrator, java.util.Arrays.asList(event1, event2));
                                                                                                                                                                                
                                                                                                                                                                                java.lang.reflect.Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                statesInitializedField.setAccessible(true);
                                                                                                                                                                                statesInitializedField.set(integrator, false);
                                                                                                                                                                                
                                                                                                                                                                                double[] y = new double[0];
                                                                                                                                                                                double[] yDot = new double[0];
                                                                                                                                                                                
                                                                                                                                                                                // Call protected method using reflection
                                                                                                                                                                                java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 10.0);
                                                                                                                                                                                
                                                                                                                                                                                // Verify event times were processed correctly
                                                                                                                                                                                verify(event2).stepAccepted(eq(5.0), any(double[].class)); // event2 should be processed after event1 at time 5.0
                                                                                                                                                                                verify(event1).stepAccepted(eq(5.0), any(double[].class));
                                                                                                                                                                                verify(event1).stepAccepted(eq(7.0), any(double[].class)); // event1 is checked again at time 7.0
                                                                                                                                                                                verify(event2).stepAccepted(eq(7.0), any(double[].class));
                                                                                                                                                                                
                                                                                                                                                                                // Verify final state
                                                                                                                                                                                assertEquals(10.0, result, 1e-10);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                public void testAcceptStep_DetectsComputeDerivativesTimeMutation() throws Exception {
                                                                                                                                                                    // Create concrete subclass for testing
                                                                                                                                                                    class TestIntegrator extends org.apache.commons.math.ode.AbstractIntegrator {
                                                                                                                                                                        boolean computeDerivativesCalled = false;
                                                                                                                                                                        double calledTime = Double.NaN;
                                                                                                                                                                        
                                                                                                                                                                        public TestIntegrator() {
                                                                                                                                                                            super("test");
                                                                                                                                                                        }
                                                                                                                                                                        @Override
                                                                                                                                                                        public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                            // Not needed for this test
                                                                                                                                                                        }
                                                                                                                                                                        @Override
                                                                                                                                                                        public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                                                                            computeDerivativesCalled = true;
                                                                                                                                                                            calledTime = t;
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    // Setup test data and mocks
                                                                                                                                                                    TestIntegrator integrator = new TestIntegrator();
                                                                                                                                                                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                        mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                    double[] y = new double[]{1.0, 2.0};
                                                                                                                                                                    double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                    double tEnd = 10.0;
                                                                                                                                                                    
                                                                                                                                                                    // Setup event that will trigger reset
                                                                                                                                                                    org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                                                                                        mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                                                                    when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                    when(eventState.getEventTime()).thenReturn(5.0);
                                                                                                                                                                    when(eventState.reset(5.0, any(double[].class))).thenReturn(true);
                                                                                                                                                                    
                                                                                                                                                                    // Setup interpolator behavior
                                                                                                                                                                    when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                    when(interpolator.getGlobalCurrentTime()).thenReturn(10.0);
                                                                                                                                                                    when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                    when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                    
                                                                                                                                                                    // Set up integrator state using reflection
                                                                                                                                                                    java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                    eventsStatesField.setAccessible(true);
                                                                                                                                                                    eventsStatesField.set(integrator, java.util.Collections.singletonList(eventState));
                                                                                                                                                                    
                                                                                                                                                                    java.lang.reflect.Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                    statesInitializedField.setAccessible(true);
                                                                                                                                                                    statesInitializedField.set(integrator, true);
                                                                                                                                                                    
                                                                                                                                                                    // Execute the method using reflection
                                                                                                                                                                    java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                        org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                    acceptStepMethod.setAccessible(true);
                                                                                                                                                                    acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                    
                                                                                                                                                                    // Verify computeDerivatives was called with exact event time (not eventT + 1)
                                                                                                                                                                    assertTrue(integrator.computeDerivativesCalled);
                                                                                                                                                                    assertEquals(5.0, integrator.calledTime, 0.0);
                                                                                                                                                                    
                                                                                                                                                                    // Additional verification that reset occurred
                                                                                                                                                                    java.lang.reflect.Field resetOccurredField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                    resetOccurredField.setAccessible(true);
                                                                                                                                                                    assertTrue((Boolean) resetOccurredField.get(integrator));
                                                                                                                                                                }

    @Test
                                                                                                                 public void testAcceptStep_DetectsDerivativeRecomputationAfterEventReset() {
                                                                                                                     // Setup test data
                                                                                                                     double tEnd = 10.0;
                                                                                                                     double[] y = new double[]{1.0, 2.0};
                                                                                                                     double[] yDot = new double[]{0.0, 0.0};
                                                                                                                     
                                                                                                                     // Mock interpolator
                                                                                                                     org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                         mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                     when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                     when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                     when(interpolator.isForward()).thenReturn(true);
                                                                                                                     when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.1, 2.1});
                                                                                                                     
                                                                                                                     // Create test integrator
                                                                                                                     org.apache.commons.math.ode.AbstractIntegrator integrator = new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                                         @Override
                                                                                                                         public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                             // Not used in this test
                                                                                                                         }
                                                                                                                         
                                                                                                                         @Override
                                                                                                                         public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                             // This should be called when reset occurs
                                                                                                                             yDot[0] = 1.5;
                                                                                                                             yDot[1] = 2.5;
                                                                                                                         }
                                                                                                                     };
                                                                                                                     
                                                                                                                     // Create event state that will trigger reset
                                                                                                                     org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                                         mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                                                     when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                     when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                     when(eventState.stop()).thenReturn(false);
                                                                                                                     when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                     
                                                                                                                     // Add event state to integrator (using reflection since eventsStates is private)
                                                                                                                     try {
                                                                                                                         java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                         eventsStatesField.setAccessible(true);
                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                         java.util.Collection<org.apache.commons.math.ode.events.EventState> eventsStates = 
                                                                                                                             (java.util.Collection<org.apache.commons.math.ode.events.EventState>) eventsStatesField.get(integrator);
                                                                                                                         if (eventsStates == null) {
                                                                                                                             eventsStates = new java.util.ArrayList<>();
                                                                                                                             eventsStatesField.set(integrator, eventsStates);
                                                                                                                         }
                                                                                                                         eventsStates.add(eventState);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to setup test due to reflection error");
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Execute the method using reflection
                                                                                                                     double result = 0.0;
                                                                                                                     try {
                                                                                                                         java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                             "acceptStep", 
                                                                                                                             org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                             double[].class, 
                                                                                                                             double[].class, 
                                                                                                                             double.class
                                                                                                                         );
                                                                                                                         acceptStepMethod.setAccessible(true);
                                                                                                                         result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to invoke acceptStep method");
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Verify derivatives were recomputed
                                                                                                                     assertEquals(1.5, yDot[0], 1e-10);
                                                                                                                     assertEquals(2.5, yDot[1], 1e-10);
                                                                                                                     
                                                                                                                     // Verify reset occurred using reflection
                                                                                                                     try {
                                                                                                                         java.lang.reflect.Field resetOccurredField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                         resetOccurredField.setAccessible(true);
                                                                                                                         assertTrue(resetOccurredField.getBoolean(integrator));
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to check resetOccurred flag");
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Verify other expected behavior
                                                                                                                     assertEquals(0.5, result, 1e-10);
                                                                                                                     verify(eventState, times(1)).stepAccepted(0.5, new double[]{1.1, 2.1});
                                                                                                                 }

    @Test
                                                                                           public void testAcceptStep_ReturnsEventT_WhenEventStopsIntegration() {
                                                                                               // Setup test data
                                                                                               double previousT = 0.0;
                                                                                               double currentT = 1.0;
                                                                                               double eventT = 0.5;
                                                                                               double[] y = new double[1];
                                                                                               double[] yDot = new double[1];
                                                                                               double tEnd = 1.0;
                                                                                               
                                                                                               // Mock interpolator
                                                                                               org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                   mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                               when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                                                                               when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                                                                               when(interpolator.isForward()).thenReturn(true);
                                                                                               
                                                                                               // Create event state that will stop integration
                                                                                               org.apache.commons.math.ode.events.EventState stoppingEvent = 
                                                                                                   mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                               when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                               when(stoppingEvent.getEventTime()).thenReturn(eventT);
                                                                                               when(stoppingEvent.stop()).thenReturn(true);  // This triggers the isLastStep condition
                                                                                               
                                                                                               // Create test integrator subclass to expose protected method
                                                                                               class TestIntegrator extends org.apache.commons.math.ode.AbstractIntegrator {
                                                                                                   public TestIntegrator() {
                                                                                                       super("test");
                                                                                                   }
                                                                                                   
                                                                                                   @Override
                                                                                                   public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                       // Not used in this test
                                                                                                   }
                                                                                                   
                                                                                                   public double testAcceptStep(org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator, 
                                                                                                                              double[] y, double[] yDot, double tEnd) {
                                                                                                       return super.acceptStep(interpolator, y, yDot, tEnd);
                                                                                                   }
                                                                                                   
                                                                                                   @Override
                                                                                                   public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                       // Not used in this test
                                                                                                   }
                                                                                               }
                                                                                               
                                                                                               TestIntegrator integrator = new TestIntegrator();
                                                                                               
                                                                                               // Set private fields via reflection
                                                                                               try {
                                                                                                   Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                   eventsStatesField.setAccessible(true);
                                                                                                   Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                                                                                                   eventsStates.add(stoppingEvent);
                                                                                                   eventsStatesField.set(integrator, eventsStates);
                                                                                                   
                                                                                                   Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                   statesInitializedField.setAccessible(true);
                                                                                                   statesInitializedField.set(integrator, true);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                               }
                                                                                               
                                                                                               // Execute test
                                                                                               double result = integrator.testAcceptStep(interpolator, y, yDot, tEnd);
                                                                                               
                                                                                               // Verify the method returned eventT immediately when event stopped integration
                                                                                               assertEquals(eventT, result, 0.0);
                                                                                               
                                                                                               // Verify interpolator was set to event time
                                                                                               verify(interpolator).setInterpolatedTime(eventT);
                                                                                               
                                                                                               // Verify event was processed
                                                                                               verify(stoppingEvent).stepAccepted(eventT, any(double[].class));
                                                                                           }

    @Test
                                                                                           public void testAcceptStepArrayCopyCompleteness() throws Exception {
                                                                                               // Setup test with array length > 1 to detect partial copy
                                                                                               final int arrayLength = 3;
                                                                                               double[] y = new double[arrayLength];
                                                                                               double[] yDot = new double[arrayLength];
                                                                                               double[] eventY = {1.0, 2.0, 3.0}; // Different values to detect copy
                                                                                               
                                                                                               // Mock interpolator and setup event that triggers arraycopy path
                                                                                               org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                   mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                               when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                               when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                               when(interpolator.isForward()).thenReturn(true);
                                                                                               when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                               
                                                                                               // Create event state that will trigger reset path
                                                                                               org.apache.commons.math.ode.events.EventState eventState = 
                                                                                                   mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                               when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                               when(eventState.getEventTime()).thenReturn(0.5);
                                                                                               when(eventState.stop()).thenReturn(false);
                                                                                               when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                               
                                                                                               // Setup test instance using anonymous class implementation
                                                                                               org.apache.commons.math.ode.AbstractIntegrator integrator = 
                                                                                                   new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                       @Override
                                                                                                       public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                           // Not used in this test
                                                                                                       }
                                                                                                   };
                                                                                               
                                                                                               // Inject our test event state
                                                                                               Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                                                                                               eventsStates.add(eventState);
                                                                                               // Need reflection to set private field
                                                                                               try {
                                                                                                   Field field = integrator.getClass().getSuperclass().getDeclaredField("eventsStates");
                                                                                                   field.setAccessible(true);
                                                                                                   field.set(integrator, eventsStates);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to set eventsStates field via reflection: " + e.getMessage());
                                                                                               }
                                                                                               
                                                                                               // Use reflection to call protected acceptStep method
                                                                                               try {
                                                                                                   Method acceptStepMethod = integrator.getClass().getSuperclass().getDeclaredMethod(
                                                                                                       "acceptStep",
                                                                                                       org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class,
                                                                                                       double[].class,
                                                                                                       double[].class,
                                                                                                       double.class
                                                                                                   );
                                                                                                   acceptStepMethod.setAccessible(true);
                                                                                                   acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to invoke acceptStep method via reflection: " + e.getMessage());
                                                                                               }
                                                                                               
                                                                                               // Verify ALL elements were copied (would fail with mutant)
                                                                                               assertArrayEquals("All array elements should be copied", eventY, y, 0.0);
                                                                                               
                                                                                               // Specifically verify last element was copied
                                                                                               assertEquals("Last element must be copied", 
                                                                                                          eventY[arrayLength-1], y[arrayLength-1], 0.0);
                                                                                           }

    @Test
                                                                                           public void testAcceptStepProcessesRemainingEventsWhenLastStep() throws Exception {
                                                                                               // Create concrete integrator subclass
                                                                                               org.apache.commons.math.ode.AbstractIntegrator integrator = new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                                   @Override
                                                                                                   public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                                       // dummy implementation for testing
                                                                                                   }
                                                                                               };
                                                                                               
                                                                                               org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                               when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                               when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                               when(interpolator.isForward()).thenReturn(true);
                                                                                               when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
                                                                                               
                                                                                               // Create multiple event states
                                                                                               org.apache.commons.math.ode.events.EventState event1 = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                               when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                                                               when(event1.getEventTime()).thenReturn(0.5);
                                                                                               when(event1.stop()).thenReturn(true); // This triggers isLastStep
                                                                                               
                                                                                               org.apache.commons.math.ode.events.EventState event2 = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                               when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                                                               when(event2.getEventTime()).thenReturn(0.7);
                                                                                               
                                                                                               // Set up integrator state using reflection
                                                                                               java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                               eventsStatesField.setAccessible(true);
                                                                                               eventsStatesField.set(integrator, java.util.Arrays.asList(event1, event2));
                                                                                               
                                                                                               java.lang.reflect.Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                               statesInitializedField.setAccessible(true);
                                                                                               statesInitializedField.set(integrator, false);
                                                                                               
                                                                                               java.lang.reflect.Field stepHandlersField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                               stepHandlersField.setAccessible(true);
                                                                                               stepHandlersField.set(integrator, new java.util.ArrayList<>());
                                                                                               
                                                                                               // Test using reflection to call protected method
                                                                                               java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod("acceptStep",
                                                                                                   org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                               acceptStepMethod.setAccessible(true);
                                                                                               
                                                                                               double[] y = new double[1];
                                                                                               double[] yDot = new double[1];
                                                                                               double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                               
                                                                                               // Verify
                                                                                               assertEquals(0.5, result, 1e-10);
                                                                                               // Verify event1 was processed
                                                                                               verify(event1).stepAccepted(0.5, new double[]{0.0});
                                                                                               // Verify event2 was processed as remaining event (would fail with mutant)
                                                                                               verify(event2).stepAccepted(0.5, new double[]{0.0});
                                                                                           }

    @Test
                                                                              public void testAcceptStepOnlyProcessesOccurringEvents() throws Exception {
                                                                                  // Create concrete integrator subclass for testing
                                                                                  org.apache.commons.math.ode.AbstractIntegrator integrator = new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                      @Override
                                                                                      public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                          // dummy implementation for testing
                                                                                      }
                                                                                  };
                                                                                  
                                                                                  // Setup test data
                                                                                  org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                                  when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                  when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                  when(interpolator.isForward()).thenReturn(true);
                                                                                  
                                                                                  // Create mock events - two occurring, one not occurring
                                                                                  org.apache.commons.math.ode.events.EventState occurringEvent1 = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                  when(occurringEvent1.evaluateStep(interpolator)).thenReturn(true);
                                                                                  when(occurringEvent1.getEventTime()).thenReturn(0.5);
                                                                                  when(occurringEvent1.stop()).thenReturn(true); // triggers stop
                                                                                  
                                                                                  org.apache.commons.math.ode.events.EventState occurringEvent2 = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                  when(occurringEvent2.evaluateStep(interpolator)).thenReturn(true);
                                                                                  when(occurringEvent2.getEventTime()).thenReturn(0.7);
                                                                                  
                                                                                  org.apache.commons.math.ode.events.EventState nonOccurringEvent = mock(org.apache.commons.math.ode.events.EventState.class);
                                                                                  when(nonOccurringEvent.evaluateStep(interpolator)).thenReturn(false);
                                                                                  
                                                                                  // Set up integrator state using reflection
                                                                                  java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                  eventsStatesField.setAccessible(true);
                                                                                  eventsStatesField.set(integrator, new java.util.ArrayList<>(java.util.Arrays.asList(occurringEvent1, occurringEvent2, nonOccurringEvent)));
                                                                                  
                                                                                  java.lang.reflect.Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                  statesInitializedField.setAccessible(true);
                                                                                  statesInitializedField.set(integrator, true);
                                                                                  
                                                                                  // Test using reflection to call protected method
                                                                                  java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod("acceptStep",
                                                                                      org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                  acceptStepMethod.setAccessible(true);
                                                                                  
                                                                                  double[] y = new double[0];
                                                                                  double[] yDot = new double[0];
                                                                                  acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                  
                                                                                  // Verify only occurring events had stepAccepted called
                                                                                  verify(occurringEvent1, times(1)).stepAccepted(anyDouble(), any(double[].class));
                                                                                  verify(occurringEvent2, times(1)).stepAccepted(anyDouble(), any(double[].class));
                                                                                  verify(nonOccurringEvent, never()).stepAccepted(anyDouble(), any(double[].class));
                                                                                  
                                                                                  // Also verify stop was called only on occurring events
                                                                                  verify(occurringEvent1, times(1)).stop();
                                                                                  verify(occurringEvent2, times(1)).stop();
                                                                                  verify(nonOccurringEvent, never()).stop();
                                                                              }

    @Test
                                                                          public void testAcceptStepReturnsExactEventTimeWhenEventStopsIntegration() throws Exception {
                                                                              // Setup test data
                                                                              final double previousTime = 0.0;
                                                                              final double eventTime = 1.5;
                                                                              final double currentTime = 2.0;
                                                                              final double tEnd = 3.0;
                                                                              final double[] y = new double[1];
                                                                              final double[] yDot = new double[1];
                                                                              
                                                                              // Mock interpolator
                                                                              org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                  mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                                                                              when(interpolator.getGlobalPreviousTime()).thenReturn(previousTime);
                                                                              when(interpolator.getGlobalCurrentTime()).thenReturn(currentTime);
                                                                              when(interpolator.isForward()).thenReturn(true);
                                                                              
                                                                              // Mock event state that will stop integration
                                                                              org.apache.commons.math.ode.events.EventState stoppingEvent = 
                                                                                  mock(org.apache.commons.math.ode.events.EventState.class);
                                                                              when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                              when(stoppingEvent.getEventTime()).thenReturn(eventTime);
                                                                              when(stoppingEvent.stop()).thenReturn(true);
                                                                              
                                                                              // Create test instance and set up state
                                                                              org.apache.commons.math.ode.AbstractIntegrator integrator = new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                                                                  @Override
                                                                                  public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                                                                      // Empty implementation for test purposes
                                                                                  }
                                                                              };
                                                                              java.util.Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new java.util.ArrayList<org.apache.commons.math.ode.events.EventState>();
                                                                              eventsStates.add(stoppingEvent);
                                                                              
                                                                              // Use reflection to set private fields since they're not accessible
                                                                              java.lang.reflect.Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                              eventsStatesField.setAccessible(true);
                                                                              eventsStatesField.set(integrator, eventsStates);
                                                                              
                                                                              java.lang.reflect.Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                              statesInitializedField.setAccessible(true);
                                                                              statesInitializedField.set(integrator, true);
                                                                              
                                                                              // Use reflection to access protected acceptStep method
                                                                              java.lang.reflect.Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                  "acceptStep", 
                                                                                  org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                                                                  double[].class, 
                                                                                  double[].class, 
                                                                                  double.class
                                                                              );
                                                                              acceptStepMethod.setAccessible(true);
                                                                              
                                                                              // Execute test
                                                                              double returnedTime = (double) acceptStepMethod.invoke(
                                                                                  integrator, 
                                                                                  interpolator, 
                                                                                  y, 
                                                                                  yDot, 
                                                                                  tEnd
                                                                              );
                                                                              
                                                                              // Verify the exact event time is returned (not eventTime + 1)
                                                                              assertEquals("Returned time should exactly match event time", 
                                                                                         eventTime, returnedTime, 0.0);
                                                                              
                                                                              // Verify interpolator interactions
                                                                              verify(interpolator).setSoftPreviousTime(previousTime);
                                                                              verify(interpolator).setSoftCurrentTime(eventTime);
                                                                              verify(interpolator).setInterpolatedTime(eventTime);
                                                                          }

    @Test
                    public void testAcceptStepNotifiesAllEventsWhenStopping() throws Exception {
                        // Setup test data
                        org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                            mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                        when(interpolator.isForward()).thenReturn(true);
                        
                        // Create multiple event states
                        org.apache.commons.math.ode.events.EventState stoppingEvent = 
                            mock(org.apache.commons.math.ode.events.EventState.class);
                        when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                        when(stoppingEvent.getEventTime()).thenReturn(0.5);
                        when(stoppingEvent.stop()).thenReturn(true); // This event will stop integration
                        
                        org.apache.commons.math.ode.events.EventState remainingEvent = 
                            mock(org.apache.commons.math.ode.events.EventState.class);
                        when(remainingEvent.evaluateStep(interpolator)).thenReturn(true);
                        when(remainingEvent.getEventTime()).thenReturn(0.7);
                        
                        // Create test integrator that implements abstract methods
                        org.apache.commons.math.ode.AbstractIntegrator integrator = 
                            new org.apache.commons.math.ode.AbstractIntegrator("test") {
                                @Override
                                public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                    // dummy implementation for test
                                }
                            };
                        
                        // Use reflection to set private fields
                        java.lang.reflect.Field eventsStatesField = 
                            org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                        eventsStatesField.setAccessible(true);
                        eventsStatesField.set(integrator, java.util.Arrays.asList(stoppingEvent, remainingEvent));
                        
                        java.lang.reflect.Field statesInitializedField = 
                            org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                        statesInitializedField.setAccessible(true);
                        statesInitializedField.set(integrator, true);
                        
                        double[] y = new double[0];
                        double[] yDot = new double[0];
                        
                        // Use reflection to call protected method
                        java.lang.reflect.Method acceptStepMethod = 
                            org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                "acceptStep", 
                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                double[].class, 
                                double[].class, 
                                double.class
                            );
                        acceptStepMethod.setAccessible(true);
                        double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                        
                        // Verify all events were notified
                        verify(stoppingEvent).stepAccepted(0.5, any(double[].class));
                        verify(remainingEvent).stepAccepted(0.5, any(double[].class));
                        assertEquals(0.5, result, 1e-10);
                    }

    @Test
                public void testAcceptStepReturnsExactEventTime() {
                    // Setup test data
                    double previousT = 0.0;
                    double currentT = 1.0;
                    double eventT = 0.5;
                    double[] y = new double[1];
                    double[] yDot = new double[1];
                    double tEnd = 1.0;
                    
                    // Mock interpolator
                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                        mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                    when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                    when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                    when(interpolator.isForward()).thenReturn(true);
                    
                    // Mock event state that will trigger the return path
                    org.apache.commons.math.ode.events.EventState eventState = 
                        mock(org.apache.commons.math.ode.events.EventState.class);
                    when(eventState.evaluateStep(interpolator)).thenReturn(true);
                    when(eventState.getEventTime()).thenReturn(eventT);
                    when(eventState.stop()).thenReturn(true); // This will trigger the early return
                    
                    // Create test instance
                    org.apache.commons.math.ode.AbstractIntegrator integrator = 
                        new org.apache.commons.math.ode.AbstractIntegrator("test") {
                            @Override
                            public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                // Not used in this test
                            }
                            
                            @Override
                            public void computeDerivatives(double t, double[] y, double[] yDot) {
                                // Not used in this test
                            }
                        };
                    
                    // Set up event states
                    java.util.Collection<org.apache.commons.math.ode.events.EventState> eventsStates = 
                        new java.util.ArrayList<org.apache.commons.math.ode.events.EventState>();
                    eventsStates.add(eventState);
                    
                    // Use reflection to set private field since there's no setter
                    try {
                        java.lang.reflect.Field field = 
                            org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                        field.setAccessible(true);
                        field.set(integrator, eventsStates);
                    } catch (Exception e) {
                        fail("Failed to set eventsStates field");
                    }
                    
                    // Execute test using reflection to call protected method
                    double returnedTime = 0.0;
                    try {
                        java.lang.reflect.Method acceptStepMethod = 
                            org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                                "acceptStep", 
                                org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                                double[].class, 
                                double[].class, 
                                double.class);
                        acceptStepMethod.setAccessible(true);
                        returnedTime = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                    } catch (Exception e) {
                        fail("Failed to invoke acceptStep method");
                    }
                    
                    // Verify the exact event time is returned, not currentT
                    assertEquals("Method should return exact event time when event triggers stop", 
                                eventT, returnedTime, 1e-12);
                    
                    // Verify the event state was processed
                    verify(eventState).stepAccepted(eventT, any(double[].class));
                }

    @Test
                public void testAcceptStepArrayCopyCompleteness1() {
                    // Setup test data
                    double[] y = new double[]{1.0, 2.0, 3.0};  // Initial state
                    double[] yDot = new double[3];
                    double[] eventY = new double[]{4.0, 5.0, 6.0};  // Event state
                    
                    // Mock interpolator
                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                        mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                    when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                    when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                    when(interpolator.isForward()).thenReturn(true);
                    when(interpolator.getInterpolatedState()).thenReturn(eventY);
                    
                    // Mock event state that triggers stop
                    org.apache.commons.math.ode.events.EventState stoppingEvent = 
                        mock(org.apache.commons.math.ode.events.EventState.class);
                    when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                    when(stoppingEvent.getEventTime()).thenReturn(0.5);
                    when(stoppingEvent.stop()).thenReturn(true);
                    
                    // Create test instance
                    org.apache.commons.math.ode.AbstractIntegrator integrator = 
                        new org.apache.commons.math.ode.AbstractIntegrator("test") {
                            @Override
                            public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                // Not used in this test
                            }
                        };
                    
                    // Set up event states
                    Collection<org.apache.commons.math.ode.events.EventState> eventsStates = new ArrayList<>();
                    eventsStates.add(stoppingEvent);
                    
                    // Use reflection to set private fields since they're not accessible
                    try {
                        Field eventsStatesField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                        eventsStatesField.setAccessible(true);
                        eventsStatesField.set(integrator, eventsStates);
                        
                        Field statesInitializedField = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                        statesInitializedField.setAccessible(true);
                        statesInitializedField.set(integrator, true);
                        
                        // Use reflection to call protected acceptStep method
                        Method acceptStepMethod = org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod(
                            "acceptStep", 
                            org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class,
                            double[].class, 
                            double[].class, 
                            double.class
                        );
                        acceptStepMethod.setAccessible(true);
                        double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                        
                        // Verify all array elements were copied (especially the last one)
                        assertEquals(0.5, result, 1e-12);
                        assertEquals(4.0, y[0], 1e-12);  // First element
                        assertEquals(5.0, y[1], 1e-12);  // Middle element
                        assertEquals(6.0, y[2], 1e-12);  // Last element - this would fail with the mutant
                        
                    } catch (Exception e) {
                        fail("Failed to set up test via reflection: " + e.getMessage());
                    }
                }

    @Test
                public void testComputeDerivativesCalledWithCorrectTimeAfterEventReset() throws Exception {
                    // Setup test data
                    double previousT = 0.0;
                    double currentT = 10.0;
                    double eventT = 5.0;
                    double[] y = new double[]{1.0, 2.0};
                    double[] yDot = new double[]{0.0, 0.0};
                    
                    // Create mock interpolator
                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                        mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
                    when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                    when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                    when(interpolator.isForward()).thenReturn(true);
                    
                    // Create mock event state that triggers reset
                    org.apache.commons.math.ode.events.EventState eventState = 
                        mock(org.apache.commons.math.ode.events.EventState.class);
                    when(eventState.evaluateStep(interpolator)).thenReturn(true);
                    when(eventState.getEventTime()).thenReturn(eventT);
                    when(eventState.stop()).thenReturn(false);
                    when(eventState.reset(eventT, any(double[].class))).thenReturn(true);
                    
                    // Create test integrator
                    org.apache.commons.math.ode.AbstractIntegrator integrator = 
                        new org.apache.commons.math.ode.AbstractIntegrator("test") {
                            @Override
                            public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                                // Not used in this test
                            }
                            
                            @Override
                            public void computeDerivatives(double t, double[] y, double[] yDot) {
                                // Verify the time parameter is exactly eventT
                                assertEquals("Derivatives should be computed at event time", 
                                            eventT, t, 1e-12);
                                // Store the time for later verification
                                try {
                                    java.lang.reflect.Field stepStartField = 
                                        org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepStart");
                                    stepStartField.setAccessible(true);
                                    stepStartField.set(this, t);
                                } catch (Exception e) {
                                    fail("Failed to set stepStart field");
                                }
                            }
                        };
                    
                    // Set up test conditions using reflection
                    java.lang.reflect.Field eventsStatesField = 
                        org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                    eventsStatesField.setAccessible(true);
                    eventsStatesField.set(integrator, java.util.Collections.singletonList(eventState));
                    
                    java.lang.reflect.Field statesInitializedField = 
                        org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                    statesInitializedField.setAccessible(true);
                    statesInitializedField.set(integrator, true);
                    
                    // Execute the test through the anonymous subclass
                    java.lang.reflect.Method acceptStepMethod = 
                        org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                            org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                            double[].class, double[].class, double.class);
                    acceptStepMethod.setAccessible(true);
                    double result = (Double)acceptStepMethod.invoke(integrator, interpolator, y, yDot, currentT);
                    
                    // Additional verification using reflection
                    java.lang.reflect.Field stepStartField = 
                        org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepStart");
                    stepStartField.setAccessible(true);
                    assertEquals("Step start should be updated to event time", 
                                eventT, (Double)stepStartField.get(integrator), 1e-12);
                    
                    java.lang.reflect.Field resetOccurredField = 
                        org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                    resetOccurredField.setAccessible(true);
                    assertTrue("Reset should have occurred", (Boolean)resetOccurredField.get(integrator));
                }

    @Test
        public void testAcceptStepDetectsComputeDerivativesParameterSwap() throws Exception {
            // Setup test data
            double tEnd = 10.0;
            double[] y = new double[]{1.0, 2.0};
            double[] yDot = new double[]{0.0, 0.0};
            
            // Create mock interpolator
            org.apache.commons.math.ode.sampling.AbstractStepInterpolator interpolator = 
                mock(org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class);
            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
            when(interpolator.isForward()).thenReturn(true);
            when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
            
            // Create mock event state that triggers reset
            org.apache.commons.math.ode.events.EventState eventState = 
                mock(org.apache.commons.math.ode.events.EventState.class);
            when(eventState.evaluateStep(interpolator)).thenReturn(true);
            when(eventState.getEventTime()).thenReturn(0.5);
            when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
            
            // Create test integrator
            org.apache.commons.math.ode.AbstractIntegrator integrator = 
                new org.apache.commons.math.ode.AbstractIntegrator("test") {
                    @Override
                    public void integrate(org.apache.commons.math.ode.ExpandableStatefulODE equations, double t) {
                        // Not used in this test
                    }
                    
                    @Override
                    public void computeDerivatives(double t, double[] yIn, double[] yDotOut) {
                        // Verify parameters are correct
                        assertArrayEquals("Input state vector should be y", y, yIn, 0.0);
                        assertSame("Output derivatives should be yDot", yDot, yDotOut);
                        // Fill with test values
                        yDotOut[0] = -yIn[1];
                        yDotOut[1] = yIn[0];
                    }
                };
            
            // Set up test conditions using reflection
            java.lang.reflect.Field eventsStatesField = 
                org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
            eventsStatesField.setAccessible(true);
            eventsStatesField.set(integrator, java.util.Collections.singletonList(eventState));
            
            java.lang.reflect.Field stepHandlersField = 
                org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
            stepHandlersField.setAccessible(true);
            stepHandlersField.set(integrator, java.util.Collections.emptyList());
            
            java.lang.reflect.Field statesInitializedField = 
                org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
            statesInitializedField.setAccessible(true);
            statesInitializedField.set(integrator, true);
            
            // Execute test using reflection
            java.lang.reflect.Method acceptStepMethod = 
                org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                    org.apache.commons.math.ode.sampling.AbstractStepInterpolator.class, 
                    double[].class, 
                    double[].class, 
                    double.class);
            acceptStepMethod.setAccessible(true);
            double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
            
            // Verify derivatives were computed correctly
            assertEquals("First derivative should be computed", -2.0, yDot[0], 1e-10);
            assertEquals("Second derivative should be computed", 1.0, yDot[1], 1e-10);
            
            // Verify reset occurred using reflection
            java.lang.reflect.Field resetOccurredField = 
                org.apache.commons.math.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
            resetOccurredField.setAccessible(true);
            assertTrue("Reset should have occurred", (Boolean) resetOccurredField.get(integrator));
        }

    @Test
        public void testAcceptStepDetectsResetOccurredMutation() throws Exception {
            // Create concrete subclass of AbstractIntegrator for testing
            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                @Override
                public void integrate(ExpandableStatefulODE equations, double t) {
                    // Empty implementation for testing
                }
            };
            
            // Create mock objects
            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
            EventState eventState = mock(EventState.class);
            
            // Test data
            double[] y = new double[2];
            double[] yDot = new double[2];
            double tEnd = 10.0;
            
            // Configure interpolator behavior
            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
            when(interpolator.isForward()).thenReturn(true);
            when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 1.0});
            
            // Configure event state behavior
            when(eventState.evaluateStep(any(AbstractStepInterpolator.class))).thenReturn(true);
            when(eventState.getEventTime()).thenReturn(0.5);
            when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
            
            // Use reflection to set private fields
            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
            eventsStatesField.setAccessible(true);
            eventsStatesField.set(integrator, Collections.singletonList(eventState));
            
            Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
            statesInitializedField.setAccessible(true);
            statesInitializedField.set(integrator, false);
            
            Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
            resetOccurredField.setAccessible(true);
            resetOccurredField.set(integrator, false);
            
            // Use reflection to call protected method
            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                "acceptStep", 
                AbstractStepInterpolator.class, 
                double[].class, 
                double[].class, 
                double.class
            );
            acceptStepMethod.setAccessible(true);
            acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
            
            // Verify resetOccurred was set to true
            assertTrue("resetOccurred should be true after event reset", 
                       (boolean) resetOccurredField.get(integrator));
            
            // Additional verification
            verify(eventState).stepAccepted(anyDouble(), any(double[].class));
            verify(interpolator, atLeastOnce()).setInterpolatedTime(anyDouble());
        }

    @Test
        public void testAcceptStepDetectsResetOccurredMutation1() throws Exception {
            // Create concrete integrator subclass
            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                @Override
                public void integrate(ExpandableStatefulODE equations, double t) {
                    // dummy implementation for test
                }
            };
            
            double[] y = new double[2];
            double[] yDot = new double[2];
            double tEnd = 10.0;
            
            // Create mock interpolator
            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
            when(interpolator.isForward()).thenReturn(true);
            when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 1.0});
            
            // Create mock event state that will trigger reset
            EventState eventState = mock(EventState.class);
            when(eventState.evaluateStep(interpolator)).thenReturn(true);
            when(eventState.getEventTime()).thenReturn(0.5);
            when(eventState.stop()).thenReturn(false);
            when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
            
            // Set up integrator state using reflection
            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
            eventsStatesField.setAccessible(true);
            eventsStatesField.set(integrator, Collections.singletonList(eventState));
            
            Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
            statesInitializedField.setAccessible(true);
            statesInitializedField.set(integrator, false);
            
            Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
            resetOccurredField.setAccessible(true);
            resetOccurredField.set(integrator, false);
            
            // Execute the method using reflection
            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                AbstractStepInterpolator.class, double[].class, double[].class, double.class);
            acceptStepMethod.setAccessible(true);
            double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
            
            // Verify resetOccurred was set to true using reflection
            assertTrue("resetOccurred should be true after event reset", 
                (Boolean) resetOccurredField.get(integrator));
            
            // Verify other expected behavior
            assertEquals(0.5, result, 1e-10);
            verify(eventState).stepAccepted(0.5, new double[]{1.0, 1.0});
            verify(interpolator).setSoftPreviousTime(0.0);
            verify(interpolator).setSoftCurrentTime(0.5);
        }

    @Test
        public void testAcceptStepReturnsCorrectEventTime() throws Exception {
            // Create concrete test integrator
            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                @Override
                public void integrate(ExpandableStatefulODE equations, double t) {
                    // dummy implementation for test
                }
            };
            
            double[] y = new double[1];
            double[] yDot = new double[1];
            double tEnd = 10.0;
            
            // Create mock interpolator
            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
            when(interpolator.isForward()).thenReturn(true);
            when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
            
            // Create mock event state that will stop integration
            EventState stoppingEvent = mock(EventState.class);
            when(stoppingEvent.evaluateStep(any(AbstractStepInterpolator.class))).thenReturn(true);
            when(stoppingEvent.getEventTime()).thenReturn(0.5);
            when(stoppingEvent.stop()).thenReturn(true);
            
            // Create mock event state that will trigger reset
            EventState resettingEvent = mock(EventState.class);
            when(resettingEvent.evaluateStep(any(AbstractStepInterpolator.class))).thenReturn(true);
            when(resettingEvent.getEventTime()).thenReturn(0.7);
            when(resettingEvent.stop()).thenReturn(false);
            when(resettingEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
            
            // Use reflection to set private eventsStates field
            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
            eventsStatesField.setAccessible(true);
            
            // Get protected acceptStep method
            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                "acceptStep", 
                AbstractStepInterpolator.class, 
                double[].class, 
                double[].class, 
                double.class
            );
            acceptStepMethod.setAccessible(true);
            
            // Test case 1: Event requests stop
            eventsStatesField.set(integrator, java.util.Arrays.asList(stoppingEvent));
            double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
            assertEquals("Should return event time when event stops integration", 
                        0.5, result, 1e-10);
            
            // Test case 2: Event triggers reset
            eventsStatesField.set(integrator, java.util.Arrays.asList(resettingEvent));
            result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
            assertEquals("Should return event time when event triggers reset", 
                        0.7, result, 1e-10);
            
            // Verify interactions
            verify(stoppingEvent).stepAccepted(0.5, new double[]{1.0});
            verify(resettingEvent).stepAccepted(0.7, new double[]{1.0});
        }

    @Test
        public void testAcceptStepProcessesAllRemainingEvents() throws Exception {
            // Create concrete test integrator
            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                @Override
                public void integrate(ExpandableStatefulODE equations, double t) {
                    // dummy implementation for test
                }
            };
            
            // Create mock interpolator
            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
            when(interpolator.isForward()).thenReturn(true);
            
            // Create mock event states
            EventState event1 = mock(EventState.class);
            EventState event2 = mock(EventState.class);
            EventState event3 = mock(EventState.class);
            
            // Configure events to trigger during step
            when(event1.evaluateStep(interpolator)).thenReturn(true);
            when(event2.evaluateStep(interpolator)).thenReturn(true);
            when(event3.evaluateStep(interpolator)).thenReturn(true);
            
            // Set event times (ordered)
            when(event1.getEventTime()).thenReturn(0.3);
            when(event2.getEventTime()).thenReturn(0.6);
            when(event3.getEventTime()).thenReturn(0.9);
            
            // First event will trigger stop
            when(event1.stop()).thenReturn(true);
            
            // Use reflection to set private eventsStates field
            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
            eventsStatesField.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<EventState> eventsStates = (List<EventState>) eventsStatesField.get(integrator);
            if (eventsStates == null) {
                eventsStates = new ArrayList<EventState>();
            }
            eventsStates.clear();
            eventsStates.add(event1);
            eventsStates.add(event2);
            eventsStates.add(event3);
            eventsStatesField.set(integrator, eventsStates);
            
            double[] y = new double[1];
            double[] yDot = new double[1];
            
            // Use reflection to call protected acceptStep method
            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                "acceptStep", AbstractStepInterpolator.class, double[].class, double[].class, double.class);
            acceptStepMethod.setAccessible(true);
            double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
            
            // Verify all remaining events were processed
            verify(event1).stepAccepted(anyDouble(), any(double[].class));
            verify(event2).stepAccepted(anyDouble(), any(double[].class));
            verify(event3).stepAccepted(anyDouble(), any(double[].class));
            
            // Verify integration stopped at first event time
            assertEquals(0.3, result, 1e-10);
            
            // Use reflection to check protected isLastStep field
            Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
            isLastStepField.setAccessible(true);
            assertTrue((boolean) isLastStepField.get(integrator));
        }

    @Test
        public void testAcceptStepWithMultipleEventsVerifiesCorrectEventTimes() throws Exception {
            // Setup test data
            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                @Override
                public void integrate(ExpandableStatefulODE equations, double t) {
                    // dummy implementation for testing
                }
            };
            
            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
            when(interpolator.getGlobalCurrentTime()).thenReturn(10.0);
            when(interpolator.isForward()).thenReturn(true);
            
            // Create two events with different times
            EventState event1 = mock(EventState.class);
            when(event1.getEventTime()).thenReturn(2.0);
            when(event1.evaluateStep(interpolator)).thenReturn(true);
            
            EventState event2 = mock(EventState.class);
            when(event2.getEventTime()).thenReturn(5.0);
            when(event2.evaluateStep(interpolator)).thenReturn(true);
            
            // Set up integrator state using reflection
            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
            eventsStatesField.setAccessible(true);
            List<EventState> eventsStates = new ArrayList<>();
            eventsStates.add(event1);
            eventsStates.add(event2);
            eventsStatesField.set(integrator, eventsStates);
            
            Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("stateInitialized");
            statesInitializedField.setAccessible(true);
            statesInitializedField.set(integrator, false);
            
            Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
            stepHandlersField.setAccessible(true);
            stepHandlersField.set(integrator, new ArrayList<>());
            
            // Create test arrays
            double[] y = new double[1];
            double[] yDot = new double[1];
            
            // Execute using reflection
            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep",
                AbstractStepInterpolator.class, double[].class, double[].class, double.class);
            acceptStepMethod.setAccessible(true);
            double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 10.0);
            
            // Verify event processing times - this will catch the mutant
            verify(event1).stepAccepted(eq(2.0), any(double[].class));
            verify(event2).stepAccepted(eq(5.0), any(double[].class));
            
            // Additional verification
            Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
            isLastStepField.setAccessible(true);
            assertFalse(isLastStepField.getBoolean(integrator));
            assertEquals(10.0, result, 1e-10);
        }

    @Test
    public void testAcceptStep_DetectsMutatedEventAcceptance() throws Exception {
        // Create concrete integrator subclass
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // Empty implementation for testing
            }
        };
        
        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
        when(interpolator.isForward()).thenReturn(true);
        
        // Create multiple event states
        EventState event1 = mock(EventState.class);
        EventState event2 = mock(EventState.class);
        EventState event3 = mock(EventState.class);
        
        // Configure events to trigger different scenarios
        when(event1.evaluateStep(interpolator)).thenReturn(true);
        when(event2.evaluateStep(interpolator)).thenReturn(true);
        when(event3.evaluateStep(interpolator)).thenReturn(true);
        
        // First event will trigger stop condition
        when(event1.stop()).thenReturn(true);
        when(event1.getEventTime()).thenReturn(0.5);
        
        // Set up integrator state using reflection
        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
        eventsStatesField.setAccessible(true);
        List<EventState> eventStates = new ArrayList<EventState>();
        eventStates.add(event1);
        eventStates.add(event2);
        eventStates.add(event3);
        eventsStatesField.set(integrator, eventStates);
        
        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
        statesInitializedField.setAccessible(true);
        statesInitializedField.set(integrator, true);
        
        Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
        stepHandlersField.setAccessible(true);
        stepHandlersField.set(integrator, new ArrayList<StepHandler>());
        
        // Test data
        double[] y = new double[2];
        double[] yDot = new double[2];
        double tEnd = 1.0;
        
        // Execute the method using reflection
        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
            AbstractStepInterpolator.class, double[].class, double[].class, double.class);
        acceptStepMethod.setAccessible(true);
        double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
        
        // Verify all events received stepAccepted calls
        verify(event1).stepAccepted(eq(0.5), any(double[].class));
        verify(event2).stepAccepted(eq(0.5), any(double[].class));
        verify(event3).stepAccepted(eq(0.5), any(double[].class));
        
        // Also test reset scenario
        reset(event1, event2, event3);
        when(event1.stop()).thenReturn(false);
        when(event1.reset(anyDouble(), any(double[].class))).thenReturn(true);
        
        result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
        verify(event1).stepAccepted(eq(0.5), any(double[].class));
        verify(event2).stepAccepted(eq(0.5), any(double[].class));
        verify(event3).stepAccepted(eq(0.5), any(double[].class));
    }


}
