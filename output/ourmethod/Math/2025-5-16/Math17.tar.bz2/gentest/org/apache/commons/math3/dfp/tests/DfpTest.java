package gentest.org.apache.commons.math3.dfp.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.dfp.*;
import java.util.Arrays;
import org.apache.commons.math3.FieldElement;
 
public class DfpTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                         public void testMultiply_MinRadix() {
                                                                                                                                                             // Create mock field and get RADIX
                                                                                                                                                             DfpField mockField = mock(DfpField.class);
                                                                                                                                                             when(mockField.getRadixDigits()).thenReturn(4); // example value
                                                                                                                                                             int RADIX = 1 << mockField.getRadixDigits(); // RADIX is 2^digits
                                                                                                                                                             
                                                                                                                                                             // Test with x equal to RADIX (boundary case)
                                                                                                                                                             int x = RADIX;
                                                                                                                                                             Dfp dfp = mock(Dfp.class);
                                                                                                                                                             when(dfp.getField()).thenReturn(mockField);
                                                                                                                                                             
                                                                                                                                                             Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                             when(mockDfp.getField()).thenReturn(mockField);
                                                                                                                                                             when(dfp.newInstance(x)).thenReturn(mockDfp);
                                                                                                                                                             when(mockDfp.multiply(mockDfp)).thenReturn(mockDfp);
                                                                                                                                                             
                                                                                                                                                             Dfp result = dfp.multiply(x);
                                                                                                                                                             
                                                                                                                                                             // Should use slow multiplication path
                                                                                                                                                             verify(dfp).newInstance(x);
                                                                                                                                                             verify(mockDfp).multiply(mockDfp);
                                                                                                                                                             assertSame(mockDfp, result);
                                                                                                                                                         }

    @Test
                                                                                                                                                         public void testMultiply_DifferentRadixDigits() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             DfpField field = mock(DfpField.class);
                                                                                                                                                             when(field.getRadixDigits()).thenReturn(10); // Default radix digits
                                                                                                                                                             Dfp dfp1 = mock(Dfp.class);
                                                                                                                                                             when(dfp1.getField()).thenReturn(field);
                                                                                                                                                             when(dfp1.newInstance(2.5)).thenReturn(dfp1);
                                                                                                                                                             
                                                                                                                                                             DfpField differentField = mock(DfpField.class);
                                                                                                                                                             when(differentField.getRadixDigits()).thenReturn(5);
                                                                                                                                                             Dfp dfp2 = mock(Dfp.class);
                                                                                                                                                             when(dfp2.getField()).thenReturn(differentField);
                                                                                                                                                             when(dfp2.newInstance(3.0)).thenReturn(dfp2);
                                                                                                                                                             
                                                                                                                                                             // Execute
                                                                                                                                                             Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                             
                                                                                                                                                             // Verify
                                                                                                                                                             // Use reflection to access protected nans field
                                                                                                                                                             Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                             nansField.setAccessible(true);
                                                                                                                                                             byte resultNans = (byte) nansField.get(result);
                                                                                                                                                             
                                                                                                                                                             assertEquals(Dfp.QNAN, resultNans); // Should return QNAN for different radix
                                                                                                                                                             verify(field).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                                                                                                         }

    @Test
                                                                                                                                                         public void testMultiply_MixedSignNumbers() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                                                                                                                             Dfp dfp1 = field.getZero().newInstance(-2.5);
                                                                                                                                                             Dfp dfp2 = field.getZero().newInstance(3.0);
                                                                                                                                                             
                                                                                                                                                             // Execute
                                                                                                                                                             Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                             
                                                                                                                                                             // Verify
                                                                                                                                                             assertEquals(-7.5, result.toDouble(), 0.0001);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to access protected sign field
                                                                                                                                                             Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                             signField.setAccessible(true);
                                                                                                                                                             byte signValue = (byte) signField.get(result);
                                                                                                                                                             assertEquals(-1, signValue); // Negative result from negative * positive
                                                                                                                                                         }

    @Test
                                                                                                                                                     public void testMultiply_SameRadixDigits() {
                                                                                                                                                         // Setup
                                                                                                                                                         DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                                                                                                                         Dfp dfp1 = field.newDfp(2.5);
                                                                                                                                                         Dfp dfp2 = field.newDfp(3.0);
                                                                                                                                                         
                                                                                                                                                         // Execute
                                                                                                                                                         Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         assertEquals(7.5, result.toDouble(), 0.0001);
                                                                                                                                                         
                                                                                                                                                         // Verify sign through public methods
                                                                                                                                                         assertTrue(result.positiveOrNull());
                                                                                                                                                         
                                                                                                                                                         // Verify nans status through public methods
                                                                                                                                                         assertFalse(result.isNaN());
                                                                                                                                                         assertFalse(result.isInfinite());
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testMultiply_SecondOperandInfiniteFirstZero() throws Exception {
                                                                                                                                                         // Setup
                                                                                                                                                         DfpField field = mock(DfpField.class);
                                                                                                                                                         when(field.getRadixDigits()).thenReturn(10); // Assuming default radix digits
                                                                                                                                                         
                                                                                                                                                         // Create zero Dfp
                                                                                                                                                         Dfp dfp1 = mock(Dfp.class);
                                                                                                                                                         when(dfp1.isZero()).thenReturn(true);
                                                                                                                                                         when(dfp1.getField()).thenReturn(field);
                                                                                                                                                         
                                                                                                                                                         // Create infinite Dfp
                                                                                                                                                         Dfp dfp2 = mock(Dfp.class);
                                                                                                                                                         when(dfp2.isInfinite()).thenReturn(true);
                                                                                                                                                         when(dfp2.getField()).thenReturn(field);
                                                                                                                                                         
                                                                                                                                                         // Mock the multiply operation to return a QNAN
                                                                                                                                                         Dfp result = mock(Dfp.class);
                                                                                                                                                         when(dfp1.multiply(dfp2)).thenReturn(result);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to set up nans field
                                                                                                                                                         Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                         nansField.setAccessible(true);
                                                                                                                                                         nansField.set(result, Dfp.QNAN);
                                                                                                                                                         
                                                                                                                                                         // Execute
                                                                                                                                                         Dfp actualResult = dfp1.multiply(dfp2);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         byte resultNans = (byte) nansField.get(actualResult);
                                                                                                                                                         assertEquals(Dfp.QNAN, resultNans); // Should return QNAN
                                                                                                                                                         
                                                                                                                                                         verify(field).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testMultiply_NegativeNumbers() throws Exception {
                                                                                                                                                         // Setup
                                                                                                                                                         DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                                                                                                                         Dfp dfp1 = field.newDfp(-2.5);
                                                                                                                                                         Dfp dfp2 = field.newDfp(-3.0);
                                                                                                                                                         
                                                                                                                                                         // Execute
                                                                                                                                                         Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         assertEquals(7.5, result.toDouble(), 0.0001);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to access protected sign field
                                                                                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                         signField.setAccessible(true);
                                                                                                                                                         byte signValue = (byte) signField.get(result);
                                                                                                                                                         assertEquals(1, signValue); // Positive result from negative * negative
                                                                                                                                                     }

    @Test
                                                                                                                                                 public void testMultiply_NegativeNumber() throws Exception {
                                                                                                                                                     // Create test Dfp instance and field
                                                                                                                                                     DfpField field = new DfpField(100);
                                                                                                                                                     Dfp dfp = field.newDfp(1); // Start with 1 to multiply by -5000
                                                                                                                                                     
                                                                                                                                                     // Test multiplication by negative number within RADIX range
                                                                                                                                                     int x = -5000;
                                                                                                                                                     Dfp result = dfp.multiply(x);
                                                                                                                                                     
                                                                                                                                                     // Use reflection to access protected fields
                                                                                                                                                     Class<?> dfpClass = Dfp.class;
                                                                                                                                                     java.lang.reflect.Field mantField = dfpClass.getDeclaredField("mant");
                                                                                                                                                     mantField.setAccessible(true);
                                                                                                                                                     int[] mant = (int[]) mantField.get(result);
                                                                                                                                                     
                                                                                                                                                     java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                                                                                                                                     signField.setAccessible(true);
                                                                                                                                                     byte sign = (byte) signField.get(result);
                                                                                                                                                     
                                                                                                                                                     java.lang.reflect.Field expField = dfpClass.getDeclaredField("exp");
                                                                                                                                                     expField.setAccessible(true);
                                                                                                                                                     int exp = (int) expField.get(result);
                                                                                                                                                     
                                                                                                                                                     java.lang.reflect.Field nansField = dfpClass.getDeclaredField("nans");
                                                                                                                                                     nansField.setAccessible(true);
                                                                                                                                                     byte nans = (byte) nansField.get(result);
                                                                                                                                                     
                                                                                                                                                     // Assert expected values
                                                                                                                                                     assertEquals(-5000, result.intValue()); // Verify the actual multiplication result
                                                                                                                                                     assertEquals(-1, sign); // Result should be negative
                                                                                                                                                     assertEquals(0, exp); // Exponent should be 0 for this case
                                                                                                                                                     assertEquals(Dfp.FINITE, nans); // Should be a finite number
                                                                                                                                                 }

    @Test
                                                                                                                                                 public void testMultiply_LargeNumbers() throws Exception {
                                                                                                                                                     // Setup
                                                                                                                                                     org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100); // Assuming 100 radix digits
                                                                                                                                                     org.apache.commons.math3.dfp.Dfp dfp1 = field.newDfp("1.0e100"); // Using String constructor for large numbers
                                                                                                                                                     org.apache.commons.math3.dfp.Dfp dfp2 = field.newDfp("2.0e100"); // Using String constructor for large numbers
                                                                                                                                                     
                                                                                                                                                     // Execute
                                                                                                                                                     org.apache.commons.math3.dfp.Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                     
                                                                                                                                                     // Verify
                                                                                                                                                     assertEquals(2.0e200, result.toDouble(), 1.0e185); // Allowing some tolerance
                                                                                                                                                     
                                                                                                                                                     // Use reflection to access protected fields
                                                                                                                                                     java.lang.reflect.Field signField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("sign");
                                                                                                                                                     signField.setAccessible(true);
                                                                                                                                                     byte sign = (byte) signField.get(result);
                                                                                                                                                     assertEquals(1, sign);
                                                                                                                                                     
                                                                                                                                                     java.lang.reflect.Field nansField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("nans");
                                                                                                                                                     nansField.setAccessible(true);
                                                                                                                                                     byte nans = (byte) nansField.get(result);
                                                                                                                                                     assertEquals(org.apache.commons.math3.dfp.Dfp.FINITE, nans);
                                                                                                                                                 }

    @Test
                                                                                                                                                 public void testMultiply_SmallNumbers() {
                                                                                                                                                     // Setup
                                                                                                                                                     org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100); // Assuming 100 radix digits based on the tested method
                                                                                                                                                     org.apache.commons.math3.dfp.Dfp dfp1 = field.newDfp(1.0e-100);
                                                                                                                                                     org.apache.commons.math3.dfp.Dfp dfp2 = field.newDfp(2.0e-100);
                                                                                                                                                     
                                                                                                                                                     // Execute
                                                                                                                                                     org.apache.commons.math3.dfp.Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                     
                                                                                                                                                     // Verify
                                                                                                                                                     assertEquals(2.0e-200, result.toDouble(), 1.0e-215); // Allowing some tolerance
                                                                                                                                                     
                                                                                                                                                     try {
                                                                                                                                                         // Use reflection to access protected fields
                                                                                                                                                         Field signField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("sign");
                                                                                                                                                         signField.setAccessible(true);
                                                                                                                                                         int sign = signField.getInt(result);
                                                                                                                                                         assertEquals(1, sign);
                                                                                                                                                         
                                                                                                                                                         Field nansField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("nans");
                                                                                                                                                         nansField.setAccessible(true);
                                                                                                                                                         byte nans = nansField.getByte(result);
                                                                                                                                                         assertEquals(org.apache.commons.math3.dfp.Dfp.FINITE, nans);
                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                         fail("Failed to access protected fields through reflection: " + e.getMessage());
                                                                                                                                                     }
                                                                                                                                                 }

    @Test
                                                                                                                                             public void testMultiply_RequiresRounding() throws Exception {
                                                                                                                                                 // Setup - Create numbers that will require rounding during multiplication
                                                                                                                                                 // Using default field settings
                                                                                                                                                 DfpField field = new DfpField(20); // Using just precision parameter
                                                                                                                                                 Dfp dfp1 = field.newDfp("1.23456789");
                                                                                                                                                 Dfp dfp2 = field.newDfp("9.87654321");
                                                                                                                                                 
                                                                                                                                                 // Execute
                                                                                                                                                 Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 // The exact value might depend on rounding implementation
                                                                                                                                                 assertEquals(12.19326311, result.toDouble(), 1.0e-7);
                                                                                                                                                 
                                                                                                                                                 // Use reflection to access protected fields
                                                                                                                                                 Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                 signField.setAccessible(true);
                                                                                                                                                 byte sign = (byte) signField.get(result);
                                                                                                                                                 assertEquals(1, sign);
                                                                                                                                                 
                                                                                                                                                 Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                 nansField.setAccessible(true);
                                                                                                                                                 byte nans = (byte) nansField.get(result);
                                                                                                                                                 assertEquals(0, nans); // 0 typically represents FINITE in Dfp implementation
                                                                                                                                             }

    @Test
                                                                                                                                             public void testMultiply_OutsideRadixRange() {
                                                                                                                                                 // Define RADIX (assuming base 10)
                                                                                                                                                 final int RADIX = 10;
                                                                                                                                                 
                                                                                                                                                 // Create mock field
                                                                                                                                                 DfpField mockField = mock(DfpField.class);
                                                                                                                                                 when(mockField.getRadixDigits()).thenReturn(RADIX);
                                                                                                                                                 
                                                                                                                                                 // Create zero instance using field's getZero() method
                                                                                                                                                 Dfp zero = mock(Dfp.class);
                                                                                                                                                 when(mockField.getZero()).thenReturn(zero);
                                                                                                                                                 
                                                                                                                                                 // Create test Dfp instance (1) by creating zero and adding one
                                                                                                                                                 Dfp one = mock(Dfp.class);
                                                                                                                                                 when(zero.add(any(Dfp.class))).thenReturn(one);
                                                                                                                                                 when(zero.newInstance(1)).thenReturn(mock(Dfp.class));
                                                                                                                                                 
                                                                                                                                                 // Test with x outside RADIX range
                                                                                                                                                 int x = RADIX + 1; // Outside RADIX range
                                                                                                                                                 
                                                                                                                                                 // Mock the newInstance and multiply methods
                                                                                                                                                 Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                 when(one.newInstance(x)).thenReturn(mockDfp);
                                                                                                                                                 when(mockDfp.multiply(mockDfp)).thenReturn(mockDfp);
                                                                                                                                                 
                                                                                                                                                 Dfp result = one.multiply(x);
                                                                                                                                                 
                                                                                                                                                 // Verify the slow multiplication path was taken
                                                                                                                                                 verify(one).newInstance(x);
                                                                                                                                                 verify(mockDfp).multiply(mockDfp);
                                                                                                                                                 assertSame(mockDfp, result);
                                                                                                                                             }

    @Test
                                                                                                                                             public void testMultiply_SecondOperandInfiniteFirstFiniteNonZero() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 DfpField field = new DfpField(100);
                                                                                                                                                 Dfp dfp1 = field.newDfp(2.5);
                                                                                                                                                 // Create negative infinite Dfp using the proper constructor
                                                                                                                                                 Dfp dfp2 = field.newDfp(Double.NEGATIVE_INFINITY);
                                                                                                                                                 
                                                                                                                                                 // Execute
                                                                                                                                                 Dfp result = dfp1.multiply(dfp2);
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 // Use reflection to access protected fields
                                                                                                                                                 java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                 nansField.setAccessible(true);
                                                                                                                                                 byte resultNans = (byte) nansField.get(result);
                                                                                                                                                 
                                                                                                                                                 java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                 signField.setAccessible(true);
                                                                                                                                                 byte resultSign = (byte) signField.get(result);
                                                                                                                                                 
                                                                                                                                                 assertEquals(1, resultNans);  // 1 represents INFINITE
                                                                                                                                                 assertEquals(-1, resultSign); // Negative infinity
                                                                                                                                             }

    @Test
                                                                                                                                         public void testMultiply_Zero() {
                                                                                                                                             // Test multiplication by zero
                                                                                                                                             try {
                                                                                                                                                 // Create a DfpField and zero Dfp instance
                                                                                                                                                 DfpField field = new DfpField(10); // Assuming 10 digits precision
                                                                                                                                                 Dfp dfp = field.newDfp(5); // Create Dfp with value 5 using factory method
                                                                                                                                                 int x = 0;
                                                                                                                                                 
                                                                                                                                                 // Perform multiplication
                                                                                                                                                 Dfp result = dfp.multiply(x);
                                                                                                                                                 
                                                                                                                                                 // Verify results using public methods rather than reflection
                                                                                                                                                 assertTrue(result.isZero());
                                                                                                                                                 assertFalse(result.isNaN());
                                                                                                                                                 assertTrue(result.positiveOrNull()); // 0 is considered positive
                                                                                                                                                 
                                                                                                                                                 // Alternative verification using toString or doubleValue
                                                                                                                                                 assertEquals(0.0, result.toDouble(), 0.0);
                                                                                                                                                 
                                                                                                                                             } catch (Exception e) {
                                                                                                                                                 fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                         }

    @Test
                                                                                                                                         public void testMultiply_ZeroResult() {
                                                                                                                                             // Setup
                                                                                                                                             DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                                                                                                             Dfp dfp1 = field.newDfp(2.5); // Using newDfp with double parameter
                                                                                                                                             Dfp dfp2 = field.getZero();    // Using field's getZero() method
                                                                                                                                             
                                                                                                                                             // Execute
                                                                                                                                             Dfp result = dfp1.multiply(dfp2);
                                                                                                                                             
                                                                                                                                             // Verify
                                                                                                                                             assertTrue(result.isZero());
                                                                                                                                             
                                                                                                                                             // Use reflection to access protected exp field
                                                                                                                                             try {
                                                                                                                                                 Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                 expField.setAccessible(true);
                                                                                                                                                 int expValue = (int) expField.get(result);
                                                                                                                                                 assertEquals(0, expValue); // Zero exponent should be 0
                                                                                                                                             } catch (Exception e) {
                                                                                                                                                 fail("Failed to access exp field: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                         }

    @Test
                                                                                                                                     public void testMultiply_FirstOperandNaN() {
                                                                                                                                         // Setup
                                                                                                                                         // Create field with 20 radix digits
                                                                                                                                         org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(20);
                                                                                                                                         
                                                                                                                                         // Create NaN using divide by zero
                                                                                                                                         org.apache.commons.math3.dfp.Dfp zero = field.newDfp(0.0);
                                                                                                                                         org.apache.commons.math3.dfp.Dfp dfp1 = zero.divide(zero);  // This creates NaN
                                                                                                                                         org.apache.commons.math3.dfp.Dfp dfp2 = field.newDfp(3.0);  // Regular number
                                                                                                                                         
                                                                                                                                         // Execute
                                                                                                                                         org.apache.commons.math3.dfp.Dfp result = dfp1.multiply(dfp2);
                                                                                                                                         
                                                                                                                                         // Verify
                                                                                                                                         assertTrue(result.isNaN());  // Should return NaN when any operand is NaN
                                                                                                                                     }

    @Test
                                                                                                                                     public void testMultiply_SecondOperandNaN() {
                                                                                                                                         // Setup
                                                                                                                                         DfpField field = new DfpField(100); // Assuming 100 radix digits
                                                                                                                                         Dfp dfp1 = field.newDfp(2.5);
                                                                                                                                         Dfp dfp2 = field.newDfp(Double.NaN); // Create NaN using Double.NaN
                                                                                                                                         
                                                                                                                                         // Execute
                                                                                                                                         Dfp result = dfp1.multiply(dfp2);
                                                                                                                                         
                                                                                                                                         // Verify
                                                                                                                                         assertTrue(result.isNaN()); // Should return NaN
                                                                                                                                     }

    @Test
                                                                                                                             public void testMultiply_FirstOperandInfiniteSecondZero() throws Exception {
                                                                                                                                 // Setup
                                                                                                                                 DfpField field = new DfpField(20); // Assuming 20 digits precision
                                                                                                                                 // Create infinite Dfp using reflection to access protected constructor
                                                                                                                                 Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                 Dfp dfp1 = constructor.newInstance(field, (byte)1, (byte)1); // sign=1 (positive), nans=1 (INFINITE)
                                                                                                                                 Dfp dfp2 = field.getZero(); // Create zero Dfp
                                                                                                                                 
                                                                                                                                 // Execute
                                                                                                                                 Dfp result = dfp1.multiply(dfp2);
                                                                                                                                 
                                                                                                                                 // Verify
                                                                                                                                 // Use reflection to access protected nans field
                                                                                                                                 java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                 nansField.setAccessible(true);
                                                                                                                                 byte resultNans = (byte) nansField.get(result);
                                                                                                                                 
                                                                                                                                 assertEquals(1, resultNans); // QNAN is typically represented as 1
                                                                                                                                 // Verify FLAG_INVALID was set
                                                                                                                                 java.lang.reflect.Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlags");
                                                                                                                                 ieeeFlagsField.setAccessible(true);
                                                                                                                                 int flags = (int) ieeeFlagsField.get(field);
                                                                                                                                 assertEquals(DfpField.FLAG_INVALID, flags & DfpField.FLAG_INVALID);
                                                                                                                             }

    @Test
                                                                                                                         public void testMultiply_WithinRadixRange() throws Exception {
                                                                                                                             // Create test Dfp instance
                                                                                                                             DfpField field = new DfpField(100); // Assuming RADIX is 10000 or larger
                                                                                                                             Dfp dfp = field.newDfp(1); // Create instance with value 1
                                                                                                                             
                                                                                                                             // Test with x within RADIX range (0 <= x < RADIX)
                                                                                                                             int x = 5000; // Within RADIX range
                                                                                                                             Dfp result = dfp.multiply(x);
                                                                                                                             
                                                                                                                             // Verify the result through public methods
                                                                                                                             assertEquals(5000, result.intValue());
                                                                                                                             assertFalse(result.isInfinite());
                                                                                                                             assertFalse(result.isNaN());
                                                                                                                             
                                                                                                                             // If we need to verify mantissa specifically, use reflection
                                                                                                                             try {
                                                                                                                                 Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                 mantField.setAccessible(true);
                                                                                                                                 int[] mant = (int[]) mantField.get(result);
                                                                                                                                 // Check if mantissa array has elements before accessing
                                                                                                                                 if (mant != null && mant.length > 0) {
                                                                                                                                     assertEquals(5000, mant[mant.length - 1]); // Assuming last element is least significant digit
                                                                                                                                 } else {
                                                                                                                                     fail("Mantissa array is empty or null");
                                                                                                                                 }
                                                                                                                             } catch (NoSuchFieldException | SecurityException | IllegalAccessException e) {
                                                                                                                                 fail("Reflection failed to access mantissa field: " + e.getMessage());
                                                                                                                             }
                                                                                                                         }

    @Test
                                                                                                                         public void testMultiply_WithNaN() throws Exception {
                                                                                                                             // Create a Dfp instance with NaN using the proper constructor
                                                                                                                             DfpField field = new DfpField(10); // Assuming 10 decimal digits
                                                                                                                             
                                                                                                                             // Create NaN using reflection since the constructor is protected
                                                                                                                             Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                             constructor.setAccessible(true);
                                                                                                                             Dfp dfp = constructor.newInstance(field, (byte)1, (byte)-1); // Using -1 as NaN flag
                                                                                                                             
                                                                                                                             // Test multiplication when the Dfp is NaN
                                                                                                                             int x = 5;
                                                                                                                             Dfp result = dfp.multiply(x);
                                                                                                                             
                                                                                                                             // Verify the result is still NaN
                                                                                                                             assertTrue(result.isNaN());
                                                                                                                         }

    @Test
                                                                                                                     public void testMultiply_InfinityByZero() {
                                                                                                                         // Create a Dfp field and instance
                                                                                                                         DfpField field = new DfpField(100);
                                                                                                                         
                                                                                                                         // Create infinity Dfp by dividing 1 by 0
                                                                                                                         Dfp one = field.getOne();
                                                                                                                         Dfp zero = field.getZero();
                                                                                                                         Dfp infinity = one.divide(zero);
                                                                                                                         
                                                                                                                         // Test infinity multiplied by zero (should be NaN)
                                                                                                                         int multiplier = 0;
                                                                                                                         Dfp result = infinity.multiply(multiplier);
                                                                                                                         
                                                                                                                         // Create a NaN Dfp for comparison by performing an operation that results in NaN
                                                                                                                         Dfp nanDfp = zero.divide(zero);  // 0/0 will produce NaN
                                                                                                                         
                                                                                                                         // Use reflection to access protected nans field
                                                                                                                         try {
                                                                                                                             Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                             nansField.setAccessible(true);
                                                                                                                             byte resultNans = (byte)nansField.get(result);
                                                                                                                             byte expectedNans = (byte)nansField.get(nanDfp);
                                                                                                                             assertEquals(expectedNans, resultNans);
                                                                                                                         } catch (NoSuchFieldException e) {
                                                                                                                             fail("Failed to access nans field: " + e.getMessage());
                                                                                                                         } catch (IllegalAccessException e) {
                                                                                                                             fail("Failed to access nans field: " + e.getMessage());
                                                                                                                         }
                                                                                                                     }

    @Test
                                                                                                                 public void testMultiply_BothOperandsInfinite() throws Exception {
                                                                                                                     // Setup
                                                                                                                     org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100);
                                                                                                                     // Create positive infinity by dividing 1 by 0
                                                                                                                     org.apache.commons.math3.dfp.Dfp dfp1 = field.getOne().divide(field.getZero());
                                                                                                                     // Create negative infinity by dividing -1 by 0
                                                                                                                     org.apache.commons.math3.dfp.Dfp dfp2 = field.getOne().negate().divide(field.getZero());
                                                                                                                     
                                                                                                                     // Execute
                                                                                                                     org.apache.commons.math3.dfp.Dfp result = dfp1.multiply(dfp2);
                                                                                                                     
                                                                                                                     // Verify
                                                                                                                     try {
                                                                                                                         // Use reflection to access protected fields
                                                                                                                         java.lang.reflect.Field nansField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("nans");
                                                                                                                         nansField.setAccessible(true);
                                                                                                                         byte resultNans = (byte) nansField.get(result);
                                                                                                                         assertEquals(org.apache.commons.math3.dfp.Dfp.INFINITE, resultNans);
                                                                                                                         
                                                                                                                         java.lang.reflect.Field signField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("sign");
                                                                                                                         signField.setAccessible(true);
                                                                                                                         byte resultSign = (byte) signField.get(result);
                                                                                                                         assertEquals(-1, resultSign); // Negative infinity
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Reflection failed: " + e.getMessage());
                                                                                                                     }
                                                                                                                 }

    @Test
                                                                                                 public void testMultiply_FirstOperandInfiniteSecondFiniteNonZero() throws Exception {
                                                                                                     // Setup
                                                                                                     org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100);
                                                                                                     
                                                                                                     // Create infinite Dfp (dfp1) by dividing 1 by 0
                                                                                                     org.apache.commons.math3.dfp.Dfp dfp1 = field.getOne().divide(field.getZero());
                                                                                                     
                                                                                                     // Create finite non-zero Dfp (dfp2) by multiplying field's one by 2
                                                                                                     org.apache.commons.math3.dfp.Dfp dfp2 = field.getOne().multiply(2);
                                                                                                     
                                                                                                     // Execute
                                                                                                     org.apache.commons.math3.dfp.Dfp result = dfp1.multiply(dfp2);
                                                                                                     
                                                                                                     // Verify
                                                                                                     // Use reflection to access protected fields
                                                                                                     Class<?> dfpClass = org.apache.commons.math3.dfp.Dfp.class;
                                                                                                     java.lang.reflect.Field nansField = dfpClass.getDeclaredField("nans");
                                                                                                     nansField.setAccessible(true);
                                                                                                     byte resultNans = (byte) nansField.get(result);
                                                                                                     
                                                                                                     java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                                                                                     signField.setAccessible(true);
                                                                                                     byte resultSign = (byte) signField.get(result);
                                                                                                     
                                                                                                     // Check for infinite flag (assuming INFINITE is represented by byte value 1)
                                                                                                     org.junit.Assert.assertEquals((byte)1, resultNans);
                                                                                                     // Check for positive sign
                                                                                                     org.junit.Assert.assertEquals(1, resultSign);
                                                                                                 }

    @Test
                                                                                 public void testMultiply_MaxRadixMinusOne() throws Exception {
                                                                                     // Create test objects and define constants
                                                                                     DfpField field = new DfpField(100);
                                                                                     Dfp dfp = field.getOne();  // Using getOne() to get a Dfp with value 1
                                                                                     
                                                                                     // Get radix from field
                                                                                     
                                                                                     try {
                                                                                         // Use reflection to access protected fields
                                                                                         Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                         mantField.setAccessible(true);
                                                                                         
                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                         signField.setAccessible(true);
                                                                                         
                                                                                         Field expField = Dfp.class.getDeclaredField("exp");
                                                                                         expField.setAccessible(true);
                                                                                         
                                                                                         Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                         nansField.setAccessible(true);
                                                                                         
                                                                                         // Access FINITE constant through reflection
                                                                                         Field finiteField = Dfp.class.getDeclaredField("FINITE");
                                                                                         finiteField.setAccessible(true);
                                                                                         byte FINITE = (byte) finiteField.get(null);
                                                                                         
                                                                                         // Should use fast multiplication path
                                                                                     } catch (NoSuchFieldException | SecurityException | IllegalAccessException e) {
                                                                                         fail("Reflection failed: " + e.getMessage());
                                                                                     }
                                                                                 }

    @Test
                                                                                 public void testMultiply_WithInfinity() throws Exception {
                                                                                     // Create a Dfp field and instance
                                                                                     DfpField field = new DfpField(10);
                                                                                     // Create infinite Dfp using constructor directly
                                                                                     
                                                                                     // Test multiplication when the Dfp is infinite
                                                                                     int x = 5;
                                                                                     
                                                                                     // Use reflection to access protected fields
                                                                                     Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                     nansField.setAccessible(true);
                                                                                     Field signField = Dfp.class.getDeclaredField("sign");
                                                                                     signField.setAccessible(true);
                                                                                     
                                                                                     
                                                                                     // Test with negative multiplier
                                                                                     x = -5;
                                                                                 }

    @Test
                                                                            public void testMultiplyWithZeroDetectsMutant() {
                                                                                // Setup test environment
                                                                                DfpField field = mock(DfpField.class);
                                                                                when(field.getRadixDigits()).thenReturn(10); // Assuming 10 digits for simplicity
                                                                                
                                                                                // Create zero Dfp
                                                                                Dfp zero = mock(Dfp.class);
                                                                                when(zero.getField()).thenReturn(field);
                                                                                when(zero.isZero()).thenReturn(true);
                                                                                when(zero.multiply(any(Dfp.class))).thenAnswer(invocation -> {
                                                                                    Dfp arg = invocation.getArgument(0);
                                                                                    Dfp result = mock(Dfp.class);
                                                                                    when(result.getField()).thenReturn(field);
                                                                                    when(result.isZero()).thenReturn(true);
                                                                                    return result;
                                                                                });
                                                                                
                                                                                // Create non-zero Dfp
                                                                                Dfp nonZero = mock(Dfp.class);
                                                                                when(nonZero.getField()).thenReturn(field);
                                                                                when(nonZero.isZero()).thenReturn(false);
                                                                                when(nonZero.multiply(any(Dfp.class))).thenAnswer(invocation -> {
                                                                                    Dfp arg = invocation.getArgument(0);
                                                                                    Dfp result = mock(Dfp.class);
                                                                                    when(result.getField()).thenReturn(field);
                                                                                    when(result.isZero()).thenReturn(arg.isZero());
                                                                                    return result;
                                                                                });
                                                                            
                                                                                // Test case 1: Multiply zero by non-zero
                                                                                Dfp result1 = zero.multiply(nonZero);
                                                                                assertTrue("Multiplying zero should result in zero", result1.isZero());
                                                                                
                                                                                // Test case 2: Multiply non-zero by zero
                                                                                Dfp result2 = nonZero.multiply(zero);
                                                                                assertTrue("Multiplying by zero should result in zero", result2.isZero());
                                                                                
                                                                                // Test case 3: Multiply zero by zero
                                                                                Dfp result3 = zero.multiply(zero);
                                                                                assertTrue("Multiplying zero by zero should result in zero", result3.isZero());
                                                                                
                                                                                // Verify no invalid flags were set
                                                                                verify(field, never()).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                            }

    @Test
                                                                    public void testMultiplyBoundaryConditions() {
                                                                        // Setup
                                                                        DfpField field = mock(DfpField.class);
                                                                        when(field.getRadixDigits()).thenReturn(1); // Needed for constructor
                                                                        Dfp dfp = mock(Dfp.class);
                                                                        when(dfp.getField()).thenReturn(field);
                                                                        when(dfp.newInstance(anyDouble())).thenAnswer(invocation -> {
                                                                            Dfp instance = mock(Dfp.class);
                                                                            when(instance.getField()).thenReturn(field);
                                                                            return instance;
                                                                        });
                                                                        
                                                                        // Test negative value (should use slow path)
                                                                        Dfp result = dfp.multiply(-1);
                                                                        verify(dfp).newInstance(-1);
                                                                        
                                                                        // Test value just below RADIX (should use fast path)
                                                                        reset(dfp);
                                                                        Dfp expectedResult = mock(Dfp.class);
                                                                        when(dfp.newInstance(anyInt())).thenReturn(expectedResult);
                                                                        result = dfp.multiply(Dfp.RADIX - 1);
                                                                        assertEquals(expectedResult, result);
                                                                        
                                                                        // Test value equal to RADIX (should use slow path)
                                                                        reset(dfp);
                                                                        dfp.multiply(Dfp.RADIX);
                                                                        verify(dfp).newInstance(Dfp.RADIX);
                                                                    }

    @Test
                                                                public void testMultiplyWithZeroShouldUseFastPath() {
                                                                    // Setup
                                                                    DfpField field = mock(DfpField.class);
                                                                    Dfp dfp = mock(Dfp.class);
                                                                    Dfp result = mock(Dfp.class);
                                                                    
                                                                    // Configure mocks
                                                                    when(field.getZero()).thenReturn(result);
                                                                    when(dfp.multiply(0)).thenReturn(result);
                                                                    
                                                                    // Test with x=0 - should use fast path in original, slow path in mutant
                                                                    Dfp actual = dfp.multiply(0);
                                                                    
                                                                    // Verify the result is correct (would fail for mutant)
                                                                    assertEquals(result, actual);
                                                                    
                                                                    // Verify no new instance was created (indirect verification of fast path)
                                                                    verify(field, never()).getZero();
                                                                }

    @Test
                                                           public void testMultiplyInfiniteFiniteCases() throws Exception {
                                                               // Create test field
                                                               DfpField field = new DfpField(20);
                                                               
                                                               // Get constructor for infinite values via reflection
                                                               Constructor<Dfp> infiniteConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                               infiniteConstructor.setAccessible(true);
                                                               
                                                               // Case 1: Current is infinite, other is finite with non-zero mantissa
                                                               Dfp infinite = infiniteConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                               Dfp finiteNonZero = field.newDfp(5); // finite with non-zero mantissa
                                                               
                                                               // Should behave differently in original vs mutant
                                                               Dfp result1 = infinite.multiply(finiteNonZero);
                                                               assertTrue(result1.isInfinite());
                                                               
                                                               // Case 2: Current is finite with non-zero mantissa, other is infinite
                                                               Dfp finiteNonZero2 = field.newDfp(3); // finite with non-zero mantissa
                                                               Dfp infinite2 = infiniteConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                               
                                                               // Should behave differently in original vs mutant
                                                               Dfp result2 = finiteNonZero2.multiply(infinite2);
                                                               assertTrue(result2.isInfinite());
                                                               
                                                               // Case 3: Both are finite with non-zero mantissa
                                                               Dfp finite1 = field.newDfp(2);
                                                               Dfp finite2 = field.newDfp(4);
                                                               Dfp result3 = finite1.multiply(finite2);
                                                               assertFalse(result3.isInfinite());
                                                               assertEquals(8, result3.intValue());
                                                               
                                                               // Case 4: Current is infinite, other is infinite
                                                               Dfp infinite3 = infiniteConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                               Dfp infinite4 = infiniteConstructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                               Dfp result4 = infinite3.multiply(infinite4);
                                                               assertTrue(result4.isInfinite());
                                                           }

    @Test
                                           public void testMultiplyInfiniteOrFiniteNonZeroMutant() throws Exception {
                                               // Setup test environment
                                               DfpField field = new DfpField(20); // Assuming 20 radix digits
                                               Dfp infiniteNum = field.newDfp(Double.POSITIVE_INFINITY);
                                               Dfp finiteNonZeroNum = field.newDfp(5); // Finite with non-zero mantissa
                                               Dfp finiteZeroNum = field.newDfp(0); // Finite with zero mantissa
                                               Dfp nanNum = field.newDfp(Double.NaN);
                                               
                                               // Test case 1: Current is INFINITE, x is not FINITE (should return this in original, but mutant would enter branch)
                                               Dfp result1 = infiniteNum.multiply(nanNum);
                                               assertTrue("Should return NaN when multiplying INFINITE by NaN", result1.isNaN());
                                               
                                               // Test case 2: Current is not INFINITE, x is FINITE with non-zero mantissa (should not enter branch in original)
                                               Dfp finiteNum = field.newDfp(2);
                                               Dfp result2 = finiteNum.multiply(finiteNonZeroNum);
                                               // Use reflection to access protected sign field
                                               Field signField = Dfp.class.getDeclaredField("sign");
                                               signField.setAccessible(true);
                                               int result2Sign = (byte) signField.get(result2);
                                               assertEquals("Sign should be positive when multiplying two positive numbers", 
                                                           1, result2Sign);
                                               assertFalse("Result should not be infinite when multiplying two finite numbers",
                                                           result2.isInfinite());
                                               
                                               // Test case 3: Current is INFINITE, x is FINITE with non-zero mantissa (should enter branch in both)
                                               Dfp result3 = infiniteNum.multiply(finiteNonZeroNum);
                                               int result3Sign = (byte) signField.get(result3);
                                               assertEquals("Sign should be positive when multiplying positive INFINITE by positive finite", 
                                                           1, result3Sign);
                                               assertTrue("Result should be infinite", result3.isInfinite());
                                               
                                               // Test case 4: Current is FINITE with zero mantissa, x is FINITE with non-zero mantissa
                                               // (should not enter branch in original but would in mutant)
                                               Dfp zeroNum = field.newDfp(0);
                                               Dfp result4 = zeroNum.multiply(finiteNonZeroNum);
                                               assertTrue("Result should be zero", result4.isZero());
                                               int result4Sign = (byte) signField.get(result4);
                                               assertEquals("Sign should be positive when multiplying zero by positive", 
                                                           1, result4Sign);
                                           }

    @Test
                                  public void testMultiplyWithZeroShouldUseFastPath1() {
                                      // Setup
                                      DfpField field = new DfpField(100); // Assuming RADIX is 100 for this test
                                      Dfp dfp = field.newDfp(5); // Create Dfp with value 5 using proper factory method
                                      
                                      // Test x=0 which should use fast path
                                      Dfp result = dfp.multiply(0);
                                      
                                      // Verify the result is zero (expected behavior)
                                      assertTrue(result.isZero());
                                      
                                      // Test boundary cases and verify results
                                      // x=-1 (should use slow path)
                                      Dfp minusOneResult = dfp.multiply(-1);
                                      assertEquals(-5, minusOneResult.intValue());
                                      
                                      // x=1 (should use fast path)
                                      Dfp oneResult = dfp.multiply(1);
                                      assertEquals(5, oneResult.intValue());
                                      
                                      // x=RADIX-1 (should use fast path)
                                      Dfp maxFastResult = dfp.multiply(99); // Assuming RADIX is 100
                                      assertEquals(495, maxFastResult.intValue());
                                      
                                      // x=RADIX (should use slow path)
                                      Dfp slowPathResult = dfp.multiply(100);
                                      assertEquals(500, slowPathResult.intValue());
                                  }

    @Test
                              public void testMultiplyWithZeroDetectsMutant1() throws Exception {
                                  // Create test DFP field and values
                                  DfpField field = new DfpField(10); // Assuming 10 radix digits
                                  Dfp zero = field.getZero();
                                  Dfp nonZero = field.newDfp(5);
                                  
                                  // Test 0 * non-zero
                                  Dfp result1 = zero.multiply(nonZero);
                                  assertTrue("0 * x should be 0", result1.isZero());
                                  java.lang.reflect.Field signField1 = Dfp.class.getDeclaredField("sign");
                                  signField1.setAccessible(true);
                                  assertEquals("Sign should be positive", 1, signField1.getByte(result1));
                                  
                                  // Test non-zero * 0
                                  Dfp result2 = nonZero.multiply(zero);
                                  assertTrue("x * 0 should be 0", result2.isZero());
                                  java.lang.reflect.Field signField2 = Dfp.class.getDeclaredField("sign");
                                  signField2.setAccessible(true);
                                  assertEquals("Sign should be positive", 1, signField2.getByte(result2));
                                  
                                  // Test 0 * 0
                                  Dfp result3 = zero.multiply(zero);
                                  assertTrue("0 * 0 should be 0", result3.isZero());
                                  java.lang.reflect.Field signField3 = Dfp.class.getDeclaredField("sign");
                                  signField3.setAccessible(true);
                                  assertEquals("Sign should be positive", 1, signField3.getByte(result3));
                                  
                                  // Test negative zero cases
                                  Dfp negativeZero = field.getZero();
                                  java.lang.reflect.Field signField4 = Dfp.class.getDeclaredField("sign");
                                  signField4.setAccessible(true);
                                  signField4.setByte(negativeZero, (byte)-1);
                                  
                                  Dfp result4 = negativeZero.multiply(nonZero);
                                  assertTrue("-0 * x should be 0", result4.isZero());
                                  java.lang.reflect.Field signField5 = Dfp.class.getDeclaredField("sign");
                                  signField5.setAccessible(true);
                                  assertEquals("Sign should be negative", -1, signField5.getByte(result4));
                                  
                                  Dfp result5 = nonZero.multiply(negativeZero);
                                  assertTrue("x * -0 should be 0", result5.isZero());
                                  java.lang.reflect.Field signField6 = Dfp.class.getDeclaredField("sign");
                                  signField6.setAccessible(true);
                                  assertEquals("Sign should be negative", -1, signField6.getByte(result5));
                                  
                                  Dfp result6 = negativeZero.multiply(negativeZero);
                                  assertTrue("-0 * -0 should be 0", result6.isZero());
                                  java.lang.reflect.Field signField7 = Dfp.class.getDeclaredField("sign");
                                  signField7.setAccessible(true);
                                  assertEquals("Sign should be positive", 1, signField7.getByte(result6));
                              }

    @Test
                     public void testMultiplyInfiniteByFiniteWithZeroMantissa() throws Exception {
                         // Create a finite Dfp with last mantissa digit = 0
                         DfpField field = new DfpField(20); // Assuming 20 digits
                         Dfp finite = field.getOne(); // Start with 1
                         
                         // Use reflection to access protected fields
                         java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                         mantField.setAccessible(true);
                         int[] mant = (int[]) mantField.get(finite);
                         
                         // Set up finite number's mantissa to have last digit 0 but not be zero
                         mant[mant.length - 1] = 0; // Explicitly set last digit to 0
                         for (int i = 0; i < mant.length - 1; i++) {
                             mant[i] = 1; // Set other digits to non-zero
                         }
                         mantField.set(finite, mant);
                         
                         java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                         expField.setAccessible(true);
                         expField.set(finite, 1); // Make sure it's not zero
                         
                         // Create an infinite Dfp using public methods
                         Dfp infinite = field.newDfp(Double.POSITIVE_INFINITY);
                         
                         // Test multiplication
                         Dfp result = finite.multiply(infinite);
                         
                         // Original code would handle this as special case (likely returning infinite)
                         // Mutant would do normal multiplication
                         assertTrue("Multiplication of infinite by finite with zero mantissa should be infinite", 
                                   result.isInfinite());
                     }

    @Test
             public void testMultiply_FiniteZeroByInfinite_ShouldReturnQNAN() {
                 // Setup test objects
                 DfpField field = new DfpField(20); // arbitrary radix digits
                 Dfp finiteZero = field.getZero(); // finite zero using public method
                 Dfp one = field.getOne(); // get one
                 Dfp zero = field.getZero(); // get zero
                 Dfp infinite = one.divide(zero); // create infinite by dividing 1/0
                 
                 // Execute multiplication
                 Dfp result = finiteZero.multiply(infinite);
                 
                 // Verify results
                 assertTrue("Result should be NaN", result.isNaN());
                 assertTrue("FLAG_INVALID should be set", 
                           (field.getIEEEFlags() & DfpField.FLAG_INVALID) != 0);
                 
                 // Removed the NaN comparison assertion as it's not meaningful
             }

    @Test
    public void testMultiplyWithZeroDetectsMutant2() throws Exception {
        // Create test field with appropriate radix
        DfpField field = new DfpField(10); // Using radix 10 for simplicity
        Dfp zero = field.getZero();
        Dfp nonZero = field.newDfp(5);
        
        // Test 0 * non-zero
        Dfp result1 = zero.multiply(nonZero);
        assertTrue("Result should be zero", result1.isZero());
        
        // Use reflection to check protected fields
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        
        assertEquals("Sign should be positive", 1, signField.get(result1));
        assertEquals("Exponent should be zero", 0, expField.get(result1));
        assertEquals("No flags should be set", 0, field.getIEEEFlags());
        
        // Test non-zero * 0
        Dfp result2 = nonZero.multiply(zero);
        assertTrue("Result should be zero", result2.isZero());
        assertEquals("Sign should be positive", 1, signField.get(result2));
        assertEquals("Exponent should be zero", 0, expField.get(result2));
        assertEquals("No flags should be set", 0, field.getIEEEFlags());
        
        // Test 0 * 0
        Dfp result3 = zero.multiply(zero);
        assertTrue("Result should be zero", result3.isZero());
        assertEquals("Sign should be positive", 1, signField.get(result3));
        assertEquals("Exponent should be zero", 0, expField.get(result3));
        assertEquals("No flags should be set", 0, field.getIEEEFlags());
    }

    @Test
    public void testMultiplyWithZeroShouldUseFastPath2() {
        // Setup
        DfpField field = new DfpField(10); // Assuming 10 decimal digits
        Dfp dfp = field.getOne(); // Get Dfp with value 1 using field's method
        Dfp zero = field.getZero(); // Get actual zero instance using field's method
        
        // Mock the slow path components to verify fast path is used
        Dfp spyDfp = spy(dfp);
        doReturn(zero).when(spyDfp).newInstance(0);
        
        // Test
        Dfp result = spyDfp.multiply(0);
        
        // Verify
        // The result should be zero (fast path result)
        assertEquals(zero, result);
        
        // Verify fast path was used by checking slow path wasn't invoked
        verify(spyDfp, never()).newInstance(0);
        verify(spyDfp, never()).multiply(any(Dfp.class));
    }


}
