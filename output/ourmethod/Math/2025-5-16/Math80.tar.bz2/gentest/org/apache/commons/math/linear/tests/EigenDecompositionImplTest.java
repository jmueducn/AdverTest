package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                public void testFlipIfWarranted_WithNEquals() throws Exception {
                                                                    // Edge case: n=1 (shouldn't flip as there's nothing to flip)
                                                                    int n = 1;
                                                                    int step = 1;
                                                                    
                                                                    // Create work array with sufficient size
                                                                    double[] work = new double[10];
                                                                    work[0] = 10.0;
                                                                    work[4 * (n - 1)] = 20.0; // Condition would be true but n=1
                                                                    
                                                                    // Create dummy EigenDecompositionImpl instance
                                                                    double[] main = new double[0];
                                                                    double[] secondary = new double[0];
                                                                    EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                    
                                                                    // Use reflection to access private method
                                                                    Method flipIfWarranted = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                        "flipIfWarranted", int.class, int.class);
                                                                    flipIfWarranted.setAccessible(true);
                                                                    
                                                                    // Set work array via reflection
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    workField.set(eigenDecomposition, work);
                                                                    
                                                                    boolean result = (boolean) flipIfWarranted.invoke(eigenDecomposition, n, step);
                                                                    assertFalse("Should not flip when n=1", result);
                                                                }

    @Test
                                                            public void testFlipIfWarranted_ShouldNotFlipWhenConditionNotMet() {
                                                                // Setup work array where condition is not met (1.5 * work[0] >= work[4*(n-1)])
                                                                int n = 3;
                                                                int step = 1;
                                                                int pingPong = 0;
                                                                double[] work = new double[4 * n]; // Enough space for the test case
                                                                
                                                                // Initialize eigenDecomposition with dummy data
                                                                double[] main = new double[n];
                                                                double[] secondary = new double[n-1];
                                                                EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                
                                                                // Set up test conditions
                                                                work[pingPong] = 10.0;
                                                                work[4 * (n - 1) + pingPong] = 10.0; // Now 1.5 * 10 = 15 >= 10 is true
                                                                
                                                                // Use reflection to set the work array
                                                                try {
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    workField.set(eigenDecomposition, work);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set work array via reflection");
                                                                }
                                                                
                                                                // Use reflection to call the private method
                                                                boolean result = false;
                                                                try {
                                                                    Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                    flipMethod.setAccessible(true);
                                                                    result = (Boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                } catch (Exception e) {
                                                                    fail("Failed to invoke flipIfWarranted via reflection");
                                                                }
                                                                
                                                                assertFalse("Method should return false when no flip occurs", result);
                                                                
                                                                // Verify no changes to work array
                                                                assertEquals(10.0, work[pingPong], 1.0e-12);
                                                                assertEquals(10.0, work[4 * (n - 1) + pingPong], 1.0e-12);
                                                            }

    @Test
                                                            public void testFlipIfWarranted_ShouldFlipWhenConditionMet() {
                                                                // Initialize required objects and arrays
                                                                double[] main = new double[0];
                                                                double[] secondary = new double[0];
                                                                EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                
                                                                // Setup work array where condition is met (1.5 * work[0] < work[4*(n-1)])
                                                                int n = 3;
                                                                int step = 1;
                                                                double[] work = new double[9]; // Need at least 9 elements (4*(3-1)+1=9)
                                                                
                                                                // Set specific values to meet the flip condition
                                                                work[0] = 10.0;  // pingPong is 0
                                                                work[4 * (n - 1)] = 20.0; // 1.5 * 10 = 15 < 20 is true
                                                                
                                                                // Fill remaining test values
                                                                for (int i = 0; i < work.length; i++) {
                                                                    work[i] = i;
                                                                }
                                                                
                                                                // Use reflection to set the work array since it's private
                                                                try {
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    workField.set(eigenDecomposition, work);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set work array via reflection");
                                                                }
                                                                
                                                                // Use reflection to call the private flipIfWarranted method
                                                                boolean result = false;
                                                                try {
                                                                    Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                    flipMethod.setAccessible(true);
                                                                    result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                } catch (Exception e) {
                                                                    fail("Failed to invoke flipIfWarranted method via reflection");
                                                                }
                                                                
                                                                assertTrue("Method should return true when flip occurs", result);
                                                                
                                                                // Verify the flip operation
                                                                // Original values: work[0]=0, work[1]=1, work[2]=2, work[3]=3
                                                                // work[8]=8, work[7]=7, work[6]=6, work[5]=5
                                                                // After flip:
                                                                // work[0] should be 8, work[1]=7, work[2]=6, work[3]=5
                                                                // work[8]=0, work[7]=1, work[6]=2, work[5]=3
                                                                assertEquals(8.0, work[0], 1.0e-12);
                                                                assertEquals(7.0, work[1], 1.0e-12);
                                                                assertEquals(6.0, work[2], 1.0e-12);
                                                                assertEquals(5.0, work[3], 1.0e-12);
                                                                
                                                                assertEquals(0.0, work[8], 1.0e-12);
                                                                assertEquals(1.0, work[7], 1.0e-12);
                                                                assertEquals(2.0, work[6], 1.0e-12);
                                                                assertEquals(3.0, work[5], 1.0e-12);
                                                            }

    @Test
                                                            public void testFlipIfWarranted_WithStepGreaterThan() {
                                                                // Initialize required objects and variables
                                                                double[] main = new double[3];
                                                                double[] secondary = new double[2];
                                                                EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                
                                                                // Set up work array (size needs to be at least 4*(n-1)+1 = 9, but test uses up to index 11)
                                                                double[] work = new double[12];
                                                                
                                                                // Test with step=2 (only flip every other element)
                                                                int n = 3;
                                                                int step = 2;
                                                                
                                                                // Fill test values
                                                                for (int i = 0; i < work.length; i++) {
                                                                    work[i] = i;
                                                                }
                                                                
                                                                // Set condition to be true (1.5 * work[0] < work[8])
                                                                work[0] = 5.0;  // 1.5 * 5 = 7.5
                                                                work[8] = 10.0; // 7.5 < 10.0 -> true
                                                                
                                                                // Use reflection to set private work array and pingPong
                                                                try {
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    workField.set(eigenDecomposition, work);
                                                                    
                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                    pingPongField.setAccessible(true);
                                                                    pingPongField.setInt(eigenDecomposition, 0);
                                                                    
                                                                    // Use reflection to access and invoke the private method
                                                                    Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                    flipMethod.setAccessible(true);
                                                                    boolean result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                    assertTrue(result);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set private fields or invoke method via reflection: " + e.getMessage());
                                                                }
                                                                
                                                                // Verify flip with step=2
                                                                // Only elements at k=0 and k=2 should be flipped (since step=2)
                                                                // Original: work[0]=5, work[1]=1, work[2]=2, work[3]=3
                                                                // work[8]=10, work[9]=9, work[10]=10, work[11]=11
                                                                // After flip:
                                                                // work[0]=10, work[1]=1, work[2]=10, work[3]=3
                                                                // work[8]=5, work[9]=9, work[10]=2, work[11]=11
                                                                assertEquals(10.0, work[0], 1.0e-12);
                                                                assertEquals(1.0, work[1], 1.0e-12);
                                                                assertEquals(10.0, work[2], 1.0e-12);
                                                                assertEquals(3.0, work[3], 1.0e-12);
                                                                
                                                                assertEquals(5.0, work[8], 1.0e-12);
                                                                assertEquals(9.0, work[9], 1.0e-12);
                                                                assertEquals(2.0, work[10], 1.0e-12);
                                                                assertEquals(11.0, work[11], 1.0e-12);
                                                            }

    @Test
                                                            public void testFlipIfWarranted_WithDifferentPingPongValue() {
                                                                // Initialize required variables
                                                                EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[0], new double[0], 1.0e-10);
                                                                double[] work = new double[13]; // Needs to be large enough for indices up to 12
                                                                int pingPong = 1;
                                                                
                                                                // Set pingPong field via reflection
                                                                try {
                                                                    java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                    pingPongField.setAccessible(true);
                                                                    pingPongField.set(eigenDecomposition, pingPong);
                                                                    
                                                                    // Also set work array via reflection since it's likely a private field
                                                                    java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    workField.set(eigenDecomposition, work);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set fields via reflection: " + e.getMessage());
                                                                }
                                                                
                                                                // Get the private flipIfWarranted method via reflection
                                                                Method flipIfWarrantedMethod;
                                                                try {
                                                                    flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                    flipIfWarrantedMethod.setAccessible(true);
                                                                } catch (Exception e) {
                                                                    fail("Failed to get flipIfWarranted method: " + e.getMessage());
                                                                    return;
                                                                }
                                                                
                                                                // Test with pingPong=1 (using work[1] instead of work[0] in condition)
                                                                int n = 3;
                                                                int step = 1;
                                                                work[1] = 10.0;  // pingPong is 1
                                                                work[4 * (n - 1) + 1] = 5.0; // 1.5 * 10 = 15 < 5 is false
                                                                
                                                                try {
                                                                    boolean result = (boolean) flipIfWarrantedMethod.invoke(eigenDecomposition, n, step);
                                                                    assertFalse(result);
                                                                } catch (Exception e) {
                                                                    fail("Failed to invoke flipIfWarranted: " + e.getMessage());
                                                                }
                                                                
                                                                // Now set condition to be true
                                                                work[4 * (n - 1) + 1] = 20.0; // 15 < 20 is true
                                                                
                                                                // Fill test values
                                                                for (int i = 0; i < work.length; i++) {
                                                                    work[i] = i;
                                                                }
                                                                
                                                                try {
                                                                    boolean result = (boolean) flipIfWarrantedMethod.invoke(eigenDecomposition, n, step);
                                                                    assertTrue(result);
                                                                } catch (Exception e) {
                                                                    fail("Failed to invoke flipIfWarranted: " + e.getMessage());
                                                                }
                                                                
                                                                // Verify flip operation uses pingPong=1 as offset
                                                                // Original: work[1]=1, work[2]=2, work[3]=3, work[4]=4
                                                                // work[9]=9, work[10]=10, work[11]=11, work[12]=12
                                                                // After flip:
                                                                // work[1]=9, work[2]=10, work[3]=11, work[4]=12
                                                                // work[9]=1, work[10]=2, work[11]=3, work[12]=4
                                                                assertEquals(9.0, work[1], 1.0e-12);
                                                                assertEquals(10.0, work[2], 1.0e-12);
                                                                assertEquals(11.0, work[3], 1.0e-12);
                                                                assertEquals(12.0, work[4], 1.0e-12);
                                                                
                                                                assertEquals(1.0, work[9], 1.0e-12);
                                                                assertEquals(2.0, work[10], 1.0e-12);
                                                                assertEquals(3.0, work[11], 1.0e-12);
                                                                assertEquals(4.0, work[12], 1.0e-12);
                                                            }

    @Test
                                                       public void testFlipIfWarranted_DetectsMutant() {
                                                           // Setup
                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                           
                                                           // Set up values where 1.0*val < comparison but 1.5*val > comparison
                                                           int n = 3;  // 4*(3-1) = 8
                                                           int step = 1;
                                                           int pingPong = 0;
                                                           double[] work = new double[20];  // Large enough array
                                                           
                                                           // Set values where work[pingPong] is between comparison/1.5 and comparison
                                                           work[pingPong] = 10.0;  // pingPong element
                                                           work[4*(n-1) + pingPong] = 15.0;  // comparison element
                                                           
                                                           // Original condition: 1.5*10 = 15 < 15 → false
                                                           // Mutant condition: 1.0*10 = 10 < 15 → true
                                                           
                                                           // Set some initial values to detect if array is flipped
                                                           for (int i = 0; i < 8; i++) {
                                                               work[i] = i;
                                                           }
                                                           double[] originalWork = work.clone();
                                                           
                                                           // Inject work array into the object (using reflection since work is private)
                                                           try {
                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                               workField.setAccessible(true);
                                                               workField.set(eigen, work);
                                                               
                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                               pingPongField.setAccessible(true);
                                                               pingPongField.set(eigen, pingPong);
                                                           } catch (Exception e) {
                                                               fail("Failed to set private fields via reflection");
                                                           }
                                                           
                                                           // Test using reflection to call private method
                                                           boolean result = false;
                                                           try {
                                                               Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                               flipMethod.setAccessible(true);
                                                               result = (boolean) flipMethod.invoke(eigen, n, step);
                                                           } catch (Exception e) {
                                                               fail("Failed to invoke private method via reflection");
                                                           }
                                                           
                                                           // Verify
                                                           assertFalse("Original condition should return false", result);
                                                           
                                                           // Verify array wasn't modified
                                                           assertArrayEquals("Work array should not be modified", originalWork, work, 0.0);
                                                           
                                                           // For mutant detection: if the test passes, it means the original behavior is preserved
                                                           // If mutant is present, result would be true and array would be flipped
                                                       }

    @Test
                                                  public void testFlipIfWarrantedDetectsMutant() throws Exception {
                                                      // Setup test data where n=2 to make difference between 4*(n-1) and 4*n significant
                                                      int n = 2;
                                                      int step = 1;
                                                      int pingPong = 0;
                                                      
                                                      // Create work array large enough (need at least 4*n + pingPong = 8 elements)
                                                      double[] work = new double[10];
                                                      
                                                      // Set values to trigger flip condition: 1.5*work[0] < work[4*(n-1)+0] => 1.5*1 < 5
                                                      work[0] = 1.0;  // work[pingPong]
                                                      work[4] = 5.0;   // work[4*(n-1)+pingPong] = work[4*(2-1)+0] = work[4]
                                                      
                                                      // Set values that should be flipped (indices 0-3) and shouldn't be (indices 4-7)
                                                      work[0] = 1.0; work[1] = 2.0; work[2] = 3.0; work[3] = 4.0;  // These should be flipped
                                                      work[4] = 5.0; work[5] = 6.0; work[6] = 7.0; work[7] = 8.0;  // These shouldn't
                                                      
                                                      // Create instance
                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                      
                                                      // Use reflection to set private fields
                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                      workField.setAccessible(true);
                                                      workField.set(eigen, work);
                                                      
                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                      pingPongField.setAccessible(true);
                                                      pingPongField.set(eigen, pingPong);
                                                      
                                                      // Use reflection to invoke private method
                                                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                      flipMethod.setAccessible(true);
                                                      boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                      
                                                      // Verify
                                                      assertTrue("Flip should have occurred", result);
                                                      
                                                      // Original would flip indices 0-3 with 4-7 (but only up to j=4*(n-1)=4)
                                                      // Mutant would try to flip indices 0-7 with 8-? (out of bounds)
                                                      
                                                      // Verify correct elements were flipped (original behavior)
                                                      assertEquals(5.0, work[0], 0.0001);  // Should be swapped with work[4]
                                                      assertEquals(6.0, work[1], 0.0001);  // Should be swapped with work[3]
                                                      assertEquals(3.0, work[2], 0.0001);  // Should stay same (middle element)
                                                      assertEquals(2.0, work[3], 0.0001);  // Should be swapped with work[1]
                                                      assertEquals(1.0, work[4], 0.0001);  // Should be swapped with work[0]
                                                      
                                                      // Verify elements that shouldn't be changed
                                                      assertEquals(7.0, work[6], 0.0001);
                                                      assertEquals(8.0, work[7], 0.0001);
                                                  }

    @Test
                                             public void testFlipIfWarrantedDetectsMutant1() throws Exception {
                                                 // Setup test data
                                                 int n = 3; // For n=3, original j=4*(3-1)=8, mutant j=2*(3-1)=4
                                                 int step = 1;
                                                 int pingPong = 0;
                                                 
                                                 // Create work array with values that will trigger the flip
                                                 // Original should flip elements 0-7, mutant would only flip 0-3
                                                 double[] work = new double[12]; // Need at least 8 elements for n=3
                                                 work[0] = 10; work[1] = 20; work[2] = 30; work[3] = 40;
                                                 work[4] = 50; work[5] = 60; work[6] = 70; work[7] = 80;
                                                 work[8] = 90; // These should remain unchanged
                                                 
                                                 // Set condition to be true: 1.5*work[0] < work[8]
                                                 work[pingPong] = 10; // work[0] = 10
                                                 work[4 * (n - 1) + pingPong] = 20; // work[8] = 20 (1.5*10=15 < 20)
                                                 
                                                 // Create test instance
                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                 
                                                 // Use reflection to set private fields
                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                 workField.setAccessible(true);
                                                 workField.set(eigen, work);
                                                 
                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                 pingPongField.setAccessible(true);
                                                 pingPongField.set(eigen, pingPong);
                                                 
                                                 // Use reflection to invoke private method
                                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                 flipMethod.setAccessible(true);
                                                 boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                 
                                                 // Verify flip occurred (method returned true)
                                                 assertTrue(result);
                                                 
                                                 // Verify correct flipping occurred - check all expected elements were flipped
                                                 // Original should have flipped pairs: (0,8), (1,7), (2,6), (3,5)
                                                 // But with mutant j=4, it would only flip (0,4), (1,3)
                                                 assertEquals(50.0, work[0], 0.0001); // Should be flipped with work[8] if j=8
                                                 assertEquals(40.0, work[1], 0.0001); // Should be flipped with work[7] if j=8
                                                 assertEquals(30.0, work[2], 0.0001); // Should be flipped with work[6] if j=8
                                                 assertEquals(20.0, work[3], 0.0001); // Should be flipped with work[5] if j=8
                                                 
                                                 // These assertions will fail with the mutant since it doesn't flip far enough:
                                                 assertEquals(80.0, work[4], 0.0001); // Should be flipped with work[4] if j=8
                                                 assertEquals(70.0, work[5], 0.0001); // Should be flipped with work[3] if j=8
                                                 assertEquals(60.0, work[6], 0.0001); // Should be flipped with work[2] if j=8
                                                 assertEquals(50.0, work[7], 0.0001); // Should be flipped with work[1] if j=8
                                                 assertEquals(10.0, work[8], 0.0001); // Should be flipped with work[0] if j=8
                                                 
                                                 // These should remain unchanged in both cases
                                                 assertEquals(90.0, work[9], 0.0001);
                                             }

    @Test
                                        public void testFlipIfWarrantedDetectsLoopConditionMutant() {
                                            // Setup
                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                            
                                            // Create a work array where flip condition is true and j will be exactly divisible by 4
                                            // Using reflection to set private fields since they're not accessible directly
                                            try {
                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                workField.setAccessible(true);
                                                double[] work = new double[20]; // Large enough for our test
                                                work[0] = 1.0;  // pingPong = 0 (assuming)
                                                work[4 * (4 - 1) + 0] = 2.0; // Makes condition true (1.5*1 < 2)
                                                workField.set(eigen, work);
                                                
                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                pingPongField.setAccessible(true);
                                                pingPongField.set(eigen, 0);
                                                
                                                // Get the private method using reflection
                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                flipMethod.setAccessible(true);
                                                
                                                // Call method with n=4 (so j=4*(4-1)=12)
                                                boolean result = (boolean) flipMethod.invoke(eigen, 4, 1);
                                                
                                                // Verify
                                                assertTrue(result); // Flip should occur
                                                
                                                // Get the modified work array
                                                double[] modifiedWork = (double[]) workField.get(eigen);
                                                
                                                // Check that the array was flipped correctly (no extra iteration occurred)
                                                // In original, when i=12, loop stops (12 < 12 is false)
                                                // In mutant, when i=12, loop continues (12 <= 12 is true) causing ArrayIndexOutOfBounds
                                                // So if we get here without exception, the test passed (caught the mutant)
                                                
                                                // Additional verification - check some swap positions
                                                // For example, check that elements at positions 0 and 12 were swapped
                                                assertEquals(work[12], modifiedWork[0], 0.0001);
                                                assertEquals(work[0], modifiedWork[12], 0.0001);
                                                
                                            } catch (Exception e) {
                                                fail("Test failed due to reflection or other issues: " + e.getMessage());
                                            }
                                        }

    @Test
                                   public void testFlipIfWarranted_DetectsIncrementMutation() throws Exception {
                                       // Setup test data
                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                       
                                       // Create a work array where flip condition is true
                                       // Size needs to be large enough to show the difference (at least 8 elements)
                                       double[] work = new double[12];
                                       work[0] = 10;  // Will be swapped with work[7]
                                       work[1] = 20;  // Will be swapped with work[6]
                                       work[2] = 30;  // Will be swapped with work[5]
                                       work[3] = 40;  // Will be swapped with work[4]
                                       work[4] = 50;
                                       work[5] = 60;
                                       work[6] = 70;
                                       work[7] = 80;
                                       
                                       // Set pingPong to 0 using reflection
                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                       pingPongField.setAccessible(true);
                                       pingPongField.setInt(eigen, 0);
                                       
                                       work[0] = 1.0;  // 1.5 * work[0] = 1.5
                                       work[4 * (3-1) + 0] = 2.0; // work[8] = 2.0 (1.5 < 2.0 condition true)
                                       
                                       // Set the work array using reflection
                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                       workField.setAccessible(true);
                                       workField.set(eigen, work.clone());
                                       
                                       // Call the method using reflection
                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                       flipMethod.setAccessible(true);
                                       boolean result = (boolean) flipMethod.invoke(eigen, 3, 1); // n=3, step=1
                                       
                                       // Verify the flip occurred
                                       assertTrue(result);
                                       
                                       // Verify exact array state after flip
                                       double[] expected = work.clone();
                                       // Correct swap should be:
                                       double tmp;
                                       // Block 0-3 swaps with 7-4
                                       for (int k = 0; k < 4; k++) {
                                           tmp = expected[0 + k];
                                           expected[0 + k] = expected[7 - k];
                                           expected[7 - k] = tmp;
                                       }
                                       
                                       // Get the work array using reflection for verification
                                       double[] actualWork = (double[]) workField.get(eigen);
                                       // Verify the array was flipped correctly (only the intended blocks)
                                       assertArrayEquals(expected, actualWork, 0.0001);
                                   }

    @Test
                              public void testFlipIfWarranted_DetectsMutant_SkipsFirstBlock() throws Exception {
                                  // Setup
                                  EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                  
                                  // Create a work array with 8 elements (2 blocks of 4)
                                  // The values are set so the flip condition will be true
                                  double[] work = new double[8];
                                  work[0] = 1.0; work[1] = 2.0; work[2] = 3.0; work[3] = 4.0;  // First block
                                  work[4] = 5.0; work[5] = 6.0; work[6] = 7.0; work[7] = 8.0;  // Second block
                                  
                                  // Use reflection to set private fields
                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                  workField.setAccessible(true);
                                  workField.set(decomposition, work);
                                  
                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                  pingPongField.setAccessible(true);
                                  pingPongField.setInt(decomposition, 0);
                                  
                                  // Use reflection to call private method
                                  Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                  flipMethod.setAccessible(true);
                                  boolean result = (boolean) flipMethod.invoke(decomposition, 2, 1); // n=2, step=1
                                  
                                  // Verify the flip occurred
                                  assertTrue(result);
                                  
                                  // Verify ALL elements were flipped correctly
                                  // Original array would be flipped to: [8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0]
                                  assertEquals(8.0, work[0], 0.0001);  // This would fail with the mutant (would remain 1.0)
                                  assertEquals(7.0, work[1], 0.0001);  // This would fail with the mutant (would remain 2.0)
                                  assertEquals(6.0, work[2], 0.0001);  // This would fail with the mutant (would remain 3.0)
                                  assertEquals(5.0, work[3], 0.0001);  // This would fail with the mutant (would remain 4.0)
                                  assertEquals(4.0, work[4], 0.0001);
                                  assertEquals(3.0, work[5], 0.0001);
                                  assertEquals(2.0, work[6], 0.0001);
                                  assertEquals(1.0, work[7], 0.0001);
                              }

    @Test
                         public void testFlipIfWarranted_DetectsMutatedLoopCondition() {
                             // Setup test data
                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                             
                             // Use reflection to set private fields and access private method
                             try {
                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                 workField.setAccessible(true);
                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                 pingPongField.setAccessible(true);
                                 
                                 // Create a work array that will trigger the flip condition
                                 // We need at least 8 elements (n=2, 4*(n-1)+1=5)
                                 double[] work = {0.0, 10.0, 0.0, 0.0, 0.0, 20.0, 0.0, 0.0};
                                 workField.set(eigen, work);
                                 pingPongField.setInt(eigen, 1); // pingPong = 1
                                 
                                 // Get the private method and make it accessible
                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                 flipMethod.setAccessible(true);
                                 
                                 // Condition: 1.5 * work[1] (15) < work[5] (20) → true
                                 // Original should flip without error
                                 boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                 
                                 // Verify the flip happened correctly
                                 assertTrue(result);
                                 assertEquals(20.0, work[0], 0.0001); // first element should be swapped with last
                                 assertEquals(0.0, work[7], 0.0001); // last element should be swapped with first
                                 
                                 // The mutated version would throw ArrayIndexOutOfBoundsException when k=4
                                 // This test will fail for the mutated version
                                 
                             } catch (Exception e) {
                                 fail("Test setup failed: " + e.getMessage());
                             }
                         }

    @Test
                    public void testFlipIfWarrantedDetectsInnerLoopBoundaryMutation() {
                        // Setup test data that will trigger the flip condition
                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                        
                        // Create a work array with size that would expose the mutation
                        // Need at least 8 elements (4*(n-1)+pingPong) where n=2, pingPong=0
                        double[] work = new double[8];
                        work[0] = 10.0;  // work[pingPong]
                        work[4] = 5.0;   // work[4*(n-1)] - condition 1.5*10 < 5 => false
                        work[4] = 20.0;  // Now condition 1.5*10 < 20 => true
                        
                        // Set required fields through reflection since they're private
                        try {
                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                            workField.setAccessible(true);
                            workField.set(eigen, work);
                            
                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                            pingPongField.setAccessible(true);
                            pingPongField.setInt(eigen, 0);
                            
                            // Get and invoke the private method using reflection
                            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                            flipMethod.setAccessible(true);
                            boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                            
                            // Verify the flip occurred and array was modified correctly
                            assertTrue(result);
                            
                            // Verify the flipping was done correctly for first 4 elements only
                            // Original array positions: [0,1,2,3,4,5,6,7]
                            // After flip should be: [4,5,6,7,0,1,2,3] (but only first 4 elements flipped)
                            assertEquals(20.0, work[0], 0.0001);  // First element should be from position 4
                            assertEquals(work[1], work[5], 0.0001); // Second element flipped with position 5
                            assertEquals(work[2], work[6], 0.0001); // Third element flipped with position 6
                            assertEquals(work[3], work[7], 0.0001); // Fourth element flipped with position 7
                            
                        } catch (Exception e) {
                            fail("Test setup failed due to reflection: " + e.getMessage());
                        }
                    }

    @Test
               public void testFlipIfWarranted_DetectsMutantByCheckingFirstElementSwap() throws Exception {
                   // Setup test data
                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                   
                   // Create a work array that will trigger the flip condition
                   // Structure: [block1, block2, ...] where each block has 4 elements
                   // Make sure 1.5 * work[pingPong] < work[4*(n-1)+pingPong]
                   double[] work = new double[8]; // 2 blocks of 4 elements
                   work[0] = 1.0;  // First element of first block (should be swapped)
                   work[1] = 2.0;
                   work[2] = 3.0;
                   work[3] = 4.0;  // Last element of first block
                   work[4] = 5.0;  // First element of second block (should be swapped)
                   work[5] = 6.0;
                   work[6] = 7.0;
                   work[7] = 8.0;  // Last element of second block
                   
                   // Use reflection to set private fields
                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                   workField.setAccessible(true);
                   workField.set(eigen, work);
                   
                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                   pingPongField.setAccessible(true);
                   pingPongField.setInt(eigen, 0);
                   
                   // Use reflection to call private method
                   Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                   flipMethod.setAccessible(true);
                   boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                   
                   // Verify flipping occurred
                   assertTrue(result);
                   
                   // Verify all elements were swapped correctly
                   // Original first block: [1,2,3,4] should become [4,3,2,1]
                   assertEquals(4.0, work[0], 0.0001);  // This would fail with mutant (would remain 1.0)
                   assertEquals(3.0, work[1], 0.0001);
                   assertEquals(2.0, work[2], 0.0001);
                   assertEquals(1.0, work[3], 0.0001);
                   
                   // Original second block: [5,6,7,8] should become [8,7,6,5]
                   assertEquals(8.0, work[4], 0.0001);  // This would fail with mutant (would remain 5.0)
                   assertEquals(7.0, work[5], 0.0001);
                   assertEquals(6.0, work[6], 0.0001);
                   assertEquals(5.0, work[7], 0.0001);
               }

    @Test
          public void testFlipIfWarranted_DetectsFinalModifierRemoval() throws Exception {
              // Setup
              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 2}, new double[]{1}, 0.0);
              
              // Get private fields using reflection
              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
              workField.setAccessible(true);
              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
              pingPongField.setAccessible(true);
              
              // Initialize work array to trigger flip condition
              // Set pingPong to 0 and create a work array where 1.5*work[0] < work[4*(n-1)]
              int n = 3; // arbitrary n > 1
              int step = 1; // step must divide 4
              double[] work = new double[4 * (n - 1) + 1];
              work[0] = 1.0; // pingPong position
              work[4 * (n - 1)] = 2.0; // 1.5*1 < 2.0 -> condition true
              workField.set(eigen, work);
              pingPongField.setInt(eigen, 0);
              
              // Fill the work array with distinct values to verify swapping
              for (int i = 0; i < work.length; i++) {
                  work[i] = i * 1.0;
              }
              
              // Make a copy of original array for verification
              double[] originalWork = work.clone();
              workField.set(eigen, work);
              
              // Get private method using reflection
              Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
              flipIfWarrantedMethod.setAccessible(true);
              
              // Execute
              boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
              
              // Get updated work array
              work = (double[]) workField.get(eigen);
              
              // Verify
              assertTrue(result); // flip should have occurred
              
              // Verify exact swapping behavior
              // The swapping should be perfect mirroring in blocks of 4
              int j = 4 * (n - 1);
              for (int i = 0; i < j; i += 4) {
                  for (int k = 0; k < 4; k += step) {
                      // Verify each element was swapped correctly
                      assertEquals(originalWork[i + k], work[j - k], 0.0001);
                      assertEquals(originalWork[j - k], work[i + k], 0.0001);
                  }
                  j -= 4;
              }
              
              // If tmp wasn't final and was modified during swapping, the above assertions would fail
          }

    @Test
      public void testFlipIfWarrantedDetectsElementAccessMutation() {
          // Setup test data that will expose the mutation
          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
          
          // Create a work array where elements at i+k differ from elements at i
          // We'll use n=2 (so j=4*(2-1)=4) and step=1 to test all k values
          double[] work = new double[8];
          // Fill with distinct values where work[i] != work[i+k] for k>0
          work[0] = 1.0; work[1] = 2.0; work[2] = 3.0; work[3] = 4.0;  // first block
          work[4] = 5.0; work[5] = 6.0; work[6] = 7.0; work[7] = 8.0;  // second block
          
          // Set condition to be true (1.5 * work[pingPong] < work[4*(n-1)+pingPong])
          // Let's set pingPong=0, so 1.5*work[0] < work[4] => 1.5 < 5.0 (true)
          
          // Use reflection to set private fields since we need to test a private method
          try {
              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
              workField.setAccessible(true);
              workField.set(eigen, work);
              
              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
              pingPongField.setAccessible(true);
              pingPongField.setInt(eigen, 0);
              
              Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
              flipMethod.setAccessible(true);
              
              // Call the method with n=2, step=1
              boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
              
              // Verify the flip occurred
              assertTrue(result);
              
              // Verify the exact array contents after flip
              // Original would swap:
              // work[0] <-> work[4], work[1] <-> work[3], work[4] <-> work[0], work[5] <-> work[7]
              // Mutated version would corrupt this swapping
              double[] expected = new double[]{5.0, 8.0, 7.0, 6.0, 1.0, 4.0, 3.0, 2.0};
              assertArrayEquals(expected, work, 0.0001);
              
          } catch (Exception e) {
              fail("Failed to test private method via reflection: " + e.getMessage());
          }
      }

    @Test
    public void testFlipIfWarrantedDetectsMutant2() throws Exception {
        // Setup test data
        int n = 3;  // For 4*(n-1) to be 8 (array index)
        int step = 1;
        int pingPong = 0;
        
        // Create work array with distinct values at different positions
        // Position 0 and 8 will be compared in the condition
        // Positions 0-3 and 8-5 will be swapped in the flip
        double[] work = new double[12]; // Needs to be large enough for indices used
        work[0] = 10.0;  // work[pingPong]
        work[8] = 20.0;  // work[4*(n-1)+pingPong] (1.5*10 < 20 => condition true)
        
        // Fill other positions with distinct values
        for (int i = 1; i < work.length; i++) {
            work[i] = i * 1.0;
        }
        
        // Create instance
        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
        
        // Use reflection to set private fields
        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
        workField.setAccessible(true);
        workField.set(eigen, work);
        
        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
        pingPongField.setAccessible(true);
        pingPongField.set(eigen, pingPong);
        
        // Use reflection to call private method
        Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
        flipMethod.setAccessible(true);
        boolean result = (boolean) flipMethod.invoke(eigen, n, step);
        
        // Verify flip occurred
        assertTrue(result);
        
        // Verify correct swapping occurred (would fail with mutant)
        // Original would swap:
        // work[0] with work[8]
        // work[1] with work[7]
        // work[2] with work[6]
        // work[3] with work[5]
        assertEquals(20.0, work[0], 0.0001);  // Should be swapped from position 8
        assertEquals(10.0, work[8], 0.0001);  // Should be swapped from position 0
        assertEquals(7.0, work[1], 0.0001);   // Should be swapped from position 7
        assertEquals(1.0, work[7], 0.0001);   // Should be swapped from position 1
        assertEquals(6.0, work[2], 0.0001);   // Should be swapped from position 6
        assertEquals(2.0, work[6], 0.0001);   // Should be swapped from position 2
        assertEquals(5.0, work[3], 0.0001);   // Should be swapped from position 5
        assertEquals(3.0, work[5], 0.0001);   // Should be swapped from position 3
        
        // With mutant, these assertions would fail because:
        // - tmp would come from work[k] (positions 0-3) instead of work[i+k]
        // - The swaps would be incorrect
    }


}
