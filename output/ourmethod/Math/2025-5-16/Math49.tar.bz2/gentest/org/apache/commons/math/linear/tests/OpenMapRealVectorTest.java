package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
import org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testEbeDivide_TypicalValues() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{4.0, 9.0, 16.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 3.0, 4.0});
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(2.0, result.getEntry(0), 0.0001);
                    assertEquals(3.0, result.getEntry(1), 0.0001);
                    assertEquals(4.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeDivide_DifferentDimensionsThrowsException() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                    
                    thrown.expect(IllegalArgumentException.class);
                    vector1.ebeDivide(vector2);
                }

    @Test
                public void testEbeDivide_DivideByZeroThrowsException() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 0.0});
                    
                    thrown.expect(ArithmeticException.class);
                    vector1.ebeDivide(vector2);
                }

    @Test
                public void testEbeDivide_SparseVectors() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0.0, 6.0, 0.0, 10.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0, 5.0});
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(0.0, result.getEntry(0), 0.0001);
                    assertEquals(3.0, result.getEntry(1), 0.0001);
                    assertEquals(0.0, result.getEntry(2), 0.0001);
                    assertEquals(2.0, result.getEntry(3), 0.0001);
                }

    @Test
                public void testEbeDivide_NegativeNumbers() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{-4.0, 9.0, -16.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, -3.0, -4.0});
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(-2.0, result.getEntry(0), 0.0001);
                    assertEquals(-3.0, result.getEntry(1), 0.0001);
                    assertEquals(4.0, result.getEntry(2), 0.0001);
                }

    @Test
                public void testEbeDivide_SmallNumbers() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1e-10, 1e-15});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1e-5, 1e-10});
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(1e-5, result.getEntry(0), 1e-15);
                    assertEquals(1e-5, result.getEntry(1), 1e-15);
                }

    @Test
                public void testEbeDivide_WithRealVectorParameter() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{4.0, 9.0});
                    RealVector mockVector = mock(RealVector.class);
                    when(mockVector.getDimension()).thenReturn(2);
                    when(mockVector.getEntry(0)).thenReturn(2.0);
                    when(mockVector.getEntry(1)).thenReturn(3.0);
                    
                    OpenMapRealVector result = vector1.ebeDivide(mockVector);
                    
                    assertEquals(2.0, result.getEntry(0), 0.0001);
                    assertEquals(3.0, result.getEntry(1), 0.0001);
                }

    @Test
                public void testEbeDivide_EmptyVectors() {
                    // Setup
                    double[] originalValues = {};
                    double[] divisorValues = {};
                    OpenMapRealVector vector = new OpenMapRealVector(originalValues);
                    
                    // Test
                    OpenMapRealVector result = vector.ebeDivide(divisorValues);
                    
                    // Verify
                    assertEquals(0, result.getDimension());
                }

    @Test
                public void testEbeDivide_WithSpecialValues() {
                    // Setup
                    double[] originalValues = {Double.NaN, Double.POSITIVE_INFINITY, 1.0};
                    double[] divisorValues = {1.0, 1.0, 0.0};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(originalValues);
                    
                    // Test
                    OpenMapRealVector result = vector.ebeDivide(divisorValues);
                    
                    // Verify
                    assertTrue(Double.isNaN(result.getEntry(0)));
                    assertTrue(Double.isInfinite(result.getEntry(1)));
                    assertTrue(Double.isInfinite(result.getEntry(2)));
                }

    @Test
                public void testEbeMultiply_TypicalValues() {
                    double[] values = {1.0, 2.0, 3.0};
                    double[] multiplyWith = {2.0, 3.0, 4.0};
                    double[] expected = {2.0, 6.0, 12.0};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(values);
                    OpenMapRealVector result = vector.ebeMultiply(multiplyWith);
                    
                    assertEquals(expected.length, result.getDimension());
                    for (int i = 0; i < expected.length; i++) {
                        assertEquals(expected[i], result.getEntry(i), 0.0001);
                    }
                }

    @Test
                public void testEbeMultiply_WithZeros() {
                    double[] values = {1.0, 0.0, 3.0};
                    double[] multiplyWith = {0.0, 2.0, 0.0};
                    double[] expected = {0.0, 0.0, 0.0};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(values);
                    OpenMapRealVector result = vector.ebeMultiply(multiplyWith);
                    
                    assertEquals(expected.length, result.getDimension());
                    for (int i = 0; i < expected.length; i++) {
                        assertEquals(expected[i], result.getEntry(i), 0.0001);
                    }
                }

    @Test
                public void testEbeMultiply_SparseVectors() {
                    double[] values = {0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 8.0};
                    double[] multiplyWith = {0.0, 0.0, 2.0, 0.0, 0.0, 0.0, 0.5};
                    double[] expected = {0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 4.0};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(values);
                    OpenMapRealVector result = vector.ebeMultiply(multiplyWith);
                    
                    assertEquals(expected.length, result.getDimension());
                    for (int i = 0; i < expected.length; i++) {
                        assertEquals(expected[i], result.getEntry(i), 0.0001);
                    }
                }

    @Test
                public void testEbeMultiply_DimensionMismatch() {
                    double[] values = {1.0, 2.0, 3.0};
                    double[] multiplyWith = {1.0, 2.0};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(values);
                    
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("vector length mismatch: 3 != 2");
                    vector.ebeMultiply(multiplyWith);
                }

    @Test
                public void testEbeMultiply_EmptyVector() {
                    double[] values = {};
                    double[] multiplyWith = {};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(values);
                    OpenMapRealVector result = vector.ebeMultiply(multiplyWith);
                    
                    assertEquals(0, result.getDimension());
                }

    @Test
                public void testEbeMultiply_EdgeCases() {
                    double[] values = {Double.MAX_VALUE, Double.MIN_VALUE};
                    double[] multiplyWith = {2.0, 0.5};
                    double[] expected = {Double.POSITIVE_INFINITY, Double.MIN_VALUE * 0.5};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(values);
                    OpenMapRealVector result = vector.ebeMultiply(multiplyWith);
                    
                    assertEquals(expected.length, result.getDimension());
                    assertEquals(expected[0], result.getEntry(0), 0.0001);
                    assertEquals(expected[1], result.getEntry(1), 0.0001);
                }

    @Test
                public void testEbeMultiply_WithNaNandInfinity() {
                    double[] values = {Double.NaN, Double.POSITIVE_INFINITY};
                    double[] multiplyWith = {1.0, 0.0};
                    double[] expected = {Double.NaN, Double.NaN};
                    
                    OpenMapRealVector vector = new OpenMapRealVector(values);
                    OpenMapRealVector result = vector.ebeMultiply(multiplyWith);
                    
                    assertEquals(expected.length, result.getDimension());
                    assertTrue(Double.isNaN(result.getEntry(0)));
                    assertTrue(Double.isNaN(result.getEntry(1)));
                }

    @Test
        public void testEbeDivide_TypicalValues1() {
            // Setup
            double[] originalValues = {4.0, 9.0, 16.0};
            double[] divisorValues = {2.0, 3.0, 4.0};
            double[] expectedValues = {2.0, 3.0, 4.0};
            double delta = 1e-15; // Small delta value for double comparisons
            
            OpenMapRealVector vector = new OpenMapRealVector(originalValues);
            
            // Test
            OpenMapRealVector result = vector.ebeDivide(divisorValues);
            
            // Verify
            assertEquals(originalValues.length, result.getDimension());
            for (int i = 0; i < expectedValues.length; i++) {
                assertEquals(expectedValues[i], result.getEntry(i), delta);
            }
        }

    @Test
        public void testEbeDivide_DivisionByZero() {
            // Setup
            double[] originalValues = {1.0, 2.0, 3.0};
            double[] divisorValues = {1.0, 0.0, 1.0};
            OpenMapRealVector vector = new OpenMapRealVector(originalValues);
            
            // Expect exception
            ExpectedException exception = ExpectedException.none();
            exception.expect(ArithmeticException.class);
            exception.expectMessage("/ by zero");
            
            // Test
            vector.ebeDivide(divisorValues);
        }

    @Test
        public void testEbeDivide_DimensionMismatch() {
            // Setup
            double[] originalValues = {1.0, 2.0};
            double[] divisorValues = {1.0};
            OpenMapRealVector vector = new OpenMapRealVector(originalValues);
            
            // Test
            try {
                vector.ebeDivide(divisorValues);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                // Verify
                assertEquals("vector length mismatch", e.getMessage());
            }
        }

    @Test
        public void testEbeDivide_WithDefaultValues() {
            // Setup
            double[] originalValues = {0.0, 5.0, 0.0};
            double[] divisorValues = {1.0, 5.0, 2.0};
            double[] expectedValues = {0.0, 1.0, 0.0};
            double delta = 0.0001; // Using a reasonable default delta value
            
            OpenMapRealVector vector = new OpenMapRealVector(originalValues);
            
            // Test
            OpenMapRealVector result = vector.ebeDivide(divisorValues);
            
            // Verify
            assertEquals(originalValues.length, result.getDimension());
            for (int i = 0; i < expectedValues.length; i++) {
                assertEquals(expectedValues[i], result.getEntry(i), delta);
            }
        }

    @Test
        public void testEbeDivide_SparseVector() {
            // Setup - create sparse vector with only some entries set
            OpenMapRealVector vector = new OpenMapRealVector(5);
            vector.setEntry(1, 10.0);
            vector.setEntry(3, 20.0);
            
            double[] divisorValues = {1.0, 2.0, 1.0, 4.0, 1.0};
            double[] expectedValues = {0.0, 5.0, 0.0, 5.0, 0.0};
            
            // Get epsilon using reflection
            double epsilon;
            try {
                Field epsilonField = OpenMapRealVector.class.getDeclaredField("epsilon");
                epsilonField.setAccessible(true);
                epsilon = epsilonField.getDouble(vector);
            } catch (Exception e) {
                // Fallback to default value if reflection fails
                epsilon = 1.0e-12;
            }
            
            // Test
            OpenMapRealVector result = vector.ebeDivide(divisorValues);
            
            // Verify
            assertEquals(5, result.getDimension());
            for (int i = 0; i < expectedValues.length; i++) {
                assertEquals(expectedValues[i], result.getEntry(i), epsilon);
            }
        }

    @Test
        public void testEbeMultiply_TypicalCase() {
            OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{2.0, 5.0, 6.0});
            OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 2.0, 3.0});
            OpenMapRealVector result = vector1.ebeMultiply(vector2);
            
            assertEquals(3, result.getDimension());
            assertEquals(4.0, result.getEntry(0), 0.0001);
            assertEquals(10.0, result.getEntry(1), 0.0001);
            assertEquals(18.0, result.getEntry(2), 0.0001);
        }

    @Test
        public void testEbeMultiply_WithSparseVector() {
            // Create vector1 with values [1.0, 2.0, 3.0]
            OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            
            // Create sparseVector with values [0.0, 7.0, 0.0]
            OpenMapRealVector sparseVector = new OpenMapRealVector(new double[]{0.0, 7.0, 0.0});
            
            OpenMapRealVector result = vector1.ebeMultiply(sparseVector);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 0.0001); // 1.0 * 0.0
            assertEquals(14.0, result.getEntry(1), 0.0001); // 2.0 * 7.0
            assertEquals(0.0, result.getEntry(2), 0.0001); // 3.0 * 0.0
        }

    @Test
        public void testEbeMultiply_WithEmptyVector() {
            // Create vector1 with dimension 3 (values don't matter since they'll be multiplied by 0)
            OpenMapRealVector vector1 = new OpenMapRealVector(3);
            vector1.setEntry(0, 1.0);
            vector1.setEntry(1, 2.0);
            vector1.setEntry(2, 3.0);
            
            // Create empty vector with dimension 3 (all zeros)
            OpenMapRealVector emptyVector = new OpenMapRealVector(3);
            
            OpenMapRealVector result = vector1.ebeMultiply(emptyVector);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 0.0001);
            assertEquals(0.0, result.getEntry(1), 0.0001);
            assertEquals(0.0, result.getEntry(2), 0.0001);
        }

    @Test
        public void testEbeMultiply_DimensionMismatch1() {
            OpenMapRealVector vector1 = new OpenMapRealVector(3); // Create vector with dimension 3
            OpenMapRealVector differentSizeVector = new OpenMapRealVector(5); // Create vector with different dimension
            
            thrown.expect(IllegalArgumentException.class);
            vector1.ebeMultiply(differentSizeVector);
        }

    @Test
        public void testEbeMultiply_Identity() {
            OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{2.5, 3.0, 4.2});
            OpenMapRealVector ones = new OpenMapRealVector(new double[]{1.0, 1.0, 1.0});
            OpenMapRealVector result = vector1.ebeMultiply(ones);
            
            assertEquals(3, result.getDimension());
            assertEquals(vector1.getEntry(0), result.getEntry(0), 0.0001);
            assertEquals(vector1.getEntry(1), result.getEntry(1), 0.0001);
            assertEquals(vector1.getEntry(2), result.getEntry(2), 0.0001);
        }

    @Test
        public void testEbeMultiply_ZeroVector() {
            OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            OpenMapRealVector zeros = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
            OpenMapRealVector result = vector1.ebeMultiply(zeros);
            
            assertEquals(3, result.getDimension());
            assertEquals(0.0, result.getEntry(0), 0.0001);
            assertEquals(0.0, result.getEntry(1), 0.0001);
            assertEquals(0.0, result.getEntry(2), 0.0001);
        }

    @Test
        public void testEbeMultiply_NegativeValues() {
            OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
            OpenMapRealVector negativeVector = new OpenMapRealVector(new double[]{-1.0, -2.0, -3.0});
            OpenMapRealVector result = vector1.ebeMultiply(negativeVector);
            
            assertEquals(3, result.getDimension());
            assertEquals(-1.0, result.getEntry(0), 0.0001);
            assertEquals(-4.0, result.getEntry(1), 0.0001);
            assertEquals(-9.0, result.getEntry(2), 0.0001);
        }

    @Test
        public void testEbeMultiply_DoesNotModifyOriginal() {
            // Create test vectors
            double[] data1 = {1.0, 2.0, 3.0};
            double[] data2 = {4.0, 5.0, 6.0};
            OpenMapRealVector vector1 = new OpenMapRealVector(data1);
            OpenMapRealVector vector2 = new OpenMapRealVector(data2);
            
            // Make a copy of the original vector
            OpenMapRealVector originalCopy = new OpenMapRealVector(vector1);
            
            // Perform the operation (should return a new vector without modifying original)
            vector1.ebeMultiply(vector2);
            
            // Verify original vector remains unchanged
            assertEquals(originalCopy.getEntry(0), vector1.getEntry(0), 0.0001);
            assertEquals(originalCopy.getEntry(1), vector1.getEntry(1), 0.0001);
            assertEquals(originalCopy.getEntry(2), vector1.getEntry(2), 0.0001);
        }

    @Test
        public void testEbeMultiply_WithMockVector() {
            // Create and initialize vector1
            OpenMapRealVector vector1 = new OpenMapRealVector(3);
            vector1.setEntry(0, 1.0);
            vector1.setEntry(1, 2.0);
            vector1.setEntry(2, 3.0);
            
            // Mock the input vector
            RealVector mockVector = mock(RealVector.class);
            when(mockVector.getDimension()).thenReturn(3);
            when(mockVector.getEntry(0)).thenReturn(2.0);
            when(mockVector.getEntry(1)).thenReturn(3.0);
            when(mockVector.getEntry(2)).thenReturn(4.0);
            
            OpenMapRealVector result = vector1.ebeMultiply(mockVector);
            
            assertEquals(3, result.getDimension());
            assertEquals(2.0, result.getEntry(0), 0.0001); // 1.0 * 2.0
            assertEquals(6.0, result.getEntry(1), 0.0001); // 2.0 * 3.0
            assertEquals(12.0, result.getEntry(2), 0.0001); // 3.0 * 4.0
        }

    @Test(expected = NullPointerException.class)
    public void testEbeMultiply_WithNullVector() {
        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
        vector1.ebeMultiply((RealVector) null);
    }


}
