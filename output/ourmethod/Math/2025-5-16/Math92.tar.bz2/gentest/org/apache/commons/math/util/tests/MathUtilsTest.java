package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                          public void testBinomialCoefficient_EdgeCases() {
                              // Test cases where k=0 or k=n
                              assertEquals(1, MathUtils.binomialCoefficient(5, 0));
                              assertEquals(1, MathUtils.binomialCoefficient(5, 5));
                              assertEquals(1, MathUtils.binomialCoefficient(0, 0));
                              
                              // Test cases where k=1 or k=n-1
                              assertEquals(5, MathUtils.binomialCoefficient(5, 1));
                              assertEquals(5, MathUtils.binomialCoefficient(5, 4));
                          }

 @Test
                          public void testBinomialCoefficient_SmallValues() {
                              // Test small values that don't risk overflow
                              assertEquals(10, MathUtils.binomialCoefficient(5, 2));
                              assertEquals(10, MathUtils.binomialCoefficient(5, 3)); // Test symmetry
                              assertEquals(35, MathUtils.binomialCoefficient(7, 3));
                              assertEquals(21, MathUtils.binomialCoefficient(7, 2));
                          }

 @Test
                          public void testBinomialCoefficient_MediumValues() {
                              // Test values in the 61-66 range where special handling occurs
                              assertEquals(916895, MathUtils.binomialCoefficient(50, 10));
                              assertEquals(15820024220L, MathUtils.binomialCoefficient(60, 5));
                              assertEquals(74974368, MathUtils.binomialCoefficient(66, 33));
                          }

 @Test
                          public void testBinomialCoefficient_LargeValues() {
                              // Test large values (>66) where overflow checking is needed
                              assertEquals(10272278170L, MathUtils.binomialCoefficient(70, 5));
                              assertEquals(536878650, MathUtils.binomialCoefficient(70, 6));
                              assertEquals(190578024, MathUtils.binomialCoefficient(100, 3));
                          }

 @Test
                          public void testBinomialCoefficient_SymmetryProperty() {
                              // Verify that C(n,k) == C(n,n-k) for various values
                              assertEquals(MathUtils.binomialCoefficient(10, 3), MathUtils.binomialCoefficient(10, 7));
                              assertEquals(MathUtils.binomialCoefficient(20, 5), MathUtils.binomialCoefficient(20, 15));
                              assertEquals(MathUtils.binomialCoefficient(30, 10), MathUtils.binomialCoefficient(30, 20));
                          }

 @Test
                          public void testBinomialCoefficient_BoundaryValues() {
                              // Test boundary values around the thresholds (61 and 66)
                              assertEquals(8910345, MathUtils.binomialCoefficient(61, 5));
                              assertEquals(594914320, MathUtils.binomialCoefficient(61, 4));
                              assertEquals(747137556, MathUtils.binomialCoefficient(66, 32));
                          }

 @Test
                          public void testBinomialCoefficientDouble_EdgeCases() {
                              // Test cases where n == k or k == 0
                              assertEquals(1.0, MathUtils.binomialCoefficientDouble(5, 5), 0.0);
                              assertEquals(1.0, MathUtils.binomialCoefficientDouble(0, 0), 0.0);
                              assertEquals(1.0, MathUtils.binomialCoefficientDouble(10, 0), 0.0);
                              
                              // Test cases where k == 1 or k == n-1
                              assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 1), 0.0);
                              assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 4), 0.0);
                              assertEquals(100.0, MathUtils.binomialCoefficientDouble(100, 99), 0.0);
                          }

 @Test
                          public void testBinomialCoefficientDouble_SymmetricProperty() {
                              // Test that C(n,k) == C(n,n-k)
                              assertEquals(MathUtils.binomialCoefficientDouble(10, 3), 
                                           MathUtils.binomialCoefficientDouble(10, 7), 0.0);
                              assertEquals(MathUtils.binomialCoefficientDouble(50, 20), 
                                           MathUtils.binomialCoefficientDouble(50, 30), 0.0);
                          }

 @Test
                          public void testBinomialCoefficientDouble_SmallN() {
                              // Test cases where n < 67
                              assertEquals(6.0, MathUtils.binomialCoefficientDouble(4, 2), 0.0);
                              assertEquals(35.0, MathUtils.binomialCoefficientDouble(7, 3), 0.0);
                              assertEquals(210.0, MathUtils.binomialCoefficientDouble(10, 6), 0.0);
                              assertEquals(66.0, MathUtils.binomialCoefficientDouble(66, 65), 0.0);
                          }

 @Test
                          public void testBinomialCoefficientDouble_LargeN() {
                              // Test cases where n >= 67
                              assertEquals(161700.0, MathUtils.binomialCoefficientDouble(100, 3), 0.0);
                              assertEquals(190578024.0, MathUtils.binomialCoefficientDouble(100, 5), 0.0);
                              assertEquals(1.0, MathUtils.binomialCoefficientDouble(100, 100), 0.0);
                              assertEquals(100.0, MathUtils.binomialCoefficientDouble(100, 99), 0.0);
                              
                              // Test rounding behavior
                              double result = MathUtils.binomialCoefficientDouble(68, 34);
                              assertEquals(2.832691e+19, result, 1e14); // Allow some tolerance for floating point
                          }

 @Test
                          public void testBinomialCoefficientDouble_BoundaryValues() {
                              // Test boundary around n = 67
                              assertEquals(2212562700.0, MathUtils.binomialCoefficientDouble(66, 33), 0.0);
                              double result67 = MathUtils.binomialCoefficientDouble(67, 33);
                              assertTrue(result67 > 2212562700.0); // Should be larger than C(66,33)
                              
                              // Test very large n with small k
                              assertEquals(4950.0, MathUtils.binomialCoefficientDouble(100, 2), 0.0);
                          }

 @Test
                          public void testBinomialCoefficientLog_InvalidArguments() {
                              // Test n < k
                              thrown.expect(IllegalArgumentException.class);
                              thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                              MathUtils.binomialCoefficientLog(5, 10);
                      
                              // Test n < 0
                              thrown.expect(IllegalArgumentException.class);
                              thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                              MathUtils.binomialCoefficientLog(-1, 2);
                          }

 @Test
                          public void testBinomialCoefficientLog_EdgeCases() {
                              // Test n == k
                              assertEquals(0.0, MathUtils.binomialCoefficientLog(10, 10), 1e-10);
                              
                              // Test k == 0
                              assertEquals(0.0, MathUtils.binomialCoefficientLog(15, 0), 1e-10);
                              
                              // Test k == 1
                              assertEquals(Math.log(20), MathUtils.binomialCoefficientLog(20, 1), 1e-10);
                              
                              // Test k == n-1
                              assertEquals(Math.log(25), MathUtils.binomialCoefficientLog(25, 24), 1e-10);
                          }

 @Test
                          public void testBinomialCoefficientLog_SmallValues() {
                              // Test n < 67 (exact computation path)
                              double expected1 = Math.log(MathUtils.binomialCoefficient(10, 5));
                              assertEquals(expected1, MathUtils.binomialCoefficientLog(10, 5), 1e-10);
                              
                              double expected2 = Math.log(MathUtils.binomialCoefficient(66, 33));
                              assertEquals(expected2, MathUtils.binomialCoefficientLog(66, 33), 1e-10);
                          }

 @Test
                          public void testBinomialCoefficientLog_MediumValues() {
                              // Test 67 <= n < 1030 (binomialCoefficientDouble path)
                              double expected1 = Math.log(MathUtils.binomialCoefficientDouble(100, 50));
                              assertEquals(expected1, MathUtils.binomialCoefficientLog(100, 50), 1e-10);
                              
                              double expected2 = Math.log(MathUtils.binomialCoefficientDouble(1029, 500));
                              assertEquals(expected2, MathUtils.binomialCoefficientLog(1029, 500), 1e-10);
                          }

 @Test
                          public void testBinomialCoefficientLog_LargeValues() {
                              // Test n >= 1030 (log sum path)
                              // We'll verify the calculation by comparing with expected values
                              // For n=1030, k=515
                              double expected = 0;
                              for (int i = 516; i <= 1030; i++) {
                                  expected += Math.log(i);
                              }
                              for (int i = 2; i <= 515; i++) {
                                  expected -= Math.log(i);
                              }
                              assertEquals(expected, MathUtils.binomialCoefficientLog(1030, 515), 1e-10);
                              
                              // Another large value test
                              expected = 0;
                              for (int i = 1001; i <= 2000; i++) {
                                  expected += Math.log(i);
                              }
                              for (int i = 2; i <= 1000; i++) {
                                  expected -= Math.log(i);
                              }
                              assertEquals(expected, MathUtils.binomialCoefficientLog(2000, 1000), 1e-10);
                          }

 @Test
                          public void testBinomialCoefficientLog_SymmetryProperty() {
                              // Verify that C(n,k) == C(n,n-k) for various n and k
                              int n = 50;
                              int k = 20;
                              assertEquals(MathUtils.binomialCoefficientLog(n, k), 
                                           MathUtils.binomialCoefficientLog(n, n-k), 1e-10);
                              
                              n = 1000;
                              k = 300;
                              assertEquals(MathUtils.binomialCoefficientLog(n, k), 
                                           MathUtils.binomialCoefficientLog(n, n-k), 1e-10);
                          }

 @Test
                  public void testBinomialCoefficient_InvalidNLessThanK() {
                      org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                      exceptionRule.expect(IllegalArgumentException.class);
                      exceptionRule.expectMessage("must have n >= k for binomial coefficient (n,k)");
                      MathUtils.binomialCoefficient(5, 6);
                  }

 @Test
                  public void testBinomialCoefficient_InvalidNegativeN() {
                      org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                      exceptionRule.expect(IllegalArgumentException.class);
                      exceptionRule.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                      MathUtils.binomialCoefficient(-1, 0);
                  }

 @Test
                  public void testBinomialCoefficient_InvalidNegativeK() {
                      // Even though k is negative, the primary check is n >= k, which fails first
                      ExpectedException exceptionRule = ExpectedException.none();
                      exceptionRule.expect(IllegalArgumentException.class);
                      exceptionRule.expectMessage("must have n >= k for binomial coefficient (n,k)");
                      MathUtils.binomialCoefficient(5, -1);
                  }

 @Test
                  public void testBinomialCoefficientDouble_InvalidInput_NLessThanK() {
                      org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                      exceptionRule.expect(IllegalArgumentException.class);
                      exceptionRule.expectMessage("must have n >= k for binomial coefficient (n,k)");
                      MathUtils.binomialCoefficientDouble(5, 6);
                  }

 @Test
                  public void testBinomialCoefficientDouble_InvalidInput_NegativeN() {
                      try {
                          MathUtils.binomialCoefficientDouble(-1, 0);
                          fail("Expected IllegalArgumentException");
                      } catch (IllegalArgumentException e) {
                          assertEquals("must have n >= 0 for binomial coefficient (n,k)", e.getMessage());
                      }
                  }

 @Test
              public void testBinomialCoefficientLogForN() {
                  // Mock the helper methods to return known values
                  MathUtils mathUtils = mock(MathUtils.class);
                  when(mathUtils.binomialCoefficient(67, 2)).thenReturn(2211L);
                  when(mathUtils.binomialCoefficientDouble(67, 2)).thenReturn(2211.0);
                  
                  // Call the method with n=67 (boundary case)
                  double result = mathUtils.binomialCoefficientLog(67, 2);
                  
                  // Verify the correct helper method was called
                  // Original should call binomialCoefficientDouble (n < 67 is false for n=67)
                  // Mutant would call binomialCoefficient (n <= 67 is true for n=67)
                  verify(mathUtils, never()).binomialCoefficient(67, 2);
                  verify(mathUtils).binomialCoefficientDouble(67, 2);
                  
                  // Verify the result matches expected log value
                  assertEquals(Math.log(2211.0), result, 1e-10);
              }

 @Test
             public void testBinomialCoefficientLogBoundaryAt() {
                 // Test the boundary case where n=66
                 // Original: should use exact computation (n < 67)
                 // Mutant: will use double approximation (n < 66 is false)
                 
                 // Choose k such that we don't hit any special cases
                 int n = 66;
                 int k = 5;
                 
                 // Calculate expected value using exact computation
                 double expectedExact = Math.log(MathUtils.binomialCoefficient(n, k));
                 
                 // Calculate actual value
                 double actual = MathUtils.binomialCoefficientLog(n, k);
                 
                 // For exact computation, they should be exactly equal
                 assertEquals("For n=66, should use exact computation", 
                             expectedExact, actual, 0.0);
                 
                 // Additionally test n=65 to ensure both versions agree on smaller values
                 n = 65;
                 expectedExact = Math.log(MathUtils.binomialCoefficient(n, k));
                 actual = MathUtils.binomialCoefficientLog(n, k);
                 assertEquals("For n=65, should use exact computation",
                             expectedExact, actual, 0.0);
                 
                 // And test n=67 to ensure it uses double approximation
                 n = 67;
                 double expectedApprox = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                 actual = MathUtils.binomialCoefficientLog(n, k);
                 assertEquals("For n=67, should use double approximation",
                             expectedApprox, actual, 1e-15); // Allow small difference for double approximation
             }

 @Test
            public void testBinomialCoefficientLogBoundaryCases() {
                // Test n=66 (should use exact computation)
                double result66 = MathUtils.binomialCoefficientLog(66, 5);
                double expectedExact66 = Math.log(MathUtils.binomialCoefficient(66, 5));
                assertEquals("For n=66 should use exact computation", 
                            expectedExact66, result66, 1e-10);
                
                // Test n=67 (should use double approximation)
                double result67 = MathUtils.binomialCoefficientLog(67, 5);
                double expectedApprox67 = Math.log(MathUtils.binomialCoefficientDouble(67, 5));
                assertEquals("For n=67 should use double approximation", 
                            expectedApprox67, result67, 1e-10);
                
                // Test n=66 with k=1 (special case)
                double result66k1 = MathUtils.binomialCoefficientLog(66, 1);
                assertEquals("For k=1 should return log(n)", 
                            Math.log(66), result66k1, 1e-10);
                
                // Test n=67 with k=66 (special case)
                double result67k66 = MathUtils.binomialCoefficientLog(67, 66);
                assertEquals("For k=n-1 should return log(n)", 
                            Math.log(67), result67k66, 1e-10);
            }

 @Test
           public void testBinomialCoefficientLogForSmallN() {
               // Test with n=10 (which is <67) and k=2
               int n = 10;
               int k = 2;
               
               // Expected value: log(C(10,2)) = log(45) ≈ 3.80666248977
               double expected = Math.log(45.0);
               
               // Actual value from the method
               double actual = MathUtils.binomialCoefficientLog(n, k);
               
               // Verify the result matches the exact computation
               assertEquals(expected, actual, 1e-10);
               
               // Additional test case with n=66 (boundary case)
               n = 66;
               k = 33;
               expected = Math.log(MathUtils.binomialCoefficient(n, k));
               actual = MathUtils.binomialCoefficientLog(n, k);
               assertEquals(expected, actual, 1e-10);
           }

 @Test
          public void testBinomialCoefficientLogSmallN() {
              // Test with small n where exact and double computations differ
              int n = 66;  // Just below threshold of 67
              int k = 33;  // Middle value to maximize difference
              
              // Calculate expected value using exact computation
              double exactLog = Math.log(MathUtils.binomialCoefficient(n, k));
              
              // Calculate value that would be returned by mutated version
              double approxLog = Math.log(MathUtils.binomialCoefficientDouble(n, k));
              
              // The exact and approximate values should be different enough to detect
              assertNotEquals("Log of binomial coefficient should use exact computation for n < 67", 
                             approxLog, exactLog, 1e-10);
              
              // Test the actual method
              double result = MathUtils.binomialCoefficientLog(n, k);
              assertEquals("Method should return exact log computation for n < 67",
                          exactLog, result, 1e-10);
          }

 @Test
         public void testBinomialCoefficientLogBoundaryCase() {
             // Test the boundary case where n=1029
             int n = 1029;
             int k = 515; // middle value to avoid special cases
             
             // Calculate expected value using original behavior (binomialCoefficientDouble)
             double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
             
             // Get actual value
             double actual = MathUtils.binomialCoefficientLog(n, k);
             
             // Verify the result is close to expected (with some tolerance for floating point)
             assertEquals("For n=1029 should use binomialCoefficientDouble approach", 
                         expected, actual, 1e-10);
             
             // Also test with k=1 to verify special case still works
             assertEquals("Special case k=1 should return log(n)",
                         Math.log(n), MathUtils.binomialCoefficientLog(n, 1), 1e-10);
             
             // Test with k=1028 (n-1) to verify special case
             assertEquals("Special case k=n-1 should return log(n)",
                         Math.log(n), MathUtils.binomialCoefficientLog(n, n-1), 1e-10);
         }

 @Test
        public void testBinomialCoefficientLogForMediumN() {
            // Test with n between 67 and 1030 to catch the mutant
            int n = 100;
            int k = 50;
            
            // Calculate expected value using binomialCoefficientDouble
            double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
            
            // Calculate actual value
            double actual = MathUtils.binomialCoefficientLog(n, k);
            
            // Verify they match (with some tolerance for floating point)
            assertEquals(expected, actual, 1e-10);
            
            // Also test another value in this range
            n = 500;
            k = 250;
            expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
            actual = MathUtils.binomialCoefficientLog(n, k);
            assertEquals(expected, actual, 1e-10);
        }

 @Test
       public void testBinomialCoefficientLogForLargeNWithDifference() {
           // Test case where n = 1030, k = 1029 (n-k = 1)
           // Should return log(1030) since C(1030,1029) = 1030
           int n = 1030;
           int k = 1029;
           double expected = Math.log(1030.0);
           double actual = MathUtils.binomialCoefficientLog(n, k);
           
           // The mutant would subtract log(1) (which is 0) making no difference in this case
           // Need a different case where n-k > 1 to see the effect
           
           // Better test case where n-k = 2
           n = 1030;
           k = 1028;
           // C(1030,1028) = C(1030,2) = 1030*1029/2
           // Original: subtracts log(2)
           // Mutant: subtracts log(1) + log(2)
           double logSum = Math.log(1029.0) + Math.log(1030.0);
           expected = logSum - Math.log(2.0);
           actual = MathUtils.binomialCoefficientLog(n, k);
           assertEquals(expected, actual, 1e-10);
           
           // The mutant would produce logSum - log(1) - log(2) = expected - 0 = expected
           // So this still wouldn't catch it
           
           // Need to find a case where the loop actually makes a difference
           // Let's try n=1030, k=1027 (n-k=3)
           // Original: subtracts log(2) + log(3)
           // Mutant: subtracts log(1) + log(2) + log(3)
           n = 1030;
           k = 1027;
           logSum = Math.log(1028.0) + Math.log(1029.0) + Math.log(1030.0);
           expected = logSum - (Math.log(2.0) + Math.log(3.0));
           actual = MathUtils.binomialCoefficientLog(n, k);
           assertEquals(expected, actual, 1e-10);
           
           // The mutant would produce logSum - (0 + Math.log(2) + Math.log(3)) = expected + Math.log(2)
           // This would be detectably different
       }

 @Test
      public void testBinomialCoefficientLogForSmallN1() {
          // Test with n=10 (which is <67) and k=2 (not a special case)
          // This should use the exact computation path (binomialCoefficient)
          // but the mutant would skip this path
          
          // Expected value: log(10 choose 2) = log(45) ≈ 3.8066625
          double expected = Math.log(45.0);
          double actual = MathUtils.binomialCoefficientLog(10, 2);
          
          // Verify with delta to account for floating point precision
          assertEquals(expected, actual, 1e-10);
          
          // Another test case with n=66 (boundary case)
          // 66 choose 33 is a large but computable value
          double expected2 = Math.log(MathUtils.binomialCoefficient(66, 33));
          double actual2 = MathUtils.binomialCoefficientLog(66, 33);
          assertEquals(expected2, actual2, 1e-10);
      }

 @Test
         public void testBinomialCoefficientLog_InvalidInput_nLessThanK() {
             int n = 5;
             int k = 6;
             
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
             
             MathUtils.binomialCoefficientLog(n, k);
         }

 @Test
         public void testBinomialCoefficientLog_InvalidInput_nNegative() {
             int n = -1;
             int k = 2;
             
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
             
             MathUtils.binomialCoefficientLog(n, k);
         }

 @Test
        public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
            MathUtils.binomialCoefficientLog(3, 5); // n=3, k=5 (n < k)
        }

 @Test
        public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
            MathUtils.binomialCoefficientLog(-1, 2); // n=-1, k=2 (n < 0)
        }

 @Test
       public void testBinomialCoefficientLogInvalidInputThrowsIllegalArgumentException() {
           // Test case for n < k
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
           MathUtils.binomialCoefficientLog(5, 10); // n=5, k=10 (n < k)
       }

 @Test
       public void testBinomialCoefficientLogNegativeNThrowsIllegalArgumentException() {
           // Test case for n < 0
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
           MathUtils.binomialCoefficientLog(-1, 0); // n=-1, k=0 (n < 0)
       }

 @Test(expected = IllegalArgumentException.class)
      public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException1() {
          // This test will fail if the mutant is present (throws RuntimeException instead)
          MathUtils.binomialCoefficientLog(3, 5); // n < k
      }

 @Test(expected = IllegalArgumentException.class)
      public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException1() {
          // This test will fail if the mutant is present (throws RuntimeException instead)
          MathUtils.binomialCoefficientLog(-1, 2); // n < 0
      }

 @Test
      public void testBinomialCoefficientLog_ValidInputs_DoesNotThrow() {
          // Just to verify that valid inputs don't throw exceptions
          MathUtils.binomialCoefficientLog(5, 3); // valid case
          MathUtils.binomialCoefficientLog(0, 0); // edge case
          MathUtils.binomialCoefficientLog(100, 50); // large n case
      }

 @Test
     public void testBinomialCoefficientLog_InvalidInput_nLessThanK1() {
         int n = 5;
         int k = 10;
         
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
         
         MathUtils.binomialCoefficientLog(n, k);
     }

 @Test
     public void testBinomialCoefficientLog_InvalidInput_nNegative1() {
         int n = -5;
         int k = 2;
         
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
         
         MathUtils.binomialCoefficientLog(n, k);
     }

}
