package gentest.org.apache.commons.math.estimation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.estimation.*;
import java.util.Arrays;
import org.apache.commons.math.linear.InvalidMatrixException;
import org.apache.commons.math.linear.RealMatrixImpl;
 
public class AbstractEstimatorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                            public void testGuessParametersErrors_ReturnsCorrectErrorValues() throws Exception {
                                                                                // Setup
                                                                                AbstractEstimator estimator = new AbstractEstimator() {
                                                                                    @Override
                                                                                    public void estimate(EstimationProblem problem) {}
                                                                                    
                                                                                    @Override
                                                                                    public double getChiSquare(EstimationProblem problem) {
                                                                                        return 4.0; // chi-square value
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public double[][] getCovariances(EstimationProblem problem) {
                                                                                        return new double[][] {{1.0, 0.0}, {0.0, 4.0}}; // covariance matrix
                                                                                    }
                                                                                };
                                                                                
                                                                                // Create mock measurements and parameters
                                                                                WeightedMeasurement[] measurements = new WeightedMeasurement[5];
                                                                                EstimatedParameter[] parameters = new EstimatedParameter[2];
                                                                                
                                                                                EstimationProblem problem = mock(EstimationProblem.class);
                                                                                when(problem.getMeasurements()).thenReturn(measurements);
                                                                                when(problem.getUnboundParameters()).thenReturn(parameters);
                                                                                
                                                                                // Test
                                                                                double[] errors = estimator.guessParametersErrors(problem);
                                                                                
                                                                                // Verify
                                                                                assertEquals(2, errors.length);
                                                                                // Expected: sqrt(covar[i][i]) * sqrt(chiSquare/(m-p))
                                                                                // sqrt(1.0) * sqrt(4.0/(5-2)) = 1 * sqrt(4/3) ≈ 1.1547
                                                                                assertEquals(1.1547, errors[0], 0.0001);
                                                                                // sqrt(4.0) * sqrt(4.0/3) = 2 * 1.1547 ≈ 2.3094
                                                                                assertEquals(2.3094, errors[1], 0.0001);
                                                                            }

    @Test
                                                                            public void testGuessParametersErrors_WithSingleParameter() throws Exception {
                                                                                // Setup
                                                                                AbstractEstimator estimator = new AbstractEstimator() {
                                                                                    @Override
                                                                                    public void estimate(EstimationProblem problem) {}
                                                                                    
                                                                                    @Override
                                                                                    public double getChiSquare(EstimationProblem problem) {
                                                                                        return 2.0; // chi-square value
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public double[][] getCovariances(EstimationProblem problem) {
                                                                                        return new double[][] {{0.25}}; // single parameter covariance
                                                                                    }
                                                                                };
                                                                                
                                                                                // Create mock measurements and parameters
                                                                                WeightedMeasurement[] measurements = new WeightedMeasurement[3];
                                                                                EstimatedParameter[] parameters = new EstimatedParameter[1];
                                                                                
                                                                                EstimationProblem problem = mock(EstimationProblem.class);
                                                                                when(problem.getMeasurements()).thenReturn(measurements);
                                                                                when(problem.getUnboundParameters()).thenReturn(parameters);
                                                                                
                                                                                // Test
                                                                                double[] errors = estimator.guessParametersErrors(problem);
                                                                                
                                                                                // Verify
                                                                                assertEquals(1, errors.length);
                                                                                // Expected: sqrt(0.25) * sqrt(2/(3-1)) = 0.5 * 1 = 0.5
                                                                                assertEquals(0.5, errors[0], 0.0001);
                                                                            }

    @Test
                                                                        public void testGetCovariances_ValidMatrix() throws Exception {
                                                                            // Setup
                                                                            // Create a testable estimator subclass
                                                                            class TestableAbstractEstimator extends AbstractEstimator {
                                                                                private double[] jacobian;
                                                                                private EstimationProblem problem;
                                                                                
                                                                                public void setJacobian(double[] jacobian) {
                                                                                    this.jacobian = jacobian;
                                                                                }
                                                                                
                                                                                public void setProblem(EstimationProblem problem) {
                                                                                    this.problem = problem;
                                                                                }
                                                                                
                                                                                @Override
                                                                                protected void updateJacobian() {
                                                                                    // No implementation needed for test
                                                                                }
                                                                                
                                                                                @Override
                                                                                public void estimate(EstimationProblem problem) {
                                                                                    // No implementation needed for test
                                                                                }
                                                                            }
                                                                            
                                                                            TestableAbstractEstimator estimator = new TestableAbstractEstimator();
                                                                            
                                                                            // Create a simple 2x2 problem (2 measurements, 2 parameters)
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                                                            WeightedMeasurement measurement2 = mock(WeightedMeasurement.class);
                                                                            WeightedMeasurement[] measurements = new WeightedMeasurement[] {measurement1, measurement2};
                                                                            EstimatedParameter param1 = mock(EstimatedParameter.class);
                                                                            EstimatedParameter param2 = mock(EstimatedParameter.class);
                                                                            EstimatedParameter[] parameters = new EstimatedParameter[] {param1, param2};
                                                                            when(problem.getMeasurements()).thenReturn(measurements);
                                                                            when(problem.getUnboundParameters()).thenReturn(parameters);
                                                                            
                                                                            // Jacobian matrix (2x2) stored in 1D array column-wise
                                                                            // [1 2]
                                                                            // [3 4]
                                                                            double[] jacobian = {1, 3, 2, 4};
                                                                            estimator.setJacobian(jacobian);
                                                                            estimator.setProblem(problem);
                                                                            
                                                                            // Expected J^T*J matrix:
                                                                            // [1*1 + 3*3  1*2 + 3*4] = [10 14]
                                                                            // [2*1 + 4*3  2*2 + 4*4]   [14 20]
                                                                            // Inverse should be:
                                                                            // [5   -3.5]
                                                                            // [-3.5 2.5]
                                                                            
                                                                            // Execute
                                                                            double[][] result = estimator.getCovariances(problem);
                                                                            
                                                                            // Verify
                                                                            assertEquals(2, result.length);
                                                                            assertEquals(2, result[0].length);
                                                                            assertEquals(5.0, result[0][0], 1e-10);
                                                                            assertEquals(-3.5, result[0][1], 1e-10);
                                                                            assertEquals(-3.5, result[1][0], 1e-10);
                                                                            assertEquals(2.5, result[1][1], 1e-10);
                                                                        }

    @Test(expected = EstimationException.class)
                                                                        public void testGetCovariances_EmptyProblem() throws Exception {
                                                                            // Setup
                                                                            AbstractEstimator estimator = new AbstractEstimator() {
                                                                                @Override
                                                                                public void estimate(EstimationProblem problem) {
                                                                                    // Empty implementation for testing
                                                                                }
                                                                                
                                                                                @Override
                                                                                protected void updateJacobian() {
                                                                                    // Empty implementation for testing
                                                                                }
                                                                            };
                                                                            
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[0]);
                                                                            when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[0]);
                                                                            
                                                                            // Execute and verify exception
                                                                            try {
                                                                                estimator.getCovariances(problem);
                                                                                fail("Expected EstimationException");
                                                                            } catch (EstimationException e) {
                                                                                assertEquals("unable to compute covariances: singular problem", e.getMessage());
                                                                                throw e;
                                                                            }
                                                                        }

    @Test
                                                                        public void testGuessParametersErrors_ThrowsExceptionWhenMeasurementsLessThanOrEqualToParameters() throws Exception {
                                                                            // Setup
                                                                            AbstractEstimator estimator = new AbstractEstimator() {
                                                                                @Override
                                                                                public void estimate(EstimationProblem problem) {}
                                                                            };
                                                                            
                                                                            double[] measurements = new double[2];
                                                                            double[] parameters = new double[2];
                                                                            
                                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                                            // Fix: Use doReturn pattern for array returns
                                                                            doReturn(measurements).when(problem).getMeasurements(); // 2 measurements
                                                                            doReturn(parameters).when(problem).getUnboundParameters(); // 2 parameters
                                                                        
                                                                            // Expect exception
                                                                            thrown.expect(EstimationException.class);
                                                                            thrown.expectMessage("no degrees of freedom (2 measurements, 2 parameters)");
                                                                        
                                                                            // Test
                                                                            estimator.guessParametersErrors(problem);
                                                                        }

    @Test
                                                                    public void testGuessParametersErrors_WithZeroCovariance() throws Exception {
                                                                        // Setup
                                                                        AbstractEstimator estimator = new AbstractEstimator() {
                                                                            @Override
                                                                            public void estimate(EstimationProblem problem) {}
                                                                            
                                                                            @Override
                                                                            public double getChiSquare(EstimationProblem problem) {
                                                                                return 9.0; // chi-square value
                                                                            }
                                                                            
                                                                            @Override
                                                                            public double[][] getCovariances(EstimationProblem problem) {
                                                                                return new double[][] {{0.0, 0.0}, {0.0, 0.0}}; // zero covariance matrix
                                                                            }
                                                                        };
                                                                        
                                                                        // Create mock measurements and parameters
                                                                        WeightedMeasurement[] measurements = new WeightedMeasurement[4];
                                                                        EstimatedParameter[] parameters = new EstimatedParameter[2];
                                                                        
                                                                        EstimationProblem problem = mock(EstimationProblem.class);
                                                                        when(problem.getMeasurements()).thenReturn(measurements); // 4 measurements
                                                                        when(problem.getUnboundParameters()).thenReturn(parameters); // 2 parameters
                                                                        
                                                                        // Test
                                                                        double[] errors = estimator.guessParametersErrors(problem);
                                                                        
                                                                        // Verify
                                                                        assertEquals(2, errors.length);
                                                                        // Expected: sqrt(0) * sqrt(9/(4-2)) = 0 * sqrt(4.5) = 0
                                                                        assertEquals(0.0, errors[0], 0.0001);
                                                                        assertEquals(0.0, errors[1], 0.0001);
                                                                    }

    @Test
                                                            public void testGetCovariances_RectangularMatrix() throws Exception {
                                                                // Setup (3 measurements, 2 parameters)
                                                                // Define TestableAbstractEstimator as inner class for testing
                                                                class TestableAbstractEstimator extends AbstractEstimator {
                                                                    private double[] jacobian;
                                                                    
                                                                    public void setJacobian(double[] jacobian) {
                                                                        this.jacobian = jacobian;
                                                                    }
                                                                    
                                                                    @Override
                                                                    protected void updateJacobian() {
                                                                        // Mock implementation
                                                                    }
                                                                    
                                                                    @Override
                                                                    public void estimate(EstimationProblem problem) {
                                                                        // Mock implementation
                                                                    }
                                                                }
                                                                
                                                                TestableAbstractEstimator estimator = new TestableAbstractEstimator();
                                                                
                                                                // Create mock objects
                                                                EstimationProblem problem = mock(EstimationProblem.class);
                                                                WeightedMeasurement[] measurements = new WeightedMeasurement[] {
                                                                    mock(WeightedMeasurement.class),
                                                                    mock(WeightedMeasurement.class),
                                                                    mock(WeightedMeasurement.class)
                                                                };
                                                                EstimatedParameter[] parameters = new EstimatedParameter[] {
                                                                    new EstimatedParameter("p0", 0),
                                                                    new EstimatedParameter("p1", 0)
                                                                };
                                                                when(problem.getMeasurements()).thenReturn(measurements);
                                                                when(problem.getUnboundParameters()).thenReturn(parameters);
                                                                
                                                                // Jacobian matrix (3x2) stored in 1D array column-wise
                                                                // [1 4]
                                                                // [2 5]
                                                                // [3 6]
                                                                double[] jacobian = {1, 2, 3, 4, 5, 6};
                                                                estimator.setJacobian(jacobian);
                                                                
                                                                // Use reflection to call protected initializeEstimate method
                                                                Method initializeEstimate = AbstractEstimator.class.getDeclaredMethod(
                                                                    "initializeEstimate", EstimationProblem.class);
                                                                initializeEstimate.setAccessible(true);
                                                                initializeEstimate.invoke(estimator, problem);
                                                                
                                                                // Expected J^T*J matrix:
                                                                // [1*1+2*2+3*3  1*4+2*5+3*6] = [14 32]
                                                                // [4*1+5*2+6*3  4*4+5*5+6*6]   [32 77]
                                                                // Inverse should be:
                                                                // [ 77/126  -32/126]
                                                                // [-32/126   14/126]
                                                                
                                                                // Execute
                                                                double[][] result = estimator.getCovariances(problem);
                                                                
                                                                // Verify
                                                                assertEquals(2, result.length);
                                                                assertEquals(2, result[0].length);
                                                                assertEquals(77.0/126, result[0][0], 1e-10);
                                                                assertEquals(-32.0/126, result[0][1], 1e-10);
                                                                assertEquals(-32.0/126, result[1][0], 1e-10);
                                                                assertEquals(14.0/126, result[1][1], 1e-10);
                                                            }

    @Test
                                                        public void testGetCovariances_SingularMatrix() throws Exception {
                                                            // Setup
                                                            // Define TestableAbstractEstimator as a local class
                                                            class TestableAbstractEstimator extends AbstractEstimator {
                                                                private double[] jacobian;
                                                                
                                                                public void setJacobian(double[] jacobian) {
                                                                    this.jacobian = jacobian;
                                                                }
                                                                
                                                                @Override
                                                                protected void updateJacobian() {
                                                                    // Implementation would use the set jacobian
                                                                }
                                                                
                                                                @Override
                                                                public void estimate(EstimationProblem problem) {
                                                                    // Empty implementation for testing
                                                                }
                                                            }
                                                            
                                                            TestableAbstractEstimator estimator = new TestableAbstractEstimator();
                                                            
                                                            EstimationProblem problem = mock(EstimationProblem.class);
                                                            WeightedMeasurement measurement1 = mock(WeightedMeasurement.class);
                                                            WeightedMeasurement measurement2 = mock(WeightedMeasurement.class);
                                                            WeightedMeasurement[] measurements = new WeightedMeasurement[]{measurement1, measurement2};
                                                            EstimatedParameter param1 = mock(EstimatedParameter.class);
                                                            EstimatedParameter param2 = mock(EstimatedParameter.class);
                                                            EstimatedParameter[] parameters = new EstimatedParameter[]{param1, param2};
                                                            when(problem.getMeasurements()).thenReturn(measurements);
                                                            when(problem.getUnboundParameters()).thenReturn(parameters);
                                                            
                                                            // Singular Jacobian matrix (rank 1)
                                                            // [1 2]
                                                            // [2 4]
                                                            double[] jacobian = {1, 2, 2, 4};
                                                            estimator.setJacobian(jacobian);
                                                        
                                                            try {
                                                                // Execute
                                                                estimator.getCovariances(problem);
                                                                fail("Expected EstimationException");
                                                            } catch (EstimationException e) {
                                                                // Verify
                                                                assertEquals("unable to compute covariances: singular problem", e.getMessage());
                                                            }
                                                        }

    @Test
                                                   public void testGuessParametersErrors_ThrowsExceptionWithDetailedMessageWhenInsufficientMeasurements() {
                                                       // Setup test data where measurements <= parameters
                                                       EstimationProblem problem = mock(EstimationProblem.class);
                                                       WeightedMeasurement[] measurements = new WeightedMeasurement[2]; // m=2
                                                       EstimatedParameter[] parameters = new EstimatedParameter[2]; // p=2
                                                       
                                                       when(problem.getMeasurements()).thenReturn(measurements);
                                                       when(problem.getUnboundParameters()).thenReturn(parameters);
                                                       
                                                       // Create instance of class under test
                                                       AbstractEstimator estimator = new AbstractEstimator() {
                                                           @Override
                                                           public void estimate(EstimationProblem problem) {
                                                               // abstract method implementation
                                                           }
                                                       };
                                                       
                                                       try {
                                                           estimator.guessParametersErrors(problem);
                                                           fail("Expected EstimationException to be thrown");
                                                       } catch (EstimationException e) {
                                                           // Verify the exception message contains the detailed information
                                                           assertTrue("Exception message should contain measurements count", 
                                                                     e.getMessage().contains("measurements"));
                                                           assertTrue("Exception message should contain parameters count", 
                                                                     e.getMessage().contains("parameters"));
                                                           // Verify the message contains the expected counts (2 and 2)
                                                           assertTrue("Exception message should contain '2 measurements'", 
                                                                     e.getMessage().contains("2 measurements"));
                                                           assertTrue("Exception message should contain '2 parameters'", 
                                                                     e.getMessage().contains("2 parameters"));
                                                       }
                                                   }

    @Test
                                              public void testGuessParametersErrors_ThrowsExceptionWithCorrectParameters() {
                                                  // Setup test data where m <= p
                                                  EstimationProblem problem = mock(EstimationProblem.class);
                                                  WeightedMeasurement[] measurements = new WeightedMeasurement[2]; // m = 2
                                                  EstimatedParameter[] parameters = new EstimatedParameter[2]; // p = 2
                                                  
                                                  when(problem.getMeasurements()).thenReturn(measurements);
                                                  when(problem.getUnboundParameters()).thenReturn(parameters);
                                                  
                                                  // Create instance of class under test
                                                  AbstractEstimator estimator = new AbstractEstimator() {
                                                      @Override
                                                      public void estimate(EstimationProblem problem) {
                                                          // empty implementation for abstract method
                                                      }
                                                  };
                                                  
                                                  try {
                                                      estimator.guessParametersErrors(problem);
                                                      fail("Expected EstimationException to be thrown");
                                                  } catch (EstimationException e) {
                                                      // Verify exception message contains actual m and p values (2 and 2)
                                                      assertTrue("Exception message should contain actual measurement count", 
                                                                e.getMessage().contains("2 measurements"));
                                                      assertTrue("Exception message should contain actual parameter count", 
                                                                e.getMessage().contains("2 parameters"));
                                                  }
                                              }

    @Test
                                     public void testGuessParametersErrorsLoopBehavior() throws EstimationException {
                                         // Create test instance (assuming this is in AbstractEstimatorTest)
                                         AbstractEstimator testInstance = new AbstractEstimator() {
                                             @Override
                                             public void estimate(EstimationProblem problem) throws EstimationException {
                                                 // empty implementation for abstract method
                                             }
                                         };
                                         
                                         // Setup mock EstimationProblem
                                         EstimationProblem problem = mock(EstimationProblem.class);
                                         
                                         // Setup measurements and parameters
                                         WeightedMeasurement[] measurements = new WeightedMeasurement[3];
                                         EstimatedParameter[] parameters = new EstimatedParameter[2];
                                         when(problem.getMeasurements()).thenReturn(measurements);
                                         when(problem.getUnboundParameters()).thenReturn(parameters);
                                         
                                         // Mock test instance methods using spy
                                         AbstractEstimator spyInstance = spy(testInstance);
                                         doReturn(4.0).when(spyInstance).getChiSquare(problem); // chi-square = 4
                                         double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}}; // identity matrix
                                         doReturn(covariances).when(spyInstance).getCovariances(problem);
                                         
                                         // Expected calculations:
                                         // c = sqrt(4.0 / (3-2)) = 2.0
                                         // errors[i] = sqrt(1.0) * 2.0 = 2.0 for each parameter
                                         double[] expectedErrors = {2.0, 2.0};
                                         
                                         // Call method and verify
                                         double[] actualErrors = spyInstance.guessParametersErrors(problem);
                                         assertArrayEquals(expectedErrors, actualErrors, 0.0001);
                                         
                                         // Verify loop executed exactly parameters.length times
                                         // This implicitly tests the loop increment behavior
                                         assertEquals(parameters.length, actualErrors.length);
                                         
                                         // Verify all elements were processed
                                         for (double error : actualErrors) {
                                             assertEquals(2.0, error, 0.0001);
                                         }
                                     }

    @Test
                                public void testGuessParametersErrorsWithDifferentArrayLengths() throws EstimationException {
                                    // Create estimator instance
                                    AbstractEstimator estimator = new AbstractEstimator() {
                                        @Override
                                        public void estimate(EstimationProblem problem) {
                                            // Empty implementation for abstract method
                                        }
                                    };
                                    
                                    // Create mock problem where unboundParameters.length != covar.length
                                    EstimationProblem problem = mock(EstimationProblem.class);
                                    WeightedMeasurement[] measurements = new WeightedMeasurement[5]; // m=5
                                    EstimatedParameter[] unboundParams = new EstimatedParameter[3];   // p=3
                                    when(problem.getMeasurements()).thenReturn(measurements);
                                    when(problem.getUnboundParameters()).thenReturn(unboundParams);
                                    
                                    // Mock getChiSquare to return a fixed value
                                    when(estimator.getChiSquare(problem)).thenReturn(10.0);
                                    
                                    // Create covariance matrix with different length (4x4 instead of 3x3)
                                    double[][] covar = new double[4][4];
                                    covar[0][0] = 1.0;
                                    covar[1][1] = 2.0;
                                    covar[2][2] = 3.0;
                                    covar[3][3] = 4.0;
                                    when(estimator.getCovariances(problem)).thenReturn(covar);
                                    
                                    // Call the method
                                    double[] errors = estimator.guessParametersErrors(problem);
                                    
                                    // Verify the result
                                    assertEquals(3, errors.length); // Should match unboundParams length (3)
                                    // Original code would pass this, mutant would either:
                                    // - Throw ArrayIndexOutOfBoundsException (if covar.length > errors.length)
                                    // - Or return array of length 4 (if covar.length < errors.length)
                                }

    @Test(expected = EstimationException.class)
                       public void testGuessParametersErrors_WhenMeasurementsLessThanParameters_ShouldThrowException() throws EstimationException {
                           // Setup test data where m < p
                           EstimationProblem problem = mock(EstimationProblem.class);
                           
                           // Create mock measurements array with 2 elements (m=2)
                           WeightedMeasurement[] measurements = new WeightedMeasurement[2];
                           measurements[0] = mock(WeightedMeasurement.class);
                           measurements[1] = mock(WeightedMeasurement.class);
                           
                           // Create mock parameters array with 3 elements (p=3)
                           EstimatedParameter[] parameters = new EstimatedParameter[3];
                           parameters[0] = mock(EstimatedParameter.class);
                           parameters[1] = mock(EstimatedParameter.class);
                           parameters[2] = mock(EstimatedParameter.class);
                           
                           // Configure mocks
                           when(problem.getMeasurements()).thenReturn(measurements);
                           when(problem.getUnboundParameters()).thenReturn(parameters);
                           
                           // Create instance of class under test with mocked methods
                           AbstractEstimator estimator = new AbstractEstimator() {
                               @Override
                               public void estimate(EstimationProblem problem) {
                                   // Empty implementation for abstract method
                               }
                               
                               @Override
                               public double getChiSquare(EstimationProblem problem) {
                                   return 1.0;
                               }
                               
                               @Override
                               public double[][] getCovariances(EstimationProblem problem) {
                                   return new double[][]{{1.0}};
                               }
                           };
                           
                           // This should throw exception in original code (m=2 < p=3)
                           // If mutant is present (m == p check), it won't throw exception
                           estimator.guessParametersErrors(problem);
                       }

    @Test
                  public void testGuessParametersErrors_ThrowsExceptionWithCorrectParameterOrder() {
                      // Setup test data
                      final int measurementsCount = 3;
                      final int parametersCount = 5;
                      
                      // Mock EstimationProblem
                      EstimationProblem problem = mock(EstimationProblem.class);
                      WeightedMeasurement[] measurements = new WeightedMeasurement[measurementsCount];
                      EstimatedParameter[] parameters = new EstimatedParameter[parametersCount];
                      
                      // Configure mock behavior
                      when(problem.getMeasurements()).thenReturn(measurements);
                      when(problem.getUnboundParameters()).thenReturn(parameters);
                      
                      // Create test subject (partial mock if needed)
                      AbstractEstimator estimator = new AbstractEstimator() {
                          @Override
                          protected void initializeEstimate(EstimationProblem problem) {}
                          
                          @Override
                          public void estimate(EstimationProblem problem) {}
                      };
                      
                      try {
                          // Execute method that should throw exception
                          estimator.guessParametersErrors(problem);
                          fail("Expected EstimationException to be thrown");
                      } catch (EstimationException e) {
                          // Verify exception message contains correct parameter order
                          String expectedMessage = String.format("no degrees of freedom (%d measurements, %d parameters)", 
                              measurementsCount, parametersCount);
                          assertEquals("Exception message should show measurements first then parameters", 
                              expectedMessage, e.getMessage());
                      }
                  }

    @Test
         public void testGuessParametersErrors_ThrowsExceptionWithCorrectCounts() {
             // Create a test scenario where measurements <= parameters
             EstimationProblem problem = mock(EstimationProblem.class);
             WeightedMeasurement[] measurements = new WeightedMeasurement[3]; // m = 3
             EstimatedParameter[] parameters = new EstimatedParameter[3];     // p = 3
             
             when(problem.getMeasurements()).thenReturn(measurements);
             when(problem.getUnboundParameters()).thenReturn(parameters);
             
             // Call the method - should throw exception
             AbstractEstimator estimator = new AbstractEstimator() {
                 @Override
                 public void estimate(EstimationProblem problem) {
                     // Empty implementation for abstract method
                 }
             };
             
             try {
                 estimator.guessParametersErrors(problem);
             } catch (EstimationException e) {
                 assertEquals("no degrees of freedom (3 measurements, 3 parameters)", e.getMessage());
             }
             
             // The test will fail if the exception message shows mutated values (4 measurements, 2 parameters)
         }

    @Test
    public void testGuessParametersErrors_ThrowsExceptionWithCorrectMessageFormat() {
        // Setup test data where measurements <= parameters
        EstimationProblem problem = mock(EstimationProblem.class);
        WeightedMeasurement[] measurements = new WeightedMeasurement[2];
        EstimatedParameter[] parameters = new EstimatedParameter[3];
        
        when(problem.getMeasurements()).thenReturn(measurements);
        when(problem.getUnboundParameters()).thenReturn(parameters);
        
        // Create instance of class under test
        AbstractEstimator estimator = new AbstractEstimator() {
            @Override
            public void estimate(EstimationProblem problem) {
                // Empty implementation for abstract method
            }
        };
        
        try {
            estimator.guessParametersErrors(problem);
            fail("Expected EstimationException to be thrown");
        } catch (EstimationException e) {
            // Verify the exact message format with parentheses
            String expectedMessage = "no degrees of freedom ({0} measurements, {1} parameters)";
            assertEquals(expectedMessage, e.getMessage());
        }
    }


}
