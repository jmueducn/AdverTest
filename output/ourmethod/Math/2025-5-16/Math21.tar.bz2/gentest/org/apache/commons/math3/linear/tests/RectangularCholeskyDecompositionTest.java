package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import org.apache.commons.math3.util.FastMath;
 
public class RectangularCholeskyDecompositionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
               public void testConstructorWithSemidefiniteMatrix() {
                   // Create a positive semidefinite matrix (rank 2)
                   double[][] data = {
                       {1, 2, 3},
                       {2, 4, 6},
                       {3, 6, 9}
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1e-10);
                   
                   // Verify rank is 2 (not full rank)
                   assertEquals(2, decomposition.getRank());
                   
                   // Verify root matrix has correct dimensions (3x2)
                   RealMatrix root = decomposition.getRootMatrix();
                   assertEquals(3, root.getRowDimension());
                   assertEquals(2, root.getColumnDimension());
               }

 @Test
               public void testConstructorWithNonPositiveDefiniteMatrixThrowsException() {
                   // Create a matrix that is not positive semidefinite
                   double[][] data = {
                       {1, 2},
                       {2, 1}  // This matrix has negative eigenvalues
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   thrown.expect(NonPositiveDefiniteMatrixException.class);
                   new RectangularCholeskyDecomposition(matrix, 1e-10);
               }

 @Test
               public void testConstructorWithZeroMatrix() {
                   // Create a zero matrix (rank 0)
                   double[][] data = {
                       {0, 0},
                       {0, 0}
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1e-10);
                   
                   assertEquals(0, decomposition.getRank());
                   assertEquals(0, decomposition.getRootMatrix().getColumnDimension());
               }

 @Test
               public void testConstructorWithSmallValues() {
                   // Create a matrix with very small values
                   double small = 1e-15;
                   double[][] data = {
                       {small, small},
                       {small, small}
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   // Test with threshold larger than matrix elements
                   thrown.expect(NonPositiveDefiniteMatrixException.class);
                   new RectangularCholeskyDecomposition(matrix, 1e-10);
               }

 @Test
               public void testGetRootMatrixReturnsImmutable() {
                   double[][] data = {
                       {4, 2},
                       {2, 5}
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1e-10);
                   
                   RealMatrix root = decomposition.getRootMatrix();
                   
                   // Verify the returned matrix is immutable (attempting to modify should throw)
                   thrown.expect(UnsupportedOperationException.class);
                   root.setEntry(0, 0, 0);
               }

 @Test
       public void testConstructorWithPositiveDefiniteMatrix() {
           // Define test constants
           final double EPSILON = 1e-10;
           
           // Create a positive definite matrix
           double[][] data = {
               {4, 12, -16},
               {12, 37, -43},
               {-16, -43, 98}
           };
           RealMatrix matrix = MatrixUtils.createRealMatrix(data);
           
           RectangularCholeskyDecomposition decomposition = 
               new RectangularCholeskyDecomposition(matrix, 1e-10);
           
           // Verify rank is full (3 for this matrix)
           assertEquals(3, decomposition.getRank());
           
           // Verify root matrix properties
           RealMatrix root = decomposition.getRootMatrix();
           RealMatrix reconstructed = root.multiply(root.transpose());
           
           // Check if reconstruction matches original matrix
           for (int i = 0; i < matrix.getRowDimension(); i++) {
               for (int j = 0; j < matrix.getColumnDimension(); j++) {
                   assertEquals(matrix.getEntry(i, j), reconstructed.getEntry(i, j), EPSILON);
               }
           }
       }

 @Test
       public void testConstructorWithDiagonalMatrix() {
           // Define epsilon for floating point comparisons
           final double EPSILON = 1e-10;
           
           // Create a diagonal positive definite matrix
           double[][] data = {
               {4, 0, 0},
               {0, 9, 0},
               {0, 0, 1}
           };
           RealMatrix matrix = MatrixUtils.createRealMatrix(data);
           
           RectangularCholeskyDecomposition decomposition = 
               new RectangularCholeskyDecomposition(matrix, 1e-10);
           
           assertEquals(3, decomposition.getRank());
           RealMatrix root = decomposition.getRootMatrix();
           
           // Verify root matrix is diagonal with square roots
           assertEquals(2.0, root.getEntry(0, 0), EPSILON);
           assertEquals(0.0, root.getEntry(0, 1), EPSILON);
           assertEquals(0.0, root.getEntry(0, 2), EPSILON);
           assertEquals(0.0, root.getEntry(1, 0), EPSILON);
           assertEquals(3.0, root.getEntry(1, 1), EPSILON);
           assertEquals(0.0, root.getEntry(1, 2), EPSILON);
           assertEquals(0.0, root.getEntry(2, 0), EPSILON);
           assertEquals(0.0, root.getEntry(2, 1), EPSILON);
           assertEquals(1.0, root.getEntry(2, 2), EPSILON);
       }

 @Test
       public void testConstructorWithPivotingNeeded() {
           // Create a matrix that requires pivoting (diagonal not in descending order)
           double[][] data = {
               {1, 0.5},
               {0.5, 2}
           };
           RealMatrix matrix = MatrixUtils.createRealMatrix(data);
           
           double small = 1e-10;
           RectangularCholeskyDecomposition decomposition = 
               new RectangularCholeskyDecomposition(matrix, small);
           
           // Verify decomposition worked correctly
           assertEquals(2, decomposition.getRank());
           RealMatrix root = decomposition.getRootMatrix();
           RealMatrix reconstructed = root.multiply(root.transpose());
           
           for (int i = 0; i < matrix.getRowDimension(); i++) {
               for (int j = 0; j < matrix.getColumnDimension(); j++) {
                   assertEquals(matrix.getEntry(i, j), reconstructed.getEntry(i, j), small);
               }
           }
       }

 @Test
  public void testCholeskyDecompositionWithMutantDetection() {
      // Create a simple 3x3 positive definite matrix
      double[][] data = {
          {4, 12, -16},
          {12, 37, -43},
          {-16, -43, 98}
      };
      RealMatrix matrix = MatrixUtils.createRealMatrix(data);
      double small = 1.0e-10;
      
      // Perform the decomposition
      RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
      RealMatrix root = decomposition.getRootMatrix();
      
      // Expected root matrix (calculated manually or from known correct implementation)
      double[][] expectedData = {
          {2, 0, 0},
          {6, 1, 0},
          {-8, 5, 3}
      };
      RealMatrix expectedRoot = MatrixUtils.createRealMatrix(expectedData);
      
      // Verify the root matrix matches expected values
      // The mutant would produce incorrect values here because it processes diagonal elements twice
      for (int i = 0; i < expectedRoot.getRowDimension(); i++) {
          for (int j = 0; j < expectedRoot.getColumnDimension(); j++) {
              assertEquals("Element [" + i + "][" + j + "] differs",
                          expectedRoot.getEntry(i, j),
                          root.getEntry(i, j),
                          1.0e-10);
          }
      }
      
      // Also verify the rank is correct
      assertEquals(3, decomposition.getRank());
  }

 @Test
     public void testRowSwappingPreservesCorrectIndices() {
         // Create a test matrix that will force row swaps
         // Diagonal elements are ordered to force swaps
         double[][] data = {
             {4.0, 1.0, 1.0},
             {1.0, 3.0, 0.5},
             {1.0, 0.5, 5.0}
         };
         RealMatrix matrix = MatrixUtils.createRealMatrix(data);
         
         // Small threshold value
         double small = 1e-10;
         
         // Perform decomposition
         RectangularCholeskyDecomposition decomposition = 
             new RectangularCholeskyDecomposition(matrix, small);
         
         // Get the root matrix
         RealMatrix root = decomposition.getRootMatrix();
         
         // Verify the decomposition is correct: original matrix should equal root * root^T
         RealMatrix reconstructed = root.multiply(root.transpose());
         
         // The reconstruction should match the original matrix (within floating point precision)
         for (int i = 0; i < matrix.getRowDimension(); i++) {
             for (int j = 0; j < matrix.getColumnDimension(); j++) {
                 assertEquals(matrix.getEntry(i, j), reconstructed.getEntry(i, j), 1e-10);
             }
         }
         
         // Additional verification that the index mapping was correct
         // The root matrix should have non-zero elements in the expected positions
         // This specifically checks that the index array was used properly in the transformation phase
         assertTrue(root.getEntry(2, 0) != 0.0); // First column should have non-zero in row 2
         assertTrue(root.getEntry(0, 1) != 0.0); // Second column should have non-zero in row 0
     }

}
