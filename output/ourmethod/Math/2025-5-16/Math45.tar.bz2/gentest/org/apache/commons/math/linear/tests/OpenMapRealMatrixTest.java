package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NumberIsTooLargeException;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
 
public class OpenMapRealMatrixTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                          public void testConstructor_ValidDimensions() {
                              // Test normal valid dimensions
                              OpenMapRealMatrix matrix1 = new OpenMapRealMatrix(10, 20);
                              assertEquals(10, matrix1.getRowDimension());
                              assertEquals(20, matrix1.getColumnDimension());
                              
                              // Test minimum valid dimensions
                              OpenMapRealMatrix matrix2 = new OpenMapRealMatrix(1, 1);
                              assertEquals(1, matrix2.getRowDimension());
                              assertEquals(1, matrix2.getColumnDimension());
                              
                              // Test maximum valid dimensions (product just below Integer.MAX_VALUE)
                              int maxDim = (int)Math.sqrt(Integer.MAX_VALUE) - 1;
                              OpenMapRealMatrix matrix3 = new OpenMapRealMatrix(maxDim, maxDim);
                              assertEquals(maxDim, matrix3.getRowDimension());
                              assertEquals(maxDim, matrix3.getColumnDimension());
                          }

 @Test
                          public void testConstructor_ZeroDimensions() {
                              // Test zero rows
                              OpenMapRealMatrix matrix1 = new OpenMapRealMatrix(0, 10);
                              assertEquals(0, matrix1.getRowDimension());
                              assertEquals(10, matrix1.getColumnDimension());
                              
                              // Test zero columns
                              OpenMapRealMatrix matrix2 = new OpenMapRealMatrix(10, 0);
                              assertEquals(10, matrix2.getRowDimension());
                              assertEquals(0, matrix2.getColumnDimension());
                              
                              // Test both zero
                              OpenMapRealMatrix matrix3 = new OpenMapRealMatrix(0, 0);
                              assertEquals(0, matrix3.getRowDimension());
                              assertEquals(0, matrix3.getColumnDimension());
                          }

 @Test
                          public void testConstructor_InvalidNegativeDimensions() {
                              // Test negative row dimension
                              thrown.expect(IllegalArgumentException.class);
                              new OpenMapRealMatrix(-1, 10);
                              
                              // Test negative column dimension
                              thrown.expect(IllegalArgumentException.class);
                              new OpenMapRealMatrix(10, -1);
                              
                              // Test both negative
                              thrown.expect(IllegalArgumentException.class);
                              new OpenMapRealMatrix(-1, -1);
                          }

 @Test
                          public void testConstructor_TooLargeDimensions() {
                              // Test case where product of dimensions equals Integer.MAX_VALUE
                              thrown.expect(NumberIsTooLargeException.class);
                              int dim = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
                              new OpenMapRealMatrix(dim, dim);
                              
                              // Test case where product exceeds Integer.MAX_VALUE
                              thrown.expect(NumberIsTooLargeException.class);
                              new OpenMapRealMatrix(Integer.MAX_VALUE, Integer.MAX_VALUE);
                              
                              // Test case with one very large dimension
                              thrown.expect(NumberIsTooLargeException.class);
                              new OpenMapRealMatrix(1, Integer.MAX_VALUE);
                          }

 @Test
                          public void testConstructor_EntriesInitialization() {
                              OpenMapRealMatrix matrix = new OpenMapRealMatrix(5, 5);
                              
                              // Verify entries map is initialized properly
                              // Since we can't directly access private field, we'll test through behavior
                              for (int i = 0; i < 5; i++) {
                                  for (int j = 0; j < 5; j++) {
                                      assertEquals(0.0, matrix.getEntry(i, j), 0.0);
                                  }
                              }
                          }

 @Test
                          public void testConstructor_CopiesDimensionsCorrectly() {
                              // Arrange
                              OpenMapRealMatrix original = new OpenMapRealMatrix(3, 4);
                              
                              // Act
                              OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                              
                              // Assert
                              assertEquals(3, copy.getRowDimension());
                              assertEquals(4, copy.getColumnDimension());
                          }

 @Test
                          public void testConstructor_CreatesDeepCopyOfEntries() {
                              // Arrange
                              OpenMapRealMatrix original = new OpenMapRealMatrix(2, 2);
                              original.setEntry(0, 0, 1.5);
                              original.setEntry(1, 1, 2.5);
                              
                              // Act
                              OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                              
                              // Assert - verify values are copied
                              assertEquals(1.5, copy.getEntry(0, 0), 0.0001);
                              assertEquals(2.5, copy.getEntry(1, 1), 0.0001);
                              
                              // Modify original and verify copy is unaffected
                              original.setEntry(0, 0, 3.0);
                              assertEquals(1.5, copy.getEntry(0, 0), 0.0001);
                          }

 @Test
                          public void testConstructor_HandlesEmptyMatrix() {
                              // Arrange
                              OpenMapRealMatrix original = new OpenMapRealMatrix(0, 0);
                              
                              // Act
                              OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                              
                              // Assert
                              assertEquals(0, copy.getRowDimension());
                              assertEquals(0, copy.getColumnDimension());
                          }

 @Test
                          public void testConstructor_HandlesSparseMatrix() {
                              // Arrange
                              OpenMapRealMatrix original = new OpenMapRealMatrix(5, 5);
                              original.setEntry(4, 4, 10.0); // Only one non-zero entry
                              
                              // Act
                              OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                              
                              // Assert
                              assertEquals(10.0, copy.getEntry(4, 4), 0.0001);
                              assertEquals(0.0, copy.getEntry(0, 0), 0.0001); // Default value
                          }

 @Test
                          public void testConstructor_ThrowsForNullInput() {
                              // Arrange
                              thrown.expect(NullPointerException.class);
                              thrown.expectMessage("matrix must not be null");
                              
                              // Act & Assert
                              new OpenMapRealMatrix(null);
                          }

 @Test
                          public void testConstructor_CopiesAllEntriesCorrectly() {
                              // Arrange
                              OpenMapRealMatrix original = new OpenMapRealMatrix(3, 3);
                              original.setEntry(0, 0, 1.0);
                              original.setEntry(0, 1, 2.0);
                              original.setEntry(0, 2, 3.0);
                              original.setEntry(1, 0, 4.0);
                              original.setEntry(1, 1, 5.0);
                              original.setEntry(1, 2, 6.0);
                              original.setEntry(2, 0, 7.0);
                              original.setEntry(2, 1, 8.0);
                              original.setEntry(2, 2, 9.0);
                              
                              // Act
                              OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                              
                              // Assert
                              for (int i = 0; i < 3; i++) {
                                  for (int j = 0; j < 3; j++) {
                                      assertEquals(original.getEntry(i, j), copy.getEntry(i, j), 0.0001);
                                  }
                              }
                          }

 @Test
              public void testConstructor_WithMockedEntries() {
                  // Arrange
                  OpenMapRealMatrix original = mock(OpenMapRealMatrix.class);
                  OpenIntToDoubleHashMap mockEntries = mock(OpenIntToDoubleHashMap.class);
                  
                  when(original.getRowDimension()).thenReturn(2);
                  when(original.getColumnDimension()).thenReturn(2);
                  
                  // Use reflection to set the private entries field
                  try {
                      Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                      entriesField.setAccessible(true);
                      entriesField.set(original, mockEntries);
                  } catch (Exception e) {
                      fail("Failed to set private entries field via reflection");
                  }
                  
                  // Act
                  OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                  
                  // Assert
                  assertEquals(2, copy.getRowDimension());
                  assertEquals(2, copy.getColumnDimension());
                  // Verify entries were copied by checking if a new map was created
                  // (we can't verify the exact contents since it's private)
              }

 @Test
             public void testConstructorWithLargeDimensions() {
                 // These values are chosen so that:
                 // - As ints: 46341 * 46341 = Integer.MAX_VALUE + 1 (overflow)
                 // - As longs: 46341L * 46341L = 2147488281 (valid)
                 int largeDimension = 46341;
                 
                 // Original code would accept this (proper long conversion)
                 // Mutant would throw exception (integer overflow occurs first)
                 try {
                     OpenMapRealMatrix matrix = new OpenMapRealMatrix(largeDimension, largeDimension);
                     // If we get here, the test passes (original behavior)
                     assertEquals(largeDimension, matrix.getRowDimension());
                     assertEquals(largeDimension, matrix.getColumnDimension());
                 } catch (NumberIsTooLargeException e) {
                     // If we get here, the mutant was detected
                     fail("Mutant detected: Integer overflow occurred due to missing long cast");
                 }
             }

 @Test
             public void testConstructorWithDimensionsExceedingMaxValue() {
                 // These values will exceed Integer.MAX_VALUE even when properly cast to long
                 int veryLargeDimension = 46342;
                 
                 thrown.expect(NumberIsTooLargeException.class);
                 new OpenMapRealMatrix(veryLargeDimension, veryLargeDimension);
             }

 @Test
             public void testConstructorWithLargeDimensions1() {
                 // Test the main constructor with dimensions that would trigger the conversion issue
                 try {
                     // This should work fine with proper long conversion
                     OpenMapRealMatrix matrix = new OpenMapRealMatrix(Integer.MAX_VALUE / 2, Integer.MAX_VALUE / 2);
                     
                     // Now test the copy constructor with this matrix
                     OpenMapRealMatrix copy = new OpenMapRealMatrix(matrix);
                     
                     // Verify dimensions were copied correctly
                     assertEquals(Integer.MAX_VALUE / 2, copy.getRowDimension());
                     assertEquals(Integer.MAX_VALUE / 2, copy.getColumnDimension());
                 } catch (NumberIsTooLargeException e) {
                     fail("Should not throw exception for these dimensions");
                 }
                 
                 // Test edge case where dimensions would exceed Integer.MAX_VALUE when multiplied
                 try {
                     new OpenMapRealMatrix(Integer.MAX_VALUE, Integer.MAX_VALUE);
                     fail("Should have thrown NumberIsTooLargeException");
                 } catch (NumberIsTooLargeException expected) {
                     // Expected behavior
                 }
             }

 @Test
             public void testCopyConstructorWithMaxDimensions() {
                 // Create a matrix with max dimensions (just below the overflow threshold)
                 int maxSafeDim = (int) Math.sqrt(Integer.MAX_VALUE);
                 OpenMapRealMatrix original = new OpenMapRealMatrix(maxSafeDim, maxSafeDim);
                 
                 // Test the copy constructor
                 OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                 
                 // Verify all properties were copied correctly
                 assertEquals(original.getRowDimension(), copy.getRowDimension());
                 assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                 // Add more assertions if needed for entries
             }

 @Test
            public void testConstructorWithDifferentDimensions() {
                // Test case where row*col would exceed MAX_VALUE but col*col wouldn't
                // This should throw exception in original code but pass in mutated code
                int largeValue = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                int rows = largeValue;
                int cols = largeValue - 1; // Makes rows*cols > MAX_VALUE but cols*cols might not
                
                thrown.expect(NumberIsTooLargeException.class);
                new OpenMapRealMatrix(rows, cols);
            }

 @Test
            public void testConstructorWithValidDifferentDimensions() {
                // Test case with different dimensions that should pass validation
                int rows = 10;
                int cols = 20;
                
                OpenMapRealMatrix matrix = new OpenMapRealMatrix(rows, cols);
                assertEquals(rows, matrix.getRowDimension());
                assertEquals(cols, matrix.getColumnDimension());
            }

 @Test
            public void testConstructorWithSquareDimensionsNearLimit() {
                // Test case with square dimensions near the limit
                int size = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
                
                OpenMapRealMatrix matrix = new OpenMapRealMatrix(size, size);
                assertEquals(size, matrix.getRowDimension());
                assertEquals(size, matrix.getColumnDimension());
            }

 @Test
            public void testConstructorWithDifferentDimensions1() {
                // Test with dimensions where row != column to catch the mutant
                int rows = 50000;
                int columns = 50000;
                
                // This should work since 50000*50000 < Integer.MAX_VALUE
                OpenMapRealMatrix validMatrix = new OpenMapRealMatrix(rows, columns);
                
                // Now test edge case where dimensions are different
                // The mutant would fail this check if it used columnDimension for both
                int largeRows = 50000;
                int smallColumns = 1;
                OpenMapRealMatrix differentDimsMatrix = new OpenMapRealMatrix(largeRows, smallColumns);
                
                assertEquals(largeRows, differentDimsMatrix.getRowDimension());
                assertEquals(smallColumns, differentDimsMatrix.getColumnDimension());
            }

 @Test(expected = NumberIsTooLargeException.class)
            public void testConstructorWithTooLargeDimensions() {
                // Test with dimensions that would overflow if validation is incorrect
                // Using different row/column dimensions to catch the mutant
                int largeRows = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                int largeColumns = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                
                // This should throw NumberIsTooLargeException
                new OpenMapRealMatrix(largeRows, largeColumns);
            }

 @Test
            public void testCopyConstructorWithDifferentDimensions() {
                // Create original matrix with different row/column dimensions
                int rows = 10;
                int columns = 20;
                OpenMapRealMatrix original = new OpenMapRealMatrix(rows, columns);
                
                // Test copy constructor
                OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                
                assertEquals(rows, copy.getRowDimension());
                assertEquals(columns, copy.getColumnDimension());
                assertEquals(0.0, copy.getEntry(0, 0), 0.0001); // Verify default value
            }

 @Test
           public void testConstructorWithLargeDimensions2() {
               // These values are chosen so that:
               // - As ints: 46342 * 46342 = overflow (would be negative)
               // - As longs: 46342L * 46342L = 2147484964 (valid, < Integer.MAX_VALUE)
               int largeDim = 46342;
               
               // Original behavior: should work fine (converts to long first)
               // Mutated behavior: would overflow during multiplication
               thrown.expect(NumberIsTooLargeException.class);
               new OpenMapRealMatrix(largeDim, largeDim);
               
               // Note: The test expects the exception because the actual product (2147484964)
               // is greater than Integer.MAX_VALUE (2147483647), so both original and mutant
               // should throw. However, the mutant would fail earlier due to overflow.
               // A better test would need to catch the arithmetic exception from overflow,
               // but since we can't modify the constructor, this test demonstrates the issue.
           }

 @Test
           public void testConstructorWithBorderlineDimensions() {
               // These values are chosen so that:
               // - As ints: 46341 * 46341 = 2147390281 (valid)
               // - As longs: same value
               int safeDim = 46341;
               
               // Both original and mutant should work
               OpenMapRealMatrix matrix = new OpenMapRealMatrix(safeDim, safeDim);
               assertEquals(safeDim, matrix.getRowDimension());
               assertEquals(safeDim, matrix.getColumnDimension());
           }

 @Test(expected = NumberIsTooLargeException.class)
           public void testConstructorOverflowDetection() {
               // These dimensions will overflow when multiplied as ints (46341*46341 > Integer.MAX_VALUE)
               // but would be properly detected when cast to long first
               int largeDim = 46341;
               
               // This should throw NumberIsTooLargeException in original code
               // The mutant without casting would fail to detect the overflow
               new OpenMapRealMatrix(largeDim, largeDim);
           }

 @Test
           public void testCopyConstructorWithValidMatrix() {
               // First create a valid matrix
               int rows = 10;
               int cols = 10;
               OpenMapRealMatrix original = new OpenMapRealMatrix(rows, cols);
               
               // Set some values
               original.setEntry(0, 0, 1.0);
               original.setEntry(5, 5, 2.0);
               
               // Test the copy constructor
               OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
               
               assertEquals(rows, copy.getRowDimension());
               assertEquals(cols, copy.getColumnDimension());
               assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
               assertEquals(2.0, copy.getEntry(5, 5), 0.0001);
           }

 @Test
          public void testConstructorWithDifferentDimensions_ShouldThrowWhenRowTimesColumnExceedsMaxValue() {
              // This test will catch the mutant because:
              // Original: 46341 * 46341 would throw (exceeds MAX_VALUE)
              // Mutant: 46341 * 1 wouldn't throw (but should)
              thrown.expect(NumberIsTooLargeException.class);
              new OpenMapRealMatrix(46341, 1);
          }

 @Test
          public void testConstructorWithDifferentDimensions_ShouldNotThrowWhenValid() {
              // This test ensures normal case works
              // 30000 x 70000 would be invalid (exceeds MAX_VALUE)
              // but 30000 x 700 is valid
              new OpenMapRealMatrix(30000, 700);
          }

 @Test
          public void testConstructorWithSquareMatrixNearLimit_ShouldThrowWhenExceedsMaxValue() {
              // Additional test for square matrices near limit
              thrown.expect(NumberIsTooLargeException.class);
              new OpenMapRealMatrix(46341, 46341);
          }

 @Test
          public void testConstructorWithDifferentDimensions_ShouldThrowWhenColumnVeryLarge() {
              // Another test case where columns are much larger than rows
              thrown.expect(NumberIsTooLargeException.class);
              new OpenMapRealMatrix(1, Integer.MAX_VALUE);
          }

 @Test
          public void testConstructorDimensionValidation() {
              // Test case where row and column dimensions are different
              // and their product is close to Integer.MAX_VALUE
              
              // This should pass as the product is valid
              new OpenMapRealMatrix(46340, 46340);
              
              // This should throw exception as product exceeds Integer.MAX_VALUE
              thrown.expect(NumberIsTooLargeException.class);
              new OpenMapRealMatrix(46341, 46341);
              
              // Test case that would catch the mutant - different row/column dimensions
              // where only one dimension is large enough to trigger the exception
              thrown.expect(NumberIsTooLargeException.class);
              // With the mutant, this might not throw exception because it would use rowDimension twice
              new OpenMapRealMatrix(1, Integer.MAX_VALUE);
          }

 @Test
          public void testCopyConstructorWithDifferentDimensions1() {
              // Create original matrix with different row/column dimensions
              OpenMapRealMatrix original = new OpenMapRealMatrix(3, 5);
              
              // Test copy constructor
              OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
              
              // Verify dimensions are copied correctly
              assertEquals(original.getRowDimension(), copy.getRowDimension());
              assertEquals(original.getColumnDimension(), copy.getColumnDimension());
              // This would fail if the mutant affected the copy constructor
              assertNotEquals(copy.getRowDimension(), copy.getColumnDimension());
          }

 @Test
         public void testConstructorWithMaxValueProduct() {
             // Find dimensions that multiply to exactly Integer.MAX_VALUE
             // Using prime factors of Integer.MAX_VALUE (which is 2^31-1, a Mersenne prime)
             // So we'll use 1 and Integer.MAX_VALUE as dimensions
             int rows = 1;
             int columns = Integer.MAX_VALUE;
             
             // Expect exception for original code
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage(Integer.MAX_VALUE + "");
             
             // This should throw in original but pass in mutant
             new OpenMapRealMatrix(rows, columns);
         }

 @Test
         public void testConstructorWithProductLargerThanMaxValue() {
             // Use dimensions that multiply to MAX_VALUE + 1
             int rows = 2;
             int columns = (Integer.MAX_VALUE / 2) + 1;
             
             // Both original and mutant should throw
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage((long)rows * columns + "");
             
             new OpenMapRealMatrix(rows, columns);
         }

 @Test
         public void testConstructorWithProductLessThanMaxValue() {
             // Use normal dimensions
             int rows = 100;
             int columns = 100;
             
             // Should work in both original and mutant
             OpenMapRealMatrix matrix = new OpenMapRealMatrix(rows, columns);
             assertEquals(rows, matrix.getRowDimension());
             assertEquals(columns, matrix.getColumnDimension());
         }

 @Test
         public void testConstructorWithMaxValueDimensions() {
             // Find dimensions that multiply to exactly Integer.MAX_VALUE
             // Using 1 and Integer.MAX_VALUE since 1 * MAX_VALUE = MAX_VALUE
             int rows = 1;
             int columns = Integer.MAX_VALUE;
             
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage(Integer.toString(Integer.MAX_VALUE));
             
             // This should throw in original code but pass in mutant
             new OpenMapRealMatrix(rows, columns);
         }

 @Test
         public void testConstructorWithJustBelowMaxValueDimensions() {
             // Test case where product is MAX_VALUE - 1
             // Should pass in both original and mutant
             int rows = 1;
             int columns = Integer.MAX_VALUE - 1;
             
             // No exception expected
             new OpenMapRealMatrix(rows, columns);
         }

 @Test
         public void testConstructorWithJustAboveMaxValueDimensions() {
             // Test case where product is MAX_VALUE + 1
             // Should throw in both original and mutant
             int rows = 2;
             int columns = Integer.MAX_VALUE / 2 + 1;
             
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage(Integer.toString(Integer.MAX_VALUE));
             
             new OpenMapRealMatrix(rows, columns);
         }

 @Test
        public void testConstructorThrowsWhenMatrixTooLarge() {
            // Choose dimensions where:
            // rows * columns > Integer.MAX_VALUE (should throw)
            // but rows + columns < Integer.MAX_VALUE (mutant would allow)
            int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
            
            thrown.expect(NumberIsTooLargeException.class);
            thrown.expectMessage("larger than");
            
            // This should throw in original code but would pass in mutant
            new OpenMapRealMatrix(largeDim, largeDim);
        }

 @Test
        public void testConstructorAllowsValidDimensions() {
            // Test with dimensions that should always be valid
            int validDim = 100;
            OpenMapRealMatrix matrix = new OpenMapRealMatrix(validDim, validDim);
            
            assertEquals(validDim, matrix.getRowDimension());
            assertEquals(validDim, matrix.getColumnDimension());
        }

 @Test
        public void testConstructorWithMaxValidDimensions() {
            // Test with largest possible dimensions where product < MAX_VALUE
            int maxDim = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
            OpenMapRealMatrix matrix = new OpenMapRealMatrix(maxDim, maxDim);
            
            assertEquals(maxDim, matrix.getRowDimension());
            assertEquals(maxDim, matrix.getColumnDimension());
        }

 @Test
        public void testConstructorThrowsWhenTotalElementsExceedsMaxValue() {
            // This test will catch the mutant because:
            // - rows + columns = 65536 + 65536 = 131072 (which is < Integer.MAX_VALUE)
            // - rows * columns = 65536 * 65536 = 2^32 = 4294967296 (which is > Integer.MAX_VALUE)
            // Original code would throw, mutant would not
            
            thrown.expect(NumberIsTooLargeException.class);
            thrown.expectMessage("4294967296");
            
            int largeSize = 65536; // 2^16
            new OpenMapRealMatrix(largeSize, largeSize);
        }

 @Test
        public void testConstructorAcceptsValidDimensions() {
            // Normal case that should work in both original and mutant
            int validSize = 1000;
            OpenMapRealMatrix matrix = new OpenMapRealMatrix(validSize, validSize);
            
            assertEquals(validSize, matrix.getRowDimension());
            assertEquals(validSize, matrix.getColumnDimension());
        }

 @Test
        public void testConstructorWithMatrixParameter() {
            // Test the copy constructor works correctly
            OpenMapRealMatrix original = new OpenMapRealMatrix(10, 10);
            original.setEntry(0, 0, 5.0);
            
            OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
            
            assertEquals(10, copy.getRowDimension());
            assertEquals(10, copy.getColumnDimension());
            assertEquals(5.0, copy.getEntry(0, 0), 0.0001);
        }

 @Test
       public void testConstructorWithBorderlineDimensions1() {
           // These dimensions will overflow when multiplied as integers
           // but would be valid when using long arithmetic
           int rows = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
           int cols = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
           
           // Original code (with long cast) should throw exception
           // Mutant (without long cast) would pass due to integer overflow
           thrown.expect(NumberIsTooLargeException.class);
           thrown.expectMessage(Long.toString((long)rows * (long)cols));
           
           new OpenMapRealMatrix(rows, cols);
       }

 @Test
       public void testConstructorWithMaxDimensions() {
           // Test with dimensions that would exactly reach MAX_VALUE
           int rows = 46340;  // sqrt(Integer.MAX_VALUE)
           int cols = 46341;  // Just over the limit when multiplied
           
           thrown.expect(NumberIsTooLargeException.class);
           new OpenMapRealMatrix(rows, cols);
       }

 @Test
       public void testConstructorWithLargeDimensions3() {
           // These dimensions will cause integer overflow when multiplied
           int rows = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
           int cols = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
           
           // Original code would throw NumberIsTooLargeException because:
           // (long)rows * (long)cols > Integer.MAX_VALUE
           // Mutated code would not throw because:
           // rows * cols (integer multiplication) would overflow to negative
           
           thrown.expect(NumberIsTooLargeException.class);
           new OpenMapRealMatrix(rows, cols);
       }

 @Test
       public void testCopyConstructor() {
           // Test normal copy constructor works
           OpenMapRealMatrix original = new OpenMapRealMatrix(2, 2);
           original.setEntry(0, 0, 1.0);
           OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
           
           assertEquals(original.getRowDimension(), copy.getRowDimension());
           assertEquals(original.getColumnDimension(), copy.getColumnDimension());
           assertEquals(original.getEntry(0, 0), copy.getEntry(0, 0), 0.0001);
       }

 @Test
      public void testConstructorThrowsWhenMatrixTooLarge1() {
          // Choose dimensions where product exceeds MAX_VALUE but sum doesn't
          // Using MAX_VALUE/2 + 1 for rows and 2 for columns:
          // (MAX_VALUE/2 + 1) * 2 = MAX_VALUE + 2 > MAX_VALUE
          // (MAX_VALUE/2 + 1) + 2 ≈ MAX_VALUE/2 + 3 < MAX_VALUE
          
          int largeRows = Integer.MAX_VALUE / 2 + 1;
          int columns = 2;
          
          thrown.expect(NumberIsTooLargeException.class);
          thrown.expectMessage(largeRows * (long)columns + " >= " + Integer.MAX_VALUE);
          
          // This should throw in original code but not in mutant
          new OpenMapRealMatrix(largeRows, columns);
      }

 @Test
      public void testConstructorWithLargeDimensionsShouldThrowException() {
          // These dimensions are chosen because:
          // 46341 * 46341 = 2,147,488,281 which is > Integer.MAX_VALUE (2,147,483,647)
          // 46341 + 46341 = 92,682 which is << Integer.MAX_VALUE
          int largeDimension = 46341;
          
          thrown.expect(NumberIsTooLargeException.class);
          thrown.expectMessage("2,147,488,281");
          
          // This should throw in original code but pass in mutant
          new OpenMapRealMatrix(largeDimension, largeDimension);
      }

 @Test
      public void testConstructorWithValidDimensionsShouldNotThrow() {
          // These dimensions are valid because:
          // 46340 * 46340 = 2,147,395,600 which is < Integer.MAX_VALUE
          // and also 46340 + 46340 is obviously valid
          int validLargeDimension = 46340;
          
          // Should not throw exception in either original or mutant
          new OpenMapRealMatrix(validLargeDimension, validLargeDimension);
      }

 @Test
     public void testConstructorThrowsWhenSizeEqualsMaxValue() {
         // Calculate dimensions that will make row*col = Integer.MAX_VALUE
         // Using prime factors of MAX_VALUE (which is 2^31-1, a prime number)
         // So we'll use 1 and MAX_VALUE as dimensions
         int rows = 1;
         int cols = Integer.MAX_VALUE;
         
         // Expect exception to be thrown
         thrown.expect(NumberIsTooLargeException.class);
         thrown.expectMessage(Integer.toString(Integer.MAX_VALUE));
         // Verify the bound is exclusive (third parameter false)
         thrown.expect(new org.hamcrest.TypeSafeMatcher<NumberIsTooLargeException>() {
             @Override
             protected boolean matchesSafely(NumberIsTooLargeException e) {
                 return !e.getBoundIsAllowed(); // Should be false in original
             }
             
             @Override
             public void describeTo(org.hamcrest.Description description) {
                 description.appendText("Expected bound to be exclusive (false)");
             }
         });
         
         // This should throw in original, but not in mutant
         new OpenMapRealMatrix(rows, cols);
     }

 @Test
     public void testConstructorWithMaxDimensions1() {
         // Test with dimensions where product equals Integer.MAX_VALUE
         // This should throw in original code but not in mutant
         int max = Integer.MAX_VALUE;
         int rows = 1;
         int columns = max;
         
         thrown.expect(NumberIsTooLargeException.class);
         thrown.expectMessage("1 * " + max + " >= " + max);
         
         // This will throw in original code but not in mutant
         new OpenMapRealMatrix(rows, columns);
     }

 @Test
     public void testConstructorWithExceedingDimensions() {
         // Test with dimensions where product exceeds Integer.MAX_VALUE
         // Both original and mutant should throw
         int max = Integer.MAX_VALUE;
         int rows = 2;
         int columns = max;
         
         thrown.expect(NumberIsTooLargeException.class);
         thrown.expectMessage("2 * " + max + " >= " + max);
         
         new OpenMapRealMatrix(rows, columns);
     }

}
