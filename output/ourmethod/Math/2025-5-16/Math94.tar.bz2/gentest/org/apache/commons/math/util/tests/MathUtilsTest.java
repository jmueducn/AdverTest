package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

       @Test
                                        public void testGcd_ZeroCases() {
                                            assertEquals(5, MathUtils.gcd(0, 5));
                                            assertEquals(5, MathUtils.gcd(5, 0));
                                            assertEquals(0, MathUtils.gcd(0, 0));
                                            assertEquals(10, MathUtils.gcd(-10, 0));
                                            assertEquals(10, MathUtils.gcd(0, -10));
                                        }

 @Test
                                        public void testGcd_PositiveNumbers() {
                                            assertEquals(1, MathUtils.gcd(1, 1));
                                            assertEquals(2, MathUtils.gcd(2, 4));
                                            assertEquals(6, MathUtils.gcd(12, 18));
                                            assertEquals(14, MathUtils.gcd(42, 56));
                                            assertEquals(1, MathUtils.gcd(13, 17)); // primes
                                        }

 @Test
                                        public void testGcd_NegativeNumbers() {
                                            assertEquals(5, MathUtils.gcd(-5, -10));
                                            assertEquals(3, MathUtils.gcd(-9, 6));
                                            assertEquals(4, MathUtils.gcd(8, -12));
                                            assertEquals(7, MathUtils.gcd(-14, -21));
                                        }

 @Test
                                        public void testGcd_EqualNumbers() {
                                            assertEquals(7, MathUtils.gcd(7, 7));
                                            assertEquals(5, MathUtils.gcd(-5, -5));
                                            assertEquals(1, MathUtils.gcd(1, 1));
                                        }

 @Test
                                        public void testGcd_OneIsMultipleOfOther() {
                                            assertEquals(3, MathUtils.gcd(3, 9));
                                            assertEquals(4, MathUtils.gcd(16, 4));
                                            assertEquals(5, MathUtils.gcd(25, 5));
                                        }

 @Test
                                        public void testGcd_LargeNumbers() {
                                            assertEquals(1000, MathUtils.gcd(1000, 1000));
                                            assertEquals(100, MathUtils.gcd(10000, 9900));
                                            assertEquals(1, MathUtils.gcd(1234567, 7654321));
                                        }

 @Test
                                        public void testGcd_EdgeCases() {
                                            // Integer boundary cases
                                            assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE - 1));
                                            assertEquals(1, MathUtils.gcd(Integer.MIN_VALUE + 1, Integer.MAX_VALUE));
                                            assertEquals(2, MathUtils.gcd(Integer.MIN_VALUE + 2, Integer.MAX_VALUE - 1));
                                        }

 @Test
                                        public void testGcd_OverflowCase() {
                                            thrown.expect(ArithmeticException.class);
                                            thrown.expectMessage("overflow: gcd is 2^31");
                                            MathUtils.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE);
                                        }

 @Test
                                        public void testGcd_OneIsPowerOfTwo() {
                                            assertEquals(1, MathUtils.gcd(1, 1024));
                                            assertEquals(2, MathUtils.gcd(2, 1024));
                                            assertEquals(4, MathUtils.gcd(4, 1024));
                                            assertEquals(8, MathUtils.gcd(8, 1024));
                                            assertEquals(16, MathUtils.gcd(16, 1024));
                                        }

 @Test
                                        public void testGcd_CoPrimeNumbers() {
                                            assertEquals(1, MathUtils.gcd(8, 15));
                                            assertEquals(1, MathUtils.gcd(14, 25));
                                            assertEquals(1, MathUtils.gcd(21, 40));
                                        }

 @Test
                                        public void testGcd_EvenAndOddNumbers() {
                                            assertEquals(1, MathUtils.gcd(2, 3));
                                            assertEquals(1, MathUtils.gcd(4, 5));
                                            assertEquals(3, MathUtils.gcd(6, 9));
                                        }

 @Test
                                    public void testFactorialLogWithNegativeInput() {
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("must have n > 0 for n!");
                                        MathUtils.factorialLog(-1);
                                    }

 @Test
                                    public void testFactorialLogWithZeroInput() {
                                        // This test will detect the mutant
                                        // Original behavior: returns 0.0 for n=0
                                        // Mutated behavior: throws exception
                                        double result = MathUtils.factorialLog(0);
                                        assertEquals(0.0, result, 0.0001);
                                    }

 @Test
                                    public void testFactorialLogWithPositiveInput() {
                                        // Test normal case to ensure other functionality remains correct
                                        double result = MathUtils.factorialLog(5);
                                        double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                                        assertEquals(expected, result, 0.0001);
                                    }

 @Test
                              public void testFactorialLogNegativeInput() {
                                  // Set up the expected exception
                                  ExpectedException exceptionRule = ExpectedException.none();
                                  exceptionRule.expect(IllegalArgumentException.class);
                                  exceptionRule.expectMessage("must have n > 0 for n!");
                                  
                                  // Call the method with negative input to trigger the exception
                                  MathUtils.factorialLog(-1);
                              }

 @Test
                              public void testFactorialLogDetectsInitializationMutant() {
                                  // Test n=0 (edge case)
                                  assertEquals(0.0, MathUtils.factorialLog(0), 0.0001);
                                  
                                  // Test n=1 (should return 0 as log(1) is 0 and we don't enter loop)
                                  assertEquals(0.0, MathUtils.factorialLog(1), 0.0001);
                                  
                                  // Test n=2 (should return log(2), mutant would return 1+log(2))
                                  double expected = Math.log(2);
                                  assertEquals(expected, MathUtils.factorialLog(2), 0.0001);
                                  
                                  // Test n=3 (should return log(2)+log(3), mutant would return 1+log(2)+log(3))
                                  expected = Math.log(2) + Math.log(3);
                                  assertEquals(expected, MathUtils.factorialLog(3), 0.0001);
                              }

 @Test(expected = IllegalArgumentException.class)
                              public void testFactorialLogNegativeInput1() {
                                  MathUtils.factorialLog(-1);
                              }

 @Test
                             public void testFactorialLogDetectsMutant() {
                                 // Test n=1 case where original and mutant have different iteration counts
                                 // Original: no iterations (i starts at 2, condition fails immediately)
                                 // Mutant: one iteration (i starts at 1, runs once)
                                 double result = MathUtils.factorialLog(1);
                                 assertEquals(0.0, result, 0.0);  // Both versions return same value
                                 
                                 // More thorough test - verify computation path by checking intermediate values
                                 // For n=2, original computes log(2)
                                 // Mutant computes log(1) + log(2) (same result but different path)
                                 // We can verify the computation path by checking the number of Math.log calls
                                 // However, since we can't intercept Math.log calls in this test,
                                 // we'll verify the behavior with n=1 where the difference is most apparent
                                 
                                 // Additional test cases to ensure full coverage
                                 assertEquals(0.0, MathUtils.factorialLog(0), 0.0);
                                 assertEquals(Math.log(2), MathUtils.factorialLog(2), 1e-10);
                                 assertEquals(Math.log(2) + Math.log(3), MathUtils.factorialLog(3), 1e-10);
                             }

 @Test(expected = IllegalArgumentException.class)
                             public void testFactorialLogNegativeInput2() {
                                 MathUtils.factorialLog(-1);
                             }

 @Test
                            public void testFactorialLogDetectsMultiplicationMutant() {
                                // Test with n=3 since it's the smallest case where the mutation produces different results
                                int n = 3;
                                
                                // Expected value is sum of logs: log(2) + log(3)
                                double expected = Math.log(2) + Math.log(3);
                                
                                // Actual value from the method
                                double actual = MathUtils.factorialLog(n);
                                
                                // Verify the result matches expected sum (not product) of logs
                                assertEquals("Factorial log should sum logs, not multiply them", 
                                             expected, actual, 1e-10);
                            }

 @Test(expected = IllegalArgumentException.class)
                            public void testFactorialLogNegativeInput3() {
                                MathUtils.factorialLog(-1);
                            }

 @Test
                            public void testFactorialLogEdgeCases() {
                                // Test n=0 (should return 0 since log(1)=0)
                                assertEquals(0.0, MathUtils.factorialLog(0), 1e-10);
                                
                                // Test n=1 (should return 0 since log(1)=0)
                                assertEquals(0.0, MathUtils.factorialLog(1), 1e-10);
                                
                                // Test n=2 (should return log(2))
                                assertEquals(Math.log(2), MathUtils.factorialLog(2), 1e-10);
                            }

 @Test(expected = IllegalArgumentException.class)
                           public void testFactorialLogNegative() {
                               MathUtils.factorialLog(-1);
                           }

 @Test
                      public void testFactorialLogZero() {
                          final double DELTA = 1e-15;
                          assertEquals(0.0, MathUtils.factorialLog(0), DELTA);
                      }

 @Test
                      public void testFactorialLogOne() {
                          final double DELTA = 1e-15;
                          assertEquals(0.0, MathUtils.factorialLog(1), DELTA);
                      }

 @Test
                      public void testFactorialLogTwo() {
                          // log(2) ≈ 0.6931471805599453
                          final double DELTA = 1e-15;
                          assertEquals(Math.log(2), MathUtils.factorialLog(2), DELTA);
                      }

 @Test
                      public void testFactorialLogFive() {
                          // log(2) + log(3) + log(4) + log(5) ≈ 4.787491742782046
                          double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                          double delta = 1e-15; // tolerance for double comparison
                          assertEquals(expected, MathUtils.factorialLog(5), delta);
                      }

 @Test
                      public void testFactorialLogBoundary() {
                          // Test with a larger number to ensure loop runs correctly
                          int n = 10;
                          double expected = 0.0;
                          for (int i = 2; i <= n; i++) {
                              expected += Math.log(i);
                          }
                          double delta = 1E-15; // Define delta for floating-point comparison
                          assertEquals(expected, MathUtils.factorialLog(n), delta);
                      }

 @Test(expected = IllegalArgumentException.class)
                      public void testFactorialLogNegative1() {
                          MathUtils.factorialLog(-1);
                      }

 @Test
                      public void testFactorialLogZero1() {
                          assertEquals(0.0, MathUtils.factorialLog(0), 1e-10);
                      }

 @Test
                      public void testFactorialLogOne1() {
                          assertEquals(0.0, MathUtils.factorialLog(1), 1e-10);
                      }

 @Test
                      public void testFactorialLogTwo1() {
                          assertEquals(Math.log(2), MathUtils.factorialLog(2), 1e-10);
                      }

 @Test
                      public void testFactorialLogFive1() {
                          double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                          assertEquals(expected, MathUtils.factorialLog(5), 1e-10);
                      }

 @Test(expected = IllegalArgumentException.class)
                     public void testFactorialLogNegativeInput4() {
                         MathUtils.factorialLog(-1);
                     }

 @Test
                     public void testFactorialLogZero2() {
                         assertEquals(0.0, MathUtils.factorialLog(0), MathUtils.EPSILON);
                     }

 @Test
                     public void testFactorialLogOne2() {
                         assertEquals(0.0, MathUtils.factorialLog(1), MathUtils.EPSILON);
                     }

 @Test
                     public void testFactorialLogTwo2() {
                         assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
                     }

 @Test
                     public void testFactorialLogFive2() {
                         double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                         assertEquals(expected, MathUtils.factorialLog(5), MathUtils.EPSILON);
                     }

 @Test
                     public void testFactorialLogBoundaryCondition() {
                         double expected = Math.log(2) + Math.log(3);
                         assertEquals(expected, MathUtils.factorialLog(3), MathUtils.EPSILON);
                     }

 @Test
               public void testFactorialLogIterationCount() throws Exception {
                   // Get MathUtils instance using reflection since constructor is private
                   Constructor<MathUtils> constructor = MathUtils.class.getDeclaredConstructor();
                   constructor.setAccessible(true);
                   MathUtils mathUtils = constructor.newInstance();
                   
                   // Test with n=2
                   double result = mathUtils.factorialLog(2);
                   assertEquals(Math.log(2), result, 0.0001);
                   
                   // Test with n=3
                   result = mathUtils.factorialLog(3);
                   assertEquals(Math.log(2) + Math.log(3), result, 0.0001);
                   
                   // Test with n=5 to verify iteration count
                   result = mathUtils.factorialLog(5);
                   assertEquals(Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5), result, 0.0001);
               }

 @Test(expected = IllegalArgumentException.class)
               public void testFactorialLogNegativeInput5() {
                   MathUtils.factorialLog(-1);
               }

 @Test
               public void testFactorialLogBoundaryCases() {
                   // n=0 should return 0 (no iterations)
                   assertEquals(0, MathUtils.factorialLog(0), 0.0001);
                   
                   // n=1 should return 0 (no iterations)
                   assertEquals(0, MathUtils.factorialLog(1), 0.0001);
               }

 @Test(expected = IllegalArgumentException.class)
               public void testFactorialLogNegative2() {
                   MathUtils.factorialLog(-1);
               }

 @Test
               public void testFactorialLogZero3() {
                   double result = MathUtils.factorialLog(0);
                   assertEquals(0.0, result, 0.0001);
               }

 @Test
               public void testFactorialLogOne3() {
                   double result = MathUtils.factorialLog(1);
                   assertEquals(0.0, result, 0.0001);
               }

 @Test
               public void testFactorialLogTwo3() {
                   double result = MathUtils.factorialLog(2);
                   assertEquals(Math.log(2), result, 0.0001);
               }

 @Test
               public void testFactorialLogFive3() {
                   double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                   double result = MathUtils.factorialLog(5);
                   assertEquals(expected, result, 0.0001);
               }

 @Test
              public void testGcdWithZero() {
                  // Test case to detect u >= 0 vs u > 0 mutation
                  // Original behavior: gcd(0,5) should return 5
                  // Mutated behavior might return different value
                  
                  // Test with zero as first argument
                  assertEquals(5, MathUtils.gcd(0, 5));
                  
                  // Test with zero as second argument
                  assertEquals(5, MathUtils.gcd(5, 0));
                  
                  // Test with both arguments zero
                  assertEquals(0, MathUtils.gcd(0, 0));
                  
                  // Test with one zero and one negative (should use absolute value)
                  assertEquals(5, MathUtils.gcd(0, -5));
                  assertEquals(5, MathUtils.gcd(-5, 0));
              }

 @Test
              public void testGcdWithPositiveNumbers() {
                  // Additional tests to ensure normal gcd still works
                  assertEquals(1, MathUtils.gcd(1, 5));
                  assertEquals(2, MathUtils.gcd(2, 4));
                  assertEquals(6, MathUtils.gcd(12, 18));
              }

 @Test(expected = IllegalArgumentException.class)
             public void testFactorialLogNegativeInput6() {
                 MathUtils.factorialLog(-1);
             }

 @Test
             public void testFactorialLogZeroAndOne() {
                 assertEquals(0.0, MathUtils.factorialLog(0), MathUtils.EPSILON);
                 assertEquals(0.0, MathUtils.factorialLog(1), MathUtils.EPSILON);
             }

 @Test
             public void testFactorialLogSmallValues() {
                 // log(2!) = log(2)
                 assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
                 
                 // log(3!) = log(2) + log(3)
                 assertEquals(Math.log(2) + Math.log(3), MathUtils.factorialLog(3), MathUtils.EPSILON);
                 
                 // log(4!) = log(2) + log(3) + log(4)
                 assertEquals(Math.log(2) + Math.log(3) + Math.log(4), MathUtils.factorialLog(4), MathUtils.EPSILON);
             }

 @Test
             public void testFactorialLogLargerValue() {
                 // Test with n=10
                 double expected = 0.0;
                 for (int i = 2; i <= 10; i++) {
                     expected += Math.log(i);
                 }
                 assertEquals(expected, MathUtils.factorialLog(10), MathUtils.EPSILON);
             }

 @Test
             public void testFactorialLogPrecision() {
                 // Test with a value where numerical precision might be affected
                 // by potential bit-shift operations in called methods
                 int n = 20;
                 double expected = 0.0;
                 for (int i = 2; i <= n; i++) {
                     expected += Math.log(i);
                 }
                 assertEquals(expected, MathUtils.factorialLog(n), MathUtils.EPSILON * expected);
             }

 @Test
        public void testFactorialLogShouldNotCalculateForN() {
            // For n=1, the loop should not execute at all (start from i=2)
            // The mutant would execute once (i=1)
            // While the output is the same, this tests the boundary condition
            double result = MathUtils.factorialLog(1);
            assertEquals(0.0, result, 0.000001);
            
            // Additional test for n=2 to ensure correct calculation
            double result2 = MathUtils.factorialLog(2);
            assertEquals(Math.log(2), result2, 0.000001);
            
            // Test for n=3 to ensure full loop execution
            double result3 = MathUtils.factorialLog(3);
            assertEquals(Math.log(2) + Math.log(3), result3, 0.000001);
            
            // Test negative input
            try {
                MathUtils.factorialLog(-1);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assertEquals("must have n > 0 for n!", e.getMessage());
            }
        }

 @Test
           public void testFactorialLogForNegative() {
               try {
                   MathUtils.factorialLog(-1);
                   fail("Expected IllegalArgumentException");
               } catch (IllegalArgumentException e) {
                   assertEquals("must have n > 0 for n!", e.getMessage());
               }
           }

 @Test
      public void testFactorialLogForZero() {
          final double DELTA = 1e-15; // Define delta for double comparison
          assertEquals(0.0, MathUtils.factorialLog(0), DELTA);
      }

 @Test
      public void testFactorialLogForOne() {
          final double DELTA = 0.0001;
          assertEquals(0.0, MathUtils.factorialLog(1), DELTA);
      }

 @Test
      public void testFactorialLogForTwo() {
          final double DELTA = 1e-15;
          assertEquals(Math.log(2), MathUtils.factorialLog(2), DELTA);
      }

 @Test
      public void testFactorialLogForThree() {
          double expected = Math.log(2) + Math.log(3);
          final double DELTA = 1e-15;
          assertEquals(expected, MathUtils.factorialLog(3), DELTA);
      }

 @Test
      public void testFactorialLogForFive() {
          final double DELTA = 1e-15;
          double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
          assertEquals(expected, MathUtils.factorialLog(5), DELTA);
      }

 @Test(expected = IllegalArgumentException.class)
      public void testFactorialLogNegative3() {
          MathUtils.factorialLog(-1);
      }

 @Test
      public void testFactorialLogZero4() {
          double result = MathUtils.factorialLog(0);
          assertEquals(0.0, result, 0.0001);
      }

 @Test
      public void testFactorialLogOne4() {
          double result = MathUtils.factorialLog(1);
          assertEquals(0.0, result, 0.0001);
      }

 @Test
      public void testFactorialLogTwo4() {
          double result = MathUtils.factorialLog(2);
          assertEquals(Math.log(2), result, 0.0001);
      }

 @Test
      public void testFactorialLogFive4() {
          double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
          double result = MathUtils.factorialLog(5);
          assertEquals(expected, result, 0.0001);
      }

 @Test
 public void testGcdWithNegativeNumbers() {
     // For positive numbers, /=2 and >>=1 behave the same
     assertEquals(6, MathUtils.gcd(12, 18));
     
     // For negative numbers, they differ
     // Original: -12 / 2 = -6 (rounds towards zero)
     // Mutant: -12 >> 1 = -6 (same in this case)
     
     // Test with odd negative number where they differ
     // Original: -13 / 2 = -6.5 -> becomes -6 when cast back to int
     // Mutant: -13 >> 1 = -7 (preserves sign and rounds down)
     // This difference will propagate through the gcd calculation
     assertEquals(1, MathUtils.gcd(-13, 14));
     
     // Another test case where behavior differs
     assertEquals(1, MathUtils.gcd(-999999, 999998));
 }

 @Test
 public void testFactorialLog() {
     // Test with n = 0 (should return 0 since logSum starts at 0 and loop doesn't run)
     assertEquals(0.0, MathUtils.factorialLog(0), MathUtils.EPSILON);
     
     // Test with n = 1 (same as above)
     assertEquals(0.0, MathUtils.factorialLog(1), MathUtils.EPSILON);
     
     // Test with n = 2
     assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
     
     // Test with n = 5
     double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
     assertEquals(expected, MathUtils.factorialLog(5), MathUtils.EPSILON);
     
     // Test negative input
     try {
         MathUtils.factorialLog(-1);
         fail("Expected IllegalArgumentException");
     } catch (IllegalArgumentException e) {
         assertEquals("must have n > 0 for n!", e.getMessage());
     }
 }

}
