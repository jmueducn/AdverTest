package gentest.org.apache.commons.math.stat.descriptive.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.descriptive.rank.Max;
import org.apache.commons.math.stat.descriptive.rank.Min;
import org.apache.commons.math.stat.descriptive.summary.Sum;
import org.apache.commons.math.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.util.FastMath;
 
public class SummaryStatisticsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
              public void testAddValue_UpdatesAllBasicStatistics() {
                  // Create new SummaryStatistics instance
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Add a value
                  stats.addValue(5.0);
                  
                  // Verify basic statistics
                  assertEquals(1L, stats.getN());
                  assertEquals(5.0, stats.getSum(), 0.0001);
                  assertEquals(25.0, stats.getSumsq(), 0.0001);
                  assertEquals(5.0, stats.getMin(), 0.0001);
                  assertEquals(5.0, stats.getMax(), 0.0001);
                  assertEquals(Math.log(5.0), stats.getSumOfLogs(), 0.0001);
              }

    @Test
              public void testAddValue_UpdatesDerivedStatistics() {
                  // Initialize statistics object
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Add multiple values to test derived statistics
                  stats.addValue(2.0);
                  stats.addValue(4.0);
                  stats.addValue(4.0);
                  
                  // Verify derived statistics
                  assertEquals(3L, stats.getN());
                  assertEquals(10.0, stats.getSum(), 0.0001);
                  assertEquals(36.0, stats.getSumsq(), 0.0001);
                  assertEquals(2.0, stats.getMin(), 0.0001);
                  assertEquals(4.0, stats.getMax(), 0.0001);
                  assertEquals(10.0/3.0, stats.getMean(), 0.0001);
                  assertEquals(1.3333, stats.getVariance(), 0.0001);
                  assertEquals(Math.pow(2*4*4, 1.0/3.0), stats.getGeometricMean(), 0.0001);
              }

    @Test
              public void testAddValue_WithOverriddenImplementations() {
                  // Create the stats instance
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Create mock implementations
                  StorelessUnivariateStatistic mockMean = mock(StorelessUnivariateStatistic.class);
                  StorelessUnivariateStatistic mockVariance = mock(StorelessUnivariateStatistic.class);
                  StorelessUnivariateStatistic mockGeoMean = mock(StorelessUnivariateStatistic.class);
                  
                  // Set the mock implementations
                  stats.setMeanImpl(mockMean);
                  stats.setVarianceImpl(mockVariance);
                  stats.setGeoMeanImpl(mockGeoMean);
                  
                  // Add a value
                  stats.addValue(3.5);
                  
                  // Verify the mock implementations were called
                  verify(mockMean).increment(3.5);
                  verify(mockVariance).increment(3.5);
                  verify(mockGeoMean).increment(3.5);
              }

    @Test
              public void testAddValue_WithDefaultImplementations() {
                  // Create instance to test
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Store original implementations
                  StorelessUnivariateStatistic originalMean = stats.getMeanImpl();
                  StorelessUnivariateStatistic originalVariance = stats.getVarianceImpl();
                  StorelessUnivariateStatistic originalGeoMean = stats.getGeoMeanImpl();
                  
                  // Add a value
                  stats.addValue(7.2);
                  
                  // Verify default implementations were not called (since they match the main ones)
                  // We can verify this by checking the counts didn't change for the main implementations
                  assertEquals(7.2, stats.getSum(), 0.0001);
                  assertEquals(1L, stats.getN());
              }

    @Test
              public void testAddValue_WithNaNValue() {
                  // Create new SummaryStatistics instance
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Add NaN value
                  stats.addValue(Double.NaN);
                  
                  // Verify statistics handle NaN appropriately
                  assertEquals(1L, stats.getN());
                  assertTrue(Double.isNaN(stats.getSum()));
                  assertTrue(Double.isNaN(stats.getSumsq()));
                  assertTrue(Double.isNaN(stats.getMin()));
                  assertTrue(Double.isNaN(stats.getMax()));
              }

    @Test
              public void testAddValue_WithInfiniteValues() {
                  // Create new statistics object
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Add positive and negative infinity
                  stats.addValue(Double.POSITIVE_INFINITY);
                  stats.addValue(Double.NEGATIVE_INFINITY);
                  
                  // Verify statistics handle infinity
                  assertEquals(2L, stats.getN());
                  assertTrue(Double.isNaN(stats.getSum())); // Infinity + -Infinity = NaN
                  assertEquals(Double.POSITIVE_INFINITY, stats.getSumsq(), 0.0001);
                  assertEquals(Double.NEGATIVE_INFINITY, stats.getMin(), 0.0001);
                  assertEquals(Double.POSITIVE_INFINITY, stats.getMax(), 0.0001);
              }

    @Test
              public void testAddValue_IncrementsSecondMoment() {
                  // Create new SummaryStatistics instance
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Add values
                  stats.addValue(1.0);
                  stats.addValue(2.0);
                  stats.addValue(3.0);
                  
                  // Verify second moment is calculated
                  assertEquals(2.0, stats.getSecondMoment(), 0.0001); // Variance of 1,2,3 is 2/3, second moment is 2
              }

    @Test
              public void testAddValue_MultipleValuesAccumulateCorrectly() {
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Add sequence of values
                  double[] values = {1.5, 2.5, 3.5, 4.5};
                  for (double v : values) {
                      stats.addValue(v);
                  }
                  
                  // Verify accumulated statistics
                  assertEquals(4L, stats.getN());
                  assertEquals(12.0, stats.getSum(), 0.0001);
                  assertEquals(1.5, stats.getMin(), 0.0001);
                  assertEquals(4.5, stats.getMax(), 0.0001);
                  assertEquals(3.0, stats.getMean(), 0.0001);
                  assertEquals(1.25, stats.getVariance(), 0.0001);
              }

    @Test
              public void testAddValue_AfterClear() {
                  // Create new SummaryStatistics instance
                  SummaryStatistics stats = new SummaryStatistics();
                  
                  // Add some values
                  stats.addValue(10.0);
                  stats.addValue(20.0);
                  
                  // Clear and add new value
                  stats.clear();
                  stats.addValue(5.0);
                  
                  // Verify statistics reset properly
                  assertEquals(1L, stats.getN());
                  assertEquals(5.0, stats.getSum(), 0.0001);
                  assertEquals(5.0, stats.getMin(), 0.0001);
                  assertEquals(5.0, stats.getMax(), 0.0001);
              }

    @Test
         public void testAddValueMeanImplCondition() throws Exception {
             // Setup
             SummaryStatistics stats = new SummaryStatistics();
             
             // Create mock implementations
             StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
             
             // Set the implementations
             stats.setMeanImpl(mockMeanImpl);
             
             // Use reflection to set the protected mean field to be equal to mockMeanImpl
             Field meanField = SummaryStatistics.class.getDeclaredField("mean");
             meanField.setAccessible(true);
             meanField.set(stats, mockMeanImpl);
             
             // Add a value - should NOT call meanImpl.increment() since meanImpl == mean
             stats.addValue(5.0);
             
             // Verify meanImpl.increment() was NOT called (original behavior)
             verify(mockMeanImpl, never()).increment(anyDouble());
             
             // The mutant would call increment() and this verification would fail
         }

    @Test
    public void testAddValueVarianceImplNotIncrementedWhenSameAsVariance() {
        // Setup
        SummaryStatistics stats = new SummaryStatistics();
        
        // Create mock implementations
        StorelessUnivariateStatistic mockVariance = mock(StorelessUnivariateStatistic.class);
        StorelessUnivariateStatistic mockVarianceImpl = mockVariance; // Same object
        
        // Set the implementations
        stats.setVarianceImpl(mockVarianceImpl);
        
        // Add a test value
        double testValue = 5.0;
        stats.addValue(testValue);
        
        // Verify varianceImpl was NOT incremented (original behavior)
        // If it was incremented (mutant behavior), this verification would fail
        verify(mockVarianceImpl, never()).increment(testValue);
        
        // Additional verification that other stats were updated
        assertTrue(stats.getN() == 1);
    }


}
