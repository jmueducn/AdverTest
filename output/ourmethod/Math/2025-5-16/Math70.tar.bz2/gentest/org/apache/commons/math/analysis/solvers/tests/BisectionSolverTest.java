package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BisectionSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testSolve_ConvergesToRoot() throws Exception {
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(-0.5);
                                                                                            when(f.value(0.75)).thenReturn(0.25);
                                                                                            when(f.value(0.625)).thenReturn(-0.125);
                                                                                            when(f.value(0.6875)).thenReturn(0.0625);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            assertEquals(0.6875, result, 0.0001);
                                                                                        }

    @Test
                                                                                        public void testSolve_RootAtMidpoint() throws Exception {
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(0.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            assertEquals(0.5, result, 0.0001);
                                                                                        }

    @Test
                                                                                        public void testSolve_IntervalWithSameSign() throws Exception {
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(1.0);
                                                                                            when(f.value(1.0)).thenReturn(2.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            solver.solve(0.0, 1.0);
                                                                                        }

    @Test
                                                                                        public void testSolve_VerySmallInterval() throws Exception {
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1E-10);
                                                                                            when(f.value(1E-10)).thenReturn(1E-10);
                                                                                            when(f.value(5E-11)).thenReturn(0.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            double result = solver.solve(0.0, 1E-10);
                                                                                            
                                                                                            assertEquals(5E-11, result, 1E-20);
                                                                                        }

    @Test
                                                                                        public void testSolve_RootAtBoundary() throws Exception {
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(0.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            assertEquals(0.0, result, 0.0001);
                                                                                        }

    @Test
                                                                                        public void testSolve_InvalidInterval() throws Exception {
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            solver.solve(1.0, 0.0);
                                                                                        }

    @Test
                                                                                public void testSolve_InvalidInterval1() throws Exception {
                                                                                    // Setup exception rule
                                                                                    org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                    exception.expectMessage("endpoints do not specify an interval");
                                                                                    
                                                                                    // Mock the function
                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                    
                                                                                    // Test the solver
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    solver.solve(2.0, 1.0);
                                                                                }

    @Test
                                                                            public void testSolve_WithFunctionAndRange_NoRootInInterval() throws Exception {
                                                                                // Test when function doesn't cross zero in the interval
                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                when(f.value(2.0)).thenReturn(2.0);
                                                                                when(f.value(3.0)).thenReturn(3.0);
                                                                                
                                                                                try {
                                                                                    BisectionSolver solver = new BisectionSolver();
                                                                                    solver.solve(f, 1.0, 3.0);
                                                                                    fail("Expected IllegalArgumentException");
                                                                                } catch (IllegalArgumentException e) {
                                                                                    assertEquals("Function values at endpoints must have different signs", e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                        public void testSolve_NoRootInInterval() throws Exception {
                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                            when(f.value(2.0)).thenReturn(2.0);
                                                                            
                                                                            try {
                                                                                BisectionSolver solver = new BisectionSolver(f);
                                                                                solver.solve(1.0, 2.0);
                                                                                fail("Expected IllegalArgumentException");
                                                                            } catch (IllegalArgumentException e) {
                                                                                assertEquals("function values at endpoints do not have different signs", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                public void testSolve_WithFunctionAndBounds_FindsRootForLinearFunction() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction linearFunction = mock(UnivariateRealFunction.class);
                                                                    when(linearFunction.value(0.0)).thenReturn(-1.0);
                                                                    when(linearFunction.value(1.0)).thenReturn(1.0);
                                                                    when(linearFunction.value(0.5)).thenReturn(0.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(linearFunction);
                                                                    double result = solver.solve(linearFunction, 0.0, 1.0);
                                                                    
                                                                    assertEquals(0.5, result, 1E-6);
                                                                }

    @Test
                                                                public void testSolve_WithBoundsOnly_FindsRootForDefaultFunction() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    // Assuming the constructor sets a default function
                                                                    UnivariateRealFunction defaultFunction = mock(UnivariateRealFunction.class);
                                                                    when(defaultFunction.value(0.0)).thenReturn(-1.0);
                                                                    when(defaultFunction.value(1.0)).thenReturn(1.0);
                                                                    when(defaultFunction.value(0.5)).thenReturn(0.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(defaultFunction);
                                                                    double result = solver.solve(0.0, 1.0);
                                                                    
                                                                    assertEquals(0.5, result, 1E-6);
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testSolve_WithFunctionAndBounds_ThrowsWhenNoRootInInterval() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                    when(function.value(0.0)).thenReturn(1.0);
                                                                    when(function.value(1.0)).thenReturn(2.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver();
                                                                    solver.solve(function, 0.0, 1.0);
                                                                }

    @Test
                                                                public void testSolve_WithFunctionAndBounds_HandlesRootAtBoundary() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                    when(function.value(0.0)).thenReturn(0.0);
                                                                    when(function.value(1.0)).thenReturn(1.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver();
                                                                    double result = solver.solve(function, 0.0, 1.0);
                                                                    
                                                                    assertEquals(0.0, result, 1E-6);
                                                                }

    @Test
                                                                public void testSolve_WithFunctionAndBounds_ConvergesWithTolerance() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                    when(function.value(0.0)).thenReturn(-1.0);
                                                                    when(function.value(1.0)).thenReturn(1.0);
                                                                    when(function.value(0.5001)).thenReturn(0.0001);
                                                                    when(function.value(0.4999)).thenReturn(-0.0001);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(function);
                                                                    double result = solver.solve(function, 0.0, 1.0);
                                                                    
                                                                    assertTrue(Math.abs(result - 0.5) <= 1E-6);
                                                                }

    @Test
                                                                public void testSolve_WithInitialGuess_IgnoresInitialGuess() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                    when(function.value(0.0)).thenReturn(-1.0);
                                                                    when(function.value(1.0)).thenReturn(1.0);
                                                                    when(function.value(0.5)).thenReturn(0.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(function);
                                                                    double result = solver.solve(function, 0.0, 1.0, 0.8); // initial guess should be ignored
                                                                    
                                                                    assertEquals(0.5, result, 1E-6);
                                                                }

    @Test
                                                                public void testSolve_WithEqualBounds_ReturnsBoundIfRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                    when(function.value(1.0)).thenReturn(0.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver();
                                                                    double result = solver.solve(function, 1.0, 1.0);
                                                                    
                                                                    assertEquals(1.0, result, 1E-6);
                                                                }

                                                                public void testSolve_WithEqualBounds_ThrowsIfNotRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                    when(function.value(1.0)).thenReturn(0.5);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver();
                                                                    solver.solve(function, 1.0, 1.0);
                                                                }

    @Test
                                                                public void testSolve_WithFunctionAndRange_RootFound() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    // Create a mock function that crosses zero between 1 and 3
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(1.0)).thenReturn(-1.0);
                                                                    when(f.value(2.0)).thenReturn(0.0);  // root at 2.0
                                                                    when(f.value(3.0)).thenReturn(1.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    double result = solver.solve(f, 1.0, 3.0);
                                                                    
                                                                    assertEquals(2.0, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_WithFunctionAndRange_RootAtBoundary() {
                                                                    // Test when root is exactly at the boundary
                                                                    try {
                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                        when(f.value(0.0)).thenReturn(0.0);  // root at 0.0
                                                                        when(f.value(1.0)).thenReturn(1.0);
                                                                        
                                                                        BisectionSolver solver = new BisectionSolver(f);
                                                                        double result = solver.solve(f, 0.0, 1.0);
                                                                        
                                                                        assertEquals(0.0, result, 1e-6);
                                                                    } catch (FunctionEvaluationException e) {
                                                                        fail("Function evaluation failed: " + e.getMessage());
                                                                    } catch (MaxIterationsExceededException e) {
                                                                        fail("Max iterations exceeded: " + e.getMessage());
                                                                    }
                                                                }

    @Test
                                                                public void testSolve_WithRangeOnly_RootFound() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    // Test the version that uses the function from constructor
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(0.0)).thenReturn(-1.0);
                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                    when(f.value(0.5)).thenReturn(0.0);  // root at 0.5
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    double result = solver.solve(0.0, 1.0);
                                                                    
                                                                    assertEquals(0.5, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_WithInitialGuess_RootFound() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    // Test the version with initial guess
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(-1.0)).thenReturn(-1.0);
                                                                    when(f.value(0.0)).thenReturn(0.0);  // root at 0.0
                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    double result = solver.solve(-1.0, 1.0, 0.5);
                                                                    
                                                                    assertEquals(0.0, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_WithDefaultConstructor() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    // Test with default constructor and then setting function
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(1.0)).thenReturn(-1.0);
                                                                    when(f.value(2.0)).thenReturn(0.0);  // root at 2.0
                                                                    when(f.value(3.0)).thenReturn(1.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver();
                                                                    double result = solver.solve(f, 1.0, 3.0);
                                                                    
                                                                    assertEquals(2.0, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_TypicalCase() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(1.0)).thenReturn(-1.0);
                                                                    when(f.value(2.0)).thenReturn(1.0);
                                                                    when(f.value(1.5)).thenReturn(0.0); // exact root
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    double result = solver.solve(1.0, 2.0);
                                                                    
                                                                    assertEquals(1.5, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_RootAtLowerBound() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(0.0)).thenReturn(0.0);
                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    double result = solver.solve(0.0, 1.0);
                                                                    
                                                                    assertEquals(0.0, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_RootAtUpperBound() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(0.0)).thenReturn(-1.0);
                                                                    when(f.value(1.0)).thenReturn(0.0);
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    double result = solver.solve(0.0, 1.0);
                                                                    
                                                                    assertEquals(1.0, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_WithInitialValue() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(1.0)).thenReturn(-1.0);
                                                                    when(f.value(3.0)).thenReturn(1.0);
                                                                    when(f.value(2.0)).thenReturn(0.0); // root
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver();
                                                                    double result = solver.solve(f, 1.0, 3.0, 2.0);
                                                                    
                                                                    assertEquals(2.0, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_WithConstructorFunction() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(0.0)).thenReturn(-1.0);
                                                                    when(f.value(2.0)).thenReturn(1.0);
                                                                    when(f.value(1.0)).thenReturn(0.0); // root
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    double result = solver.solve(0.0, 2.0);
                                                                    
                                                                    assertEquals(1.0, result, 1e-6);
                                                                }

    @Test
                                                                public void testSolve_NonConvergingFunction() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                    org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(anyDouble())).thenReturn(1.0); // Always positive
                                                                    
                                                                    exception.expect(IllegalStateException.class);
                                                                    exception.expectMessage("maximum number of iterations exceeded");
                                                                    
                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                    solver.solve(0.0, 1.0);
                                                                }

    @Test
                                                                public void testSolve_MaxIterationsExceeded() {
                                                                    // Test when the solution doesn't converge within max iterations
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    try {
                                                                        when(f.value(0.0)).thenReturn(-1.0);
                                                                        when(f.value(1.0)).thenReturn(1.0);
                                                                        // Make the function return values that would require more iterations than allowed
                                                                        when(f.value(anyDouble())).thenAnswer(invocation -> {
                                                                            double x = invocation.getArgument(0);
                                                                            return x - 0.5000000001;  // root very close to 0.5 but not exact
                                                                        });
                                                                    } catch (FunctionEvaluationException e) {
                                                                        fail("Unexpected FunctionEvaluationException during mock setup");
                                                                    }
                                                                    
                                                                    try {
                                                                        BisectionSolver solver = new BisectionSolver(f);
                                                                        solver.solve(0.0, 1.0);
                                                                        fail("Expected IllegalStateException");
                                                                    } catch (MaxIterationsExceededException e) {
                                                                        fail("Expected IllegalStateException but got MaxIterationsExceededException");
                                                                    } catch (FunctionEvaluationException e) {
                                                                        fail("Unexpected FunctionEvaluationException during solve");
                                                                    } catch (IllegalStateException e) {
                                                                        assertEquals("Maximum number of iterations (100) exceeded", e.getMessage());
                                                                    }
                                                                }

    @Test
                                                                public void testSolve_MaxIterationsExceeded1() throws FunctionEvaluationException {
                                                                    // Test when the solution doesn't converge within max iterations
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(0.0)).thenReturn(-1.0);
                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                    // Make the function return values that would require more iterations than allowed
                                                                    when(f.value(anyDouble())).thenAnswer(invocation -> {
                                                                        double x = invocation.getArgument(0);
                                                                        return x - 0.5000000001;  // root very close to 0.5 but not exact
                                                                    });
                                                                    
                                                                    try {
                                                                        BisectionSolver solver = new BisectionSolver(f);
                                                                        solver.solve(0.0, 1.0);
                                                                        fail("Expected MaxIterationsExceededException");
                                                                    } catch (MaxIterationsExceededException e) {
                                                                        assertTrue(e.getMessage().contains("maximum number of iterations (100) exceeded"));
                                                                    }
                                                                }

    @Test
                                        public void testSolve_WithInvalidBounds_ThrowsException() throws MaxIterationsExceededException, FunctionEvaluationException {
                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                            BisectionSolver solver = new BisectionSolver();
                                            
                                            thrown.expect(IllegalArgumentException.class);
                                            solver.solve(function, 1.0, 0.0); // max < min
                                        }

    @Test
                                        public void testSolve_InvalidRange() throws MaxIterationsExceededException, FunctionEvaluationException {
                                            // Test when min > max
                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                            BisectionSolver solver = new BisectionSolver(f);
                                            try {
                                                solver.solve(f, 2.0, 1.0);
                                                fail("Expected IllegalArgumentException");
                                            } catch (IllegalArgumentException e) {
                                                assertEquals("Endpoints do not specify an interval", e.getMessage());
                                            }
                                        }


}
