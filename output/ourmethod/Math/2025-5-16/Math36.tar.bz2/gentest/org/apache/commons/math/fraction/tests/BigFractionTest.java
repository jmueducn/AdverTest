package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.ArithmeticUtils;
 
public class BigFractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                               public void testDoubleValue_SimpleFractions() {
                                   // Test simple fractions that can be exactly represented as doubles
                                   BigFraction half = new BigFraction(1, 2);
                                   assertEquals(0.5, half.doubleValue(), 0.0);
                           
                                   BigFraction third = new BigFraction(1, 3);
                                   assertEquals(1.0/3.0, third.doubleValue(), 1e-15);
                           
                                   BigFraction quarter = new BigFraction(1, 4);
                                   assertEquals(0.25, quarter.doubleValue(), 0.0);
                               }

 @Test
                               public void testDoubleValue_WholeNumbers() {
                                   // Test whole numbers
                                   BigFraction five = new BigFraction(5, 1);
                                   assertEquals(5.0, five.doubleValue(), 0.0);
                           
                                   BigFraction zero = new BigFraction(0, 1);
                                   assertEquals(0.0, zero.doubleValue(), 0.0);
                           
                                   BigFraction minusTen = new BigFraction(-10, 1);
                                   assertEquals(-10.0, minusTen.doubleValue(), 0.0);
                               }

 @Test
                               public void testDoubleValue_LargeNumbers() {
                                   // Test with numbers that are large but still within double range
                                   BigFraction largeFraction = new BigFraction(1234567890L, 987654321L);
                                   assertEquals(1234567890.0/987654321.0, largeFraction.doubleValue(), 1e-15);
                           
                                   BigFraction veryLarge = new BigFraction(Long.MAX_VALUE, Long.MAX_VALUE/2);
                                   assertEquals(2.0, veryLarge.doubleValue(), 1e-15);
                               }

 @Test
                               public void testDoubleValue_VeryLargeNumbers() {
                                   // Test with numbers that exceed double range and need shifting
                                   BigInteger hugeNum = BigInteger.TEN.pow(1000);
                                   BigInteger hugeDen = BigInteger.TEN.pow(999);
                                   BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                   
                                   // Should be 10.0 but needs shifting to compute
                                   assertEquals(10.0, hugeFraction.doubleValue(), 1e-15);
                           
                                   BigInteger maxLong = BigInteger.valueOf(Long.MAX_VALUE);
                                   BigFraction nearLimit = new BigFraction(maxLong.multiply(maxLong), maxLong);
                                   assertEquals((double)Long.MAX_VALUE, nearLimit.doubleValue(), 1e-15);
                               }

 @Test
                               public void testDoubleValue_EdgeCases() {
                                   // Test edge cases
                                   BigFraction maxDouble = new BigFraction(
                                       BigInteger.valueOf((long)Double.MAX_VALUE), 
                                       BigInteger.ONE);
                                   assertEquals(Double.MAX_VALUE, maxDouble.doubleValue(), 0.0);
                           
                                   BigFraction minDouble = new BigFraction(
                                       BigInteger.valueOf(1L), 
                                       BigInteger.valueOf((long)Double.MAX_VALUE));
                                   assertEquals(Double.MIN_VALUE, minDouble.doubleValue(), 0.0);
                           
                                   BigFraction verySmall = new BigFraction(
                                       BigInteger.ONE, 
                                       BigInteger.TEN.pow(100));
                                   assertEquals(0.0, verySmall.doubleValue(), 0.0);
                               }

 @Test
                               public void testDoubleValue_NegativeNumbers() {
                                   // Test negative fractions
                                   BigFraction negativeHalf = new BigFraction(-1, 2);
                                   assertEquals(-0.5, negativeHalf.doubleValue(), 0.0);
                           
                                   BigFraction negativeReciprocal = new BigFraction(2, -3);
                                   assertEquals(-2.0/3.0, negativeReciprocal.doubleValue(), 1e-15);
                           
                                   BigFraction bothNegative = new BigFraction(-5, -10);
                                   assertEquals(0.5, bothNegative.doubleValue(), 0.0);
                               }

 @Test
                               public void testDoubleValue_ZeroNumerator() {
                                   // Test zero numerator cases
                                   BigFraction zero = new BigFraction(0, 1);
                                   assertEquals(0.0, zero.doubleValue(), 0.0);
                           
                                   BigFraction zeroLargeDenominator = new BigFraction(0, 1000000);
                                   assertEquals(0.0, zeroLargeDenominator.doubleValue(), 0.0);
                               }

 @Test
                               public void testDoubleValue_PredefinedConstants() {
                                   // Test the predefined constants
                                   assertEquals(1.0, BigFraction.ONE.doubleValue(), 0.0);
                                   assertEquals(0.0, BigFraction.ZERO.doubleValue(), 0.0);
                                   assertEquals(-1.0, BigFraction.MINUS_ONE.doubleValue(), 0.0);
                                   assertEquals(2.0, BigFraction.TWO.doubleValue(), 0.0);
                                   assertEquals(0.5, BigFraction.ONE_HALF.doubleValue(), 0.0);
                                   assertEquals(1.0/3.0, BigFraction.ONE_THIRD.doubleValue(), 1e-15);
                                   assertEquals(0.25, BigFraction.ONE_QUARTER.doubleValue(), 0.0);
                               }

 @Test
                               public void testFloatValue_NormalFractions() {
                                   // Test simple fractions that fit within float range
                                   BigFraction half = new BigFraction(1, 2);
                                   assertEquals(0.5f, half.floatValue(), 0.000001f);
                                   
                                   BigFraction third = new BigFraction(1, 3);
                                   assertEquals(0.333333f, third.floatValue(), 0.000001f);
                                   
                                   BigFraction negative = new BigFraction(-3, 4);
                                   assertEquals(-0.75f, negative.floatValue(), 0.000001f);
                               }

 @Test
                               public void testFloatValue_WholeNumbers() {
                                   // Test whole numbers
                                   BigFraction five = new BigFraction(5);
                                   assertEquals(5.0f, five.floatValue(), 0.000001f);
                                   
                                   BigFraction zero = new BigFraction(0);
                                   assertEquals(0.0f, zero.floatValue(), 0.000001f);
                                   
                                   BigFraction large = new BigFraction(123456789);
                                   assertEquals(123456789.0f, large.floatValue(), 0.000001f);
                               }

 @Test
                               public void testFloatValue_LargeNumbers() {
                                   // Test numbers that exceed normal float range
                                   BigInteger hugeNum = BigInteger.TEN.pow(50);
                                   BigInteger hugeDen = BigInteger.TEN.pow(49);
                                   BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                   
                                   // Should be 10.0 but needs shifting
                                   assertEquals(10.0f, hugeFraction.floatValue(), 0.000001f);
                                   
                                   BigInteger veryLarge = BigInteger.valueOf(2).pow(200);
                                   BigFraction largeFraction = new BigFraction(veryLarge, BigInteger.ONE);
                                   assertEquals(Float.POSITIVE_INFINITY, largeFraction.floatValue(), 0.0f);
                               }

 @Test
                               public void testFloatValue_SmallNumbers() {
                                   // Test very small numbers
                                   BigInteger tinyNum = BigInteger.ONE;
                                   BigInteger tinyDen = BigInteger.TEN.pow(50);
                                   BigFraction tinyFraction = new BigFraction(tinyNum, tinyDen);
                                   
                                   // Should be approximately 0 but needs shifting
                                   assertEquals(0.0f, tinyFraction.floatValue(), 0.000001f);
                                   
                                   BigInteger verySmall = BigInteger.ONE;
                                   BigInteger veryLargeDen = BigInteger.valueOf(2).pow(200);
                                   BigFraction smallFraction = new BigFraction(verySmall, veryLargeDen);
                                   assertEquals(0.0f, smallFraction.floatValue(), 0.0f);
                               }

 @Test
                               public void testFloatValue_EdgeCases() {
                                   // Test edge cases
                                   BigFraction maxFloat = new BigFraction(
                                       BigInteger.valueOf((long) Float.MAX_VALUE), 
                                       BigInteger.ONE);
                                   assertEquals(Float.MAX_VALUE, maxFloat.floatValue(), 0.0f);
                                   
                                   BigFraction minFloat = new BigFraction(
                                       BigInteger.valueOf(1), 
                                       BigInteger.valueOf((long) Float.MAX_VALUE));
                                   assertEquals(Float.MIN_VALUE, minFloat.floatValue(), 0.0f);
                                   
                                   BigFraction overflow = new BigFraction(
                                       BigInteger.valueOf((long) Float.MAX_VALUE).multiply(BigInteger.TEN), 
                                       BigInteger.ONE);
                                   assertEquals(Float.POSITIVE_INFINITY, overflow.floatValue(), 0.0f);
                               }

 @Test
                               public void testFloatValue_Constants() {
                                   // Test class constants
                                   assertEquals(1.0f, BigFraction.ONE.floatValue(), 0.0f);
                                   assertEquals(0.0f, BigFraction.ZERO.floatValue(), 0.0f);
                                   assertEquals(-1.0f, BigFraction.MINUS_ONE.floatValue(), 0.0f);
                                   assertEquals(0.5f, BigFraction.ONE_HALF.floatValue(), 0.000001f);
                                   assertEquals(0.25f, BigFraction.ONE_QUARTER.floatValue(), 0.000001f);
                                   assertEquals(0.333333f, BigFraction.ONE_THIRD.floatValue(), 0.000001f);
                               }

 @Test
                               public void testFloatValue_EqualButDifferentRepresentations() {
                                   // Test fractions that are equal but have different representations
                                   BigFraction half1 = new BigFraction(1, 2);
                                   BigFraction half2 = new BigFraction(2, 4);
                                   BigFraction half3 = new BigFraction(50, 100);
                                   
                                   assertEquals(half1.floatValue(), half2.floatValue(), 0.0f);
                                   assertEquals(half1.floatValue(), half3.floatValue(), 0.0f);
                               }

 @Test
                           public void testFloatValueWithLargeNumbers() {
                               // Create numbers that would overflow float range if not shifted
                               BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                               BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                               
                               BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                               
                               float result = fraction.floatValue();
                               
                               // Original behavior: Should return a finite float after shifting
                               // Mutant behavior: Would return NaN
                               assertFalse("Result should not be NaN", Float.isNaN(result));
                               
                               // Additional check to ensure we got a reasonable value
                               assertTrue("Result should be between 0 and 2", result > 0 && result < 2);
                           }

 @Test
                          public void testFloatValueShouldNotShiftNormalNumbers() {
                              // Create a fraction with normal numbers that don't need shifting
                              BigInteger numerator = BigInteger.valueOf(1);
                              BigInteger denominator = BigInteger.valueOf(2);
                              BigFraction fraction = new BigFraction(numerator, denominator);
                              
                              // Calculate expected value (0.5)
                              float expected = numerator.floatValue() / denominator.floatValue();
                              
                              // Get actual value
                              float actual = fraction.floatValue();
                              
                              // With original code: should be exactly 0.5
                              // With mutant: will perform unnecessary shift and lose precision
                              assertEquals("Normal numbers should not be shifted", expected, actual, 0.0f);
                              
                              // Additional check - verify the shifted calculation would give different result
                              int shift = Math.max(numerator.bitLength(), denominator.bitLength()) - Float.MAX_EXPONENT;
                              float shiftedResult = numerator.shiftRight(shift).floatValue() / 
                                                  denominator.shiftRight(shift).floatValue();
                              assertNotEquals("Shifted result should differ from exact result", 
                                             expected, shiftedResult, 0.0f);
                          }

 @Test
                         public void testFloatValueWithNaN() {
                             // Create extremely large numbers that will produce NaN when divided as floats
                             // Using values beyond Float.MAX_VALUE but not infinite
                             BigInteger hugeNum = new BigInteger("2").pow(1000);
                             BigInteger hugeDen = new BigInteger("3").pow(1000);
                             
                             BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                             
                             // The original code would handle this by shifting, mutated code would return NaN
                             float result = fraction.floatValue();
                             
                             // Verify the result is a finite number (not NaN or infinite)
                             assertFalse("Result should not be NaN", Float.isNaN(result));
                             assertFalse("Result should not be infinite", Float.isInfinite(result));
                             
                             // Additional verification that the shifting logic worked
                             // The exact value isn't important, just that it's a valid float
                             assertTrue("Result should be a normal float value", 
                                 Math.abs(result) > Float.MIN_VALUE && Math.abs(result) < Float.MAX_VALUE);
                         }

 @Test
                        public void testFloatValueWithLargeNumbers1() {
                            // Create numbers that are too large for direct float division
                            BigInteger hugeNum = new BigInteger("123456789012345678901234567890");
                            BigInteger hugeDen = new BigInteger("987654321098765432109876543210");
                            
                            // With original code, this should return a valid float after shifting
                            // With mutant, it would return NaN because shift is skipped
                            BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                            float result = fraction.floatValue();
                            
                            // Verify result is not NaN (which would happen if shift was skipped)
                            assertFalse("Result should not be NaN", Float.isNaN(result));
                            
                            // Verify result is finite (additional check)
                            assertTrue("Result should be finite", Float.isFinite(result));
                            
                            // Verify result is approximately correct
                            float expected = 0.125f; // approximate expected value after shifting
                            assertEquals(expected, result, 0.01f);
                        }

 @Test
                        public void testFloatValueWithNormalNumbers() {
                            // Test with normal numbers that don't need shifting
                            BigFraction fraction = new BigFraction(1, 2);
                            float result = fraction.floatValue();
                            
                            // Verify correct result
                            assertEquals(0.5f, result, 0.0001f);
                        }

 @Test
                  public void testFloatValueWithNaNCondition() {
                      // Create a fraction that will produce NaN when converted to float
                      // Using very large numbers that exceed float range
                      BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                      BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                      BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                      
                      // The original code would detect NaN using Double.isNaN()
                      // The mutant uses result != result which should behave the same
                      // But we want to explicitly test this path
                      float result = fraction.floatValue();
                      
                      // Verify the result is a valid float (not NaN or infinite)
                      // This ensures the NaN handling path was taken
                      assertFalse(Float.isNaN(result));
                      assertFalse(Float.isInfinite(result));
                      
                      // Additional test with numbers that don't produce NaN
                      BigFraction normalFraction = new BigFraction(1, 2);
                      float normalResult = normalFraction.floatValue();
                      assertEquals(0.5f, normalResult, 0.0001f);
                      
                      // Test with numbers that would produce infinity
                      BigInteger maxFloatNum = BigInteger.valueOf((long)Float.MAX_VALUE).multiply(BigInteger.valueOf(2));
                      BigFraction infiniteFraction = new BigFraction(maxFloatNum, BigInteger.ONE);
                      float infiniteResult = infiniteFraction.floatValue();
                      assertTrue(Float.isInfinite(infiniteResult));
                  }

 @Test
                  public void testFloatValueNaNDetection() {
                      // Create a fraction that will produce NaN
                      BigInteger maxFloat = BigInteger.valueOf((long) Float.MAX_VALUE);
                      BigFraction nanFraction = new BigFraction(maxFloat.multiply(maxFloat), 
                                maxFloat.multiply(maxFloat));
                      
                      // The key assertion - verify NaN is properly detected and handled
                      // This would fail if the NaN check was mutated to result != result
                      // because that would miss some edge cases of NaN detection
                      float result = nanFraction.floatValue();
                      
                      // Verify the result was properly adjusted (not NaN)
                      assertFalse(Float.isNaN(result));
                      
                      // Additional verification that the adjustment was correct
                      assertTrue(Math.abs(result - 1.0f) < 0.0001f);
                  }

 @Test
                  public void testFloatValue_ShouldNotEnterNaNCheckForNormalValues() {
                      // Arrange - create a fraction that can be represented directly as float
                      BigInteger numerator = BigInteger.valueOf(1);
                      BigInteger denominator = BigInteger.valueOf(2);
                      BigFraction fraction = new BigFraction(numerator, denominator);
                      
                      // Act
                      float result = fraction.floatValue();
                      
                      // Assert - should be 0.5f without entering NaN check
                      assertEquals(0.5f, result, 0.0001f);
                  }

 @Test
                  public void testFloatValue_ShouldEnterNaNCheckForLargeValues() {
                      // Arrange - create a fraction with very large numbers that would produce NaN
                      BigInteger numerator = new BigInteger("1E1000");
                      BigInteger denominator = new BigInteger("2E1000");
                      BigFraction fraction = new BigFraction(numerator, denominator);
                      
                      // Act
                      float result = fraction.floatValue();
                      
                      // Assert - should be approximately 0.5f after shift-right adjustment
                      assertEquals(0.5f, result, 0.0001f);
                  }

 @Test
             public void testFloatValueWithLargeNumbers2() {
                 // Create numbers that will overflow float initially but should be representable after scaling
                 BigInteger hugeNum = BigInteger.TEN.pow(100); // 10^100
                 BigInteger hugeDen = BigInteger.TEN.pow(100).add(BigInteger.ONE); // 10^100 + 1
                 
                 BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                 
                 // Original should return approximately 1.0 (since 10^100 / (10^100 + 1) ≈ 1.0)
                 // Mutant would either return NaN or a very wrong value due to left shift making numbers larger
                 float result = fraction.floatValue();
                 
                 // Verify result is finite and approximately correct
                 assertFalse("Result should not be NaN", Float.isNaN(result));
                 assertTrue("Result should be finite", Float.isFinite(result));
                 assertEquals("Result should be approximately 1.0", 1.0f, result, 0.0001f);
             }

 @Test
            public void testFloatValueWithLargeNumbers3() {
                // Create numbers that are too large for float representation
                BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200 is way beyond float range
                BigInteger hugeDen = BigInteger.valueOf(3).pow(200);  // 3^200 is also beyond float range
                
                // Create BigFraction with these numbers
                BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                
                // Calculate expected value by shifting both numerator and denominator
                int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                float expected = hugeNum.shiftRight(shift).floatValue() / hugeDen.shiftRight(shift).floatValue();
                
                // Test the actual floatValue()
                float actual = fraction.floatValue();
                
                // The mutant would calculate numerator without shifting, so it would be different
                assertEquals(expected, actual, 0.0001f);
                
                // Additional check - the unshifted division should be NaN
                assertTrue(Float.isNaN(hugeNum.floatValue() / hugeDen.floatValue()));
            }

 @Test
           public void testFloatValueWithDifferentBitLengths() {
               // Create numbers where numerator has much larger bit length than denominator
               BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
               BigInteger smallDen = BigInteger.valueOf(1L);
               
               BigFraction fraction = new BigFraction(hugeNum, smallDen);
               
               // This should not throw exception or return NaN
               float result = fraction.floatValue();
               
               // Verify the result is finite (not NaN or infinite)
               assertFalse(Float.isNaN(result));
               assertFalse(Float.isInfinite(result));
               
               // Verify the result is approximately correct
               // We can't check exact value due to floating point precision,
               // but should be in reasonable range
               assertTrue(result > 1.0e30f); // Should be very large but finite
           }

 @Test
              public void testFloatValueWithLargeNumbers4() {
                  // Create numerator and denominator that are too large for direct float conversion
                  // but when properly scaled down will give 1.0
                  BigInteger huge = BigInteger.valueOf(2).pow(1000); // Much larger than Float.MAX_VALUE
                  BigFraction fraction = new BigFraction(huge, huge);
                  
                  // Original should return ~1.0 after proper scaling
                  // Mutant would shift left making numbers even larger and likely return NaN or Infinity
                  float result = fraction.floatValue();
                  
                  // Verify we got the expected scaled result
                  assertEquals(1.0f, result, 0.0001f);
                  
                  // Additional verification that we actually went through the scaling path
                  assertFalse(Float.isNaN(result));
                  assertFalse(Float.isInfinite(result));
              }

 @Test
             public void testFloatValueWithLargeNumbers5() {
                 // Create numbers large enough to trigger the shift case
                 BigInteger hugeNum = new BigInteger("123456789012345678901234567890");
                 BigInteger hugeDen = new BigInteger("98765432109876543210987654321");
                 BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                 
                 // Calculate expected value by doing the shift with double precision
                 int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                 double expected = hugeNum.shiftRight(shift).doubleValue() / 
                                  hugeDen.shiftRight(shift).doubleValue();
                 
                 // Get actual value from the method
                 float actual = fraction.floatValue();
                 
                 // Verify the actual float value is close enough to our double-precision calculation
                 // Using delta of 1e-5 to account for float precision limitations
                 assertEquals((float)expected, actual, 1e-5);
                 
                 // Additional verification that the mutant would fail:
                 // If floatValue() was used in the shift calculation, the result would be less precise
                 float mutantValue = hugeNum.shiftRight(shift).floatValue() / 
                                    hugeDen.shiftRight(shift).floatValue();
                 assertNotEquals("Mutant detected: floatValue used in shift calculation", 
                                mutantValue, actual, 0.0);
             }

 @Test
            public void testFloatValueWithDifferentBitLengths1() {
                // Create numbers with significantly different bit lengths
                // Large numerator (100 bits), small denominator (10 bits)
                BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890"); // ~132 bits
                BigInteger smallDen = BigInteger.valueOf(1023); // 10 bits
                
                // Original behavior: shift should be based on numerator's bit length (132 - 127 = 5)
                // Mutated behavior: shift would be based on denominator's bit length (10 - 127 = -117)
                BigFraction fraction = new BigFraction(hugeNum, smallDen);
                
                // The mutated version would calculate a negative shift (-117) which when applied via shiftRight
                // would actually shift LEFT (since shiftRight with negative = shiftLeft), making numbers bigger
                // This would definitely still result in NaN
                float result = fraction.floatValue();
                
                // Verify we got a valid float (not NaN) - this will fail with the mutant
                assertFalse("Result should not be NaN", Float.isNaN(result));
                
                // Additional verification that the scaling worked properly
                // Calculate expected shift (original behavior)
                int expectedShift = Math.max(hugeNum.bitLength(), smallDen.bitLength()) - Float.MAX_EXPONENT;
                BigInteger scaledNum = hugeNum.shiftRight(expectedShift);
                BigInteger scaledDen = smallDen.shiftRight(expectedShift);
                float expected = scaledNum.floatValue() / scaledDen.floatValue();
                
                assertEquals("Scaled value should match expected", expected, result, 0.0001f);
            }

 @Test
           public void testFloatValueShouldNotShiftForNormalValues() {
               // Create a fraction with normal values that don't need shifting
               BigInteger numerator = BigInteger.valueOf(1);
               BigInteger denominator = BigInteger.valueOf(2);
               BigFraction fraction = new BigFraction(numerator, denominator);
               
               // Expected value is simple division (0.5)
               float expected = 0.5f;
               
               // Actual value should match expected if no shifting occurs
               float actual = fraction.floatValue();
               
               // If mutant is present, actual will be shifted version which may differ
               assertEquals("Float value should be direct division result without shifting", 
                           expected, actual, 0.0001f);
               
               // Additional check - verify numerator/denominator weren't shifted
               // by checking they remain the same after floatValue() call
               assertEquals("Numerator should remain unchanged", 
                           numerator, fraction.getNumerator());
               assertEquals("Denominator should remain unchanged", 
                           denominator, fraction.getDenominator());
           }

 @Test
          public void testFloatValueWithExtremeValues() {
              // Create numbers that will overflow float range when divided
              BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
              BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
              
              BigFraction fraction = new BigFraction(hugeNum, hugeDen);
              
              // The important part is that we get a finite result, 
              // which proves the shift operation was performed
              float result = fraction.floatValue();
              
              // Verify the result is finite (not NaN or infinite)
              assertFalse(Float.isNaN(result));
              assertFalse(Float.isInfinite(result));
              
              // Additional verification that the value is reasonable
              assertTrue(result > 0);
              assertTrue(result < 2); // The actual value should be ~1.25
          }

 @Test
         public void testFloatValueShouldNotEnterNaNCheckForSmallNumbers() {
             // Create a BigFraction with small numbers that don't need shifting
             BigInteger numerator = BigInteger.valueOf(1);
             BigInteger denominator = BigInteger.valueOf(2);
             BigFraction fraction = new BigFraction(numerator, denominator);
             
             // Calculate expected value directly
             float expected = numerator.floatValue() / denominator.floatValue();
             
             // Verify the method returns the expected value without entering NaN check
             assertEquals(expected, fraction.floatValue(), 0.0001f);
             
             // The mutation would have performed shifting even for these small numbers,
             // resulting in a different value, so this test would fail for the mutated code
         }

 @Test
         public void testFloatValueShouldEnterNaNCheckForLargeNumbers() {
             // Create a BigFraction with very large numbers that would cause NaN
             BigInteger numerator = new BigInteger("123456789012345678901234567890");
             BigInteger denominator = new BigInteger("987654321098765432109876543210");
             BigFraction fraction = new BigFraction(numerator, denominator);
             
             // Calculate expected value with shifting
             int shift = Math.max(numerator.bitLength(), denominator.bitLength()) - Float.MAX_EXPONENT;
             float expected = numerator.shiftRight(shift).floatValue() / 
                              denominator.shiftRight(shift).floatValue();
             
             // Verify the method returns the shifted value
             assertEquals(expected, fraction.floatValue(), 0.0001f);
         }

 @Test
        public void testFloatValueWithLargeNumbers6() {
            // Create numbers with different bit lengths that would cause overflow
            // numerator has more bits than denominator
            BigInteger numerator = new BigInteger("1").shiftLeft(Float.MAX_EXPONENT + 10);
            BigInteger denominator = new BigInteger("1").shiftLeft(Float.MAX_EXPONENT + 5);
            
            BigFraction fraction = new BigFraction(numerator, denominator);
            
            // The test will fail with the mutant because:
            // Original: shift = max(1034,1029) - 127 = 907 (enough to bring both into range)
            // Mutant: shift = min(1034,1029) - 127 = 902 (may not be enough for numerator)
            float result = fraction.floatValue();
            
            // Verify we got a valid float value (not NaN)
            assertFalse("Result should not be NaN", Float.isNaN(result));
            
            // Verify the value is approximately correct (2^5 = 32)
            assertEquals(32.0f, result, 0.0001f);
        }

 @Test
       public void testFloatValueWithLargeNumbers7() {
           // Create numbers large enough to cause initial NaN
           BigInteger hugeNum = BigInteger.valueOf(2).pow(1000);  // 2^1000
           BigInteger hugeDen = BigInteger.valueOf(3).pow(1000); // 3^1000
           
           // Create BigFraction with these large numbers
           BigFraction fraction = new BigFraction(hugeNum, hugeDen);
           
           // Calculate expected value by manual right shifting
           int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
           BigInteger shiftedNum = hugeNum.shiftRight(shift);
           BigInteger shiftedDen = hugeDen.shiftRight(shift);
           float expected = shiftedNum.floatValue() / shiftedDen.floatValue();
           
           // Test the actual floatValue()
           float actual = fraction.floatValue();
           
           // Verify the result is finite and correct
           assertFalse("Result should not be NaN", Float.isNaN(actual));
           assertFalse("Result should not be infinite", Float.isInfinite(actual));
           assertEquals("Result should match manually shifted calculation", 
                       expected, actual, 0.0001f);
           
           // The mutant using shiftLeft would either:
           // 1. Still return NaN (if shifted numbers are still too big)
           // 2. Return a completely wrong value (if shifted numbers are in range but incorrect)
           // Either way, the assertions above would fail
       }

 @Test
      public void testFloatValueWithLargeNumbers8() {
          // Create numerator and denominator that are too large for float representation
          BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
          BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
          
          BigFraction fraction = new BigFraction(hugeNum, hugeDen);
          
          // The initial float division should result in NaN
          float result = fraction.floatValue();
          
          // Verify the result is finite (not NaN or infinite)
          // This will fail with the mutant because floatValue() in fallback may still produce NaN
          assertFalse(Float.isNaN(result));
          assertFalse(Float.isInfinite(result));
          
          // Verify the result is approximately correct
          // Using doubleValue() as reference since it's more precise
          double expected = hugeNum.doubleValue() / hugeDen.doubleValue();
          assertEquals((double)expected, (double)result, 1e-10);
      }

 @Test
     public void testFloatValueWithLargeNumbersOfDifferentSizes() {
         // Create numbers where numerator has much larger bit length than denominator
         // These values are chosen to be large enough to require scaling,
         // but with significantly different bit lengths
         BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
         BigInteger smallDen = BigInteger.valueOf(12345);
         
         // Create BigFraction (assuming constructor is available)
         BigFraction fraction = new BigFraction(hugeNum, smallDen);
         
         // Test floatValue()
         float result = fraction.floatValue();
         
         // Verify the result is a valid float (not NaN)
         assertFalse("Result should not be NaN", Float.isNaN(result));
         
         // Additional verification that the value is approximately correct
         // We can't check exact value due to floating point imprecision,
         // but can check it's in a reasonable range
         float expectedApprox = 1.0e36f; // Rough order of magnitude
         assertTrue("Result should be approximately correct", 
                   Math.abs(result - expectedApprox)/expectedApprox < 0.1);
     }

}
