package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.text.FieldPosition;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Locale;
 
public class ComplexFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
             public void testParse_ValidComplexNumber() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 Complex result = format.parse("3.14 + 2.71i");
                 
                 assertEquals(3.14, result.getReal(), 0.0001);
                 assertEquals(2.71, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_ValidNegativeComplexNumber() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 Complex result = format.parse("-5.0 - 7.2i");
                 
                 assertEquals(-5.0, result.getReal(), 0.0001);
                 assertEquals(-7.2, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_ValidRealOnly() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 Complex result = format.parse("42.0");
                 
                 assertEquals(42.0, result.getReal(), 0.0001);
                 assertEquals(0.0, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_ValidImaginaryOnly() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 Complex result = format.parse("3.5i");
                 
                 assertEquals(0.0, result.getReal(), 0.0001);
                 assertEquals(3.5, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_WithDifferentImaginaryCharacter() throws ParseException {
                 ComplexFormat format = new ComplexFormat("j");
                 Complex result = format.parse("1.0 + 2.0j");
                 
                 assertEquals(1.0, result.getReal(), 0.0001);
                 assertEquals(2.0, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_WithCustomNumberFormat() throws ParseException {
                 NumberFormat format = NumberFormat.getInstance();
                 format.setMaximumFractionDigits(2);
                 ComplexFormat complexFormat = new ComplexFormat(format);
                 
                 Complex result = complexFormat.parse("3,14159 + 2,71828i");
                 
                 assertEquals(3.14, result.getReal(), 0.0001);
                 assertEquals(2.72, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_EmptyStringShouldThrowException() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 
                 thrown.expect(ParseException.class);
                 thrown.expectMessage("Unparseable complex number: \"\"");
                 format.parse("");
             }

    @Test
             public void testParse_InvalidFormatShouldThrowException() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 
                 thrown.expect(ParseException.class);
                 thrown.expectMessage("Unparseable complex number: \"abc\"");
                 format.parse("abc");
             }

    @Test
             public void testParse_MissingImaginaryPartShouldThrowException() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 
                 thrown.expect(ParseException.class);
                 thrown.expectMessage("Unparseable complex number: \"5.0 + \"");
                 format.parse("5.0 + ");
             }

    @Test
             public void testParse_WithWhitespace() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 Complex result = format.parse("   1.0   +   2.0i   ");
                 
                 assertEquals(1.0, result.getReal(), 0.0001);
                 assertEquals(2.0, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_WithParentheses() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 Complex result = format.parse("(1.0 + 2.0i)");
                 
                 assertEquals(1.0, result.getReal(), 0.0001);
                 assertEquals(2.0, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_WithScientificNotation() throws ParseException {
                 ComplexFormat format = new ComplexFormat();
                 Complex result = format.parse("1.0E-5 + 2.0E+3i");
                 
                 assertEquals(1.0E-5, result.getReal(), 0.0001);
                 assertEquals(2.0E+3, result.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_ValidComplexNumber1() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Test with positive real and positive imaginary
                 Complex result1 = format.parse("3.14 + 2.71i", pos);
                 assertEquals(3.14, result1.getReal(), 0.0001);
                 assertEquals(2.71, result1.getImaginary(), 0.0001);
                 
                 // Test with negative real and negative imaginary
                 pos.setIndex(0);
                 Complex result2 = format.parse("-5.5 - 1.2i", pos);
                 assertEquals(-5.5, result2.getReal(), 0.0001);
                 assertEquals(-1.2, result2.getImaginary(), 0.0001);
                 
                 // Test with no sign (only real part)
                 pos.setIndex(0);
                 Complex result3 = format.parse("7.8", pos);
                 assertEquals(7.8, result3.getReal(), 0.0001);
                 assertEquals(0.0, result3.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_InvalidRealNumber() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Invalid real number (letters instead of numbers)
                 Complex result = format.parse("abc + 2i", pos);
                 assertNull(result);
                 assertEquals(0, pos.getIndex()); // Should reset to initial position
                 assertTrue(pos.getErrorIndex() >= 0); // Should set error index
             }

    @Test
             public void testParse_InvalidImaginaryNumber() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Valid real but invalid imaginary
                 Complex result = format.parse("3.14 + xyi", pos);
                 assertNull(result);
                 assertEquals(0, pos.getIndex()); // Should reset to initial position
                 assertTrue(pos.getErrorIndex() >= 0); // Should set error index
             }

    @Test
             public void testParse_InvalidSign() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Invalid sign character
                 Complex result = format.parse("3.14 * 2i", pos);
                 assertNull(result);
                 assertEquals(0, pos.getIndex()); // Should reset to initial position
                 assertTrue(pos.getErrorIndex() >= 0); // Should set error index
             }

    @Test
             public void testParse_MissingImaginaryCharacter() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Missing 'i' at the end
                 Complex result = format.parse("3.14 + 2", pos);
                 assertNull(result);
                 assertEquals(0, pos.getIndex()); // Should reset to initial position
                 assertTrue(pos.getErrorIndex() >= 0); // Should set error index
             }

    @Test
             public void testParse_WhitespaceHandling() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Test with various whitespace patterns
                 Complex result1 = format.parse("  3.14  +  2.71i  ", pos);
                 assertEquals(3.14, result1.getReal(), 0.0001);
                 assertEquals(2.71, result1.getImaginary(), 0.0001);
                 
                 pos.setIndex(0);
                 Complex result2 = format.parse("3.14+2.71i", pos); // No spaces
                 assertEquals(3.14, result2.getReal(), 0.0001);
                 assertEquals(2.71, result2.getImaginary(), 0.0001);
             }

    @Test
             public void testParse_CustomImaginaryCharacter() {
                 ComplexFormat format = new ComplexFormat("j");
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Test with custom imaginary character
                 Complex result = format.parse("3.14 + 2.71j", pos);
                 assertEquals(3.14, result.getReal(), 0.0001);
                 assertEquals(2.71, result.getImaginary(), 0.0001);
                 
                 // Should fail with default 'i'
                 pos.setIndex(0);
                 Complex result2 = format.parse("3.14 + 2.71i", pos);
                 assertNull(result2);
             }

    @Test
             public void testParse_EmptyString() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 Complex result = format.parse("", pos);
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

    @Test
             public void testParse_NullString() {
                 ComplexFormat format = new ComplexFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 thrown.expect(NullPointerException.class);
                 format.parse(null, pos);
             }

    @Test
             public void testParse_NullParsePosition() {
                 ComplexFormat format = new ComplexFormat();
                 
                 thrown.expect(NullPointerException.class);
                 format.parse("3.14 + 2.71i", null);
             }

    @Test
             public void testParse_WithDifferentNumberFormats() {
                 NumberFormat customFormat = NumberFormat.getInstance();
                 customFormat.setMaximumFractionDigits(2);
                 ComplexFormat format = new ComplexFormat(customFormat);
                 ParsePosition pos = new ParsePosition(0);
                 
                 // Test with numbers that would be formatted differently
                 Complex result = format.parse("3.14159 + 2.71828i", pos);
                 assertEquals(3.14, result.getReal(), 0.0001);
                 assertEquals(2.72, result.getImaginary(), 0.0001);
             }

    @Test
     public void testParseWithMissingImaginaryCharacter() {
         // Setup
         ComplexFormat format = new ComplexFormat();
         ParsePosition pos = new ParsePosition(0);
         String source = "1.23+4.56"; // Missing imaginary character
         
         // Execute
         Complex result = format.parse(source, pos);
         
         // Verify
         assertNull("Should return null when imaginary character is missing", result);
         assertEquals("Error index should be set to start of imaginary character", 
                      source.indexOf('+') + 1, pos.getErrorIndex());
         assertEquals("Parse position should be reset to initial", 0, pos.getIndex());
     }

    @Test(expected = ParseException.class)
    public void testParseWithEmptyStringShouldThrowException() throws ParseException {
        // Setup
        ComplexFormat complexFormat = new ComplexFormat();
        String emptySource = "";
        
        // Exercise
        complexFormat.parse(emptySource);
        
        // The test will pass if ParseException is thrown (original behavior)
        // The mutant would fail to throw the exception when startIndex == source.length()
        // because it only checks startIndex > source.length()
    }

    @Test(expected = ParseException.class)
    public void testParseWithWhitespaceOnlyStringShouldThrowException() throws ParseException {
        // Setup
        ComplexFormat complexFormat = new ComplexFormat();
        String whitespaceSource = "   ";
        
        // Exercise
        complexFormat.parse(whitespaceSource);
        
        // After parsing all whitespace, startIndex would equal source.length()
        // Original would throw exception, mutant might not
    }


}
