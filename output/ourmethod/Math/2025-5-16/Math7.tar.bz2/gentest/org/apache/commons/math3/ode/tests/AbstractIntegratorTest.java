package gentest.org.apache.commons.math3.ode.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.ode.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.apache.commons.math3.analysis.solvers.BracketingNthOrderBrentSolver;
import org.apache.commons.math3.analysis.solvers.UnivariateSolver;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.ode.events.EventHandler;
import org.apache.commons.math3.ode.events.EventState;
import org.apache.commons.math3.ode.sampling.AbstractStepInterpolator;
import org.apache.commons.math3.ode.sampling.StepHandler;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Incrementor;
import org.apache.commons.math3.util.Precision;
 
public class AbstractIntegratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                         public void testAcceptStep_NoEventsForwardIntegration() throws Exception {
                                             // Setup
                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                 @Override
                                                 public void integrate(ExpandableStatefulODE equations, double t) {}
                                             };
                                             
                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                             when(interpolator.isForward()).thenReturn(true);
                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                             
                                             double[] y = new double[2];
                                             double[] yDot = new double[2];
                                             double tEnd = 1.0;
                                             
                                             // Set up eventsStates using reflection
                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                             eventsStatesField.setAccessible(true);
                                             eventsStatesField.set(integrator, Collections.<EventState>emptyList());
                                             
                                             // Add a step handler
                                             StepHandler stepHandler = mock(StepHandler.class);
                                             Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                             stepHandlersField.setAccessible(true);
                                             stepHandlersField.set(integrator, Collections.<StepHandler>singletonList(stepHandler));
                                             
                                             // Initialize statesInitialized to true to skip event initialization
                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                             statesInitializedField.setAccessible(true);
                                             statesInitializedField.set(integrator, true);
                                             
                                             // Execute using reflection
                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                             acceptStepMethod.setAccessible(true);
                                             double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                             
                                             // Verify
                                             assertEquals(1.0, result, 1e-10);
                                             assertArrayEquals(new double[]{1.0, 2.0}, y, 1e-10);
                                             verify(stepHandler).handleStep(interpolator, true);
                                             
                                             // Check resetOccurred using reflection
                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                             resetOccurredField.setAccessible(true);
                                             assertFalse(resetOccurredField.getBoolean(integrator));
                                         }

    @Test
                                         public void testAcceptStep_WithSingleEventForwardIntegration() throws Exception {
                                             // Setup
                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                 @Override
                                                 public void integrate(ExpandableStatefulODE equations, double t) {}
                                                 
                                                 @Override
                                                 protected void sanityChecks(ExpandableStatefulODE equations, double t) {}
                                                 
                                                 @Override
                                                 public void computeDerivatives(double t, double[] y, double[] yDot) {}
                                             };
                                             
                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                             when(interpolator.isForward()).thenReturn(true);
                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                             
                                             double[] y = new double[2];
                                             double[] yDot = new double[2];
                                             double tEnd = 1.0;
                                             
                                             // Setup event state
                                             EventState eventState = mock(EventState.class);
                                             when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                             when(eventState.getEventTime()).thenReturn(0.5);
                                             when(eventState.stop()).thenReturn(false);
                                             when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                             
                                             // Set private eventsStates field using reflection
                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                             eventsStatesField.setAccessible(true);
                                             eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                             
                                             // Add a step handler
                                             StepHandler stepHandler = mock(StepHandler.class);
                                             Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                             stepHandlersField.setAccessible(true);
                                             stepHandlersField.set(integrator, Collections.singletonList(stepHandler));
                                             
                                             // Execute using reflection to call protected method
                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep",
                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                             acceptStepMethod.setAccessible(true);
                                             double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                             
                                             // Verify
                                             assertEquals(1.0, result, 1e-10);
                                             verify(eventState).reinitializeBegin(interpolator);
                                             verify(eventState).stepAccepted(0.5, new double[]{1.0, 2.0});
                                             verify(eventState).stepAccepted(1.0, new double[]{1.0, 2.0});
                                             verify(stepHandler, times(2)).handleStep(any(AbstractStepInterpolator.class), anyBoolean());
                                             
                                             // Check protected resetOccurred field using reflection
                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                             resetOccurredField.setAccessible(true);
                                             assertFalse(resetOccurredField.getBoolean(integrator));
                                         }

    @Test
                                         public void testAcceptStep_EventRequestsStop() throws Exception {
                                             // Setup
                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                 @Override
                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                     // Empty implementation for test
                                                 }
                                                 
                                                 @Override
                                                 protected double acceptStep(AbstractStepInterpolator interpolator, double[] y, double[] yDot, double tEnd) {
                                                     // Delegate to super implementation for testing
                                                     return super.acceptStep(interpolator, y, yDot, tEnd);
                                                 }
                                             };
                                             
                                             // Create mock interpolator
                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                             when(interpolator.isForward()).thenReturn(true);
                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                             
                                             double[] y = new double[2];
                                             double[] yDot = new double[2];
                                             double tEnd = 1.0;
                                             
                                             // Setup event state that requests stop
                                             EventState eventState = mock(EventState.class);
                                             when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                             when(eventState.getEventTime()).thenReturn(0.5);
                                             when(eventState.stop()).thenReturn(true);
                                             
                                             // Use reflection to set eventsStates
                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                             eventsStatesField.setAccessible(true);
                                             eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                             
                                             // Use reflection to set statesInitialized to true
                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                             statesInitializedField.setAccessible(true);
                                             statesInitializedField.set(integrator, true);
                                             
                                             // Use reflection to call acceptStep
                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                             acceptStepMethod.setAccessible(true);
                                             double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                             
                                             // Verify
                                             assertEquals(0.5, result, 1e-10);
                                             assertArrayEquals(new double[]{1.0, 2.0}, y, 1e-10);
                                             
                                             // Use reflection to check isLastStep
                                             Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                             isLastStepField.setAccessible(true);
                                             assertTrue((boolean) isLastStepField.get(integrator));
                                         }

    @Test
                                         public void testAcceptStep_EventRequestsReset() throws Exception {
                                             // Setup
                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                 @Override
                                                 public void integrate(ExpandableStatefulODE equations, double t) {}
                                                 
                                                 @Override
                                                 public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                     yDot[0] = 1.0;
                                                     yDot[1] = 2.0;
                                                 }
                                             };
                                             
                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                             when(interpolator.isForward()).thenReturn(true);
                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                             
                                             double[] y = new double[2];
                                             double[] yDot = new double[2];
                                             double tEnd = 1.0;
                                             
                                             // Setup event state that requests reset
                                             EventState eventState = mock(EventState.class);
                                             when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                             when(eventState.getEventTime()).thenReturn(0.5);
                                             when(eventState.stop()).thenReturn(false);
                                             when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                             
                                             // Use reflection to set eventsStates
                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                             eventsStatesField.setAccessible(true);
                                             eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                             
                                             // Use reflection to invoke acceptStep
                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                 "acceptStep", AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                             acceptStepMethod.setAccessible(true);
                                             double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                             
                                             // Verify
                                             assertEquals(0.5, result, 1e-10);
                                             assertArrayEquals(new double[]{1.0, 2.0}, y, 1e-10);
                                             assertArrayEquals(new double[]{1.0, 2.0}, yDot, 1e-10);
                                             
                                             // Use reflection to check resetOccurred
                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                             resetOccurredField.setAccessible(true);
                                             assertTrue((boolean) resetOccurredField.get(integrator));
                                         }

    @Test
                                         public void testAcceptStep_BackwardIntegration() throws Exception {
                                             // Setup
                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                 @Override
                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                     // Empty implementation for test
                                                 }
                                             };
                                             
                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                             when(interpolator.getGlobalPreviousTime()).thenReturn(1.0);
                                             when(interpolator.getGlobalCurrentTime()).thenReturn(0.0);
                                             when(interpolator.isForward()).thenReturn(false);
                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                             
                                             double[] y = new double[2];
                                             double[] yDot = new double[2];
                                             double tEnd = 0.0;
                                             
                                             // Setup event state
                                             EventState eventState = mock(EventState.class);
                                             when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                             when(eventState.getEventTime()).thenReturn(0.5);
                                             when(eventState.stop()).thenReturn(false);
                                             when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                             
                                             // Use reflection to set private eventsStates field
                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                             eventsStatesField.setAccessible(true);
                                             eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                             
                                             // Use reflection to call protected acceptStep method
                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                 "acceptStep", 
                                                 AbstractStepInterpolator.class, 
                                                 double[].class, 
                                                 double[].class, 
                                                 double.class
                                             );
                                             acceptStepMethod.setAccessible(true);
                                             double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                             
                                             // Verify
                                             assertEquals(0.0, result, 1e-10);
                                             assertArrayEquals(new double[]{1.0, 2.0}, y, 1e-10);
                                         }

    @Test
                                         public void testAcceptStep_DetectNeedResetMutant() throws Exception {
                                             // Create concrete integrator subclass
                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                 @Override
                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                     // dummy implementation
                                                 }
                                             };
                                             
                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                             double[] y = new double[2];
                                             double[] yDot = new double[2];
                                             double tEnd = 10.0;
                                             
                                             // Configure interpolator
                                             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                             when(interpolator.isForward()).thenReturn(true);
                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 1.0});
                                             
                                             // Create event states that don't require reset
                                             EventState eventState1 = mock(EventState.class);
                                             when(eventState1.evaluateStep(interpolator)).thenReturn(false);
                                             when(eventState1.stop()).thenReturn(true); // This will set isLastStep to true
                                             when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                             
                                             EventState eventState2 = mock(EventState.class);
                                             when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                             when(eventState2.stop()).thenReturn(false);
                                             when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                             
                                             // Set up integrator state using reflection
                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                             statesInitializedField.setAccessible(true);
                                             statesInitializedField.set(integrator, true);
                                             
                                             Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                             eventStatesField.setAccessible(true);
                                             eventStatesField.set(integrator, java.util.Arrays.asList(eventState1, eventState2));
                                             
                                             Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                             stepHandlersField.setAccessible(true);
                                             stepHandlersField.set(integrator, new java.util.ArrayList<StepHandler>());
                                             
                                             // Execute the method using reflection
                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                             acceptStepMethod.setAccessible(true);
                                             double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                             
                                             // Verify behavior
                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                             resetOccurredField.setAccessible(true);
                                             boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                             
                                             assertFalse(resetOccurred);
                                             assertEquals(1.0, result, 1e-10);
                                             
                                             // Verify interactions
                                             verify(eventState1).stepAccepted(anyDouble(), any(double[].class));
                                             verify(eventState2).stepAccepted(anyDouble(), any(double[].class));
                                             verify(eventState1).stop();
                                             verify(eventState2).stop();
                                         }

    @Test
                                         public void testAcceptStepDetectsMultipleResetRequests() throws Exception {
                                             // Create concrete integrator subclass
                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                 @Override
                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                     // dummy implementation for test
                                                 }
                                             };
                                             
                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                             when(interpolator.isForward()).thenReturn(true);
                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
                                             
                                             // Create mock event states - first one needs reset, second doesn't, third needs reset
                                             EventState eventState1 = mock(EventState.class);
                                             when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                             when(eventState1.getEventTime()).thenReturn(0.5);
                                             when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                             
                                             EventState eventState2 = mock(EventState.class);
                                             when(eventState2.evaluateStep(interpolator)).thenReturn(true);
                                             when(eventState2.getEventTime()).thenReturn(0.6);
                                             when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                             
                                             EventState eventState3 = mock(EventState.class);
                                             when(eventState3.evaluateStep(interpolator)).thenReturn(true);
                                             when(eventState3.getEventTime()).thenReturn(0.7);
                                             when(eventState3.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                             
                                             // Set up integrator state using reflection
                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                             eventsStatesField.setAccessible(true);
                                             eventsStatesField.set(integrator, java.util.Arrays.asList(eventState1, eventState2, eventState3));
                                             
                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                             statesInitializedField.setAccessible(true);
                                             statesInitializedField.set(integrator, true);
                                             
                                             Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                             stepHandlersField.setAccessible(true);
                                             stepHandlersField.set(integrator, new java.util.ArrayList<>());
                                             
                                             // Test using reflection to access protected method
                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                             acceptStepMethod.setAccessible(true);
                                             double[] y = new double[1];
                                             double[] yDot = new double[1];
                                             double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                             
                                             // Verify - check resetOccurred using reflection
                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                             resetOccurredField.setAccessible(true);
                                             boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                             
                                             assertTrue("resetOccurred should be true when any event requests reset", resetOccurred);
                                             assertEquals("Should return event time", 0.5, result, 1e-10);
                                             
                                             // Verify all reset methods were called
                                             verify(eventState1).reset(0.5, any(double[].class));
                                             verify(eventState2).reset(0.5, any(double[].class));
                                             verify(eventState3).reset(0.5, any(double[].class));
                                         }

    @Test
                                     public void testAcceptStep_NeedResetInitialization() throws Exception {
                                         // Create concrete implementation of AbstractIntegrator
                                         AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                             @Override
                                             public void integrate(ExpandableStatefulODE equations, double t) {
                                                 // dummy implementation for test
                                             }
                                         };
                                         
                                         AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                         double[] y = new double[2];
                                         double[] yDot = new double[2];
                                         double tEnd = 10.0;
                                         
                                         // Configure interpolator behavior
                                         when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                         when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                         when(interpolator.isForward()).thenReturn(true);
                                         when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 1.0});
                                         
                                         // Create mock EventStates that don't require reset
                                         EventState eventState1 = mock(EventState.class);
                                         when(eventState1.evaluateStep(interpolator)).thenReturn(false);
                                         when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                         
                                         EventState eventState2 = mock(EventState.class);
                                         when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                         when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                         
                                         // Create list of event states
                                         java.util.List<EventState> eventStates = new java.util.ArrayList<>();
                                         eventStates.add(eventState1);
                                         eventStates.add(eventState2);
                                         
                                         // Use reflection to set private fields
                                         Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                         eventsStatesField.setAccessible(true);
                                         eventsStatesField.set(integrator, eventStates);
                                         
                                         Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                         statesInitializedField.setAccessible(true);
                                         statesInitializedField.set(integrator, true);
                                         
                                         Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                         resetOccurredField.setAccessible(true);
                                         resetOccurredField.set(integrator, false);
                                         
                                         // Use reflection to call protected method
                                         Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                             "acceptStep", 
                                             AbstractStepInterpolator.class, 
                                             double[].class, 
                                             double[].class, 
                                             double.class
                                         );
                                         acceptStepMethod.setAccessible(true);
                                         double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                         
                                         // Verify behavior
                                         assertEquals(1.0, result, 1e-10);
                                         assertFalse("resetOccurred should remain false when no events require reset", 
                                                    (boolean) resetOccurredField.get(integrator));
                                         
                                         // Verify event state interactions
                                         verify(eventState1, times(1)).reset(anyDouble(), any(double[].class));
                                         verify(eventState2, times(1)).reset(anyDouble(), any(double[].class));
                                     }

    @Test
                                public void testAcceptStep_DetectsResetWithCorrectEventTime() {
                                    // Setup test data
                                    double previousT = 0.0;
                                    double currentT = 1.0;
                                    double eventT = 0.5;
                                    
                                    // Create mock interpolator
                                    AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                    when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                    when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                    when(interpolator.isForward()).thenReturn(true);
                                    
                                    // Create mock event state that will trigger reset
                                    EventState eventState = mock(EventState.class);
                                    when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                    when(eventState.getEventTime()).thenReturn(eventT);
                                    when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                    
                                    // Create test integrator subclass that exposes protected method
                                    class TestIntegrator extends AbstractIntegrator {
                                        public TestIntegrator() {
                                            super("test");
                                        }
                                        
                                        @Override
                                        public void integrate(ExpandableStatefulODE equations, double t) {
                                            // dummy implementation
                                        }
                                        
                                        public double callAcceptStep(AbstractStepInterpolator interpolator, 
                                                                   double[] y, double[] yDot, double tEnd) {
                                            return acceptStep(interpolator, y, yDot, tEnd);
                                        }
                                    }
                                    
                                    TestIntegrator integrator = new TestIntegrator();
                                    
                                    // Set private fields via reflection
                                    try {
                                        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                        eventsStatesField.setAccessible(true);
                                        Collection<EventState> eventsStates = new ArrayList<>();
                                        eventsStates.add(eventState);
                                        eventsStatesField.set(integrator, eventsStates);
                                        
                                        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                        statesInitializedField.setAccessible(true);
                                        statesInitializedField.set(integrator, true);
                                    } catch (Exception e) {
                                        fail("Failed to set up test via reflection: " + e.getMessage());
                                    }
                                    
                                    // Test parameters
                                    double[] y = new double[1];
                                    double[] yDot = new double[1];
                                    double tEnd = 2.0;
                                    
                                    // Execute test
                                    integrator.callAcceptStep(interpolator, y, yDot, tEnd);
                                    
                                    // Verify reset was called with correct event time (eventT) not currentT
                                    verify(eventState).reset(eq(eventT), any(double[].class));
                                    verify(eventState, never()).reset(eq(currentT), any(double[].class));
                                    
                                    // Additional verification that reset occurred flag was set
                                    try {
                                        Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                        resetOccurredField.setAccessible(true);
                                        assertTrue((boolean) resetOccurredField.get(integrator));
                                    } catch (Exception e) {
                                        fail("Failed to verify resetOccurred: " + e.getMessage());
                                    }
                                }

    @Test
                       public void testAcceptStep_ShouldNotResetWhenNoEventNeedsReset() throws Exception {
                           // Setup test data and mocks
                           AbstractIntegrator integrator = new AbstractIntegrator("test") {
                               @Override
                               public void integrate(ExpandableStatefulODE equations, double t) {
                                   // dummy implementation
                               }
                           };
                           
                           // Create mock interpolator
                           AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                           when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                           when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                           when(interpolator.isForward()).thenReturn(true);
                           when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                           
                           // Create mock event states that don't need reset
                           EventState eventState1 = mock(EventState.class);
                           when(eventState1.evaluateStep(interpolator)).thenReturn(false);
                           when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                           
                           EventState eventState2 = mock(EventState.class);
                           when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                           when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                           
                           // Set up integrator state using reflection
                           Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                           eventsStatesField.setAccessible(true);
                           eventsStatesField.set(integrator, java.util.Arrays.asList(eventState1, eventState2));
                           
                           Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                           statesInitializedField.setAccessible(true);
                           statesInitializedField.set(integrator, true);
                           
                           Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                           resetOccurredField.setAccessible(true);
                           resetOccurredField.set(integrator, false);
                           
                           // Test parameters
                           double[] y = new double[]{0.0};
                           double[] yDot = new double[]{0.0};
                           double tEnd = 2.0;
                           
                           // Execute through reflection since acceptStep is protected
                           Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                               AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                           acceptStepMethod.setAccessible(true);
                           double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                           
                           // Verify
                           assertFalse("resetOccurred should be false when no events need reset", 
                                      (boolean) resetOccurredField.get(integrator));
                           assertEquals("Method should complete full step", 1.0, result, 1e-10);
                           
                           // Verify derivatives weren't recomputed unnecessarily
                           assertEquals("Derivatives should not be recomputed", 
                                       0.0, yDot[0], 1e-10);
                       }

    @Test
                  public void testComputeDerivativesCalledWithCorrectTimeAfterEventReset() throws Exception {
                      // Setup test data
                      double previousT = 0.0;
                      double eventT = 0.5;
                      double currentT = 1.0;
                      double tEnd = 1.0;
                      double[] y = new double[]{1.0};
                      double[] yDot = new double[]{0.0};
                      
                      // Mock interpolator
                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                      when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                      when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                      when(interpolator.isForward()).thenReturn(true);
                      when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                      
                      // Create test integrator subclass to expose protected methods
                      class TestIntegrator extends AbstractIntegrator {
                          boolean resetOccurred = false;
                          
                          public TestIntegrator() {
                              super("test");
                          }
                          
                          @Override
                          public void integrate(ExpandableStatefulODE equations, double t) {
                              // Not used in this test
                          }
                          
                          @Override
                          public void computeDerivatives(double t, double[] y, double[] yDot) {
                              // Verify this is called with eventT, not currentT
                              assertEquals("Derivatives should be computed at event time", eventT, t, 1e-10);
                              yDot[0] = -y[0]; // Simple derivative for testing
                          }
                          
                          public double callAcceptStep(AbstractStepInterpolator interpolator, double[] y, double[] yDot, double tEnd) {
                              return acceptStep(interpolator, y, yDot, tEnd);
                          }
                          
                          public boolean getResetOccurred() {
                              return resetOccurred;
                          }
                      }
                      
                      TestIntegrator integrator = new TestIntegrator();
                      
                      // Setup event state that will trigger reset
                      EventState eventState = mock(EventState.class);
                      when(eventState.evaluateStep(interpolator)).thenReturn(true);
                      when(eventState.getEventTime()).thenReturn(eventT);
                      when(eventState.reset(eventT, any(double[].class))).thenReturn(true);
                      
                      // Add the event state to the integrator
                      integrator.addEventHandler(new EventHandler() {
                          @Override
                          public void init(double t0, double[] y0, double t) {}
                          
                          @Override
                          public double g(double t, double[] y) {
                              return 0;
                          }
                          
                          @Override
                          public Action eventOccurred(double t, double[] y, boolean increasing) {
                              return Action.RESET_STATE;
                          }
                          
                          @Override
                          public void resetState(double t, double[] y) {}
                      }, 1.0, 1e-6, 10);
                      
                      // Call the method under test through the exposed method
                      double result = integrator.callAcceptStep(interpolator, y, yDot, tEnd);
                      
                      // Verify the event time was returned
                      assertEquals(eventT, result, 1e-10);
                      assertTrue(integrator.getResetOccurred());
                  }

    @Test
             public void testAcceptStepDetectsComputeDerivativesMutant() throws Exception {
                 // Setup test data with different y and eventY arrays
                 double[] y = new double[]{1.0, 2.0};
                 double[] yDot = new double[]{0.0, 0.0};
                 double[] eventY = new double[]{3.0, 4.0};
                 
                 // Create mock interpolator
                 AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                 when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                 when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                 when(interpolator.isForward()).thenReturn(true);
                 when(interpolator.getInterpolatedState()).thenReturn(eventY);
                 
                 // Create mock EventState that triggers reset
                 EventState eventState = mock(EventState.class);
                 when(eventState.evaluateStep(interpolator)).thenReturn(true);
                 when(eventState.getEventTime()).thenReturn(0.5);
                 when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                 
                 // Setup test integrator
                 AbstractIntegrator integrator = new AbstractIntegrator("test") {
                     @Override
                     public void integrate(ExpandableStatefulODE equations, double t) {
                         // Not used in this test
                     }
                 };
                 
                 // Spy on the integrator to verify computeDerivatives calls
                 AbstractIntegrator spyIntegrator = spy(integrator);
                 
                 // Set up event states using reflection
                 Collection<EventState> eventsStates = new ArrayList<>();
                 eventsStates.add(eventState);
                 Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                 eventsStatesField.setAccessible(true);
                 eventsStatesField.set(spyIntegrator, eventsStates);
                 
                 // Set up step handlers using reflection
                 Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                 stepHandlersField.setAccessible(true);
                 stepHandlersField.set(spyIntegrator, new ArrayList<>());
                 
                 // Call the method using reflection
                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                     "acceptStep", AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                 acceptStepMethod.setAccessible(true);
                 acceptStepMethod.invoke(spyIntegrator, interpolator, y, yDot, 1.0);
                 
                 // Verify computeDerivatives was called with correct arguments
                 verify(spyIntegrator).computeDerivatives(eq(0.5), eq(y), eq(yDot));
                 
                 // Additional verification that reset occurred using reflection
                 Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                 resetOccurredField.setAccessible(true);
                 assertTrue((Boolean) resetOccurredField.get(spyIntegrator));
             }

    @Test
    public void testAcceptStepDetectsResetOccurredMutation() throws Exception {
        // Setup test environment
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // dummy implementation for testing
            }
        };
        
        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
        
        // Create event states where one requires reset
        EventState resetEvent = mock(EventState.class);
        when(resetEvent.evaluateStep(interpolator)).thenReturn(true);
        when(resetEvent.getEventTime()).thenReturn(0.5);
        when(resetEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
        
        EventState noResetEvent = mock(EventState.class);
        when(noResetEvent.evaluateStep(interpolator)).thenReturn(true);
        when(noResetEvent.getEventTime()).thenReturn(0.6);
        when(noResetEvent.reset(anyDouble(), any(double[].class))).thenReturn(false);
        
        // Set up integrator state using reflection
        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
        eventsStatesField.setAccessible(true);
        eventsStatesField.set(integrator, java.util.Arrays.asList(resetEvent, noResetEvent));
        
        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
        statesInitializedField.setAccessible(true);
        statesInitializedField.set(integrator, false);
        
        Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
        resetOccurredField.setAccessible(true);
        resetOccurredField.set(integrator, false);
        
        // Test data
        double[] y = new double[1];
        double[] yDot = new double[1];
        
        // Execute using reflection
        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
            AbstractStepInterpolator.class, double[].class, double[].class, double.class);
        acceptStepMethod.setAccessible(true);
        acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
        
        // Verify resetOccurred was set to true
        assertTrue("resetOccurred should be true when any event requests reset", 
                   (boolean) resetOccurredField.get(integrator));
        
        // Additional verification that the reset was properly handled
        verify(resetEvent).stepAccepted(0.5, any(double[].class));
        verify(noResetEvent).stepAccepted(0.5, any(double[].class));
        verify(interpolator).setSoftPreviousTime(0.0);
        verify(interpolator).setSoftCurrentTime(0.5);
    }


}
