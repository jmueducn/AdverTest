package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class MathArraysTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                  public void testLinearCombination_SingleElementArrays() {
                                                      double[] a = {2.5};
                                                      double[] b = {3.0};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(7.5, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_TwoElementArrays() {
                                                      double[] a = {1.0, 2.0};
                                                      double[] b = {3.0, 4.0};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(11.0, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_MultipleElementArrays() {
                                                      double[] a = {1.0, 2.0, 3.0, 4.0};
                                                      double[] b = {5.0, 6.0, 7.0, 8.0};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(70.0, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_ArraysWithNegativeValues() {
                                                      double[] a = {-1.0, 2.0, -3.0};
                                                      double[] b = {4.0, -5.0, 6.0};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(-32.0, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_ArraysWithZeroValues() {
                                                      double[] a = {0.0, 0.0, 0.0};
                                                      double[] b = {1.0, 2.0, 3.0};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(0.0, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_ArraysWithLargeValues() {
                                                      double[] a = {1e100, 2e100, 3e100};
                                                      double[] b = {4e100, 5e100, 6e100};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(32e100, result, 1e185);
                                                  }

 @Test
                                                  public void testLinearCombination_ArraysWithSmallValues() {
                                                      double[] a = {1e-100, 2e-100, 3e-100};
                                                      double[] b = {4e-100, 5e-100, 6e-100};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(32e-100, result, 1e-115);
                                                  }

 @Test
                                                  public void testLinearCombination_ArraysWithNaNValues() {
                                                      double[] a = {1.0, Double.NaN, 3.0};
                                                      double[] b = {4.0, 5.0, 6.0};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(1.0*4.0 + 3.0*6.0, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_ArraysWithInfiniteValues() {
                                                      double[] a = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                      double[] b = {4.0, 5.0, 6.0};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(1.0*4.0 + Double.POSITIVE_INFINITY*5.0 + 3.0*6.0, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_DimensionMismatch() {
                                                      double[] a = {1.0, 2.0, 3.0};
                                                      double[] b = {4.0, 5.0};
                                                      
                                                      thrown.expect(DimensionMismatchException.class);
                                                      thrown.expectMessage("3 != 2");
                                                      MathArrays.linearCombination(a, b);
                                                  }

 @Test
                                                  public void testLinearCombination_EmptyArrays() {
                                                      double[] a = {};
                                                      double[] b = {};
                                                      
                                                      thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                      MathArrays.linearCombination(a, b);
                                                  }

 @Test
                                                  public void testLinearCombination_AccuracyCheck() {
                                                      // Test accuracy with values that would cause cancellation in naive implementation
                                                      double[] a = {1.0, 1.0};
                                                      double[] b = {1.0 + 1e-17, 1.0 - 1e-17};
                                                      double result = MathArrays.linearCombination(a, b);
                                                      assertEquals(2.0, result, 1e-30);
                                                  }

 @Test
                                                  public void testLinearCombination_TypicalValues() {
                                                      // Test with typical positive values
                                                      double result1 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0);
                                                      assertEquals(1.0 * 2.0 + 3.0 * 4.0, result1, 1e-15);
                                              
                                                      // Test with mixed positive and negative values
                                                      double result2 = MathArrays.linearCombination(-1.0, 2.0, 3.0, -4.0);
                                                      assertEquals(-1.0 * 2.0 + 3.0 * -4.0, result2, 1e-15);
                                              
                                                      // Test with very small values
                                                      double result3 = MathArrays.linearCombination(1e-20, 2e-20, 3e-20, 4e-20);
                                                      assertEquals(1e-20 * 2e-20 + 3e-20 * 4e-20, result3, 1e-35);
                                                  }

 @Test
                                                  public void testLinearCombination_EdgeCases() {
                                                      // Test with zeros
                                                      double result1 = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0);
                                                      assertEquals(0.0, result1, 0.0);
                                              
                                                      // Test with one zero pair
                                                      double result2 = MathArrays.linearCombination(1.0, 2.0, 0.0, 0.0);
                                                      assertEquals(1.0 * 2.0, result2, 1e-15);
                                              
                                                      // Test with very large values
                                                      double result3 = MathArrays.linearCombination(Double.MAX_VALUE, 1.0, -Double.MAX_VALUE, 1.0);
                                                      assertEquals(0.0, result3, 1e-15);
                                              
                                                      // Test with values near Double.MIN_VALUE
                                                      double result4 = MathArrays.linearCombination(Double.MIN_VALUE, Double.MIN_VALUE, 
                                                                                                   Double.MIN_VALUE, Double.MIN_VALUE);
                                                      assertEquals(2 * Double.MIN_VALUE * Double.MIN_VALUE, result4, 1e-300);
                                                  }

 @Test
                                                  public void testLinearCombination_SpecialValues() {
                                                      // Test with NaN values
                                                      double result1 = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0);
                                                      assertTrue(Double.isNaN(result1));
                                              
                                                      // Test with infinite values
                                                      double result2 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 2.0, 3.0);
                                                      assertEquals(Double.POSITIVE_INFINITY, result2, 0.0);
                                              
                                                      // Test with combination of infinite values that would cancel out
                                                      double result3 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                                  Double.NEGATIVE_INFINITY, 1.0);
                                                      assertTrue(Double.isNaN(result3));
                                              
                                                      // Test with overflow scenario
                                                      double result4 = MathArrays.linearCombination(Double.MAX_VALUE, 2.0, Double.MAX_VALUE, 2.0);
                                                      assertEquals(Double.POSITIVE_INFINITY, result4, 0.0);
                                                  }

 @Test
                                                  public void testLinearCombination_Precision() {
                                                      // Test precision with values that would normally lose precision
                                                      double a1 = 1.0000000000000001;
                                                      double b1 = 1.0000000000000002;
                                                      double a2 = 1.0000000000000003;
                                                      double b2 = 1.0000000000000004;
                                                      
                                                      double naiveResult = a1 * b1 + a2 * b2;
                                                      double preciseResult = MathArrays.linearCombination(a1, b1, a2, b2);
                                                      
                                                      // The precise result should be more accurate than the naive calculation
                                                      double expected = 2.0000000000000006;
                                                      assertTrue(Math.abs(preciseResult - expected) < Math.abs(naiveResult - expected));
                                                  }

 @Test
                                                  public void testLinearCombination_Cancellation() {
                                                      // Test cases where significant cancellation occurs
                                                      double a1 = 1e18;
                                                      double b1 = 1.0;
                                                      double a2 = 1.0;
                                                      double b2 = -1e18;
                                                      
                                                      // Naive computation would lose all precision
                                                      double naiveResult = a1 * b1 + a2 * b2;
                                                      double preciseResult = MathArrays.linearCombination(a1, b1, a2, b2);
                                                      
                                                      // The precise result should maintain accuracy
                                                      assertEquals(0.0, preciseResult, 1e-15);
                                                      assertNotEquals(naiveResult, preciseResult, 0.0);
                                                  }

 @Test
                                                  public void testLinearCombination_TypicalValues1() {
                                                      double result = MathArrays.linearCombination(2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                                      assertEquals(2.0*3.0 + 4.0*5.0 + 6.0*7.0, result, 1e-15);
                                                      
                                                      result = MathArrays.linearCombination(1.5, -2.5, 3.5, -4.5, 5.5, -6.5);
                                                      assertEquals(1.5*-2.5 + 3.5*-4.5 + 5.5*-6.5, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_ZeroValues() {
                                                      double result = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                                      assertEquals(0.0, result, 0.0);
                                                      
                                                      result = MathArrays.linearCombination(1.0, 0.0, 0.0, 2.0, 3.0, 0.0);
                                                      assertEquals(0.0 + 0.0 + 0.0, result, 0.0);
                                                  }

 @Test
                                                  public void testLinearCombination_LargeValues() {
                                                      double large = 1e100;
                                                      double result = MathArrays.linearCombination(large, large, large, large, large, large);
                                                      assertEquals(3 * large * large, result, 1e85); // Relaxed delta due to magnitude
                                                      
                                                      result = MathArrays.linearCombination(large, -large, large, large, -large, large);
                                                      assertEquals(large * -large + large * large + -large * large, result, 1e85);
                                                  }

 @Test
                                                  public void testLinearCombination_SmallValues() {
                                                      double small = 1e-100;
                                                      double result = MathArrays.linearCombination(small, small, small, small, small, small);
                                                      assertEquals(3 * small * small, result, 1e-115);
                                                  }

 @Test
                                                  public void testLinearCombination_MixedMagnitudes() {
                                                      double large = 1e100;
                                                      double small = 1e-100;
                                                      double result = MathArrays.linearCombination(large, small, 1.0, 1.0, small, large);
                                                      assertEquals(large*small + 1.0*1.0 + small*large, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_NaNValues() {
                                                      double nan = Double.NaN;
                                                      double result = MathArrays.linearCombination(nan, 1.0, 2.0, 3.0, 4.0, 5.0);
                                                      assertTrue(Double.isNaN(result));
                                                      
                                                      result = MathArrays.linearCombination(1.0, 2.0, nan, 3.0, 4.0, 5.0);
                                                      assertTrue(Double.isNaN(result));
                                                      
                                                      result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, nan, 5.0);
                                                      assertTrue(Double.isNaN(result));
                                                  }

 @Test
                                                  public void testLinearCombination_InfiniteValues() {
                                                      double inf = Double.POSITIVE_INFINITY;
                                                      double result = MathArrays.linearCombination(inf, 1.0, 2.0, 3.0, 4.0, 5.0);
                                                      assertEquals(inf * 1.0 + 2.0 * 3.0 + 4.0 * 5.0, result, 0.0);
                                                      
                                                      result = MathArrays.linearCombination(1.0, inf, 2.0, 3.0, 4.0, 5.0);
                                                      assertEquals(1.0 * inf + 2.0 * 3.0 + 4.0 * 5.0, result, 0.0);
                                                      
                                                      result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, inf, -inf);
                                                      assertTrue(Double.isNaN(result)); // Infinity - Infinity is NaN
                                                  }

 @Test
                                                  public void testLinearCombination_CancellationEffects() {
                                                      double a = 1.000000000000001;
                                                      double b = 1.000000000000002;
                                                      double result = MathArrays.linearCombination(a, 1.0, -b, 1.0, 1.0, 1.0);
                                                      double expected = (a - b) + 1.0;
                                                      assertEquals(expected, result, 1e-15);
                                                  }

 @Test
                                                  public void testLinearCombination_Precision1() {
                                                      // Values chosen to cause cancellation in naive implementation
                                                      double a1 = 1.000000000000001;
                                                      double b1 = 1.000000000000002;
                                                      double a2 = 1.000000000000003;
                                                      double b2 = 1.000000000000004;
                                                      double a3 = 1.000000000000005;
                                                      double b3 = 1.000000000000006;
                                                      
                                                      double naive = a1*b1 + a2*b2 + a3*b3;
                                                      double precise = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
                                                      
                                                      // The precise version should be more accurate than naive
                                                      double exact = 3.000000000000021; // Calculated with higher precision
                                                      assertTrue(Math.abs(precise - exact) < Math.abs(naive - exact));
                                                  }

 @Test
                                                  public void testLinearCombination_NaNHandling() {
                                                      // Test with NaN in first pair
                                                      double result = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                                      assertTrue(Double.isNaN(result));
                                                      
                                                      // Test with NaN in middle pair
                                                      result = MathArrays.linearCombination(1.0, 2.0, Double.NaN, 3.0, 4.0, 5.0, 6.0, 7.0);
                                                      assertTrue(Double.isNaN(result));
                                                      
                                                      // Test with NaN in last pair
                                                      result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, Double.NaN, 7.0);
                                                      assertTrue(Double.isNaN(result));
                                                  }

 @Test
                                          public void testLinearCombination_TypicalValues2() {
                                              // Define precision constant
                                              final double EPSILON = 1.0e-15;
                                              
                                              // Test with typical positive values
                                              double result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);
                                              assertEquals(1.0*2.0 + 3.0*4.0 + 5.0*6.0 + 7.0*8.0, result, EPSILON);
                                              
                                              // Test with mixed positive and negative values
                                              result = MathArrays.linearCombination(-1.0, 2.0, 3.0, -4.0, -5.0, -6.0, 7.0, 8.0);
                                              assertEquals(-1.0*2.0 + 3.0*-4.0 + -5.0*-6.0 + 7.0*8.0, result, EPSILON);
                                          }

 @Test
                                          public void testLinearCombination_ExtremeValues() {
                                              // Define epsilon for double precision comparison
                                              final double EPSILON = 1e-15;
                                              
                                              // Test with very large values
                                              double large = 1e100;
                                              double result = MathArrays.linearCombination(large, large, large, large, large, large, large, large);
                                              assertEquals(4 * large * large, result, large * EPSILON);
                                              
                                              // Test with very small values
                                              double small = 1e-100;
                                              result = MathArrays.linearCombination(small, small, small, small, small, small, small, small);
                                              assertEquals(4 * small * small, result, EPSILON);
                                          }

 @Test
                                          public void testLinearCombination_ZeroValues1() {
                                              // Define epsilon for floating point comparison
                                              final double EPSILON = 1e-15;
                                              
                                              // Test with all zeros
                                              double result = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                              assertEquals(0.0, result, EPSILON);
                                              
                                              // Test with some zeros
                                              result = MathArrays.linearCombination(1.0, 0.0, 0.0, 2.0, 3.0, 0.0, 0.0, 4.0);
                                              assertEquals(1.0*0.0 + 0.0*2.0 + 3.0*0.0 + 0.0*4.0, result, EPSILON);
                                          }

 @Test
                                          public void testLinearCombination_InfiniteValues1() {
                                              // Define epsilon for floating-point comparisons
                                              final double EPSILON = 1e-15;
                                              
                                              // Test with positive infinity
                                              double result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                              assertEquals(Double.POSITIVE_INFINITY, result, EPSILON);
                                              
                                              // Test with negative infinity
                                              result = MathArrays.linearCombination(1.0, Double.NEGATIVE_INFINITY, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                              assertEquals(Double.NEGATIVE_INFINITY, result, EPSILON);
                                              
                                              // Test with mixed infinities that should cancel out
                                              result = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY, 1.0, Double.NEGATIVE_INFINITY, 
                                                                                   1.0, Double.POSITIVE_INFINITY, 1.0, Double.NEGATIVE_INFINITY);
                                              assertTrue(Double.isNaN(result));
                                          }

 @Test
                                          public void testLinearCombination_Precision2() {
                                              // Define precision constant
                                              final double EPSILON = 1e-20;
                                              
                                              // Test precision with values that would normally cause cancellation
                                              double a = 1e18;
                                              double b = 1e-18;
                                              double result = MathArrays.linearCombination(a, b, -a, b, a, b, -a, b);
                                              // The exact result should be 0, but naive computation would lose precision
                                              assertEquals(0.0, result, EPSILON);
                                              
                                              // Test with values that would normally cause overflow
                                              double large = 1e100;
                                              result = MathArrays.linearCombination(large, large, -large, large, large, large, -large, large);
                                              assertEquals(0.0, result, large * EPSILON);
                                          }

 @Test
                                          public void testLinearCombination_Cancellation1() {
                                              // Test cancellation of large terms
                                              double big = 1e20;
                                              double small = 1e-20;
                                              double result = MathArrays.linearCombination(big, big, -big, big, small, small, -small, small);
                                              // Should be exactly 0, but naive computation would lose the small terms
                                              double epsilon = 1e-30; // Define epsilon locally for the test
                                              assertEquals(0.0, result, epsilon);
                                          }

 @Test
  public void testLinearCombinationArraySizeMutation() {
      // Test with arrays of length 2 to expose any boundary issues
      double[] a = {1.0, 2.0};
      double[] b = {3.0, 4.0};
      
      // Calculate expected result manually
      double expected = 0;
      for (int i = 0; i < a.length; i++) {
          expected += a[i] * b[i];
      }
      
      // Test with normal values
      double result = MathArrays.linearCombination(a, b);
      assertEquals(expected, result, 1e-15);
      
      // Test with edge case values that might expose array boundary issues
      double[] edgeA = {Double.MAX_VALUE, Double.MIN_VALUE};
      double[] edgeB = {Double.MIN_VALUE, Double.MAX_VALUE};
      double edgeExpected = edgeA[0] * edgeB[0] + edgeA[1] * edgeB[1];
      double edgeResult = MathArrays.linearCombination(edgeA, edgeB);
      assertEquals(edgeExpected, edgeResult, 1e-15);
      
      // Test with NaN values to ensure proper handling
      double[] nanA = {Double.NaN, 1.0};
      double[] nanB = {1.0, Double.NaN};
      double nanResult = MathArrays.linearCombination(nanA, nanB);
      assertTrue(Double.isNaN(nanResult));
      
      // Test with larger arrays to ensure no array bounds issues
      double[] largeA = {1.0, 2.0, 3.0, 4.0, 5.0};
      double[] largeB = {6.0, 7.0, 8.0, 9.0, 10.0};
      double largeExpected = 0;
      for (int i = 0; i < largeA.length; i++) {
          largeExpected += largeA[i] * largeB[i];
      }
      double largeResult = MathArrays.linearCombination(largeA, largeB);
      assertEquals(largeExpected, largeResult, 1e-15);
  }

 @Test
      public void testLinearCombinationArraySize() {
          // Test with array length 2 (minimum for this method)
          double[] a = {1.0, 2.0};
          double[] b = {3.0, 4.0};
          
          // Calculate expected result using simple multiplication
          double expected = a[0]*b[0] + a[1]*b[1];
          
          // Call the method and verify result
          double result = MathArrays.linearCombination(a, b);
          assertEquals(expected, result, 1e-15);
          
          // The mutation would create an array of size 3 instead of 2,
          // which could be detected by checking array bounds behavior
          // or memory usage, but in Java this is harder to test directly.
          // Instead, we can test with very large arrays to see if the
          // mutation affects performance or causes memory issues
          
          // Test with larger arrays
          double[] largeA = new double[10000];
          double[] largeB = new double[10000];
          for (int i = 0; i < largeA.length; i++) {
              largeA[i] = i;
              largeB[i] = i;
          }
          
          // The mutated version would allocate 10001 elements instead of 10000
          // While this won't break functionality, it's detectable through
          // memory monitoring or performance testing
          double largeResult = MathArrays.linearCombination(largeA, largeB);
          double largeExpected = 0;
          for (int i = 0; i < largeA.length; i++) {
              largeExpected += largeA[i] * largeB[i];
          }
          assertEquals(largeExpected, largeResult, 1e-10);
      }

 @Test
  public void testLinearCombinationArrayBoundaryConditions() {
      // Test with minimum array length (1)
      double[] a1 = {1.0};
      double[] b1 = {2.0};
      double expected1 = 2.0; // 1.0 * 2.0
      assertEquals(expected1, MathArrays.linearCombination(a1, b1), 1e-15);
      
      // Test with typical array length (3)
      double[] a2 = {1.0, 2.0, 3.0};
      double[] b2 = {4.0, 5.0, 6.0};
      double expected2 = 32.0; // 1*4 + 2*5 + 3*6
      assertEquals(expected2, MathArrays.linearCombination(a2, b2), 1e-15);
      
      // Test with larger array length (5)
      double[] a3 = {1.0, 2.0, 3.0, 4.0, 5.0};
      double[] b3 = {6.0, 7.0, 8.0, 9.0, 10.0};
      double expected3 = 130.0; // 1*6 + 2*7 + 3*8 + 4*9 + 5*10
      assertEquals(expected3, MathArrays.linearCombination(a3, b3), 1e-15);
      
      // Test with empty arrays (should throw exception)
      double[] a4 = {};
      double[] b4 = {};
      try {
          MathArrays.linearCombination(a4, b4);
          fail("Expected IllegalArgumentException for empty arrays");
      } catch (IllegalArgumentException e) {
          // Expected behavior
      }
      
      // Test with arrays of different lengths
      double[] a5 = {1.0, 2.0};
      double[] b5 = {3.0};
      try {
          MathArrays.linearCombination(a5, b5);
          fail("Expected IllegalArgumentException for different length arrays");
      } catch (IllegalArgumentException e) {
          // Expected behavior
      }
  }

 @Test
      public void testLinearCombinationArraySize1() {
          // Test with values that would expose array size issues
          double a1 = 1.234567890123456;
          double b1 = 9.876543210987654;
          double a2 = 2.345678901234567;
          double b2 = 8.765432109876543;
          double a3 = 3.456789012345678;
          double b3 = 7.654321098765432;
          double a4 = 4.567890123456789;
          double b4 = 6.543210987654321;
          
          // Calculate expected result using simple multiplication
          double expected = a1 * b1 + a2 * b2 + a3 * b3 + a4 * b4;
          
          // Call the method and verify result
          double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
          
          // Verify the result is accurate (should be very close to expected)
          assertEquals(expected, result, 1e-15);
          
          // Test with NaN values to trigger the fallback path
          double nanResult = MathArrays.linearCombination(Double.NaN, b1, a2, b2, a3, b3, a4, b4);
          assertTrue(Double.isNaN(nanResult));
          
          // Test with very large numbers that could expose array bounds issues
          double large1 = Double.MAX_VALUE;
          double large2 = Double.MAX_VALUE / 2;
          double largeResult = MathArrays.linearCombination(large1, large1, large2, large2, 
                                                            -large1, -large1, -large2, -large2);
          assertEquals(0.0, largeResult, 0.0);
          
          // Test with very small numbers that need precise handling
          double small1 = Double.MIN_VALUE;
          double small2 = Double.MIN_NORMAL;
          double smallResult = MathArrays.linearCombination(small1, small1, small2, small2, 
                                                           small1, small1, small2, small2);
          assertEquals(2 * (small1 * small1 + small2 * small2), smallResult, 1e-30);
      }

 @Test
 public void testLinearCombinationProdLowSumInitialization() {
     // Setup test data that won't trigger NaN fallback
     double[] a = {1.0, 2.0, 3.0};
     double[] b = {4.0, 5.0, 6.0};
     
     // Expected result: 1*4 + 2*5 + 3*6 = 4 + 10 + 18 = 32
     double expected = 32.0;
     
     // Call the method
     double result = MathArrays.linearCombination(a, b);
     
     // Verify the result is not NaN and matches expected value
     assertFalse("Result should not be NaN", Double.isNaN(result));
     assertEquals("Linear combination result incorrect", 
                 expected, result, 1e-15);
     
     // Additional verification that prodLowSum was properly accumulated
     // by checking the result is numerically precise
     double naiveResult = 0;
     for (int i = 0; i < a.length; i++) {
         naiveResult += a[i] * b[i];
     }
     assertEquals("High precision result should match naive computation", 
                 naiveResult, result, 1e-15);
 }

 @Test
     public void testLinearCombinationDoesNotProduceNaNWithValidInput() {
         // Test with normal values that shouldn't produce NaN
         double a1 = 1.23456789;
         double b1 = 9.87654321;
         double a2 = 2.34567891;
         double b2 = 8.76543219;
         
         // Calculate expected value using simple arithmetic
         double expected = a1 * b1 + a2 * b2;
         
         // Call the method
         double result = MathArrays.linearCombination(a1, b1, a2, b2);
         
         // Verify the result is not NaN and matches expected within reasonable tolerance
         assertFalse("Result should not be NaN", Double.isNaN(result));
         assertEquals("Result should match expected linear combination", 
                     expected, result, 1e-15);
         
         // Additional verification that we're not just hitting the NaN fallback case
         // The result should be more precise than simple multiplication
         double simpleResult = a1 * b1 + a2 * b2;
         assertNotEquals("Result should be more precise than simple multiplication",
                       simpleResult, result);
     }

 @Test
     public void testLinearCombinationWithLowPrecisionComponents() {
         // These values are chosen to:
         // 1. Have significant low-precision components
         // 2. Not produce NaN through normal operations
         // 3. Show difference between precise and simple calculation
         double a1 = 1.0000000000000002;
         double b1 = 1.0000000000000004;
         double a2 = 1.0000000000000006;
         double b2 = 1.0000000000000008;
         double a3 = 1.0000000000000010;
         double b3 = 1.0000000000000012;
         
         // Calculate expected value using simple multiplication
         double naiveResult = a1 * b1 + a2 * b2 + a3 * b3;
         
         // Call the method under test
         double result = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
         
         // Verify:
         // 1. Result is not NaN (would happen if mutation propagated NaN)
         assertFalse(Double.isNaN(result));
         
         // 2. Result is different from naive calculation (shows precision was maintained)
         assertNotEquals(naiveResult, result, 0.0);
         
         // 3. Verify the precise calculation was used by checking against expected value
         // The expected value here is precomputed from the algorithm's expected behavior
         double expected = 3.0000000000000044;
         assertEquals(expected, result, 1e-16);
     }

 @Test
     public void testLinearCombinationWithLowPrecisionParts() {
         // These values are chosen to have significant low-precision parts
         // that would be affected by the prodLowSum initialization
         double a1 = 1.0000000000000002;
         double b1 = 1.0000000000000004;
         double a2 = 1.0000000000000006;
         double b2 = 1.0000000000000008;
         double a3 = 1.0000000000000010;
         double b3 = 1.0000000000000012;
         double a4 = 1.0000000000000014;
         double b4 = 1.0000000000000016;
         
         // Calculate expected value using the naive implementation
         double expected = a1 * b1 + a2 * b2 + a3 * b3 + a4 * b4;
         
         // Call the method under test
         double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
         
         // The mutant would return NaN here because of the NaN in the sum
         // The original would return a finite number close to expected but more precise
         assertFalse("Result should not be NaN", Double.isNaN(actual));
         
         // Verify the result is close to expected but not exactly equal
         // (since the method should be more precise than naive implementation)
         assertEquals("Result should be close to naive implementation", 
                    expected, actual, 1e-15);
         assertNotEquals("Result should not exactly equal naive implementation",
                       expected, actual);
     }

}
