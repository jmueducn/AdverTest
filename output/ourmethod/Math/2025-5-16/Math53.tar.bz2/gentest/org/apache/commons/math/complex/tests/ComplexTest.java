package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
             public void testAdd_TypicalValues() {
                 Complex c1 = new Complex(3.0, 4.0);
                 Complex c2 = new Complex(1.0, 2.0);
                 Complex result = c1.add(c2);
                 
                 assertEquals(4.0, result.getReal(), 0.0001);
                 assertEquals(6.0, result.getImaginary(), 0.0001);
                 assertFalse(result.isNaN());
                 assertFalse(result.isInfinite());
             }

 @Test
             public void testAdd_WithNegativeValues() {
                 Complex c1 = new Complex(-3.0, -4.0);
                 Complex c2 = new Complex(1.0, 2.0);
                 Complex result = c1.add(c2);
                 
                 assertEquals(-2.0, result.getReal(), 0.0001);
                 assertEquals(-2.0, result.getImaginary(), 0.0001);
             }

 @Test
             public void testAdd_WithZeroValues() {
                 Complex c1 = new Complex(0.0, 0.0);
                 Complex c2 = new Complex(0.0, 0.0);
                 Complex result = c1.add(c2);
                 
                 assertEquals(0.0, result.getReal(), 0.0001);
                 assertEquals(0.0, result.getImaginary(), 0.0001);
             }

 @Test
             public void testAdd_WithNaN() {
                 Complex c1 = new Complex(Double.NaN, 4.0);
                 Complex c2 = new Complex(1.0, 2.0);
                 Complex result = c1.add(c2);
                 
                 assertTrue(result.isNaN());
             }

 @Test
             public void testAdd_WithNaNInBoth() {
                 Complex c1 = new Complex(Double.NaN, 4.0);
                 Complex c2 = new Complex(1.0, Double.NaN);
                 Complex result = c1.add(c2);
                 
                 assertTrue(result.isNaN());
             }

 @Test
             public void testAdd_WithInfinity() {
                 Complex c1 = new Complex(Double.POSITIVE_INFINITY, 4.0);
                 Complex c2 = new Complex(1.0, 2.0);
                 Complex result = c1.add(c2);
                 
                 assertTrue(result.isInfinite());
                 assertEquals(Double.POSITIVE_INFINITY, result.getReal(), 0.0001);
                 assertEquals(6.0, result.getImaginary(), 0.0001);
             }

 @Test
             public void testAdd_WithNull() {
                 Complex c1 = new Complex(3.0, 4.0);
                 
                 thrown.expect(NullPointerException.class);
                 c1.add(null);
             }

 @Test
             public void testAdd_WithStaticConstants() {
                 Complex result1 = Complex.ONE.add(Complex.ZERO);
                 assertEquals(1.0, result1.getReal(), 0.0001);
                 assertEquals(0.0, result1.getImaginary(), 0.0001);
                 
                 Complex result2 = Complex.I.add(Complex.ONE);
                 assertEquals(1.0, result2.getReal(), 0.0001);
                 assertEquals(1.0, result2.getImaginary(), 0.0001);
             }

 @Test
             public void testAdd_CommutativeProperty() {
                 Complex c1 = new Complex(3.0, 4.0);
                 Complex c2 = new Complex(1.0, 2.0);
                 
                 Complex result1 = c1.add(c2);
                 Complex result2 = c2.add(c1);
                 
                 assertEquals(result1.getReal(), result2.getReal(), 0.0001);
                 assertEquals(result1.getImaginary(), result2.getImaginary(), 0.0001);
             }

 @Test
         public void testAddWithNaN() {
             // Case 1: Current number is NaN, rhs is not NaN
             Complex nanComplex = new Complex(Double.NaN, 1.0);
             Complex normalComplex = new Complex(1.0, 1.0);
             assertTrue("Should return NaN when current is NaN", 
                        nanComplex.add(normalComplex).isNaN());
             
             // Case 2: Current number is not NaN, rhs is NaN
             assertTrue("Should return NaN when rhs is NaN", 
                        normalComplex.add(nanComplex).isNaN());
             
             // Case 3: Both numbers are NaN
             Complex anotherNan = new Complex(Double.NaN, Double.NaN);
             assertTrue("Should return NaN when both are NaN", 
                        nanComplex.add(anotherNan).isNaN());
             
             // Case 4: Neither is NaN (should return normal sum)
             Complex a = new Complex(1.0, 2.0);
             Complex b = new Complex(3.0, 4.0);
             Complex result = a.add(b);
             assertEquals("Real part should be sum", 4.0, result.getReal(), 0.0001);
             assertEquals("Imaginary part should be sum", 6.0, result.getImaginary(), 0.0001);
         }

 @Test
        public void testAddWithNaN1() {
            // Case 1: Current complex is NaN
            Complex nanComplex1 = new Complex(Double.NaN, 1.0);
            Complex normalComplex1 = new Complex(2.0, 3.0);
            assertEquals(Complex.NaN, nanComplex1.add(normalComplex1));
            
            // Case 2: Parameter complex is NaN
            Complex normalComplex2 = new Complex(2.0, 3.0);
            Complex nanComplex2 = new Complex(Double.NaN, 1.0);
            assertEquals(Complex.NaN, normalComplex2.add(nanComplex2));
            
            // Case 3: Both complexes are NaN
            Complex nanComplex3 = new Complex(Double.NaN, 1.0);
            Complex nanComplex4 = new Complex(2.0, Double.NaN);
            assertEquals(Complex.NaN, nanComplex3.add(nanComplex4));
            
            // Case 4: Neither is NaN (sanity check)
            Complex normalComplex3 = new Complex(2.0, 3.0);
            Complex normalComplex4 = new Complex(4.0, 5.0);
            Complex result = normalComplex3.add(normalComplex4);
            assertEquals(6.0, result.getReal(), 0.0001);
            assertEquals(8.0, result.getImaginary(), 0.0001);
        }

 @Test
   public void testAdd_WhenRhsIsNaN_ShouldReturnNaN() {
       // Create a regular complex number (not NaN)
       Complex regular = new Complex(1.0, 2.0);
       
       // Create a NaN complex number by using NaN in constructor
       Complex nanComplex = new Complex(Double.NaN, Double.NaN);
       
       // Verify adding regular + NaN returns NaN
       Complex result = regular.add(nanComplex);
       
       // Assert the result is NaN (using isNaN() method)
       assertTrue(result.isNaN());
       
       // Also test the reverse case (NaN + regular) for completeness
       Complex reverseResult = nanComplex.add(regular);
       assertTrue(reverseResult.isNaN());
   }

 @Test
      public void testAdd_WhenLeftOperandIsNaN_ShouldReturnNaN() {
          // Create a NaN complex number (left operand)
          Complex nanComplex = new Complex(Double.NaN, Double.NaN);
          // Create a normal complex number (right operand)
          Complex normalComplex = new Complex(1.0, 2.0);
          
          // Call add() - original should return NaN, mutant will return sum
          Complex result = nanComplex.add(normalComplex);
          
          // Verify result is NaN
          assertTrue("Adding NaN to normal number should return NaN", 
                     result.isNaN());
          
          // Additional verification that it's not doing the addition
          assertNotEquals("Result should not be the sum of components",
                         new Complex(1.0, 2.0), result);
      }

 @Test
      public void testAdd_WhenRightOperandIsNaN_ShouldReturnNaN() {
          // Create a normal complex number (left operand)
          Complex normalComplex = new Complex(1.0, 2.0);
          // Create a NaN complex number (right operand)
          Complex nanComplex = new Complex(Double.NaN, Double.NaN);
          
          // Call add() - both original and mutant should return NaN
          Complex result = normalComplex.add(nanComplex);
          
          // Verify result is NaN
          assertTrue("Adding normal number to NaN should return NaN", 
                     result.isNaN());
      }

 @Test
 public void testAddWhenNaNShouldReturnStaticNaN() {
     // Create a NaN complex number
     Complex nanComplex = new Complex(Double.NaN, 1.0);
     // Create a normal complex number
     Complex normalComplex = new Complex(1.0, 1.0);
     
     // Test case 1: this is NaN, rhs is normal
     Complex result1 = nanComplex.add(normalComplex);
     // Should return static NaN, not 'this' (nanComplex)
     assertSame(Complex.NaN, result1);
     
     // Test case 2: this is normal, rhs is NaN
     Complex result2 = normalComplex.add(nanComplex);
     // Should return static NaN, not 'this' (normalComplex)
     assertSame(Complex.NaN, result2);
     
     // Test case 3: both are NaN
     Complex result3 = nanComplex.add(nanComplex);
     // Should return static NaN, not 'this' (nanComplex)
     assertSame(Complex.NaN, result3);
 }

}
