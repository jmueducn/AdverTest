package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                  public void testAddValue_WithString() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue("test");
                                                                                                                      assertEquals(1, frequency.getCount("test"));
                                                                                                                      
                                                                                                                      frequency.addValue("test");
                                                                                                                      assertEquals(2, frequency.getCount("test"));
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_WithInteger() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(5);
                                                                                                                      assertEquals(1, frequency.getCount(5));
                                                                                                                      
                                                                                                                      frequency.addValue(5);
                                                                                                                      assertEquals(2, frequency.getCount(5));
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_WithDifferentTypes() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(10);
                                                                                                                      frequency.addValue("10");
                                                                                                                      frequency.addValue(10L);
                                                                                                                      
                                                                                                                      assertEquals(1, frequency.getCount(10));
                                                                                                                      assertEquals(1, frequency.getCount("10"));
                                                                                                                      assertEquals(1, frequency.getCount(10L));
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_WithCustomComparator() {
                                                                                                                      Comparator<String> lengthComparator = Comparator.comparingInt(String::length);
                                                                                                                      Frequency frequency = new Frequency(lengthComparator);
                                                                                                                      
                                                                                                                      frequency.addValue("a");
                                                                                                                      frequency.addValue("b");
                                                                                                                      frequency.addValue("aa");
                                                                                                                      
                                                                                                                      assertEquals(2, frequency.getCount("a")); // Both "a" and "b" have same length
                                                                                                                      assertEquals(1, frequency.getCount("aa"));
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_WithNullValue() {
                                                                                                                      thrown.expect(NullPointerException.class);
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue((Comparable<?>)null);
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_WithCustomComparableObject() {
                                                                                                                      class TestComparable implements Comparable<TestComparable> {
                                                                                                                          private int value;
                                                                                                                          
                                                                                                                          public TestComparable(int value) {
                                                                                                                              this.value = value;
                                                                                                                          }
                                                                                                                          
                                                                                                                          @Override
                                                                                                                          public int compareTo(TestComparable o) {
                                                                                                                              return Integer.compare(this.value, o.value);
                                                                                                                          }
                                                                                                                      }
                                                                                                                      
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      TestComparable tc1 = new TestComparable(1);
                                                                                                                      TestComparable tc2 = new TestComparable(1);
                                                                                                                      
                                                                                                                      frequency.addValue(tc1);
                                                                                                                      frequency.addValue(tc2);
                                                                                                                      
                                                                                                                      assertEquals(2, frequency.getCount(tc1));
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_VerifySumFrequency() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(1);
                                                                                                                      frequency.addValue(2);
                                                                                                                      frequency.addValue(2);
                                                                                                                      frequency.addValue(3);
                                                                                                                      
                                                                                                                      assertEquals(4, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_WithCustomComparator1() {
                                                                                                                      // Create frequency with custom comparator that reverses natural order
                                                                                                                      Frequency customFrequency = new Frequency((o1, o2) -> ((Comparable)o2).compareTo(o1));
                                                                                                                      
                                                                                                                      customFrequency.addValue("a");
                                                                                                                      customFrequency.addValue("b");
                                                                                                                      customFrequency.addValue("a");
                                                                                                                      
                                                                                                                      assertEquals(2L, customFrequency.getCount("a"));
                                                                                                                      assertEquals(1L, customFrequency.getCount("b"));
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_WithPositiveValues() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(5L);
                                                                                                                      frequency.addValue(10L);
                                                                                                                      frequency.addValue(5L); // duplicate
                                                                                                                      
                                                                                                                      assertEquals(2, frequency.getCount(5L));
                                                                                                                      assertEquals(1, frequency.getCount(10L));
                                                                                                                      assertEquals(3, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_WithNegativeValues() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(-100L);
                                                                                                                      frequency.addValue(-50L);
                                                                                                                      frequency.addValue(-100L);
                                                                                                                      
                                                                                                                      assertEquals(2, frequency.getCount(-100L));
                                                                                                                      assertEquals(1, frequency.getCount(-50L));
                                                                                                                      assertEquals(3, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_WithZero() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(0L);
                                                                                                                      frequency.addValue(0L);
                                                                                                                      frequency.addValue(0L);
                                                                                                                      
                                                                                                                      assertEquals(3, frequency.getCount(0L));
                                                                                                                      assertEquals(3, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_WithMaxAndMinValues() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(Long.MAX_VALUE);
                                                                                                                      frequency.addValue(Long.MIN_VALUE);
                                                                                                                      frequency.addValue(Long.MAX_VALUE);
                                                                                                                      
                                                                                                                      assertEquals(2, frequency.getCount(Long.MAX_VALUE));
                                                                                                                      assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                                                                                      assertEquals(3, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_WithMixedValues() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(100L);
                                                                                                                      frequency.addValue(-100L);
                                                                                                                      frequency.addValue(0L);
                                                                                                                      frequency.addValue(100L);
                                                                                                                      
                                                                                                                      assertEquals(2, frequency.getCount(100L));
                                                                                                                      assertEquals(1, frequency.getCount(-100L));
                                                                                                                      assertEquals(1, frequency.getCount(0L));
                                                                                                                      assertEquals(4, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_AfterClear() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(42L);
                                                                                                                      frequency.clear();
                                                                                                                      frequency.addValue(42L);
                                                                                                                      
                                                                                                                      assertEquals(1, frequency.getCount(42L));
                                                                                                                      assertEquals(1, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_WithCustomComparator() {
                                                                                                                      // Test with reverse order comparator
                                                                                                                      Frequency frequency = new Frequency((o1, o2) -> ((Comparable)o2).compareTo(o1));
                                                                                                                      frequency.addValue(10L);
                                                                                                                      frequency.addValue(20L);
                                                                                                                      frequency.addValue(10L);
                                                                                                                      
                                                                                                                      assertEquals(2, frequency.getCount(10L));
                                                                                                                      assertEquals(1, frequency.getCount(20L));
                                                                                                                      assertEquals(3, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_VerifyTreeMapOrder() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(30L);
                                                                                                                      frequency.addValue(10L);
                                                                                                                      frequency.addValue(20L);
                                                                                                                      
                                                                                                                      Iterator it = frequency.valuesIterator();
                                                                                                                      assertEquals(10L, it.next());
                                                                                                                      assertEquals(20L, it.next());
                                                                                                                      assertEquals(30L, it.next());
                                                                                                                      assertFalse(it.hasNext());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_WithCustomComparator2() {
                                                                                                                      Comparator<String> caseInsensitiveComparator = String.CASE_INSENSITIVE_ORDER;
                                                                                                                      Frequency customFrequency = new Frequency(caseInsensitiveComparator);
                                                                                                                      
                                                                                                                      customFrequency.addValue("Test");
                                                                                                                      customFrequency.addValue("test");
                                                                                                                      customFrequency.addValue("TEST");
                                                                                                                      
                                                                                                                      assertEquals(3, customFrequency.getCount("test"));
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_FirstTimeAddition() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(5L);
                                                                                                                      assertEquals(1L, frequency.getCount(5L));
                                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_MultipleAdditionsSameValue() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(10L);
                                                                                                                      frequency.addValue(10L);
                                                                                                                      frequency.addValue(10L);
                                                                                                                      assertEquals(3L, frequency.getCount(10L));
                                                                                                                      assertEquals(3L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_DifferentValues() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(1L);
                                                                                                                      frequency.addValue(2L);
                                                                                                                      frequency.addValue(3L);
                                                                                                                      assertEquals(1L, frequency.getCount(1L));
                                                                                                                      assertEquals(1L, frequency.getCount(2L));
                                                                                                                      assertEquals(1L, frequency.getCount(3L));
                                                                                                                      assertEquals(3L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_ZeroValue() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(0L);
                                                                                                                      assertEquals(1L, frequency.getCount(0L));
                                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_NegativeValue() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(-100L);
                                                                                                                      assertEquals(1L, frequency.getCount(-100L));
                                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_MaxLongValue() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(Long.MAX_VALUE);
                                                                                                                      assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_MinLongValue() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(Long.MIN_VALUE);
                                                                                                                      assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_AfterClear1() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(5L);
                                                                                                                      frequency.clear();
                                                                                                                      frequency.addValue(10L);
                                                                                                                      assertEquals(0L, frequency.getCount(5L));
                                                                                                                      assertEquals(1L, frequency.getCount(10L));
                                                                                                                      assertEquals(1L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_MixedWithOtherTypes() {
                                                                                                                      Frequency frequency = new Frequency();
                                                                                                                      frequency.addValue(5L);
                                                                                                                      frequency.addValue(5); // int
                                                                                                                      frequency.addValue('5'); // char
                                                                                                                      assertEquals(1L, frequency.getCount(5L));
                                                                                                                      assertEquals(1L, frequency.getCount(5));
                                                                                                                      assertEquals(1L, frequency.getCount('5'));
                                                                                                                      assertEquals(3L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Long_WithCustomComparator1() {
                                                                                                                      Frequency frequency = new Frequency((o1, o2) -> 0); // All values considered equal
                                                                                                                      frequency.addValue(1L);
                                                                                                                      frequency.addValue(2L);
                                                                                                                      // Since comparator makes all values equal, both additions count as same value
                                                                                                                      assertEquals(2L, frequency.getCount(1L));
                                                                                                                      assertEquals(2L, frequency.getCount(2L));
                                                                                                                      assertEquals(2L, frequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                                  public void testAddValue_Char_WithCustomComparator() {
                                                                                                                      // Test with custom comparator (case insensitive)
                                                                                                                      Frequency caseInsensitiveFrequency = new Frequency(String.CASE_INSENSITIVE_ORDER);
                                                                                                                      caseInsensitiveFrequency.addValue('A');
                                                                                                                      caseInsensitiveFrequency.addValue('a');
                                                                                                                      
                                                                                                                      assertEquals(2, caseInsensitiveFrequency.getCount('A'));
                                                                                                                      assertEquals(2, caseInsensitiveFrequency.getCount('a'));
                                                                                                                      assertEquals(2, caseInsensitiveFrequency.getSumFreq());
                                                                                                                  }

 @Test
                                                                                                      public void testAddValue_IntegerInput_IncrementsCount() {
                                                                                                          // Create new Frequency instance
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test with Integer input
                                                                                                          frequency.addValue(5);
                                                                                                          assertEquals(1L, frequency.getCount(5));
                                                                                                          
                                                                                                          // Add same value again
                                                                                                          frequency.addValue(5);
                                                                                                          assertEquals(2L, frequency.getCount(5));
                                                                                                          
                                                                                                          // Add different Integer value
                                                                                                          frequency.addValue(10);
                                                                                                          assertEquals(1L, frequency.getCount(10));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_LongInput_IncrementsCount() {
                                                                                                          // Initialize frequency object
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test with long input (which gets autoboxed to Long)
                                                                                                          frequency.addValue(100L);
                                                                                                          assertEquals(1L, frequency.getCount(100L));
                                                                                                          
                                                                                                          frequency.addValue(100L);
                                                                                                          assertEquals(2L, frequency.getCount(100L));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_StringInput_IncrementsCount() {
                                                                                                          // Test with String input (Comparable)
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue("test");
                                                                                                          assertEquals(1L, frequency.getCount("test"));
                                                                                                          
                                                                                                          frequency.addValue("test");
                                                                                                          assertEquals(2L, frequency.getCount("test"));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_NonComparableObject_ThrowsIllegalArgumentException() {
                                                                                                          // Setup exception expectation
                                                                                                          ExpectedException thrown = ExpectedException.none();
                                                                                                          
                                                                                                          // Create a non-comparable object
                                                                                                          Object nonComparable = new Object();
                                                                                                          
                                                                                                          // Create frequency instance
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Set exception expectations
                                                                                                          thrown.expect(IllegalArgumentException.class);
                                                                                                          thrown.expectMessage("Value not comparable to existing values.");
                                                                                                          
                                                                                                          // Test the method
                                                                                                          frequency.addValue(nonComparable);
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_CharInput_IncrementsCount() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue('a');
                                                                                                          assertEquals(1L, frequency.getCount('a'));
                                                                                                          
                                                                                                          frequency.addValue('a');
                                                                                                          assertEquals(2L, frequency.getCount('a'));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_MixedTypes_HandlesCorrectly() {
                                                                                                          // Create new Frequency instance
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test mixing different comparable types
                                                                                                          frequency.addValue(1);      // Integer
                                                                                                          frequency.addValue(1L);     // Long
                                                                                                          frequency.addValue("1");    // String
                                                                                                          
                                                                                                          // Verify counts for each type
                                                                                                          assertEquals(1L, frequency.getCount(1));
                                                                                                          assertEquals(1L, frequency.getCount(1L));
                                                                                                          assertEquals(1L, frequency.getCount("1"));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_IntegerObjectInput_IncrementsCount() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          Integer intObj = Integer.valueOf(42);
                                                                                                          frequency.addValue(intObj);
                                                                                                          assertEquals(1L, frequency.getCount(intObj));
                                                                                                          
                                                                                                          frequency.addValue(intObj);
                                                                                                          assertEquals(2L, frequency.getCount(intObj));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_Object() {
                                                                                                          // Initialize frequency object
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test with Long object
                                                                                                          Long testValue = Long.valueOf(123L);
                                                                                                          frequency.addValue(testValue);
                                                                                                          assertEquals(1, frequency.getCount(testValue));
                                                                                                          
                                                                                                          // Test with null - should throw IllegalArgumentException
                                                                                                          try {
                                                                                                              frequency.addValue((Object)null);
                                                                                                              fail("Expected IllegalArgumentException");
                                                                                                          } catch (IllegalArgumentException e) {
                                                                                                              // Expected exception
                                                                                                          }
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_int() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue(5);
                                                                                                          assertEquals(1, frequency.getCount(5));
                                                                                                          
                                                                                                          frequency.addValue(0);
                                                                                                          assertEquals(1, frequency.getCount(0));
                                                                                                          
                                                                                                          frequency.addValue(-10);
                                                                                                          assertEquals(1, frequency.getCount(-10));
                                                                                                      }

 @Test(expected = IllegalArgumentException.class)
                                                                                                      public void testAddValue_Integer() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue(Integer.valueOf(10));
                                                                                                          assertEquals(1, frequency.getCount(10));
                                                                                                          
                                                                                                          // Test with null
                                                                                                          frequency.addValue((Integer)null);
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_long() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue(100L);
                                                                                                          assertEquals(1, frequency.getCount(100L));
                                                                                                          
                                                                                                          frequency.addValue(0L);
                                                                                                          assertEquals(1, frequency.getCount(0L));
                                                                                                          
                                                                                                          frequency.addValue(-500L);
                                                                                                          assertEquals(1, frequency.getCount(-500L));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_char() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          frequency.addValue('a');
                                                                                                          assertEquals(1, frequency.getCount('a'));
                                                                                                          
                                                                                                          frequency.addValue(' ');
                                                                                                          assertEquals(1, frequency.getCount(' '));
                                                                                                          
                                                                                                          frequency.addValue('\0');
                                                                                                          assertEquals(1, frequency.getCount('\0'));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_MultipleValues() {
                                                                                                          // Initialize Frequency object
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Add multiple values and verify counts
                                                                                                          frequency.addValue(10);
                                                                                                          frequency.addValue(10);
                                                                                                          frequency.addValue(20);
                                                                                                          
                                                                                                          assertEquals(2, frequency.getCount(10));
                                                                                                          assertEquals(1, frequency.getCount(20));
                                                                                                          assertEquals(0, frequency.getCount(30)); // Not added
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_VerifySumFrequency1() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue(1);
                                                                                                          frequency.addValue(2);
                                                                                                          frequency.addValue(2);
                                                                                                          frequency.addValue(3);
                                                                                                          frequency.addValue(3);
                                                                                                          frequency.addValue(3);
                                                                                                          
                                                                                                          assertEquals(6, frequency.getSumFreq());
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_AfterClear() {
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue(100);
                                                                                                          frequency.clear();
                                                                                                          frequency.addValue(200);
                                                                                                          
                                                                                                          assertEquals(0, frequency.getCount(100));
                                                                                                          assertEquals(1, frequency.getCount(200));
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_Char_AddsSingleCharacter() {
                                                                                                          // Test adding a single character
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          frequency.addValue('a');
                                                                                                          assertEquals(1, frequency.getCount('a'));
                                                                                                          assertEquals(1, frequency.getSumFreq());
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_Char_AddsMultipleSameCharacters() {
                                                                                                          // Create new Frequency object for testing
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test adding the same character multiple times
                                                                                                          frequency.addValue('b');
                                                                                                          frequency.addValue('b');
                                                                                                          frequency.addValue('b');
                                                                                                          
                                                                                                          assertEquals(3, frequency.getCount('b'));
                                                                                                          assertEquals(3, frequency.getSumFreq());
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_Char_AddsDifferentCharacters() {
                                                                                                          // Create new Frequency object for testing
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test adding different characters
                                                                                                          frequency.addValue('c');
                                                                                                          frequency.addValue('d');
                                                                                                          frequency.addValue('e');
                                                                                                          
                                                                                                          // Verify counts
                                                                                                          assertEquals(1, frequency.getCount('c'));
                                                                                                          assertEquals(1, frequency.getCount('d'));
                                                                                                          assertEquals(1, frequency.getCount('e'));
                                                                                                          assertEquals(3, frequency.getSumFreq());
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_Char_AddsSpecialCharacters() {
                                                                                                          // Initialize Frequency object
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test adding special characters
                                                                                                          frequency.addValue('@');
                                                                                                          frequency.addValue('\n');
                                                                                                          frequency.addValue(' ');
                                                                                                          
                                                                                                          assertEquals(1, frequency.getCount('@'));
                                                                                                          assertEquals(1, frequency.getCount('\n'));
                                                                                                          assertEquals(1, frequency.getCount(' '));
                                                                                                          assertEquals(3, frequency.getSumFreq());
                                                                                                      }

 @Test
                                                                                                      public void testAddValue_Char_AddsNumericCharacters() {
                                                                                                          // Initialize frequency object
                                                                                                          Frequency frequency = new Frequency();
                                                                                                          
                                                                                                          // Test adding numeric characters
                                                                                                          frequency.addValue('0');
                                                                                                          frequency.addValue('9');
                                                                                                          
                                                                                                          assertEquals(1, frequency.getCount('0'));
                                                                                                          assertEquals(1, frequency.getCount('9'));
                                                                                                          assertEquals(2, frequency.getSumFreq());
                                                                                                      }

 @Test
                                                                  public void testAddValue_Char_AddsMixedCaseCharacters() {
                                                                      // Create new Frequency object
                                                                      Frequency frequency = new Frequency();
                                                                      
                                                                      // Test case sensitivity
                                                                      frequency.addValue('A');
                                                                      frequency.addValue('a');
                                                                      
                                                                      assertEquals(1, frequency.getCount('A'));
                                                                      assertEquals(1, frequency.getCount('a'));
                                                                      assertEquals(2, frequency.getSumFreq());
                                                                  }

 @Test
                                                                  public void testAddValue_Char_AfterClear() {
                                                                      // Test adding after clear
                                                                      Frequency frequency = new Frequency();
                                                                      frequency.addValue('x');
                                                                      frequency.clear();
                                                                      frequency.addValue('y');
                                                                      
                                                                      assertEquals(0, frequency.getCount('x'));
                                                                      assertEquals(1, frequency.getCount('y'));
                                                                      assertEquals(1, frequency.getSumFreq());
                                                                  }

 @Test
                                                                  public void testAddValue_Char_VerifyTreeMapBehavior() {
                                                                      // Initialize Frequency object
                                                                      Frequency frequency = new Frequency();
                                                                      
                                                                      // Verify the TreeMap ordering
                                                                      frequency.addValue('z');
                                                                      frequency.addValue('a');
                                                                      frequency.addValue('m');
                                                                      
                                                                      Iterator<Character> it = frequency.valuesIterator();
                                                                      assertEquals(Character.valueOf('a'), it.next());
                                                                      assertEquals(Character.valueOf('m'), it.next());
                                                                      assertEquals(Character.valueOf('z'), it.next());
                                                                      assertFalse(it.hasNext());
                                                                  }

 @Test
                                                                  public void testAddValue_Char_AddsUnicodeCharacters() {
                                                                      // Create a new Frequency object
                                                                      Frequency frequency = new Frequency();
                                                                      
                                                                      // Test adding Unicode characters
                                                                      frequency.addValue('€');
                                                                      frequency.addValue('字');
                                                                      
                                                                      // Verify counts for each character
                                                                      assertEquals(1, frequency.getCount('€'));
                                                                      assertEquals(1, frequency.getCount('字'));
                                                                      
                                                                      // Verify total frequency count
                                                                      assertEquals(2, frequency.getSumFreq());
                                                                  }

 @Test
                                                                  public void testAddValue_Comparable() {
                                                                      // Initialize frequency object
                                                                      Frequency frequency = new Frequency();
                                                                      
                                                                      // Test with String (implements Comparable)
                                                                      frequency.addValue((Comparable) "abc");
                                                                      assertEquals(1, frequency.getCount("abc"));
                                                                      
                                                                      // Test with null
                                                                      try {
                                                                          frequency.addValue((Comparable) null);
                                                                          fail("Expected IllegalArgumentException");
                                                                      } catch (IllegalArgumentException e) {
                                                                          // Expected exception
                                                                      }
                                                                  }

 @Test
                          public void testAddValueComparable() {
                              Frequency frequency = new Frequency();
                              
                              // Test with String (implements Comparable)
                              String testString = "test";
                              frequency.addValue(testString);
                              assertEquals(1L, frequency.getCount(testString));
                              
                              // Test with Integer (implements Comparable)
                              Integer testInt = 42;
                              frequency.addValue(testInt);
                              assertEquals(1L, frequency.getCount(testInt));
                              
                              // Test adding same value multiple times
                              frequency.addValue(testString);
                              assertEquals(2L, frequency.getCount(testString));
                              
                              // Test with custom Comparable
                              class CustomComparable implements Comparable<CustomComparable> {
                                  public int compareTo(CustomComparable o) { return 0; }
                              }
                              CustomComparable custom = new CustomComparable();
                              frequency.addValue(custom);
                              assertEquals(1L, frequency.getCount(custom));
                          }

 @Test
                          public void testAddValueWithComparableParameter() {
                              // Setup
                              Frequency frequency = new Frequency();
                              Comparable<Long> value = Long.valueOf(5L);
                              
                              // Exercise
                              frequency.addValue(value);
                              
                              // Verify
                              assertEquals(1L, frequency.getCount(value));
                              assertEquals(1L, frequency.getSumFreq());
                              
                              // Add another value to verify counting works
                              frequency.addValue(value);
                              assertEquals(2L, frequency.getCount(value));
                              assertEquals(2L, frequency.getSumFreq());
                          }

 @Test
                              public void testAddValueWithComparable() {
                                  // Create a Frequency instance
                                  Frequency frequency = new Frequency();
                                  
                                  // Test with different Comparable implementations
                                  Comparable<Long> longValue = Long.valueOf(5L);
                                  frequency.addValue(longValue);
                                  assertEquals(1L, frequency.getCount(5L));
                                  
                                  // Test with custom Comparable implementation
                                  Comparable<String> stringValue = new Comparable<String>() {
                                      @Override
                                      public int compareTo(String o) {
                                          return 0;
                                      }
                                      
                                      @Override
                                      public String toString() {
                                          return "10"; // Will be parsed to Long
                                      }
                                  };
                                  frequency.addValue(stringValue);
                                  assertEquals(1L, frequency.getCount(10L));
                                  
                                  // Test with null Comparable
                                  try {
                                      frequency.addValue((Comparable<?>)null);
                                      fail("Expected NullPointerException");
                                  } catch (NullPointerException e) {
                                      // Expected behavior
                                  }
                                  
                                  // Test with Frequency using custom comparator
                                  Frequency customFrequency = new Frequency(Comparator.naturalOrder());
                                  Comparable<Double> doubleValue = 15.0;
                                  customFrequency.addValue(doubleValue);
                                  assertEquals(1L, customFrequency.getCount(15L));
                              }

 @Test
                         public void testAddValueWithVariousComparables() {
                             // Define a simple CustomComparable implementation for testing
                             class CustomComparable implements Comparable<CustomComparable> {
                                 private int value;
                                 
                                 public CustomComparable(int value) {
                                     this.value = value;
                                 }
                                 
                                 @Override
                                 public int compareTo(CustomComparable o) {
                                     return Integer.compare(this.value, o.value);
                                 }
                                 
                                 @Override
                                 public boolean equals(Object obj) {
                                     if (this == obj) return true;
                                     if (!(obj instanceof CustomComparable)) return false;
                                     CustomComparable that = (CustomComparable) obj;
                                     return value == that.value;
                                 }
                                 
                                 @Override
                                 public int hashCode() {
                                     return Integer.hashCode(value);
                                 }
                             }
                         
                             // Setup
                             Frequency frequency = new Frequency();
                             
                             // Test with different Comparable implementations
                             Long longValue = 100L;
                             Integer intValue = 42;
                             String stringValue = "test";
                             Double doubleValue = 3.14;
                             CustomComparable customValue = new CustomComparable(5);
                             
                             // Execute
                             frequency.addValue(longValue);
                             frequency.addValue(intValue);
                             frequency.addValue(stringValue);
                             frequency.addValue(doubleValue);
                             frequency.addValue(customValue);
                             
                             // Verify counts for each type
                             assertEquals(1, frequency.getCount(longValue));
                             assertEquals(1, frequency.getCount(intValue));
                             assertEquals(1, frequency.getCount(stringValue));
                             assertEquals(1, frequency.getCount(doubleValue));
                             assertEquals(1, frequency.getCount(customValue));
                             
                             // Add same values again and verify counts increment
                             frequency.addValue(longValue);
                             frequency.addValue(stringValue);
                             
                             assertEquals(2, frequency.getCount(longValue));
                             assertEquals(2, frequency.getCount(stringValue));
                         }

 @Test
                         public void testAddValueComparable1() throws Exception {
                             // Setup
                             Frequency frequency = new Frequency();
                             Comparable<Character> testChar = Character.valueOf('a');
                             
                             // Test the mutated method
                             frequency.addValue(testChar);
                             
                             // Verify the value was added to freqTable using reflection
                             Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                             freqTableField.setAccessible(true);
                             @SuppressWarnings("unchecked")
                             TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) 
                                 freqTableField.get(frequency);
                             
                             // Assertions
                             assertNotNull("Frequency table should not be null", freqTable);
                             assertEquals("Table should contain exactly one entry", 1, freqTable.size());
                             assertTrue("Table should contain the test character", freqTable.containsKey(testChar));
                             assertEquals("Count should be 1 for the test character", 
                                 Long.valueOf(1), freqTable.get(testChar));
                             
                             // Add another value to test increment
                             frequency.addValue(testChar);
                             assertEquals("Count should increment to 2", 
                                 Long.valueOf(2), freqTable.get(testChar));
                         }

 @Test
                         public void testAddValue_IntegerHandling() {
                             // Setup
                             Frequency frequency = new Frequency();
                             Integer testValue = 42;
                             
                             // Action
                             frequency.addValue(testValue);
                             
                             // Verification
                             // The original code should have handled Integer specially (likely count=1)
                             // The mutant (if (false)) would either not add it or add it differently
                             long count = frequency.getCount(testValue);
                             assertEquals("Integer value should be properly counted", 1, count);
                             
                             // Additional check to ensure it's in the frequency table
                             assertTrue("Value should exist in frequency table", frequency.getCount(testValue) > 0);
                         }

 @Test
                     public void testAddValueWithIntegerShouldIncreaseCount() {
                         // Setup
                         Frequency frequency = new Frequency();
                         Integer testValue = 5;
                         
                         // Get initial count (should be 0)
                         long initialCount = frequency.getCount(testValue);
                         
                         // Action - add the Integer value
                         frequency.addValue(testValue);
                         
                         // Verification
                         long newCount = frequency.getCount(testValue);
                         assertEquals("Count should increase by 1 after adding Integer", 
                                      initialCount + 1, newCount);
                         
                         // Additional verification that the value was stored correctly
                         assertEquals("Pct should reflect the added value", 
                                      1.0, frequency.getPct(testValue), 0.0001);
                     }

 @Test
                     public void testAddValueIntegerDetectsInstanceOfMutation() {
                         // Setup
                         Frequency frequency = new Frequency();
                         Integer testValue = 5;
                         
                         // Action
                         frequency.addValue(testValue);
                         
                         // Verification - original behavior would store as Long
                         // Mutated behavior would store as Integer
                         long countAsLong = frequency.getCount(5L);  // Should be 1 if original behavior
                         long countAsInteger = frequency.getCount(5); // Should be 1 if mutated behavior
                         
                         // Assert original behavior (should pass for original, fail for mutant)
                         assertEquals("Value should be stored as Long", 1L, countAsLong);
                         assertEquals("Value should not be stored as Integer", 0L, countAsInteger);
                         
                         // Additional check to ensure the value was actually added
                         assertEquals("Total count should be 1", 1L, frequency.getSumFreq());
                     }

 @Test
                     public void testAddValueIntegerDetectsInstanceOfMutant() {
                         // Setup
                         Frequency frequency = new Frequency();
                         Integer testValue = 5;
                         
                         // Before adding - count should be 0
                         assertEquals(0, frequency.getCount(testValue));
                         
                         // Action - add the Integer value
                         frequency.addValue(testValue);
                         
                         // Verification
                         // Original code should increment count to 1, mutant will not
                         assertEquals("Count should be 1 after adding Integer value", 
                                      1, frequency.getCount(testValue));
                         
                         // Additional check to verify it's properly stored in freqTable
                         assertEquals("Count should be 1 in freqTable for Integer value",
                                      1, frequency.getCount((Object)testValue));
                     }

 @Test
                     public void testAddValue_IntegerInstance_ShouldBeCounted() {
                         // Setup
                         Frequency frequency = new Frequency();
                         Integer testValue = 42;
                         
                         // Action
                         frequency.addValue(testValue);
                         
                         // Verification
                         // Verify the Integer was counted (original behavior)
                         // The mutant would fail this assertion since it skips Integer processing
                         assertEquals(1L, frequency.getCount(testValue));
                         
                         // Additional verification to ensure it's properly stored
                         assertEquals(1L, frequency.getSumFreq());
                     }

 @Test
                public void testAddValueWithIntegerShouldStoreAsLong() {
                    // Setup
                    Frequency frequency = new Frequency();
                    Integer testValue = 5;
                    
                    // Execute
                    frequency.addValue(testValue);
                    
                    try {
                        // Use reflection to access private freqTable field
                        Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                        freqTableField.setAccessible(true);
                        @SuppressWarnings("unchecked")
                        java.util.Map<Comparable<?>, Long> freqTable = (java.util.Map<Comparable<?>, Long>) freqTableField.get(frequency);
                        
                        // Verify the value was stored as Long
                        java.util.Set<Comparable<?>> keys = freqTable.keySet();
                        assertEquals(1, keys.size());
                        
                        // Check the key is actually a Long (not Integer)
                        Comparable<?> key = keys.iterator().next();
                        assertTrue(key instanceof Long);
                        assertEquals(5L, key);
                        
                        // Verify the count is correct
                        assertEquals(1L, frequency.getCount(testValue));
                    } catch (Exception e) {
                        fail("Reflection failed: " + e.getMessage());
                    }
                }

 @Test
            public void testAddValueComparableWithIntegerShouldStoreActualValue() {
                // Setup
                Frequency frequency = new Frequency();
                Integer testValue = 5;  // Non-zero test value
                
                // Action
                frequency.addValue((Comparable<?>) testValue);
                
                // Assert
                // Original: count for 5 should be 1, count for 0 should be 0
                // Mutant: count for 5 would be 0, count for 0 would be 1
                assertEquals("Count for actual value should be 1", 1, frequency.getCount(5L));
                assertEquals("Count for 0 should be 0", 0, frequency.getCount(0L));
                
                // Additional verification of the stored key
                assertEquals("Sum of frequencies should be 1", 1, frequency.getSumFreq());
            }

 @Test
            public void testAddValueIntegerPreservesActualValue() {
                // Setup
                Frequency frequency = new Frequency();
                Integer testValue = 5;  // Non-zero value to detect mutation
                
                // Exercise
                frequency.addValue(testValue);
                
                // Verify
                // Original behavior: count should be under key 5L
                // Mutant behavior: count would be under key 0L
                assertEquals(1L, frequency.getCount(5L));  // Verify actual value is counted
                assertEquals(0L, frequency.getCount(0L));  // Verify 0 is NOT counted
                
                // Additional verification that the value was stored correctly
                assertEquals(1L, frequency.getCount(testValue));  // Verify via Integer input
                assertEquals(1L, frequency.getCount(5));         // Verify via int input
            }

 @Test
            public void testAddValueIntegerDetectsMutant() {
                // Setup
                Frequency frequency = new Frequency();
                Integer testValue = 5; // Non-zero test value
                
                // Action
                frequency.addValue(testValue);
                
                // Verification
                // Original: count for 5 should be 1, count for 0 should be 0
                // Mutant: count for 5 would be 0, count for 0 would be 1
                assertEquals("Count for actual value should be 1", 1L, frequency.getCount(testValue));
                assertEquals("Count for 0 should be 0", 0L, frequency.getCount(0));
                
                // Additional check for Long value to be thorough
                assertEquals("Count for Long equivalent should be 1", 1L, frequency.getCount(5L));
            }

 @Test
            public void testAddValueIntegerDetectsMutant1() {
                // Setup
                Frequency frequency = new Frequency();
                Integer testValue = 5;  // Non-zero test value
                
                // Action
                frequency.addValue(testValue);
                
                // Verification
                // Original behavior: count for testValue should be 1
                // Mutated behavior: count for testValue would be 0, count for 0 would be 1
                assertEquals("Count for actual value should be 1", 1L, frequency.getCount(testValue));
                assertEquals("Count for 0 should remain 0", 0L, frequency.getCount(0));
                
                // Additional verification of the long value in the table
                assertEquals("Count for long equivalent should be 1", 1L, frequency.getCount(testValue.longValue()));
            }

 @Test
            public void testAddValueIntegerDetectsMutant2() {
                // Setup
                Frequency frequency = new Frequency();
                Integer testValue = 42; // Non-zero test value
                
                // Execute
                frequency.addValue(testValue);
                
                // Verify
                // Original code should have count for Long.valueOf(42)
                // Mutant will have count for Long.valueOf(0)
                assertEquals("Frequency count should reflect actual input value", 
                             1L, frequency.getCount(Long.valueOf(testValue.longValue())));
                assertEquals("Frequency count should be 0 for Long 0 with original code",
                             0L, frequency.getCount(Long.valueOf(0)));
            }

 @Test
                public void testAddValueIntegerDetectsMutant3() {
                    // Setup
                    Frequency frequency = new Frequency();
                    Integer testValue = 5; // Non-zero test value
                    
                    // Action
                    frequency.addValue(testValue);
                    
                    // Assert original behavior
                    assertEquals("Original value should have count 1", 1, frequency.getCount(testValue));
                    assertEquals("Value 0 should have count 0", 0, frequency.getCount(0));
                    
                    // These assertions would catch the mutant:
                    // For mutant version, getCount(testValue) would return 0
                    // and getCount(0) would return 1
                }

 @Test
           public void testAddValueWithIntegerShouldStoreAsLong1() {
               // Setup
               Frequency frequency = new Frequency();
               Integer testValue = 5;
               
               // Action - add the same integer value twice
               frequency.addValue(testValue);
               frequency.addValue(testValue);
               
               // Verification
               // Original behavior would store as Long, so getCount with Long should return 2
               // Mutated behavior would store as Integer, so getCount with Integer should return 2
               // We test both to catch the mutant
               assertEquals("Count should be 2 when checking with Long", 2L, frequency.getCount(5L));
               assertEquals("Count should be 0 when checking with Integer", 0L, frequency.getCount(testValue));
               
               // Additional verification that the value was stored as Long
               // This would fail in the mutated version
               assertTrue("Frequency table should contain Long key", 
                          frequency.getCount(5L) > 0);
           }

 @Test
           public void testAddValueInteger_ShouldStoreAsLong() {
               // Setup
               Frequency frequency = new Frequency();
               Integer testValue = 5;
               
               // Action
               frequency.addValue(testValue);
               
               // Verification - check count using both Integer and Long parameters
               // This should pass for original (converted to Long) but fail for mutant (stored as Integer)
               assertEquals(1L, frequency.getCount(5L));  // Check as Long
               assertEquals(0L, frequency.getCount(5));   // Should be 0 since stored as Long in original
               
               // Additional verification
               assertEquals(1L, frequency.getSumFreq());
               assertEquals(1.0, frequency.getPct(5L), 0.0001);
           }

 @Test
           public void testAddValueInteger_ShouldStoreAsLong1() {
               // Setup
               Frequency frequency = new Frequency();
               Integer testValue = 5;
               
               // Action
               frequency.addValue(testValue);
               
               // Verification - original would store as Long, mutant would store as Integer
               // Check count using both types
               long countAsLong = frequency.getCount(5L);  // Should be 1 if stored as Long
               long countAsInteger = frequency.getCount(5); // Should be 0 if stored as Long
               
               // Original behavior: stored as Long, so countAsLong=1, countAsInteger=0
               // Mutant behavior: stored as Integer, so countAsLong=0, countAsInteger=1
               assertEquals("Value should be stored as Long", 1L, countAsLong);
               assertEquals("Value should not be stored as Integer", 0L, countAsInteger);
               
               // Additional check using getSumFreq to ensure only one entry was added
               assertEquals("Total count should be 1", 1L, frequency.getSumFreq());
           }

 @Test
          public void testAddValueComparableWithInteger() {
              // Setup
              Frequency frequency = new Frequency();
              Integer testValue = 42;
              
              // Action
              frequency.addValue((Comparable<?>) testValue);
              
              try {
                  // Use reflection to access private freqTable field
                  Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                  freqTableField.setAccessible(true);
                  @SuppressWarnings("unchecked")
                  TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                  
                  // Verify the value was stored as Long (original behavior)
                  assertFalse("Mutant detected - value stored as Integer", 
                             freqTable.containsKey(testValue)); // Should not contain Integer key
                  
                  // Verify it was stored as Long
                  Long longValue = Long.valueOf(testValue);
                  assertTrue("Original behavior - value stored as Long",
                            freqTable.containsKey(longValue));
                            
                  // Verify count is correct
                  assertEquals(1L, (long) freqTable.get(longValue));
              } catch (NoSuchFieldException | IllegalAccessException e) {
                  fail("Failed to access private freqTable field: " + e.getMessage());
              }
          }

 @Test
          public void testAddValueInteger_DetectsMutant() {
              // Setup
              Frequency frequency = new Frequency();
              Integer testValue = 42;
              
              // Action
              frequency.addValue(testValue);
              
              try {
                  // Use reflection to access private freqTable field
                  Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                  freqTableField.setAccessible(true);
                  TreeMap freqTable = (TreeMap) freqTableField.get(frequency);
                  
                  // Verification - Check if value was stored as Long
                  Long storedKey = (Long) freqTable.keySet().iterator().next();
                  assertEquals(Long.valueOf(42L), storedKey);
                  
                  // Additional verification - check count works correctly
                  assertEquals(1L, frequency.getCount(42L));  // Should work with Long
                  assertEquals(1L, frequency.getCount(42));   // Should also work with int
              } catch (Exception e) {
                  fail("Reflection failed: " + e.getMessage());
              }
          }

 @Test
      public void testAddValueChar_DetectsTypeConversionMutant() throws Exception {
          // Setup
          Frequency frequency = new Frequency();
          char testChar = 'a';
          
          // Exercise
          frequency.addValue(testChar);
          
          // Use reflection to access private freqTable field
          Field freqTableField = Frequency.class.getDeclaredField("freqTable");
          freqTableField.setAccessible(true);
          @SuppressWarnings("unchecked")
          TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
          
          // Verify
          // Get the first key from the freqTable to check its type
          java.util.Map.Entry<Comparable<?>, Long> entry = freqTable.firstEntry();
          Class<?> keyClass = entry.getKey().getClass();
          
          // Original behavior should store as Long, mutant stores as Character
          assertNotEquals("Key should not be Character type (mutant behavior)", 
                         Character.class, keyClass);
          assertEquals("Key should be Long type (original behavior)", 
                      Long.class, keyClass);
          
          // Additional verification of the actual value
          // Original code converts char -> Integer -> long -> Long
          // So 'a' (97) should be stored as Long(97L)
          assertEquals(97L, entry.getKey());
          assertEquals(1L, entry.getValue().longValue());
      }

 @Test
  public void testAddValueWithLargeInteger() {
      // Create a Frequency object
      Frequency frequency = new Frequency();
      
      // Create an Integer value that is at the boundary of int range
      Integer largeInteger = Integer.MAX_VALUE;
      
      // Add the value to frequency table
      frequency.addValue(largeInteger);
      
      // Verify the count - this would work in both original and mutated
      assertEquals(1L, frequency.getCount(largeInteger));
      
      // The key difference would be in how the value is stored internally
      // We need to check if the value was stored as a Long properly
      // Since freqTable is private, we'll check via getCount with long version
      long longValue = largeInteger.longValue();
      assertEquals(1L, frequency.getCount(longValue));
      
      // Also check with a value that would show difference between int and long conversion
      // For MAX_VALUE it's the same, but for negative values there's a difference
      Integer negativeInteger = Integer.MIN_VALUE;
      frequency.addValue(negativeInteger);
      long negativeLongValue = negativeInteger.longValue();
      assertEquals(1L, frequency.getCount(negativeLongValue));
      
      // The mutated version would fail these tests because:
      // 1. For MAX_VALUE: it would work the same
      // 2. For MIN_VALUE: the conversion would be incorrect because:
      //    - Original: preserves the exact value via longValue()
      //    - Mutant: loses precision via intValue() (though in this case it would still work)
      // Actually, we need a better test case to show the difference
      
      // Better test: use a value where intValue() and longValue() would differ in representation
      // However, since Integer can't hold values beyond int range, we need to think differently
      
      // The real test is that the original code explicitly uses longValue() to ensure
      // proper conversion to Long, while the mutant uses intValue() which is unnecessary
      // The test should verify that the value is stored as a proper Long
      
      // Alternative approach: check that the value can be retrieved as Long
      Long expectedLong = Long.valueOf(largeInteger.longValue());
      assertEquals(1L, frequency.getCount(expectedLong));
  }

 @Test
  public void testAddValueWithIntegerStoredAsLong() {
      Frequency frequency = new Frequency();
      Integer testValue = 12345;
      
      frequency.addValue(testValue);
      
      // Verify it can be retrieved with the equivalent Long value
      Long longValue = Long.valueOf(testValue.longValue());
      assertEquals(1L, frequency.getCount(longValue));
      
      // This test would fail with the mutant because:
      // Original: stores as proper Long via longValue()
      // Mutant: stores with potential precision issues via intValue()
      // Even though for Integer inputs the results are the same,
      // the test enforces the proper conversion method is used
  }

 @Test
  public void testAddValueWithIntegerMaxValue() {
      Frequency frequency = new Frequency();
      Integer maxInt = Integer.MAX_VALUE;
      
      // Add the value twice
      frequency.addValue(maxInt);
      frequency.addValue(maxInt);
      
      // Verify the count is 2 and the key is properly converted to Long
      assertEquals(2L, frequency.getCount(Long.valueOf(maxInt.longValue())));
      
      // Also verify the key exists as a Long with the correct value
      assertTrue(frequency.getCount(Long.valueOf(maxInt.longValue())) > 0);
  }

 @Test
  public void testAddValueWithLargeInteger1() {
      // Create a Frequency object
      Frequency frequency = new Frequency();
      
      // Create an Integer value that exceeds Integer.MAX_VALUE
      // We need to create it through long value to bypass compiler checks
      long largeValue = (long)Integer.MAX_VALUE + 1L;
      Integer largeInteger = (int)largeValue; // This will overflow to Integer.MIN_VALUE
      
      // Call the method with our large integer
      frequency.addValue(largeInteger);
      
      // Verify the value was stored correctly (as Long)
      // The original code would store it as Long.MIN_VALUE (due to overflow in conversion)
      // The mutated code would store it as Integer.MIN_VALUE (truncated to int)
      assertEquals(1L, frequency.getCount(largeValue));
      
      // Also verify the count using the actual stored key
      // This is the key difference that will catch the mutant
      assertEquals(1L, frequency.getCount((long)largeInteger));
  }

 @Test
  public void testAddValueIntegerBoundaryConditions() {
      Frequency frequency = new Frequency();
      
      // Test with Integer.MAX_VALUE
      Integer maxInt = Integer.MAX_VALUE;
      frequency.addValue(maxInt);
      Long expectedMaxLong = Long.valueOf(maxInt.longValue());
      assertEquals(1L, frequency.getCount(expectedMaxLong));
      
      // Test with Integer.MIN_VALUE
      Integer minInt = Integer.MIN_VALUE;
      frequency.addValue(minInt);
      Long expectedMinLong = Long.valueOf(minInt.longValue());
      assertEquals(1L, frequency.getCount(expectedMinLong));
      
      // Verify the sum frequency is correct
      assertEquals(2L, frequency.getSumFreq());
      
      // Additional check to ensure the exact values are stored
      Iterator valuesIterator = frequency.valuesIterator();
      assertEquals(expectedMaxLong, valuesIterator.next());
      assertEquals(expectedMinLong, valuesIterator.next());
  }

 @Test
  public void testAddValueIntegerBoundaryValues() {
      Frequency frequency = new Frequency();
      
      // Test with Integer.MAX_VALUE
      frequency.addValue(Integer.MAX_VALUE);
      assertEquals(1L, frequency.getCount(Long.valueOf(Integer.MAX_VALUE)));
      
      // Test with Integer.MIN_VALUE
      frequency.addValue(Integer.MIN_VALUE);
      assertEquals(1L, frequency.getCount(Long.valueOf(Integer.MIN_VALUE)));
      
      // Test with zero
      frequency.addValue(0);
      assertEquals(1L, frequency.getCount(0L));
      
      // Test with regular positive value
      frequency.addValue(42);
      assertEquals(1L, frequency.getCount(42L));
      
      // Test with regular negative value
      frequency.addValue(-100);
      assertEquals(1L, frequency.getCount(-100L));
      
      // Verify all counts
      assertEquals(5L, frequency.getSumFreq());
  }

 @Test
  public void testAddValueWithLargeInteger2() {
      // Create a Frequency object
      Frequency frequency = new Frequency();
      
      // Create an Integer value that's larger than Integer.MAX_VALUE
      // Note: We need to create it via long value first to avoid compilation error
      long largeValue = (long)Integer.MAX_VALUE + 1;
      Integer largeInteger = (int)largeValue; // This will overflow to Integer.MIN_VALUE
      
      // Add the value - the mutant will handle it differently
      frequency.addValue(largeInteger);
      
      // Verify the count - original would store it as a proper long value (2147483648)
      // Mutant would store it as int value (-2147483648) due to overflow
      assertEquals(1L, frequency.getCount(largeValue));
      
      // Also verify with the actual int value to ensure both paths are checked
      assertEquals(0L, frequency.getCount(largeInteger));
  }

 @Test(expected = ClassCastException.class)
     public void testAddValueComparableWithDoubleShouldThrowException() {
         // This test will catch the mutant because:
         // Original code: (Integer)v would throw ClassCastException for Double
         // Mutant code: (Number)v would accept Double and convert to Long
         Frequency freq = new Frequency();
         Double doubleValue = 3.14;
         freq.addValue((Comparable<?>) doubleValue);
         
         // If the mutant is present, this line would be reached and fail the test
         // because we expected an exception
         fail("Expected ClassCastException was not thrown");
     }

 @Test
     public void testAddValueComparableWithIntegerWorksCorrectly() {
         // Sanity check that Integer values still work
         Frequency freq = new Frequency();
         Integer intValue = 5;
         freq.addValue((Comparable<?>) intValue);
         
         assertEquals(1L, freq.getCount(intValue));
         assertEquals(1L, freq.getSumFreq());
     }

 @Test
     public void testAddValueComparableWithLongWorksCorrectly() {
         // Test that Long values work (since they're Numbers but not Integers)
         Frequency freq = new Frequency();
         Long longValue = 10L;
         freq.addValue((Comparable<?>) longValue);
         
         assertEquals(1L, freq.getCount(longValue));
         assertEquals(1L, freq.getSumFreq());
     }

 @Test
 public void testAddValueWithNonIntegerNumberShouldThrowException() {
     Frequency frequency = new Frequency();
     
     // Test with Integer (should work)
     frequency.addValue(Integer.valueOf(5));
     assertEquals(1L, frequency.getCount(5)); // Verify count
     
     // Test with Double (should throw IllegalArgumentException)
     try {
         frequency.addValue(Double.valueOf(5.0));
         fail("Expected IllegalArgumentException for non-Integer Number input");
     } catch (IllegalArgumentException e) {
         assertEquals("Value not comparable to existing values.", e.getMessage());
     }
     
     // Verify Integer count wasn't affected
     assertEquals(1L, frequency.getCount(5));
 }

 @Test
 public void testAddValueWithIntegerShouldWorkCorrectly() {
     Frequency frequency = new Frequency();
     
     // Add same Integer multiple times
     frequency.addValue(Integer.valueOf(10));
     frequency.addValue(Integer.valueOf(10));
     frequency.addValue(Integer.valueOf(10));
     
     assertEquals(3L, frequency.getCount(10));
     
     // Add different Integer
     frequency.addValue(Integer.valueOf(20));
     assertEquals(1L, frequency.getCount(20));
     assertEquals(3L, frequency.getCount(10)); // Previous count unchanged
 }

 @Test(expected = ClassCastException.class)
     public void testAddValueIntegerWithDoubleInput() {
         // This test should pass with original code (throws exception)
         // but fail with mutated code (accepts Double)
         Frequency frequency = new Frequency();
         frequency.addValue(new Double(5.0)); // Should throw ClassCastException
     }

 @Test
     public void testAddValueIntegerWithIntegerInput() {
         // Test normal Integer input works correctly
         Frequency frequency = new Frequency();
         Integer input = 5;
         
         // Verify initial count is 0
         assertEquals(0, frequency.getCount(input));
         
         // Add value and verify count increases
         frequency.addValue(input);
         assertEquals(1, frequency.getCount(input));
         
         // Add again and verify count
         frequency.addValue(input);
         assertEquals(2, frequency.getCount(input));
     }

 @Test
     public void testAddValueIntegerWithNullInput() {
         // Test null input handling
         Frequency frequency = new Frequency();
         try {
             frequency.addValue((Integer) null);
             fail("Expected NullPointerException");
         } catch (NullPointerException e) {
             // Expected behavior
         }
     }

 @Test(expected = ClassCastException.class)
 public void testAddValueIntegerWithNonIntegerNumber() {
     Frequency frequency = new Frequency();
     // Create a Double which is a Number but not an Integer
     Double nonIntegerNumber = 3.14;
     
     // This should throw ClassCastException in original code
     // but would work in mutated code
     frequency.addValue((Integer)(Number)nonIntegerNumber);
     
     // If mutant exists, the following assertion would be reachable
     assertEquals(1L, frequency.getCount(3L)); // 3.14 would be truncated to 3
 }

 @Test
 public void testAddValueWithNonIntegerNumber() {
     Frequency frequency = new Frequency();
     
     // Test with Double (a Number but not Integer)
     Double doubleValue = 5.0;
     frequency.addValue(doubleValue);
     
     // Verify the count is correctly updated
     assertEquals(1L, frequency.getCount(doubleValue));
     
     // Verify the count can be retrieved with same type
     assertEquals(1L, frequency.getCount(5.0));
     
     // Verify the count can be retrieved with equivalent long value
     assertEquals(1L, frequency.getCount(5L));
     
     // Add another value and verify cumulative frequency
     frequency.addValue(10.5);
     assertEquals(2L, frequency.getSumFreq());
 }

 @Test(expected = ClassCastException.class)
 public void testAddValueWithNonIntegerNumber1() {
     Frequency frequency = new Frequency();
     // Create a Double which is a Number but not an Integer
     Number nonIntegerNumber = Double.valueOf(1.5);
     // This should throw ClassCastException in original code
     // but would work in mutated code (which we want to catch)
     frequency.addValue(nonIntegerNumber);
 }

}
