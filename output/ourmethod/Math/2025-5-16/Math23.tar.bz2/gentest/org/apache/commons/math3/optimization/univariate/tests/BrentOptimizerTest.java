package gentest.org.apache.commons.math3.optimization.univariate.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.univariate.*;
import org.apache.commons.math3.util.Precision;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
 
public class BrentOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                      public void testDoOptimize_ReversedBounds() throws Exception {
                                                                                                                                                                                                                                                                                                          // Setup test function: f(x) = x^2
                                                                                                                                                                                                                                                                                                          org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                                                                                              public double value(double x) {
                                                                                                                                                                                                                                                                                                                  return x * x;
                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                          };
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Create optimizer
                                                                                                                                                                                                                                                                                                          org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                                                                              new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                          java.lang.reflect.Field minField = optimizer.getClass().getDeclaredField("min");
                                                                                                                                                                                                                                                                                                          minField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          minField.set(optimizer, 10.0);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          java.lang.reflect.Field maxField = optimizer.getClass().getDeclaredField("max");
                                                                                                                                                                                                                                                                                                          maxField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          maxField.set(optimizer, -10.0);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          java.lang.reflect.Field startValueField = optimizer.getClass().getDeclaredField("startValue");
                                                                                                                                                                                                                                                                                                          startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          startValueField.set(optimizer, 0.0);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          java.lang.reflect.Field goalTypeField = optimizer.getClass().getDeclaredField("goalType");
                                                                                                                                                                                                                                                                                                          goalTypeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          goalTypeField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          java.lang.reflect.Field funcField = optimizer.getClass().getDeclaredField("function");
                                                                                                                                                                                                                                                                                                          funcField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          funcField.set(optimizer, function);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Call doOptimize via reflection
                                                                                                                                                                                                                                                                                                          java.lang.reflect.Method doOptimizeMethod = optimizer.getClass().getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                                                          doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                          org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                                                              (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Should still find the minimum at x=0
                                                                                                                                                                                                                                                                                                          assertEquals(0.0, result.getPoint(), 1e-6);
                                                                                                                                                                                                                                                                                                          assertEquals(0.0, result.getValue(), 1e-6);
                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                              public void testDoOptimize_StartValueAtBoundary() throws Exception {
                                                                                                                                                                                                                                                                                                  // Setup test function: f(x) = (x-1)^2
                                                                                                                                                                                                                                                                                                  org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                                                                                                                                                      new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                                                                                                                                                              return Math.pow(x - 1, 2);
                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Create optimizer with default settings
                                                                                                                                                                                                                                                                                                  BrentOptimizer optimizer = new BrentOptimizer(1e-10, 1e-14);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Use reflection to set required parameters
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field goalTypeField = optimizer.getClass().getSuperclass().getDeclaredField("goal");
                                                                                                                                                                                                                                                                                                  goalTypeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  goalTypeField.set(optimizer, GoalType.MINIMIZE);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field minField = optimizer.getClass().getSuperclass().getDeclaredField("min");
                                                                                                                                                                                                                                                                                                  minField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  minField.set(optimizer, 0.0);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field maxField = optimizer.getClass().getSuperclass().getDeclaredField("max");
                                                                                                                                                                                                                                                                                                  maxField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  maxField.set(optimizer, 2.0);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field startValueField = optimizer.getClass().getSuperclass().getDeclaredField("startValue");
                                                                                                                                                                                                                                                                                                  startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  startValueField.set(optimizer, 0.0);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Use reflection to access protected doOptimize method
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                                                  doOptimize.setAccessible(true);
                                                                                                                                                                                                                                                                                                  UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Should still find the minimum at x=1
                                                                                                                                                                                                                                                                                                  assertEquals(1.0, result.getPoint(), 1e-6);
                                                                                                                                                                                                                                                                                                  assertEquals(0.0, result.getValue(), 1e-6);
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                              public void testDoOptimize_MultipleLocalMinima() throws Exception {
                                                                                                                                                                                                                                                                                                  // Setup test function: f(x) = x^4 - 3x^3 + 2x^2 + x
                                                                                                                                                                                                                                                                                                  org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                                                                                                      public double value(double x) {
                                                                                                                                                                                                                                                                                                          return Math.pow(x, 4) - 3*Math.pow(x, 3) + 2*Math.pow(x, 2) + x;
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Create optimizer with proper configuration
                                                                                                                                                                                                                                                                                                  org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                                                                      new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Use reflection to access protected doOptimize method
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Method doOptimize = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                                                  doOptimize.setAccessible(true);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Set required fields through reflection since they're not public
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field goalField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("goal");
                                                                                                                                                                                                                                                                                                  goalField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  goalField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field minField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("min");
                                                                                                                                                                                                                                                                                                  minField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  minField.set(optimizer, 1.0);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field maxField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("max");
                                                                                                                                                                                                                                                                                                  maxField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  maxField.set(optimizer, 2.0);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  java.lang.reflect.Field startValueField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("startValue");
                                                                                                                                                                                                                                                                                                  startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  startValueField.set(optimizer, 1.5);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Optimize
                                                                                                                                                                                                                                                                                                  org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                                                      (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Verify result is close to expected local minimum
                                                                                                                                                                                                                                                                                                  assertEquals(1.366, result.getPoint(), 1e-3);
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                              public void testDoOptimize_VeryTightTolerances() {
                                                                                                                                                                                                                                                                                  // Setup test function: f(x) = x^4 - 2x^2 + x
                                                                                                                                                                                                                                                                                  org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                                      public double value(double x) {
                                                                                                                                                                                                                                                                                          return Math.pow(x, 4) - 2*Math.pow(x, 2) + x;
                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Create optimizer with very tight tolerances
                                                                                                                                                                                                                                                                                  org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                                                      new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-15, 1e-15);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                                      // Set bounds and start value
                                                                                                                                                                                                                                                                                      Field minField = optimizer.getClass().getDeclaredField("searchMin");
                                                                                                                                                                                                                                                                                      minField.setAccessible(true);
                                                                                                                                                                                                                                                                                      minField.set(optimizer, -2.0);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field maxField = optimizer.getClass().getDeclaredField("searchMax");
                                                                                                                                                                                                                                                                                      maxField.setAccessible(true);
                                                                                                                                                                                                                                                                                      maxField.set(optimizer, 2.0);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field startValueField = optimizer.getClass().getDeclaredField("startValue");
                                                                                                                                                                                                                                                                                      startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                                      startValueField.set(optimizer, 0.5);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field goalTypeField = optimizer.getClass().getDeclaredField("goal");
                                                                                                                                                                                                                                                                                      goalTypeField.setAccessible(true);
                                                                                                                                                                                                                                                                                      goalTypeField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field functionField = optimizer.getClass().getDeclaredField("function");
                                                                                                                                                                                                                                                                                      functionField.setAccessible(true);
                                                                                                                                                                                                                                                                                      functionField.set(optimizer, function);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Optimize using reflection to access protected method
                                                                                                                                                                                                                                                                                      Method doOptimizeMethod = optimizer.getClass().getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                                          (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify we get a precise result
                                                                                                                                                                                                                                                                                      double expectedMin = -1.1914878839531184;
                                                                                                                                                                                                                                                                                      assertEquals(expectedMin, result.getPoint(), 1e-10);
                                                                                                                                                                                                                                                                                      assertEquals(function.value(expectedMin), result.getValue(), 1e-10);
                                                                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                                                                      fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                          public void testDoOptimize_QuadraticMaximization() {
                                                                                                                                                                                                                                                              // Setup test function: f(x) = -(x-2)^2 + 3, maximum at x=2
                                                                                                                                                                                                                                                              org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                                                                                                                  new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                                                                      public double value(double x) {
                                                                                                                                                                                                                                                                          return -Math.pow(x - 2, 2) + 3;
                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create optimizer with relative and absolute tolerances
                                                                                                                                                                                                                                                              double relTol = 1e-10;
                                                                                                                                                                                                                                                              double absTol = 1e-10;
                                                                                                                                                                                                                                                              org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                                  new org.apache.commons.math3.optimization.univariate.BrentOptimizer(relTol, absTol);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create optimization problem parameters
                                                                                                                                                                                                                                                              int maxEval = 100;
                                                                                                                                                                                                                                                              org.apache.commons.math3.optimization.GoalType goalType = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
                                                                                                                                                                                                                                                              double min = 0.0;
                                                                                                                                                                                                                                                              double max = 4.0;
                                                                                                                                                                                                                                                              double initialGuess = 1.0;
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Optimize using public API
                                                                                                                                                                                                                                                              org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                  optimizer.optimize(maxEval, function, goalType, min, max, initialGuess);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Verify result is close to expected maximum
                                                                                                                                                                                                                                                              assertEquals(2.0, result.getPoint(), 1e-6);
                                                                                                                                                                                                                                                              assertEquals(3.0, result.getValue(), 1e-6);
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                  public void testDoOptimize_QuadraticMinimization() {
                                                                                                                                                                                                                      // Setup test function: f(x) = (x-2)^2 + 3, minimum at x=2
                                                                                                                                                                                                                      org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                                                                              return Math.pow(x - 2, 2) + 3;
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      };
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create optimizer with reasonable tolerances
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                          new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Perform optimization with search bounds that include the minimum
                                                                                                                                                                                                                      double min = 0.0;
                                                                                                                                                                                                                      double max = 4.0;
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                          optimizer.optimize(200, function, org.apache.commons.math3.optimization.GoalType.MINIMIZE, min, max);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify result is close to expected minimum
                                                                                                                                                                                                                      assertEquals(2.0, result.getPoint(), 1e-6);
                                                                                                                                                                                                                      assertEquals(3.0, result.getValue(), 1e-6);
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                  public void testDoOptimize_WithConvergenceChecker() throws Exception {
                                                                                                                                                                                                                      // Setup test function: f(x) = x^2
                                                                                                                                                                                                                      org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                                                                          new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                              public double value(double x) {
                                                                                                                                                                                                                                  return x * x;
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          };
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Mock convergence checker with correct generic type
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                                                                                                                                                          new org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair>() {
                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                              public boolean converged(int iteration, org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair previous, org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair current) {
                                                                                                                                                                                                                                  return true; // Force immediate convergence
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          };
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create optimizer with checker
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                          new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14, checker);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create optimization data with correct class names
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.GoalType goal = 
                                                                                                                                                                                                                          org.apache.commons.math3.optimization.GoalType.MINIMIZE;
                                                                                                                                                                                                                      double startValue = 5.0;
                                                                                                                                                                                                                      double min = -10.0;
                                                                                                                                                                                                                      double max = 10.0;
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Get reflection access to protected members
                                                                                                                                                                                                                      java.lang.reflect.Field optDataField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("optData");
                                                                                                                                                                                                                      java.lang.reflect.Method doOptimize = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Set optimization data using reflection
                                                                                                                                                                                                                      optDataField.setAccessible(true);
                                                                                                                                                                                                                      optDataField.set(optimizer, new Object[]{goal, min, max, startValue, function});
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to access protected doOptimize method
                                                                                                                                                                                                                      doOptimize.setAccessible(true);
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                          (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify the result is the start value (since we forced immediate convergence)
                                                                                                                                                                                                                      org.junit.Assert.assertEquals(5.0, result.getPoint(), 1e-6);
                                                                                                                                                                                                                      org.junit.Assert.assertEquals(25.0, result.getValue(), 1e-6);
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                             public void testDoOptimizeTriggersDefaultTermination() throws Exception {
                                                                                                                                                                                                                 // Setup test function: simple quadratic function with minimum at x=2
                                                                                                                                                                                                                 org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                                                                     new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                         public double value(double x) {
                                                                                                                                                                                                                             return (x - 2) * (x - 2);
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                     };
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create optimizer with reasonable tolerances
                                                                                                                                                                                                                 double relTol = 1e-10;
                                                                                                                                                                                                                 double absTol = 1e-10;
                                                                                                                                                                                                                 BrentOptimizer optimizer = new BrentOptimizer(relTol, absTol);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Use reflection to set private fields since we can't mock protected methods
                                                                                                                                                                                                                 java.lang.reflect.Field goalTypeField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                                                                                     .getDeclaredField("goal");
                                                                                                                                                                                                                 goalTypeField.setAccessible(true);
                                                                                                                                                                                                                 goalTypeField.set(optimizer, GoalType.MINIMIZE);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 java.lang.reflect.Field minField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                                                                                     .getDeclaredField("min");
                                                                                                                                                                                                                 minField.setAccessible(true);
                                                                                                                                                                                                                 minField.set(optimizer, 0.0);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 java.lang.reflect.Field maxField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                                                                                     .getDeclaredField("max");
                                                                                                                                                                                                                 maxField.setAccessible(true);
                                                                                                                                                                                                                 maxField.set(optimizer, 4.0);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 java.lang.reflect.Field startValueField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                                                                                     .getDeclaredField("startValue");
                                                                                                                                                                                                                 startValueField.setAccessible(true);
                                                                                                                                                                                                                 startValueField.set(optimizer, 1.0);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Use reflection to access protected doOptimize method
                                                                                                                                                                                                                 java.lang.reflect.Method doOptimizeMethod = BrentOptimizer.class
                                                                                                                                                                                                                     .getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                 doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Execute optimization
                                                                                                                                                                                                                 UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify results
                                                                                                                                                                                                                 assertEquals(2.0, result.getPoint(), 1e-8);  // Should find minimum at x=2
                                                                                                                                                                                                                 assertEquals(0.0, result.getValue(), 1e-8);  // Minimum value should be 0
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // The test will pass with original code, but would show different 
                                                                                                                                                                                                                 // coverage metrics with the mutated code (else if (true))
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                        public void testDoOptimizeReturnsOverallBestPoint() throws Exception {
                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                            double rel = 1e-10;
                                                                                                                                                                                                            double abs = 1e-14;
                                                                                                                                                                                                            BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Mock the necessary components
                                                                                                                                                                                                            org.apache.commons.math3.analysis.UnivariateFunction function = mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                                                                                            when(function.value(anyDouble())).thenReturn(1.0, 0.5, 0.3, 0.4, 0.2, 0.6);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create test implementation of abstract methods
                                                                                                                                                                                                            BrentOptimizer testOptimizer = new BrentOptimizer(rel, abs) {
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                protected UnivariatePointValuePair doOptimize() {
                                                                                                                                                                                                                    // Setup initial conditions through reflection since methods are protected
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        Method setMin = BaseAbstractUnivariateOptimizer.class.getDeclaredMethod("setMin", double.class);
                                                                                                                                                                                                                        setMin.setAccessible(true);
                                                                                                                                                                                                                        setMin.invoke(this, 0.0);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        Method setMax = BaseAbstractUnivariateOptimizer.class.getDeclaredMethod("setMax", double.class);
                                                                                                                                                                                                                        setMax.setAccessible(true);
                                                                                                                                                                                                                        setMax.invoke(this, 1.0);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        Method setStartValue = BaseAbstractUnivariateOptimizer.class.getDeclaredMethod("setStartValue", double.class);
                                                                                                                                                                                                                        setStartValue.setAccessible(true);
                                                                                                                                                                                                                        setStartValue.invoke(this, 0.5);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        Method setGoalType = BaseAbstractUnivariateOptimizer.class.getDeclaredMethod("setGoalType", GoalType.class);
                                                                                                                                                                                                                        setGoalType.setAccessible(true);
                                                                                                                                                                                                                        setGoalType.invoke(this, GoalType.MINIMIZE);
                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                        throw new RuntimeException(e);
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Force the optimization to go through multiple points
                                                                                                                                                                                                                    // where the best point is not the current one
                                                                                                                                                                                                                    return super.doOptimize();
                                                                                                                                                                                                                }
                                                                                                                                                                                                                
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                protected double computeObjectiveValue(double point) {
                                                                                                                                                                                                                    return function.value(point);
                                                                                                                                                                                                                }
                                                                                                                                                                                                            };
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Execute using reflection to access protected method
                                                                                                                                                                                                            Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                            doOptimize.setAccessible(true);
                                                                                                                                                                                                            UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimize.invoke(testOptimizer);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify - the best value should be 0.2 (5th call)
                                                                                                                                                                                                            assertEquals(0.2, result.getValue(), 1e-10);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify the function was called multiple times
                                                                                                                                                                                                            verify(function, atLeast(5)).value(anyDouble());
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Additional verification that we're not just getting the last point
                                                                                                                                                                                                            assertNotEquals(0.6, result.getValue(), 1e-10);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                               public void testDoOptimizeReturnsOverallBestPointNotJustBetterThanPrevious() throws Exception {
                                                                                                                                                                                                   // Setup test with known values where best point is not the previous point
                                                                                                                                                                                                   double rel = 1e-10;
                                                                                                                                                                                                   double abs = 1e-14;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Create a test subclass that allows us to control the objective value computation
                                                                                                                                                                                                   BrentOptimizer optimizer = new BrentOptimizer(rel, abs) {
                                                                                                                                                                                                       private int callCount = 0;
                                                                                                                                                                                                       
                                                                                                                                                                                                       @Override
                                                                                                                                                                                                       protected double computeObjectiveValue(double point) {
                                                                                                                                                                                                           // Sequence of return values: 10.0, 5.0, 8.0, 8.0...
                                                                                                                                                                                                           callCount++;
                                                                                                                                                                                                           switch (callCount) {
                                                                                                                                                                                                               case 1: return 10.0;  // initial bad value
                                                                                                                                                                                                               case 2: return 5.0;    // first improvement (best)
                                                                                                                                                                                                               default: return 8.0;   // final value and subsequent calls
                                                                                                                                                                                                           }
                                                                                                                                                                                                       }
                                                                                                                                                                                                   };
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to access protected doOptimize method
                                                                                                                                                                                                   Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                   doOptimize.setAccessible(true);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Mock getters using a spy
                                                                                                                                                                                                   BrentOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                   when(spyOptimizer.getGoalType()).thenReturn(GoalType.MINIMIZE);
                                                                                                                                                                                                   when(spyOptimizer.getMin()).thenReturn(0.0);
                                                                                                                                                                                                   when(spyOptimizer.getMax()).thenReturn(10.0);
                                                                                                                                                                                                   when(spyOptimizer.getStartValue()).thenReturn(5.0);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Execute optimization using reflection
                                                                                                                                                                                                   UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimize.invoke(spyOptimizer);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the result is the best point found (value = 5.0), not just better than previous
                                                                                                                                                                                                   assertEquals(5.0, result.getValue(), 1e-10);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // The mutant would return the point with value 8.0 (better than previous but not overall best)
                                                                                                                                                                                                   // So this test would fail if the mutant is present
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                          public void testBestPointSelectionDetectsMutant() throws Exception {
                                                                                                                                                                                              // Setup test function with known minimum
                                                                                                                                                                                              org.apache.commons.math3.analysis.UnivariateFunction func = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                  @Override
                                                                                                                                                                                                  public double value(double x) {
                                                                                                                                                                                                      return (x - 0.5) * (x - 0.5);
                                                                                                                                                                                                  }
                                                                                                                                                                                              };
                                                                                                                                                                                              
                                                                                                                                                                                              // Create optimizer with loose tolerances to ensure multiple iterations
                                                                                                                                                                                              double relTol = 1e-3;
                                                                                                                                                                                              double absTol = 1e-3;
                                                                                                                                                                                              BrentOptimizer optimizer = new BrentOptimizer(relTol, absTol);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set bounds and start value through reflection
                                                                                                                                                                                              java.lang.reflect.Method setMin = BrentOptimizer.class.getDeclaredMethod("setMin", double.class);
                                                                                                                                                                                              setMin.setAccessible(true);
                                                                                                                                                                                              setMin.invoke(optimizer, 0.0);
                                                                                                                                                                                              
                                                                                                                                                                                              java.lang.reflect.Method setMax = BrentOptimizer.class.getDeclaredMethod("setMax", double.class);
                                                                                                                                                                                              setMax.setAccessible(true);
                                                                                                                                                                                              setMax.invoke(optimizer, 1.0);
                                                                                                                                                                                              
                                                                                                                                                                                              java.lang.reflect.Method setStartValue = BrentOptimizer.class.getDeclaredMethod("setStartValue", double.class);
                                                                                                                                                                                              setStartValue.setAccessible(true);
                                                                                                                                                                                              setStartValue.invoke(optimizer, 0.2); // Start away from minimum
                                                                                                                                                                                              
                                                                                                                                                                                              // Track evaluations
                                                                                                                                                                                              final double[] evalPoints = new double[3];
                                                                                                                                                                                              final int[] evalCount = {0};
                                                                                                                                                                                              
                                                                                                                                                                                              // Mock computeObjectiveValue through reflection
                                                                                                                                                                                              java.lang.reflect.Field funcField = BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                              funcField.setAccessible(true);
                                                                                                                                                                                              funcField.set(optimizer, new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                  @Override
                                                                                                                                                                                                  public double value(double x) {
                                                                                                                                                                                                      if (evalCount[0] < evalPoints.length) {
                                                                                                                                                                                                          evalPoints[evalCount[0]] = x;
                                                                                                                                                                                                      }
                                                                                                                                                                                                      evalCount[0]++;
                                                                                                                                                                                                      return func.value(x);
                                                                                                                                                                                                  }
                                                                                                                                                                                              });
                                                                                                                                                                                              
                                                                                                                                                                                              // Run optimization via reflection
                                                                                                                                                                                              java.lang.reflect.Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                              doOptimize.setAccessible(true);
                                                                                                                                                                                              UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify that the optimization properly considered intermediate points
                                                                                                                                                                                              assertTrue("Optimizer should have evaluated at least 3 points", evalCount[0] >= 3);
                                                                                                                                                                                              
                                                                                                                                                                                              // Check that the result is close to the true minimum (0.5)
                                                                                                                                                                                              assertEquals(0.5, result.getPoint(), 1e-2);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify that the best point selection worked correctly
                                                                                                                                                                                              assertNotEquals("Optimizer should not be stuck at initial point",
                                                                                                                                                                                                             0.2, result.getPoint(), 1e-10);
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                         public void testDoOptimizeDetectsIsMinimMutant() {
                                                                                                                                                                             // Setup a simple quadratic function: f(x) = (x-2)^2 + 3
                                                                                                                                                                             // Minimum is at x=2 (value=3), maximum would be at boundaries
                                                                                                                                                                             org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                 public double value(double x) {
                                                                                                                                                                                     return Math.pow(x - 2, 2) + 3;
                                                                                                                                                                                 }
                                                                                                                                                                             };
                                                                                                                                                                             
                                                                                                                                                                             // Create optimizer with MINIMIZE goal
                                                                                                                                                                             org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                 new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14);
                                                                                                                                                                             
                                                                                                                                                                             // Perform optimization for MINIMIZE
                                                                                                                                                                             org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = optimizer.optimize(
                                                                                                                                                                                 100,  // maxEval
                                                                                                                                                                                 function,
                                                                                                                                                                                 org.apache.commons.math3.optimization.GoalType.MINIMIZE,
                                                                                                                                                                                 0, 4);  // search interval
                                                                                                                                                                             
                                                                                                                                                                             // Verify we found the minimum
                                                                                                                                                                             assertEquals(2.0, result.getPoint(), 1e-8);
                                                                                                                                                                             assertEquals(3.0, result.getValue(), 1e-8);
                                                                                                                                                                             
                                                                                                                                                                             // Now test with MAXIMIZE goal to ensure both cases work
                                                                                                                                                                             result = optimizer.optimize(
                                                                                                                                                                                 100,  // maxEval
                                                                                                                                                                                 function,
                                                                                                                                                                                 org.apache.commons.math3.optimization.GoalType.MAXIMIZE,
                                                                                                                                                                                 0, 4);  // search interval
                                                                                                                                                                             
                                                                                                                                                                             // Should find maximum at boundary (x=0 gives highest value)
                                                                                                                                                                             assertEquals(0.0, result.getPoint(), 1e-8);
                                                                                                                                                                             assertEquals(7.0, result.getValue(), 1e-8);
                                                                                                                                                                         }

    @Test
                                                                                                                                                                public void testDoOptimizeDetectsIsMinimMutant1() throws Exception {
                                                                                                                                                                    // Test function: f(x) = (x-2)^2, minimum at x=2
                                                                                                                                                                    org.apache.commons.math3.analysis.UnivariateFunction func = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                        public double value(double x) {
                                                                                                                                                                            return (x - 2) * (x - 2);
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    // Create optimizer with dummy convergence checker that never converges
                                                                                                                                                                    // so we can test the termination condition
                                                                                                                                                                    org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                                                                                                        new org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair>() {
                                                                                                                                                                            public boolean converged(int iter, org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair prev, 
                                                                                                                                                                                                   org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair current) {
                                                                                                                                                                                return false;
                                                                                                                                                                            }
                                                                                                                                                                        };
                                                                                                                                                                    org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                        new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14, checker);
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected doOptimize method
                                                                                                                                                                    java.lang.reflect.Method doOptimize = optimizer.getClass().getDeclaredMethod("doOptimize");
                                                                                                                                                                    doOptimize.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Set optimization parameters through reflection
                                                                                                                                                                    java.lang.reflect.Field goalField = optimizer.getClass().getSuperclass().getDeclaredField("goal");
                                                                                                                                                                    goalField.setAccessible(true);
                                                                                                                                                                    goalField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                                    
                                                                                                                                                                    java.lang.reflect.Field minField = optimizer.getClass().getSuperclass().getDeclaredField("min");
                                                                                                                                                                    minField.setAccessible(true);
                                                                                                                                                                    minField.set(optimizer, 0.0);
                                                                                                                                                                    
                                                                                                                                                                    java.lang.reflect.Field maxField = optimizer.getClass().getSuperclass().getDeclaredField("max");
                                                                                                                                                                    maxField.setAccessible(true);
                                                                                                                                                                    maxField.set(optimizer, 4.0);
                                                                                                                                                                    
                                                                                                                                                                    java.lang.reflect.Field startValueField = optimizer.getClass().getSuperclass().getDeclaredField("startValue");
                                                                                                                                                                    startValueField.setAccessible(true);
                                                                                                                                                                    startValueField.set(optimizer, 1.0);
                                                                                                                                                                    
                                                                                                                                                                    // The best point should be close to x=2 (minimum)
                                                                                                                                                                    org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair resultMin = 
                                                                                                                                                                        (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                                    assertTrue("For minimization, result should be close to minimum", 
                                                                                                                                                                              Math.abs(resultMin.getPoint() - 2) < 1e-6);
                                                                                                                                                                    
                                                                                                                                                                    // For maximization test (using same function)
                                                                                                                                                                    goalField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MAXIMIZE);
                                                                                                                                                                    
                                                                                                                                                                    // The best point should be at one of the boundaries (since parabola is unbounded)
                                                                                                                                                                    org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair resultMax = 
                                                                                                                                                                        (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                                    assertTrue("For maximization, result should be at boundary",
                                                                                                                                                                             Math.abs(resultMax.getPoint() - 0) < 1e-6 || 
                                                                                                                                                                             Math.abs(resultMax.getPoint() - 4) < 1e-6);
                                                                                                                                                                    
                                                                                                                                                                    // Verify the mutant would fail these tests by returning the worst points
                                                                                                                                                                }

    @Test
                                                                                                                                                       public void testOptimizationRespectsGoalType() {
                                                                                                                                                           // Setup test function: f(x) = (x-2)^2 + 1 (min at x=2, max at bounds)
                                                                                                                                                           org.apache.commons.math3.analysis.UnivariateFunction func = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                               @Override
                                                                                                                                                               public double value(double x) {
                                                                                                                                                                   return Math.pow(x - 2, 2) + 1;
                                                                                                                                                               }
                                                                                                                                                           };
                                                                                                                                                           
                                                                                                                                                           // Create optimizer with reasonable thresholds
                                                                                                                                                           double relTol = 1e-10;
                                                                                                                                                           double absTol = 1e-10;
                                                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                               new org.apache.commons.math3.optimization.univariate.BrentOptimizer(relTol, absTol);
                                                                                                                                                           
                                                                                                                                                           try {
                                                                                                                                                               // Use reflection to access protected methods and fields
                                                                                                                                                               Method setGoalType = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                   .getDeclaredMethod("setGoalType", org.apache.commons.math3.optimization.GoalType.class);
                                                                                                                                                               setGoalType.setAccessible(true);
                                                                                                                                                               Method setMin = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                   .getDeclaredMethod("setMin", double.class);
                                                                                                                                                               setMin.setAccessible(true);
                                                                                                                                                               Method setMax = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                   .getDeclaredMethod("setMax", double.class);
                                                                                                                                                               setMax.setAccessible(true);
                                                                                                                                                               Method setStartValue = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                   .getDeclaredMethod("setStartValue", double.class);
                                                                                                                                                               setStartValue.setAccessible(true);
                                                                                                                                                               Method doOptimize = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                   .getDeclaredMethod("doOptimize");
                                                                                                                                                               doOptimize.setAccessible(true);
                                                                                                                                                               
                                                                                                                                                               // Test minimization
                                                                                                                                                               setGoalType.invoke(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                               setMin.invoke(optimizer, 0.0);
                                                                                                                                                               setMax.invoke(optimizer, 4.0);
                                                                                                                                                               setStartValue.invoke(optimizer, 1.0);
                                                                                                                                                               org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair minResult = 
                                                                                                                                                                   (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                               assertEquals(2.0, minResult.getPoint(), 1e-8); // Should find minimum at x=2
                                                                                                                                                               
                                                                                                                                                               // Test maximization
                                                                                                                                                               setGoalType.invoke(optimizer, org.apache.commons.math3.optimization.GoalType.MAXIMIZE);
                                                                                                                                                               setMin.invoke(optimizer, 0.0);
                                                                                                                                                               setMax.invoke(optimizer, 4.0);
                                                                                                                                                               setStartValue.invoke(optimizer, 3.0);
                                                                                                                                                               org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair maxResult = 
                                                                                                                                                                   (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                               // Should find maximum at one of the bounds (either 0 or 4)
                                                                                                                                                               assertTrue(maxResult.getPoint() == 0.0 || maxResult.getPoint() == 4.0);
                                                                                                                                                               
                                                                                                                                                               // Verify function values are correct for each goal type
                                                                                                                                                               assertTrue(minResult.getValue() < maxResult.getValue());
                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                               fail("Reflection failed: " + e.getMessage());
                                                                                                                                                           }
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testDoOptimizeDetectsIsMinimMutant2() throws Exception {
                                                                                                                                                      // Setup test function with clear minimum and maximum
                                                                                                                                                      org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                          new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                              @Override
                                                                                                                                                              public double value(double x) {
                                                                                                                                                                  return (x - 2) * (x - 2); // parabola with min at x=2
                                                                                                                                                              }
                                                                                                                                                          };
                                                                                                                                                      double rel = 1e-10;
                                                                                                                                                      double abs = 1e-10;
                                                                                                                                                      
                                                                                                                                                      // Create real optimizer with MINIMIZE goal
                                                                                                                                                      BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to set protected fields
                                                                                                                                                      java.lang.reflect.Field goalField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                          .getDeclaredField("goal");
                                                                                                                                                      goalField.setAccessible(true);
                                                                                                                                                      goalField.set(optimizer, GoalType.MINIMIZE);
                                                                                                                                                      
                                                                                                                                                      java.lang.reflect.Field minField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                          .getDeclaredField("min");
                                                                                                                                                      minField.setAccessible(true);
                                                                                                                                                      minField.set(optimizer, 1.0);
                                                                                                                                                      
                                                                                                                                                      java.lang.reflect.Field maxField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                          .getDeclaredField("max");
                                                                                                                                                      maxField.setAccessible(true);
                                                                                                                                                      maxField.set(optimizer, 3.0);
                                                                                                                                                      
                                                                                                                                                      java.lang.reflect.Field startValueField = BrentOptimizer.class.getSuperclass()
                                                                                                                                                          .getDeclaredField("startValue");
                                                                                                                                                      startValueField.setAccessible(true);
                                                                                                                                                      startValueField.set(optimizer, 1.5);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to call protected doOptimize method
                                                                                                                                                      java.lang.reflect.Method doOptimizeMethod = BrentOptimizer.class
                                                                                                                                                          .getDeclaredMethod("doOptimize");
                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                      UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                      
                                                                                                                                                      // Verify the result is indeed the minimum (x≈2)
                                                                                                                                                      assertEquals(2.0, result.getPoint(), 1e-6);
                                                                                                                                                      assertEquals(0.0, result.getValue(), 1e-6);
                                                                                                                                                      
                                                                                                                                                      // The mutant would have returned the maximum (x=1 or x=3) instead
                                                                                                                                                      // because it would use false (MAXIMIZE) in the best() comparison
                                                                                                                                                  }

    @Test
                                                                                                                                         public void testIterationCountIncrementsCorrectly() throws Exception {
                                                                                                                                             // Setup test with mock convergence checker
                                                                                                                                             org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                                                                                                                                                 mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                                             
                                                                                                                                             // Create optimizer with mock checker that will return true after 5 iterations
                                                                                                                                             org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                 new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14, mockChecker);
                                                                                                                                             
                                                                                                                                             // Mock the behavior of computeObjectiveValue to return simple quadratic function
                                                                                                                                             org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                 mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                             when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                                                                                                                 double x = invocation.getArgument(0);
                                                                                                                                                 return (x - 2) * (x - 2); // minimum at x=2
                                                                                                                                             });
                                                                                                                                             
                                                                                                                                             // Setup optimization problem
                                                                                                                                             org.apache.commons.math3.optimization.GoalType goalType = 
                                                                                                                                                 org.apache.commons.math3.optimization.GoalType.MINIMIZE;
                                                                                                                                             double min = 1;
                                                                                                                                             double max = 3;
                                                                                                                                             double startValue = 1.5;
                                                                                                                                             
                                                                                                                                             // Use reflection to set up test (since original method is protected)
                                                                                                                                             Method doOptimize = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                 .getDeclaredMethod("doOptimize");
                                                                                                                                             doOptimize.setAccessible(true);
                                                                                                                                             
                                                                                                                                             // Set up mock checker to return true after exactly 5 iterations
                                                                                                                                             when(mockChecker.converged(anyInt(), any(), any()))
                                                                                                                                                 .thenAnswer(invocation -> {
                                                                                                                                                     int iter = invocation.getArgument(0);
                                                                                                                                                     return iter >= 5; // Should converge after 5 iterations
                                                                                                                                                 });
                                                                                                                                             
                                                                                                                                             // Execute optimization
                                                                                                                                             org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                 (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                             
                                                                                                                                             // Verify that checker was called with iter=5 (would fail with --iter mutation)
                                                                                                                                             verify(mockChecker, atLeastOnce()).converged(eq(5), any(), any());
                                                                                                                                             
                                                                                                                                             // Additional verification that optimization completed successfully
                                                                                                                                             assertNotNull(result);
                                                                                                                                             assertEquals(2.0, result.getPoint(), 1e-8); // Should find minimum near x=2
                                                                                                                                         }

    @Test
                                                                                                                                    public void testIterationCountForConvergenceChecking() {
                                                                                                                                        // Setup mock convergence checker that records iterations
                                                                                                                                        final List<Integer> recordedIterations = new ArrayList<>();
                                                                                                                                        ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                                                                                                                        when(mockChecker.converged(anyInt(), any(), any())).thenAnswer(invocation -> {
                                                                                                                                            int iter = invocation.getArgument(0);
                                                                                                                                            recordedIterations.add(iter);
                                                                                                                                            return iter >= 10; // Force convergence after 10 iterations
                                                                                                                                        });
                                                                                                                                    
                                                                                                                                        // Create test subclass that exposes protected methods
                                                                                                                                        class TestBrentOptimizer extends BrentOptimizer {
                                                                                                                                            public TestBrentOptimizer(double rel, double abs, ConvergenceChecker<UnivariatePointValuePair> checker) {
                                                                                                                                                super(rel, abs, checker);
                                                                                                                                            }
                                                                                                                                    
                                                                                                                                            @Override
                                                                                                                                            public UnivariatePointValuePair doOptimize() {
                                                                                                                                                return super.doOptimize();
                                                                                                                                            }
                                                                                                                                    
                                                                                                                                            @Override
                                                                                                                                            protected double computeObjectiveValue(double x) {
                                                                                                                                                return 1.0; // Simple constant function
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    
                                                                                                                                        // Setup test parameters
                                                                                                                                        double rel = 1e-10;
                                                                                                                                        double abs = 1e-14;
                                                                                                                                        TestBrentOptimizer optimizer = new TestBrentOptimizer(rel, abs, mockChecker);
                                                                                                                                        
                                                                                                                                        // Mock the necessary methods
                                                                                                                                        when(optimizer.getGoalType()).thenReturn(GoalType.MINIMIZE);
                                                                                                                                        when(optimizer.getMin()).thenReturn(-1.0);
                                                                                                                                        when(optimizer.getMax()).thenReturn(1.0);
                                                                                                                                        when(optimizer.getStartValue()).thenReturn(0.0);
                                                                                                                                    
                                                                                                                                        // Execute
                                                                                                                                        optimizer.doOptimize();
                                                                                                                                    
                                                                                                                                        // Verify iteration counts
                                                                                                                                        // Should see iterations 0 through 10 (11 total calls)
                                                                                                                                        assertEquals(11, recordedIterations.size());
                                                                                                                                        for (int i = 0; i < recordedIterations.size(); i++) {
                                                                                                                                            assertEquals(i, (int)recordedIterations.get(i));
                                                                                                                                        }
                                                                                                                                    }

    @Test
                                                                                                                       public void testIterationCounterIncrements() throws Exception {
                                                                                                                           // Setup test function that requires multiple iterations
                                                                                                                           org.apache.commons.math3.analysis.UnivariateFunction func = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                               public double value(double x) {
                                                                                                                                   return (x - 5) * (x - 5); // Simple quadratic with minimum at x=5
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Mock convergence checker that only converges after 3 iterations
                                                                                                                           org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                                                                                                                               mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                           when(mockChecker.converged(anyInt(), any(), any()))
                                                                                                                               .thenAnswer(invocation -> {
                                                                                                                                   int iter = invocation.getArgument(0);
                                                                                                                                   return iter >= 3; // Only converge after 3 iterations
                                                                                                                               });
                                                                                                                           
                                                                                                                           // Create optimizer with mocked checker
                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                               new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-6, 1e-6, mockChecker);
                                                                                                                           
                                                                                                                           // Get protected doOptimize method via reflection
                                                                                                                           Method doOptimize = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                           doOptimize.setAccessible(true);
                                                                                                                           
                                                                                                                           // Set optimization parameters through reflection
                                                                                                                           Field goalField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("goal");
                                                                                                                           goalField.setAccessible(true);
                                                                                                                           goalField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                           
                                                                                                                           Field minField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("min");
                                                                                                                           minField.setAccessible(true);
                                                                                                                           minField.set(optimizer, 0.0);
                                                                                                                           
                                                                                                                           Field maxField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("max");
                                                                                                                           maxField.setAccessible(true);
                                                                                                                           maxField.set(optimizer, 10.0);
                                                                                                                           
                                                                                                                           Field startValueField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("startValue");
                                                                                                                           startValueField.setAccessible(true);
                                                                                                                           startValueField.set(optimizer, 1.0);
                                                                                                                           
                                                                                                                           // Set objective function through reflection
                                                                                                                           Field funcField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("function");
                                                                                                                           funcField.setAccessible(true);
                                                                                                                           funcField.set(optimizer, func);
                                                                                                                           
                                                                                                                           // Perform optimization
                                                                                                                           org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                               (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                           
                                                                                                                           // Verify the checker was called with increasing iteration counts
                                                                                                                           verify(mockChecker, atLeastOnce()).converged(eq(0), any(), any());
                                                                                                                           verify(mockChecker, atLeastOnce()).converged(eq(1), any(), any());
                                                                                                                           verify(mockChecker, atLeastOnce()).converged(eq(2), any(), any());
                                                                                                                           
                                                                                                                           // Also verify the optimization actually completed (sanity check)
                                                                                                                           assertNotNull(result);
                                                                                                                           assertEquals(5.0, result.getPoint(), 1e-6);
                                                                                                                       }

    @Test
                                                                                                                  public void testDoOptimizeTerminationByBrentsCriterion() throws Exception {
                                                                                                                      // Setup test data
                                                                                                                      final double rel = 1e-10;
                                                                                                                      final double abs = 1e-14;
                                                                                                                      BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                      
                                                                                                                      // Mock the objective function (simple quadratic x^2 - 2x + 1 with minimum at x=1)
                                                                                                                      org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                          new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                              @Override
                                                                                                                              public double value(double x) {
                                                                                                                                  return x * x - 2 * x + 1;
                                                                                                                              }
                                                                                                                          };
                                                                                                                      
                                                                                                                      // Use reflection to set bounds and goal type
                                                                                                                      java.lang.reflect.Method setMinMethod = BrentOptimizer.class.getDeclaredMethod("setMin", double.class);
                                                                                                                      setMinMethod.setAccessible(true);
                                                                                                                      setMinMethod.invoke(optimizer, 0.0);
                                                                                                                      
                                                                                                                      java.lang.reflect.Method setMaxMethod = BrentOptimizer.class.getDeclaredMethod("setMax", double.class);
                                                                                                                      setMaxMethod.setAccessible(true);
                                                                                                                      setMaxMethod.invoke(optimizer, 2.0);
                                                                                                                      
                                                                                                                      java.lang.reflect.Method setStartValueMethod = BrentOptimizer.class.getDeclaredMethod("setStartValue", double.class);
                                                                                                                      setStartValueMethod.setAccessible(true);
                                                                                                                      setStartValueMethod.invoke(optimizer, 1.0);
                                                                                                                      
                                                                                                                      java.lang.reflect.Method setGoalTypeMethod = BrentOptimizer.class.getDeclaredMethod("setGoalType", org.apache.commons.math3.optimization.GoalType.class);
                                                                                                                      setGoalTypeMethod.setAccessible(true);
                                                                                                                      setGoalTypeMethod.invoke(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                      
                                                                                                                      // Use reflection to set the objective function
                                                                                                                      java.lang.reflect.Method setObjectiveFunctionMethod = BrentOptimizer.class.getDeclaredMethod("setObjectiveFunction", org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                      setObjectiveFunctionMethod.setAccessible(true);
                                                                                                                      setObjectiveFunctionMethod.invoke(optimizer, function);
                                                                                                                      
                                                                                                                      // Use reflection to call protected doOptimize method
                                                                                                                      java.lang.reflect.Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                      org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                          (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                      
                                                                                                                      // Verify termination at correct point (minimum at x=1)
                                                                                                                      assertEquals(1.0, result.getPoint(), 1e-8);
                                                                                                                      assertEquals(0.0, result.getValue(), 1e-8);
                                                                                                                      
                                                                                                                      // Verify the optimization terminated via Brent's criterion
                                                                                                                      assertTrue(org.apache.commons.math3.util.FastMath.abs(result.getPoint() - 1.0) < 1e-8);
                                                                                                                  }

    @Test
                                                                                         public void testBestPointSelectionDetectsMutant1() throws Exception {
                                                                                             // Setup test with known values where current and previous differ
                                                                                             double rel = 1e-10;
                                                                                             double abs = 1e-14;
                                                                                             BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                             
                                                                                             // Create test points where current is better than previous
                                                                                             UnivariatePointValuePair previous = new UnivariatePointValuePair(1.0, 2.0); // worse point
                                                                                             UnivariatePointValuePair current = new UnivariatePointValuePair(2.0, 1.0);  // better point
                                                                                             
                                                                                             // Use reflection to access private best() method
                                                                                             java.lang.reflect.Method bestMethod = BrentOptimizer.class.getDeclaredMethod(
                                                                                                 "best", UnivariatePointValuePair.class, UnivariatePointValuePair.class, boolean.class);
                                                                                             bestMethod.setAccessible(true);
                                                                                             
                                                                                             // The original code should select current as better, mutant would select previous
                                                                                             UnivariatePointValuePair result = (UnivariatePointValuePair) 
                                                                                                 bestMethod.invoke(optimizer, current, previous, true);
                                                                                             
                                                                                             // Verify the better point was selected
                                                                                             assertEquals("Should select the point with lower value when minimizing", 
                                                                                                        current.getValue(), result.getValue(), 1e-10);
                                                                                             assertEquals("Should select the current point's position", 
                                                                                                        current.getPoint(), result.getPoint(), 1e-10);
                                                                                             
                                                                                             // Test the opposite case where previous is better
                                                                                             previous = new UnivariatePointValuePair(1.0, 1.0);  // better point
                                                                                             current = new UnivariatePointValuePair(2.0, 2.0);    // worse point
                                                                                             result = (UnivariatePointValuePair) 
                                                                                                 bestMethod.invoke(optimizer, current, previous, true);
                                                                                             
                                                                                             assertEquals("Should select the point with lower value when minimizing", 
                                                                                                        previous.getValue(), result.getValue(), 1e-10);
                                                                                             assertEquals("Should select the previous point's position", 
                                                                                                        previous.getPoint(), result.getPoint(), 1e-10);
                                                                                         }

    @Test
                                                                                    public void testMaximizationDetectsIsMinimMutant() throws Exception {
                                                                                        // Setup - create a simple quadratic function to maximize: f(x) = -(x-2)^2 (max at x=2)
                                                                                        org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                            @Override
                                                                                            public double value(double x) {
                                                                                                return -1 * (x - 2) * (x - 2);
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Create optimizer with reasonable thresholds and bounds
                                                                                        double relTol = 1e-10;
                                                                                        double absTol = 1e-10;
                                                                                        double min = 0;
                                                                                        double max = 4;
                                                                                        double startValue = 1;
                                                                                        org.apache.commons.math3.optimization.GoalType goalType = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
                                                                                        
                                                                                        // Create optimizer instance
                                                                                        org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                            new org.apache.commons.math3.optimization.univariate.BrentOptimizer(relTol, absTol);
                                                                                        
                                                                                        // Use reflection to set required fields since they're not publicly accessible
                                                                                        java.lang.reflect.Field minField = optimizer.getClass().getDeclaredField("min");
                                                                                        minField.setAccessible(true);
                                                                                        minField.set(optimizer, min);
                                                                                        
                                                                                        java.lang.reflect.Field maxField = optimizer.getClass().getDeclaredField("max");
                                                                                        maxField.setAccessible(true);
                                                                                        maxField.set(optimizer, max);
                                                                                        
                                                                                        java.lang.reflect.Field startValueField = optimizer.getClass().getDeclaredField("startValue");
                                                                                        startValueField.setAccessible(true);
                                                                                        startValueField.set(optimizer, startValue);
                                                                                        
                                                                                        java.lang.reflect.Field goalTypeField = optimizer.getClass().getDeclaredField("goalType");
                                                                                        goalTypeField.setAccessible(true);
                                                                                        goalTypeField.set(optimizer, goalType);
                                                                                        
                                                                                        // Use reflection to call protected doOptimize method
                                                                                        java.lang.reflect.Method doOptimize = optimizer.getClass().getDeclaredMethod("doOptimize");
                                                                                        doOptimize.setAccessible(true);
                                                                                        org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                            (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                        
                                                                                        // Verify the result is indeed the maximum
                                                                                        assertEquals(2.0, result.getPoint(), 1e-8); // should find x=2
                                                                                        assertEquals(0.0, result.getValue(), 1e-8); // f(2) = 0
                                                                                        
                                                                                        // The key assertion - verify the value is correct for maximization
                                                                                        // The mutant would return a different value since it would treat as minimization
                                                                                        assertTrue(result.getValue() >= function.value(result.getPoint() - 0.1));
                                                                                        assertTrue(result.getValue() >= function.value(result.getPoint() + 0.1));
                                                                                    }

    @Test
                                                                       public void testIterationCounterIncrements1() throws Exception {
                                                                           // Setup test with mock convergence checker
                                                                           ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                                                           
                                                                           // Create optimizer with mock checker
                                                                           BrentOptimizer optimizer = new BrentOptimizer(1e-8, 1e-14, mockChecker);
                                                                           
                                                                           // Setup mock behavior - return false until iteration 5 to force multiple iterations
                                                                           when(mockChecker.converged(anyInt(), any(), any()))
                                                                               .thenAnswer(invocation -> {
                                                                                   int iter = invocation.getArgument(0);
                                                                                   return iter >= 5;
                                                                               });
                                                                           
                                                                           // Setup test function (simple quadratic) using lambda
                                                                           org.apache.commons.math3.analysis.UnivariateFunction func = x -> (x - 2) * (x - 2);
                                                                           
                                                                           // Set bounds and initial guess using reflection
                                                                           Method setMin = BrentOptimizer.class.getDeclaredMethod("setMin", double.class);
                                                                           setMin.setAccessible(true);
                                                                           setMin.invoke(optimizer, 0.0);
                                                                           
                                                                           Method setMax = BrentOptimizer.class.getDeclaredMethod("setMax", double.class);
                                                                           setMax.setAccessible(true);
                                                                           setMax.invoke(optimizer, 4.0);
                                                                           
                                                                           Method setStartValue = BrentOptimizer.class.getDeclaredMethod("setStartValue", double.class);
                                                                           setStartValue.setAccessible(true);
                                                                           setStartValue.invoke(optimizer, 1.0);
                                                                           
                                                                           Method setGoalType = BrentOptimizer.class.getDeclaredMethod("setGoalType", GoalType.class);
                                                                           setGoalType.setAccessible(true);
                                                                           setGoalType.invoke(optimizer, GoalType.MINIMIZE);
                                                                           
                                                                           Method computeObjectiveValue = BrentOptimizer.class.getDeclaredMethod("computeObjectiveValue", double.class);
                                                                           computeObjectiveValue.setAccessible(true);
                                                                           computeObjectiveValue.invoke(optimizer, 1.0);
                                                                           
                                                                           // Execute optimization using reflection
                                                                           Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                           doOptimize.setAccessible(true);
                                                                           UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                           
                                                                           // Verify iteration count was checked and incremented
                                                                           verify(mockChecker, atLeast(5)).converged(anyInt(), any(), any());
                                                                           
                                                                           // Additional verification that optimization completed successfully
                                                                           assertEquals(2.0, result.getPoint(), 1e-6);
                                                                           assertEquals(0.0, result.getValue(), 1e-6);
                                                                       }

    @Test
                                                                  public void testDoOptimizeDetectsBestCurrentVsPreviousMutant() throws Exception {
                                                                      // Setup test with mock convergence checker
                                                                      ConvergenceChecker<UnivariatePointValuePair> checker = mock(ConvergenceChecker.class);
                                                                      when(checker.converged(anyInt(), any(), any())).thenReturn(false);
                                                                      
                                                                      // Create test optimizer subclass that exposes protected methods
                                                                      class TestBrentOptimizer extends BrentOptimizer {
                                                                          public TestBrentOptimizer(double rel, double abs, ConvergenceChecker<UnivariatePointValuePair> checker) {
                                                                              super(rel, abs, checker);
                                                                          }
                                                                          
                                                                          @Override
                                                                          public double computeObjectiveValue(double x) {
                                                                              // Simple quadratic function with minimum at x=2
                                                                              return (x - 2) * (x - 2);
                                                                          }
                                                                          
                                                                          @Override
                                                                          public UnivariatePointValuePair doOptimize() {
                                                                              return super.doOptimize();
                                                                          }
                                                                      }
                                                                      
                                                                      // Create optimizer with test parameters
                                                                      TestBrentOptimizer optimizer = new TestBrentOptimizer(1e-10, 1e-14, checker);
                                                                      
                                                                      // Set bounds and start value that will create multiple iterations
                                                                      when(optimizer.getMin()).thenReturn(0.0);
                                                                      when(optimizer.getMax()).thenReturn(4.0);
                                                                      when(optimizer.getStartValue()).thenReturn(1.0);
                                                                      when(optimizer.getGoalType()).thenReturn(GoalType.MINIMIZE);
                                                                      
                                                                      // Execute optimization
                                                                      UnivariatePointValuePair result = optimizer.doOptimize();
                                                                      
                                                                      // Verify the result is better than the initial point
                                                                      // If the mutant is present, it would return a worse point (previous)
                                                                      double initialValue = (1.0 - 2) * (1.0 - 2); // 1.0
                                                                      assertTrue("Result should be better than initial point", 
                                                                                 result.getValue() < initialValue);
                                                                      
                                                                      // Verify the result is close to the actual minimum (x=2)
                                                                      assertEquals(2.0, result.getPoint(), 1e-6);
                                                                      assertEquals(0.0, result.getValue(), 1e-6);
                                                                      
                                                                      // Additional verification that best() was called with current point
                                                                      // This would fail if the mutant is present
                                                                      verify(checker, atLeastOnce()).converged(
                                                                          anyInt(), 
                                                                          argThat(arg -> arg.getPoint() != 1.0), // Not the initial point
                                                                          any());
                                                                  }

    @Test
                                                             public void testBestPointSelectionDetectsMutant2() throws Exception {
                                                                 // Setup test function with known minimum
                                                                 org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                     public double value(double x) {
                                                                         // Quadratic function with minimum at x=2
                                                                         return (x - 2) * (x - 2);
                                                                     }
                                                                 };
                                                                 
                                                                 // Create optimizer with reasonable thresholds
                                                                 double relThreshold = 1e-10;
                                                                 double absThreshold = 1e-10;
                                                                 BrentOptimizer optimizer = new BrentOptimizer(relThreshold, absThreshold);
                                                                 
                                                                 // Use reflection to access protected methods
                                                                 java.lang.reflect.Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                 doOptimizeMethod.setAccessible(true);
                                                                 
                                                                 java.lang.reflect.Method computeObjMethod = BrentOptimizer.class.getDeclaredMethod("computeObjectiveValue", double.class);
                                                                 computeObjMethod.setAccessible(true);
                                                                 
                                                                 // Mock the necessary methods to control the optimization process
                                                                 // We'll use reflection to set internal state rather than mocking protected methods
                                                                 java.lang.reflect.Field goalField = BrentOptimizer.class.getSuperclass().getDeclaredField("goal");
                                                                 goalField.setAccessible(true);
                                                                 goalField.set(optimizer, GoalType.MINIMIZE);
                                                                 
                                                                 java.lang.reflect.Field minField = BrentOptimizer.class.getSuperclass().getDeclaredField("min");
                                                                 minField.setAccessible(true);
                                                                 minField.set(optimizer, 1.0);
                                                                 
                                                                 java.lang.reflect.Field maxField = BrentOptimizer.class.getSuperclass().getDeclaredField("max");
                                                                 maxField.setAccessible(true);
                                                                 maxField.set(optimizer, 3.0);
                                                                 
                                                                 java.lang.reflect.Field startValueField = BrentOptimizer.class.getSuperclass().getDeclaredField("startValue");
                                                                 startValueField.setAccessible(true);
                                                                 startValueField.set(optimizer, 1.5);
                                                                 
                                                                 // Override computeObjectiveValue behavior
                                                                 java.lang.reflect.Field funcField = BrentOptimizer.class.getSuperclass().getDeclaredField("function");
                                                                 funcField.setAccessible(true);
                                                                 funcField.set(optimizer, function);
                                                                 
                                                                 // Run optimization using reflection
                                                                 UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                 
                                                                 // Verify that the best point found is indeed the minimum
                                                                 // The mutation would cause the optimizer to potentially keep an older best point
                                                                 // instead of properly tracking the current best
                                                                 assertEquals(2.0, result.getPoint(), 1e-6);
                                                                 assertEquals(0.0, result.getValue(), 1e-6);
                                                                 
                                                                 // Additional verification that the optimization properly tracked progress
                                                                 // This would fail with the mutant since it wouldn't properly track intermediate improvements
                                                                 assertTrue("Optimizer should find value close to 0", result.getValue() < 1e-6);
                                                             }

    @Test
                                    public void testConvergenceCheckerReceivesDifferentPoints() throws Exception {
                                        // Setup test parameters
                                        double rel = 1e-10;
                                        double abs = 1e-14;
                                        
                                        // Create mock convergence checker
                                        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                                            mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                        
                                        // Create optimizer with mock checker
                                        org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                            new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, mockChecker);
                                        
                                        // Setup mock behavior - return false first time to force multiple iterations
                                        when(mockChecker.converged(anyInt(), 
                                            any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                            any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class)))
                                            .thenReturn(false)  // first call
                                            .thenReturn(true);  // second call
                                        
                                        // Create test function (simple quadratic)
                                        org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                            public double value(double x) {
                                                return (x - 2) * (x - 2);
                                            }
                                        };
                                        
                                        // Setup optimization bounds
                                        double min = 1;
                                        double max = 3;
                                        double startValue = 1.5;
                                        
                                        // Create a subclass that exposes the protected method for testing
                                        class TestableBrentOptimizer extends org.apache.commons.math3.optimization.univariate.BrentOptimizer {
                                            public TestableBrentOptimizer(double rel, double abs, 
                                                org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker) {
                                                super(rel, abs, checker);
                                            }
                                            
                                            @Override
                                            public double computeObjectiveValue(double x) {
                                                return function.value(x);
                                            }
                                        }
                                        
                                        TestableBrentOptimizer testableOptimizer = new TestableBrentOptimizer(rel, abs, mockChecker);
                                        org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizerSpy = spy(testableOptimizer);
                                        doReturn(org.apache.commons.math3.optimization.GoalType.MINIMIZE).when(optimizerSpy).getGoalType();
                                        doReturn(min).when(optimizerSpy).getMin();
                                        doReturn(max).when(optimizerSpy).getMax();
                                        doReturn(startValue).when(optimizerSpy).getStartValue();
                                        
                                        // Use reflection to access protected doOptimize
                                        Method doOptimize = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                            .getDeclaredMethod("doOptimize");
                                        doOptimize.setAccessible(true);
                                        org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                            (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(optimizerSpy);
                                        
                                        // Verify checker was called with different points
                                        org.mockito.ArgumentCaptor<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> previousCaptor = 
                                            org.mockito.ArgumentCaptor.forClass(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class);
                                        org.mockito.ArgumentCaptor<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> currentCaptor = 
                                            org.mockito.ArgumentCaptor.forClass(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class);
                                        
                                        verify(mockChecker, atLeastOnce()).converged(anyInt(), previousCaptor.capture(), currentCaptor.capture());
                                        
                                        // Get all captured values
                                        java.util.List<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> previousValues = previousCaptor.getAllValues();
                                        java.util.List<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> currentValues = currentCaptor.getAllValues();
                                        
                                        // Verify that at least one pair of previous and current are different
                                        boolean foundDifferent = false;
                                        for (int i = 0; i < previousValues.size(); i++) {
                                            if (!previousValues.get(i).equals(currentValues.get(i))) {
                                                foundDifferent = true;
                                                break;
                                            }
                                        }
                                        assertTrue("Convergence checker should receive different points", foundDifferent);
                                    }

    @Test
                               public void testDoOptimizeDetectsIsMinimMutation() throws Exception {
                                   // Setup - create a simple quadratic function f(x) = (x-2)^2 + 3
                                   // Minimum is at x=2 (value=3), maximum would be at boundaries
                                   org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                       @Override
                                       public double value(double x) {
                                           return Math.pow(x - 2, 2) + 3;
                                       }
                                   };
                                   
                                   // Create optimizer with minimization goal
                                   BrentOptimizer minimizer = new BrentOptimizer(1e-10, 1e-14);
                                   
                                   // Get protected doOptimize method via reflection
                                   java.lang.reflect.Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                   doOptimize.setAccessible(true);
                                   
                                   // Set fields via reflection
                                   java.lang.reflect.Field goalField = BrentOptimizer.class.getDeclaredField("goal");
                                   goalField.setAccessible(true);
                                   goalField.set(minimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                   
                                   java.lang.reflect.Field minField = BrentOptimizer.class.getDeclaredField("min");
                                   minField.setAccessible(true);
                                   minField.set(minimizer, 1.0);
                                   
                                   java.lang.reflect.Field maxField = BrentOptimizer.class.getDeclaredField("max");
                                   maxField.setAccessible(true);
                                   maxField.set(minimizer, 3.0);
                                   
                                   java.lang.reflect.Field startValueField = BrentOptimizer.class.getDeclaredField("startValue");
                                   startValueField.setAccessible(true);
                                   startValueField.set(minimizer, 1.5);
                                   
                                   // Execute minimization
                                   org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair resultMin = 
                                       (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(minimizer);
                                   
                                   // Verify we found the minimum
                                   assertEquals(2.0, resultMin.getPoint(), 1e-8);
                                   assertEquals(3.0, resultMin.getValue(), 1e-8);
                                   
                                   // Now test maximization case
                                   BrentOptimizer maximizer = new BrentOptimizer(1e-10, 1e-14);
                                   
                                   // Set fields via reflection
                                   goalField.set(maximizer, org.apache.commons.math3.optimization.GoalType.MAXIMIZE);
                                   minField.set(maximizer, 1.0);
                                   maxField.set(maximizer, 3.0);
                                   startValueField.set(maximizer, 1.5);
                                   
                                   // Execute maximization
                                   org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair resultMax = 
                                       (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimize.invoke(maximizer);
                                   
                                   // Verify we get the maximum (which is at x=1 or x=3 in this case)
                                   // The exact point depends on the optimization process, but value should be 4
                                   assertEquals(4.0, resultMax.getValue(), 1e-8);
                                   
                                   // The mutation would cause the minimizer to return a maximum point and vice versa
                                   // So this test would fail if the mutation is present
                               }

    @Test
                  public void testDoOptimizeDetectsIsMinimMutant3() throws Exception {
                      // Setup for maximization test
                      double rel = 1e-10;
                      double abs = 1e-14;
                      BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                      
                      // Create a simple unimodal function where max and min are clearly different
                      // f(x) = -(x-2)^2 + 4 (max at x=2, value=4)
                      org.apache.commons.math3.analysis.UnivariateFunction function = 
                          new org.apache.commons.math3.analysis.UnivariateFunction() {
                              @Override
                              public double value(double x) {
                                  return -((x - 2) * (x - 2)) + 4;
                              }
                          };
                      
                      // Set optimization bounds and start value
                      double min = 0;
                      double max = 4;
                      double startValue = 1;
                      
                      // Create mock optimizer
                      BrentOptimizer mockOptimizer = spy(optimizer);
                      
                      // Mock the necessary methods
                      when(mockOptimizer.getGoalType()).thenReturn(GoalType.MAXIMIZE);
                      when(mockOptimizer.getMin()).thenReturn(min);
                      when(mockOptimizer.getMax()).thenReturn(max);
                      when(mockOptimizer.getStartValue()).thenReturn(startValue);
                      
                      // Use reflection to access protected doOptimize method
                      Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                      doOptimizeMethod.setAccessible(true);
                      
                      // Create a subclass that exposes computeObjectiveValue for testing
                      class TestableBrentOptimizer extends BrentOptimizer {
                          private org.apache.commons.math3.analysis.UnivariateFunction func;
                          
                          public TestableBrentOptimizer(double rel, double abs, org.apache.commons.math3.analysis.UnivariateFunction func) {
                              super(rel, abs);
                              this.func = func;
                          }
                          
                          @Override
                          protected double computeObjectiveValue(double point) {
                              return func.value(point);
                          }
                      }
                      
                      // Create testable optimizer with our function
                      TestableBrentOptimizer testableOptimizer = new TestableBrentOptimizer(rel, abs, function);
                      BrentOptimizer spyOptimizer = spy(testableOptimizer);
                      
                      // Mock the remaining methods
                      when(spyOptimizer.getGoalType()).thenReturn(GoalType.MAXIMIZE);
                      when(spyOptimizer.getMin()).thenReturn(min);
                      when(spyOptimizer.getMax()).thenReturn(max);
                      when(spyOptimizer.getStartValue()).thenReturn(startValue);
                      
                      // Execute optimization
                      UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(spyOptimizer);
                      
                      // Verify the result is indeed the maximum
                      assertEquals(2.0, result.getPoint(), 1e-8);  // Should find maximum at x=2
                      assertEquals(4.0, result.getValue(), 1e-8);  // Maximum value should be 4
                      
                      // Additional verification that we're testing maximization case
                      verify(spyOptimizer).getGoalType();
                  }

    @Test
         public void testIterationCountMutation() {
             // Setup test with known function to optimize
             org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                 @Override
                 public double value(double x) {
                     return (x - 5) * (x - 5); // parabola with minimum at x=5
                 }
             };
             org.apache.commons.math3.optimization.GoalType goalType = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
             
             // Create convergence checker that will verify iteration count
             org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                 new org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair>() {
                     @Override
                     public boolean converged(int iteration, org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair previous, 
                                             org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair current) {
                         // Should converge in reasonable iterations (original would be ~10-20)
                         // If mutant is present (--iter), iteration would go negative quickly
                         assertTrue("Iteration count should be positive and reasonable", iteration >= 0 && iteration < 100);
                         return org.apache.commons.math3.util.FastMath.abs(previous.getValue() - current.getValue()) < 1e-6;
                     }
                 };
             
             // Create optimizer with tight tolerances to ensure multiple iterations
             org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                 new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14, checker);
             
             // Test with bounds that will require several iterations
             org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = optimizer.optimize(
                 100, // maxEval
                 function, // function to optimize
                 goalType, // goal type
                 0, 10); // min and max bounds
             
             // Verify correct optimization result
             assertEquals(5.0, result.getPoint(), 1e-6);
             assertEquals(0.0, result.getValue(), 1e-6);
         }

    @Test
    public void testDoOptimizeTerminationCondition() {
        // Setup test function: f(x) = (x-2)^2, minimum at x=2
        org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
            @Override
            public double value(double x) {
                return (x - 2) * (x - 2);
            }
        };
        
        // Mock the necessary parts of BrentOptimizer
        BrentOptimizer optimizer = new BrentOptimizer(1e-10, 1e-14);
        
        // Use reflection to set up the test since doOptimize is protected
        try {
            // Set up the optimizer's state
            Method getGoalType = BrentOptimizer.class.getDeclaredMethod("getGoalType");
            getGoalType.setAccessible(true);
            when(getGoalType.invoke(optimizer)).thenReturn(GoalType.MINIMIZE);
            
            Method getMin = BrentOptimizer.class.getDeclaredMethod("getMin");
            getMin.setAccessible(true);
            when(getMin.invoke(optimizer)).thenReturn(1.0);
            
            Method getMax = BrentOptimizer.class.getDeclaredMethod("getMax");
            getMax.setAccessible(true);
            when(getMax.invoke(optimizer)).thenReturn(3.0);
            
            Method getStartValue = BrentOptimizer.class.getDeclaredMethod("getStartValue");
            getStartValue.setAccessible(true);
            when(getStartValue.invoke(optimizer)).thenReturn(1.5);
            
            Method computeObjectiveValue = BrentOptimizer.class.getDeclaredMethod("computeObjectiveValue", double.class);
            computeObjectiveValue.setAccessible(true);
            when(computeObjectiveValue.invoke(optimizer, anyDouble())).thenAnswer(invocation -> {
                double x = (double) invocation.getArguments()[0];
                return function.value(x);
            });
            
            // Call the method
            Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
            doOptimize.setAccessible(true);
            UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimize.invoke(optimizer);
            
            // Verify termination via Brent's criterion
            assertEquals(2.0, result.getPoint(), 1e-8);  // Should find the minimum at x=2
            assertEquals(0.0, result.getValue(), 1e-8);  // Minimum value should be 0
            
        } catch (Exception e) {
            fail("Test failed due to reflection exception: " + e.getMessage());
        }
    }


}
