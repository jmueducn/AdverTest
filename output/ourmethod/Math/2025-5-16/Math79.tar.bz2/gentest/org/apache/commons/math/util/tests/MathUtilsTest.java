package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                              public void testDistance_Typical2DPoints() {
                                                                                                                                                  double[] p1 = {1.0, 2.0};
                                                                                                                                                  double[] p2 = {4.0, 6.0};
                                                                                                                                                  double expected = 5.0; // sqrt((4-1)^2 + (6-2)^2) = sqrt(9+16) = 5
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_3DPoints() {
                                                                                                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                                                  double[] p2 = {4.0, 6.0, 9.0};
                                                                                                                                                  double expected = 7.0; // sqrt(3^2 + 4^2 + 6^2) = sqrt(9+16+36) = sqrt(61) ≈ 7.8102
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), 0.0001);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_ZeroDistance() {
                                                                                                                                                  double[] p1 = {5.0, 3.0, 2.0};
                                                                                                                                                  double[] p2 = {5.0, 3.0, 2.0};
                                                                                                                                                  assertEquals(0.0, MathUtils.distance(p1, p2), 0.0);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_NegativeCoordinates() {
                                                                                                                                                  double[] p1 = {-1.0, -2.0};
                                                                                                                                                  double[] p2 = {-4.0, -6.0};
                                                                                                                                                  double expected = 5.0; // Same as positive case since squares eliminate negatives
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_MixedSignCoordinates() {
                                                                                                                                                  double[] p1 = {-1.0, 2.0};
                                                                                                                                                  double[] p2 = {4.0, -6.0};
                                                                                                                                                  double expected = Math.sqrt(25 + 64); // sqrt(5^2 + 8^2) = sqrt(89)
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_SingleDimension() {
                                                                                                                                                  double[] p1 = {5.0};
                                                                                                                                                  double[] p2 = {9.0};
                                                                                                                                                  assertEquals(4.0, MathUtils.distance(p1, p2), 0.0);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_EmptyArrays() {
                                                                                                                                                  double[] p1 = {};
                                                                                                                                                  double[] p2 = {};
                                                                                                                                                  assertEquals(0.0, MathUtils.distance(p1, p2), 0.0);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_ArraysDifferentLength() {
                                                                                                                                                  double[] p1 = {1.0, 2.0};
                                                                                                                                                  double[] p2 = {1.0};
                                                                                                                                                  
                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                  thrown.expectMessage("Arrays must have the same length");
                                                                                                                                                  MathUtils.distance(p1, p2);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_NullFirstArray() {
                                                                                                                                                  double[] p1 = null;
                                                                                                                                                  double[] p2 = {1.0, 2.0};
                                                                                                                                                  
                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                  thrown.expectMessage("Points arrays cannot be null");
                                                                                                                                                  MathUtils.distance(p1, p2);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_NullSecondArray() {
                                                                                                                                                  double[] p1 = {1.0, 2.0};
                                                                                                                                                  double[] p2 = null;
                                                                                                                                                  
                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                  thrown.expectMessage("Points arrays cannot be null");
                                                                                                                                                  MathUtils.distance(p1, p2);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_WithNaNValues() {
                                                                                                                                                  double[] p1 = {1.0, Double.NaN};
                                                                                                                                                  double[] p2 = {4.0, 6.0};
                                                                                                                                                  
                                                                                                                                                  assertTrue(Double.isNaN(MathUtils.distance(p1, p2)));
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_WithInfiniteValues() {
                                                                                                                                                  double[] p1 = {1.0, Double.POSITIVE_INFINITY};
                                                                                                                                                  double[] p2 = {4.0, 6.0};
                                                                                                                                                  
                                                                                                                                                  assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(p1, p2), 0.0);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_VerySmallValues() {
                                                                                                                                                  double[] p1 = {MathUtils.SAFE_MIN, MathUtils.SAFE_MIN};
                                                                                                                                                  double[] p2 = {2 * MathUtils.SAFE_MIN, 2 * MathUtils.SAFE_MIN};
                                                                                                                                                  double expected = Math.sqrt(2 * MathUtils.SAFE_MIN * MathUtils.SAFE_MIN);
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_VeryLargeValues() {
                                                                                                                                                  double[] p1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                                                                  double[] p2 = {Double.MAX_VALUE / 2, Double.MAX_VALUE / 2};
                                                                                                                                                  
                                                                                                                                                  // Should be sqrt(2*(MAX_VALUE/2)^2) = (MAX_VALUE/2)*sqrt(2)
                                                                                                                                                  double expected = (Double.MAX_VALUE / 2) * Math.sqrt(2);
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), 1e292); // Using large delta due to floating point precision
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_Typical2DPoints1() {
                                                                                                                                                  double[] p1 = {1.0, 2.0};
                                                                                                                                                  double[] p2 = {4.0, 6.0};
                                                                                                                                                  double expected = 5.0; // sqrt((4-1)^2 + (6-2)^2) = sqrt(9 + 16) = 5
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_Typical3DPoints() {
                                                                                                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                                                  double[] p2 = {4.0, 6.0, 9.0};
                                                                                                                                                  double expected = 7.0; // sqrt((4-1)^2 + (6-2)^2 + (9-3)^2) = sqrt(9 + 16 + 36) = sqrt(61) ≈ 7.0
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_IdenticalPoints() {
                                                                                                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                                                  double[] p2 = {1.0, 2.0, 3.0};
                                                                                                                                                  assertEquals(0.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_ZeroDistance1() {
                                                                                                                                                  double[] p1 = {0.0, 0.0, 0.0};
                                                                                                                                                  double[] p2 = {0.0, 0.0, 0.0};
                                                                                                                                                  assertEquals(0.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_NegativeCoordinates1() {
                                                                                                                                                  double[] p1 = {-1.0, -2.0};
                                                                                                                                                  double[] p2 = {-4.0, -6.0};
                                                                                                                                                  double expected = 5.0; // Distance should be same as positive coordinates
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_MixedSignCoordinates1() {
                                                                                                                                                  double[] p1 = {-1.0, 2.0};
                                                                                                                                                  double[] p2 = {4.0, -6.0};
                                                                                                                                                  double expected = Math.sqrt(25 + 64); // sqrt((4 - -1)^2 + (-6 - 2)^2) = sqrt(25 + 64)
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_SingleDimension1() {
                                                                                                                                                  double[] p1 = {5.0};
                                                                                                                                                  double[] p2 = {2.0};
                                                                                                                                                  assertEquals(3.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_HighDimensionalSpace() {
                                                                                                                                                  double[] p1 = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                                                                                  double[] p2 = {6.0, 7.0, 8.0, 9.0, 10.0};
                                                                                                                                                  double expected = Math.sqrt(25 + 25 + 25 + 25 + 25); // sqrt(5 * 25)
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_VerySmallValues1() {
                                                                                                                                                  double[] p1 = {MathUtils.SAFE_MIN, MathUtils.SAFE_MIN};
                                                                                                                                                  double[] p2 = {2 * MathUtils.SAFE_MIN, 2 * MathUtils.SAFE_MIN};
                                                                                                                                                  double expected = Math.sqrt(2 * MathUtils.SAFE_MIN * MathUtils.SAFE_MIN);
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testDistance_VeryLargeValues1() {
                                                                                                                                                  double[] p1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                                                                  double[] p2 = {Double.MAX_VALUE - 1, Double.MAX_VALUE - 1};
                                                                                                                                                  double expected = Math.sqrt(2); // sqrt(1^2 + 1^2)
                                                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                                                              }

 @Test
                                                                                              public void testDistance_NullFirstArray1() {
                                                                                                  double[] p2 = {4.0, 6.0};
                                                                                                  try {
                                                                                                      MathUtils.distance(null, p2);
                                                                                                      fail("Expected IllegalArgumentException");
                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                      assertEquals("Points arrays cannot be null", e.getMessage());
                                                                                                  }
                                                                                              }

 @Test
                                                          public void testDistanceWithZeroLengthVectors() {
                                                              // Create two identical points (zero distance)
                                                              double[] p1 = {0.0, 0.0, 0.0};
                                                              double[] p2 = {0.0, 0.0, 0.0};
                                                              
                                                              // Expected distance should be exactly 0
                                                              double expected = 0.0;
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              // This will fail for the mutant (returns 1.0 instead of 0.0)
                                                              assertEquals("Distance between identical points should be 0", 
                                                                          expected, actual, 0.000001);
                                                          }

 @Test
                                                          public void testDistanceWithSmallVectors() {
                                                              // Create two very close points
                                                              double[] p1 = {0.0, 0.0};
                                                              double[] p2 = {0.0001, 0.0001};
                                                              
                                                              // Calculate expected distance manually
                                                              double expected = Math.sqrt(0.0001*0.0001 + 0.0001*0.0001);
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              // Mutant would return at least 1.0, which is much larger
                                                              assertEquals("Distance between close points should be small",
                                                                          expected, actual, 0.000001);
                                                          }

 @Test
                                                          public void testDistanceWithZeroVectors() {
                                                              double[] p1 = {0.0, 0.0};
                                                              double[] p2 = {0.0, 0.0};
                                                              
                                                              // Distance between identical points should be exactly 0
                                                              // This will fail with mutant (returns 1.0 instead of 0.0)
                                                              assertEquals(0.0, MathUtils.distance(p1, p2), 0.0);
                                                          }

 @Test
                                                          public void testDistanceWithSimpleVectors() {
                                                              double[] p1 = {0.0, 0.0};
                                                              double[] p2 = {0.0, 1.0};
                                                              
                                                              // Simple distance calculation that should be exactly 1.0
                                                              // This will fail with mutant (returns √2 ≈ 1.414 instead of 1.0)
                                                              assertEquals(1.0, MathUtils.distance(p1, p2), 0.0);
                                                          }

 @Test
                                                          public void testDistanceWithNonZeroVectors() {
                                                              double[] p1 = {1.0, 2.0, 3.0};
                                                              double[] p2 = {4.0, 5.0, 6.0};
                                                              
                                                              // Expected distance: √((4-1)² + (5-2)² + (6-3)²) = √27 ≈ 5.196
                                                              // With mutant: √(1 + 27) ≈ 5.291
                                                              double expected = Math.sqrt(27);
                                                              assertEquals(expected, MathUtils.distance(p1, p2), 0.0001);
                                                          }

 @Test
                                                         public void testDistanceWithSmallDifferences() {
                                                             // Points that are very close but not identical
                                                             double[] p1 = {0.1, 0.1, 0.1};
                                                             double[] p2 = {0.1001, 0.1001, 0.1001};
                                                             
                                                             // With double sum, this should calculate a small but non-zero distance
                                                             // With int sum, each (0.0001)^2 = 0.00000001 would be truncated to 0
                                                             double expectedDistance = Math.sqrt(3 * Math.pow(0.0001, 2));
                                                             double actualDistance = MathUtils.distance(p1, p2);
                                                             
                                                             // Verify the distance is calculated with proper precision
                                                             assertEquals("Distance calculation should maintain double precision", 
                                                                         expectedDistance, actualDistance, 1e-10);
                                                             
                                                             // Also verify it's not zero
                                                             assertTrue("Distance between different points should not be zero", 
                                                                       actualDistance > 0);
                                                         }

 @Test
                                                         public void testDistanceWithLargerDifferences() {
                                                             // Points with larger differences to verify general functionality
                                                             double[] p1 = {1.5, 2.5, 3.5};
                                                             double[] p2 = {4.5, 5.5, 6.5};
                                                             
                                                             double expectedDistance = Math.sqrt(3 * Math.pow(3.0, 2)); // 3 * 9 = 27, sqrt(27)
                                                             double actualDistance = MathUtils.distance(p1, p2);
                                                             
                                                             assertEquals(expectedDistance, actualDistance, 1e-10);
                                                         }

 @Test
                                                         public void testDistanceWithSmallDifferences1() {
                                                             // Test with small differences that would be rounded to 0 with integer sum
                                                             double[] p1 = {0.1, 0.2, 0.3};
                                                             double[] p2 = {0.4, 0.5, 0.6};
                                                             
                                                             // Expected calculation with double precision:
                                                             // sqrt((0.3^2 + 0.3^2 + 0.3^2)) = sqrt(0.09 + 0.09 + 0.09) = sqrt(0.27) ≈ 0.51961524227
                                                             double expected = Math.sqrt(0.27);
                                                             double actual = MathUtils.distance(p1, p2);
                                                             
                                                             // With integer sum, this would calculate sqrt(0 + 0 + 0) = 0
                                                             assertEquals("Distance calculation should maintain double precision", 
                                                                         expected, actual, 1e-10);
                                                         }

 @Test
                                                         public void testDistanceWithFractionalDifferences() {
                                                             // Test with fractional differences that would be truncated with integer sum
                                                             double[] p1 = {1.1, 2.2, 3.3};
                                                             double[] p2 = {1.4, 2.5, 3.6};
                                                             
                                                             // Expected calculation:
                                                             // sqrt((0.3^2 + 0.3^2 + 0.3^2)) = sqrt(0.09 + 0.09 + 0.09) = sqrt(0.27) ≈ 0.51961524227
                                                             double expected = Math.sqrt(0.27);
                                                             double actual = MathUtils.distance(p1, p2);
                                                             
                                                             // With integer sum, this would calculate sqrt(0 + 0 + 0) = 0
                                                             assertEquals("Distance calculation should maintain fractional precision", 
                                                                         expected, actual, 1e-10);
                                                         }

 @Test
                                                         public void testDistanceWithLargeArrays() {
                                                             // Test with larger arrays to accumulate more rounding errors
                                                             double[] p1 = new double[100];
                                                             double[] p2 = new double[100];
                                                             for (int i = 0; i < 100; i++) {
                                                                 p1[i] = 0.1 * i;
                                                                 p2[i] = 0.1 * i + 0.01; // Small difference
                                                             }
                                                             
                                                             // Expected calculation would maintain all small differences
                                                             double expectedSum = 0;
                                                             for (int i = 0; i < 100; i++) {
                                                                 double diff = 0.01;
                                                                 expectedSum += diff * diff;
                                                             }
                                                             double expected = Math.sqrt(expectedSum);
                                                             double actual = MathUtils.distance(p1, p2);
                                                             
                                                             // With integer sum, this would calculate sqrt(0) = 0
                                                             assertEquals("Distance should accumulate many small differences correctly", 
                                                                         expected, actual, 1e-10);
                                                         }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                    public void testDistanceWithArrayIndexOutOfBounds() {
                                                        // Arrange
                                                        double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                                        double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                                        
                                                        // Act
                                                        double result = MathUtils.distance(p1, p2);
                                                        
                                                        // Assert
                                                        // If we reach here, the test fails (original behavior passed)
                                                        // The expected exception will catch the mutated version
                                                    }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                        public void testDistanceWithMutatedLoopCondition() {
                                                            // Arrange
                                                            double[] p1 = {1.0, 2.0, 3.0}; // Any non-empty array will work
                                                            double[] p2 = {4.0, 5.0, 6.0}; // Same length as p1
                                                            
                                                            // Act
                                                            double result = MathUtils.distance(p1, p2);
                                                            
                                                            // Assert - The test will pass if ArrayIndexOutOfBoundsException is thrown
                                                            // which would happen with the mutated version (i <= p1.length)
                                                            // The original version would complete successfully and reach this line
                                                            fail("Expected ArrayIndexOutOfBoundsException but method completed successfully with result: " + result);
                                                        }

 @Test
                                                        public void testDistanceOriginalBehavior() {
                                                            // Additional test to verify original behavior works correctly
                                                            double[] p1 = {1.0, 2.0};
                                                            double[] p2 = {4.0, 6.0};
                                                            
                                                            double expected = 5.0; // sqrt((4-1)^2 + (6-2)^2) = sqrt(9+16) = 5
                                                            double actual = MathUtils.distance(p1, p2);
                                                            
                                                            assertEquals(expected, actual, 0.0001);
                                                        }

 @Test
                                                       public void testDistanceShouldIncludeFirstElement() {
                                                           // Arrange
                                                           double[] p1 = {1.0, 0.0, 0.0}; // First element is non-zero
                                                           double[] p2 = {0.0, 0.0, 0.0};  // All zeros
                                                           
                                                           // Act - calculate distance
                                                           double result = MathUtils.distance(p1, p2);
                                                           
                                                           // Assert - verify first element was included
                                                           // Expected distance is sqrt(1^2 + 0^2 + 0^2) = 1.0
                                                           assertEquals(1.0, result, 0.0001);
                                                           
                                                           // Additional verification with different first elements
                                                           p1[0] = 3.0;
                                                           p2[0] = 1.0;
                                                           result = MathUtils.distance(p1, p2);
                                                           // Expected distance is sqrt(2^2 + 0^2 + 0^2) = 2.0
                                                           assertEquals(2.0, result, 0.0001);
                                                       }

 @Test
                                                       public void testDistanceShouldIncludeFirstElement1() {
                                                           // Test case with single element arrays
                                                           double[] p1 = {5.0};
                                                           double[] p2 = {2.0};
                                                           double expected = Math.sqrt(9.0); // sqrt((5-2)^2) = 3.0
                                                           double actual = MathUtils.distance(p1, p2);
                                                           assertEquals("Distance calculation should include first element", expected, actual, 0.0001);
                                                           
                                                           // Test case where first element is different but others are same
                                                           double[] p3 = {3.0, 0.0, 0.0};
                                                           double[] p4 = {1.0, 0.0, 0.0};
                                                           expected = Math.sqrt(4.0); // sqrt((3-1)^2 + 0 + 0) = 2.0
                                                           actual = MathUtils.distance(p3, p4);
                                                           assertEquals("Distance calculation should include first element", expected, actual, 0.0001);
                                                           
                                                           // Test case where first element is only different
                                                           double[] p5 = {10.0, 5.0, 5.0};
                                                           double[] p6 = {10.0, 5.0, 5.0};
                                                           expected = 0.0; // All elements same
                                                           actual = MathUtils.distance(p5, p6);
                                                           assertEquals("Distance should be 0 when all elements same", expected, actual, 0.0001);
                                                       }

 @Test
                                                      public void testDistanceShouldProcessAllDimensions() {
                                                          // Create test points with 2 dimensions where the major difference is in the last dimension
                                                          double[] p1 = {0.0, 0.0};
                                                          double[] p2 = {0.0, 3.0};  // Only last dimension differs
                                                          
                                                          // Expected distance is sqrt(0² + 3²) = 3.0
                                                          double expected = 3.0;
                                                          double actual = MathUtils.distance(p1, p2);
                                                          
                                                          // This will fail with the mutant since it will skip the last dimension
                                                          // Mutant would calculate sqrt(0²) = 0.0
                                                          assertEquals("Distance calculation should include all dimensions", 
                                                                      expected, actual, 0.0001);
                                                          
                                                          // Additional test with more dimensions
                                                          double[] p3 = {1.0, 2.0, 3.0, 4.0};
                                                          double[] p4 = {1.0, 2.0, 3.0, 5.0};  // Only last dimension differs
                                                          expected = 1.0;  // sqrt(0+0+0+1²) = 1.0
                                                          actual = MathUtils.distance(p3, p4);
                                                          assertEquals("Distance calculation should include all dimensions in multi-dimensional case",
                                                                      expected, actual, 0.0001);
                                                      }

 @Test
                                                      public void testDistanceWithSingleElementArrays() {
                                                          // This test will catch the mutant as it skips the only element
                                                          double[] p1 = {3.0};
                                                          double[] p2 = {7.0};
                                                          double expected = 4.0; // sqrt((3-7)^2) = 4
                                                          double actual = MathUtils.distance(p1, p2);
                                                          assertEquals("Distance calculation for single element arrays failed", 
                                                                      expected, actual, 0.0001);
                                                      }

 @Test
                                                      public void testDistanceWhereLastElementDiffers() {
                                                          // This test ensures last element is processed
                                                          double[] p1 = {1.0, 2.0, 3.0, 100.0}; // Last element differs significantly
                                                          double[] p2 = {1.0, 2.0, 3.0, 0.0};
                                                          double expected = 100.0; // sqrt(0+0+0+10000) = 100
                                                          double actual = MathUtils.distance(p1, p2);
                                                          assertEquals("Distance calculation should include last element", 
                                                                      expected, actual, 0.0001);
                                                      }

 @Test
                                                      public void testDistanceWithMultipleElements() {
                                                          // General case test
                                                          double[] p1 = {1.0, 2.0, 3.0};
                                                          double[] p2 = {4.0, 5.0, 6.0};
                                                          double expected = Math.sqrt(9 + 9 + 9); // sqrt(27) ≈ 5.196152
                                                          double actual = MathUtils.distance(p1, p2);
                                                          assertEquals("Distance calculation for multiple elements failed", 
                                                                      expected, actual, 0.0001);
                                                      }

 @Test
                                                     public void testDistanceDetectsSubtractionMutant() {
                                                         // Test case that will catch the p1[i] + p2[i] mutant
                                                         double[] p1 = {1.0, -1.0};  // Point with mixed signs
                                                         double[] p2 = {-1.0, 1.0};  // Opposite signs to p1
                                                         
                                                         // Original should calculate sqrt((1 - -1)^2 + (-1 - 1)^2) = sqrt(4 + 4) = sqrt(8)
                                                         // Mutated would calculate sqrt((1 + -1)^2 + (-1 + 1)^2) = sqrt(0 + 0) = 0
                                                         double expected = Math.sqrt(8.0); // Expected Euclidean distance
                                                         double actual = MathUtils.distance(p1, p2);
                                                         
                                                         assertEquals("Distance calculation should use subtraction, not addition", 
                                                                     expected, actual, 0.0001);
                                                         
                                                         // Additional test case with one zero coordinate
                                                         double[] p3 = {0.0, 2.0};
                                                         double[] p4 = {0.0, 3.0};
                                                         assertEquals("Distance with zero coordinates", 
                                                                     1.0, MathUtils.distance(p3, p4), 0.0001);
                                                         
                                                         // Test with equal points (should be zero in both original and mutant)
                                                         double[] p5 = {5.0, 5.0};
                                                         assertEquals("Distance between equal points should be zero",
                                                                     0.0, MathUtils.distance(p5, p5), 0.0001);
                                                     }

 @Test
                                                     public void testDistanceDetectsSubtractionMutation() {
                                                         // Test case that will fail if subtraction is replaced with addition
                                                         double[] p1 = {1.0, 2.0, 3.0};
                                                         double[] p2 = {4.0, 5.0, 6.0};
                                                         
                                                         // Calculate expected value manually
                                                         double expected = Math.sqrt(
                                                             Math.pow(1.0 - 4.0, 2) + 
                                                             Math.pow(2.0 - 5.0, 2) + 
                                                             Math.pow(3.0 - 6.0, 2)
                                                         );
                                                         
                                                         // Calculate what the mutated version would return
                                                         double mutated = Math.sqrt(
                                                             Math.pow(1.0 + 4.0, 2) + 
                                                             Math.pow(2.0 + 5.0, 2) + 
                                                             Math.pow(3.0 + 6.0, 2)
                                                         );
                                                         
                                                         // Actual result from the method
                                                         double actual = MathUtils.distance(p1, p2);
                                                         
                                                         // Verify the result matches expected distance
                                                         assertEquals(expected, actual, 0.0001);
                                                         
                                                         // Additional assertion to ensure we're not getting the mutated result
                                                         assertNotEquals(mutated, actual, 0.0001);
                                                         
                                                         // Test with negative numbers to ensure proper difference calculation
                                                         double[] p3 = {-1.0, -2.0};
                                                         double[] p4 = {1.0, 2.0};
                                                         expected = Math.sqrt(Math.pow(-1.0 - 1.0, 2) + Math.pow(-2.0 - 2.0, 2));
                                                         actual = MathUtils.distance(p3, p4);
                                                         assertEquals(expected, actual, 0.0001);
                                                     }

 @Test
                                                public void testDistanceDetectsSubtractionOrderMutant() {
                                                    // Create asymmetric test data where p1[i] != p2[i]
                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                    double[] p2 = {4.0, 5.0, 6.0};
                                                    
                                                    // Calculate expected squared differences manually
                                                    double[] expectedSquaredDiffs = new double[p1.length];
                                                    for (int i = 0; i < p1.length; i++) {
                                                        expectedSquaredDiffs[i] = (p1[i] - p2[i]) * (p1[i] - p2[i]);
                                                    }
                                                    
                                                    // Call the method and verify intermediate calculations
                                                    double sum = 0;
                                                    for (int i = 0; i < p1.length; i++) {
                                                        double dp = p1[i] - p2[i];
                                                        sum += dp * dp;
                                                        // Verify each squared difference matches expected
                                                        assertEquals(expectedSquaredDiffs[i], dp * dp, 0.0001);
                                                    }
                                                    
                                                    // Final verification of distance
                                                    double expectedDistance = Math.sqrt(sum);
                                                    double actualDistance = MathUtils.distance(p1, p2);
                                                    assertEquals(expectedDistance, actualDistance, 0.0001);
                                                    
                                                    // Additional verification with different test data
                                                    double[] p3 = {1.5, -2.5};
                                                    double[] p4 = {-1.5, 2.5};
                                                    double expectedDist2 = Math.sqrt(Math.pow(1.5 - (-1.5), 2) + Math.pow(-2.5 - 2.5, 2));
                                                    assertEquals(expectedDist2, MathUtils.distance(p3, p4), 0.0001);
                                                }

 @Test
                                                public void testDistanceShouldDetectMutant() {
                                                    // Test with asymmetric values to detect the subtraction order mutation
                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                    double[] p2 = {4.0, 5.0, 6.0};
                                                    
                                                    // Calculate expected value manually
                                                    double expected = 0.0;
                                                    for (int i = 0; i < p1.length; i++) {
                                                        double dp = p1[i] - p2[i];
                                                        expected += dp * dp;
                                                    }
                                                    expected = Math.sqrt(expected);
                                                    
                                                    // Test the actual method
                                                    double actual = MathUtils.distance(p1, p2);
                                                    
                                                    // Verify the result matches expected calculation
                                                    assertEquals("Distance calculation should be correct", expected, actual, 1e-10);
                                                    
                                                    // Additional test with different values to ensure robustness
                                                    double[] p3 = {1.5, -2.5, 0.0};
                                                    double[] p4 = {-1.5, 2.5, 1.0};
                                                    
                                                    expected = 0.0;
                                                    for (int i = 0; i < p3.length; i++) {
                                                        double dp = p3[i] - p4[i];
                                                        expected += dp * dp;
                                                    }
                                                    expected = Math.sqrt(expected);
                                                    
                                                    actual = MathUtils.distance(p3, p4);
                                                    assertEquals("Distance calculation should be correct for negative values", 
                                                                expected, actual, 1e-10);
                                                    
                                                    // Test with very small numbers
                                                    double[] p5 = {1e-300, 2e-300};
                                                    double[] p6 = {3e-300, 4e-300};
                                                    
                                                    expected = 0.0;
                                                    for (int i = 0; i < p5.length; i++) {
                                                        double dp = p5[i] - p6[i];
                                                        expected += dp * dp;
                                                    }
                                                    expected = Math.sqrt(expected);
                                                    
                                                    actual = MathUtils.distance(p5, p6);
                                                    assertEquals("Distance calculation should work with very small numbers", 
                                                                expected, actual, 1e-310);
                                                }

 @Test
                                                   public void testDistanceShouldCalculateEuclideanDistance() {
                                                       // Test case that will catch the multiplication mutant
                                                       double[] p1 = {3.0, 4.0};  // Point (3,4)
                                                       double[] p2 = {1.0, 2.0};  // Point (1,2)
                                                       
                                                       // Original calculation: sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                                                       // Mutated calculation: sqrt((3*1)² + (4*2)²) = sqrt(9 + 64) = sqrt(73) ≈ 8.544
                                                       double expected = Math.sqrt(8.0); // Expected Euclidean distance
                                                       double actual = MathUtils.distance(p1, p2);
                                                       
                                                       assertEquals("Distance calculation should use subtraction, not multiplication", 
                                                                   expected, actual, 0.0001);
                                                       
                                                       // Additional test case with negative numbers
                                                       double[] p3 = {-1.0, -2.0};
                                                       double[] p4 = {-3.0, -4.0};
                                                       
                                                       // Original: sqrt((-1 - -3)² + (-2 - -4)²) = sqrt(4 + 4) = sqrt(8)
                                                       // Mutated: sqrt((-1 * -3)² + (-2 * -4)²) = sqrt(9 + 64) = sqrt(73)
                                                       expected = Math.sqrt(8.0);
                                                       actual = MathUtils.distance(p3, p4);
                                                       
                                                       assertEquals("Distance calculation with negative numbers should use subtraction", 
                                                                   expected, actual, 0.0001);
                                                   }

 @Test
                                                   public void testDistanceWithZeroValues() {
                                                       // Test case where one array contains zeros
                                                       double[] p1 = {0.0, 0.0};
                                                       double[] p2 = {1.0, 1.0};
                                                       
                                                       // Original: sqrt((0-1)² + (0-1)²) = sqrt(1 + 1) = sqrt(2)
                                                       // Mutated: sqrt((0*1)² + (0*1)²) = sqrt(0 + 0) = 0
                                                       double expected = Math.sqrt(2.0);
                                                       double actual = MathUtils.distance(p1, p2);
                                                       
                                                       assertEquals("Distance with zero values should not return zero", 
                                                                   expected, actual, 0.0001);
                                                   }

 @Test
                                               public void testDistanceDetectsSubtractionToMultiplicationMutant() {
                                                   // Test case that will fail with the mutant but pass with original
                                                   double[] p1 = {2.0};  // Simple 1-dimensional case
                                                   double[] p2 = {3.0};
                                                   
                                                   // Original should calculate: sqrt((2-3)²) = 1.0
                                                   // Mutant would calculate: sqrt((2*3)²) = 6.0
                                                   double expected = 1.0;
                                                   double actual = MathUtils.distance(p1, p2);
                                                   
                                                   assertEquals("Distance calculation incorrect - mutant not detected", 
                                                               expected, actual, 0.0001);
                                                   
                                                   // Additional test case with negative numbers
                                                   double[] p3 = {-1.0, 2.0};
                                                   double[] p4 = {3.0, -4.0};
                                                   
                                                   // Original: sqrt((-1-3)² + (2-(-4))²) = sqrt(16 + 36) = sqrt(52) ≈ 7.2111
                                                   // Mutant: sqrt((-1*3)² + (2*-4)²) = sqrt(9 + 64) = sqrt(73) ≈ 8.5440
                                                   expected = 7.2111;
                                                   actual = MathUtils.distance(p3, p4);
                                                   
                                                   assertEquals("Distance calculation with negatives incorrect - mutant not detected",
                                                               expected, actual, 0.0001);
                                               }

 @Test
                                              public void testDistanceDetectsMutant() {
                                                  // Test case where p1 and p2 are different
                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                  
                                                  // Calculate expected distance manually
                                                  double expectedDistance = Math.sqrt(
                                                      Math.pow(1.0-4.0, 2) + 
                                                      Math.pow(2.0-5.0, 2) + 
                                                      Math.pow(3.0-6.0, 2)
                                                  );
                                                  
                                                  // Call the method
                                                  double actualDistance = MathUtils.distance(p1, p2);
                                                  
                                                  // Verify the result
                                                  assertEquals("Distance calculation should be correct", 
                                                              expectedDistance, 
                                                              actualDistance, 
                                                              0.0001);
                                                  
                                                  // Additional test case where p1 and p2 are same (distance should be 0)
                                                  double[] p3 = {1.0, 1.0};
                                                  double[] p4 = {1.0, 1.0};
                                                  assertEquals("Distance between identical points should be 0", 
                                                              0.0, 
                                                              MathUtils.distance(p3, p4), 
                                                              0.0001);
                                                  
                                                  // Test case with negative values
                                                  double[] p5 = {-1.0, -2.0};
                                                  double[] p6 = {1.0, 2.0};
                                                  double expectedDistance2 = Math.sqrt(
                                                      Math.pow(-1.0-1.0, 2) + 
                                                      Math.pow(-2.0-2.0, 2)
                                                  );
                                                  assertEquals("Distance with negative values should be correct",
                                                              expectedDistance2,
                                                              MathUtils.distance(p5, p6),
                                                              0.0001);
                                              }

 @Test
                                                  public void testDistanceDetectsMutant1() {
                                                      // Test case where p1 and p2 are different
                                                      double[] p1 = {1.0, 2.0, 3.0};
                                                      double[] p2 = {4.0, 5.0, 6.0};
                                                      
                                                      // Calculate expected distance manually
                                                      double expectedDistance = Math.sqrt(
                                                          Math.pow(1.0-4.0, 2) + 
                                                          Math.pow(2.0-5.0, 2) + 
                                                          Math.pow(3.0-6.0, 2)
                                                      );
                                                      
                                                      // Call the method and assert
                                                      double actualDistance = MathUtils.distance(p1, p2);
                                                      assertEquals("Distance calculation is incorrect", 
                                                                  expectedDistance, 
                                                                  actualDistance, 
                                                                  0.0001);
                                                      
                                                      // Additional test case with zeros
                                                      double[] p3 = {0.0, 0.0};
                                                      double[] p4 = {3.0, 4.0};
                                                      assertEquals("Distance should be 5 for (0,0) to (3,4)", 
                                                                  5.0, 
                                                                  MathUtils.distance(p3, p4), 
                                                                  0.0001);
                                                      
                                                      // Test case with negative values
                                                      double[] p5 = {-1.0, -2.0};
                                                      double[] p6 = {1.0, 2.0};
                                                      double expectedNegativeDistance = Math.sqrt(
                                                          Math.pow(-1.0-1.0, 2) + 
                                                          Math.pow(-2.0-2.0, 2)
                                                      );
                                                      assertEquals("Distance with negative values incorrect",
                                                                  expectedNegativeDistance,
                                                                  MathUtils.distance(p5, p6),
                                                                  0.0001);
                                                  }

 @Test
                                                 public void testDistanceCapturesSquaredDifferenceMutant() {
                                                     // Test case that will fail if sum += dp is used instead of sum += dp*dp
                                                     double[] p1 = {2.0, 3.0};  // Point (2,3)
                                                     double[] p2 = {5.0, 7.0};  // Point (5,7)
                                                     
                                                     // Calculate expected Euclidean distance: sqrt((5-2)² + (7-3)²) = sqrt(9 + 16) = 5.0
                                                     double expected = 5.0;
                                                     
                                                     // Calculate using the method
                                                     double actual = MathUtils.distance(p1, p2);
                                                     
                                                     // Verify with delta for floating point precision
                                                     assertEquals("Distance calculation incorrect - mutant not detected", 
                                                                 expected, actual, 0.0001);
                                                     
                                                     // If mutant is present, it would calculate:
                                                     // sum = (5-2) + (7-3) = 3 + 4 = 7
                                                     // sqrt(7) ≈ 2.64575 which would not match expected 5.0
                                                 }

 @Test
                                                 public void testDistanceWithNegativeValues() {
                                                     // Another test case with negative values
                                                     double[] p1 = {-1.0, -2.0};
                                                     double[] p2 = {2.0, 3.0};
                                                     
                                                     // Expected: sqrt((2 - -1)² + (3 - -2)²) = sqrt(9 + 25) = sqrt(34) ≈ 5.83095
                                                     double expected = Math.sqrt(34);
                                                     
                                                     double actual = MathUtils.distance(p1, p2);
                                                     
                                                     assertEquals("Distance with negative values incorrect - mutant not detected",
                                                                 expected, actual, 0.0001);
                                                 }

 @Test
                                                 public void testDistanceShouldCalculateCorrectEuclideanDistance() {
                                                     // Arrange
                                                     double[] p1 = {3.0, 4.0};  // Point (3,4)
                                                     double[] p2 = {0.0, 0.0};   // Origin (0,0)
                                                     
                                                     // Expected calculation:
                                                     // diff1 = 3-0 = 3 → squared = 9
                                                     // diff2 = 4-0 = 4 → squared = 16
                                                     // sum = 25 → sqrt = 5
                                                     double expectedDistance = 5.0;
                                                     
                                                     // Act
                                                     double actualDistance = MathUtils.distance(p1, p2);
                                                     
                                                     // Assert
                                                     assertEquals("Distance calculation is incorrect", 
                                                                 expectedDistance, actualDistance, 0.0001);
                                                     
                                                     // This will fail with the mutation because:
                                                     // With mutation: sum = 3 + 4 = 7 → sqrt(7) ≈ 2.64575
                                                     // Expected: 5.0
                                                 }

 @Test
                                                 public void testDistanceWithNegativeCoordinates() {
                                                     // Arrange
                                                     double[] p1 = {-1.0, -1.0};
                                                     double[] p2 = {2.0, 3.0};
                                                     
                                                     // Expected calculation:
                                                     // diff1 = -1-2 = -3 → squared = 9
                                                     // diff2 = -1-3 = -4 → squared = 16
                                                     // sum = 25 → sqrt = 5
                                                     double expectedDistance = 5.0;
                                                     
                                                     // Act
                                                     double actualDistance = MathUtils.distance(p1, p2);
                                                     
                                                     // Assert
                                                     assertEquals("Distance calculation with negative coordinates is incorrect",
                                                                 expectedDistance, actualDistance, 0.0001);
                                                     
                                                     // This will fail with mutation because:
                                                     // With mutation: sum = -3 + -4 = -7 → sqrt(-7) would be NaN
                                                     // But even if absolute values were used, sum would be 7 → sqrt(7) ≈ 2.64575
                                                 }

 @Test
                                                public void testDistanceDetectsSumSubtractionMutant() {
                                                    // Test case that will catch the sum -= dp*dp mutant
                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                    double[] p2 = {4.0, 5.0, 6.0};
                                                    
                                                    // Calculate expected distance manually:
                                                    // diff1 = 1-4 = -3 → squared = 9
                                                    // diff2 = 2-5 = -3 → squared = 9
                                                    // diff3 = 3-6 = -3 → squared = 9
                                                    // sum = 9+9+9 = 27
                                                    // sqrt(27) ≈ 5.196152422706632
                                                    double expected = 5.196152422706632;
                                                    double actual = MathUtils.distance(p1, p2);
                                                    
                                                    // The mutant would calculate:
                                                    // sum = 0-9-9-9 = -27
                                                    // sqrt(-27) = NaN
                                                    // So these assertions will catch the mutant
                                                    assertFalse(Double.isNaN(actual)); // Mutant would fail here
                                                    assertEquals(expected, actual, 1e-10); // Verify exact value
                                                }

 @Test
                                                public void testDistanceWithSamePoints() {
                                                    // Additional test case - distance between same points should be 0
                                                    double[] p1 = {1.5, 2.5};
                                                    double[] p2 = {1.5, 2.5};
                                                    double expected = 0.0;
                                                    double actual = MathUtils.distance(p1, p2);
                                                    
                                                    assertEquals(expected, actual, 0.0);
                                                }

 @Test
                                                public void testDistanceWithOneDimensionalPoints() {
                                                    // Test with 1D points
                                                    double[] p1 = {5.0};
                                                    double[] p2 = {2.0};
                                                    double expected = 3.0; // sqrt((5-2)^2) = 3
                                                    double actual = MathUtils.distance(p1, p2);
                                                    
                                                    assertEquals(expected, actual, 0.0);
                                                }

 @Test
                                                public void testDistanceShouldCalculateCorrectEuclideanDistance1() {
                                                    // Arrange
                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                    double[] p2 = {4.0, 5.0, 6.0};
                                                    
                                                    // Expected calculation:
                                                    // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                    // sqrt(27) ≈ 5.196152422706632
                                                    double expectedDistance = 5.196152422706632;
                                                    
                                                    // Act
                                                    double actualDistance = MathUtils.distance(p1, p2);
                                                    
                                                    // Assert
                                                    // Check it's a positive finite number (would be NaN with mutant)
                                                    assertTrue(Double.isFinite(actualDistance));
                                                    assertTrue(actualDistance > 0);
                                                    
                                                    // Check exact value with delta for floating point precision
                                                    assertEquals(expectedDistance, actualDistance, 1e-10);
                                                }

 @Test
                                                public void testDistanceShouldReturnZeroForIdenticalPoints() {
                                                    // Arrange
                                                    double[] p1 = {1.5, 2.5, 3.5};
                                                    double[] p2 = {1.5, 2.5, 3.5};
                                                    
                                                    // Act
                                                    double result = MathUtils.distance(p1, p2);
                                                    
                                                    // Assert
                                                    assertEquals(0.0, result, 0.0);
                                                }

 @Test
                                                public void testDistanceShouldHandleSingleDimension() {
                                                    // Arrange
                                                    double[] p1 = {5.0};
                                                    double[] p2 = {2.0};
                                                    
                                                    // Expected: sqrt((5-2)²) = 3.0
                                                    double expected = 3.0;
                                                    
                                                    // Act
                                                    double result = MathUtils.distance(p1, p2);
                                                    
                                                    // Assert
                                                    assertEquals(expected, result, 0.0);
                                                }

 @Test
                                               public void testDistanceWithMultipleDimensions() {
                                                   // Arrange
                                                   double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
                                                   double[] p2 = {4.0, 5.0, 6.0}; // 3-dimensional point
                                                   
                                                   // Expected calculation:
                                                   // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                   // sqrt(27) ≈ 5.196152422706632
                                                   double expectedDistance = Math.sqrt(27);
                                                   
                                                   // Act
                                                   double actualDistance = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert
                                                   assertEquals("Distance calculation should accumulate all squared differences", 
                                                               expectedDistance, actualDistance, 1e-10);
                                               }

 @Test
                                               public void testDistanceWithTwoDimensions() {
                                                   // Arrange
                                                   double[] p1 = {0.0, 0.0}; // Origin
                                                   double[] p2 = {3.0, 4.0};  // Point (3,4)
                                                   
                                                   // Expected calculation:
                                                   // (0-3)² + (0-4)² = 9 + 16 = 25
                                                   // sqrt(25) = 5.0
                                                   double expectedDistance = 5.0;
                                                   
                                                   // Act
                                                   double actualDistance = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert
                                                   assertEquals("Distance calculation should work for 2D points", 
                                                               expectedDistance, actualDistance, 1e-10);
                                               }

 @Test
                                               public void testDistanceShouldCalculateCorrectlyForMultiDimensionalPoints() {
                                                   // Arrange
                                                   double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
                                                   double[] p2 = {4.0, 5.0, 6.0}; // 3-dimensional point
                                                   
                                                   // Expected calculation:
                                                   // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                   // sqrt(27) ≈ 5.196152422706632
                                                   double expected = Math.sqrt(27);
                                                   
                                                   // Act
                                                   double actual = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert
                                                   assertEquals("Distance should be calculated correctly for multi-dimensional points", 
                                                               expected, actual, 1e-10);
                                                   
                                                   // This test will fail with the mutant because:
                                                   // Mutant would only calculate (3-6)² = 9 and return sqrt(9) = 3
                                                   // While original would return sqrt(27) ≈ 5.196
                                               }

 @Test
                                          public void testDistanceDetectsDivisionMutant() {
                                              // Arrange
                                              double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
                                              double[] p2 = {4.0, 5.0, 6.0}; // Different 3-dimensional point
                                              
                                              // Expected Euclidean distance calculation:
                                              // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196
                                              double expectedDistance = Math.sqrt(27.0);
                                              
                                              // Act
                                              double actualDistance = MathUtils.distance(p1, p2);
                                              
                                              // Assert
                                              // Original would return ~5.196, mutant would return sqrt(3) ≈ 1.732
                                              assertEquals("Distance calculation should use squared differences, not division", 
                                                          expectedDistance, actualDistance, 0.0001);
                                              
                                              // Additional check that specifically catches the mutant
                                              assertNotEquals("Mutant detection: distance should not equal sqrt(array length)",
                                                            Math.sqrt(p1.length), actualDistance, 0.0001);
                                          }

 @Test
                                              public void testDistanceWithNonZeroDifferences() {
                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                  
                                                  // Original would calculate: sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196
                                                  // Mutant would calculate: sqrt(1 + 1 + 1) = sqrt(3) ≈ 1.732
                                                  double expected = Math.sqrt(27); // Correct result
                                                  double actual = MathUtils.distance(p1, p2);
                                                  
                                                  assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                              }

 @Test(expected = ArithmeticException.class)
                                              public void testDistanceWithZeroDifferences() {
                                                  double[] p1 = {1.0, 1.0, 1.0};
                                                  double[] p2 = {1.0, 1.0, 1.0};
                                                  
                                                  // Original would calculate: sqrt(0 + 0 + 0) = 0
                                                  // Mutant would try to do 0/0 and throw ArithmeticException
                                                  MathUtils.distance(p1, p2);
                                                  
                                                  // If we get here, the test fails (mutant not detected)
                                                  fail("Expected ArithmeticException for division by zero");
                                              }

 @Test
                                             public void testDistanceReturnsSquareRootOfSumOfSquares() {
                                                 // Test case where sum of squares is 25 (5^2)
                                                 double[] p1 = {3.0, 4.0}; // 3^2 + 4^2 = 9 + 16 = 25
                                                 double[] p2 = {0.0, 0.0};
                                                 
                                                 double expected = 5.0; // sqrt(25) = 5
                                                 double actual = MathUtils.distance(p1, p2);
                                                 
                                                 assertEquals("Distance should be square root of sum of squares", 
                                                             expected, actual, 0.0001);
                                                 
                                                 // Additional test case where sum isn't a perfect square
                                                 double[] p3 = {1.0, 1.0}; // 1^2 + 1^2 = 2
                                                 double[] p4 = {0.0, 0.0};
                                                 
                                                 expected = Math.sqrt(2.0); // ~1.4142
                                                 actual = MathUtils.distance(p3, p4);
                                                 
                                                 assertEquals("Distance should be square root of sum of squares", 
                                                             expected, actual, 0.0001);
                                             }

 @Test
                                         public void testDistanceShouldReturnSquareRootOfSum() {
                                             // Arrange
                                             double[] p1 = {3.0, 4.0};  // 3D point (3,4)
                                             double[] p2 = {0.0, 0.0};  // Origin
                                             
                                             // Calculate expected values
                                             double sumOfSquares = (3.0*3.0) + (4.0*4.0);  // 9 + 16 = 25
                                             double expectedDistance = Math.sqrt(sumOfSquares);  // 5.0
                                             
                                             // Act
                                             double actualDistance = MathUtils.distance(p1, p2);
                                             
                                             // Assert
                                             // This will catch the mutant because:
                                             // - Original returns 5.0 (√25)
                                             // - Mutant returns 25.0
                                             assertEquals("Distance should be square root of sum of squared differences", 
                                                         expectedDistance, actualDistance, 0.0001);
                                             
                                             // Additional assertion to make it explicit
                                             assertNotEquals("Should not return raw sum of squares", 
                                                            sumOfSquares, actualDistance, 0.0001);
                                         }

 @Test
                                        public void testDistanceShouldReturnSquareRootOfSumNotSquare() {
                                            // Test with simple known values where sqrt(sum) != pow(sum,2)
                                            double[] p1 = {0.0, 0.0};
                                            double[] p2 = {3.0, 4.0};
                                            
                                            // Original should return 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5
                                            // Mutated version would return 25.0 (pow(25, 2))
                                            
                                            double result = MathUtils.distance(p1, p2);
                                            
                                            // Verify it's the square root (correct behavior) not the square (mutated behavior)
                                            assertEquals(5.0, result, 0.0001);
                                            
                                            // Additional test case with different values
                                            double[] p3 = {1.0, 1.0};
                                            double[] p4 = {4.0, 5.0};
                                            // sqrt((4-1)² + (5-1)²) = sqrt(9+16) = 5
                                            // Mutated would return 25
                                            assertEquals(5.0, MathUtils.distance(p3, p4), 0.0001);
                                            
                                            // Edge case with zero distance
                                            double[] p5 = {2.5, 3.5};
                                            double[] p6 = {2.5, 3.5};
                                            // sqrt(0) = 0
                                            // Mutated would return 0 (same in this case, so need another test)
                                            assertEquals(0.0, MathUtils.distance(p5, p6), 0.0001);
                                            
                                            // Another test where sum is not a perfect square
                                            double[] p7 = {1.0, 2.0};
                                            double[] p8 = {3.0, 5.0};
                                            // sqrt(4 + 9) = sqrt(13) ≈ 3.60555
                                            // Mutated would return 13
                                            assertEquals(Math.sqrt(13), MathUtils.distance(p7, p8), 0.0001);
                                        }

 @Test
                                        public void testDistanceShouldReturnSquareRootNotSquare() {
                                            // Test with simple known values where sqrt and pow give different results
                                            double[] p1 = {0.0, 0.0};
                                            double[] p2 = {3.0, 4.0};
                                            
                                            // Original should return sqrt(3² + 4²) = 5.0
                                            // Mutated would return (3² + 4²)² = 25² = 625.0
                                            double expected = 5.0;
                                            double actual = MathUtils.distance(p1, p2);
                                            
                                            assertEquals("Distance calculation should return square root of sum of squares", 
                                                        expected, actual, 0.0001);
                                            
                                            // Another test case with different values
                                            double[] p3 = {1.0, 1.0};
                                            double[] p4 = {4.0, 5.0};
                                            
                                            // Original: sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5.0
                                            // Mutated: (9 + 16)² = 625.0
                                            expected = 5.0;
                                            actual = MathUtils.distance(p3, p4);
                                            
                                            assertEquals("Distance calculation should return square root of sum of squares", 
                                                        expected, actual, 0.0001);
                                            
                                            // Edge case: zero distance
                                            double[] p5 = {2.5, 3.5};
                                            double[] p6 = {2.5, 3.5};
                                            
                                            // Original: sqrt(0 + 0) = 0.0
                                            // Mutated: (0 + 0)² = 0.0
                                            // This case wouldn't catch the mutant, but is good for completeness
                                            expected = 0.0;
                                            actual = MathUtils.distance(p5, p6);
                                            
                                            assertEquals("Identical points should have zero distance", 
                                                        expected, actual, 0.0001);
                                        }

 @Test
                                           public void testDistanceShouldReturnExactValue() {
                                               // Test case with identical points (distance should be 0)
                                               double[] p1 = {0.0, 0.0, 0.0};
                                               double[] p2 = {0.0, 0.0, 0.0};
                                               
                                               double result = MathUtils.distance(p1, p2);
                                               
                                               // Original would return 0.0, mutant would return 1.0
                                               assertEquals(0.0, result, 0.0);
                                               
                                               // Additional test case with known distance
                                               double[] p3 = {3.0, 4.0}; // 3-4-5 triangle
                                               double[] p4 = {0.0, 0.0};
                                               double result2 = MathUtils.distance(p3, p4);
                                               
                                               // Original would return 5.0, mutant would return 6.0
                                               assertEquals(5.0, result2, 0.0);
                                           }

 @Test
                                           public void testDistanceShouldReturnCorrectEuclideanDistance() {
                                               // Test case 1: Zero distance (same point)
                                               double[] p1 = {0.0, 0.0};
                                               double[] p2 = {0.0, 0.0};
                                               double expected = 0.0;
                                               double actual = MathUtils.distance(p1, p2);
                                               assertEquals("Distance between same points should be 0", expected, actual, 0.0001);
                                       
                                               // Test case 2: Simple 1D distance
                                               double[] p3 = {0.0};
                                               double[] p4 = {3.0};
                                               expected = 3.0;
                                               actual = MathUtils.distance(p3, p4);
                                               assertEquals("Simple 1D distance incorrect", expected, actual, 0.0001);
                                       
                                               // Test case 3: 3-4-5 right triangle case
                                               double[] p5 = {0.0, 0.0};
                                               double[] p6 = {3.0, 4.0};
                                               expected = 5.0;
                                               actual = MathUtils.distance(p5, p6);
                                               assertEquals("3-4-5 triangle distance incorrect", expected, actual, 0.0001);
                                       
                                               // Test case 4: Multi-dimensional case
                                               double[] p7 = {1.0, 2.0, 3.0};
                                               double[] p8 = {4.0, 5.0, 6.0};
                                               expected = Math.sqrt(27); // sqrt(3² + 3² + 3²) = sqrt(27)
                                               actual = MathUtils.distance(p7, p8);
                                               assertEquals("Multi-dimensional distance incorrect", expected, actual, 0.0001);
                                           }

 @Test
                                          public void testDistanceShouldReturnPositiveValue() {
                                              // Test with simple 2D points where distance is clearly positive
                                              double[] p1 = {0.0, 0.0};
                                              double[] p2 = {3.0, 4.0}; // Distance should be 5.0 (3-4-5 triangle)
                                              
                                              double result = MathUtils.distance(p1, p2);
                                              
                                              // Verify the distance is positive
                                              assertTrue("Distance should be positive", result > 0);
                                              
                                              // Also verify the exact value to ensure correct calculation
                                              assertEquals(5.0, result, 0.0001);
                                              
                                              // Test with identical points (distance should be 0)
                                              double[] p3 = {1.5, 2.5};
                                              double result2 = MathUtils.distance(p3, p3);
                                              assertEquals(0.0, result2, 0.0001);
                                              
                                              // Test with another set of points
                                              double[] p4 = {1.0, 1.0, 1.0};
                                              double[] p5 = {2.0, 2.0, 2.0};
                                              double expected = Math.sqrt(3.0); // sqrt(1² + 1² + 1²) = sqrt(3)
                                              double result3 = MathUtils.distance(p4, p5);
                                              assertTrue("Distance should be positive", result3 > 0);
                                              assertEquals(expected, result3, 0.0001);
                                          }

 @Test
                                          public void testDistanceShouldReturnNonNegativeValue() {
                                              // Test case 1: Simple known distance
                                              double[] p1 = {0.0, 0.0};
                                              double[] p2 = {3.0, 4.0};
                                              double distance = MathUtils.distance(p1, p2);
                                              assertTrue("Distance should be non-negative", distance >= 0);
                                              assertEquals("Distance should be 5.0 for points (0,0) and (3,4)", 
                                                           5.0, distance, 0.0001);
                                      
                                              // Test case 2: Zero distance (same points)
                                              double[] p3 = {1.5, 2.5};
                                              double zeroDistance = MathUtils.distance(p3, p3);
                                              assertTrue("Distance between same points should be 0", 
                                                        zeroDistance == 0.0);
                                      
                                              // Test case 3: Random points
                                              double[] p4 = {1.2, 3.4, 5.6};
                                              double[] p5 = {7.8, 9.0, 1.2};
                                              double randomDistance = MathUtils.distance(p4, p5);
                                              assertTrue("Distance should be non-negative for random points", 
                                                        randomDistance >= 0);
                                      
                                              // Test case 4: Edge case with maximum double values
                                              double[] p6 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                              double[] p7 = {Double.MIN_VALUE, Double.MIN_VALUE};
                                              double edgeDistance = MathUtils.distance(p6, p7);
                                              assertTrue("Distance should be non-negative for edge cases", 
                                                        edgeDistance >= 0);
                                          }

 @Test
                                         public void testDistanceShouldNotDivideSumByTwo() {
                                             // Test case 1: Simple 1D case
                                             double[] p1 = {0.0};
                                             double[] p2 = {2.0};
                                             double expected = 2.0; // sqrt((2-0)^2) = 2
                                             double actual = MathUtils.distance(p1, p2);
                                             assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                             
                                             // Test case 2: 2D case where sum of squares is 2
                                             double[] p3 = {0.0, 0.0};
                                             double[] p4 = {1.0, 1.0};
                                             expected = Math.sqrt(2.0); // sqrt(1^2 + 1^2) = sqrt(2)
                                             actual = MathUtils.distance(p3, p4);
                                             assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                             
                                             // Test case 3: 3D case where sum of squares is 3
                                             double[] p5 = {0.0, 0.0, 0.0};
                                             double[] p6 = {1.0, 1.0, 1.0};
                                             expected = Math.sqrt(3.0); // sqrt(1^2 + 1^2 + 1^2) = sqrt(3)
                                             actual = MathUtils.distance(p5, p6);
                                             assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                         }

 @Test
                                     public void testDistanceShouldDetectSqrtSumMutation() {
                                         // Arrange
                                         double[] p1 = {0.0, 0.0};  // Origin point
                                         double[] p2 = {3.0, 4.0};   // Point at (3,4)
                                         
                                         // Expected distance calculation:
                                         // sum = (3-0)² + (4-0)² = 9 + 16 = 25
                                         // distance = √25 = 5
                                         double expectedDistance = 5.0;
                                         
                                         // If mutation exists (sum/2):
                                         // sum = 25
                                         // distance = √(25/2) ≈ 3.5355
                                         
                                         // Act and Assert
                                         double actualDistance = MathUtils.distance(p1, p2);
                                         assertEquals("Distance calculation is incorrect - mutation may exist", 
                                                     expectedDistance, 
                                                     actualDistance, 
                                                     0.0001);  // delta for floating point comparison
                                     }

 @Test
                                        public void testDistanceWithZeroLengthVectors1() {
                                            // Test with identical points (distance should be exactly 0)
                                            double[] p1 = {0.0, 0.0, 0.0};
                                            double[] p2 = {0.0, 0.0, 0.0};
                                            double expected = 0.0;
                                            double actual = MathUtils.distance(p1, p2);
                                            assertEquals("Distance between identical points should be 0", expected, actual, 0.0);
                                        }

 @Test
                                        public void testDistanceWithVeryClosePoints() {
                                            // Test with points very close to each other
                                            double[] p1 = {1.0, 1.0};
                                            double[] p2 = {1.0 + 1e-10, 1.0 + 1e-10};
                                            // Expected distance is sqrt(2*(1e-10)^2) = sqrt(2)*1e-10 ≈ 1.4142135623730951e-10
                                            double expected = Math.sqrt(2) * 1e-10;
                                            double actual = MathUtils.distance(p1, p2);
                                            assertEquals("Distance calculation is incorrect for very close points", 
                                                         expected, actual, 1e-20);
                                        }

 @Test
                                        public void testDistanceWithSimpleCase() {
                                            // Simple case where we can easily compute the expected value
                                            double[] p1 = {0.0, 0.0};
                                            double[] p2 = {3.0, 4.0};
                                            double expected = 5.0; // sqrt(3^2 + 4^2) = 5
                                            double actual = MathUtils.distance(p1, p2);
                                            assertEquals("Distance calculation is incorrect for simple case", 
                                                         expected, actual, 0.0);
                                        }

 @Test
                                        public void testDistanceWithZeroLengthVectors2() {
                                            // Test with zero-length vectors (should return 0)
                                            double[] zeroVector = new double[0];
                                            double expected = 0.0;
                                            double actual = MathUtils.distance(zeroVector, zeroVector);
                                            assertEquals("Distance between zero-length vectors should be 0", 
                                                        expected, actual, 0.0);
                                        }

 @Test
                                        public void testDistanceWithIdenticalPoints() {
                                            // Test with identical points (should return 0)
                                            double[] point1 = {0.0, 0.0, 0.0};
                                            double[] point2 = {0.0, 0.0, 0.0};
                                            double expected = 0.0;
                                            double actual = MathUtils.distance(point1, point2);
                                            assertEquals("Distance between identical points should be 0", 
                                                        expected, actual, 0.0);
                                        }

 @Test
                                        public void testDistanceWithVerySmallDistance() {
                                            // Test with very small distance to amplify the +1 error
                                            double[] point1 = {0.0};
                                            double[] point2 = {1e-8}; // Very small difference
                                            double expected = 1e-8;
                                            double actual = MathUtils.distance(point1, point2);
                                            assertEquals("Distance with very small difference", 
                                                        expected, actual, 1e-10);
                                        }

 @Test
                                       public void testDistanceWithFractionalDifferences1() {
                                           // Test with small fractional differences that would be truncated with int sum
                                           double[] p1 = {1.1, 2.2, 3.3};
                                           double[] p2 = {1.2, 2.3, 3.4};
                                           
                                           // Calculate expected value manually
                                           double expected = Math.sqrt(
                                               Math.pow(1.1-1.2, 2) + 
                                               Math.pow(2.2-2.3, 2) + 
                                               Math.pow(3.3-3.4, 2)
                                           );
                                           
                                           double actual = MathUtils.distance(p1, p2);
                                           
                                           // With int sum, this would fail due to truncation of fractional parts
                                           assertEquals(expected, actual, 0.0001);
                                       }

 @Test
                                       public void testDistanceWithLargeValues() {
                                           // Test with values that could cause integer overflow if sum was int
                                           double[] p1 = {1000000.1, 2000000.2, 3000000.3};
                                           double[] p2 = {1000000.2, 2000000.3, 3000000.4};
                                           
                                           // Calculate expected value manually
                                           double expected = Math.sqrt(
                                               Math.pow(1000000.1-1000000.2, 2) + 
                                               Math.pow(2000000.2-2000000.3, 2) + 
                                               Math.pow(3000000.3-3000000.4, 2)
                                           );
                                           
                                           double actual = MathUtils.distance(p1, p2);
                                           
                                           // With int sum, this would fail due to integer overflow
                                           assertEquals(expected, actual, 0.0001);
                                       }

 @Test
                                       public void testDistancePrecision() {
                                           // Create test points with fractional differences
                                           double[] p1 = {1.1, 2.2, 3.3, 4.4, 5.5};
                                           double[] p2 = {1.2, 2.3, 3.4, 4.5, 5.6};
                                           
                                           // Calculate expected value manually
                                           double expected = 0.0;
                                           for (int i = 0; i < p1.length; i++) {
                                               double diff = p1[i] - p2[i];
                                               expected += diff * diff;
                                           }
                                           expected = Math.sqrt(expected);
                                           
                                           // Call the method and assert
                                           double actual = MathUtils.distance(p1, p2);
                                           
                                           // With double sum, this should pass
                                           // With int sum, precision loss would make it fail
                                           assertEquals("Distance calculation should maintain precision", 
                                                      expected, actual, 0.000001);
                                           
                                           // Additional test with more significant fractional parts
                                           double[] p3 = {0.123456789, 0.987654321};
                                           double[] p4 = {0.987654321, 0.123456789};
                                           
                                           expected = 0.0;
                                           for (int i = 0; i < p3.length; i++) {
                                               double diff = p3[i] - p4[i];
                                               expected += diff * diff;
                                           }
                                           expected = Math.sqrt(expected);
                                           
                                           actual = MathUtils.distance(p3, p4);
                                           assertEquals("Distance should handle small fractional differences precisely",
                                                      expected, actual, 0.000000001);
                                       }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                      public void testDistanceWithMutatedLoopCondition1() {
                                          // Arrange
                                          double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                          double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                          
                                          // Act - this should throw ArrayIndexOutOfBoundsException for the mutant
                                          // For original code, it would complete normally
                                          MathUtils.distance(p1, p2);
                                          
                                          // If we reach here, the test fails (mutant not detected)
                                          // For original code, we should add assertions to verify correct distance
                                          double expectedDistance = Math.sqrt(9 + 9 + 9); // sqrt(27)
                                          assertEquals(expectedDistance, MathUtils.distance(p1, p2), 0.0001);
                                      }

 @Test
                                      public void testDistanceWithValidArrays() {
                                          // Test with arrays of length 1
                                          double[] p1 = {1.0};
                                          double[] p2 = {2.0};
                                          double expected = 1.0; // sqrt((2-1)^2) = 1
                                          double result = MathUtils.distance(p1, p2);
                                          assertEquals(expected, result, 0.0001);
                                          
                                          // Test with arrays of length 2
                                          double[] p3 = {1.0, 2.0};
                                          double[] p4 = {4.0, 6.0};
                                          expected = 5.0; // sqrt((4-1)^2 + (6-2)^2) = 5
                                          result = MathUtils.distance(p3, p4);
                                          assertEquals(expected, result, 0.0001);
                                      }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                      public void testDistanceShouldThrowExceptionWithMutant() {
                                          // This test will pass only if the mutant exists (i <= length instead of i < length)
                                          // because it will try to access an out-of-bounds index
                                          double[] p1 = {1.0, 2.0};
                                          double[] p2 = {3.0, 4.0};
                                          
                                          // If the mutant exists, this will throw ArrayIndexOutOfBoundsException
                                          // If the original code is present, this will complete normally
                                          MathUtils.distance(p1, p2);
                                      }

 @Test
                                      public void testDistanceWithEmptyArrays() {
                                          // Test with empty arrays (edge case)
                                          double[] p1 = {};
                                          double[] p2 = {};
                                          double expected = 0.0; // sqrt(0) = 0
                                          double result = MathUtils.distance(p1, p2);
                                          assertEquals(expected, result, 0.0001);
                                      }

 @Test
                                     public void testDistanceShouldCalculateCorrectlyForAllArrayElements() {
                                         // Arrange
                                         double[] p1 = {3.0, 4.0};  // Simple 2D point
                                         double[] p2 = {0.0, 0.0};  // Origin
                                         
                                         // Expected distance calculation: sqrt((3-0)² + (4-0)²) = 5
                                         double expectedDistance = 5.0;
                                         
                                         // Act
                                         double actualDistance = MathUtils.distance(p1, p2);
                                         
                                         // Assert
                                         assertEquals("Distance should be calculated using all array elements", 
                                                     expectedDistance, actualDistance, 0.0001);
                                     }

 @Test
                                     public void testDistanceShouldIncludeFirstElementInCalculation() {
                                         // Arrange - point where all distance comes from first element
                                         double[] p1 = {5.0, 0.0};  
                                         double[] p2 = {0.0, 0.0};
                                         
                                         // Expected distance: sqrt((5-0)² + (0-0)²) = 5
                                         double expectedDistance = 5.0;
                                         
                                         // Act
                                         double actualDistance = MathUtils.distance(p1, p2);
                                         
                                         // Assert
                                         assertEquals("Distance must include first element in calculation",
                                                     expectedDistance, actualDistance, 0.0001);
                                     }

 @Test
                                     public void testDistanceShouldIncludeFirstElement2() {
                                         // Create test arrays where only first elements differ
                                         double[] p1 = {5.0, 0.0, 0.0};  // First element is 5.0
                                         double[] p2 = {1.0, 0.0, 0.0};  // First element is 1.0
                                         
                                         // Calculate expected distance manually
                                         double expected = Math.sqrt((5.0-1.0)*(5.0-1.0)); // Should be 4.0
                                         
                                         // Call the method
                                         double actual = MathUtils.distance(p1, p2);
                                         
                                         // Assert with delta for floating point precision
                                         assertEquals("Distance calculation should include first element", 
                                                     expected, actual, 0.0001);
                                         
                                         // Additional test with single-element arrays
                                         double[] single1 = {2.0};
                                         double[] single2 = {0.0};
                                         double expectedSingle = 2.0;
                                         double actualSingle = MathUtils.distance(single1, single2);
                                         assertEquals("Distance calculation should work with single-element arrays",
                                                     expectedSingle, actualSingle, 0.0001);
                                     }

 @Test
                                public void testDistanceShouldProcessAllDimensions1() {
                                    // Create test points with 3 dimensions where the difference is only in the last dimension
                                    double[] p1 = {1.0, 2.0, 3.0};
                                    double[] p2 = {1.0, 2.0, 5.0};  // Only differs in last dimension
                                    
                                    // Calculate expected distance manually
                                    double expectedDistance = Math.sqrt((3.0 - 5.0) * (3.0 - 5.0));  // Only last dimension contributes
                                    
                                    // Call the method
                                    double actualDistance = MathUtils.distance(p1, p2);
                                    
                                    // Assert the distance is calculated correctly
                                    assertEquals("Distance should include all dimensions", 
                                                 expectedDistance, 
                                                 actualDistance, 
                                                 0.0001);
                                    
                                    // Additional test with more dimensions to be thorough
                                    double[] p3 = {1.0, 2.0, 3.0, 4.0, 5.0};
                                    double[] p4 = {1.0, 2.0, 3.0, 4.0, 6.0};  // Only differs in last dimension
                                    double expectedDistance2 = Math.sqrt((5.0 - 6.0) * (5.0 - 6.0));
                                    double actualDistance2 = MathUtils.distance(p3, p4);
                                    assertEquals("Distance should include all dimensions for 5D case",
                                                 expectedDistance2,
                                                 actualDistance2,
                                                 0.0001);
                                }

 @Test
                                public void testDistanceShouldProcessAllElements() {
                                    // Create test data where last element makes significant difference
                                    double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                    double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                    
                                    // Calculate expected distance manually (including all elements)
                                    double expected = Math.sqrt(
                                        Math.pow(1.0-4.0, 2) + 
                                        Math.pow(2.0-5.0, 2) + 
                                        Math.pow(3.0-6.0, 2)
                                    );
                                    
                                    // Call the method
                                    double actual = MathUtils.distance(p1, p2);
                                    
                                    // Verify the result
                                    assertEquals("Distance should include all array elements", 
                                                expected, actual, 0.0001);
                                    
                                    // Additional verification with different values
                                    double[] p3 = {0.0, 0.0, 10.0};
                                    double[] p4 = {0.0, 0.0, 0.0};
                                    assertEquals("Last element should contribute to distance", 
                                                10.0, MathUtils.distance(p3, p4), 0.0001);
                                }

 @Test
                                   public void testDistanceShouldCalculateEuclideanDistance1() {
                                       // Test case that will catch the mutant
                                       double[] p1 = {1.0, 2.0, 3.0};
                                       double[] p2 = {4.0, 5.0, 6.0};
                                       
                                       // Expected distance calculation:
                                       // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                       double expected = Math.sqrt(27);
                                       
                                       // If mutant exists (using addition instead of subtraction):
                                       // sqrt((1+4)² + (2+5)² + (3+6)²) = sqrt(25 + 49 + 81) = sqrt(155) ≈ 12.4499
                                       // This would fail the assertion
                                       
                                       double actual = MathUtils.distance(p1, p2);
                                       
                                       assertEquals("Distance calculation is incorrect", expected, actual, 0.000001);
                                   }

 @Test
                                   public void testDistanceWithNegativeNumbers() {
                                       // Additional test case with negative numbers
                                       double[] p1 = {-1.0, -2.0};
                                       double[] p2 = {1.0, 2.0};
                                       
                                       // Expected: sqrt((-1-1)² + (-2-2)²) = sqrt(4 + 16) = sqrt(20) ≈ 4.472136
                                       double expected = Math.sqrt(20);
                                       
                                       // Mutant would calculate: sqrt((-1+1)² + (-2+2)²) = sqrt(0 + 0) = 0
                                       // This would fail the assertion
                                       
                                       double actual = MathUtils.distance(p1, p2);
                                       
                                       assertEquals("Distance with negative numbers incorrect", expected, actual, 0.000001);
                                   }

 @Test
                                   public void testDistanceWithSingleDimension() {
                                       // Edge case: single dimension
                                       double[] p1 = {5.0};
                                       double[] p2 = {2.0};
                                       
                                       // Expected: sqrt((5-2)²) = 3.0
                                       double expected = 3.0;
                                       
                                       // Mutant would calculate: sqrt((5+2)²) = 7.0
                                       // This would fail the assertion
                                       
                                       double actual = MathUtils.distance(p1, p2);
                                       
                                       assertEquals("Single dimension distance incorrect", expected, actual, 0.000001);
                                   }

 @Test
                                   public void testDistanceDetectsSubtractionMutant1() {
                                       // Test case where p1 and p2 have opposite values
                                       double[] p1 = {1.0, -2.0, 3.0};
                                       double[] p2 = {-1.0, 2.0, -3.0};
                                       
                                       // Calculate expected Euclidean distance
                                       double expected = 0.0;
                                       for (int i = 0; i < p1.length; i++) {
                                           double diff = p1[i] - p2[i];
                                           expected += diff * diff;
                                       }
                                       expected = Math.sqrt(expected);
                                       
                                       // Calculate actual distance
                                       double actual = MathUtils.distance(p1, p2);
                                       
                                       // Assert the distance matches expected Euclidean distance
                                       assertEquals("Distance calculation should use subtraction, not addition", 
                                                   expected, actual, 0.0001);
                                       
                                       // Additional test case with non-zero expected result
                                       double[] p3 = {1.0, 2.0, 3.0};
                                       double[] p4 = {4.0, 5.0, 6.0};
                                       
                                       double expected2 = 0.0;
                                       for (int i = 0; i < p3.length; i++) {
                                           double diff = p3[i] - p4[i];
                                           expected2 += diff * diff;
                                       }
                                       expected2 = Math.sqrt(expected2);
                                       
                                       double actual2 = MathUtils.distance(p3, p4);
                                       assertEquals("Distance calculation should use subtraction for all cases",
                                                   expected2, actual2, 0.0001);
                                   }

 @Test
                                  public void testDistanceShouldCalculateCorrectDifference() {
                                      // Test with single dimension arrays where p1[0] != p2[0]
                                      double[] p1 = {3.0};
                                      double[] p2 = {1.0};
                                      
                                      // Original would calculate (3.0-1.0)² = 4.0, sqrt = 2.0
                                      // Mutant would calculate (1.0-3.0)² = 4.0, sqrt = 2.0
                                      // So this case wouldn't catch the mutant
                                      
                                      // Need to make the test sensitive to the operation order
                                      // Let's try with NaN values where order matters
                                      double[] p1_nan = {Double.NaN};
                                      double[] p2_nan = {1.0};
                                      
                                      // Original: NaN - 1.0 = NaN → NaN² = NaN → sqrt(NaN) = NaN
                                      // Mutant: 1.0 - NaN = NaN → same result
                                      // Still not catching
                                      
                                      // Alternative approach: verify the exact calculation sequence is maintained
                                      // Since the mathematical result is same, we need to test the behavior
                                      // when the calculation is observed through other means
                                      
                                      // Best approach: test with arrays of length 2 where the differences
                                      // are different in each dimension
                                      double[] p1_multi = {3.0, 1.0};
                                      double[] p2_multi = {1.0, 3.0};
                                      
                                      // Original calculation:
                                      // dim1: (3.0-1.0)² = 4.0
                                      // dim2: (1.0-3.0)² = 4.0
                                      // sum = 8.0 → sqrt = 2.828...
                                      
                                      // Mutant calculation:
                                      // dim1: (1.0-3.0)² = 4.0
                                      // dim2: (3.0-1.0)² = 4.0
                                      // sum = 8.0 → sqrt = 2.828...
                                      // Still same
                                      
                                      // Conclusion: The mutation is mathematically equivalent and cannot be detected
                                      // through normal testing of the distance method's output
                                      
                                      // However, if we want to be thorough and test the exact calculation sequence,
                                      // we could modify the test to verify the method's behavior with non-commutative
                                      // operations (though this isn't the case here)
                                      
                                      // Since the mutation is mathematically equivalent, it's actually an equivalent
                                      // mutant that can't be killed by testing the output
                                      
                                      // But if we must create a test that would fail with this mutation,
                                      // we could test with a mock that verifies operation order
                                      // (though this would be testing implementation details)
                                      
                                      // Final test case that would fail if the operation order changes:
                                      double[] p1_order = {1.0, 0.0};
                                      double[] p2_order = {0.0, 1.0};
                                      
                                      double expected = Math.sqrt(1.0 + 1.0); // 1.414...
                                      double actual = MathUtils.distance(p1_order, p2_order);
                                      
                                      assertEquals("Distance calculation should be correct", expected, actual, 0.0001);
                                      
                                      // Note: This test won't actually catch the mutant since the operation order
                                      // doesn't affect the final result in this case
                                  }

 @Test
                                  public void testDistanceShouldDetectOperationOrderWithSpecialValues() {
                                      // Test with values where operation order might matter
                                      double[] p1 = {Double.POSITIVE_INFINITY};
                                      double[] p2 = {Double.NEGATIVE_INFINITY};
                                      
                                      // Original: Infinity - (-Infinity) = +Infinity → squared = +Infinity
                                      // Mutant: -Infinity - Infinity = -Infinity → squared = +Infinity
                                      // Same result
                                      
                                      // This shows the mutant is actually equivalent and can't be killed
                                      // by normal testing of the distance method's output
                                  }

 @Test
                                  public void testDistanceWithNaNValues() {
                                      // Setup test data with NaN values where order of subtraction matters
                                      double[] p1 = {Double.NaN, 1.0};
                                      double[] p2 = {1.0, Double.NaN};
                                      
                                      // Calculate expected value manually
                                      double expectedSum = 0;
                                      for (int i = 0; i < p1.length; i++) {
                                          final double dp = p1[i] - p2[i];
                                          expectedSum += dp * dp;
                                      }
                                      double expected = Math.sqrt(expectedSum);
                                      
                                      // Calculate actual value
                                      double actual = MathUtils.distance(p1, p2);
                                      
                                      // Verify the result
                                      assertEquals("Distance calculation with NaN values should match expected", 
                                                  expected, actual, 0.0001);
                                      
                                      // Additional verification that the arrays were processed in correct order
                                      // NaN - number = NaN, number - NaN = NaN, but the computation path differs
                                      assertTrue(Double.isNaN(actual));
                                  }

 @Test
                                  public void testDistanceWithAsymmetricValues() {
                                      // Setup test data where p1 and p2 are different
                                      double[] p1 = {1.0, 2.0, 3.0};
                                      double[] p2 = {4.0, 5.0, 6.0};
                                      
                                      // Calculate expected value manually
                                      double expectedSum = 0;
                                      for (int i = 0; i < p1.length; i++) {
                                          final double dp = p1[i] - p2[i];
                                          expectedSum += dp * dp;
                                      }
                                      double expected = Math.sqrt(expectedSum);
                                      
                                      // Calculate actual value
                                      double actual = MathUtils.distance(p1, p2);
                                      
                                      // Verify the result
                                      assertEquals("Distance calculation should match expected", 
                                                  expected, actual, 0.0001);
                                  }

 @Test
                                 public void testDistanceShouldCalculateEuclideanDistance2() {
                                     // Test case where subtraction and multiplication would give different results
                                     double[] p1 = {3.0, 4.0};  // Point (3,4)
                                     double[] p2 = {1.0, 2.0};  // Point (1,2)
                                     
                                     // Original correct calculation:
                                     // sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                                     // Mutated calculation:
                                     // sqrt(3*1 + 4*2) = sqrt(3 + 8) = sqrt(11) ≈ 3.3166
                                     
                                     double expected = Math.sqrt(8.0); // Correct result
                                     double actual = MathUtils.distance(p1, p2);
                                     
                                     assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                 }

 @Test
                                 public void testDistanceWithNegativeNumbers1() {
                                     // Test with negative numbers where difference and product differ
                                     double[] p1 = {-1.0, -2.0};
                                     double[] p2 = {-3.0, -4.0};
                                     
                                     // Original: sqrt((-1 - -3)² + (-2 - -4)²) = sqrt(4 + 4) = sqrt(8)
                                     // Mutated: sqrt((-1 * -3) + (-2 * -4)) = sqrt(3 + 8) = sqrt(11)
                                     
                                     double expected = Math.sqrt(8.0);
                                     double actual = MathUtils.distance(p1, p2);
                                     
                                     assertEquals("Distance with negative numbers incorrect", expected, actual, 0.0001);
                                 }

 @Test
                                 public void testDistanceWithZeroValues1() {
                                     // Test where one array contains zeros
                                     double[] p1 = {0.0, 0.0};
                                     double[] p2 = {5.0, 12.0};
                                     
                                     // Original: sqrt(25 + 144) = 13
                                     // Mutated: sqrt(0 + 0) = 0
                                     
                                     double expected = 13.0;
                                     double actual = MathUtils.distance(p1, p2);
                                     
                                     assertEquals("Distance with zeros incorrect", expected, actual, 0.0001);
                                 }

 @Test
                                 public void testDistanceDetectsSubtractionToMultiplicationMutant1() {
                                     // Test case where subtraction and multiplication would give different results
                                     double[] p1 = {1.0, 2.0};
                                     double[] p2 = {3.0, 4.0};
                                     
                                     // Expected calculation:
                                     // sqrt((1-3)² + (2-4)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                                     double expected = Math.sqrt(8.0);
                                     
                                     // Mutated calculation would be:
                                     // sqrt((1*3)² + (2*4)²) = sqrt(9 + 16) = sqrt(25) = 5.0
                                     // This is significantly different from expected
                                     
                                     double result = MathUtils.distance(p1, p2);
                                     
                                     // Using delta for floating point comparison
                                     assertEquals(expected, result, 0.0001);
                                     
                                     // Additional test case with zeros
                                     double[] p3 = {0.0, 0.0};
                                     double[] p4 = {1.0, 1.0};
                                     assertEquals(Math.sqrt(2.0), MathUtils.distance(p3, p4), 0.0001);
                                     
                                     // Test case with negative values
                                     double[] p5 = {-1.0, -2.0};
                                     double[] p6 = {1.0, 2.0};
                                     assertEquals(Math.sqrt(8.0), MathUtils.distance(p5, p6), 0.0001);
                                 }

 @Test
                                public void testDistanceDetectsMutant2() {
                                    // Test case where p1 and p2 have different values
                                    double[] p1 = {1.0, 2.0, 3.0};
                                    double[] p2 = {4.0, 5.0, 6.0};
                                    
                                    // Calculate expected distance manually
                                    double expected = Math.sqrt(
                                        (1.0-4.0)*(1.0-4.0) + 
                                        (2.0-5.0)*(2.0-5.0) + 
                                        (3.0-6.0)*(3.0-6.0)
                                    );
                                    
                                    // The mutant would return sqrt(1*1 + 2*2 + 3*3) = sqrt(14) ≈ 3.7417
                                    // Instead of the correct sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.1962
                                    double actual = MathUtils.distance(p1, p2);
                                    
                                    assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                    
                                    // Additional test case with negative values
                                    double[] p3 = {-1.0, -2.0};
                                    double[] p4 = {1.0, 2.0};
                                    expected = Math.sqrt(
                                        (-1.0-1.0)*(-1.0-1.0) + 
                                        (-2.0-2.0)*(-2.0-2.0)
                                    );
                                    actual = MathUtils.distance(p3, p4);
                                    assertEquals("Distance calculation with negative values is incorrect", 
                                                expected, actual, 0.0001);
                                }

 @Test
                                public void testDistanceDetectsMutant3() {
                                    // Test case where p1 and p2 are different
                                    double[] p1 = {1.0, 2.0, 3.0};
                                    double[] p2 = {4.0, 5.0, 6.0};
                                    
                                    // Calculate expected distance manually
                                    double expectedDistance = Math.sqrt(
                                        Math.pow(1.0-4.0, 2) + 
                                        Math.pow(2.0-5.0, 2) + 
                                        Math.pow(3.0-6.0, 2)
                                    );
                                    
                                    // The mutant would calculate distance as if p2 was all zeros
                                    double mutantDistance = Math.sqrt(
                                        Math.pow(1.0, 2) + 
                                        Math.pow(2.0, 2) + 
                                        Math.pow(3.0, 2)
                                    );
                                    
                                    // Verify the actual distance matches expected
                                    double actualDistance = MathUtils.distance(p1, p2);
                                    assertEquals(expectedDistance, actualDistance, 0.0001);
                                    
                                    // This assertion would fail with the mutant
                                    assertNotEquals(mutantDistance, actualDistance, 0.0001);
                                    
                                    // Additional test case where p1 = p2 should give 0 distance
                                    double[] p3 = {1.0, 2.0, 3.0};
                                    assertEquals(0.0, MathUtils.distance(p3, p3), 0.0001);
                                }

 @Test
                               public void testDistanceDetectsSquaredDifferenceMutation() {
                                   // Test case that will reveal the mutation
                                   double[] p1 = {2.0, 3.0};  // Point (2,3)
                                   double[] p2 = {4.0, 6.0};  // Point (4,6)
                                   
                                   // Calculate expected value manually
                                   // Original correct calculation: sqrt((2-4)² + (3-6)²) = sqrt(4 + 9) = sqrt(13) ≈ 3.605551275463989
                                   // Mutated calculation: sqrt((2-4) + (3-6)) = sqrt(-2 + -3) = sqrt(-5) = NaN (or would fail earlier)
                                   
                                   double expected = Math.sqrt(13.0); // ≈ 3.605551275463989
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   // The mutated version would either:
                                   // 1. Return NaN (if negative sum reaches sqrt)
                                   // 2. Return completely wrong value (if sum is positive but different)
                                   assertEquals("Distance calculation incorrect - mutant not detected", 
                                               expected, actual, 1e-10);
                                   
                                   // Additional test case with positive differences
                                   double[] p3 = {1.0, 1.0};
                                   double[] p4 = {3.0, 2.0};
                                   // Expected: sqrt((1-3)² + (1-2)²) = sqrt(4 + 1) = sqrt(5) ≈ 2.23606797749979
                                   assertEquals("Distance calculation incorrect - mutant not detected",
                                               Math.sqrt(5.0), MathUtils.distance(p3, p4), 1e-10);
                               }

 @Test
                           public void testDistanceShouldCalculateEuclideanDistance3() {
                               // Test with simple 2D points where the difference is obvious
                               double[] p1 = {1.0, 2.0};
                               double[] p2 = {4.0, 6.0};
                               
                               // Calculate expected Euclidean distance manually:
                               // sqrt((4-1)^2 + (6-2)^2) = sqrt(9 + 16) = sqrt(25) = 5.0
                               double expected = 5.0;
                               
                               // Call the method
                               double actual = MathUtils.distance(p1, p2);
                               
                               // Verify the result matches expected Euclidean distance
                               assertEquals(expected, actual, 0.0001);
                               
                               // This test will catch the mutant because:
                               // Original code: sqrt( (3)^2 + (4)^2 ) = 5.0
                               // Mutant code: sqrt(3 + 4) = sqrt(7) ≈ 2.6458 ≠ 5.0
                           }

 @Test
                              public void testDistanceShouldCalculateCorrectEuclideanDistance2() {
                                  // Test with known values where distance is easy to verify
                                  double[] p1 = {0.0, 0.0};
                                  double[] p2 = {3.0, 4.0};
                                  
                                  // Expected distance is 5.0 (3-4-5 triangle)
                                  double expected = 5.0;
                                  double actual = MathUtils.distance(p1, p2);
                                  
                                  // First check it's not NaN (which mutant would produce)
                                  assertFalse("Distance should not be NaN", Double.isNaN(actual));
                                  
                                  // Then verify exact value with delta for floating point precision
                                  assertEquals("Distance calculation is incorrect", 
                                              expected, actual, 0.0001);
                                  
                                  // Additional test case with identical points
                                  double[] p3 = {1.0, 2.0};
                                  assertEquals("Distance between identical points should be 0",
                                              0.0, MathUtils.distance(p3, p3), 0.0);
                              }

 @Test
                              public void testDistanceShouldCalculateCorrectEuclideanDistance3() {
                                  // Test case that will catch the sum -= dp*dp mutant
                                  double[] p1 = {1.0, 2.0, 3.0};
                                  double[] p2 = {4.0, 5.0, 6.0};
                                  
                                  // Calculate expected distance manually
                                  double expectedSum = 0;
                                  for (int i = 0; i < p1.length; i++) {
                                      double dp = p1[i] - p2[i];
                                      expectedSum += dp * dp;
                                  }
                                  double expectedDistance = Math.sqrt(expectedSum);
                                  
                                  // Call the method and get actual result
                                  double actualDistance = MathUtils.distance(p1, p2);
                                  
                                  // Verify the result is positive and matches expected value
                                  assertTrue("Distance should be positive", actualDistance >= 0);
                                  assertEquals("Distance calculation is incorrect", 
                                              expectedDistance, actualDistance, 0.0001);
                                  
                                  // Additional test with identical points (distance should be 0)
                                  double[] p3 = {1.0, 1.0};
                                  double[] p4 = {1.0, 1.0};
                                  assertEquals("Distance between identical points should be 0",
                                              0.0, MathUtils.distance(p3, p4), 0.0001);
                                  
                                  // Test with simple 1D case
                                  double[] p5 = {5.0};
                                  double[] p6 = {2.0};
                                  assertEquals("Simple 1D distance incorrect",
                                              3.0, MathUtils.distance(p5, p6), 0.0001);
                              }

 @Test
                             public void testDistanceWithMultipleDimensions1() {
                                 // Arrange
                                 double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
                                 double[] p2 = {4.0, 5.0, 6.0}; // 3-dimensional point
                                 
                                 // Expected calculation:
                                 // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                 // sqrt(27) ≈ 5.196152422706632
                                 double expected = 5.196152422706632;
                                 
                                 // Act
                                 double actual = MathUtils.distance(p1, p2);
                                 
                                 // Assert
                                 assertEquals("Distance calculation incorrect for multi-dimensional points", 
                                             expected, actual, 1e-10);
                             }

 @Test
                             public void testDistanceMultiDimensional() {
                                 // Test with 3-dimensional points where each dimension contributes to distance
                                 double[] p1 = {1.0, 2.0, 3.0};
                                 double[] p2 = {4.0, 5.0, 6.0};
                                 
                                 // Calculate expected distance manually:
                                 // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                 double expected = Math.sqrt(27.0);
                                 double actual = MathUtils.distance(p1, p2);
                                 
                                 // The mutant would only calculate (6-3)^2 = 9 and return sqrt(9) = 3
                                 // So this test would fail with the mutant (3 vs 5.196152)
                                 assertEquals("Distance should consider all dimensions", expected, actual, 1e-10);
                             }

 @Test
                             public void testDistanceSingleDimensional() {
                                 // This test case wouldn't catch the mutant since there's only one dimension
                                 // Included for completeness but not sufficient to catch this mutation
                                 double[] p1 = {1.0};
                                 double[] p2 = {4.0};
                                 
                                 double expected = 3.0; // sqrt((4-1)^2) = 3
                                 double actual = MathUtils.distance(p1, p2);
                                 
                                 assertEquals(expected, actual, 1e-10);
                             }

 @Test
                             public void testDistanceWithZeroDifference() {
                                 // Test case where all dimensions have zero difference
                                 double[] p1 = {1.5, 2.5, 3.5};
                                 double[] p2 = {1.5, 2.5, 3.5};
                                 
                                 double expected = 0.0;
                                 double actual = MathUtils.distance(p1, p2);
                                 
                                 assertEquals(expected, actual, 1e-10);
                             }

 @Test
                        public void testDistanceShouldDetectDivisionMutant() {
                            // Test case where dp is not 1.0 to expose the mutant
                            double[] p1 = {1.0, 2.0, 3.0};
                            double[] p2 = {4.0, 5.0, 6.0};
                            
                            // Calculate expected distance manually
                            double expectedSum = 0.0;
                            for (int i = 0; i < p1.length; i++) {
                                final double dp = p1[i] - p2[i];
                                expectedSum += dp * dp;
                            }
                            double expectedDistance = Math.sqrt(expectedSum);
                            
                            // Mutant would calculate sum as 1.0+1.0+1.0=3.0 instead of 9+9+9=27
                            // So mutant would return sqrt(3.0) ≈ 1.732 instead of sqrt(27) ≈ 5.196
                            
                            double actualDistance = MathUtils.distance(p1, p2);
                            
                            assertEquals("Distance calculation is incorrect", 
                                        expectedDistance, 
                                        actualDistance, 
                                        0.0001); // delta for double comparison
                            
                            // Additional test case with zero difference to catch potential division by zero
                            double[] p3 = {1.0, 1.0};
                            double[] p4 = {1.0, 1.0};
                            assertEquals("Zero distance case failed", 
                                        0.0, 
                                        MathUtils.distance(p3, p4), 
                                        0.0001);
                        }

 @Test
                            public void testDistanceDetectsDivisionMutant1() {
                                // Test case that will catch the sum += dp/dp mutant
                                double[] p1 = {1.0, 2.0, 3.0};
                                double[] p2 = {4.0, 5.0, 6.0};
                                
                                // Calculate expected value manually
                                double expectedSum = 0;
                                for (int i = 0; i < p1.length; i++) {
                                    double dp = p1[i] - p2[i];
                                    expectedSum += dp * dp;
                                }
                                double expected = Math.sqrt(expectedSum);
                                
                                // The mutant would calculate sum as:
                                // (1.0-4.0)/(1.0-4.0) + (2.0-5.0)/(2.0-5.0) + (3.0-6.0)/(3.0-6.0) = 1 + 1 + 1 = 3
                                // Then sqrt(3) ≈ 1.732...
                                // So we verify the actual distance is not √3
                                double actual = MathUtils.distance(p1, p2);
                                assertNotEquals("Mutant not detected - division instead of multiplication", 
                                               Math.sqrt(p1.length), actual, 0.0001);
                                assertEquals("Distance calculation incorrect", 
                                            expected, actual, 0.0001);
                            }

 @Test(expected = ArithmeticException.class)
                            public void testDistanceWithZeroDifferenceCausesDivisionByZeroInMutant() {
                                // This would throw ArithmeticException in mutant but work fine in original
                                double[] p1 = {1.0, 1.0};
                                double[] p2 = {1.0, 1.0};
                                
                                // Original should return 0, mutant would try to do 0/0
                                double actual = MathUtils.distance(p1, p2);
                                assertEquals(0.0, actual, 0.0001);
                            }

 @Test
                           public void testDistanceReturnsEuclideanDistanceNotSumOfSquares() {
                               // Simple 2D case where differences are 3 and 4
                               double[] p1 = {0, 0};
                               double[] p2 = {3, 4};
                               
                               // Sum of squares would be 3² + 4² = 9 + 16 = 25
                               double sumOfSquares = 25.0;
                               
                               // Euclidean distance would be √25 = 5
                               double expectedDistance = 5.0;
                               
                               // Call the method
                               double actual = MathUtils.distance(p1, p2);
                               
                               // Verify it returns the Euclidean distance, not the sum of squares
                               assertEquals("Method should return Euclidean distance, not sum of squares", 
                                           expectedDistance, actual, 0.0001);
                               
                               // Explicitly verify it's not returning the sum of squares
                               assertNotEquals("Method should not return sum of squares", 
                                              sumOfSquares, actual, 0.0001);
                           }

 @Test
                           public void testDistanceWithAnotherSimpleCase() {
                               // 3D case with differences 1, 1, 1
                               double[] p1 = {0, 0, 0};
                               double[] p2 = {1, 1, 1};
                               
                               // Sum of squares would be 1 + 1 + 1 = 3
                               double sumOfSquares = 3.0;
                               
                               // Euclidean distance would be √3 ≈ 1.73205
                               double expectedDistance = Math.sqrt(3.0);
                               
                               // Call the method
                               double actual = MathUtils.distance(p1, p2);
                               
                               // Verify it returns the Euclidean distance
                               assertEquals(expectedDistance, actual, 0.0001);
                               
                               // Verify it's not returning the sum of squares
                               assertNotEquals(sumOfSquares, actual, 0.0001);
                           }

 @Test
                           public void testDistanceShouldReturnSquareRootOfSumOfSquares() {
                               // Test case that will catch the mutant returning sum instead of sqrt(sum)
                               double[] p1 = {3.0, 4.0};  // 3-0=3, 4-0=4
                               double[] p2 = {0.0, 0.0};  // sum of squares = 9 + 16 = 25
                               
                               // The correct distance should be sqrt(25) = 5
                               // The mutant would return 25 instead
                               double expectedDistance = 5.0;
                               double actualDistance = MathUtils.distance(p1, p2);
                               
                               assertEquals("Distance should be square root of sum of squares", 
                                           expectedDistance, actualDistance, 0.0001);
                               
                               // Additional test case with non-integer result
                               double[] p3 = {1.0, 1.0};
                               double[] p4 = {0.0, 0.0};
                               double expectedDistance2 = Math.sqrt(2); // ~1.4142
                               double actualDistance2 = MathUtils.distance(p3, p4);
                               
                               assertEquals("Distance should be square root of sum of squares", 
                                           expectedDistance2, actualDistance2, 0.0001);
                           }

 @Test
                          public void testDistance() {
                              // Test case 1: Simple known distance
                              double[] p1 = {0.0, 0.0};
                              double[] p2 = {3.0, 4.0};
                              double expected = 5.0; // sqrt(3² + 4²) = 5
                              double actual = MathUtils.distance(p1, p2);
                              assertEquals("Distance should be 5.0 for points (0,0) and (3,4)", expected, actual, 0.0001);
                              
                              // Test case 2: Zero distance
                              double[] p3 = {1.5, 2.5};
                              double[] p4 = {1.5, 2.5};
                              assertEquals("Distance should be 0 for identical points", 
                                          0.0, MathUtils.distance(p3, p4), 0.0001);
                              
                              // Test case 3: 1D distance
                              double[] p5 = {5.0};
                              double[] p6 = {2.0};
                              assertEquals("Distance should be 3.0 for single dimension points", 
                                          3.0, MathUtils.distance(p5, p6), 0.0001);
                              
                              // Test case 4: Negative coordinates
                              double[] p7 = {-1.0, -1.0};
                              double[] p8 = {2.0, 3.0};
                              expected = 5.0; // sqrt(3² + 4²) = 5
                              assertEquals("Distance should handle negative coordinates", 
                                          expected, MathUtils.distance(p7, p8), 0.0001);
                          }

 @Test
                          public void testDistanceShouldReturnCorrectEuclideanDistance1() {
                              // Simple case where we can calculate the expected result manually
                              double[] p1 = {0.0, 0.0};
                              double[] p2 = {3.0, 4.0};
                              
                              // Expected: sqrt((3-0)² + (4-0)²) = sqrt(9 + 16) = sqrt(25) = 5.0
                              double expected = 5.0;
                              double actual = MathUtils.distance(p1, p2);
                              
                              // This will catch the mutant because:
                              // Original: returns 5.0 (correct)
                              // Mutated: returns (3² + 4²)² = (9 + 16)² = 25² = 625.0 (wrong)
                              assertEquals("Distance calculation should return correct Euclidean distance", 
                                          expected, actual, 0.0001);
                              
                              // Additional test case with different values
                              double[] p3 = {1.0, 2.0, 3.0};
                              double[] p4 = {4.0, 5.0, 6.0};
                              
                              // Expected: sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                              expected = 5.196152;
                              actual = MathUtils.distance(p3, p4);
                              
                              assertEquals("Distance calculation should work for 3D points",
                                          expected, actual, 0.0001);
                          }

 @Test
                         public void testDistanceShouldReturnCorrectEuclideanDistance2() {
                             // Test case 1: Simple 2D points
                             double[] p1 = {0.0, 0.0};
                             double[] p2 = {3.0, 4.0};
                             double expected = 5.0; // sqrt(3² + 4²) = 5
                             double actual = MathUtils.distance(p1, p2);
                             assertEquals("Distance between (0,0) and (3,4) should be 5", expected, actual, 0.0001);
                             
                             // Test case 2: Identical points (distance should be 0)
                             double[] p3 = {1.0, 2.0, 3.0};
                             double[] p4 = {1.0, 2.0, 3.0};
                             assertEquals("Distance between identical points should be 0", 
                                          0.0, MathUtils.distance(p3, p4), 0.0001);
                             
                             // Test case 3: Points with negative coordinates
                             double[] p5 = {-1.0, -1.0};
                             double[] p6 = {2.0, 3.0};
                             expected = 5.0; // sqrt(3² + 4²) = 5
                             actual = MathUtils.distance(p5, p6);
                             assertEquals("Distance between (-1,-1) and (2,3) should be 5", expected, actual, 0.0001);
                             
                             // Test case 4: 1D points
                             double[] p7 = {5.0};
                             double[] p8 = {9.0};
                             expected = 4.0; // sqrt(4²) = 4
                             actual = MathUtils.distance(p7, p8);
                             assertEquals("Distance between [5] and [9] should be 4", expected, actual, 0.0001);
                         }

 @Test
                     public void testDistanceExactValue() {
                         // Test case where distance should be exactly 0
                         double[] p1 = {0.0, 0.0};
                         double[] p2 = {0.0, 0.0};
                         assertEquals(0.0, MathUtils.distance(p1, p2), 0.0);
                         
                         // Test case where distance should be exactly 1
                         double[] p3 = {0.0, 0.0};
                         double[] p4 = {1.0, 0.0};
                         assertEquals(1.0, MathUtils.distance(p3, p4), 0.0);
                         
                         // Test case with known exact distance (sqrt(2))
                         double[] p5 = {0.0, 0.0};
                         double[] p6 = {1.0, 1.0};
                         assertEquals(Math.sqrt(2.0), MathUtils.distance(p5, p6), 0.0);
                     }

 @Test
                    public void testDistanceShouldReturnPositiveValue1() {
                        // Test with simple 2D points where distance is easily calculable
                        double[] p1 = {0.0, 0.0};
                        double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                        
                        double result = MathUtils.distance(p1, p2);
                        
                        // Verify the distance is positive (should be 5.0)
                        assertTrue("Distance should be positive", result > 0);
                        assertEquals(5.0, result, 0.0001);
                        
                        // Test with identical points (distance should be 0)
                        double[] p3 = {1.0, 2.0, 3.0};
                        double result2 = MathUtils.distance(p3, p3);
                        assertEquals(0.0, result2, 0.0001);
                        
                        // Test with another simple case
                        double[] p4 = {1.0, 1.0};
                        double[] p5 = {4.0, 5.0}; // distance should be 5.0
                        double result3 = MathUtils.distance(p4, p5);
                        assertTrue("Distance should be positive", result3 > 0);
                        assertEquals(5.0, result3, 0.0001);
                    }

 @Test
                        public void testDistanceShouldReturnNonNegativeValue1() {
                            // Test case 1: Simple known distance
                            double[] p1 = {0.0, 0.0};
                            double[] p2 = {3.0, 4.0};
                            double distance = MathUtils.distance(p1, p2);
                            // The distance should be 5.0 (sqrt(3² + 4²)), and definitely positive
                            assertEquals(5.0, distance, 0.0001);
                            assertTrue("Distance should be positive", distance >= 0.0);
                            
                            // Test case 2: Zero distance case
                            double[] p3 = {1.5, 2.5};
                            double zeroDistance = MathUtils.distance(p3, p3);
                            assertEquals(0.0, zeroDistance, 0.0001);
                            assertTrue("Zero distance should be exactly 0", zeroDistance >= 0.0);
                            
                            // Test case 3: Random positive distance
                            double[] p4 = {1.0, 2.0, 3.0};
                            double[] p5 = {4.0, 5.0, 6.0};
                            double randomDistance = MathUtils.distance(p4, p5);
                            double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                            assertEquals(expected, randomDistance, 0.0001);
                            assertTrue("Random distance should be positive", randomDistance > 0.0);
                        }

 @Test
                       public void testDistanceShouldReturnCorrectEuclideanDistance3() {
                           // Test case 1: Distance between same points should be 0
                           double[] p1 = {0.0, 0.0};
                           double[] p2 = {0.0, 0.0};
                           assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                           
                           // Test case 2: Simple 2D case with known result
                           double[] p3 = {0.0, 0.0};
                           double[] p4 = {1.0, 1.0};
                           double expectedDistance = Math.sqrt(2); // √(1² + 1²) = √2 ≈ 1.4142
                           assertEquals(expectedDistance, MathUtils.distance(p3, p4), 0.0001);
                           
                           // Test case 3: 3D case with known result
                           double[] p5 = {0.0, 0.0, 0.0};
                           double[] p6 = {1.0, 1.0, 1.0};
                           double expectedDistance3D = Math.sqrt(3); // √(1² + 1² + 1²) = √3 ≈ 1.732
                           assertEquals(expectedDistance3D, MathUtils.distance(p5, p6), 0.0001);
                           
                           // Test case 4: Different values in each dimension
                           double[] p7 = {1.0, 2.0, 3.0};
                           double[] p8 = {4.0, 5.0, 6.0};
                           double expectedDistance4 = Math.sqrt(9 + 9 + 9); // √(3² + 3² + 3²) = √27 ≈ 5.196
                           assertEquals(expectedDistance4, MathUtils.distance(p7, p8), 0.0001);
                       }

 @Test
                   public void testDistanceShouldReturnCorrectEuclideanDistance4() {
                       // Arrange
                       double[] p1 = {0, 0};  // Origin point
                       double[] p2 = {3, 4};  // Point at (3,4)
                       
                       // Expected calculation:
                       // sum = (3-0)² + (4-0)² = 9 + 16 = 25
                       // distance = sqrt(25) = 5
                       double expectedDistance = 5.0;
                       
                       // Act
                       double actualDistance = MathUtils.distance(p1, p2);
                       
                       // Assert
                       assertEquals("Distance between (0,0) and (3,4) should be exactly 5", 
                                   expectedDistance, 
                                   actualDistance, 
                                   0.000001);  // Using delta for floating point comparison
                       
                       // This test will fail if the mutant is present because:
                       // Mutant would calculate sqrt(25/2) ≈ 3.5355 instead of 5
                   }

 @Test
                      public void testDistanceWithZeroDistanceShouldReturnZero() {
                          // Arrange
                          double[] p1 = {0.0, 0.0, 0.0};
                          double[] p2 = {0.0, 0.0, 0.0};
                          
                          // Act & Assert
                          assertEquals(0.0, MathUtils.distance(p1, p2), 0.0);
                      }

 @Test
                      public void testDistanceWithSmallDistanceShouldReturnExactValue() {
                          // Arrange
                          double[] p1 = {0.0, 0.0};
                          double[] p2 = {1.0, 0.0};
                          
                          // Act & Assert
                          // Expected: sqrt(1^2 + 0^2) = 1.0
                          // Mutant would return: sqrt(1 + 1^2 + 0^2) = sqrt(2) ≈ 1.414
                          assertEquals(1.0, MathUtils.distance(p1, p2), 0.0);
                      }

 @Test
                      public void testDistanceWithMultipleDimensions2() {
                          // Arrange
                          double[] p1 = {1.0, 2.0, 3.0};
                          double[] p2 = {4.0, 5.0, 6.0};
                          
                          // Calculate expected value
                          double expectedSum = 0.0;
                          for (int i = 0; i < p1.length; i++) {
                              double diff = p1[i] - p2[i];
                              expectedSum += diff * diff;
                          }
                          double expectedDistance = Math.sqrt(expectedSum);
                          
                          // Act & Assert
                          assertEquals(expectedDistance, MathUtils.distance(p1, p2), 0.0);
                      }

 @Test
                      public void testDistanceWithZeroLengthVectors3() {
                          // Test with zero-length arrays (edge case)
                          double[] empty1 = new double[0];
                          double[] empty2 = new double[0];
                          assertEquals(0.0, MathUtils.distance(empty1, empty2), 0.0);
                      }

 @Test
                      public void testDistanceWithIdenticalPoints1() {
                          // Test with identical points - should be 0 distance
                          double[] point1 = {1.0, 2.0, 3.0};
                          double[] point2 = {1.0, 2.0, 3.0};
                          assertEquals(0.0, MathUtils.distance(point1, point2), 0.0);
                      }

 @Test
                      public void testDistanceWithDifferentPoints() {
                          // Test with different points to verify calculation
                          double[] point1 = {0.0, 0.0};
                          double[] point2 = {3.0, 4.0}; // 3-4-5 triangle
                          assertEquals(5.0, MathUtils.distance(point1, point2), 0.0);
                          
                          // Test with small values
                          double[] point3 = {0.001, 0.001};
                          double[] point4 = {0.002, 0.002};
                          double expected = Math.sqrt(0.001*0.001 + 0.001*0.001);
                          assertEquals(expected, MathUtils.distance(point3, point4), 1e-10);
                      }

 @Test
                     public void testDistanceWithFractionalValues() {
                         // Test with values that have fractional parts
                         double[] p1 = {1.1, 2.2, 3.3};
                         double[] p2 = {4.4, 5.5, 6.6};
                         
                         // Calculate expected value manually
                         double expected = 0.0;
                         for (int i = 0; i < p1.length; i++) {
                             double diff = p1[i] - p2[i];
                             expected += diff * diff;
                         }
                         expected = Math.sqrt(expected);
                         
                         // The mutant using int sum will produce a different result
                         double actual = MathUtils.distance(p1, p2);
                         
                         // Verify with delta for floating point precision
                         assertEquals("Distance calculation should handle fractional values precisely", 
                                     expected, actual, 0.0001);
                     }

 @Test
                     public void testDistanceWithLargeValues1() {
                         // Test with values that would cause integer overflow if summed as int
                         double[] p1 = {100000.1, 200000.2, 300000.3};
                         double[] p2 = {400000.4, 500000.5, 600000.6};
                         
                         // Calculate expected value manually
                         double expected = 0.0;
                         for (int i = 0; i < p1.length; i++) {
                             double diff = p1[i] - p2[i];
                             expected += diff * diff;
                         }
                         expected = Math.sqrt(expected);
                         
                         // The mutant using int sum would overflow and produce wrong result
                         double actual = MathUtils.distance(p1, p2);
                         
                         assertEquals("Distance calculation should handle large values without overflow", 
                                     expected, actual, 0.0001);
                     }

 @Test
                     public void testDistanceWithSmallDifferences2() {
                         // Create points with small differences that will produce fractional squared differences
                         double[] p1 = {0.1, 0.2, 0.3};
                         double[] p2 = {0.4, 0.5, 0.6};
                         
                         // Calculate expected distance manually
                         double expected = Math.sqrt(
                             Math.pow(0.1-0.4, 2) + 
                             Math.pow(0.2-0.5, 2) + 
                             Math.pow(0.3-0.6, 2)
                         );
                         
                         // Call the method and assert
                         double actual = MathUtils.distance(p1, p2);
                         
                         // The mutated version would return 0 because all squared differences are <1 and would be truncated
                         assertNotEquals(0.0, actual, 0.0001); // This will fail for the mutant
                         assertEquals(expected, actual, 0.0001); // Verify correct calculation
                     }

 @Test
                     public void testDistanceWithVerySmallDifferences() {
                         // Test with extremely small differences that would definitely be truncated to 0 as int
                         double[] p1 = {0.0001, 0.0002, 0.0003};
                         double[] p2 = {0.0004, 0.0005, 0.0006};
                         
                         // The original should return a small but non-zero value
                         double actual = MathUtils.distance(p1, p2);
                         
                         // The mutant would return 0.0 here
                         assertTrue("Distance should be greater than 0", actual > 0.0);
                     }

 @Test
                    public void testDistanceWithArrayBounds() {
                        // Test normal case first to verify basic functionality
                        double[] p1 = {1.0, 2.0, 3.0};
                        double[] p2 = {4.0, 5.0, 6.0};
                        double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                        assertEquals(expected, MathUtils.distance(p1, p2), 0.0001);
                        
                        // Now test with empty arrays (should return 0)
                        double[] empty1 = {};
                        double[] empty2 = {};
                        assertEquals(0.0, MathUtils.distance(empty1, empty2), 0.0);
                        
                        // Test with single element arrays
                        double[] single1 = {5.0};
                        double[] single2 = {8.0};
                        assertEquals(3.0, MathUtils.distance(single1, single2), 0.0);
                        
                        // The key test that would catch the mutant
                        // For arrays of length n, the mutated version would try to access index n
                        // which should throw ArrayIndexOutOfBoundsException
                        try {
                            MathUtils.distance(p1, p2); // This should not throw for original
                            // If we get here, original version is working
                            // Now force the out of bounds case
                            double[] p3 = {1.0};
                            double[] p4 = {2.0};
                            MathUtils.distance(p3, p4); // Should only do one iteration
                            // If we get here, test passes (mutant would have thrown)
                        } catch (ArrayIndexOutOfBoundsException e) {
                            fail("Method threw ArrayIndexOutOfBoundsException indicating the mutant was present");
                        }
                    }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                    public void testDistanceWithMutatedLoopCondition2() {
                        // Arrange
                        double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                        double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                        
                        // Act - this should throw ArrayIndexOutOfBoundsException for the mutant
                        // but work fine for original
                        double result = MathUtils.distance(p1, p2);
                        
                        // Assert - if we get here, the test fails (mutant not caught)
                        // We include this assertion to verify the original behavior works
                        assertEquals(Math.sqrt(9+9+9), result, 0.0001);
                    }

 @Test
                    public void testDistanceWithEmptyArrays1() {
                        // Arrange
                        double[] p1 = {};  // empty array
                        double[] p2 = {};  // empty array
                        
                        // Act
                        double result = MathUtils.distance(p1, p2);
                        
                        // Assert - should be 0 for empty arrays
                        assertEquals(0.0, result, 0.0001);
                    }

 @Test
                   public void testDistanceShouldCalculateCorrectlyForSingleDimension() {
                       // Arrange
                       double[] p1 = {3.0};
                       double[] p2 = {7.0};
                       
                       // Act
                       double result = MathUtils.distance(p1, p2);
                       
                       // Assert
                       assertEquals(4.0, result, 0.0001); // Expected distance is 4.0 (7-3)
                       // Mutant would return 0.0 (skips the only element)
                   }

 @Test
                   public void testDistanceShouldIncludeFirstElementInCalculation1() {
                       // Arrange
                       double[] p1 = {1.0, 0.0, 0.0, 0.0}; // All difference in first element
                       double[] p2 = {5.0, 0.0, 0.0, 0.0};
                       
                       // Act
                       double result = MathUtils.distance(p1, p2);
                       
                       // Assert
                       assertEquals(4.0, result, 0.0001); // Expected distance is 4.0 (sqrt(16))
                       // Mutant would return 0.0 (skips the only differing element)
                   }

 @Test
                   public void testDistanceShouldCalculateAllDimensions() {
                       // Arrange
                       double[] p1 = {1.0, 2.0, 3.0};
                       double[] p2 = {4.0, 5.0, 6.0};
                       
                       // Act
                       double result = MathUtils.distance(p1, p2);
                       
                       // Assert
                       // Expected distance is sqrt(9+9+9) = sqrt(27) ≈ 5.196
                       assertEquals(5.196152, result, 0.0001);
                       // Mutant would return sqrt(9+9) ≈ 4.2426 (skips first dimension)
                   }

 @Test
               public void testDistanceShouldIncludeFirstElement3() {
                   // Test case where first elements are different
                   double[] p1 = {5.0, 2.0, 3.0};
                   double[] p2 = {1.0, 2.0, 3.0};
                   
                   // Calculate expected distance manually
                   double expected = Math.sqrt((5.0-1.0)*(5.0-1.0) + (2.0-2.0)*(2.0-2.0) + (3.0-3.0)*(3.0-3.0));
                   
                   // The mutant would skip first element, calculating sqrt(0 + 0) = 0
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals("Distance calculation should include first element", expected, actual, 0.0001);
               }

 @Test
               public void testDistanceWithSingleElementArrays1() {
                   // Test case with single-element arrays
                   double[] p1 = {5.0};
                   double[] p2 = {1.0};
                   
                   // Expected distance
                   double expected = 4.0; // sqrt((5-1)^2) = 4
                   
                   // Mutant would skip the only element, returning sqrt(0) = 0
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals("Distance calculation should work with single-element arrays", 
                               expected, actual, 0.0001);
               }

 @Test
               public void testDistanceWhereOnlyFirstElementsDiffer() {
                   // Test case where only first elements differ
                   double[] p1 = {5.0, 2.0, 2.0, 2.0};
                   double[] p2 = {1.0, 2.0, 2.0, 2.0};
                   
                   // Expected distance is just from first element difference
                   double expected = 4.0; // sqrt((5-1)^2) = 4
                   
                   // Mutant would return 0 since it skips the only differing element
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals("Distance should reflect difference in first elements", 
                               expected, actual, 0.0001);
               }

 @Test
                  public void testDistanceShouldIncludeAllDimensions() {
                      // Create test points with 3 dimensions
                      double[] p1 = {1.0, 2.0, 3.0};
                      double[] p2 = {4.0, 5.0, 6.0};
                      
                      // Calculate expected distance manually
                      double expected = Math.sqrt(
                          Math.pow(1.0-4.0, 2) + 
                          Math.pow(2.0-5.0, 2) + 
                          Math.pow(3.0-6.0, 2)
                      );
                      
                      // Call the method and assert
                      double actual = MathUtils.distance(p1, p2);
                      assertEquals("Distance should include all dimensions", expected, actual, 0.0001);
                      
                      // Additional test with different values to be thorough
                      double[] p3 = {0.0, 0.0, 0.0, 1.0}; // 4 dimensions
                      double[] p4 = {0.0, 0.0, 0.0, 2.0};
                      expected = Math.sqrt(Math.pow(0.0-0.0, 2)*3 + Math.pow(1.0-2.0, 2));
                      actual = MathUtils.distance(p3, p4);
                      assertEquals("Distance should include last dimension", expected, actual, 0.0001);
                  }

 @Test
                  public void testDistanceShouldProcessAllElements1() {
                      // Test with single element arrays - mutant will skip the only element
                      double[] p1 = {3.0};
                      double[] p2 = {7.0};
                      double expected = 4.0; // sqrt((3-7)^2) = 4
                      double actual = MathUtils.distance(p1, p2);
                      assertEquals("Distance calculation should include all elements", expected, actual, 0.0001);
                      
                      // Test with multiple elements where last element is significant
                      double[] p3 = {1.0, 2.0, 3.0, 4.0};
                      double[] p4 = {1.0, 2.0, 3.0, 8.0}; // Only last element differs
                      expected = 4.0; // sqrt((4-8)^2) = 4
                      actual = MathUtils.distance(p3, p4);
                      assertEquals("Distance calculation should include last element", expected, actual, 0.0001);
                      
                      // Test with all elements contributing
                      double[] p5 = {1.0, 2.0, 3.0};
                      double[] p6 = {4.0, 5.0, 6.0};
                      expected = 5.196152; // sqrt((1-4)^2 + (2-5)^2 + (3-6)^2) ≈ 5.196152
                      actual = MathUtils.distance(p5, p6);
                      assertEquals("Distance calculation should include all elements", expected, actual, 0.0001);
                  }

 @Test
             public void testDistanceShouldCalculateEuclideanDistance4() {
                 // Test case 1: Simple 1D case where difference and sum produce different results
                 double[] point1 = {3.0};
                 double[] point2 = {1.0};
                 double expectedDistance = 2.0; // sqrt((3-1)^2) = 2
                 double actualDistance = MathUtils.distance(point1, point2);
                 assertEquals("Distance calculation is incorrect", expectedDistance, actualDistance, 0.0001);
             
                 // Test case 2: 2D case with opposite signs to amplify the difference
                 double[] point3 = {1.0, -2.0};
                 double[] point4 = {-1.0, 2.0};
                 expectedDistance = Math.sqrt(4.0 + 16.0); // sqrt((1-(-1))^2 + (-2-2)^2) = sqrt(4 + 16) ≈ 4.472
                 actualDistance = MathUtils.distance(point3, point4);
                 assertEquals("Distance calculation with opposite signs is incorrect", 
                             expectedDistance, actualDistance, 0.0001);
             
                 // Test case 3: Equal points should return 0 distance
                 double[] point5 = {5.0, 5.0};
                 double[] point6 = {5.0, 5.0};
                 assertEquals("Distance between equal points should be 0", 
                             0.0, MathUtils.distance(point5, point6), 0.0001);
             
                 // Test case 4: Different values but same sum (would pass if using sum instead of difference)
                 double[] point7 = {4.0, 3.0};
                 double[] point8 = {1.0, 6.0};
                 expectedDistance = Math.sqrt(9.0 + 9.0); // sqrt((4-1)^2 + (3-6)^2) = sqrt(9 + 9) ≈ 4.242
                 actualDistance = MathUtils.distance(point7, point8);
                 assertEquals("Distance calculation should use difference not sum", 
                             expectedDistance, actualDistance, 0.0001);
             }

 @Test
                 public void testDistanceShouldCalculateCorrectEuclideanDistance4() {
                     // Test case that will catch the mutant
                     double[] p1 = {1.0, -2.0, 3.0};  // Mixed positive and negative values
                     double[] p2 = {-1.0, 2.0, -3.0}; // Opposite signs to maximize difference
                     
                     // Calculate expected value manually
                     double expected = Math.sqrt(
                         Math.pow(1.0 - (-1.0), 2) + 
                         Math.pow(-2.0 - 2.0, 2) + 
                         Math.pow(3.0 - (-3.0), 2)
                     );
                     
                     // Calculate what the mutant would produce
                     double mutantValue = Math.sqrt(
                         Math.pow(1.0 + (-1.0), 2) + 
                         Math.pow(-2.0 + 2.0, 2) + 
                         Math.pow(3.0 + (-3.0), 2)
                     );
                     
                     // Verify the actual result matches expected and doesn't match mutant
                     double actual = MathUtils.distance(p1, p2);
                     assertEquals(expected, actual, 0.0001);
                     assertNotEquals(mutantValue, actual, 0.0001);
                 }

 @Test
                 public void testDistanceWithAllPositiveValues() {
                     // Additional test case with all positive values
                     double[] p1 = {1.0, 2.0, 3.0};
                     double[] p2 = {4.0, 5.0, 6.0};
                     
                     double expected = Math.sqrt(
                         Math.pow(1.0 - 4.0, 2) + 
                         Math.pow(2.0 - 5.0, 2) + 
                         Math.pow(3.0 - 6.0, 2)
                     );
                     
                     assertEquals(expected, MathUtils.distance(p1, p2), 0.0001);
                 }

 @Test
                 public void testDistanceWithZeroVectors1() {
                     // Edge case with zero vectors
                     double[] p1 = {0.0, 0.0, 0.0};
                     double[] p2 = {0.0, 0.0, 0.0};
                     
                     assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                 }

 @Test
                 public void testDistanceWithSingleElementArrays2() {
                     // Test with minimal array size
                     double[] p1 = {5.0};
                     double[] p2 = {3.0};
                     
                     assertEquals(2.0, MathUtils.distance(p1, p2), 0.0001);
                 }

 @Test
                public void testDistanceDetectsSubtractionOrderMutant1() {
                    // Test case that will fail if the subtraction order is reversed
                    double[] p1 = {1.0, 2.0, 3.0};
                    double[] p2 = {4.0, 5.0, 6.0};
                    
                    // Calculate expected value manually
                    double expected = Math.sqrt(
                        Math.pow(1.0 - 4.0, 2) + 
                        Math.pow(2.0 - 5.0, 2) + 
                        Math.pow(3.0 - 6.0, 2)
                    );
                    
                    // If the mutant is present (p2[i] - p1[i]), the result would be the same
                    // because of squaring, so we need a more sophisticated test
                    
                    // Better test: use asymmetric values where the order matters for intermediate steps
                    double[] asymmetricP1 = {1.0, 0.0};
                    double[] asymmetricP2 = {0.0, 1.0};
                    
                    // Expected distance should be sqrt((1-0)² + (0-1)²) = sqrt(1 + 1) = sqrt(2)
                    double expectedAsymmetric = Math.sqrt(2);
                    double actual = MathUtils.distance(asymmetricP1, asymmetricP2);
                    
                    // This will catch the mutant because while the final distance is the same,
                    // the intermediate calculations would be different
                    assertEquals("Distance calculation should be correct", 
                        expectedAsymmetric, actual, 1e-10);
                    
                    // Additional verification with the first test case
                    double actualFirstCase = MathUtils.distance(p1, p2);
                    assertEquals("Distance calculation should be correct", 
                        expected, actualFirstCase, 1e-10);
                }

 @Test
                public void testDistance_shouldDetectSubtractionOrderMutant() {
                    // Arrange
                    double[] p1 = {1.0, 2.0, 3.0};
                    double[] p2 = {4.0, 5.0, 6.0};
                    
                    // Act - calculate expected value manually with correct subtraction order
                    double expectedSum = 0.0;
                    for (int i = 0; i < p1.length; i++) {
                        final double dp = p1[i] - p2[i];  // Correct order
                        expectedSum += dp * dp;
                    }
                    double expected = Math.sqrt(expectedSum);
                    
                    // Assert
                    double actual = MathUtils.distance(p1, p2);
                    assertEquals("Distance calculation should use p1[i]-p2[i] order", 
                                expected, actual, 0.0001);
                    
                    // Additional test with different values to ensure detection
                    double[] p3 = {0.0, -1.0};
                    double[] p4 = {1.0, 1.0};
                    
                    expectedSum = (0.0-1.0)*(0.0-1.0) + (-1.0-1.0)*(-1.0-1.0);
                    expected = Math.sqrt(expectedSum);
                    actual = MathUtils.distance(p3, p4);
                    assertEquals("Distance calculation should maintain subtraction order", 
                                expected, actual, 0.0001);
                }

 @Test
               public void testDistanceShouldCalculateEuclideanDistance5() {
                   // Test case that will catch the p1[i]-p2[i] -> p1[i]*p2[i] mutation
                   double[] point1 = {2.0, 3.0};
                   double[] point2 = {1.0, 1.0};
                   
                   // Original expected calculation:
                   // sqrt((2-1)^2 + (3-1)^2) = sqrt(1 + 4) = sqrt(5) ≈ 2.236
                   double expected = Math.sqrt(5.0);
                   
                   // Mutated calculation would be:
                   // sqrt((2*1)^2 + (3*1)^2) = sqrt(4 + 9) = sqrt(13) ≈ 3.606
                   // This is significantly different from expected
                   
                   double actual = MathUtils.distance(point1, point2);
                   
                   // Using delta of 0.0001 for floating point comparison
                   assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
               }

 @Test
               public void testDistanceWithNegativeValues1() {
                   // Another test case with negative values to catch the mutation
                   double[] point1 = {-1.0, 2.0};
                   double[] point2 = {3.0, -4.0};
                   
                   // Original expected:
                   // sqrt((-1-3)^2 + (2-(-4))^2) = sqrt(16 + 36) = sqrt(52) ≈ 7.211
                   double expected = Math.sqrt(52.0);
                   
                   // Mutated would be:
                   // sqrt((-1*3)^2 + (2*-4)^2) = sqrt(9 + 64) = sqrt(73) ≈ 8.544
                   double actual = MathUtils.distance(point1, point2);
                   
                   assertEquals("Distance with negative values incorrect", expected, actual, 0.0001);
               }

 @Test
               public void testDistanceWithZeroValues2() {
                   // Test case with zero values
                   double[] point1 = {0.0, 5.0};
                   double[] point2 = {0.0, 2.0};
                   
                   // Original expected:
                   // sqrt((0-0)^2 + (5-2)^2) = sqrt(0 + 9) = 3.0
                   double expected = 3.0;
                   
                   // Mutated would be:
                   // sqrt((0*0)^2 + (5*2)^2) = sqrt(0 + 100) = 10.0
                   double actual = MathUtils.distance(point1, point2);
                   
                   assertEquals("Distance with zero values incorrect", expected, actual, 0.0001);
               }

 @Test
               public void testDistanceShouldCalculateEuclideanDistance6() {
                   // Test case that will catch the multiplication mutant
                   double[] p1 = {1.0, 2.0, 3.0};
                   double[] p2 = {4.0, 5.0, 6.0};
                   
                   // Calculate expected value manually
                   double expected = Math.sqrt(
                       Math.pow(1.0-4.0, 2) + 
                       Math.pow(2.0-5.0, 2) + 
                       Math.pow(3.0-6.0, 2)
                   );
                   
                   // Calculate what the mutant would produce
                   double mutantValue = Math.sqrt(
                       Math.pow(1.0*4.0, 2) + 
                       Math.pow(2.0*5.0, 2) + 
                       Math.pow(3.0*6.0, 2)
                   );
                   
                   // Actual result from the method
                   double actual = MathUtils.distance(p1, p2);
                   
                   // Verify the actual result matches expected Euclidean distance
                   assertEquals(expected, actual, 0.0001);
                   
                   // Additional verification that we're not getting the mutant value
                   assertNotEquals(mutantValue, actual, 0.0001);
               }

 @Test
               public void testDistanceWithNegativeValues2() {
                   // Another test case with negative values to catch the mutant
                   double[] p1 = {-1.0, -2.0};
                   double[] p2 = {1.0, 2.0};
                   
                   double expected = Math.sqrt(
                       Math.pow(-1.0-1.0, 2) + 
                       Math.pow(-2.0-2.0, 2)
                   );
                   
                   double mutantValue = Math.sqrt(
                       Math.pow(-1.0*1.0, 2) + 
                       Math.pow(-2.0*2.0, 2)
                   );
                   
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals(expected, actual, 0.0001);
                   assertNotEquals(mutantValue, actual, 0.0001);
               }

 @Test
               public void testDistanceWithZeroValues3() {
                   // Test case with zero values
                   double[] p1 = {0.0, 0.0};
                   double[] p2 = {0.0, 0.0};
                   
                   double expected = 0.0;
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals(expected, actual, 0.0001);
               }

 @Test
          public void testDistanceShouldCalculateCorrectlyWithNonZeroPoints() {
              // Arrange
              double[] p1 = {1.0, 2.0, 3.0};
              double[] p2 = {4.0, 5.0, 6.0};
              
              // Expected distance calculation:
              // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
              double expectedDistance = Math.sqrt(27);
              
              // Act
              double actualDistance = MathUtils.distance(p1, p2);
              
              // Assert
              assertEquals("Distance between non-zero points should be calculated correctly", 
                          expectedDistance, actualDistance, 1e-10);
          }

 @Test
          public void testDistanceShouldBeNonZeroForDifferentPoints() {
              // Arrange
              double[] p1 = {1.0, 1.0};
              double[] p2 = {2.0, 2.0};
              
              // Act
              double actualDistance = MathUtils.distance(p1, p2);
              
              // Assert
              assertTrue("Distance between different points should be non-zero", 
                         actualDistance > 0);
          }

 @Test
          public void testDistanceShouldBeZeroForSamePoints() {
              // Arrange
              double[] p1 = {1.0, 2.0, 3.0};
              double[] p2 = {1.0, 2.0, 3.0};
              
              // Act
              double actualDistance = MathUtils.distance(p1, p2);
              
              // Assert
              assertEquals("Distance between identical points should be zero", 
                          0.0, actualDistance, 1e-10);
          }

 @Test
          public void testDistanceShouldHandleNegativeCoordinates() {
              // Arrange
              double[] p1 = {-1.0, -2.0};
              double[] p2 = {1.0, 2.0};
              
              // Expected distance calculation:
              // sqrt((-1-1)² + (-2-2)²) = sqrt(4 + 16) = sqrt(20) ≈ 4.472136
              double expectedDistance = Math.sqrt(20);
              
              // Act
              double actualDistance = MathUtils.distance(p1, p2);
              
              // Assert
              assertEquals("Distance should handle negative coordinates correctly", 
                          expectedDistance, actualDistance, 1e-10);
          }

 @Test
              public void testDistanceDetectsMutant4() {
                  // Test case where p1 and p2 are different
                  double[] p1 = {1.0, 2.0, 3.0};
                  double[] p2 = {4.0, 5.0, 6.0};
                  
                  // Expected distance calculation:
                  // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                  double expected = Math.sqrt(27);
                  double actual = MathUtils.distance(p1, p2);
                  
                  // This will fail with the mutant since mutant would calculate:
                  // sqrt(1² + 2² + 3²) = sqrt(1 + 4 + 9) = sqrt(14) ≈ 3.741657
                  assertEquals("Distance calculation should consider both points", 
                              expected, actual, 0.000001);
                  
                  // Additional test case with negative values
                  double[] p3 = {-1.0, -2.0};
                  double[] p4 = {1.0, 2.0};
                  
                  // Expected: sqrt((-1-1)² + (-2-2)²) = sqrt(4 + 16) = sqrt(20) ≈ 4.472136
                  expected = Math.sqrt(20);
                  actual = MathUtils.distance(p3, p4);
                  assertEquals("Distance should work with negative coordinates",
                              expected, actual, 0.000001);
              }

 @Test
             public void testDistanceDetectsSquaredDifferenceMutation1() {
                 // Test case where direct sum would differ from squared sum
                 double[] p1 = {1.0, 2.0, 3.0};
                 double[] p2 = {4.0, 5.0, 6.0};
                 
                 // Calculate expected Euclidean distance manually:
                 // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                 double expected = Math.sqrt(27.0);
                 
                 // If mutation exists (sum += dp instead of sum += dp*dp):
                 // sum would be (1-4)+(2-5)+(3-6) = -3 + -3 + -3 = -9
                 // sqrt would be NaN (sqrt of negative)
                 
                 double actual = MathUtils.distance(p1, p2);
                 
                 // Verify the result matches expected Euclidean distance
                 assertEquals(expected, actual, 1e-10);
                 
                 // Additional test case with different values
                 double[] p3 = {0.0, 0.0};
                 double[] p4 = {3.0, 4.0};
                 assertEquals(5.0, MathUtils.distance(p3, p4), 1e-10); // 3-4-5 triangle
             }

 @Test
             public void testDistanceShouldCalculateCorrectEuclideanDistance5() {
                 // Test case that will catch the sum += dp mutation
                 double[] p1 = {3.0, 4.0};  // Point (3,4)
                 double[] p2 = {0.0, 0.0};  // Origin (0,0)
                 
                 // Expected calculation:
                 // Original: sqrt((3-0)^2 + (4-0)^2) = sqrt(9 + 16) = sqrt(25) = 5.0
                 // Mutated: sqrt((3-0) + (4-0)) = sqrt(3 + 4) = sqrt(7) ≈ 2.64575
                 
                 double expected = 5.0;  // Correct Euclidean distance
                 double actual = MathUtils.distance(p1, p2);
                 
                 assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                 
                 // This will fail for the mutated version since:
                 // 5.0 != 2.64575 (approximately)
             }

 @Test
             public void testDistanceWithNegativeCoordinates1() {
                 // Another test case to ensure robustness
                 double[] p1 = {-1.0, -1.0};
                 double[] p2 = {2.0, 3.0};
                 
                 // Original: sqrt((-1-2)^2 + (-1-3)^2) = sqrt(9 + 16) = 5.0
                 // Mutated: sqrt((-3) + (-4)) = sqrt(-7) → would throw exception or give NaN
                 
                 double expected = 5.0;
                 double actual = MathUtils.distance(p1, p2);
                 
                 assertEquals("Distance with negative coordinates failed", expected, actual, 0.0001);
             }

 @Test
             public void testDistanceWithSingleDimension1() {
                 // Simple one-dimensional case
                 double[] p1 = {5.0};
                 double[] p2 = {2.0};
                 
                 // Original: sqrt((5-2)^2) = 3.0
                 // Mutated: sqrt(3) ≈ 1.73205
                 
                 double expected = 3.0;
                 double actual = MathUtils.distance(p1, p2);
                 
                 assertEquals("Single dimension distance failed", expected, actual, 0.0001);
             }

 @Test
        public void testDistanceShouldDetectSumSubtractionMutant() {
            // Test case that will catch the sum -= dp*dp mutant
            double[] p1 = {1.0, 2.0, 3.0};
            double[] p2 = {4.0, 5.0, 6.0};
            
            // Calculate expected distance manually:
            // diff1 = 1-4 = -3 → squared = 9
            // diff2 = 2-5 = -3 → squared = 9
            // diff3 = 3-6 = -3 → squared = 9
            // sum = 9+9+9 = 27
            // sqrt(27) ≈ 5.196152422706632
            double expectedDistance = 5.196152422706632;
            
            // Call the method
            double actualDistance = MathUtils.distance(p1, p2);
            
            // Assert the result matches expected
            assertEquals("Distance calculation is incorrect", 
                        expectedDistance, 
                        actualDistance, 
                        1e-10); // Using small delta for floating point comparison
            
            // Additional test with all zeros to catch potential negative results
            double[] zeros = {0.0, 0.0, 0.0};
            double zeroDistance = MathUtils.distance(zeros, zeros);
            assertEquals("Distance between identical points should be 0", 
                        0.0, 
                        zeroDistance, 
                        0.0); // Exact comparison for zero
        }

 @Test
            public void testDistanceWithNonZeroVectors1() {
                // Arrange
                double[] p1 = {1.0, 2.0, 3.0};
                double[] p2 = {4.0, 5.0, 6.0};
                
                // Expected calculation:
                // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                // sqrt(27) ≈ 5.196152422706632
                double expected = 5.196152422706632;
                
                // Act
                double actual = MathUtils.distance(p1, p2);
                
                // Assert
                // First check it's not NaN (which mutant would produce)
                assertFalse(Double.isNaN(actual));
                // Then verify the actual value with delta for floating point precision
                assertEquals(expected, actual, 1e-10);
            }

 @Test
            public void testDistanceWithSameVectors() {
                // Arrange
                double[] p1 = {1.0, 2.0, 3.0};
                double[] p2 = {1.0, 2.0, 3.0};
                
                // Expected distance between identical points is 0
                double expected = 0.0;
                
                // Act
                double actual = MathUtils.distance(p1, p2);
                
                // Assert
                assertEquals(expected, actual, 0.0);
            }

 @Test
           public void testDistanceWithMultipleDimensions3() {
               // Test with 3D points where the mutation would be obvious
               double[] p1 = {1.0, 2.0, 3.0};
               double[] p2 = {4.0, 5.0, 6.0};
               
               // Calculate expected distance manually
               double expectedSum = 0.0;
               expectedSum += (1.0-4.0)*(1.0-4.0); // 9.0
               expectedSum += (2.0-5.0)*(2.0-5.0); // 9.0
               expectedSum += (3.0-6.0)*(3.0-6.0); // 9.0
               double expectedDistance = Math.sqrt(expectedSum); // sqrt(27) ≈ 5.196
               
               // Call the method and assert
               double actualDistance = MathUtils.distance(p1, p2);
               assertEquals("Distance calculation should consider all dimensions", 
                            expectedDistance, actualDistance, 0.0001);
               
               // Additional check that would fail with the mutant
               // The sum should be greater than any single dimension's squared difference
               assertTrue("Sum of squares should be greater than any single dimension's square",
                         actualDistance > Math.sqrt(9.0)); // 9.0 is any single dimension's square
           }

 @Test
           public void testDistanceWithMultipleDimensions4() {
               // Test with 3D points where all dimensions differ
               double[] p1 = {1.0, 2.0, 3.0};
               double[] p2 = {4.0, 5.0, 6.0};
               
               // Calculate expected distance manually:
               // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
               double expected = Math.sqrt(27.0);
               double actual = MathUtils.distance(p1, p2);
               
               // Use delta for floating point comparison
               assertEquals("Distance calculation incorrect for 3D points", 
                           expected, actual, 1e-10);
           }

 @Test
           public void testDistanceWithTwoDimensions1() {
               // Test with 2D points
               double[] p1 = {0.0, 0.0};
               double[] p2 = {3.0, 4.0};
               
               // Expected distance: sqrt(3^2 + 4^2) = 5
               double expected = 5.0;
               double actual = MathUtils.distance(p1, p2);
               
               assertEquals("Distance calculation incorrect for 2D points",
                           expected, actual, 1e-10);
           }

 @Test
          public void testDistanceWithNonZeroDifferences1() {
              // Test case that will expose the mutant
              double[] p1 = {1.0, 2.0, 3.0};  // Simple coordinates with known distances
              double[] p2 = {4.0, 5.0, 6.0};  // Each dimension has difference of 3
              
              // Calculate expected distance manually:
              // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
              double expected = Math.sqrt(27.0);
              
              // Mutated version would calculate:
              // sqrt((3/3) + (3/3) + (3/3)) = sqrt(1 + 1 + 1) = sqrt(3) ≈ 1.73205
              // Which is very different from expected
              
              double actual = MathUtils.distance(p1, p2);
              
              // Use delta for floating point comparison
              assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
          }

 @Test
          public void testDistanceWithZeroDifferences1() {
              // This test case won't catch the mutant but is good for completeness
              double[] p1 = {1.0, 2.0, 3.0};
              double[] p2 = {1.0, 2.0, 3.0};  // Same points
              
              double expected = 0.0;
              double actual = MathUtils.distance(p1, p2);
              
              assertEquals("Distance between identical points should be 0", 
                         expected, actual, 1e-10);
          }

 @Test
          public void testDistanceWithNonZeroDifferences2() {
              double[] p1 = {1.0, 2.0, 3.0};
              double[] p2 = {4.0, 5.0, 6.0};
              
              // Original should return sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196
              // Mutant would return sqrt(1 + 1 + 1) = sqrt(3) ≈ 1.732 (since each dp/dp = 1)
              double expected = Math.sqrt(27); // Correct result
              double actual = MathUtils.distance(p1, p2);
              
              assertEquals("Distance calculation with non-zero differences failed", 
                          expected, actual, 0.0001);
          }

 @Test(expected = ArithmeticException.class)
          public void testDistanceWithZeroDifferences2() {
              double[] p1 = {1.0, 1.0};
              double[] p2 = {1.0, 1.0};
              
              // Original should return 0 (sqrt(0 + 0))
              // Mutant would throw ArithmeticException (division by 0)
              MathUtils.distance(p1, p2);
              
              // If we reach here, the test fails (no exception thrown)
              fail("Expected ArithmeticException for zero differences");
          }

 @Test
         public void testDistanceShouldReturnSquareRootOfSum1() {
             // Test case that will clearly show the difference between sum and sqrt(sum)
             double[] p1 = {0.0, 0.0};  // Origin point
             double[] p2 = {3.0, 4.0};  // Point (3,4)
             
             // Calculate expected value (Euclidean distance)
             // For (3,4), distance should be 5 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
             double expectedDistance = 5.0;
             
             // Calculate what the mutant would return (sum of squares without sqrt)
             double mutantValue = 25.0;  // 3² + 4² = 9 + 16 = 25
             
             // Actual call
             double actual = MathUtils.distance(p1, p2);
             
             // Assertion that will fail if the mutant is present
             assertEquals("Distance should be the square root of the sum of squared differences", 
                          expectedDistance, 
                          actual, 
                          0.0001);  // delta for double comparison
             
             // Additional assertion to ensure we're not getting the sum of squares
             assertNotEquals("Return value should not equal the sum of squares", 
                             mutantValue, 
                             actual, 
                             0.0001);
         }

 @Test
         public void testDistanceWithAnotherSimpleCase1() {
             // Another simple test case
             double[] p1 = {1.0, 1.0};
             double[] p2 = {4.0, 5.0};
             
             // Expected: sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5
             // Mutant would return 25
             double actual = MathUtils.distance(p1, p2);
             
             assertEquals(5.0, actual, 0.0001);
             assertNotEquals(25.0, actual, 0.0001);
         }

 @Test
         public void testDistanceWithZeroLengthVectors4() {
             // Edge case: same points should return 0 distance
             double[] p1 = {2.5, 3.5};
             double[] p2 = {2.5, 3.5};
             
             double actual = MathUtils.distance(p1, p2);
             
             assertEquals(0.0, actual, 0.0001);
         }

 @Test
     public void testDistanceShouldReturnSquareRootOfSum2() {
         // Test case where sum of squares is 25 (3² + 4²)
         double[] p1 = {0, 0};  // Origin point
         double[] p2 = {3, 4};  // Point at (3,4)
         
         // Expected Euclidean distance is 5 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5
         double expected = 5.0;
         double actual = MathUtils.distance(p1, p2);
         
         // This will fail if mutation exists (would return 25 instead of 5)
         assertEquals("Distance should be square root of sum of squared differences", 
                     expected, actual, 0.0001);
         
         // Additional test case with different values
         double[] p3 = {1, 1};
         double[] p4 = {4, 5};  // Differences are 3 and 4 again
         assertEquals("Second test case should also return 5", 
                     5.0, MathUtils.distance(p3, p4), 0.0001);
         
         // Edge case: zero distance
         double[] p5 = {2.5, 3.7};
         assertEquals("Distance between same points should be 0", 
                     0.0, MathUtils.distance(p5, p5), 0.0001);
         
         // Test with negative coordinates
         double[] p6 = {-1, -1};
         double[] p7 = {2, 3};  // Differences are 3 and 4
         assertEquals("Should work with negative coordinates", 
                     5.0, MathUtils.distance(p6, p7), 0.0001);
     }

 @Test
        public void testDistanceShouldReturnCorrectEuclideanDistance5() {
            // Test with simple known values that will expose the mutation
            double[] p1 = {0.0, 0.0};
            double[] p2 = {3.0, 4.0};
            
            // Expected Euclidean distance: sqrt(3² + 4²) = 5
            double expected = 5.0;
            double actual = MathUtils.distance(p1, p2);
            
            // This will fail for the mutant since it would return (3² + 4²)² = (9+16)² = 625
            assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
        }

 @Test
        public void testDistanceWithNonZeroInputShouldNotReturnSquaredSum() {
            // Another test case that would clearly expose the mutation
            double[] p1 = {1.0, 1.0};
            double[] p2 = {2.0, 2.0};
            
            // Expected: sqrt((2-1)² + (2-1)²) = sqrt(1 + 1) = sqrt(2) ≈ 1.4142
            // Mutant would return (1 + 1)² = 4
            double expected = Math.sqrt(2);
            double actual = MathUtils.distance(p1, p2);
            
            assertEquals("Distance should return square root of sum, not square of sum", 
                       expected, actual, 0.0001);
        }

 @Test
        public void testDistanceWithZeroVectorsShouldReturnZero() {
            // Edge case - should work for both original and mutant
            double[] p1 = {0.0, 0.0};
            double[] p2 = {0.0, 0.0};
            
            double expected = 0.0;
            double actual = MathUtils.distance(p1, p2);
            
            assertEquals("Distance between zero vectors should be zero", 
                       expected, actual, 0.0001);
        }

 @Test
    public void testDistanceShouldReturnEuclideanDistanceNotSquaredSum() {
        // Create simple points where distance is easy to calculate
        double[] p1 = {0.0, 0.0};
        double[] p2 = {3.0, 4.0};
        
        // Expected Euclidean distance: sqrt(3² + 4²) = 5.0
        double expected = 5.0;
        
        // Actual result from method
        double actual = MathUtils.distance(p1, p2);
        
        // Verify the result matches expected Euclidean distance
        assertEquals(expected, actual, 0.0001);
        
        // Additional test case with different values
        double[] p3 = {1.0, 1.0};
        double[] p4 = {4.0, 5.0};
        expected = 5.0; // sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5
        actual = MathUtils.distance(p3, p4);
        assertEquals(expected, actual, 0.0001);
        
        // Edge case: zero distance
        double[] p5 = {2.5, 3.5};
        double[] p6 = {2.5, 3.5};
        expected = 0.0;
        actual = MathUtils.distance(p5, p6);
        assertEquals(expected, actual, 0.0001);
    }

 @Test
       public void testDistanceWithZeroVectors2() {
           // Arrange
           double[] zeroVector1 = new double[]{0.0, 0.0, 0.0};
           double[] zeroVector2 = new double[]{0.0, 0.0, 0.0};
           
           // Act
           double result = MathUtils.distance(zeroVector1, zeroVector2);
           
           // Assert
           assertEquals("Distance between zero vectors should be exactly 0", 
                       0.0, result, 0.0);
       }

 @Test
       public void testDistanceWithEqualVectors() {
           // Arrange
           double[] vector1 = new double[]{1.0, 2.0, 3.0};
           double[] vector2 = new double[]{1.0, 2.0, 3.0};
           
           // Act
           double result = MathUtils.distance(vector1, vector2);
           
           // Assert
           assertEquals("Distance between equal vectors should be exactly 0", 
                       0.0, result, 0.0);
       }

 @Test
       public void testDistanceWithKnownValues() {
           // Arrange
           double[] p1 = new double[]{0.0, 0.0};
           double[] p2 = new double[]{3.0, 4.0}; // 3-4-5 triangle
           
           // Act
           double result = MathUtils.distance(p1, p2);
           
           // Assert
           assertEquals("Distance should be exactly 5 for 3-4-5 triangle", 
                       5.0, result, 0.0);
       }

 @Test
       public void testDistance1() {
           // Test case 1: Zero distance (identical points)
           double[] point1 = {0.0, 0.0};
           double[] point2 = {0.0, 0.0};
           double expected = 0.0;
           double actual = MathUtils.distance(point1, point2);
           assertEquals("Distance between identical points should be 0", expected, actual, 0.0001);
   
           // Test case 2: Known distance (3-4-5 triangle)
           double[] pointA = {0.0, 0.0};
           double[] pointB = {3.0, 4.0};
           expected = 5.0;
           actual = MathUtils.distance(pointA, pointB);
           assertEquals("Distance should follow Pythagorean theorem", expected, actual, 0.0001);
   
           // Test case 3: 1D distance
           double[] pointX = {5.0};
           double[] pointY = {2.0};
           expected = 3.0;
           actual = MathUtils.distance(pointX, pointY);
           assertEquals("Simple 1D distance should be difference", expected, actual, 0.0001);
       }

 @Test
      public void testDistanceReturnsNonNegativeValue() {
          // Test with simple 2D points
          double[] p1 = {0.0, 0.0};
          double[] p2 = {3.0, 4.0}; // Distance should be 5.0
          
          double result = MathUtils.distance(p1, p2);
          
          // The key assertion - distance should never be negative
          assertTrue("Distance should be non-negative", result >= 0);
          
          // Additional verification of exact value for completeness
          assertEquals(5.0, result, 0.0001);
      }

 @Test
      public void testDistanceWithZeroLengthVectors5() {
          // Test with identical points (distance should be 0)
          double[] p1 = {1.0, 2.0, 3.0};
          double[] p2 = {1.0, 2.0, 3.0};
          
          double result = MathUtils.distance(p1, p2);
          
          // Verify it's exactly 0 and non-negative
          assertEquals(0.0, result, 0.0);
          assertTrue(result >= 0);
      }

 @Test
      public void testDistanceWithRandomPoints() {
          // Test with random points
          double[] p1 = {1.5, 2.5, 3.5};
          double[] p2 = {4.5, 5.5, 6.5};
          
          double result = MathUtils.distance(p1, p2);
          
          // Just verify non-negativity since we don't know exact expected value
          assertTrue(result >= 0);
      }

 @Test
      public void testDistanceShouldReturnPositiveValue2() {
          // Test case 1: Simple 1D case
          double[] p1 = {1.0};
          double[] p2 = {2.0};
          double distance = MathUtils.distance(p1, p2);
          assertTrue("Distance should be positive", distance >= 0);
          assertEquals(1.0, distance, 0.0001);
          
          // Test case 2: 2D case with known distance
          double[] p3 = {0.0, 0.0};
          double[] p4 = {3.0, 4.0};
          distance = MathUtils.distance(p3, p4);
          assertTrue("Distance should be positive", distance >= 0);
          assertEquals(5.0, distance, 0.0001);
          
          // Test case 3: Zero distance case
          double[] p5 = {1.5, 2.5, 3.5};
          distance = MathUtils.distance(p5, p5);
          assertTrue("Distance should be positive", distance >= 0);
          assertEquals(0.0, distance, 0.0001);
          
          // Test case 4: Negative coordinates
          double[] p6 = {-1.0, -1.0};
          double[] p7 = {1.0, 1.0};
          distance = MathUtils.distance(p6, p7);
          assertTrue("Distance should be positive", distance >= 0);
          assertEquals(Math.sqrt(8), distance, 0.0001);
      }

 @Test
 public void testDistanceShouldReturnCorrectEuclideanDistance6() {
     // Arrange
     double[] p1 = {1.0, 2.0, 3.0};  // Point (1,2,3)
     double[] p2 = {4.0, 6.0, 8.0};  // Point (4,6,8)
     
     // Expected calculation:
     // (1-4)² + (2-6)² + (3-8)² = 9 + 16 + 25 = 50
     // sqrt(50) ≈ 7.0710678118654755
     double expectedDistance = Math.sqrt(50);
     
     // Act
     double actualDistance = MathUtils.distance(p1, p2);
     
     // Assert
     assertEquals("Distance calculation should return correct Euclidean distance", 
                 expectedDistance, 
                 actualDistance, 
                 1e-15);  // Very small delta for double comparison
     
     // Additional check to ensure it's not the mutated version
     // Mutated version would return sqrt(50/2) ≈ 5.0
     assertNotEquals("Should not return distance divided by 2", 
                    5.0, 
                    actualDistance, 
                    1e-15);
 }

 @Test
 public void testDistanceShouldReturnCorrectEuclideanDistance7() {
     // Test with simple 2D vectors where we can manually compute expected distance
     double[] p1 = {0.0, 0.0};
     double[] p2 = {3.0, 4.0};
     
     // Expected distance = sqrt(3² + 4²) = 5
     double expected = 5.0;
     double actual = MathUtils.distance(p1, p2);
     
     // The mutant would return sqrt((9+16)/2) = sqrt(12.5) ≈ 3.5355
     // So we assert the exact expected value which the mutant can't match
     assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
     
     // Additional test case with different values
     double[] p3 = {1.0, 2.0, 3.0};
     double[] p4 = {4.0, 5.0, 6.0};
     
     // Expected distance = sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(9+9+9) = sqrt(27) ≈ 5.196152
     expected = Math.sqrt(27);
     actual = MathUtils.distance(p3, p4);
     
     // The mutant would return sqrt(27/2) ≈ 3.67423
     assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
 }

}
