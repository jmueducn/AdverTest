package gentest.org.apache.commons.math3.analysis.differentiation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.analysis.differentiation.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class DSCompilerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                          public void testAtan2_PositiveX() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {1.0};
                                              double[] x = {1.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(FastMath.atan2(1.0, 1.0), result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_NegativeX_PositiveY() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {1.0};
                                              double[] x = {-1.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(FastMath.atan2(1.0, -1.0), result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_NegativeX_NegativeY() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {-1.0};
                                              double[] x = {-1.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(FastMath.atan2(-1.0, -1.0), result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_ZeroX_PositiveY() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {1.0};
                                              double[] x = {0.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(FastMath.PI/2, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_ZeroX_NegativeY() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {-1.0};
                                              double[] x = {0.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(-FastMath.PI/2, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_PositiveX_ZeroY() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {0.0};
                                              double[] x = {1.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(0.0, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_NegativeX_ZeroY() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {0.0};
                                              double[] x = {-1.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(FastMath.PI, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_ZeroX_ZeroY() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {0.0};
                                              double[] x = {0.0};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(0.0, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_PositiveInfinityY_PositiveInfinityX() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {Double.POSITIVE_INFINITY};
                                              double[] x = {Double.POSITIVE_INFINITY};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(FastMath.PI/4, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_PositiveInfinityY_NegativeInfinityX() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {Double.POSITIVE_INFINITY};
                                              double[] x = {Double.NEGATIVE_INFINITY};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(3*FastMath.PI/4, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_NegativeInfinityY_PositiveInfinityX() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {Double.NEGATIVE_INFINITY};
                                              double[] x = {Double.POSITIVE_INFINITY};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(-FastMath.PI/4, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_NegativeInfinityY_NegativeInfinityX() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(1);
                                              
                                              double[] y = {Double.NEGATIVE_INFINITY};
                                              double[] x = {Double.NEGATIVE_INFINITY};
                                              double[] result = new double[1];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(-3*FastMath.PI/4, result[0], 1e-15);
                                          }

 @Test
                                          public void testAtan2_WithDerivatives() {
                                              // Setup
                                              DSCompiler compiler = mock(DSCompiler.class);
                                              when(compiler.getSize()).thenReturn(3); // Value + 2 derivatives
                                              
                                              double[] y = {1.0, 0.1, 0.2}; // Value and derivatives
                                              double[] x = {2.0, 0.3, 0.4}; // Value and derivatives
                                              double[] result = new double[3];
                                              
                                              // Call method
                                              compiler.atan2(y, 0, x, 0, result, 0);
                                              
                                              // Verify
                                              assertEquals(FastMath.atan2(1.0, 2.0), result[0], 1e-15);
                                              // Derivatives would need more complex verification
                                              // For now just check they're calculated
                                              assertNotEquals(0.0, result[1], 1e-15);
                                              assertNotEquals(0.0, result[2], 1e-15);
                                          }

 @Test
                                  public void testAtan2_NullInputArrays() {
                                      // Setup
                                      DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                      
                                      thrown.expect(NullPointerException.class);
                                      compiler.atan2(null, 0, new double[1], 0, new double[1], 0);
                                      
                                      thrown.expect(NullPointerException.class);
                                      compiler.atan2(new double[1], 0, null, 0, new double[1], 0);
                                      
                                      thrown.expect(NullPointerException.class);
                                      compiler.atan2(new double[1], 0, new double[1], 0, null, 0);
                                  }

 @Test
                                  public void testAtan2_InvalidOffsets() {
                                      // Setup
                                      DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                      double[] arr = new double[1];
                                      
                                      thrown.expect(ArrayIndexOutOfBoundsException.class);
                                      compiler.atan2(arr, -1, arr, 0, arr, 0);
                                      
                                      thrown.expect(ArrayIndexOutOfBoundsException.class);
                                      compiler.atan2(arr, 0, arr, -1, arr, 0);
                                      
                                      thrown.expect(ArrayIndexOutOfBoundsException.class);
                                      compiler.atan2(arr, 0, arr, 0, arr, -1);
                                  }

 @Test
                              public void testAtan2DetectsArgumentSwapMutant() {
                                  // Create test compiler instance
                                  DSCompiler compiler = DSCompiler.getCompiler(1, 1); // using 1 parameter and order 1
                                  
                                  // Test input where x and y are different to ensure atan2(y,x) != atan2(x,y)
                                  double[] y = new double[]{1.0};
                                  double[] x = new double[]{2.0};
                                  double[] result = new double[compiler.getSize()];
                                  
                                  // Expected value using correct argument order
                                  double expected = FastMath.atan2(y[0], x[0]);
                                  
                                  // Call the method
                                  compiler.atan2(y, 0, x, 0, result, 0);
                                  
                                  // Verify the result matches the expected atan2(y,x)
                                  assertEquals("Final result should match FastMath.atan2(y,x)", 
                                              expected, result[0], 1e-15);
                                  
                                  // Additional test case with negative values
                                  double[] y2 = new double[]{-1.0};
                                  double[] x2 = new double[]{-2.0};
                                  double[] result2 = new double[compiler.getSize()];
                                  double expected2 = FastMath.atan2(y2[0], x2[0]);
                                  
                                  compiler.atan2(y2, 0, x2, 0, result2, 0);
                                  assertEquals("Final result should match FastMath.atan2(y,x) for negative values",
                                              expected2, result2[0], 1e-15);
                                  
                                  // Edge case where x=0
                                  double[] y3 = new double[]{1.0};
                                  double[] x3 = new double[]{0.0};
                                  double[] result3 = new double[compiler.getSize()];
                                  double expected3 = FastMath.atan2(y3[0], x3[0]);
                                  
                                  compiler.atan2(y3, 0, x3, 0, result3, 0);
                                  assertEquals("Final result should handle x=0 case correctly",
                                              expected3, result3[0], 1e-15);
                              }

 @Test
                             public void testAtan2DetectsSignFlipMutant() {
                                 // Create a compiler instance (parameters=1, order=1 for simplicity)
                                 DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                                 
                                 // Test cases with different combinations of x and y signs
                                 double[] testCases = {
                                     // x, y, expected angle
                                     1.0, 1.0, FastMath.atan2(1.0, 1.0),    // first quadrant
                                     1.0, -1.0, FastMath.atan2(-1.0, 1.0),   // fourth quadrant
                                     -1.0, 1.0, FastMath.atan2(1.0, -1.0),   // second quadrant
                                     -1.0, -1.0, FastMath.atan2(-1.0, -1.0), // third quadrant
                                     0.0, 1.0, FastMath.atan2(1.0, 0.0),     // positive y-axis
                                     0.0, -1.0, FastMath.atan2(-1.0, 0.0)    // negative y-axis
                                 };
                                 
                                 // Prepare arrays for input and output
                                 double[] x = new double[compiler.getSize()];
                                 double[] y = new double[compiler.getSize()];
                                 double[] result = new double[compiler.getSize()];
                                 
                                 for (int i = 0; i < testCases.length; i += 3) {
                                     x[0] = testCases[i];
                                     y[0] = testCases[i+1];
                                     double expected = testCases[i+2];
                                     
                                     // Call the method
                                     compiler.atan2(y, 0, x, 0, result, 0);
                                     
                                     // Verify the result matches expected angle
                                     assertEquals("Incorrect atan2 result for (x=" + x[0] + ", y=" + y[0] + ")",
                                                 expected, result[0], 1e-15);
                                 }
                             }

 @Test
                           public void testAtan2DetectsSignFlipMutation() {
                               // Create test compiler instance using public factory method
                               DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                               
                               // Test case 1: x positive, y positive (first quadrant)
                               double[] x1 = {1.0, 0.0, 0.0};
                               double[] y1 = {1.0, 0.0, 0.0};
                               double[] result1 = new double[3];
                               compiler.atan2(y1, 0, x1, 0, result1, 0);
                               assertEquals(FastMath.atan2(y1[0], x1[0]), result1[0], 1e-15);
                               
                               // Test case 2: x negative, y positive (second quadrant)
                               double[] x2 = {-1.0, 0.0, 0.0};
                               double[] y2 = {1.0, 0.0, 0.0};
                               double[] result2 = new double[3];
                               compiler.atan2(y2, 0, x2, 0, result2, 0);
                               assertEquals(FastMath.atan2(y2[0], x2[0]), result2[0], 1e-15);
                               
                               // Test case 3: x negative, y negative (third quadrant)
                               double[] x3 = {-1.0, 0.0, 0.0};
                               double[] y3 = {-1.0, 0.0, 0.0};
                               double[] result3 = new double[3];
                               compiler.atan2(y3, 0, x3, 0, result3, 0);
                               assertEquals(FastMath.atan2(y3[0], x3[0]), result3[0], 1e-15);
                               
                               // Test case 4: x positive, y negative (fourth quadrant)
                               double[] x4 = {1.0, 0.0, 0.0};
                               double[] y4 = {-1.0, 0.0, 0.0};
                               double[] result4 = new double[3];
                               compiler.atan2(y4, 0, x4, 0, result4, 0);
                               assertEquals(FastMath.atan2(y4[0], x4[0]), result4[0], 1e-15);
                               
                               // Test case 5: x zero (edge case)
                               double[] x5 = {0.0, 0.0, 0.0};
                               double[] y5 = {1.0, 0.0, 0.0};
                               double[] result5 = new double[3];
                               compiler.atan2(y5, 0, x5, 0, result5, 0);
                               assertEquals(FastMath.atan2(y5[0], x5[0]), result5[0], 1e-15);
                           }

 @Test
                       public void testAtan2DetectsFinalCorrectionMutation() {
                           // Setup
                           DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case
                           double[] y = {1.0}; // Non-zero y value
                           double[] x = {1.0}; 
                           double[] result = new double[compiler.getSize()];
                           
                           // Action
                           compiler.atan2(y, 0, x, 0, result, 0);
                           
                           // Verification
                           // The mutation would compute atan2(0,1) instead of atan2(1,1)
                           double expected = FastMath.atan2(y[0], x[0]);
                           assertEquals("Final correction should use actual y value", 
                                       expected, result[0], 1e-15);
                           
                           // Additional edge case with negative y
                           y[0] = -1.0;
                           compiler.atan2(y, 0, x, 0, result, 0);
                           expected = FastMath.atan2(y[0], x[0]);
                           assertEquals("Final correction should work for negative y", 
                                       expected, result[0], 1e-15);
                       }

 @Test
                      public void testAtan2DetectsXValueMutation() {
                          // Setup test data where x is not zero and angle is not π/2
                          DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Assuming 2 parameters, order 2
                          
                          double[] y = {1.0, 0.0, 0.0}; // y = 1.0
                          double[] x = {1.0, 0.0, 0.0};  // x = 1.0 (should give π/4 angle)
                          double[] result = new double[3];
                          
                          // Call the method
                          compiler.atan2(y, 0, x, 0, result, 0);
                          
                          // Verify the result matches exact FastMath.atan2 calculation
                          double expectedAngle = FastMath.atan2(y[0], x[0]);
                          assertEquals("Angle should match exact FastMath.atan2 calculation", 
                                      expectedAngle, result[0], 1e-15);
                          
                          // Additional verification that it's not just giving π/2
                          assertNotEquals("Result should not be π/2 when x is not zero",
                                         FastMath.PI/2, result[0], 1e-15);
                          
                          // Test another case with negative x
                          x[0] = -1.0;
                          compiler.atan2(y, 0, x, 0, result, 0);
                          expectedAngle = FastMath.atan2(y[0], x[0]);
                          assertEquals("Angle should match exact calculation for negative x",
                                      expectedAngle, result[0], 1e-15);
                      }

 @Test
                    public void testAtan2SpecialCasesDetectsMutant() {
                        // Setup
                        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using public factory method
                        double[] y = new double[compiler.getSize()];
                        double[] x = new double[compiler.getSize()];
                        double[] result = new double[compiler.getSize()];
                        
                        // Test case 1: y = 0.5 (not equal to 1)
                        y[0] = 0.5;
                        x[0] = 1.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 0.0);
                        
                        // Test case 2: y = 0.0 (special case)
                        y[0] = 0.0;
                        x[0] = 1.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 0.0);
                        
                        // Test case 3: y = -0.0 (special case)
                        y[0] = -0.0;
                        x[0] = 1.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 0.0);
                        
                        // Test case 4: y = Double.POSITIVE_INFINITY
                        y[0] = Double.POSITIVE_INFINITY;
                        x[0] = 1.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 0.0);
                        
                        // Test case 5: y = Double.NEGATIVE_INFINITY
                        y[0] = Double.NEGATIVE_INFINITY;
                        x[0] = 1.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 0.0);
                        
                        // Test case 6: x = 0.0, y = 1.0 (edge case)
                        y[0] = 1.0;
                        x[0] = 0.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 0.0);
                    }

 @Test
                public void testAtan2DetectsMutantInFinalCorrection() {
                    // Setup test data with x != 1 to detect the mutant
                    DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, order 1
                    
                    // Test case where x is negative (to go through the else branch)
                    double[] y = new double[2];
                    double[] x = new double[2];
                    double[] result = new double[2];
                    
                    // Set values: y = 1.0, x = -1.0 (important that x != 1)
                    y[0] = 1.0;
                    x[0] = -1.0;
                    
                    // Call the method
                    compiler.atan2(y, 0, x, 0, result, 0);
                    
                    // Expected value should be FastMath.atan2(y[0], x[0])
                    double expected = FastMath.atan2(y[0], x[0]);
                    
                    // Assert the result matches expected atan2 calculation
                    assertEquals("Final correction should use actual x value", 
                                expected, result[0], 1e-15);
                    
                    // Additional test case with x = 0 (another edge case)
                    x[0] = 0.0;
                    compiler.atan2(y, 0, x, 0, result, 0);
                    expected = FastMath.atan2(y[0], x[0]);
                    assertEquals("Final correction should work with x=0", 
                                expected, result[0], 1e-15);
                }

 @Test
              public void testAtan2DetectsFinalCorrectionMutation1() {
                  // Setup test data where y is not Double.MAX_VALUE
                  double[] y = {1.0};
                  int yOffset = 0;
                  double[] x = {1.0}; // Using x=1 to ensure we go through the first branch
                  int xOffset = 0;
                  double[] result = new double[1];
                  int resultOffset = 0;
                  
                  // Create a compiler instance using the public factory method
                  DSCompiler compiler = DSCompiler.getCompiler(1, 1);
                  
                  // Call the method
                  compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                  
                  // Verify the final correction uses the original y value, not Double.MAX_VALUE
                  double expected = FastMath.atan2(y[yOffset], x[xOffset]);
                  assertEquals("Final correction should use original y value", 
                             expected, result[resultOffset], 1e-15);
                  
                  // Additional test case with negative x to cover both branches
                  x[0] = -1.0;
                  compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                  expected = FastMath.atan2(y[yOffset], x[xOffset]);
                  assertEquals("Final correction should use original y value for negative x", 
                             expected, result[resultOffset], 1e-15);
                  
                  // Edge case with y=0
                  y[0] = 0.0;
                  x[0] = 1.0;
                  compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                  expected = FastMath.atan2(y[yOffset], x[xOffset]);
                  assertEquals("Final correction should work with y=0", 
                             expected, result[resultOffset], 1e-15);
              }

 @Test
         public void testAtan2DetectsMutantUsingFinalValue() {
             // Create test compiler instance using public factory method
             DSCompiler compiler = DSCompiler.getCompiler(2, 2);
             
             // Test input where x is clearly different from Double.MAX_VALUE
             double[] y = {1.0};
             double[] x = {1.0};  // This will be different from Double.MAX_VALUE in the mutant
             double[] result = new double[compiler.getSize()];
             
             // Calculate expected value
             double expected = FastMath.atan2(y[0], x[0]);
             
             // Call the method
             compiler.atan2(y, 0, x, 0, result, 0);
             
             // Verify the result matches the expected FastMath.atan2 calculation
             assertEquals("Final result should match exact FastMath.atan2 calculation", 
                         expected, result[0], 1e-15);
             
             // Additional test case with negative x to cover both branches
             double[] xNeg = {-1.0};
             double expectedNeg = FastMath.atan2(y[0], xNeg[0]);
             compiler.atan2(y, 0, xNeg, 0, result, 0);
             assertEquals("Final result for negative x should match exact FastMath.atan2", 
                         expectedNeg, result[0], 1e-15);
         }

 @Test
     public void testAtan2SpecialCaseDetection() {
         // Setup
         DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case with 1 parameter and order 1
         double[] y = {1.0}; // Non-zero y value
         double[] x = {0.0}; // Special case when x is 0
         double[] result = new double[compiler.getSize()];
         
         // Action
         compiler.atan2(y, 0, x, 0, result, 0);
         
         // Verification
         // The mutant would use Double.MIN_VALUE instead of 1.0 in the final correction
         double expected = FastMath.atan2(y[0], x[0]);
         double actual = result[0];
         assertEquals("Special case correction should use actual y value", 
                     expected, actual, 1e-15);
         
         // Also verify other array elements if needed
         for (int i = 1; i < result.length; i++) {
             assertEquals(0.0, result[i], 1e-15);
         }
     }

 @Test
    public void testAtan2DetectsMutantUsingXValue() {
        // Setup test data with x values that are not Double.MIN_VALUE
        DSCompiler compiler = DSCompiler.getCompiler(1, 1); // parameters=1, order=1
        double[] y = {1.0};
        double[] x = {1.0}; // Regular positive x
        double[] xNegative = {-1.0}; // Negative x
        double[] xZero = {0.0}; // Zero x
        double[] xLarge = {1e300}; // Large x
        double[] result = new double[compiler.getSize()];
        
        // Test positive x case
        compiler.atan2(y, 0, x, 0, result, 0);
        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
        
        // Test negative x case
        compiler.atan2(y, 0, xNegative, 0, result, 0);
        assertEquals(FastMath.atan2(y[0], xNegative[0]), result[0], 1e-15);
        
        // Test zero x case
        compiler.atan2(y, 0, xZero, 0, result, 0);
        assertEquals(FastMath.atan2(y[0], xZero[0]), result[0], 1e-15);
        
        // Test large x case
        compiler.atan2(y, 0, xLarge, 0, result, 0);
        assertEquals(FastMath.atan2(y[0], xLarge[0]), result[0], 1e-15);
        
        // Test with x = Double.MIN_VALUE (should pass even with mutant)
        double[] xMin = {Double.MIN_VALUE};
        compiler.atan2(y, 0, xMin, 0, result, 0);
        assertEquals(FastMath.atan2(y[0], xMin[0]), result[0], 1e-15);
    }

 @Test
   public void testAtan2DetectsFinalCorrectionMutation2() {
       // Setup test data with small x value where x vs x+1 makes a difference
       DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, 1st order
       
       double[] y = {1.0};
       double[] x = {0.0001}; // very small x value
       double[] result = new double[compiler.getSize()];
       
       // Calculate expected value using correct formula
       double expected = FastMath.atan2(y[0], x[0]);
       
       // Call the method
       compiler.atan2(y, 0, x, 0, result, 0);
       
       // Verify the final correction matches exactly what we expect
       assertEquals("Final correction should use exact x value", 
                    expected, result[0], 1.0e-15);
       
       // Also verify other array elements if needed
       for (int i = 1; i < result.length; i++) {
           assertEquals(0.0, result[i], 1.0e-15);
       }
   }

 @Test
  public void testAtan2DetectsMutant() {
      // Setup
      DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, 1st order
      double[] y = new double[compiler.getSize()];
      double[] x = new double[compiler.getSize()];
      double[] result = new double[compiler.getSize()];
      
      // Test with known value (1,1) which should give π/4
      y[0] = 1.0;
      x[0] = 1.0;
      
      // Expected value
      double expected = FastMath.atan2(y[0], x[0]);
      
      // Execute
      compiler.atan2(y, 0, x, 0, result, 0);
      
      // Verify - this will fail if the mutant is present
      assertEquals("First element should match exact FastMath.atan2 computation", 
                  expected, result[0], 1e-15);
      
      // Additional verification for other elements if needed
      for (int i = 1; i < result.length; i++) {
          assertEquals(0.0, result[i], 1e-15);
      }
  }

 @Test
 public void testAtan2DetectsMutant1() {
     // Create test compiler instance
     DSCompiler compiler = DSCompiler.getCompiler(1, 1); // 1 parameter, 1st order
     
     // Test with small x value where doubling it would significantly change the angle
     double[] y = {1.0};  // y coordinate
     double[] x = {0.001}; // very small x coordinate
     double[] result = new double[1];
     
     // Calculate expected correct value
     double expected = FastMath.atan2(y[0], x[0]);
     
     // Call the method
     compiler.atan2(y, 0, x, 0, result, 0);
     
     // Verify the result matches the expected FastMath.atan2 calculation
     assertEquals("Final atan2 result should match FastMath.atan2 without mutation", 
                 expected, result[0], 1e-15);
     
     // Additional verification that the result is not what the mutant would produce
     double mutantValue = FastMath.atan2(y[0], x[0] * 2);
     assertNotEquals("Test should detect the mutant by showing different results", 
                    mutantValue, result[0], 1e-15);
 }

}
