package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Erf;
import org.apache.commons.math.util.FastMath;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                     public void testConstructor_InvalidStandardDeviation() {
                                         thrown.expect(NotStrictlyPositiveException.class);
                                         thrown.expectMessage(LocalizedFormats.STANDARD_DEVIATION.toString());
                                         new NormalDistributionImpl(0.0, 0.0);
                                     }

 @Test
                         public void testCumulativeProbability_ExtremeLeft() throws MathException {
                             NormalDistributionImpl normalDist = new NormalDistributionImpl();
                             final double EPSILON = 1e-10;
                             double result = normalDist.cumulativeProbability(-1000);
                             assertEquals(0.0, result, EPSILON);
                         }

 @Test
                         public void testCumulativeProbability_ExtremeRight() throws org.apache.commons.math.MathException {
                             // Create normal distribution with mean 0 and standard deviation 1 (standard normal)
                             NormalDistributionImpl normalDist = new NormalDistributionImpl();
                             // Test extreme right value (1000 is way beyond 40 standard deviations from mean 0)
                             double result = normalDist.cumulativeProbability(1000);
                             // Use small epsilon for double comparison
                             double EPSILON = 1e-10;
                             assertEquals(1.0, result, EPSILON);
                         }

 @Test
                         public void testCumulativeProbability_AtMean() throws org.apache.commons.math.MathException {
                             // Create standard normal distribution (mean=0, sd=1)
                             NormalDistributionImpl normalDist = new NormalDistributionImpl(0.0, 1.0);
                             // Define epsilon for double comparison
                             double EPSILON = 1e-10;
                             // Test cumulative probability at mean (should be 0.5)
                             double result = normalDist.cumulativeProbability(0.0);
                             assertEquals(0.5, result, EPSILON);
                         }

 @Test
                         public void testCumulativeProbability_NearMean() throws MathException {
                             // Create normal distribution with mean=0 and standard deviation=1
                             NormalDistributionImpl normalDist = new NormalDistributionImpl();
                             final double EPSILON = 1e-12;
                             
                             double result = normalDist.cumulativeProbability(0.5);
                             assertEquals(0.691462461274, result, EPSILON);
                             
                             result = normalDist.cumulativeProbability(-0.5);
                             assertEquals(0.308537538726, result, EPSILON);
                         }

 @Test
                         public void testCumulativeProbability_BoundaryConditions() throws MathException {
                             // Define test constants
                             final double EPSILON = 1e-10;
                             NormalDistributionImpl normalDist = new NormalDistributionImpl(); // mean=0, sd=1
                             
                             // Just inside 40*SD threshold (SD=1, so 40)
                             double result = normalDist.cumulativeProbability(39.9);
                             assertTrue(result < 1.0);
                             assertTrue(result > 0.0);
                             
                             result = normalDist.cumulativeProbability(-39.9);
                             assertTrue(result > 0.0);
                             assertTrue(result < 1.0);
                             
                             // Just outside 40*SD threshold
                             result = normalDist.cumulativeProbability(40.1);
                             assertEquals(1.0, result, EPSILON);
                             
                             result = normalDist.cumulativeProbability(-40.1);
                             assertEquals(0.0, result, EPSILON);
                         }

 @Test
                         public void testCumulativeProbability_NonStandardDistribution() throws MathException {
                             final double EPSILON = 1e-12;
                             NormalDistributionImpl customDist = new NormalDistributionImpl(10.0, 2.0);
                             
                             // Test at mean
                             assertEquals(0.5, customDist.cumulativeProbability(10.0), EPSILON);
                             
                             // Test one SD above mean
                             assertEquals(0.841344746069, customDist.cumulativeProbability(12.0), EPSILON);
                             
                             // Test extreme values
                             assertEquals(0.0, customDist.cumulativeProbability(-1000), EPSILON);
                             assertEquals(1.0, customDist.cumulativeProbability(1000), EPSILON);
                         }

 @Test
                    public void testCumulativeProbabilityAt40StandardDeviations() throws MathException {
                        // Setup - create distribution with mean 0 and standard deviation 1
                        double mean = 0.0;
                        double standardDeviation = 1.0;
                        NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                        
                        // Test exactly 40 standard deviations above mean
                        double x = mean + 40 * standardDeviation;
                        double result = distribution.cumulativeProbability(x);
                        
                        // Verify it didn't return 1.0 (which mutant would do)
                        // We can't predict exact Erf value, but we know it should be very close to 1
                        // but not exactly 1 (since original uses Erf.erf)
                        assertTrue(result < 1.0);
                        assertTrue(result > 0.999999999); // Should be extremely close to 1
                        
                        // Also test negative case
                        x = mean - 40 * standardDeviation;
                        result = distribution.cumulativeProbability(x);
                        assertTrue(result > 0.0); // Should be extremely small but not 0
                        assertTrue(result < 0.000000001);
                    }

 @Test
               public void testCumulativeProbabilityForLargeDeviations() throws MathException {
                   // Setup: mean=0, standard deviation=1 for simplicity
                   double mean = 0;
                   double stdDev = 1;
                   NormalDistributionImpl dist = new NormalDistributionImpl(mean, stdDev);
                   
                   // Test point at 35 standard deviations from mean (between 30 and 40)
                   double x = mean + 35 * stdDev;
                   
                   // Original behavior should calculate using erf (result > 0 and < 1)
                   // Mutant would return exactly 1.0
                   double result = dist.cumulativeProbability(x);
                   
                   // Verify it's not exactly 1.0 (which mutant would return)
                   assertTrue("Result should be very close to 1 but not exactly 1", 
                             result < 1.0 && result > 0.999999999);
                   
                   // Also test negative side
                   x = mean - 35 * stdDev;
                   result = dist.cumulativeProbability(x);
                   assertTrue("Result should be very close to 0 but not exactly 0",
                             result > 0.0 && result < 0.000000001);
               }

 @Test
          public void testCumulativeProbabilityBoundaryCondition() throws MathException {
              // Create distribution with mean=0, standardDeviation=10
              // This makes 40*standardDeviation = 400
              NormalDistributionImpl dist = new NormalDistributionImpl(0, 10);
              
              // Test value where abs(dev) > 40 but < 40*standardDeviation
              // x=50 (dev=50) - should use erf calculation in original
              // but mutant will return 1.0
              double result = dist.cumulativeProbability(50);
              
              // Verify it's using the erf calculation (not exactly 1.0)
              assertTrue(result > 0.999999 && result < 1.0);
              
              // Test negative case
              result = dist.cumulativeProbability(-50);
              assertTrue(result > 0.0 && result < 0.000001);
              
              // Test value where abs(dev) > 40*standardDeviation (x=500)
              // Both should return 1.0
              assertEquals(1.0, dist.cumulativeProbability(500), 0.0);
          }

 @Test
     public void testCumulativeProbabilityAtMeanWithLargeDeviation() throws Exception {
         // Create a normal distribution with mean=0 and very large standard deviation
         // so that any finite x will satisfy |x - mean| <= 40*sd
         double mean = 0.0;
         double largeSD = Double.MAX_VALUE / 40; // Makes 40*sd effectively infinite
         NormalDistribution dist = new NormalDistributionImpl(mean, largeSD);
         
         // Test exactly at the mean (dev = 0)
         double x = mean;
         double result = dist.cumulativeProbability(x);
         
         // Original should calculate using erf (result ~0.5)
         // Mutant would return 0.0 due to dev <= 0
         assertEquals(0.5, result, 1e-10);
     }

 @Test
     public void testCumulativeProbabilityEdgeCases() throws MathException {
         double mean = 10.0;
         double sd = 1.0;
         NormalDistribution dist = new NormalDistributionImpl(mean, sd);
         
         // Test case where dev is exactly 0 (x equals mean)
         // This would be affected by the mutation
         assertEquals(0.5, dist.cumulativeProbability(mean), 1e-10);
         
         // Test case where dev is negative but within 40*sd
         assertEquals(0.5 * (1.0 + Erf.erf(-1/FastMath.sqrt(2.0))), 
                      dist.cumulativeProbability(mean - 1), 1e-10);
         
         // Test case where dev is positive but within 40*sd
         assertEquals(0.5 * (1.0 + Erf.erf(1/FastMath.sqrt(2.0))), 
                      dist.cumulativeProbability(mean + 1), 1e-10);
     }

 @Test
     public void testCumulativeProbabilityWithNegativeStandardDeviation() throws Exception {
         // Create normal distribution with mean 0 and sd 1
         NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
         
         // Use reflection to forcibly set negative standard deviation
         Field sdField = NormalDistributionImpl.class.getDeclaredField("standardDeviation");
         sdField.setAccessible(true);
         sdField.set(dist, -1.0);
         
         // Test case where dev is exactly 40 * standardDeviation (but standardDeviation is negative)
         double x = 0 + 40 * -1.0; // mean + 40 * sd
         double result = dist.cumulativeProbability(x);
         
         // Original code would return Erf calculation (since 40 > 40*-1 is false)
         // Mutated code would return 1.0 (since 40 > 40*1 is true)
         // So we assert it's not 1.0 to catch the mutant
         assertNotEquals(1.0, result, 0.0001);
         
         // Additional assertion to verify it's using Erf calculation
         double expected = 0.5 * (1.0 + Erf.erf(40 * -1.0 / (-1.0 * FastMath.sqrt(2.0))));
         assertEquals(expected, result, 0.0001);
     }

}
