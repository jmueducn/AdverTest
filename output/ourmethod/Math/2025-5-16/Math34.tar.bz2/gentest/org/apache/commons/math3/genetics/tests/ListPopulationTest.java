package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
 
public class ListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                 public void testIterator_DoubleRemoveShouldThrow() {
                                                                                                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                                                                                                     Chromosome chromosome = new Chromosome() {
                                                                                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                                                                                         public double fitness() {
                                                                                                                                                                                                                                                                                                             return 0;
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                                                                     List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                                                                                                                                                                                                     chromosomes.add(chromosome);
                                                                                                                                                                                                                                                                                                     ListPopulation population = new ElitisticListPopulation(chromosomes, 10, 0.1);
                                                                                                                                                                                                                                                                                                     Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                                                                     iterator.next();
                                                                                                                                                                                                                                                                                                     iterator.remove();
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Expect exception
                                                                                                                                                                                                                                                                                                     thrown.expect(IllegalStateException.class);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                                                                     iterator.remove();
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                         public void testIterator_SingleChromosome() {
                                                                                                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                                                                                                             Chromosome mockChromosome1 = new Chromosome() {
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public double fitness() {
                                                                                                                                                                                                                                                                                                     return 0;
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                             List<Chromosome> chromosomes = Collections.singletonList(mockChromosome1);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public Population nextGeneration() {
                                                                                                                                                                                                                                                                                                     return null;
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public Chromosome getFittestChromosome() {
                                                                                                                                                                                                                                                                                                     return mockChromosome1;
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public void addChromosome(Chromosome chromosome) {
                                                                                                                                                                                                                                                                                                     // Implementation for test purposes
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Act
                                                                                                                                                                                                                                                                                             Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Assert
                                                                                                                                                                                                                                                                                             assertTrue("Iterator should have elements", iterator.hasNext());
                                                                                                                                                                                                                                                                                             assertEquals("First element should match", mockChromosome1, iterator.next());
                                                                                                                                                                                                                                                                                             assertFalse("Iterator should have no more elements", iterator.hasNext());
                                                                                                                                                                                                                                                                                         }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                                                                                                         public void testIterator_RemoveWithoutNextShouldThrow() {
                                                                                                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                                                                                                             Chromosome chromosome = new Chromosome() {
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public double fitness() {
                                                                                                                                                                                                                                                                                                     return 0;
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                             List<Chromosome> chromosomes = java.util.Arrays.asList(chromosome);
                                                                                                                                                                                                                                                                                             ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public int getPopulationSize() {
                                                                                                                                                                                                                                                                                                     return chromosomes.size();
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public Chromosome getFittestChromosome() {
                                                                                                                                                                                                                                                                                                     return chromosome;
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public void addChromosome(Chromosome chromosome) {
                                                                                                                                                                                                                                                                                                     // Empty implementation for test
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public Population nextGeneration() {
                                                                                                                                                                                                                                                                                                     return this;
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public int getPopulationLimit() {
                                                                                                                                                                                                                                                                                                     return 10;
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                             Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Act
                                                                                                                                                                                                                                                                                             iterator.remove();
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                 public void testIterator_RemoveOperation() {
                                                                                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                                                                                     org.apache.commons.math3.genetics.Chromosome mockChromosome1 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                                                                                                                                                                                                                                                     org.apache.commons.math3.genetics.Chromosome mockChromosome2 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                                                                                                                                                                                                                                                     java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = new java.util.ArrayList<>(java.util.Arrays.asList(mockChromosome1, mockChromosome2));
                                                                                                                                                                                                                                                                                     // Use ListPopulation directly instead of anonymous implementation
                                                                                                                                                                                                                                                                                     org.apache.commons.math3.genetics.ListPopulation population = new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                                                                                                                                                                                                                                         // Override only the methods we need to customize
                                                                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                                                                         public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                                                                                                                                                                                             return null; // Not needed for this test
                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                                                     iterator.next();
                                                                                                                                                                                                                                                                                     iterator.remove();
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                                                                                     assertEquals("Population size should decrease", 1, population.getPopulationSize());
                                                                                                                                                                                                                                                                                     assertFalse("Chromosome should be removed", population.getChromosomes().contains(mockChromosome1));
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                             public void testIterator_EmptyPopulation() {
                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                 ListPopulation population = new ListPopulation(new ArrayList<Chromosome>(), 10) {
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public Population nextGeneration() {
                                                                                                                                                                                                                                                                                         // Dummy implementation for testing
                                                                                                                                                                                                                                                                                         return this;
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Act
                                                                                                                                                                                                                                                                                 Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Assert
                                                                                                                                                                                                                                                                                 assertNotNull("Iterator should not be null", iterator);
                                                                                                                                                                                                                                                                                 assertFalse("Iterator should have no elements", iterator.hasNext());
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                             public void testIterator_ConcurrentModification() {
                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                 org.apache.commons.math3.genetics.Chromosome mockChromosome1 = 
                                                                                                                                                                                                                                                                     new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                                                         public double fitness() {
                                                                                                                                                                                                                                                                             return 0;
                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                                 org.apache.commons.math3.genetics.Chromosome mockChromosome2 = 
                                                                                                                                                                                                                                                                     new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                                                         public double fitness() {
                                                                                                                                                                                                                                                                             return 0;
                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                                 java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                                                                                                                                                                                                                                     new java.util.ArrayList<>(java.util.Arrays.asList(mockChromosome1, mockChromosome2));
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Using anonymous class to create concrete implementation
                                                                                                                                                                                                                                                                 org.apache.commons.math3.genetics.ListPopulation population = 
                                                                                                                                                                                                                                                                     new org.apache.commons.math3.genetics.ListPopulation(chromosomes, 10) {
                                                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                                                         public org.apache.commons.math3.genetics.Population nextGeneration() {
                                                                                                                                                                                                                                                                             return null; // Simple implementation for test
                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Act & Assert
                                                                                                                                                                                                                                                                 assertTrue(iterator.hasNext());
                                                                                                                                                                                                                                                                 iterator.next();
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Modify the underlying collection
                                                                                                                                                                                                                                                                 chromosomes.remove(0);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                     iterator.next();
                                                                                                                                                                                                                                                                     fail("Expected ConcurrentModificationException");
                                                                                                                                                                                                                                                                 } catch (java.util.ConcurrentModificationException e) {
                                                                                                                                                                                                                                                                     // Expected exception
                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                     public void testIterator_MultipleChromosomes() {
                                                                                                                                                                                                         // Arrange
                                                                                                                                                                                                         org.apache.commons.math3.genetics.Chromosome mockChromosome1 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             public double fitness() {
                                                                                                                                                                                                                 return 0.5;
                                                                                                                                                                                                             }
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         org.apache.commons.math3.genetics.Chromosome mockChromosome2 = new org.apache.commons.math3.genetics.Chromosome() {
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             public double fitness() {
                                                                                                                                                                                                                 return 0.7;
                                                                                                                                                                                                             }
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         List<org.apache.commons.math3.genetics.Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                                                                                         chromosomes.add(mockChromosome1);
                                                                                                                                                                                                         chromosomes.add(mockChromosome2);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create a concrete ListPopulation for testing
                                                                                                                                                                                                         ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             public Population nextGeneration() {
                                                                                                                                                                                                                 return null; // Simple implementation for testing
                                                                                                                                                                                                             }
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Act
                                                                                                                                                                                                         Iterator<org.apache.commons.math3.genetics.Chromosome> iterator = population.iterator();
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Assert
                                                                                                                                                                                                         assertTrue(iterator.hasNext());
                                                                                                                                                                                                         assertEquals(mockChromosome1, iterator.next());
                                                                                                                                                                                                         assertTrue(iterator.hasNext());
                                                                                                                                                                                                         assertEquals(mockChromosome2, iterator.next());
                                                                                                                                                                                                         assertFalse(iterator.hasNext());
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                            public void testIteratorReturnsRegularIteratorNotListIterator() {
                                                                                                                                                                                                // Setup test data
                                                                                                                                                                                                List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                                                                                chromosomes.add(mock(Chromosome.class));
                                                                                                                                                                                                chromosomes.add(mock(Chromosome.class));
                                                                                                                                                                                                
                                                                                                                                                                                                // Create anonymous subclass since ListPopulation is abstract
                                                                                                                                                                                                ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public Population nextGeneration() {
                                                                                                                                                                                                        return null; // Simple implementation for test purposes
                                                                                                                                                                                                    }
                                                                                                                                                                                                };
                                                                                                                                                                                                
                                                                                                                                                                                                // Get the iterator
                                                                                                                                                                                                Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify it's not a ListIterator
                                                                                                                                                                                                assertFalse("Returned iterator should not be a ListIterator", 
                                                                                                                                                                                                           iterator instanceof java.util.ListIterator);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify basic iterator functionality works
                                                                                                                                                                                                assertTrue("Iterator should have next element", iterator.hasNext());
                                                                                                                                                                                                assertNotNull("First element should not be null", iterator.next());
                                                                                                                                                                                            }

    @Test
                                                                                                                                                   public void testIteratorAllowsModification() {
                                                                                                                                                       // Setup test data
                                                                                                                                                       List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                                       chromosomes.add(mock(Chromosome.class));
                                                                                                                                                       chromosomes.add(mock(Chromosome.class));
                                                                                                                                                       // Create anonymous subclass of ListPopulation with dummy nextGeneration implementation
                                                                                                                                                       ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                                                           @Override
                                                                                                                                                           public Population nextGeneration() {
                                                                                                                                                               return null; // dummy implementation
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Get iterator and attempt modification
                                                                                                                                                       Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                                       iterator.next();
                                                                                                                                                       
                                                                                                                                                       try {
                                                                                                                                                           iterator.remove();
                                                                                                                                                           // If we get here, modification was allowed (original behavior)
                                                                                                                                                           // Verify the list was actually modified
                                                                                                                                                           assertEquals(1, population.getChromosomes().size());
                                                                                                                                                       } catch (UnsupportedOperationException e) {
                                                                                                                                                           // If we get here, the mutant was detected
                                                                                                                                                           fail("Iterator should allow modification but threw UnsupportedOperationException");
                                                                                                                                                       }
                                                                                                                                                   }

    @Test
                                                                                                                                  public void testIteratorReturnsDirectListIterator() {
                                                                                                                                      // Create a concrete subclass for testing
                                                                                                                                      class TestPopulation extends ListPopulation {
                                                                                                                                          public TestPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                                                                                              super(chromosomes, populationLimit);
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          @Override
                                                                                                                                          public Population nextGeneration() {
                                                                                                                                              // Stub implementation for testing
                                                                                                                                              return this;
                                                                                                                                          }
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Setup test data
                                                                                                                                      List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                      chromosomes.add(mock(Chromosome.class));
                                                                                                                                      chromosomes.add(mock(Chromosome.class));
                                                                                                                                      
                                                                                                                                      // Create concrete population instance
                                                                                                                                      ListPopulation population = new TestPopulation(chromosomes, 10);
                                                                                                                                      
                                                                                                                                      // Get iterators
                                                                                                                                      Iterator<Chromosome> listIterator = chromosomes.iterator();
                                                                                                                                      Iterator<Chromosome> populationIterator = population.iterator();
                                                                                                                                      
                                                                                                                                      // The original implementation should return the exact same iterator
                                                                                                                                      // The mutant will return a different iterator implementation
                                                                                                                                      assertSame("Iterator should be the same as list's iterator", 
                                                                                                                                                listIterator.getClass(), 
                                                                                                                                                populationIterator.getClass());
                                                                                                                                      
                                                                                                                                      // Also verify behavior with concurrent modification
                                                                                                                                      Iterator<Chromosome> iter = population.iterator();
                                                                                                                                      population.addChromosome(mock(Chromosome.class));
                                                                                                                                      try {
                                                                                                                                          iter.next(); // Original list iterator should fail fast
                                                                                                                                          fail("Expected ConcurrentModificationException");
                                                                                                                                      } catch (java.util.ConcurrentModificationException expected) {
                                                                                                                                          // Expected behavior for original implementation
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                             public void testIteratorReturnsSequentialIterator() {
                                                                                                                 // Setup test data
                                                                                                                 List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                 chromosomes.add(mock(Chromosome.class));
                                                                                                                 chromosomes.add(mock(Chromosome.class));
                                                                                                                 chromosomes.add(mock(Chromosome.class));
                                                                                                                 
                                                                                                                 // Create concrete population instance by defining a concrete subclass
                                                                                                                 class ConcretePopulation extends ListPopulation {
                                                                                                                     public ConcretePopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                                                                         super(chromosomes, populationLimit);
                                                                                                                     }
                                                                                                                     
                                                                                                                     @Override
                                                                                                                     public Population nextGeneration() {
                                                                                                                         // Stub implementation for testing
                                                                                                                         return this;
                                                                                                                     }
                                                                                                                 }
                                                                                                                 ListPopulation population = new ConcretePopulation(chromosomes, 3);
                                                                                                                 
                                                                                                                 // Get iterator and verify behavior
                                                                                                                 Iterator<Chromosome> iterator = population.iterator();
                                                                                                                 
                                                                                                                 // Verify iteration order matches original list
                                                                                                                 assertSame(chromosomes.get(0), iterator.next());
                                                                                                                 assertSame(chromosomes.get(1), iterator.next());
                                                                                                                 assertSame(chromosomes.get(2), iterator.next());
                                                                                                                 assertFalse(iterator.hasNext());
                                                                                                                 
                                                                                                                 // Verify iterator characteristics by checking the underlying list's spliterator
                                                                                                                 java.util.Spliterator<Chromosome> spliterator = chromosomes.spliterator();
                                                                                                                 assertFalse(spliterator.hasCharacteristics(java.util.Spliterator.CONCURRENT));
                                                                                                                 assertFalse(spliterator.hasCharacteristics(java.util.Spliterator.IMMUTABLE));
                                                                                                             }

    @Test
                                                                                    public void testIteratorReturnsDirectListIterator1() {
                                                                                        // Create a concrete subclass of ListPopulation for testing
                                                                                        class TestPopulation extends ListPopulation {
                                                                                            TestPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                                                super(chromosomes, populationLimit);
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public Population nextGeneration() {
                                                                                                return new TestPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
                                                                                            }
                                                                                        }
                                                                                        
                                                                                        // Setup test data
                                                                                        List<Chromosome> chromosomes = new ArrayList<>();
                                                                                        chromosomes.add(mock(Chromosome.class));
                                                                                        chromosomes.add(mock(Chromosome.class));
                                                                                        
                                                                                        // Create ListPopulation instance using concrete subclass
                                                                                        ListPopulation population = new TestPopulation(chromosomes, 10);
                                                                                        
                                                                                        // Get the iterator
                                                                                        Iterator<Chromosome> iterator = population.iterator();
                                                                                        
                                                                                        // Verify it's the direct list iterator (not stream iterator)
                                                                                        // ArrayList's iterator is typically implemented as Itr inner class
                                                                                        assertTrue("Iterator should be direct list iterator", 
                                                                                                   iterator.getClass().getName().contains("$Itr"));
                                                                                        
                                                                                        // Verify iteration behavior
                                                                                        assertTrue(iterator.hasNext());
                                                                                        iterator.next();
                                                                                        assertTrue(iterator.hasNext());
                                                                                        iterator.next();
                                                                                        assertFalse(iterator.hasNext());
                                                                                        
                                                                                        // Verify concurrent modification detection
                                                                                        try {
                                                                                            population.addChromosome(mock(Chromosome.class));
                                                                                            iterator.hasNext(); // Should throw ConcurrentModificationException
                                                                                            fail("Expected ConcurrentModificationException");
                                                                                        } catch (java.util.ConcurrentModificationException e) {
                                                                                            // Expected behavior for list iterator
                                                                                        }
                                                                                    }

    @Test
                                                                           public void testIteratorMaintainsOriginalOrder() {
                                                                               // Create concrete Chromosome implementation for testing
                                                                               class TestChromosome extends Chromosome {
                                                                                   @Override
                                                                                   public double fitness() {
                                                                                       return 0; // dummy implementation for testing
                                                                                   }
                                                                               }
                                                                               
                                                                               // Create concrete ListPopulation implementation for testing
                                                                               class TestPopulation extends ListPopulation {
                                                                                   public TestPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                                       super(chromosomes, populationLimit);
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   public Population nextGeneration() {
                                                                                       // dummy implementation for testing
                                                                                       return new TestPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
                                                                                   }
                                                                               }
                                                                               
                                                                               // Create test data with ordered chromosomes
                                                                               List<Chromosome> chromosomes = new ArrayList<>();
                                                                               chromosomes.add(new TestChromosome());
                                                                               chromosomes.add(new TestChromosome());
                                                                               chromosomes.add(new TestChromosome());
                                                                               
                                                                               // Create population with test data
                                                                               ListPopulation population = new TestPopulation(chromosomes, 3);
                                                                               
                                                                               // Get iterator and verify order
                                                                               Iterator<Chromosome> iterator = population.iterator();
                                                                               List<Chromosome> iteratedChromosomes = new ArrayList<>();
                                                                               while (iterator.hasNext()) {
                                                                                   iteratedChromosomes.add(iterator.next());
                                                                               }
                                                                               
                                                                               // Verify order matches original
                                                                               assertEquals("Iterator should maintain original order", 
                                                                                           chromosomes, 
                                                                                           iteratedChromosomes);
                                                                               
                                                                               // Also verify size matches
                                                                               assertEquals("Iterator should return all elements",
                                                                                           chromosomes.size(),
                                                                                           iteratedChromosomes.size());
                                                                           }

    @Test
                                                                  public void testIteratorShouldAllowModificationWhenNotUnmodifiable() {
                                                                      // Setup test data
                                                                      List<Chromosome> chromosomes = new ArrayList<>();
                                                                      chromosomes.add(mock(Chromosome.class));
                                                                      chromosomes.add(mock(Chromosome.class));
                                                                      
                                                                      // Create concrete subclass for testing
                                                                      class ConcretePopulation extends ListPopulation {
                                                                          ConcretePopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                              super(chromosomes, populationLimit);
                                                                          }
                                                                          
                                                                          @Override
                                                                          public Population nextGeneration() {
                                                                              // Stub implementation for testing
                                                                              return new ConcretePopulation(new ArrayList<Chromosome>(), getPopulationLimit());
                                                                          }
                                                                      }
                                                                      ListPopulation population = new ConcretePopulation(chromosomes, 10);
                                                                      
                                                                      // Get iterator and attempt modification
                                                                      Iterator<Chromosome> iterator = population.iterator();
                                                                      iterator.next(); // Move to first element
                                                                      iterator.remove(); // This should throw UnsupportedOperationException for mutated version
                                                                      
                                                                      // If we reach here, the test fails (for mutated version)
                                                                      // For original version, this assertion would verify the removal
                                                                      assertEquals(1, population.getChromosomes().size());
                                                                  }

    @Test
                                                     public void testIteratorReturnsDirectListIterator2() {
                                                         // Setup test data
                                                         List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                         chromosomes.add(mock(Chromosome.class));
                                                         chromosomes.add(mock(Chromosome.class));
                                                         
                                                         // Create concrete subclass of ListPopulation for testing
                                                         ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                             // Implement the abstract method
                                                             @Override
                                                             public Population nextGeneration() {
                                                                 return new ListPopulation(getChromosomes(), getPopulationLimit()) {
                                                                     @Override
                                                                     public Population nextGeneration() {
                                                                         return null;
                                                                     }
                                                                 };
                                                             }
                                                         };
                                                         
                                                         // Get the iterator
                                                         Iterator<Chromosome> iterator = population.iterator();
                                                         
                                                         // Verify the iterator is directly from ArrayList (not from Stream)
                                                         // ArrayList's iterator is of type Itr (a private inner class)
                                                         // While Stream's iterator would be of type IteratorSpliterator
                                                         assertTrue("Iterator should be directly from ArrayList", 
                                                             iterator.getClass().getName().contains("ArrayList$Itr"));
                                                         
                                                         // Verify iteration behavior
                                                         assertTrue(iterator.hasNext());
                                                         iterator.next();
                                                         assertTrue(iterator.hasNext());
                                                         iterator.next();
                                                         assertFalse(iterator.hasNext());
                                                     }

    @Test
                             public void testIteratorReflectsConcurrentModifications() {
                                 // Setup test data
                                 List<Chromosome> chromosomes = new ArrayList<>();
                                 Chromosome chr1 = mock(Chromosome.class);
                                 chromosomes.add(chr1);
                                 
                                 // Create population using anonymous subclass with nextGeneration implementation
                                 ListPopulation population = new ListPopulation(chromosomes, 10) {
                                     @Override
                                     public Population nextGeneration() {
                                         return new ListPopulation(new ArrayList<Chromosome>(), getPopulationLimit()) {
                                             @Override
                                             public Population nextGeneration() {
                                                 return null;
                                             }
                                         };
                                     }
                                 };
                                 
                                 // Get the iterator
                                 Iterator<Chromosome> iterator = population.iterator();
                                 
                                 // Modify the underlying collection
                                 Chromosome chr2 = mock(Chromosome.class);
                                 population.addChromosome(chr2);
                                 
                                 // Verify concurrent modification is detected
                                 try {
                                     iterator.next();
                                     fail("Expected ConcurrentModificationException");
                                 } catch (java.util.ConcurrentModificationException e) {
                                     // Expected behavior for direct List iterator
                                 }
                             }

    @Test
    public void testIteratorOrderConsistency() {
        // Setup test data - create chromosomes with distinct values
        List<Chromosome> chromosomes = new ArrayList<>();
        chromosomes.add(new Chromosome() {
            @Override
            public double fitness() {
                return 0;
            }
        });
        chromosomes.add(new Chromosome() {
            @Override
            public double fitness() {
                return 1;
            }
        });
        chromosomes.add(new Chromosome() {
            @Override
            public double fitness() {
                return 2;
            }
        });
        
        // Create concrete ListPopulation subclass for testing
        class ConcreteListPopulation extends ListPopulation {
            public ConcreteListPopulation(List<Chromosome> chromosomes, int populationLimit) {
                super(chromosomes, populationLimit);
            }
            
            @Override
            public Population nextGeneration() {
                return new ConcreteListPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
            }
        }
        ListPopulation population = new ConcreteListPopulation(chromosomes, 10);
        
        // Get iterator and verify order matches original list
        Iterator<Chromosome> iterator = population.iterator();
        int index = 0;
        while (iterator.hasNext()) {
            Chromosome expected = chromosomes.get(index++);
            Chromosome actual = iterator.next();
            // This will fail for parallelStream iterator due to potential reordering
            assertSame("Iterator should return chromosomes in original order", 
                      expected, actual);
        }
        
        // Verify we iterated through all elements
        assertEquals("Should iterate through all chromosomes", 
                   chromosomes.size(), index);
    }


}
