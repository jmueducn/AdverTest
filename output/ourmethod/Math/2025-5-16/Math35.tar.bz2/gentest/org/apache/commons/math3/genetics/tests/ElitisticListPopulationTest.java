package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.Collections;
import java.util.List;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
 
public class ElitisticListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                    public void testConstructor_ValidParameters() {
                                                                                                                                                                                        // Test with typical valid values
                                                                                                                                                                                        ElitisticListPopulation population = new ElitisticListPopulation(100, 0.2);
                                                                                                                                                                                        assertEquals(100, population.getPopulationLimit());
                                                                                                                                                                                        assertEquals(0.2, population.getElitismRate(), 0.0001);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test with minimum valid values
                                                                                                                                                                                        ElitisticListPopulation population2 = new ElitisticListPopulation(1, 0.0);
                                                                                                                                                                                        assertEquals(1, population2.getPopulationLimit());
                                                                                                                                                                                        assertEquals(0.0, population2.getElitismRate(), 0.0001);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test with maximum valid elitism rate
                                                                                                                                                                                        ElitisticListPopulation population3 = new ElitisticListPopulation(50, 1.0);
                                                                                                                                                                                        assertEquals(50, population3.getPopulationLimit());
                                                                                                                                                                                        assertEquals(1.0, population3.getElitismRate(), 0.0001);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testConstructor_InvalidPopulationLimit() {
                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                        new ElitisticListPopulation(0, 0.5);  // populationLimit must be >= 1
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testConstructor_NegativePopulationLimit() {
                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                        new ElitisticListPopulation(-10, 0.5);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testConstructor_ElitismRateBelowZero() {
                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                        new ElitisticListPopulation(100, -0.1);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testConstructor_ElitismRateAboveOne() {
                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                        new ElitisticListPopulation(100, 1.1);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testConstructor_ExtremeValidValues() {
                                                                                                                                                                                        // Test with very large population limit
                                                                                                                                                                                        ElitisticListPopulation population = new ElitisticListPopulation(Integer.MAX_VALUE, 0.5);
                                                                                                                                                                                        assertEquals(Integer.MAX_VALUE, population.getPopulationLimit());
                                                                                                                                                                                        assertEquals(0.5, population.getElitismRate(), 0.0001);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test with very small but valid elitism rate
                                                                                                                                                                                        ElitisticListPopulation population2 = new ElitisticListPopulation(100, Double.MIN_VALUE);
                                                                                                                                                                                        assertEquals(100, population2.getPopulationLimit());
                                                                                                                                                                                        assertEquals(Double.MIN_VALUE, population2.getElitismRate(), 0.0001);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                            public void testConstructor_ValidParameters1() {
                                                                                                                                                                                // Setup
                                                                                                                                                                                org.apache.commons.math3.genetics.Chromosome chrom1 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                                                                                                                                                org.apache.commons.math3.genetics.Chromosome chrom2 = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                                                                                                                                                java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = java.util.Arrays.asList(chrom1, chrom2);
                                                                                                                                                                                int populationLimit = 10;
                                                                                                                                                                                double elitismRate = 0.2;
                                                                                                                                                                            
                                                                                                                                                                                // Test
                                                                                                                                                                                org.apache.commons.math3.genetics.ElitisticListPopulation population = 
                                                                                                                                                                                    new org.apache.commons.math3.genetics.ElitisticListPopulation(
                                                                                                                                                                                        chromosomes, populationLimit, elitismRate);
                                                                                                                                                                            
                                                                                                                                                                                // Verify
                                                                                                                                                                                assertEquals(populationLimit, population.getPopulationLimit());
                                                                                                                                                                                assertEquals(elitismRate, population.getElitismRate(), 0.0001);
                                                                                                                                                                                assertEquals(2, population.getPopulationSize());
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testConstructor_ZeroElitismRate() {
                                                                                                                                                                                // Setup
                                                                                                                                                                                Chromosome chrom = mock(Chromosome.class);
                                                                                                                                                                                List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                                                                                chromosomes.add(chrom);
                                                                                                                                                                                int populationLimit = 5;
                                                                                                                                                                                double elitismRate = 0.0;
                                                                                                                                                                            
                                                                                                                                                                                // Test
                                                                                                                                                                                ElitisticListPopulation population = new ElitisticListPopulation(
                                                                                                                                                                                    chromosomes, populationLimit, elitismRate);
                                                                                                                                                                            
                                                                                                                                                                                // Verify
                                                                                                                                                                                assertEquals(0.0, population.getElitismRate(), 0.0001);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testConstructor_EmptyChromosomes() {
                                                                                                                                                                                // Setup
                                                                                                                                                                                java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = java.util.Collections.emptyList();
                                                                                                                                                                                int populationLimit = 5;
                                                                                                                                                                                double elitismRate = 0.3;
                                                                                                                                                                            
                                                                                                                                                                                // Test
                                                                                                                                                                                org.apache.commons.math3.genetics.ElitisticListPopulation population = 
                                                                                                                                                                                    new org.apache.commons.math3.genetics.ElitisticListPopulation(
                                                                                                                                                                                        chromosomes, populationLimit, elitismRate);
                                                                                                                                                                            
                                                                                                                                                                                // Verify
                                                                                                                                                                                assertEquals(0, population.getPopulationSize());
                                                                                                                                                                                assertEquals(elitismRate, population.getElitismRate(), 0.0001);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testConstructor_NegativePopulationLimit_ThrowsException() {
                                                                                                                                                                                // Setup
                                                                                                                                                                                org.apache.commons.math3.genetics.Chromosome chrom = mock(org.apache.commons.math3.genetics.Chromosome.class);
                                                                                                                                                                                java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = java.util.Arrays.asList(chrom);
                                                                                                                                                                                int invalidPopulationLimit = -5;
                                                                                                                                                                                double elitismRate = 0.2;
                                                                                                                                                                                
                                                                                                                                                                                // Expect exception
                                                                                                                                                                                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                
                                                                                                                                                                                // Test
                                                                                                                                                                                new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, invalidPopulationLimit, elitismRate);
                                                                                                                                                                            }

    @Test
                                                                                                                                    public void testConstructor_NegativeElitismRate_ThrowsException() {
                                                                                                                                        // Setup
                                                                                                                                        Chromosome chrom = mock(Chromosome.class);
                                                                                                                                        int populationLimit = 5;
                                                                                                                                        double invalidElitismRate = -0.1;
                                                                                                                                        
                                                                                                                                        // Setup exception expectation
                                                                                                                                        ExpectedException expectedException = ExpectedException.none();
                                                                                                                                        expectedException.expect(IllegalArgumentException.class);
                                                                                                                                        expectedException.expectMessage("Elitism rate (-0.1) must be in [0,1] range");
                                                                                                                                        
                                                                                                                                        // Test
                                                                                                                                    }

    @Test
                                                                                            public void testConstructor_MaxElitismRate() {
                                                                                                // Setup
                                                                                                int populationLimit = 100;
                                                                                                double maxElitismRate = 1.0; // Maximum allowed elitism rate
                                                                                                List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                
                                                                                                // Test the constructor
                                                                                                ElitisticListPopulation population = new ElitisticListPopulation(chromosomes, populationLimit, maxElitismRate);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(populationLimit, population.getPopulationLimit());
                                                                                                assertEquals(maxElitismRate, population.getElitismRate(), 0.0001);
                                                                                                assertEquals(chromosomes, population.getChromosomes());
                                                                                            }

    @Test
                                                                                            public void testConstructor_ZeroPopulationLimit_ThrowsException() {
                                                                                                // Setup
                                                                                                int invalidPopulationLimit = 0;
                                                                                                double elitismRate = 0.2;
                                                                                                
                                                                                                // Test
                                                                                                try {
                                                                                                    new ElitisticListPopulation(invalidPopulationLimit, elitismRate);
                                                                                                    fail("Expected IllegalArgumentException");
                                                                                                } catch (IllegalArgumentException e) {
                                                                                                    assertEquals("population limit must be positive", e.getMessage());
                                                                                                }
                                                                                            }

    @Test
               public void testConstructorInitializesFieldsCorrectly() {
                   // Test data
                   int populationLimit = 100;
                   double elitismRate = 0.2;
                   
                   // Create instance
                   ElitisticListPopulation population = new ElitisticListPopulation(populationLimit, elitismRate);
                   
                   // Verify fields are set correctly
                   assertEquals("Population limit should be set correctly", 
                                populationLimit, population.getPopulationLimit());
                   assertEquals("Elitism rate should be set correctly",
                                elitismRate, population.getElitismRate(), 0.0001);
                   
                   // Test with edge cases
                   populationLimit = 0;
                   elitismRate = 0.0;
                   population = new ElitisticListPopulation(populationLimit, elitismRate);
                   assertEquals("Population limit should handle 0 correctly",
                                populationLimit, population.getPopulationLimit());
                   assertEquals("Elitism rate should handle 0.0 correctly",
                                elitismRate, population.getElitismRate(), 0.0001);
                   
                   elitismRate = 1.0;
                   population = new ElitisticListPopulation(populationLimit, elitismRate);
                   assertEquals("Elitism rate should handle 1.0 correctly",
                                elitismRate, population.getElitismRate(), 0.0001);
               }

    @Test(expected = IllegalArgumentException.class)
               public void testNegativePopulationLimit() {
                   new ElitisticListPopulation(-1, 0.5);
               }

    @Test(expected = IllegalArgumentException.class)
               public void testNegativeElitismRate() {
                   new ElitisticListPopulation(100, -0.1);
               }

    @Test(expected = IllegalArgumentException.class)
               public void testElitismRateGreaterThanOne() {
                   new ElitisticListPopulation(100, 1.1);
               }

    @Test
          public void testConstructorWithPopulationLimitAndElitismRate() {
              // Test data
              int populationLimit = 100;
              double elitismRate = 0.2;
              
              // Create instance
              ElitisticListPopulation population = new ElitisticListPopulation(populationLimit, elitismRate);
              
              // Verify elitismRate was set correctly
              assertEquals(elitismRate, population.getElitismRate(), 0.0001);
              
              // Test with edge cases
              // Zero population limit
              try {
                  new ElitisticListPopulation(0, 0.1);
                  fail("Should throw IllegalArgumentException for zero population limit");
              } catch (IllegalArgumentException e) {
                  // Expected
              }
              
              // Negative elitism rate
              try {
                  new ElitisticListPopulation(10, -0.1);
                  fail("Should throw IllegalArgumentException for negative elitism rate");
              } catch (IllegalArgumentException e) {
                  // Expected
              }
              
              // Elitism rate > 1
              try {
                  new ElitisticListPopulation(10, 1.1);
                  fail("Should throw IllegalArgumentException for elitism rate > 1");
              } catch (IllegalArgumentException e) {
                  // Expected
              }
          }

    @Test
          public void testConstructorSetsElitismRateCorrectly() {
              // Prepare test data
              List<Chromosome> chromosomes = new ArrayList<>();
              int populationLimit = 100;
              double testRate = 0.3;
              
              // Create instance
              ElitisticListPopulation population = new ElitisticListPopulation(
                  chromosomes, populationLimit, testRate);
                  
              // Verify elitism rate was set correctly
              assertEquals("Elitism rate should be set to 0.3", 
                  testRate, population.getElitismRate(), 0.0001);
          }

    @Test
          public void testBoundaryElitismRates() {
              List<Chromosome> chromosomes = new ArrayList<>();
              int populationLimit = 100;
              
              // Test minimum boundary (0.0)
              ElitisticListPopulation zeroPopulation = new ElitisticListPopulation(
                  chromosomes, populationLimit, 0.0);
              assertEquals(0.0, zeroPopulation.getElitismRate(), 0.0001);
              
              // Test maximum boundary (1.0)
              ElitisticListPopulation fullPopulation = new ElitisticListPopulation(
                  chromosomes, populationLimit, 1.0);
              assertEquals(1.0, fullPopulation.getElitismRate(), 0.0001);
          }

    @Test(expected = IllegalArgumentException.class)
          public void testNegativeElitismRateThrowsException() {
              List<Chromosome> chromosomes = new ArrayList<>();
              int populationLimit = 100;
              // This should throw IllegalArgumentException
              new ElitisticListPopulation(chromosomes, populationLimit, -0.1);
          }

    @Test(expected = IllegalArgumentException.class)
          public void testTooLargeElitismRateThrowsException() {
              List<Chromosome> chromosomes = new ArrayList<>();
              int populationLimit = 100;
              // This should throw IllegalArgumentException
              new ElitisticListPopulation(chromosomes, populationLimit, 1.1);
          }

    @Test
      public void testConstructorSetsElitismRate() {
          // Arrange
          int populationLimit = 100;
          double expectedElitismRate = 0.2;
          
          // Act
          ElitisticListPopulation population = new ElitisticListPopulation(populationLimit, expectedElitismRate);
          
          // Assert
          assertEquals("Elitism rate should be set by constructor", 
                       expectedElitismRate, 
                       population.getElitismRate(), 
                       0.0001);
      }

    @Test
         public void testConstructorSetsElitismRateCorrectlyWhenParameterModified() {
             // Create a subclass that attempts to modify the parameter before setting
             class TestPopulation extends ElitisticListPopulation {
                 public TestPopulation(int populationLimit, double elitismRate) {
                     super(populationLimit, elitismRate);
                     // Attempt to modify the parameter (would only work if not final)
                     elitismRate = elitismRate * 2;
                 }
             }
             
             double testRate = 0.5;
             int limit = 100;
             TestPopulation population = new TestPopulation(limit, testRate);
             
             // Verify the field was set to the original value, not the modified one
             assertEquals("Elitism rate should be set to original parameter value", 
                         testRate, population.getElitismRate(), 0.0001);
         }

    @Test
    public void testConstructorWithModifiedParameterShouldUseOriginalValue() {
        // Arrange
        int populationLimit = 100;
        double originalElitismRate = 0.2;
        double modifiedElitismRate = 0.5; // Different value to test if parameter is modified
        
        // Create an anonymous subclass that attempts to modify the parameter
        ElitisticListPopulation population = new ElitisticListPopulation(populationLimit, originalElitismRate) {
            {
                try {
                    // Use reflection to access the private field
                    Field elitismRateField = ElitisticListPopulation.class.getDeclaredField("elitismRate");
                    elitismRateField.setAccessible(true);
                    elitismRateField.set(this, modifiedElitismRate);
                } catch (Exception e) {
                    fail("Failed to modify elitismRate field via reflection");
                }
            }
        };
        
        // Assert
        // If parameter was properly protected (original), this would be originalElitismRate
        // If parameter was not protected (mutant), this would be modifiedElitismRate
        assertEquals("Elitism rate should use original passed value, not modified parameter", 
                    originalElitismRate, population.getElitismRate(), 0.0001);
    }


}
