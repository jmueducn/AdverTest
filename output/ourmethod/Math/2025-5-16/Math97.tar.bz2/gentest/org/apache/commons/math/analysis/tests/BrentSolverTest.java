package gentest.org.apache.commons.math.analysis.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
 
public class BrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                            public void testSolve_InitialGuessIsRoot_ReturnsInitial() throws Exception {
                                                                                                                                                                                                                                                                // Define accuracy constant
                                                                                                                                                                                                                                                                final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Initialize solver
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                                assertEquals(1.5, result, FUNCTION_VALUE_ACCURACY);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_MinIsRoot_ReturnsMin() throws Exception {
                                                                                                                                                                                                                                                                // Define accuracy constant
                                                                                                                                                                                                                                                                final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(0.5);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Initialize solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test and verify
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                                assertEquals(1.0, result, FUNCTION_VALUE_ACCURACY);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_MaxIsRoot_ReturnsMax() throws Exception {
                                                                                                                                                                                                                                                                // Define accuracy constant
                                                                                                                                                                                                                                                                final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                                assertEquals(2.0, result, FUNCTION_VALUE_ACCURACY);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_RootBetweenMinAndInitial_CallsSolveWithReducedInterval() throws Exception {
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(0.5);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mocked function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // We can't easily verify the internal solve call, but we can check it doesn't return immediately
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                                assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_RootBetweenInitialAndMax_CallsSolveWithReducedInterval() throws Exception {
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mocked function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test the solve method
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                                assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_NoRootInInterval_ReturnsApproximateSolution() throws Exception {
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(0.5);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(0.25);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Should still return something within the interval
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                                assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_WithTwoArgMethod_UsesMidpointAsInitial() throws Exception {
                                                                                                                                                                                                                                                                // Define accuracy constant
                                                                                                                                                                                                                                                                final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(0.0); // midpoint is root
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test and verify
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                                assertEquals(1.5, result, FUNCTION_VALUE_ACCURACY);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_RootAtMin() throws Exception {
                                                                                                                                                                                                                                                                // Define test constants
                                                                                                                                                                                                                                                                final double EPSILON = 1e-6;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test and verify
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                                assertEquals(1.0, result, EPSILON);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_RootAtMax() throws Exception {
                                                                                                                                                                                                                                                                // Define test constants
                                                                                                                                                                                                                                                                final double EPSILON = 1e-6;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with the mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test and verify
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                                assertEquals(2.0, result, EPSILON);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_BracketingRoot() throws Exception {
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                // Mock the private solve method's behavior through the function
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                                // Since we can't mock the private solve method directly, we can only verify it's called
                                                                                                                                                                                                                                                                // The actual value would depend on the implementation of the private solve method
                                                                                                                                                                                                                                                                assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_CloseToZeroAtMin() throws Exception {
                                                                                                                                                                                                                                                                // Define test constants
                                                                                                                                                                                                                                                                final double EPSILON = 1e-10;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(1e-7);  // Below functionValueAccuracy (1E-6)
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test and verify
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                                assertEquals(1.0, result, EPSILON);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_CloseToZeroAtMax() throws Exception {
                                                                                                                                                                                                                                                                // Define constants
                                                                                                                                                                                                                                                                final double EPSILON = 1e-10;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(-1e-7);  // Below functionValueAccuracy (1E-6)
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test and verify
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                                assertEquals(2.0, result, EPSILON);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_InvalidIntervalThrowsException() throws Exception {
                                                                                                                                                                                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create a simple mock function that returns 0 for any input
                                                                                                                                                                                                                                                                UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public double value(double x) {
                                                                                                                                                                                                                                                                        return 0;
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                solver.solve(2.0, 1.0);  // min > max
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_EqualEndpointsWithRoot() throws Exception {
                                                                                                                                                                                                                                                                // Define test constants
                                                                                                                                                                                                                                                                final double EPSILON = 1e-6;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Initialize solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test equal endpoints with root
                                                                                                                                                                                                                                                                double result = solver.solve(1.0, 1.0);
                                                                                                                                                                                                                                                                assertEquals(1.0, result, EPSILON);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_NanInputThrowsException() throws Exception {
                                                                                                                                                                                                                                                                // Setup expected exception rule
                                                                                                                                                                                                                                                                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                                exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock function and solver
                                                                                                                                                                                                                                                                org.apache.commons.math.analysis.UnivariateRealFunction f = new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                                                                                                                                                                                    public double value(double x) {
                                                                                                                                                                                                                                                                        return x;
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                org.apache.commons.math.analysis.BrentSolver solver = new org.apache.commons.math.analysis.BrentSolver(f);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test with NaN input
                                                                                                                                                                                                                                                                solver.solve(Double.NaN, 1.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testSolve_UsesBisectionWhenProgressIsSlow() throws Exception {
                                                                                                                                                                                                                                                                // Create mock function
                                                                                                                                                                                                                                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Setup mock function behavior
                                                                                                                                                                                                                                                                when(function.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                                when(function.value(2.0)).thenReturn(0.4);
                                                                                                                                                                                                                                                                when(function.value(3.0)).thenReturn(-0.5);
                                                                                                                                                                                                                                                                when(function.value(1.5)).thenReturn(0.2);
                                                                                                                                                                                                                                                                when(function.value(1.75)).thenReturn(-0.1);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access private solve method
                                                                                                                                                                                                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "solve", double.class, double.class, double.class, 
                                                                                                                                                                                                                                                                    double.class, double.class, double.class);
                                                                                                                                                                                                                                                                solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test case where bisection is forced due to slow progress
                                                                                                                                                                                                                                                                double result = (Double)solveMethod.invoke(
                                                                                                                                                                                                                                                                    solver, 1.0, 0.5, 2.0, 0.4, 3.0, -0.5);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Should converge somewhere between 1.5 and 2.0
                                                                                                                                                                                                                                                                assertTrue(result >= 1.5 && result <= 2.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_ConvergesWithFunctionValueAccuracy() throws Exception {
                                                                                                                                                                                                                                                            // Create mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            // Setup mock function behavior
                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                            when(function.value(2.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                            when(function.value(3.0)).thenReturn(-0.5);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Create solver with mock function
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get the private solve method using reflection
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Invoke the private method
                                                                                                                                                                                                                                                            double result = (Double) solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                1.0, 0.0, 
                                                                                                                                                                                                                                                                2.0, 0.5, 
                                                                                                                                                                                                                                                                3.0, -0.5
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            assertEquals(1.0, result, 0.0001);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_ConvergesWithTolerance() throws Exception {
                                                                                                                                                                                                                                                            // Create mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Setup mock function behavior
                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(0.1);
                                                                                                                                                                                                                                                            when(function.value(1.1)).thenReturn(0.05);
                                                                                                                                                                                                                                                            when(function.value(1.2)).thenReturn(-0.05);
                                                                                                                                                                                                                                                            when(function.value(1.05)).thenReturn(0.000001); // Within tolerance
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Create solver with mock function
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get the private solve method via reflection
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Invoke the private method
                                                                                                                                                                                                                                                            double result = (Double) solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                1.0, 0.1, 
                                                                                                                                                                                                                                                                1.1, 0.05, 
                                                                                                                                                                                                                                                                1.2, -0.05
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            assertEquals(1.05, result, 0.0001);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_UsesInverseQuadraticInterpolation() throws Exception {
                                                                                                                                                                                                                                                            // Create mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Setup mock function behavior
                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                            when(function.value(2.0)).thenReturn(0.4);
                                                                                                                                                                                                                                                            when(function.value(3.0)).thenReturn(-0.5);
                                                                                                                                                                                                                                                            when(function.value(2.2)).thenReturn(0.1);
                                                                                                                                                                                                                                                            when(function.value(2.4)).thenReturn(-0.1);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Initialize solver with mock function
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get the private solve method via reflection
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Test case where inverse quadratic interpolation is used
                                                                                                                                                                                                                                                            double result = (Double)solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                1.0, 0.5, 
                                                                                                                                                                                                                                                                2.0, 0.4, 
                                                                                                                                                                                                                                                                3.0, -0.5
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Should converge somewhere between 2.0 and 3.0
                                                                                                                                                                                                                                                            assertTrue(result >= 2.0 && result <= 3.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_SwapsPointsWhenY2IsBetter() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Setup mock function behavior
                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                            when(function.value(2.0)).thenReturn(0.4);
                                                                                                                                                                                                                                                            when(function.value(3.0)).thenReturn(0.1); // y2 is better than y1
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get the private solve method via reflection
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Invoke the private method
                                                                                                                                                                                                                                                            double result = (Double) solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                1.0, 0.5, 
                                                                                                                                                                                                                                                                2.0, 0.4, 
                                                                                                                                                                                                                                                                3.0, 0.1
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // The method should first swap x1 and x2 since y2 is better
                                                                                                                                                                                                                                                            assertTrue(result >= 2.0 && result <= 3.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_HandlesLinearInterpolationCase() throws Exception {
                                                                                                                                                                                                                                                            // Create mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            // Setup mock function behavior for x0 == x2 case (linear interpolation)
                                                                                                                                                                                                                                                            when(function.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                            when(function.value(2.0)).thenReturn(0.4);
                                                                                                                                                                                                                                                            when(function.value(1.5)).thenReturn(0.1);
                                                                                                                                                                                                                                                            when(function.value(1.6)).thenReturn(-0.1);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Create solver with mock function
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get the private solve method using reflection
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", double.class, double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, double.class);
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Invoke the private method
                                                                                                                                                                                                                                                            double result = (Double) solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 1.0, 0.5, 1.0, 0.5, 2.0, 0.4);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Should converge somewhere between 1.0 and 2.0
                                                                                                                                                                                                                                                            assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_NoBracketingThrowsException() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                        when(function.value(2.0)).thenReturn(2.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Exception verification
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                            assertEquals("Function values at endpoints do not have different signs.", e.getMessage());
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_ThrowsMaxIterationsExceeded() throws Exception {
                                                                                                                                                                                                                                                        // Setup mock function that never converges
                                                                                                                                                                                                                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(function.value(anyDouble())).thenReturn(1.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Initialize solver with mock function
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Get the private solve method via reflection
                                                                                                                                                                                                                                                        Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                            "solve", 
                                                                                                                                                                                                                                                            double.class, double.class, double.class, 
                                                                                                                                                                                                                                                            double.class, double.class, double.class
                                                                                                                                                                                                                                                        );
                                                                                                                                                                                                                                                        solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Set up exception expectation
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            // Invoke the private method
                                                                                                                                                                                                                                                            solveMethod.invoke(solver, 1.0, 1.0, 2.0, 1.0, 3.0, 1.0);
                                                                                                                                                                                                                                                            fail("Expected MaxIterationsExceededException");
                                                                                                                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                            assertTrue(e.getCause() instanceof MaxIterationsExceededException);
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                    public void testSolve_EqualEndpointsWithoutRoot() throws Exception {
                                                                                                                                                                                                                        // Set up expected exception
                                                                                                                                                                                                                        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                        exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Create mock function that returns same sign for equal endpoints
                                                                                                                                                                                                                        org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                                                                                                                                                                                            new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                                                                                                                                                public double value(double x) {
                                                                                                                                                                                                                                    return 1.0; // Always positive, no root
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        org.apache.commons.math.analysis.BrentSolver solver = new org.apache.commons.math.analysis.BrentSolver(function);
                                                                                                                                                                                                                        solver.solve(1.0, 1.0);
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                public void testSolve_InitialGuessOutsideInterval_ThrowsException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                    when(function.value(2.0)).thenReturn(2.0);
                                                                                                                                                                                                                    when(function.value(3.0)).thenReturn(3.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        solver.solve(2.0, 3.0, 1.0); // initial=1.0 outside [2.0,3.0]
                                                                                                                                                                                                                        fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                        assertEquals("Initial guess is not in search interval", e.getMessage());
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testSignCalculationDetectsDifferentSigns() throws Exception {
                                                                                                                                                                                                                    // Create mock function
                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Setup test case where yMin and yMax have different signs
                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(-2.0);  // yMin = -2.0
                                                                                                                                                                                                                    when(f.value(3.0)).thenReturn(4.0);   // yMax = 4.0
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        double result = solver.solve(1.0, 3.0);
                                                                                                                                                                                                                        // If the mutant is present (using subtraction), it might incorrectly process the bracket
                                                                                                                                                                                                                        // We can verify the function was called with expected values
                                                                                                                                                                                                                        verify(f, atLeastOnce()).value(1.0);
                                                                                                                                                                                                                        verify(f, atLeastOnce()).value(3.0);
                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                        fail("Should not throw exception for valid bracket");
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testSignCalculationDetectsSameSigns() throws Exception {
                                                                                                                                                                                                                    // Create mock function
                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Setup test case where yMin and yMax have same signs (both positive)
                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                                                                                                                                                                                                                    when(f.value(3.0)).thenReturn(4.0);  // yMax = 4.0
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        solver.solve(1.0, 3.0);
                                                                                                                                                                                                                        fail("Should throw exception when root is not bracketed");
                                                                                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                        // Expected behavior - root not bracketed
                                                                                                                                                                                                                        assertTrue(e.getMessage().contains("Function values at endpoints must have different signs"));
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                           public void testSolveDetectsSignChangeCorrectly() throws Exception {
                                                                                                                                                                                                               // Setup test case where yMin is positive and yMax is negative
                                                                                                                                                                                                               // With multiplication, sign would be negative (correct)
                                                                                                                                                                                                               // With subtraction, sign would be positive (incorrect)
                                                                                                                                                                                                               double min = 0;
                                                                                                                                                                                                               double max = 2;
                                                                                                                                                                                                               double initial = 1;
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create mock function
                                                                                                                                                                                                               UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock function values
                                                                                                                                                                                                               when(function.value(min)).thenReturn(1.0);    // yMin = 1.0 (positive)
                                                                                                                                                                                                               when(function.value(max)).thenReturn(-1.0);   // yMax = -1.0 (negative)
                                                                                                                                                                                                               when(function.value(initial)).thenReturn(0.5); // yInitial = 0.5 (positive)
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create solver with mock function
                                                                                                                                                                                                               BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // The key is that yMin*yMax would be negative (indicating root between them)
                                                                                                                                                                                                               // But yMin-yMax would be positive (2.0), which would not trigger the same logic
                                                                                                                                                                                                               
                                                                                                                                                                                                               // We expect the method to recognize the sign change and proceed accordingly
                                                                                                                                                                                                               // The mutant would miss this sign change
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Since we can't see the full implementation, we'll test that the method
                                                                                                                                                                                                               // at least doesn't throw an exception and returns a value between min and max
                                                                                                                                                                                                               double result = solver.solve(min, max, initial);
                                                                                                                                                                                                               assertTrue("Result should be between min and max", result >= min && result <= max);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify the function was called with expected values
                                                                                                                                                                                                               verify(function).value(min);
                                                                                                                                                                                                               verify(function).value(max);
                                                                                                                                                                                                               verify(function).value(initial);
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testSolveWithOppositeSignsAtEndpoints() throws Exception {
                                                                                                                                                                                                               // Create mock function
                                                                                                                                                                                                               UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                               // Create solver with mock function
                                                                                                                                                                                                               BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Another test case where yMin is negative and yMax is positive
                                                                                                                                                                                                               double min = 0;
                                                                                                                                                                                                               double max = 2;
                                                                                                                                                                                                               double initial = 1;
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock function values
                                                                                                                                                                                                               when(function.value(min)).thenReturn(-1.0);   // yMin = -1.0 (negative)
                                                                                                                                                                                                               when(function.value(max)).thenReturn(1.0);    // yMax = 1.0 (positive)
                                                                                                                                                                                                               when(function.value(initial)).thenReturn(0.5); // yInitial = 0.5 (positive)
                                                                                                                                                                                                               
                                                                                                                                                                                                               // yMin*yMax would be negative (correct)
                                                                                                                                                                                                               // yMin-yMax would be -2.0 (negative, same sign in this case)
                                                                                                                                                                                                               // Need to ensure the test would fail if subtraction was used
                                                                                                                                                                                                               
                                                                                                                                                                                                               double result = solver.solve(min, max, initial);
                                                                                                                                                                                                               assertTrue("Result should be between min and max", result >= min && result <= max);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify the function was called with expected values
                                                                                                                                                                                                               verify(function).value(min);
                                                                                                                                                                                                               verify(function).value(max);
                                                                                                                                                                                                               verify(function).value(initial);
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                       public void testSolveDetectsSignMutation() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                           // Create a mock function where:
                                                                                                                                                                                                           // f(min) = 2 (positive)
                                                                                                                                                                                                           // f(max) = 1 (positive)
                                                                                                                                                                                                           // Product is positive (same signs) but difference is positive (2-1=1)
                                                                                                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                           when(f.value(1.0)).thenReturn(2.0); // yMin
                                                                                                                                                                                                           when(f.value(2.0)).thenReturn(1.0); // yMax
                                                                                                                                                                                                           
                                                                                                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // With original code: sign = 2*1=2 >0 → should check for near-zero or throw exception
                                                                                                                                                                                                           // With mutant: sign = 2-1=1 >0 → would incorrectly proceed to solve
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               solver.solve(1.0, 2.0);
                                                                                                                                                                                                               // If we get here, the mutant wasn't caught
                                                                                                                                                                                                               fail("Expected IllegalArgumentException for non-bracketing interval");
                                                                                                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                                                                                                               // Expected behavior for original code
                                                                                                                                                                                                               assertTrue(e.getMessage().contains("Function values at endpoints do not have different signs"));
                                                                                                                                                                                                           }
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Additional test case where signs are opposite but yMin > yMax
                                                                                                                                                                                                           // f(min) = 1 (positive)
                                                                                                                                                                                                           // f(max) = -1 (negative)
                                                                                                                                                                                                           // Product is negative (opposite signs) but difference is positive (1-(-1)=2)
                                                                                                                                                                                                           when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                           when(f.value(2.0)).thenReturn(-1.0);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // With original code: sign = 1*-1=-1 <0 → should proceed to solve
                                                                                                                                                                                                           // With mutant: sign = 1-(-1)=2 >0 → would incorrectly throw exception
                                                                                                                                                                                                           double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                           // Verify solve was called (wouldn't reach here with mutant)
                                                                                                                                                                                                           assertFalse(Double.isNaN(result));
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                  public void testSignCalculationDetectsMultiplicationMutant() throws Exception {
                                                                                                                                                                                                      // Setup test objects
                                                                                                                                                                                                      UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                      BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Case 1: yMin positive, yMax negative (sign should be negative)
                                                                                                                                                                                                      when(function.value(1.0)).thenReturn(2.0);   // yMin
                                                                                                                                                                                                      when(function.value(3.0)).thenReturn(-3.0);  // yMax
                                                                                                                                                                                                      when(function.value(2.0)).thenReturn(1.0);   // initial
                                                                                                                                                                                                      
                                                                                                                                                                                                      try {
                                                                                                                                                                                                          solver.solve(1.0, 3.0, 2.0);
                                                                                                                                                                                                          // If we get here, the mutant wasn't detected - force test failure
                                                                                                                                                                                                          fail("Expected ArithmeticException from division by zero in mutant");
                                                                                                                                                                                                      } catch (ArithmeticException e) {
                                                                                                                                                                                                          // This is expected for the mutant
                                                                                                                                                                                                          // The original would not throw this exception
                                                                                                                                                                                                      }
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Case 2: yMin is zero (should work in original, throw exception in mutant)
                                                                                                                                                                                                      when(function.value(1.0)).thenReturn(0.0);   // yMin
                                                                                                                                                                                                      when(function.value(3.0)).thenReturn(-3.0);  // yMax
                                                                                                                                                                                                      when(function.value(2.0)).thenReturn(1.0);   // initial
                                                                                                                                                                                                      
                                                                                                                                                                                                      try {
                                                                                                                                                                                                          solver.solve(1.0, 3.0, 2.0);
                                                                                                                                                                                                          // Original would proceed, mutant would throw ArithmeticException
                                                                                                                                                                                                      } catch (ArithmeticException e) {
                                                                                                                                                                                                          fail("Original code should handle yMin=0 case without exception");
                                                                                                                                                                                                      }
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                              public void testSolveDetectsSignMutation1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                  // Create a mock function that returns specific values
                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(-2.0); // yMax = -2.0
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create solver with our mock function
                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test the solve method - this should work in original but fail in mutant
                                                                                                                                                                                                  double result = solver.solve(1.0, 3.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify the mock interactions
                                                                                                                                                                                                  verify(f).value(1.0);
                                                                                                                                                                                                  verify(f).value(3.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // The key point is that with yMin=2.0 and yMax=-2.0:
                                                                                                                                                                                                  // Original: 2.0 * -2.0 = -4.0 (negative) -> will proceed to solve
                                                                                                                                                                                                  // Mutant: 2.0 / -2.0 = -1.0 (negative) -> appears same behavior
                                                                                                                                                                                                  // But if we change values to yMin=1.0, yMax=-2.0:
                                                                                                                                                                                                  // Original: 1.0 * -2.0 = -2.0 (negative)
                                                                                                                                                                                                  // Mutant: 1.0 / -2.0 = -0.5 (negative)
                                                                                                                                                                                                  // So we need a case where division gives different sign than multiplication
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Better test case - when yMin is zero
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Original: 0.0 * 1.0 = 0.0 -> will return min (1.0)
                                                                                                                                                                                                  // Mutant: 0.0 / 1.0 = 0.0 -> same behavior
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Even better - when yMax is zero
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(0.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Original: 1.0 * 0.0 = 0.0 -> will return max (3.0)
                                                                                                                                                                                                  // Mutant: 1.0 / 0.0 = Infinity -> will throw ArithmeticException
                                                                                                                                                                                                  
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      result = solver.solve(1.0, 3.0);
                                                                                                                                                                                                      // If we get here in mutant, test fails
                                                                                                                                                                                                      fail("Expected ArithmeticException in mutant version");
                                                                                                                                                                                                  } catch (ArithmeticException e) {
                                                                                                                                                                                                      // This is expected in mutant version
                                                                                                                                                                                                  }
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Another case where signs are same but values different
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(2.0);
                                                                                                                                                                                                  when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Original: 2.0 * 1.0 = 2.0 (positive)
                                                                                                                                                                                                  // Mutant: 2.0 / 1.0 = 2.0 (positive) - same behavior
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Final verification that we tested all paths
                                                                                                                                                                                                  verify(f, times(4)).value(anyDouble());
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testSignCalculationDetectsMutant() throws FunctionEvaluationException {
                                                                                                                                                                                                  // Create mock function that returns specific values
                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(2.0);  // yMin
                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(4.0);  // yMax
                                                                                                                                                                                                  
                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                  
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      // This should internally calculate the sign
                                                                                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify the function was called with expected values
                                                                                                                                                                                                      verify(f).value(1.0);
                                                                                                                                                                                                      verify(f).value(2.0);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // The actual test - if mutant exists, it might throw exception or return wrong result
                                                                                                                                                                                                      // We can't directly test the sign variable as it's private, but we can test behavior
                                                                                                                                                                                                      // that depends on it - like proper interval selection
                                                                                                                                                                                                      assertTrue("Solver should find a solution", Double.isFinite(result));
                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                      fail("Mutant should be detected by unexpected exception: " + e.getMessage());
                                                                                                                                                                                                  }
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test case with opposite signs
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-2.0);
                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(4.0);
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                      assertTrue("Solver should find a solution with opposite signs", Double.isFinite(result));
                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                      fail("Mutant should be detected by unexpected exception with opposite signs: " + e.getMessage());
                                                                                                                                                                                                  }
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test case with zero value
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(4.0);
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                      // Either the zero is the root, or we should get finite result
                                                                                                                                                                                                      assertTrue("Solver should handle zero value", 
                                                                                                                                                                                                          result == 1.0 || Double.isFinite(result));
                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                      fail("Mutant should be detected by unexpected exception with zero value: " + e.getMessage());
                                                                                                                                                                                                  }
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testSolveDetectsSignMutation2() throws Exception {
                                                                                                                                                                                                  // Setup mock function with yMin positive and yMax negative
                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(1.0);  // yMin = 1.0 (positive)
                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(-1.0); // yMax = -1.0 (negative)
                                                                                                                                                                                                  
                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // This should pass with original code (sign = -1 < 0) and try to solve
                                                                                                                                                                                                  // With mutated code (sign = 1 > 0), it would throw IllegalArgumentException
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                      // If we get here, original behavior is preserved
                                                                                                                                                                                                      // We can add additional assertions about the solution if needed
                                                                                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                                                                                      fail("Mutation detected: Method incorrectly threw exception for valid bracketing");
                                                                                                                                                                                                  }
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test opposite case: yMin negative and yMax positive
                                                                                                                                                                                                  when(f.value(1.0)).thenReturn(-1.0);  // yMin = -1.0 (negative)
                                                                                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);   // yMax = 1.0 (positive)
                                                                                                                                                                                                  
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                      // If we get here, original behavior is preserved
                                                                                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                                                                                      fail("Mutation detected: Method incorrectly threw exception for valid bracketing");
                                                                                                                                                                                                  }
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                          public void testSolveDetectsSignChange() throws Exception {
                                                                                                                                                                                              // Create a mock function that crosses zero between 1 and 2
                                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                              when(f.value(1.0)).thenReturn(-1.0);  // yMin is negative
                                                                                                                                                                                              when(f.value(2.0)).thenReturn(1.0);   // yMax is positive
                                                                                                                                                                                              
                                                                                                                                                                                              // Create solver with default parameters
                                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                              
                                                                                                                                                                                              // Test solving between 1 and 2 where the sign changes
                                                                                                                                                                                              double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify the result is between the bounds
                                                                                                                                                                                              assertTrue("Result should be between 1 and 2", result >= 1.0 && result <= 2.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify the function was called with values between 1 and 2
                                                                                                                                                                                              verify(f, atLeastOnce()).value(argThat(x -> x >= 1.0 && x <= 2.0));
                                                                                                                                                                                              
                                                                                                                                                                                              // Additional verification that the sign change was properly detected
                                                                                                                                                                                              // The original code would find the root, while the mutant might not
                                                                                                                                                                                              verify(f, atLeast(2)).value(anyDouble()); // Ensure multiple iterations occurred
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                         public void testSignCalculationDetectsMutant1() throws FunctionEvaluationException {
                                                                                                                                                                                             // Create mock function that returns specific values
                                                                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(f.value(0.0)).thenReturn(1.0);   // yMin = 1.0 (positive)
                                                                                                                                                                                             when(f.value(1.0)).thenReturn(-1.0);  // yMax = -1.0 (negative)
                                                                                                                                                                                             when(f.value(0.5)).thenReturn(0.5);   // yInitial = 0.5 (not solution)
                                                                                                                                                                                             
                                                                                                                                                                                             // Create solver with mock function
                                                                                                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                             
                                                                                                                                                                                             // Set accuracy threshold that won't be met
                                                                                                                                                                                             double functionValueAccuracy = 0.0001;
                                                                                                                                                                                             
                                                                                                                                                                                             // Test parameters where min and max bracket root (0.0 to 1.0)
                                                                                                                                                                                             // Initial guess is valid (0.5)
                                                                                                                                                                                             try {
                                                                                                                                                                                                 double result = solver.solve(0.0, 1.0, 0.5);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // If we get here, the mutant wasn't caught - fail the test
                                                                                                                                                                                                 fail("Mutant not detected - incorrect sign calculation didn't affect result");
                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                 // The original code would proceed with Brent's algorithm
                                                                                                                                                                                                 // The mutant might fail to detect the bracketing condition
                                                                                                                                                                                                 // We expect the original to work, so any exception indicates mutant behavior
                                                                                                                                                                                                 assertTrue("Mutant behavior detected by unexpected exception", false);
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the mock interactions
                                                                                                                                                                                             verify(f).value(0.0);
                                                                                                                                                                                             verify(f).value(1.0);
                                                                                                                                                                                             verify(f).value(0.5);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testSolveWithExactZeroAtInitialGuess() throws Exception {
                                                                                                                                                                                             // Setup mock function that returns zero at initial guess
                                                                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(f.value(1.5)).thenReturn(0.0);  // initial guess returns zero
                                                                                                                                                                                             when(f.value(1.0)).thenReturn(-1.0); // min
                                                                                                                                                                                             when(f.value(2.0)).thenReturn(1.0);  // max
                                                                                                                                                                                             
                                                                                                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                             solver.setFunctionValueAccuracy(1e-6);
                                                                                                                                                                                             
                                                                                                                                                                                             // Test with initial guess that gives exact zero
                                                                                                                                                                                             double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the result is the initial guess (1.5) since it's already a root
                                                                                                                                                                                             assertEquals(1.5, result, 1e-6);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the function was evaluated at the initial point
                                                                                                                                                                                             verify(f).value(1.5);
                                                                                                                                                                                             
                                                                                                                                                                                             // The mutation would potentially cause different behavior when sign=0,
                                                                                                                                                                                             // but the correct behavior is to return the initial guess immediately
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testSolveWithExactZeroAtEndpoint() throws Exception {
                                                                                                                                                                                             // Setup mock function that returns zero at min endpoint
                                                                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(f.value(1.0)).thenReturn(0.0);  // min returns zero
                                                                                                                                                                                             when(f.value(1.5)).thenReturn(0.5); // initial guess
                                                                                                                                                                                             when(f.value(2.0)).thenReturn(1.0); // max
                                                                                                                                                                                             
                                                                                                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                             solver.setFunctionValueAccuracy(1e-6);
                                                                                                                                                                                             
                                                                                                                                                                                             // Test with endpoint that gives exact zero
                                                                                                                                                                                             double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the result is the min endpoint (1.0) since it's already a root
                                                                                                                                                                                             assertEquals(1.0, result, 1e-6);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the function was evaluated at the min point
                                                                                                                                                                                             verify(f).value(1.0);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testSolveWithExactZeroAtMinShouldReturnMin() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                                                                                             when(f.value(2.0)).thenReturn(3.0);  // yMax = 3
                                                                                                                                                                                             
                                                                                                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                             
                                                                                                                                                                                             // Test - min is exactly zero (sign == 0)
                                                                                                                                                                                             double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify
                                                                                                                                                                                             assertEquals(1.0, result, 0.0001);  // Should return min
                                                                                                                                                                                             verify(f).value(1.0);
                                                                                                                                                                                             verify(f).value(2.0);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testSolveWithExactZeroAtMaxShouldReturnMax() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(f.value(1.0)).thenReturn(3.0);  // yMin = 3
                                                                                                                                                                                             when(f.value(2.0)).thenReturn(0.0);  // yMax = 0
                                                                                                                                                                                             
                                                                                                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                             
                                                                                                                                                                                             // Test - max is exactly zero (sign == 0)
                                                                                                                                                                                             double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify
                                                                                                                                                                                             assertEquals(2.0, result, 0.0001);  // Should return max
                                                                                                                                                                                             verify(f).value(1.0);
                                                                                                                                                                                             verify(f).value(2.0);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                    public void testSolveWithZeroSign() throws Exception {
                                                                                                                                                                                        // Create a mock function that returns zero at specific point
                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                        when(f.value(anyDouble())).thenReturn(1.0, 0.0, -1.0); // y0=1, y1=0, y2=-1
                                                                                                                                                                                        
                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                        
                                                                                                                                                                                        // Set up test values where y1 will be exactly zero (sign=0)
                                                                                                                                                                                        double x0 = 0.0;
                                                                                                                                                                                        double y0 = 1.0;
                                                                                                                                                                                        double x1 = 1.0;
                                                                                                                                                                                        double y1 = 0.0;
                                                                                                                                                                                        double x2 = 2.0;
                                                                                                                                                                                        double y2 = -1.0;
                                                                                                                                                                                        
                                                                                                                                                                                        try {
                                                                                                                                                                                            // Use reflection to access private solve method
                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                "solve", double.class, double.class, double.class, 
                                                                                                                                                                                                double.class, double.class, double.class);
                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                            
                                                                                                                                                                                            // This should throw MaxIterationsExceededException in original version
                                                                                                                                                                                            // but might behave differently in mutated version
                                                                                                                                                                                            double result = (Double)solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                                            
                                                                                                                                                                                            // If we get here, the mutant wasn't caught - fail the test
                                                                                                                                                                                            fail("Expected MaxIterationsExceededException not thrown");
                                                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                                                            if (e.getCause() instanceof MaxIterationsExceededException) {
                                                                                                                                                                                                // Expected behavior for original version
                                                                                                                                                                                                // Verify the iteration count is as expected
                                                                                                                                                                                                MaxIterationsExceededException mee = (MaxIterationsExceededException)e.getCause();
                                                                                                                                                                                                assertEquals(100, mee.getMaxIterations());
                                                                                                                                                                                            } else {
                                                                                                                                                                                                throw e;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify the function was called with expected values
                                                                                                                                                                                        verify(f, atLeastOnce()).value(x1);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                               public void testSolve_ExactFunctionValueAccuracy_ShouldReturnImmediately() throws Exception {
                                                                                                                                                                                   // Setup
                                                                                                                                                                                   double functionValueAccuracy = 1E-6;
                                                                                                                                                                                   double x0 = 0.0, x1 = 1.0, x2 = 2.0;
                                                                                                                                                                                   double y0 = -1.0, y1 = functionValueAccuracy, y2 = 1.0; // y1 exactly equals accuracy
                                                                                                                                                                                   
                                                                                                                                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                   when(f.value(x1)).thenReturn(y1);
                                                                                                                                                                                   
                                                                                                                                                                                   BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                   solver.setFunctionValueAccuracy(functionValueAccuracy);
                                                                                                                                                                                   
                                                                                                                                                                                   // Get the private solve method via reflection
                                                                                                                                                                                   Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                       "solve", double.class, double.class, double.class, 
                                                                                                                                                                                       double.class, double.class, double.class);
                                                                                                                                                                                   solveMethod.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Execute
                                                                                                                                                                                   double result = (Double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify
                                                                                                                                                                                   // Original behavior should return x1 when y1 exactly equals functionValueAccuracy
                                                                                                                                                                                   // Mutant would continue iterating (would throw MaxIterationsExceededException)
                                                                                                                                                                                   assertEquals(x1, result, 0.0);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the function was called exactly once (for initial value)
                                                                                                                                                                                   verify(f, times(1)).value(x1);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                           public void testSolve_DetectsExactFunctionValueAtMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                               // Setup
                                                                                                                                                                               double functionValueAccuracy = 1E-6;
                                                                                                                                                                               double min = 0.0;
                                                                                                                                                                               double max = 1.0;
                                                                                                                                                                               double initial = 0.5;
                                                                                                                                                                               
                                                                                                                                                                               // Mock the function to return exactly functionValueAccuracy at min
                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                               when(f.value(min)).thenReturn(functionValueAccuracy);
                                                                                                                                                                               when(f.value(initial)).thenReturn(1.0); // Any non-zero value
                                                                                                                                                                               when(f.value(max)).thenReturn(1.0); // Any non-zero value
                                                                                                                                                                               
                                                                                                                                                                               // Create solver with our mock function and known accuracy
                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                               // Need to set functionValueAccuracy through reflection since it's inherited
                                                                                                                                                                               try {
                                                                                                                                                                                   Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                                                                   field.setAccessible(true);
                                                                                                                                                                                   field.set(solver, functionValueAccuracy);
                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                   fail("Failed to set functionValueAccuracy through reflection");
                                                                                                                                                                               }
                                                                                                                                                                               
                                                                                                                                                                               // Test
                                                                                                                                                                               double result = solver.solve(min, max, initial);
                                                                                                                                                                               
                                                                                                                                                                               // Verify
                                                                                                                                                                               assertEquals(min, result, 0.0); // Should return min when yMin exactly equals accuracy
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testSolve_DetectsFunctionValueExactlyAtAccuracyThreshold() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                               // Setup
                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                               double functionValueAccuracy = 1E-6; // Assuming this is the accuracy from constructor
                                                                                                                                                                               double min = 0.0;
                                                                                                                                                                               double max = 1.0;
                                                                                                                                                                               
                                                                                                                                                                               // Stub the function to return exactly functionValueAccuracy at min
                                                                                                                                                                               when(f.value(min)).thenReturn(functionValueAccuracy);
                                                                                                                                                                               when(f.value(max)).thenReturn(1.0); // Any positive value
                                                                                                                                                                               
                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                               
                                                                                                                                                                               // Set functionValueAccuracy through reflection since it's likely inherited
                                                                                                                                                                               try {
                                                                                                                                                                                   Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                                                                   field.setAccessible(true);
                                                                                                                                                                                   field.set(solver, functionValueAccuracy);
                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                   fail("Failed to set functionValueAccuracy through reflection");
                                                                                                                                                                               }
                                                                                                                                                                               
                                                                                                                                                                               // Test
                                                                                                                                                                               double result = solver.solve(min, max);
                                                                                                                                                                               
                                                                                                                                                                               // Verify
                                                                                                                                                                               assertEquals(min, result, 0.0);
                                                                                                                                                                               
                                                                                                                                                                               // Additional verification that we took the first branch
                                                                                                                                                                               verify(f).value(min);
                                                                                                                                                                               verify(f).value(max);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testConvergenceWhenFunctionValueLessThanAccuracy() throws Exception {
                                                                                                                                                                               // Setup
                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                               
                                                                                                                                                                               // Set up test values where |y1| < functionValueAccuracy
                                                                                                                                                                               double x0 = 0.0, x1 = 1.0, x2 = 2.0;
                                                                                                                                                                               double y0 = 0.5, y1 = 1e-7, y2 = 0.5;  // y1 is less than default accuracy (1E-6)
                                                                                                                                                                               
                                                                                                                                                                               // Mock the function to return y1 when x1 is evaluated
                                                                                                                                                                               when(f.value(x1)).thenReturn(y1);
                                                                                                                                                                               
                                                                                                                                                                               // Set up reflection to access private solve method
                                                                                                                                                                               try {
                                                                                                                                                                                   java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                       "solve", double.class, double.class, double.class, 
                                                                                                                                                                                       double.class, double.class, double.class);
                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Invoke the method
                                                                                                                                                                                   double result = (double) method.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the method returned x1 (should converge immediately)
                                                                                                                                                                                   assertEquals(x1, result, 0.0);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the function was only evaluated once (for y1)
                                                                                                                                                                                   verify(f, times(1)).value(x1);
                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                   fail("Reflection failed: " + e.toString());
                                                                                                                                                                               }
                                                                                                                                                                           }

    @Test
                                                                                                                                                                  public void testSolveDetectsMutantWhenYMinIsLessThanAccuracy() throws FunctionEvaluationException {
                                                                                                                                                                      // Setup
                                                                                                                                                                      double min = 0.0;
                                                                                                                                                                      double max = 2.0;
                                                                                                                                                                      double initial = 1.0;
                                                                                                                                                                      double functionValueAccuracy = 1E-6;
                                                                                                                                                                      double yMinValue = 0.5E-6; // Less than accuracy threshold
                                                                                                                                                                      
                                                                                                                                                                      // Mock the function
                                                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                      when(f.value(min)).thenReturn(yMinValue);
                                                                                                                                                                      when(f.value(initial)).thenReturn(1.0); // Some non-zero value
                                                                                                                                                                      when(f.value(max)).thenReturn(1.0); // Some non-zero value
                                                                                                                                                                      
                                                                                                                                                                      // Create solver with custom accuracy (if possible) or use default
                                                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                      
                                                                                                                                                                      // Set functionValueAccuracy through reflection if needed
                                                                                                                                                                      try {
                                                                                                                                                                          java.lang.reflect.Field field = BrentSolver.class.getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                                          field.set(solver, functionValueAccuracy);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to set functionValueAccuracy through reflection");
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      double result = 0;
                                                                                                                                                                      try {
                                                                                                                                                                          result = solver.solve(min, max, initial);
                                                                                                                                                                      } catch (MaxIterationsExceededException e) {
                                                                                                                                                                          fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      // Original code would return yMin since |yMin| < accuracy
                                                                                                                                                                      // Mutant would continue solving since |yMin| != accuracy
                                                                                                                                                                      assertEquals("Should return min value when |yMin| < accuracy", 
                                                                                                                                                                                   min, result, 1E-10);
                                                                                                                                                                      
                                                                                                                                                                      // Verify the function was called as expected
                                                                                                                                                                      verify(f).value(min);
                                                                                                                                                                  }

    @Test
                                                                                                                                                              public void testSolveDetectsMutantWhenYMinLessThanButNotEqualToAccuracy() {
                                                                                                                                                                  // Setup
                                                                                                                                                                  double min = 0.0;
                                                                                                                                                                  double max = 1.0;
                                                                                                                                                                  double functionValueAccuracy = 1E-6;
                                                                                                                                                                  double yMin = 0.5E-6;  // Less than but not equal to accuracy
                                                                                                                                                                  double yMax = 2.0;     // Positive value
                                                                                                                                                                  
                                                                                                                                                                  // Mock the function
                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                  try {
                                                                                                                                                                      when(f.value(min)).thenReturn(yMin);
                                                                                                                                                                      when(f.value(max)).thenReturn(yMax);
                                                                                                                                                                  } catch (FunctionEvaluationException e) {
                                                                                                                                                                      fail("Unexpected FunctionEvaluationException during mocking");
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  // Create solver with custom accuracy
                                                                                                                                                                  BrentSolver solver = new BrentSolver(f) {
                                                                                                                                                                      @Override
                                                                                                                                                                      public double getFunctionValueAccuracy() {
                                                                                                                                                                          return functionValueAccuracy;
                                                                                                                                                                      }
                                                                                                                                                                  };
                                                                                                                                                                  
                                                                                                                                                                  // Test
                                                                                                                                                                  try {
                                                                                                                                                                      try {
                                                                                                                                                                          double result = solver.solve(min, max);
                                                                                                                                                                          // If we get here, the mutant survived (bad)
                                                                                                                                                                          fail("Expected IllegalArgumentException but got result: " + result);
                                                                                                                                                                      } catch (MaxIterationsExceededException e) {
                                                                                                                                                                          fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                      } catch (FunctionEvaluationException e) {
                                                                                                                                                                          fail("Unexpected FunctionEvaluationException");
                                                                                                                                                                      }
                                                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                                                      // This is what the mutant would do (bad)
                                                                                                                                                                      // Verify the exception message contains the expected text
                                                                                                                                                                      assertTrue(e.getMessage().contains("Function values at endpoints do not have different signs"));
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  // For completeness, we should also test what the original would do
                                                                                                                                                                  // But since we can't have both behaviors, this is just for illustration
                                                                                                                                                                  // In a real test, we would only have one version of the code
                                                                                                                                                              }

    @Test
                                                                                                                                                         public void testSolveWithNegativeFunctionValueWithinAccuracy() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             double functionValueAccuracy = 1E-6;
                                                                                                                                                             double negativeValueWithinAccuracy = -0.5E-6; // Negative but within accuracy
                                                                                                                                                             
                                                                                                                                                             // Mock the function to return our test value when x1 is evaluated
                                                                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                             when(f.value(anyDouble())).thenReturn(negativeValueWithinAccuracy);
                                                                                                                                                             
                                                                                                                                                             // Create solver with our mocked function
                                                                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                                                                             
                                                                                                                                                             // Set up test values where y1 is our negative value within accuracy
                                                                                                                                                             double x0 = 0.0, y0 = 1.0;
                                                                                                                                                             double x1 = 1.0, y1 = negativeValueWithinAccuracy;
                                                                                                                                                             double x2 = 2.0, y2 = 1.0;
                                                                                                                                                             
                                                                                                                                                             // Use reflection to access private solve method
                                                                                                                                                             Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                 "solve", 
                                                                                                                                                                 double.class, double.class, 
                                                                                                                                                                 double.class, double.class, 
                                                                                                                                                                 double.class, double.class
                                                                                                                                                             );
                                                                                                                                                             solveMethod.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             // Call the method - should accept the solution since abs(y1) <= accuracy
                                                                                                                                                             double result = (Double)solveMethod.invoke(
                                                                                                                                                                 solver, 
                                                                                                                                                                 x0, y0, 
                                                                                                                                                                 x1, y1, 
                                                                                                                                                                 x2, y2
                                                                                                                                                             );
                                                                                                                                                             
                                                                                                                                                             // Verify the result is x1 since y1 meets the accuracy condition
                                                                                                                                                             assertEquals(x1, result, 0.0);
                                                                                                                                                             
                                                                                                                                                             // Verify the function was called with x1
                                                                                                                                                             verify(f).value(x1);
                                                                                                                                                         }

    @Test
                                                                                                                                                     public void testSolve_NegativeYMinWithinAccuracy_ShouldReturnMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                         // Setup
                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                         when(f.value(anyDouble())).thenReturn(-0.5, 1.0, 1.0); // yMin = -0.5, others > accuracy
                                                                                                                                                         
                                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                                         // Set functionValueAccuracy through reflection since it's inherited from parent
                                                                                                                                                         try {
                                                                                                                                                             Field accuracyField = BrentSolver.class.getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                                             accuracyField.setAccessible(true);
                                                                                                                                                             accuracyField.set(solver, 1.0);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Failed to set functionValueAccuracy through reflection");
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         // Test
                                                                                                                                                         double result = solver.solve(0.0, 2.0, 1.0);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         // Original would return min (0.0) because |-0.5| <= 1.0
                                                                                                                                                         // Mutant would continue because -0.5 <= 1.0 is true but not absolute value check
                                                                                                                                                         assertEquals(0.0, result, 0.0001);
                                                                                                                                                         verify(f, times(1)).value(0.0); // Verify min was checked
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testSolveDetectsNegativeRootWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                         // Setup
                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                         when(f.value(anyDouble())).thenReturn(-1e-7); // negative value within typical accuracy
                                                                                                                                                         
                                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                                         solver.setFunctionValueAccuracy(1e-6); // accuracy higher than our test value
                                                                                                                                                         
                                                                                                                                                         // Test
                                                                                                                                                         double result = solver.solve(0.0, 1.0);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         assertEquals(0.0, result, 0.0); // Should return min (0.0) as it's a root
                                                                                                                                                         
                                                                                                                                                         // Additional verification that we took the correct path
                                                                                                                                                         verify(f, times(1)).value(0.0); // verify min was evaluated
                                                                                                                                                         verify(f, times(1)).value(1.0); // verify max was evaluated
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testSolveDetectsYMinAccuracyMutant() throws Exception {
                                                                                                                                                         // Setup
                                                                                                                                                         double min = 1.0;
                                                                                                                                                         double max = 2.0;
                                                                                                                                                         double functionValueAccuracy = 1E-6;
                                                                                                                                                         double yMin = 0.5E-6;  // Within accuracy (<= 1E-6)
                                                                                                                                                         double yMax = 1.0;     // Not within accuracy
                                                                                                                                                         
                                                                                                                                                         // Mock the function to return specific values
                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                         when(f.value(min)).thenReturn(yMin);
                                                                                                                                                         when(f.value(max)).thenReturn(yMax);
                                                                                                                                                         
                                                                                                                                                         // Create solver with small functionValueAccuracy
                                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                                         // Use reflection to set functionValueAccuracy if needed
                                                                                                                                                         // (Assuming it's inherited from a parent class)
                                                                                                                                                         
                                                                                                                                                         // Test
                                                                                                                                                         double result = solver.solve(min, max);
                                                                                                                                                         
                                                                                                                                                         // Verify - original would return min, mutant would check yMax instead
                                                                                                                                                         assertEquals("Should return min when yMin is within accuracy", 
                                                                                                                                                                     min, result, 0.0);
                                                                                                                                                         
                                                                                                                                                         // Verify function was called correctly
                                                                                                                                                         verify(f).value(min);
                                                                                                                                                         verify(f).value(max);
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testSolve_DetectsY1AccuracyCheckMutant() throws Exception {
                                                                                                                                                         // Setup mock function
                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                         
                                                                                                                                                         // Case where y1 meets accuracy but y2 doesn't
                                                                                                                                                         // Should return in original, mutant might not
                                                                                                                                                         when(f.value(anyDouble())).thenReturn(1e-7, 1e-8, 1.0);
                                                                                                                                                         
                                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                                         solver.setFunctionValueAccuracy(1e-6); // Set accuracy threshold
                                                                                                                                                         
                                                                                                                                                         try {
                                                                                                                                                             // Call private solve method via reflection for testing
                                                                                                                                                             java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                 "solve", double.class, double.class, double.class, 
                                                                                                                                                                 double.class, double.class, double.class);
                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             // Parameters where y1 (1e-8) is accurate but y2 (1.0) is not
                                                                                                                                                             double result = (double) method.invoke(solver, 
                                                                                                                                                                 0.0, 1.0,  // x0, y0
                                                                                                                                                                 1.0, 1e-8,  // x1, y1 (should trigger return)
                                                                                                                                                                 2.0, 1.0); // x2, y2
                                                                                                                                                             
                                                                                                                                                             // Verify we got x1 (1.0) as result since y1 was accurate
                                                                                                                                                             assertEquals(1.0, result, 0.0);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Exception should not be thrown");
                                                                                                                                                         }
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testSolve_DetectsY2AccuracyCheckMutant() throws Exception {
                                                                                                                                                         // Setup mock function
                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                         
                                                                                                                                                         // Case where y2 meets accuracy but y1 doesn't
                                                                                                                                                         // Should NOT return in original, mutant might return
                                                                                                                                                         when(f.value(anyDouble())).thenReturn(1e-7, 1.0, 1e-8);
                                                                                                                                                         
                                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                                         solver.setFunctionValueAccuracy(1e-6); // Set accuracy threshold
                                                                                                                                                         
                                                                                                                                                         try {
                                                                                                                                                             // Call private solve method via reflection for testing
                                                                                                                                                             java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                 "solve", double.class, double.class, double.class, 
                                                                                                                                                                 double.class, double.class, double.class);
                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             // Parameters where y2 (1e-8) is accurate but y1 (1.0) is not
                                                                                                                                                             double result = (double) method.invoke(solver, 
                                                                                                                                                                 0.0, 1e-7,  // x0, y0
                                                                                                                                                                 1.0, 1.0,    // x1, y1 (should NOT trigger return)
                                                                                                                                                                 2.0, 1e-8);  // x2, y2
                                                                                                                                                             
                                                                                                                                                             // Verify we didn't get x2 as result (mutant would return here)
                                                                                                                                                             assertNotEquals(2.0, result, 0.0);
                                                                                                                                                             
                                                                                                                                                             // Original should continue iterating, so result should be different
                                                                                                                                                             // from x2 (2.0) since y1 wasn't accurate enough
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Exception should not be thrown");
                                                                                                                                                         }
                                                                                                                                                     }

    @Test
                                                                                                                                                public void testSolve_ShouldReturnMinWhenYMinIsWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                    // Setup
                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                    when(f.value(anyDouble())).thenAnswer(invocation -> {
                                                                                                                                                        double x = invocation.getArgument(0);
                                                                                                                                                        if (x == 1.0) return 0.0;       // min
                                                                                                                                                        if (x == 2.0) return 0.1;       // initial
                                                                                                                                                        if (x == 3.0) return 0.2;       // max
                                                                                                                                                        return 0.0;
                                                                                                                                                    });
                                                                                                                                                    
                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                    solver.setFunctionValueAccuracy(1e-5);
                                                                                                                                                    
                                                                                                                                                    // Test - min=1.0 (y=0.0), max=3.0 (y=0.2), initial=2.0 (y=0.1)
                                                                                                                                                    // Should return min (1.0) since yMin is within accuracy
                                                                                                                                                    double result = solver.solve(1.0, 3.0, 2.0);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals(1.0, result, 1e-6);
                                                                                                                                                    verify(f, times(1)).value(1.0);  // Verify min was checked
                                                                                                                                                    verify(f, times(1)).value(2.0);  // Verify initial was checked
                                                                                                                                                    verify(f, never()).value(3.0);   // Should not check max in original
                                                                                                                                                }

    @Test
                                                                                                                                           public void testSolve_EarlyTerminationWhenFunctionValueWithinAccuracy() throws Exception {
                                                                                                                                               // Setup mock function that returns values within accuracy
                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                               when(f.value(anyDouble())).thenReturn(1e-7); // Within default accuracy (1E-6)
                                                                                                                                               
                                                                                                                                               // Create solver with default accuracy (1E-6)
                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                               
                                                                                                                                               // Set up test values where y1 is within function value accuracy
                                                                                                                                               double x0 = 0.0, y0 = 1.0;
                                                                                                                                               double x1 = 1.0, y1 = 1e-7; // y1 is within accuracy
                                                                                                                                               double x2 = 2.0, y2 = 1.0;
                                                                                                                                               
                                                                                                                                               // Use reflection to call private solve method
                                                                                                                                               Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                   "solve", double.class, double.class, double.class, 
                                                                                                                                                   double.class, double.class, double.class);
                                                                                                                                               solveMethod.setAccessible(true);
                                                                                                                                               double result = (Double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                               
                                                                                                                                               // Verify the result is x1 (since y1 was within accuracy)
                                                                                                                                               assertEquals(x1, result, 0.0);
                                                                                                                                               
                                                                                                                                               // Verify the function was only evaluated once (for y1)
                                                                                                                                               verify(f, times(1)).value(anyDouble());
                                                                                                                                               
                                                                                                                                               // Additional verification that we didn't do unnecessary iterations
                                                                                                                                               // (This would fail with the mutant since it would continue iterating)
                                                                                                                                               assertTrue(solver.getIterationCount() == 0);
                                                                                                                                           }

    @Test
                                                                                                                                       public void testSolve_ShouldReturnMinWhenWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                           // Setup
                                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                           doReturn(0.0).when(f).value(1.0); // min is exact solution
                                                                                                                                           doReturn(1.0).when(f).value(2.0); // initial guess
                                                                                                                                           doReturn(2.0).when(f).value(3.0); // max
                                                                                                                                           
                                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                                           solver.setFunctionValueAccuracy(1e-6);
                                                                                                                                           
                                                                                                                                           // Test - min is 1.0, max is 3.0, initial is 2.0
                                                                                                                                           double result = solver.solve(1.0, 3.0, 2.0);
                                                                                                                                           
                                                                                                                                           // Verify - should return min (1.0) since it's exact solution
                                                                                                                                           // The mutant would skip this and proceed to other checks
                                                                                                                                           assertEquals(1.0, result, 0.0);
                                                                                                                                           
                                                                                                                                           // Verify the function was called at min point
                                                                                                                                           verify(f).value(1.0);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testSolve_DetectsYMinCloseToZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                           // Setup
                                                                                                                                           double min = 1.0;
                                                                                                                                           double max = 2.0;
                                                                                                                                           double functionValueAccuracy = 1E-6;
                                                                                                                                           double yMin = 1E-7;  // Smaller than functionValueAccuracy
                                                                                                                                           double yMax = 1.0;   // Not close to zero
                                                                                                                                           
                                                                                                                                           // Mock the function
                                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                           when(f.value(min)).thenReturn(yMin);
                                                                                                                                           when(f.value(max)).thenReturn(yMax);
                                                                                                                                           
                                                                                                                                           // Create solver with small functionValueAccuracy
                                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                                           solver.setFunctionValueAccuracy(functionValueAccuracy);
                                                                                                                                           
                                                                                                                                           // Test
                                                                                                                                           double result = solver.solve(min, max);
                                                                                                                                           
                                                                                                                                           // Verify - original should return min, mutant would throw exception or return max
                                                                                                                                           assertEquals(min, result, 0.0);
                                                                                                                                           
                                                                                                                                           // Verify function was called correctly
                                                                                                                                           verify(f).value(min);
                                                                                                                                           verify(f).value(max);
                                                                                                                                       }

    @Test
                                                                                                                                   public void testSolveReportsZeroIterationsWhenImmediateConvergence() throws Exception {
                                                                                                                                       // Create a mock function that returns 0 at x=1.0 (root found immediately)
                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                       when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                       
                                                                                                                                       // Create solver with default accuracy settings
                                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                                       
                                                                                                                                       // Call solve with initial point already at root
                                                                                                                                       double result = solver.solve(0.5, 1.5, 1.0);
                                                                                                                                       
                                                                                                                                       // Verify the result is correct
                                                                                                                                       assertEquals(1.0, result, 0.0);
                                                                                                                                       
                                                                                                                                       // The key assertion - verify iteration count is 0
                                                                                                                                       // This will fail if the mutant is present (which reports 1)
                                                                                                                                       assertEquals(0, solver.getIterationCount());
                                                                                                                                       
                                                                                                                                       // Verify function was evaluated exactly once at x=1.0
                                                                                                                                       verify(f, times(1)).value(1.0);
                                                                                                                                   }

    @Test
                                                                                                                              public void testSolve_FirstEndpointIsSolution_ShouldReturnZeroIterations() {
                                                                                                                                  try {
                                                                                                                                      // Setup mock function that returns 0 at min (exact solution)
                                                                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                      when(f.value(anyDouble())).thenReturn(1.0); // default return
                                                                                                                                      when(f.value(0.0)).thenReturn(0.0); // exact solution at min
                                                                                                                                      
                                                                                                                                      // Create solver with tight accuracy
                                                                                                                                      double accuracy = 1e-10;
                                                                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                                                                      solver.setFunctionValueAccuracy(accuracy);
                                                                                                                                      
                                                                                                                                      // Call solve with min being the exact solution
                                                                                                                                      double result = solver.solve(0.0, 1.0, 0.5);
                                                                                                                                      
                                                                                                                                      // Verify the iteration count is 0 (not 1 as in mutant)
                                                                                                                                      // Note: This assumes the solver stores iteration count in a way we can access it
                                                                                                                                      // If we can't directly access iteration count, we'd need to verify through other means
                                                                                                                                      // For this test, we'll assume getIterationCount() is available
                                                                                                                                      assertEquals(0, solver.getIterationCount());
                                                                                                                                      
                                                                                                                                      // Also verify the result is exactly min (0.0)
                                                                                                                                      assertEquals(0.0, result, 0.0);
                                                                                                                                  } catch (FunctionEvaluationException e) {
                                                                                                                                      fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                                                                  } catch (MaxIterationsExceededException e) {
                                                                                                                                      fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                              public void testSolve_DetectsRootAtMinWithZeroIterations() throws FunctionEvaluationException {
                                                                                                                                  // Create a mock function where min is very close to root
                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                  when(f.value(1.0)).thenReturn(1e-7);  // within default functionValueAccuracy (1E-6)
                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);   // positive value
                                                                                                                                  
                                                                                                                                  // Create solver with default accuracy (1E-6)
                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                  
                                                                                                                                  try {
                                                                                                                                      // Call solve - min should be detected as root
                                                                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                                                                      
                                                                                                                                      // Verify result is min
                                                                                                                                      assertEquals(1.0, result, 0.0);
                                                                                                                                      
                                                                                                                                      // Verify iteration count was set to 0 (this would fail for the mutant)
                                                                                                                                      // Note: This assumes the solver has a way to access the iteration count
                                                                                                                                      // If not directly accessible, we might need reflection or to extend the class
                                                                                                                                      try {
                                                                                                                                          Field iterationsField = BrentSolver.class.getDeclaredField("iterationCount");
                                                                                                                                          iterationsField.setAccessible(true);
                                                                                                                                          int iterations = iterationsField.getInt(solver);
                                                                                                                                          assertEquals(0, iterations);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to access iteration count: " + e.getMessage());
                                                                                                                                      }
                                                                                                                                  } catch (MaxIterationsExceededException e) {
                                                                                                                                      fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                          public void testSolve_DetectsRootAtMinWithZeroIterations1() throws MaxIterationsExceededException {
                                                                                                                              // Create a mock function where min is very close to root
                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                              try {
                                                                                                                                  when(f.value(1.0)).thenReturn(1e-7);  // within default functionValueAccuracy (1E-6)
                                                                                                                                  when(f.value(2.0)).thenReturn(1.0);   // positive value
                                                                                                                              } catch (FunctionEvaluationException e) {
                                                                                                                                  fail("Mock setup failed: " + e.getMessage());
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Create solver with default accuracy (1E-6)
                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                              
                                                                                                                              // Call solve - min should be detected as root
                                                                                                                              double result;
                                                                                                                              try {
                                                                                                                                  result = solver.solve(1.0, 2.0);
                                                                                                                              } catch (FunctionEvaluationException e) {
                                                                                                                                  fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                                                                  return;
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Verify result is min
                                                                                                                              assertEquals(1.0, result, 0.0);
                                                                                                                              
                                                                                                                              // Use reflection to verify iteration count
                                                                                                                              try {
                                                                                                                                  Field iterationsField = UnivariateRealSolverImpl.class.getDeclaredField("iterationCount");
                                                                                                                                  iterationsField.setAccessible(true);
                                                                                                                                  int iterations = (int) iterationsField.get(solver);
                                                                                                                                  assertEquals(0, iterations);
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to verify iteration count via reflection: " + e.getMessage());
                                                                                                                              }
                                                                                                                          }

    @Test
                                                                                                         public void testSolve_DetectsMutantWhenMinIsSolution() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                             // Setup mock function that returns 0 at min (solution found)
                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                             when(f.value(1.0)).thenReturn(0.0); // min is solution
                                                                                                             when(f.value(2.0)).thenReturn(1.0); // max is not solution
                                                                                                             when(f.value(1.5)).thenReturn(0.5); // initial is not solution
                                                                                                             
                                                                                                             // Create solver with small accuracy threshold
                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                             solver.setFunctionValueAccuracy(1e-6);
                                                                                                             
                                                                                                             // Call solve - min (1.0) should be solution
                                                                                                             double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                             
                                                                                                             // Verify correct result (min) is returned
                                                                                                             // This will fail if mutant is present (would return max instead)
                                                                                                             assertEquals(1.0, result, 1e-6);
                                                                                                             
                                                                                                             // Additional verification that max wasn't returned
                                                                                                             assertNotEquals(2.0, result, 1e-6);
                                                                                                         }

    @Test
                                                                                                         public void testSolveReturnsMinInsteadOfMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                             // Create a mock function where min is clearly the better solution
                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                             when(f.value(1.0)).thenReturn(-1.0);  // min
                                                                                                             when(f.value(2.0)).thenReturn(1.0);   // max
                                                                                                             
                                                                                                             // Create solver with mock function
                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                             
                                                                                                             // Test case where min should be returned
                                                                                                             double min = 1.0;
                                                                                                             double max = 2.0;
                                                                                                             double result = solver.solve(min, max);
                                                                                                             
                                                                                                             // Verify the result is closer to min (should be min if not mutated)
                                                                                                             assertEquals("Result should be closer to min value", min, result, 0.0001);
                                                                                                             
                                                                                                             // Additional verification that we didn't get max
                                                                                                             assertNotEquals("Result should not be max value", max, result, 0.0001);
                                                                                                         }

    @Test
                                                                                                         public void testSolve_WhenMinIsCloseToRoot_ShouldSetResultToMin() {
                                                                                                             // Setup
                                                                                                             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                             try {
                                                                                                                 when(f.value(1.0)).thenReturn(1e-7);  // within default 1e-6 accuracy
                                                                                                                 when(f.value(2.0)).thenReturn(1.0);
                                                                                                             } catch (FunctionEvaluationException e) {
                                                                                                                 fail("Mock setup failed");
                                                                                                             }
                                                                                                             
                                                                                                             BrentSolver solver = new BrentSolver(f);
                                                                                                             
                                                                                                             // Action
                                                                                                             double result = 0;
                                                                                                             try {
                                                                                                                 result = solver.solve(1.0, 2.0);
                                                                                                             } catch (MaxIterationsExceededException e) {
                                                                                                                 fail("Max iterations exceeded");
                                                                                                             } catch (FunctionEvaluationException e) {
                                                                                                                 fail("Function evaluation failed");
                                                                                                             }
                                                                                                             
                                                                                                             // Assertion - verify result is min (1.0)
                                                                                                             assertEquals(1.0, result, 0.0);
                                                                                                             
                                                                                                             // Additional verification to catch the mutant
                                                                                                             // Using a custom UnivariateRealFunction that records calls
                                                                                                             final java.util.concurrent.atomic.AtomicReference<Double> storedResult = new java.util.concurrent.atomic.AtomicReference<>();
                                                                                                             UnivariateRealFunction trackingFunction = new UnivariateRealFunction() {
                                                                                                                 public double value(double x) throws FunctionEvaluationException {
                                                                                                                     if (Math.abs(x - 1.0) < 1e-6) return 1e-7;
                                                                                                                     return 1.0;
                                                                                                                 }
                                                                                                             };
                                                                                                             
                                                                                                             // Create a solver and use reflection to get the result
                                                                                                             BrentSolver trackingSolver = new BrentSolver(trackingFunction);
                                                                                                             try {
                                                                                                                 trackingSolver.solve(1.0, 2.0);
                                                                                                             } catch (MaxIterationsExceededException e) {
                                                                                                                 fail("Max iterations exceeded");
                                                                                                             } catch (FunctionEvaluationException e) {
                                                                                                                 fail("Function evaluation failed");
                                                                                                             }
                                                                                                             
                                                                                                             try {
                                                                                                                 Field resultField = UnivariateRealSolverImpl.class.getDeclaredField("result");
                                                                                                                 resultField.setAccessible(true);
                                                                                                                 double solverResult = resultField.getDouble(trackingSolver);
                                                                                                                 assertEquals(1.0, solverResult, 0.0);  // This will fail if mutant is present
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Failed to access result field through reflection");
                                                                                                             }
                                                                                                         }

    @Test
                                                                                                    public void testSolve_ConvergesImmediately_ShouldRecordZeroIterations() throws Exception {
                                                                                                        // Setup
                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                        when(f.value(anyDouble())).thenReturn(0.0);  // y1 will be exactly 0
                                                                                                        
                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                        
                                                                                                        // Set functionValueAccuracy to a value that will make y1 (0.0) satisfy convergence
                                                                                                        solver.setFunctionValueAccuracy(1e-6);
                                                                                                        solver.setRelativeAccuracy(1e-10);
                                                                                                        solver.setAbsoluteAccuracy(1e-10);
                                                                                                        
                                                                                                        // Test data where initial evaluation is already within accuracy
                                                                                                        // We'll use the public solve(min, max) method which will internally call the private solve method
                                                                                                        // The mock is set up to return 0.0 for any input, so the first evaluation should satisfy convergence
                                                                                                        double min = 1.0;
                                                                                                        double max = 2.0;
                                                                                                        
                                                                                                        // Execute
                                                                                                        double result = solver.solve(min, max);
                                                                                                        
                                                                                                        // Verify iteration count was 0
                                                                                                        Field iterationsField = BrentSolver.class.getDeclaredField("iterationCount");
                                                                                                        iterationsField.setAccessible(true);
                                                                                                        int iterations = (int) iterationsField.get(solver);
                                                                                                        
                                                                                                        assertEquals("Iteration count should be 0 when converging immediately", 
                                                                                                                     0, iterations);
                                                                                                    }

    @Test
                                                                                                public void testSolve_DetectsMinEndpointSolutionWithCorrectIterationCount() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                    // Setup - create a function where min is exactly a root (yMin = 0)
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                                                                                    when(f.value(2.0)).thenReturn(1.0);  // yMax = some non-zero value
                                                                                                    when(f.value(1.5)).thenReturn(0.5);  // yInitial = some non-zero value
                                                                                                    
                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                    solver.setFunctionValueAccuracy(1e-6);
                                                                                                    
                                                                                                    // Test - min is exactly a root
                                                                                                    double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                    
                                                                                                    // Verify - should set iteration count to 0, not -1
                                                                                                    // Since we can't directly access the iteration count, we need to verify the behavior
                                                                                                    // through the result. The correct behavior should return min (1.0) as the solution.
                                                                                                    assertEquals(1.0, result, 1e-6);
                                                                                                    
                                                                                                    // Alternative verification if we had access to the result object:
                                                                                                    // assertEquals(0, solver.getIterationCount());
                                                                                                    // But since we don't see the class structure fully, we verify through the result
                                                                                                }

    @Test
                                                                                                public void testSolve_DetectsSetResultMutation() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                    // Setup
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    when(f.value(anyDouble())).thenReturn(1e-7, 1.0); // yMin is close to zero
                                                                                                    
                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                    // Set functionValueAccuracy to be larger than yMin
                                                                                                    solver.setFunctionValueAccuracy(1e-6);
                                                                                                    
                                                                                                    // Test
                                                                                                    double result = solver.solve(0.0, 1.0);
                                                                                                    
                                                                                                    // Verify
                                                                                                    // The mutation would have set iteration count to -1 instead of 0
                                                                                                    // We need to access the solver's result to verify this
                                                                                                    // Assuming there's a way to get the result (this part might need adjustment based on actual class implementation)
                                                                                                    // For demonstration, we'll check the returned value is correct
                                                                                                    assertEquals(0.0, result, 1e-12);
                                                                                                    
                                                                                                    // If the class has a way to get the last result's iteration count, we would add:
                                                                                                    // assertEquals(0, solver.getIterationCount());
                                                                                                    // Since we don't see those methods, we'll focus on the observable behavior
                                                                                                    
                                                                                                    // Alternative approach: verify the setResult was called with correct parameters
                                                                                                    // This would require making setResult protected or package-private and using spy
                                                                                                    // Since we can't modify the original code, we'll focus on the functional test
                                                                                                    
                                                                                                    // The key is that the mutant would still pass this test since it doesn't affect the return value
                                                                                                    // To truly catch this mutant, we'd need to verify the internal state change
                                                                                                    // This shows the importance of testing not just return values but also side effects
                                                                                                }

    @Test
                                                                                                public void testEarlyConvergenceSetsResult() throws Exception {
                                                                                                    // Create a mock function that returns known values
                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                    when(f.value(1.0)).thenReturn(0.0);  // Exact solution at x=1
                                                                                                    
                                                                                                    // Create solver with tight accuracy requirements
                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                    
                                                                                                    // Test case where solution is found immediately
                                                                                                    double result = solver.solve(0.5, 1.5, 1.0);
                                                                                                    
                                                                                                    // Verify the correct result was returned
                                                                                                    assertEquals(1.0, result, 0.0);
                                                                                                    
                                                                                                    // Additional verification that setResult was called properly
                                                                                                    // This would normally require access to solver's internal state,
                                                                                                    // but since we can't access it, we verify through behavior
                                                                                                    
                                                                                                    // Test another case where solution is found in first iteration
                                                                                                    when(f.value(1.0)).thenReturn(1.0);
                                                                                                    when(f.value(1.1)).thenReturn(0.1);
                                                                                                    when(f.value(1.05)).thenReturn(0.0);  // Solution at 1.05
                                                                                                    
                                                                                                    result = solver.solve(1.0, 1.1, 1.05);
                                                                                                    assertEquals(1.05, result, 0.0);
                                                                                                    
                                                                                                    // Test case where function value is already within accuracy
                                                                                                    when(f.value(1.0)).thenReturn(1e-10);  // Within functionValueAccuracy
                                                                                                    result = solver.solve(0.9, 1.1, 1.0);
                                                                                                    assertEquals(1.0, result, 0.0);
                                                                                                }

    @Test
                                                                                           public void testSolve_DetectsSolutionAtMinEndpoint() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                               // Setup
                                                                                               double min = 1.0;
                                                                                               double max = 5.0;
                                                                                               double initial = 3.0;
                                                                                               double functionValueAccuracy = 1e-6;
                                                                                               
                                                                                               // Mock the function to return 0 at min (solution) and non-zero elsewhere
                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                               when(f.value(min)).thenReturn(0.0);  // Solution at min
                                                                                               when(f.value(initial)).thenReturn(1.0);  // Non-solution
                                                                                               when(f.value(max)).thenReturn(2.0);  // Non-solution
                                                                                               
                                                                                               // Create solver with mocked function and set accuracy
                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                               solver.setFunctionValueAccuracy(functionValueAccuracy);
                                                                                               
                                                                                               // Test
                                                                                               double result = solver.solve(min, max, initial);
                                                                                               
                                                                                               // Verify
                                                                                               assertEquals("Should return min when it's a solution", min, result, 0.0);
                                                                                               
                                                                                               // Additional verification to catch the mutant
                                                                                               // The mutant would not have set the result properly
                                                                                               // We can verify the internal state if possible, or verify behavior
                                                                                               // Since we can't access private state, we rely on the return value
                                                                                               // which should be min in this case
                                                                                           }

    @Test
                                                                                           public void testSolve_WhenYMinWithinAccuracy_ShouldSetResult() throws Exception {
                                                                                               // Setup
                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                               when(f.value(1.0)).thenReturn(1e-7);  // Within default accuracy (1E-6)
                                                                                               when(f.value(2.0)).thenReturn(1.0);
                                                                                               
                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                               
                                                                                               // Execute
                                                                                               double result = 0;
                                                                                               try {
                                                                                                   result = solver.solve(1.0, 2.0);
                                                                                               } catch (MaxIterationsExceededException e) {
                                                                                                   fail("Unexpected MaxIterationsExceededException");
                                                                                               }
                                                                                               
                                                                                               // Verify return value
                                                                                               assertEquals(1.0, result, 0.0);
                                                                                               
                                                                                               // Verify result was properly set in solver state
                                                                                               try {
                                                                                                   Field resultField = BrentSolver.class.getDeclaredField("result");
                                                                                                   resultField.setAccessible(true);
                                                                                                   double storedResult = resultField.getDouble(solver);
                                                                                                   assertEquals(1.0, storedResult, 0.0);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to verify result was set in solver state");
                                                                                               }
                                                                                           }

    @Test
                                                                                      public void testSolve_ExactFunctionValueAccuracy() throws Exception {
                                                                                          // Setup
                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                          when(f.value(anyDouble())).thenReturn(1.0, 1.0, 1.0, 1E-6); // Last value equals functionValueAccuracy
                                                                                          
                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                          solver.setFunctionValueAccuracy(1E-6);
                                                                                          
                                                                                          // Test data where y1 will equal functionValueAccuracy exactly
                                                                                          double x0 = 0.0;
                                                                                          double y0 = 1.0;
                                                                                          double x1 = 1.0;
                                                                                          double y1 = 1.0;
                                                                                          double x2 = 2.0;
                                                                                          double y2 = 1E-6; // This will be swapped to y1 position
                                                                                          
                                                                                          // Use reflection to access private solve method
                                                                                          Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                              "solve", double.class, double.class, double.class, 
                                                                                              double.class, double.class, double.class);
                                                                                          solveMethod.setAccessible(true);
                                                                                          
                                                                                          // Execute
                                                                                          double result = (Double)solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                          
                                                                                          // Verify
                                                                                          // The original should return after first iteration when exact equality is found
                                                                                          // The mutant would continue iterating
                                                                                          // We can verify by checking the result is x1 (1.0) which is where we set y=1E-6
                                                                                          assertEquals(1.0, result, 0.0);
                                                                                          
                                                                                          // Alternatively, if the solver exposes iteration count, we could verify it only took 1 iteration
                                                                                      }

    @Test
                                                                                  public void testSolve_ExactFunctionValueAtMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                      // Setup
                                                                                      double min = 0;
                                                                                      double max = 2;
                                                                                      double initial = 1;
                                                                                      double functionValueAccuracy = 1E-6;
                                                                                      
                                                                                      // Mock the function to return exactly the accuracy value at max
                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                      when(f.value(min)).thenReturn(1.0);  // Not accurate
                                                                                      when(f.value(initial)).thenReturn(1.0);  // Not accurate
                                                                                      when(f.value(max)).thenReturn(functionValueAccuracy);  // Exactly equals accuracy
                                                                                      
                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                      
                                                                                      // Set functionValueAccuracy through reflection since it's likely inherited
                                                                                      try {
                                                                                          Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                          field.setAccessible(true);
                                                                                          field.set(solver, functionValueAccuracy);
                                                                                      } catch (Exception e) {
                                                                                          fail("Failed to set functionValueAccuracy through reflection");
                                                                                      }
                                                                                      
                                                                                      // Test
                                                                                      double result = solver.solve(min, max, initial);
                                                                                      
                                                                                      // Verify
                                                                                      assertEquals(max, result, 0.0);  // Should return max point
                                                                                      verify(f).value(min);
                                                                                      verify(f).value(initial);
                                                                                      verify(f).value(max);
                                                                                  }

    @Test
                                                                                  public void testSolveDetectsExactFunctionValueAccuracyAtMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                      // Setup
                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                      when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0 (not close to zero)
                                                                                      when(f.value(2.0)).thenReturn(1E-6); // yMax = functionValueAccuracy (exactly)
                                                                                      
                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                      solver.setFunctionValueAccuracy(1E-6);
                                                                                      
                                                                                      // Test - should return max (2.0) since abs(yMax) == functionValueAccuracy
                                                                                      double result = solver.solve(1.0, 2.0);
                                                                                      
                                                                                      // Verify
                                                                                      assertEquals(2.0, result, 0.0);
                                                                                      
                                                                                      // Additional verification that we took the correct path
                                                                                      // In the original code, this would set result to max
                                                                                      // In the mutant, it would throw an exception or take a different path
                                                                                  }

    @Test
                                                                                  public void testConvergenceConditionDetectsYMutation() throws Exception {
                                                                                      // Setup mock function
                                                                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                      
                                                                                      // Create test case where yMax is within accuracy but yMin is not
                                                                                      // Original should converge, mutant should not
                                                                                      when(f.value(anyDouble())).thenReturn(1e-7, 1.0, 1e-7);
                                                                                      
                                                                                      BrentSolver solver = new BrentSolver(f);
                                                                                      solver.setFunctionValueAccuracy(1e-6); // Set accuracy threshold
                                                                                      
                                                                                      try {
                                                                                          double result = solver.solve(0.0, 1.0, 0.5);
                                                                                          // If we get here, original behavior worked (converged)
                                                                                          
                                                                                          // Now test case where yMin is within accuracy but yMax is not
                                                                                          // Original should not converge, mutant would
                                                                                          when(f.value(anyDouble())).thenReturn(1.0, 1e-7, 1.0);
                                                                                          
                                                                                          try {
                                                                                              result = solver.solve(0.0, 1.0, 0.5);
                                                                                              // If we get here with mutant, it's wrong - should throw
                                                                                              fail("Mutant incorrectly converged when yMin was accurate but yMax was not");
                                                                                          } catch (MaxIterationsExceededException e) {
                                                                                              // Expected behavior for original
                                                                                          }
                                                                                      } catch (MaxIterationsExceededException e) {
                                                                                          fail("Original failed to converge when yMax was accurate");
                                                                                      }
                                                                                  }

    @Test
                                                                             public void testSolve_DetectsSolutionAtMaxEndpoint() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                 // Setup mock function
                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                 
                                                                                 // Configure mock behavior
                                                                                 double min = 0.0;
                                                                                 double max = 2.0;
                                                                                 double initial = 1.0;
                                                                                 double functionValueAccuracy = 1e-6;
                                                                                 
                                                                                 // yMin is NOT a solution (abs > accuracy)
                                                                                 when(f.value(min)).thenReturn(0.1);
                                                                                 // yInitial is NOT a solution
                                                                                 when(f.value(initial)).thenReturn(0.5);
                                                                                 // yMax IS a solution (abs <= accuracy)
                                                                                 when(f.value(max)).thenReturn(1e-7);
                                                                                 
                                                                                 // Create solver with mock function and set accuracy
                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                 solver.setFunctionValueAccuracy(functionValueAccuracy);
                                                                                 
                                                                                 // Call solve method
                                                                                 double result = solver.solve(min, max, initial);
                                                                                 
                                                                                 // Verify the result should be max since yMax is a solution
                                                                                 assertEquals(max, result, 1e-12);
                                                                                 
                                                                                 // Verify mock interactions
                                                                                 verify(f).value(min);
                                                                                 verify(f).value(initial);
                                                                                 verify(f).value(max);
                                                                             }

    @Test
                                                                             public void testSolve_DetectsRootAtMaxWhenWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                 // Setup mock function where yMax is within accuracy but yMin is not
                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                 when(f.value(1.0)).thenReturn(0.1);  // yMin not close to zero
                                                                                 when(f.value(2.0)).thenReturn(1e-7); // yMax within default accuracy (1E-6)
                                                                                 
                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                 
                                                                                 // Test - should return max (2.0) since yMax is within accuracy
                                                                                 double result = solver.solve(1.0, 2.0);
                                                                                 
                                                                                 // Verify the mutant would fail this assertion
                                                                                 assertEquals(2.0, result, 0.0);
                                                                                 
                                                                                 // Verify the function was called with expected arguments
                                                                                 verify(f).value(1.0);
                                                                                 verify(f).value(2.0);
                                                                             }

    @Test
                                                                    public void testSolve_ShouldReturnMaxEndpointWhenWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                        // Setup mock function where max endpoint is a solution
                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                        when(f.value(1.0)).thenReturn(0.5);  // min
                                                                        when(f.value(2.0)).thenReturn(0.6);  // initial
                                                                        when(f.value(3.0)).thenReturn(1e-7); // max (within default 1e-6 accuracy)
                                                                        
                                                                        BrentSolver solver = new BrentSolver(f);
                                                                        
                                                                        // Call solve with min=1.0, max=3.0, initial=2.0
                                                                        double result = solver.solve(1.0, 3.0, 2.0);
                                                                        
                                                                        // Verify it returns the max endpoint (3.0) since it's within accuracy
                                                                        assertEquals(3.0, result, 1e-10);
                                                                        
                                                                        // Verify the function was evaluated at all required points
                                                                        verify(f).value(1.0);
                                                                        verify(f).value(2.0);
                                                                        verify(f).value(3.0);
                                                                    }

    @Test
                                                                    public void testSolve_DetectsRootAtMaxWhenWithinAccuracy1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                        // Setup mock function where f(min) is not zero, f(max) is within accuracy
                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                        when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                                                                        when(f.value(2.0)).thenReturn(1e-7); // yMax = 1e-7 (within default 1e-6 accuracy)
                                                                        
                                                                        BrentSolver solver = new BrentSolver(f);
                                                                        
                                                                        // Should return max (2.0) since yMax is within accuracy
                                                                        double result = solver.solve(1.0, 2.0);
                                                                        
                                                                        assertEquals(2.0, result, 0.0);
                                                                        
                                                                        // Verify the function was called with expected arguments
                                                                        verify(f).value(1.0);
                                                                        verify(f).value(2.0);
                                                                    }

    @Test
                                                                    public void testSolveTerminatesWhenFunctionValueWithinAccuracy() throws Exception {
                                                                        // Setup test data
                                                                        double x0 = 0.0;
                                                                        double y0 = 1.0;
                                                                        double x1 = 1.0;
                                                                        double y1 = 1e-10;  // Very small value within typical accuracy
                                                                        double x2 = 2.0;
                                                                        double y2 = 1.0;
                                                                        
                                                                        // Mock the function
                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                        when(f.value(x1)).thenReturn(y1);
                                                                        
                                                                        // Create solver with tight accuracy settings
                                                                        BrentSolver solver = new BrentSolver(f);
                                                                        solver.setFunctionValueAccuracy(1e-8);  // y1 is smaller than this
                                                                        
                                                                        try {
                                                                            // Use reflection to access private solve method
                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                "solve", double.class, double.class, double.class, 
                                                                                double.class, double.class, double.class);
                                                                            solveMethod.setAccessible(true);
                                                                            
                                                                            // Call the method
                                                                            double result = (Double)solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                            
                                                                            // Verify behavior
                                                                            // The original method should terminate early when y1 is within accuracy
                                                                            // The mutant would continue iterating
                                                                            // We can verify by checking the result is x1 (since y1 is small enough)
                                                                            assertEquals(x1, result, 0.0);
                                                                            
                                                                            // Additionally, we could verify the number of iterations is small
                                                                            // (implementation detail would need access to iteration count)
                                                                        } catch (InvocationTargetException e) {
                                                                            if (e.getTargetException() instanceof MaxIterationsExceededException) {
                                                                                fail("Method should have terminated early due to function value accuracy");
                                                                            } else {
                                                                                throw e;
                                                                            }
                                                                        }
                                                                    }

    @Test
                                                                public void testSolve_ConvergesImmediately_ReportsZeroIterations() throws Exception {
                                                                    // Setup
                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                    when(f.value(anyDouble())).thenReturn(0.0); // y1 will be 0.0
                                                                    
                                                                    BrentSolver solver = new BrentSolver(f);
                                                                    solver.setFunctionValueAccuracy(1e-6);
                                                                    
                                                                    // Use reflection to access private solve method
                                                                    Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                        "solve", 
                                                                        double.class, double.class, double.class, 
                                                                        double.class, double.class, double.class
                                                                    );
                                                                    solveMethod.setAccessible(true);
                                                                    
                                                                    // Call with y1 already at solution (within accuracy)
                                                                    double x0 = 0.0, y0 = 1.0;
                                                                    double x1 = 1.0, y1 = 0.0; // y1 is exactly 0 (within any reasonable accuracy)
                                                                    double x2 = 2.0, y2 = 1.0;
                                                                    
                                                                    // Verify the result
                                                                    double result = (double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                    
                                                                    // The key assertion - verify iteration count was 0
                                                                    // Since we can't directly observe setResult calls, we need to verify the behavior
                                                                    // that would be different based on iteration count
                                                                    // In this case, we know with y1=0 it should converge immediately
                                                                    assertEquals(1.0, result, 1e-12); // Should return x1 (1.0)
                                                                    
                                                                    // Alternative approach if we had access to iteration count:
                                                                    // assertEquals(0, solver.getIterationCount());
                                                                    // But since we don't see that method, we rely on the fact that
                                                                    // the mutation would make it return after 1 "fake" iteration
                                                                    // while original would return immediately
                                                                }

    @Test
                                                           public void testSolve_DetectsMaxEndpointSolutionWithZeroIterations() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                               // Setup mock function where max is a solution
                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                               when(f.value(1.0)).thenReturn(0.0);  // min
                                                               when(f.value(2.0)).thenReturn(0.0);  // max is exact solution
                                                               when(f.value(1.5)).thenReturn(0.5);  // initial
                                                               
                                                               BrentSolver solver = new BrentSolver(f);
                                                               solver.setFunctionValueAccuracy(1e-6);
                                                               
                                                               // Call solve where max is a solution
                                                               double result = solver.solve(1.0, 2.0, 1.5);
                                                               
                                                               // Verify max is returned as solution
                                                               assertEquals(2.0, result, 1e-6);
                                                               
                                                               // This assertion will catch the mutant - original expects 0 iterations
                                                               // Mutant would set iteration count to 1
                                                               assertEquals(0, solver.getIterationCount());
                                                           }

    @Test
                                                           public void testSolveDetectsMaxAsRootWithFunctionValueAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                               // Create a mock function where f(max) is within accuracy of zero
                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                               when(f.value(anyDouble())).thenReturn(1.0); // default
                                                               when(f.value(2.0)).thenReturn(1e-7); // within default accuracy (1E-6)
                                                               
                                                               BrentSolver solver = new BrentSolver(f);
                                                               
                                                               // Call solve with max being a root (within accuracy)
                                                               double result = solver.solve(1.0, 2.0);
                                                               
                                                               // Verify the result is max
                                                               assertEquals(2.0, result, 0.0);
                                                               
                                                               // Alternative approach using reflection to verify internal state
                                                               try {
                                                                   Field functionValueField = BrentSolver.class.getDeclaredField("functionValue");
                                                                   functionValueField.setAccessible(true);
                                                                   double functionValue = functionValueField.getDouble(solver);
                                                                   assertEquals(0.0, functionValue, 1e-10);
                                                               } catch (Exception e) {
                                                                   fail("Failed to verify function value through reflection: " + e.getMessage());
                                                               }
                                                           }

    @Test
                                                      public void testSolve_ReturnsMaxWhenFunctionValueAtMaxIsWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                          // Setup mock function that returns 0 at max (within accuracy)
                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                          when(f.value(1.0)).thenReturn(1.0);  // min
                                                          when(f.value(2.0)).thenReturn(0.0);  // max (solution)
                                                          when(f.value(1.5)).thenReturn(0.5);  // initial
                                                          
                                                          // Create solver with small accuracy threshold
                                                          BrentSolver solver = new BrentSolver(f);
                                                          solver.setFunctionValueAccuracy(1e-6);
                                                          
                                                          // Call solve - max should be returned as solution
                                                          double result = solver.solve(1.0, 2.0, 1.5);
                                                          
                                                          // Verify correct endpoint (max) is returned
                                                          assertEquals(2.0, result, 1e-6);
                                                          
                                                          // Additional verification that min wasn't returned
                                                          assertNotEquals(1.0, result, 1e-6);
                                                      }

    @Test
                                                      public void testSolve_DetectsMaxAsRootWhenWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                          // Setup mock function where f(max) is within accuracy (close to zero)
                                                          // and f(min) is not close to zero
                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                          when(f.value(1.0)).thenReturn(0.5);  // yMin not close to zero
                                                          when(f.value(2.0)).thenReturn(1e-7); // yMax within default accuracy (1E-6)
                                                          
                                                          BrentSolver solver = new BrentSolver(f);
                                                          
                                                          // Call method - should return max (2.0) since yMax is within accuracy
                                                          double result = solver.solve(1.0, 2.0);
                                                          
                                                          // Verify correct root is returned
                                                          assertEquals(2.0, result, 0.0);
                                                          
                                                          // Additional verification that setResult was called with max, not min
                                                          // This requires access to solver's result field or adding a getter
                                                          // Assuming there's a way to verify the internal state was set correctly
                                                          // For example, if there's a getResult() method:
                                                          // assertEquals(2.0, solver.getResult(), 0.0);
                                                          
                                                          // Since we can't see the full class implementation, we focus on the 
                                                          // most important aspect - the returned value which should be max (2.0)
                                                          // The mutant would return min (1.0) instead
                                                      }

    @Test
                                                      public void testSolveReturnsMaxInsteadOfMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                          // Create a mock function where f(min) is far from zero and f(max) is close to zero
                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                          when(f.value(1.0)).thenReturn(10.0);  // f(min) is large
                                                          when(f.value(2.0)).thenReturn(0.001); // f(max) is small
                                                          
                                                          // Create solver with tight accuracy requirements
                                                          BrentSolver solver = new BrentSolver(f);
                                                          solver.setFunctionValueAccuracy(0.01);
                                                          solver.setAbsoluteAccuracy(0.0001);
                                                          solver.setRelativeAccuracy(0.0001);
                                                          
                                                          // Call solve with min=1.0, max=2.0
                                                          double result = solver.solve(1.0, 2.0);
                                                          
                                                          // Verify result is max (2.0) not min (1.0)
                                                          assertEquals(2.0, result, 0.0001);
                                                          
                                                          // Verify the function was evaluated at the expected points
                                                          verify(f).value(1.0);
                                                          verify(f).value(2.0);
                                                      }

    @Test
                                                 public void testSolve_ConvergesImmediately_ShouldPassZeroIterationsToSetResult() throws Exception {
                                                     // Create a mock function that returns 0 immediately
                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                     when(f.value(anyDouble())).thenReturn(0.0);
                                                     
                                                     // Create a spy of BrentSolver to verify setResult calls
                                                     BrentSolver solver = spy(new BrentSolver(f));
                                                     
                                                     // Prepare arguments where y1 is already within accuracy
                                                     double x0 = 0.0, y0 = 1.0;
                                                     double x1 = 1.0, y1 = 0.0;  // y1 meets functionValueAccuracy
                                                     double x2 = 2.0, y2 = 1.0;
                                                     
                                                     // Use reflection to access private solve method
                                                     Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                         "solve", double.class, double.class, double.class, 
                                                         double.class, double.class, double.class);
                                                     solveMethod.setAccessible(true);
                                                     solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                     
                                                     // Verify result through reflection
                                                     Field resultField = UnivariateRealSolverImpl.class.getDeclaredField("result");
                                                     resultField.setAccessible(true);
                                                     double result = (Double) resultField.get(solver);
                                                     assertEquals(x1, result, 0.0);
                                                     
                                                     // Verify iteration count through reflection
                                                     Field iterationCountField = UnivariateRealSolverImpl.class.getDeclaredField("iterationCount");
                                                     iterationCountField.setAccessible(true);
                                                     int iterations = (Integer) iterationCountField.get(solver);
                                                     assertEquals(0, iterations);
                                                 }

    @Test
                                             public void testSolve_DetectsMaxEndpointSolutionWithCorrectIterationCount() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                 // Setup - create a function where max is exactly a root
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(1.0)).thenReturn(0.0); // max is solution
                                                 when(f.value(0.0)).thenReturn(1.0); // min is not solution
                                                 when(f.value(0.5)).thenReturn(0.5); // initial is not solution
                                                 
                                                 BrentSolver solver = new BrentSolver(f);
                                                 solver.setFunctionValueAccuracy(1e-6);
                                                 
                                                 // Test - solve with max as exact solution
                                                 double result = solver.solve(0.0, 1.0, 0.5);
                                                 
                                                 // Verify - should return max value with iteration count 0
                                                 // The mutant would set iteration count to -1 instead
                                                 assertEquals(1.0, result, 1e-6);
                                                 
                                                 // Additional verification - check iteration count through reflection if possible
                                                 // Or verify that the result was set with iteration count 0
                                                 // (Assuming there's a way to access this information)
                                                 // This part would depend on how setResult is implemented and what's accessible
                                             }

    @Test
                                             public void testSolve_WhenMaxIsExactRoot_ShouldSetResultWithZeroIterations() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                 // Create a mock function that returns 0 at max
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(1.0)).thenReturn(1.0);  // yMin
                                                 when(f.value(2.0)).thenReturn(0.0);  // yMax (exact root)
                                                 
                                                 // Create solver with default accuracy (1E-6 from constructor)
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 // Call solve - should recognize max as exact root
                                                 double result = solver.solve(1.0, 2.0);
                                                 
                                                 // Verify correct result is returned
                                                 assertEquals(2.0, result, 0.0);
                                                 
                                                 // The mutation would have set iteration count to -1 instead of 0
                                                 // Since we can't directly verify setResult parameters, we rely on the fact that
                                                 // the correct behavior should return max value when it's an exact root
                                                 // The mutant would still return correct value but with wrong internal state
                                                 // To fully catch this, we'd need access to iteration count, but this test
                                                 // combined with others should help identify the issue
                                                 
                                                 // Alternative approach if we could verify internal state:
                                                 // assertEquals(0, solver.getIterationCount());
                                             }

    @Test
                                             public void testSolveSetsResultWhenConverged() throws Exception {
                                                 // Create a mock function that returns 0 at x=2.0
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(1.0)).thenReturn(-1.0);
                                                 when(f.value(2.0)).thenReturn(0.0);
                                                 when(f.value(3.0)).thenReturn(1.0);
                                                 
                                                 // Create solver with tight tolerances to ensure quick convergence
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 // Call solve with initial bracket containing the root
                                                 double result = solver.solve(1.0, 3.0);
                                                 
                                                 // Verify the result is properly set to the root location
                                                 assertEquals(2.0, result, 0.0001);
                                                 
                                                 // If the setResult call was mutated out, this assertion would fail
                                             }

    @Test
                                    public void testSolve_ReturnsMaxEndpointWhenFunctionValueAtMaxIsWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                        // Setup
                                        double min = 0;
                                        double max = 10;
                                        double initial = 5;
                                        double functionValueAccuracy = 1E-6;
                                        
                                        // Mock the function to return 0 at max (within accuracy)
                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                        when(f.value(min)).thenReturn(1.0);  // Not zero
                                        when(f.value(initial)).thenReturn(0.5);  // Not zero
                                        when(f.value(max)).thenReturn(0.0);  // Exactly zero
                                        
                                        // Create solver with mocked function and set accuracy
                                        BrentSolver solver = new BrentSolver(f);
                                        solver.setFunctionValueAccuracy(functionValueAccuracy);
                                        
                                        // Call method
                                        double result = solver.solve(min, max, initial);
                                        
                                        // Verify
                                        assertEquals("Should return max endpoint when f(max) is zero", 
                                                     max, result, 0.0);
                                        
                                        // Additional verification that setResult was called with max and 0
                                        // Note: This would require access to the result field or using a spy
                                        // Since we don't have visibility into the result field, we rely on the return value
                                        // If we had access, we could verify the internal state was set correctly
                                    }

    @Test
                                    public void testSolve_WhenMaxIsRootWithinAccuracy_ShouldSetResult() throws FunctionEvaluationException, MaxIterationsExceededException {
                                        // Setup
                                        double min = 1.0;
                                        double max = 2.0;
                                        double accuracy = 1E-6;
                                        
                                        // Mock the function to return 0 at max (within accuracy)
                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                        when(f.value(min)).thenReturn(1.0);  // Non-zero at min
                                        when(f.value(max)).thenReturn(accuracy/2);  // Within accuracy at max
                                        
                                        // Create solver with small accuracy to trigger the condition
                                        BrentSolver solver = new BrentSolver(f);
                                        solver.setFunctionValueAccuracy(accuracy);
                                        
                                        // Test
                                        double result = solver.solve(min, max);
                                        
                                        // Verify
                                        assertEquals(max, result, 0.0);
                                        // Can't verify protected setResult call directly, but the result value confirms it worked
                                    }

    @Test
                                    public void testSolveThrowsIllegalArgumentExceptionForInvalidInput() throws Exception {
                                        // Setup
                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                        when(f.value(anyDouble())).thenReturn(1.0); // Mock function that never crosses zero
                                        
                                        BrentSolver solver = new BrentSolver(f);
                                        
                                        // We expect IllegalArgumentException when function values don't bracket a root
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("Function values at endpoints must have different signs");
                                        
                                        // Test - provide endpoints where function has same sign at both ends
                                        solver.solve(0.0, 1.0);
                                    }

    @Test
                               public void testSolve_ThrowsIllegalArgumentExceptionWhenNoBracketing() throws FunctionEvaluationException {
                                   // Setup
                                   UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                   when(mockFunction.value(anyDouble())).thenReturn(1.0); // Both endpoints return positive value
                                   
                                   BrentSolver solver = new BrentSolver(mockFunction);
                                   
                                   // Set functionValueAccuracy to ensure we don't hit the "close to zero" case
                                   // Note: This assumes the parent class has a way to set this, or we can use reflection
                                   // For this test, we'll assume the default accuracy is small enough that 1.0 isn't "close to zero"
                                   
                                   // Test - this should throw IllegalArgumentException
                                   try {
                                       solver.solve(0.0, 1.0);
                                       fail("Expected IllegalArgumentException");
                                   } catch (IllegalArgumentException e) {
                                       // Expected
                                   } catch (MaxIterationsExceededException e) {
                                       fail("Unexpected MaxIterationsExceededException");
                                   }
                                   
                                   // The test will pass if IllegalArgumentException is thrown,
                                   // and fail if RuntimeException is thrown (due to mutation)
                               }

    @Test
                           public void testInitialGuessOutsideIntervalThrowsIllegalArgumentException() throws FunctionEvaluationException, MaxIterationsExceededException {
                               // Setup
                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                               BrentSolver solver = new BrentSolver(mockFunction);
                               
                               // Set expectations
                               thrown.expect(IllegalArgumentException.class);
                               thrown.expectMessage("Initial guess is not in search interval.");
                               
                               // Test case where initial is outside [min, max]
                               double min = 0.0;
                               double max = 10.0;
                               double initial = -1.0;  // Clearly outside [min, max]
                               
                               // Execute
                               solver.solve(min, max, initial);
                               
                               // Verification is handled by ExpectedException rule
                           }

    @Test
                           public void testSolve_ThrowsIllegalArgumentExceptionWhenFunctionValuesSameSign() throws Exception {
                               // Setup
                               double min = 1.0;
                               double max = 2.0;
                               double functionValueAccuracy = 1E-6;
                               
                               // Mock the function to return positive values at both endpoints
                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                               when(f.value(min)).thenReturn(1.0);
                               when(f.value(max)).thenReturn(2.0);
                               
                               // Create solver with mocked function
                               BrentSolver solver = new BrentSolver(f);
                               
                               // Set function value accuracy to ensure neither value is considered "close to zero"
                               solver.setFunctionValueAccuracy(functionValueAccuracy);
                               
                               // Expect IllegalArgumentException to be thrown
                               thrown.expect(IllegalArgumentException.class);
                               thrown.expectMessage("Function values at endpoints do not have different signs.");
                               
                               // Execute
                               solver.solve(min, max);
                           }

    @Test
                           public void testConstructorWithNullFunction() {
                               // Set up expectation for the original behavior
                               thrown.expect(IllegalArgumentException.class);
                               thrown.expectMessage("function is null");
                               
                               // Try to create solver with null function
                               new BrentSolver(null);
                           }

    @Test
                  public void testInitialGuessOutsideIntervalThrowsIllegalArgumentException1() throws MaxIterationsExceededException, FunctionEvaluationException {
                      // Setup
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      // Mock function to return values that won't cause iteration issues
                      when(f.value(anyDouble())).thenReturn(1.0);
                      
                      BrentSolver solver = new BrentSolver(f);
                      
                      // Test case where initial guess is below min
                      double min = 1.0;
                      double max = 5.0;
                      double initial = 0.5; // outside [min, max]
                      
                      // Expect IllegalArgumentException
                      thrown.expect(IllegalArgumentException.class);
                      thrown.expectMessage("Initial guess is not in search interval.");
                      
                      // Execute
                      solver.solve(min, max, initial);
                      
                      // The test will fail if NullPointerException is thrown instead
                  }

    @Test
                  public void testInitialGuessAboveMaxThrowsIllegalArgumentException() throws MaxIterationsExceededException, FunctionEvaluationException {
                      // Setup
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      BrentSolver solver = new BrentSolver(f);
                      
                      // Test case where initial guess is above max
                      double min = 1.0;
                      double max = 5.0;
                      double initial = 6.0; // outside [min, max]
                      
                      // Expect IllegalArgumentException
                      thrown.expect(IllegalArgumentException.class);
                      thrown.expectMessage("Initial guess is not in search interval.");
                      
                      // Execute
                      solver.solve(min, max, initial);
                      
                      // The test will fail if NullPointerException is thrown instead
                  }

    @Test
                  public void testSolve_ThrowsIllegalArgumentExceptionWhenNoRootBracketed() throws Exception {
                      // Setup
                      double min = 0.0;
                      double max = 2.0;
                      double functionValueAccuracy = 1E-6;
                      
                      // Mock the function to return positive values at both endpoints
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      when(f.value(min)).thenReturn(1.0);
                      when(f.value(max)).thenReturn(2.0);
                      
                      // Create solver with mocked function
                      BrentSolver solver = new BrentSolver(f);
                      
                      // Set functionValueAccuracy to ensure values aren't considered "close to zero"
                      // Note: This assumes the class has a way to set this value, either through inheritance or directly
                      // If not settable, we rely on default value (1E-6) and ensure our mock values are larger
                      
                      // Expect IllegalArgumentException
                      thrown.expect(IllegalArgumentException.class);
                      thrown.expectMessage("Function values at endpoints do not have different signs.");
                      
                      // Test
                      solver.solve(min, max);
                      
                      // If the mutant is present (throws ArithmeticException), this test will fail
                  }

    @Test
                  public void testSolveThrowsCorrectExceptionType() throws Exception {
                      // Setup
                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                      BrentSolver solver = new BrentSolver(mockFunction);
                      
                      // Set expectations - we expect IllegalArgumentException
                      thrown.expect(IllegalArgumentException.class);
                      
                      // Test with invalid input where min == max
                      // This should trigger IllegalArgumentException in original code
                      // but would throw ArithmeticException in mutated code
                      solver.solve(1.0, 1.0);
                  }

    @Test
         public void testInitialGuessOutsideIntervalThrowsIllegalArgumentException2() {
             // Setup
             UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
             BrentSolver solver = new BrentSolver(mockFunction);
             
             // Set expectations - we expect IllegalArgumentException
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("Initial guess is not in search interval.");
             
             // Test case where initial is outside [min, max]
             // min = 0, max = 10, initial = -1 (outside interval)
             try {
                 solver.solve(0, 10, -1);
             } catch (MaxIterationsExceededException e) {
                 // This shouldn't happen in this test case
                 fail("Unexpected MaxIterationsExceededException");
             } catch (FunctionEvaluationException e) {
                 // This shouldn't happen in this test case
                 fail("Unexpected FunctionEvaluationException");
             }
             
             // If mutant is present, this would throw ArithmeticException instead
             // and the test would fail
         }

    @Test
     public void testSolveWithZeroSign1() throws Exception {
         // Create a mock function that returns zero at x=1.0
         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
         when(f.value(1.0)).thenReturn(0.0);
         when(f.value(anyDouble())).thenReturn(1.0); // default return
         
         BrentSolver solver = new BrentSolver(f);
         
         // Set up initial points where y1 will be exactly zero
         double result = solver.solve(0.0, 1.0, 2.0);
         
         // Verify the result is correctly found at x=1.0
         assertEquals(1.0, result, 1e-6);
         
         // Verify the function was called with the expected values
         verify(f).value(1.0);
         
         // Additional verification that the zero-sign case was handled correctly
         // The original code would handle sign=0 differently than the mutant
         // This test will fail if the mutant is present because the logic path would differ
     }

    @Test
    public void testSolveWithZeroFunctionValueDetectsSignMutation() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that returns zero at initial point
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(anyDouble())).thenReturn(1.0); // default return
        when(f.value(2.0)).thenReturn(0.0); // exact zero at initial=2.0
        
        // Set up solver with tight accuracy
        BrentSolver solver = new BrentSolver(f);
        solver.setFunctionValueAccuracy(1e-10);
        
        // Test parameters where initial guess gives exactly zero
        double min = 1.0;
        double max = 3.0;
        double initial = 2.0;
        
        // The original code would proceed to full Brent algorithm
        // The mutated code would take the zero-sign path
        double result = solver.solve(min, max, initial);
        
        // Verify the result is exactly the initial guess (as it's a root)
        assertEquals(2.0, result, 0.0);
        
        // Verify the function was evaluated at initial point
        verify(f).value(2.0);
        
        // Additional verification that we didn't proceed to full algorithm
        // (would require access to internal state or spy, but this simple test
        // should be sufficient to detect the mutation)
    }

    @Test
    public void testSolve_WhenOneEndpointIsZero_ReturnsEndpointWithoutSolving() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that returns 0 at min and positive at max
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(0.0)).thenReturn(0.0);  // min is root
        when(f.value(1.0)).thenReturn(1.0);  // max is positive
        
        BrentSolver solver = new BrentSolver(f);
        
        // Test case where min is exactly zero (sign == 0)
        double result = solver.solve(0.0, 1.0);
        
        // Verify it returns the root (0.0) without trying to solve
        assertEquals(0.0, result, 0.0001);
        
        // Also test case where max is exactly zero
        when(f.value(0.0)).thenReturn(-1.0);  // min is negative
        when(f.value(1.0)).thenReturn(0.0);   // max is root
        
        result = solver.solve(0.0, 1.0);
        
        // Verify it returns the root (1.0) without trying to solve
        assertEquals(1.0, result, 0.0001);
        
        // Verify no interactions with the solve(min,yMin,max,yMax,...) method
        // (though this would require more advanced verification)
    }


}
