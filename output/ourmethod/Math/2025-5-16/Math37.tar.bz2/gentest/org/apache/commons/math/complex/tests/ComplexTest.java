package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                          public void testTan_NaNValues() {
                              // Test with NaN real part
                              Complex c1 = new Complex(Double.NaN, 1.0);
                              assertEquals(Complex.NaN, c1.tan());
                              
                              // Test with NaN imaginary part
                              Complex c2 = new Complex(1.0, Double.NaN);
                              assertEquals(Complex.NaN, c2.tan());
                              
                              // Test with both parts NaN
                              Complex c3 = new Complex(Double.NaN, Double.NaN);
                              assertEquals(Complex.NaN, c3.tan());
                          }

 @Test
                          public void testTan_InfiniteValues() {
                              // Test with infinite real part
                              Complex c1 = new Complex(Double.POSITIVE_INFINITY, 1.0);
                              assertEquals(Complex.NaN, c1.tan());
                              
                              // Test with infinite imaginary part
                              Complex c2 = new Complex(1.0, Double.POSITIVE_INFINITY);
                              assertEquals(Complex.NaN, c2.tan());
                              
                              // Test with both parts infinite
                              Complex c3 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                              assertEquals(Complex.NaN, c3.tan());
                          }

 @Test
                          public void testTan_LargeImaginaryPositive() {
                              // Test with imaginary part > 20
                              Complex c1 = new Complex(1.0, 21.0);
                              Complex result1 = c1.tan();
                              assertEquals(0.0, result1.getReal(), 1e-15);
                              assertEquals(1.0, result1.getImaginary(), 1e-15);
                              
                              // Test boundary case just above 20
                              Complex c2 = new Complex(1.0, 20.0001);
                              Complex result2 = c2.tan();
                              assertEquals(0.0, result2.getReal(), 1e-15);
                              assertEquals(1.0, result2.getImaginary(), 1e-15);
                          }

 @Test
                          public void testTan_LargeImaginaryNegative() {
                              // Test with imaginary part < -20
                              Complex c1 = new Complex(1.0, -21.0);
                              Complex result1 = c1.tan();
                              assertEquals(0.0, result1.getReal(), 1e-15);
                              assertEquals(-1.0, result1.getImaginary(), 1e-15);
                              
                              // Test boundary case just below -20
                              Complex c2 = new Complex(1.0, -20.0001);
                              Complex result2 = c2.tan();
                              assertEquals(0.0, result2.getReal(), 1e-15);
                              assertEquals(-1.0, result2.getImaginary(), 1e-15);
                          }

 @Test
                          public void testTan_NormalCases() {
                              // Test with zero
                              Complex c1 = new Complex(0.0, 0.0);
                              Complex result1 = c1.tan();
                              assertEquals(0.0, result1.getReal(), 1e-15);
                              assertEquals(0.0, result1.getImaginary(), 1e-15);
                              
                              // Test with real number (imaginary part = 0)
                              Complex c2 = new Complex(Math.PI/4, 0.0);
                              Complex result2 = c2.tan();
                              assertEquals(Math.tan(Math.PI/4), result2.getReal(), 1e-15);
                              assertEquals(0.0, result2.getImaginary(), 1e-15);
                              
                              // Test with pure imaginary number (real part = 0)
                              Complex c3 = new Complex(0.0, 1.0);
                              Complex result3 = c3.tan();
                              assertEquals(0.0, result3.getReal(), 1e-15);
                              assertEquals(Math.tanh(1.0), result3.getImaginary(), 1e-15);
                              
                              // Test with general complex number
                              Complex c4 = new Complex(1.0, 1.0);
                              Complex result4 = c4.tan();
                              double real2 = 2.0;
                              double imag2 = 2.0;
                              double d = FastMath.cos(real2) + FastMath.cosh(imag2);
                              double expectedReal = FastMath.sin(real2) / d;
                              double expectedImag = FastMath.sinh(imag2) / d;
                              assertEquals(expectedReal, result4.getReal(), 1e-15);
                              assertEquals(expectedImag, result4.getImaginary(), 1e-15);
                          }

 @Test
                          public void testTan_BoundaryCases() {
                              // Test exactly at imaginary = 20 (should use normal calculation)
                              Complex c1 = new Complex(1.0, 20.0);
                              Complex result1 = c1.tan();
                              double real2 = 2.0;
                              double imag2 = 40.0;
                              double d = FastMath.cos(real2) + FastMath.cosh(imag2);
                              double expectedReal = FastMath.sin(real2) / d;
                              double expectedImag = FastMath.sinh(imag2) / d;
                              assertEquals(expectedReal, result1.getReal(), 1e-15);
                              assertEquals(expectedImag, result1.getImaginary(), 1e-15);
                              
                              // Test exactly at imaginary = -20 (should use normal calculation)
                              Complex c2 = new Complex(1.0, -20.0);
                              Complex result2 = c2.tan();
                              real2 = 2.0;
                              imag2 = -40.0;
                              d = FastMath.cos(real2) + FastMath.cosh(imag2);
                              expectedReal = FastMath.sin(real2) / d;
                              expectedImag = FastMath.sinh(imag2) / d;
                              assertEquals(expectedReal, result2.getReal(), 1e-15);
                              assertEquals(expectedImag, result2.getImaginary(), 1e-15);
                          }

 @Test
                          public void testTanh_NaNInput() {
                              // Test with NaN real part
                              Complex c1 = new Complex(Double.NaN, 1.0);
                              assertTrue(c1.tanh().isNaN());
                      
                              // Test with NaN imaginary part
                              Complex c2 = new Complex(1.0, Double.NaN);
                              assertTrue(c2.tanh().isNaN());
                      
                              // Test with both parts NaN
                              Complex c3 = new Complex(Double.NaN, Double.NaN);
                              assertTrue(c3.tanh().isNaN());
                          }

 @Test
                          public void testTanh_InfiniteInput() {
                              // Test with infinite real part
                              Complex c1 = new Complex(Double.POSITIVE_INFINITY, 1.0);
                              assertTrue(c1.tanh().isNaN());
                      
                              // Test with infinite imaginary part
                              Complex c2 = new Complex(1.0, Double.POSITIVE_INFINITY);
                              assertTrue(c2.tanh().isNaN());
                      
                              // Test with both parts infinite
                              Complex c3 = new Complex(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY);
                              assertTrue(c3.tanh().isNaN());
                          }

 @Test
                          public void testTanh_LargePositiveReal() {
                              // Test with real part > 20
                              Complex c1 = new Complex(21.0, 0.0);
                              assertEquals(1.0, c1.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c1.tanh().getImaginary(), 0.0001);
                      
                              // Test with real part > 20 and non-zero imaginary
                              Complex c2 = new Complex(25.0, 3.0);
                              assertEquals(1.0, c2.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c2.tanh().getImaginary(), 0.0001);
                          }

 @Test
                          public void testTanh_LargeNegativeReal() {
                              // Test with real part < -20
                              Complex c1 = new Complex(-21.0, 0.0);
                              assertEquals(-1.0, c1.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c1.tanh().getImaginary(), 0.0001);
                      
                              // Test with real part < -20 and non-zero imaginary
                              Complex c2 = new Complex(-25.0, 3.0);
                              assertEquals(-1.0, c2.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c2.tanh().getImaginary(), 0.0001);
                          }

 @Test
                          public void testTanh_NormalCases() {
                              // Test with zero
                              Complex c1 = new Complex(0.0, 0.0);
                              assertEquals(0.0, c1.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c1.tanh().getImaginary(), 0.0001);
                      
                              // Test with real number
                              Complex c2 = new Complex(1.0, 0.0);
                              assertEquals(Math.tanh(1.0), c2.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c2.tanh().getImaginary(), 0.0001);
                      
                              // Test with pure imaginary number
                              Complex c3 = new Complex(0.0, 1.0);
                              assertEquals(0.0, c3.tanh().getReal(), 0.0001);
                              assertEquals(Math.tan(1.0), c3.tanh().getImaginary(), 0.0001);
                      
                              // Test with complex number
                              Complex c4 = new Complex(1.0, 1.0);
                              double real2 = 2.0 * 1.0;
                              double imaginary2 = 2.0 * 1.0;
                              double d = Math.cosh(real2) + Math.cos(imaginary2);
                              double expectedReal = Math.sinh(real2) / d;
                              double expectedImaginary = Math.sin(imaginary2) / d;
                              assertEquals(expectedReal, c4.tanh().getReal(), 0.0001);
                              assertEquals(expectedImaginary, c4.tanh().getImaginary(), 0.0001);
                          }

 @Test
                          public void testTanh_BoundaryCases() {
                              // Test just above the positive threshold
                              Complex c1 = new Complex(20.1, 0.0);
                              assertEquals(1.0, c1.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c1.tanh().getImaginary(), 0.0001);
                      
                              // Test just below the positive threshold
                              Complex c2 = new Complex(19.9, 0.0);
                              double expectedReal = Math.sinh(2.0 * 19.9) / (Math.cosh(2.0 * 19.9) + Math.cos(0.0));
                              assertEquals(expectedReal, c2.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c2.tanh().getImaginary(), 0.0001);
                      
                              // Test just above the negative threshold
                              Complex c3 = new Complex(-20.1, 0.0);
                              assertEquals(-1.0, c3.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c3.tanh().getImaginary(), 0.0001);
                      
                              // Test just below the negative threshold
                              Complex c4 = new Complex(-19.9, 0.0);
                              expectedReal = Math.sinh(2.0 * -19.9) / (Math.cosh(2.0 * -19.9) + Math.cos(0.0));
                              assertEquals(expectedReal, c4.tanh().getReal(), 0.0001);
                              assertEquals(0.0, c4.tanh().getImaginary(), 0.0001);
                          }

 @Test
                      public void testTanh_NaNCase() {
                          // Case 1: isNaN true, imaginary finite
                          Complex c1 = new Complex(Double.NaN, 5.0);
                          assertEquals(Complex.NaN, c1.tanh());
                          
                          // Case 2: isNaN false, imaginary infinite
                          Complex c2 = new Complex(3.0, Double.POSITIVE_INFINITY);
                          assertEquals(Complex.NaN, c2.tanh());
                          
                          // Case 3: Both isNaN true and imaginary infinite
                          Complex c3 = new Complex(Double.NaN, Double.POSITIVE_INFINITY);
                          assertEquals(Complex.NaN, c3.tanh());
                          
                          // Case 4: Normal case (both false)
                          Complex c4 = new Complex(3.0, 4.0);
                          // Just verify it doesn't return NaN
                          assertNotEquals(Complex.NaN, c4.tanh());
                      }

 @Test
                     public void testTanhWithNaN() {
                         // Test case 1: NaN in real part
                         Complex c1 = new Complex(Double.NaN, 1.0);
                         assertTrue("tanh(NaN + i) should be NaN", c1.tanh().isNaN());
                         
                         // Test case 2: NaN in imaginary part
                         Complex c2 = new Complex(1.0, Double.NaN);
                         assertTrue("tanh(1 + NaN*i) should be NaN", c2.tanh().isNaN());
                         
                         // Test case 3: NaN in both parts
                         Complex c3 = new Complex(Double.NaN, Double.NaN);
                         assertTrue("tanh(NaN + NaN*i) should be NaN", c3.tanh().isNaN());
                     }

 @Test
               public void testTanhBoundaryAt() {
                   // Create complex number with real exactly 20.0
                   Complex c = new Complex(20.0, 3.0);
                   
                   // Calculate expected tanh value (what original code would return)
                   double real2 = 2.0 * 20.0;
                   double imaginary2 = 2.0 * 3.0;
                   double d = FastMath.cosh(real2) + FastMath.cos(imaginary2);
                   Complex expected = new Complex(FastMath.sinh(real2)/d, FastMath.sin(imaginary2)/d);
                   
                   // Actual result
                   Complex result = c.tanh();
                   
                   // Verify - should not be (1.0, 0.0) for original code
                   assertNotEquals(1.0, result.getReal(), 0.0001);
                   assertNotEquals(0.0, result.getImaginary(), 0.0001);
                   
                   // Also verify against calculated expected value
                   assertEquals(expected.getReal(), result.getReal(), 0.0001);
                   assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
               }

 @Test
          public void testTanhBoundaryBetween10And() {
              // Create a complex number with real part between 10 and 20
              Complex c = new Complex(15.0, 0.0);
              
              // Calculate expected tanh value (not 1.0 since real < 20.0)
              double real2 = 2.0 * 15.0;
              double imaginary2 = 2.0 * 0.0;
              double d = FastMath.cosh(real2) + FastMath.cos(imaginary2);
              Complex expected = new Complex(FastMath.sinh(real2) / d, 
                                           FastMath.sin(imaginary2) / d);
              
              // Test against actual result
              Complex result = c.tanh();
              
              // This will pass for original code but fail for mutant
              assertEquals(expected.getReal(), result.getReal(), 0.0001);
              assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
              
              // Additional check to ensure it's not returning (1.0, 0.0)
              assertNotEquals(1.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
          }

 @Test
      public void testTanhBoundaryNegative() {
          // Create a complex number with real exactly -20.0
          Complex c = new Complex(-20.0, 0.0);
          
          // Call the tanh method
          Complex result = c.tanh();
          
          // For original code, it should calculate the value
          // For mutant, it will return (-1.0, 0.0)
          
          // Verify it's not returning the special case value (-1.0, 0.0)
          assertNotEquals(-1.0, result.getReal(), 0.0001);
          assertNotEquals(0.0, result.getImaginary(), 0.0001);
          
          // Also verify it's not NaN or infinite
          assertFalse(result.isNaN());
          assertFalse(result.isInfinite());
          
          // Additional check - verify the calculated value is correct
          // Expected value calculated via reference implementation
          double expectedReal = Math.sinh(-40.0) / (Math.cosh(-40.0) + Math.cos(0.0));
          double expectedImaginary = Math.sin(0.0) / (Math.cosh(-40.0) + Math.cos(0.0));
          
          assertEquals(expectedReal, result.getReal(), 0.0001);
          assertEquals(expectedImaginary, result.getImaginary(), 0.0001);
      }

 @Test
         public void testTanhBoundaryConditions() {
             // Test case to catch the real < -20.0 vs real < -10.0 mutation
             
             // Case 1: real < -20.0 (should return -1.0 in both original and mutant)
             Complex c1 = new Complex(-21.0, 0.0);
             Complex result1 = c1.tanh();
             assertEquals(-1.0, result1.getReal(), 0.0001);
             assertEquals(0.0, result1.getImaginary(), 0.0001);
             
             // Case 2: -20.0 < real < -10.0 (critical case to catch mutation)
             // Original should calculate, mutant should return -1.0
             Complex c2 = new Complex(-15.0, 0.0);
             Complex result2 = c2.tanh();
             
             // Verify it's not returning -1.0 (which mutant would do)
             assertNotEquals(-1.0, result2.getReal(), 0.0001);
             
             // Verify it's doing proper calculation (approximate expected value)
             // tanh(-15) should be very close to -1 but not exactly -1
             assertEquals(-0.9999999999999999, result2.getReal(), 0.0001);
             assertEquals(0.0, result2.getImaginary(), 0.0001);
             
             // Case 3: real > -10.0 (should calculate in both)
             Complex c3 = new Complex(-5.0, 0.0);
             Complex result3 = c3.tanh();
             assertEquals(Math.tanh(-5.0), result3.getReal(), 0.0001);
             assertEquals(0.0, result3.getImaginary(), 0.0001);
         }

 @Test
        public void testTanhWithInfiniteImaginary() {
            // Create a complex number with finite real but infinite imaginary part
            Complex c = new Complex(1.0, Double.POSITIVE_INFINITY);
            
            // Verify tanh() returns NaN (original behavior)
            // This will fail if the mutant is present (which skips infinite check)
            assertTrue("tanh() should return NaN for infinite imaginary part", 
                      c.tanh().isNaN());
            
            // Additional verification that it's not just any NaN but the class constant
            assertSame("Should return the class NaN constant",
                      Complex.NaN, c.tanh());
        }

 @Test
        public void testTanhWithNaN1() {
            // Also test the NaN case to ensure that part still works
            Complex c = new Complex(Double.NaN, 1.0);
            assertTrue(c.tanh().isNaN());
            assertSame(Complex.NaN, c.tanh());
        }

 @Test
        public void testTanhWithFiniteValues() {
            // Test normal case to ensure basic functionality works
            Complex c = new Complex(1.0, 1.0);
            Complex result = c.tanh();
            assertFalse(result.isNaN());
            assertFalse(result.isInfinite());
        }

 @Test
   public void testTanh_RealGreaterThan20WithNonPositiveImaginary_ShouldReturnOneZero() {
       // Test case where real > 20.0 and imaginary = 0
       Complex c1 = new Complex(21.0, 0.0);
       Complex result1 = c1.tanh();
       assertEquals(1.0, result1.getReal(), 0.0001);
       assertEquals(0.0, result1.getImaginary(), 0.0001);
       
       // Test case where real > 20.0 and imaginary < 0
       Complex c2 = new Complex(25.0, -5.0);
       Complex result2 = c2.tanh();
       assertEquals(1.0, result2.getReal(), 0.0001);
       assertEquals(0.0, result2.getImaginary(), 0.0001);
       
       // Test case where real > 20.0 and imaginary is negative infinity
       Complex c3 = new Complex(30.0, Double.NEGATIVE_INFINITY);
       Complex result3 = c3.tanh();
       assertTrue(Double.isNaN(result3.getReal()));
       assertTrue(Double.isNaN(result3.getImaginary()));
   }

 @Test
      public void testTanhWithLargeNegativeRealAndNonNegativeImaginary() {
          // This test case should detect the mutant
          Complex c = new Complex(-21.0, 1.0); // real < -20.0, imaginary > 0
          
          // Original should return (-1.0, 0.0)
          // Mutant will calculate the actual tanh value
          Complex result = c.tanh();
          
          // Verify real part is -1.0 (original behavior)
          assertEquals(-1.0, result.getReal(), 0.0001);
          // Verify imaginary part is 0.0 (original behavior)
          assertEquals(0.0, result.getImaginary(), 0.0001);
      }

 @Test
      public void testTanhWithLargeNegativeRealAndNegativeImaginary() {
          // This is the case where both versions behave the same
          Complex c = new Complex(-21.0, -1.0); // real < -20.0, imaginary < 0
          
          Complex result = c.tanh();
          
          // Both should return (-1.0, 0.0)
          assertEquals(-1.0, result.getReal(), 0.0001);
          assertEquals(0.0, result.getImaginary(), 0.0001);
      }

 @Test
     public void testTanhWithNaN2() {
         // Create a NaN complex number
         Complex nanComplex = new Complex(Double.NaN, 0.0);
         
         // Test tanh should return NaN
         Complex result = nanComplex.tanh();
         assertTrue("tanh of NaN should return NaN", result.isNaN());
     }

 @Test
     public void testTanhWithInfiniteImaginary1() {
         // Create complex with infinite imaginary part
         Complex infiniteImaginary = new Complex(0.0, Double.POSITIVE_INFINITY);
         
         // Test tanh should return NaN
         Complex result = infiniteImaginary.tanh();
         assertTrue("tanh with infinite imaginary should return NaN", result.isNaN());
     }

 @Test
     public void testTanhWithNegativeInfiniteImaginary() {
         // Create complex with negative infinite imaginary part
         Complex negativeInfiniteImaginary = new Complex(0.0, Double.NEGATIVE_INFINITY);
         
         // Test tanh should return NaN
         Complex result = negativeInfiniteImaginary.tanh();
         assertTrue("tanh with negative infinite imaginary should return NaN", result.isNaN());
     }

}
