package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class UnivariateRealSolverUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                         public void testBracket_ConvergesWithinBounds() throws Exception {
                                                                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(function.value(anyDouble())).thenReturn(-1.0, 1.0); // First negative, then positive
                                                                                                                                                                                             
                                                                                                                                                                                             double initial = 1.0;
                                                                                                                                                                                             double lowerBound = 0.0;
                                                                                                                                                                                             double upperBound = 2.0;
                                                                                                                                                                                             
                                                                                                                                                                                             double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                                                                                                                                                             
                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                             assertEquals(2, result.length);
                                                                                                                                                                                             assertTrue(result[0] < result[1]);
                                                                                                                                                                                             assertTrue(result[0] >= lowerBound);
                                                                                                                                                                                             assertTrue(result[1] <= upperBound);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testBracket_InitialAtLowerBound() throws Exception {
                                                                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(function.value(anyDouble())).thenReturn(-1.0, 1.0);
                                                                                                                                                                                             
                                                                                                                                                                                             double initial = 0.0;
                                                                                                                                                                                             double lowerBound = 0.0;
                                                                                                                                                                                             double upperBound = 2.0;
                                                                                                                                                                                             
                                                                                                                                                                                             double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                                                                                                                                                             
                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                             assertEquals(2, result.length);
                                                                                                                                                                                             assertTrue(result[0] >= lowerBound);
                                                                                                                                                                                             assertTrue(result[1] <= upperBound);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testBracket_InitialAtUpperBound() throws Exception {
                                                                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(function.value(anyDouble())).thenReturn(1.0, -1.0);
                                                                                                                                                                                             
                                                                                                                                                                                             double initial = 2.0;
                                                                                                                                                                                             double lowerBound = 0.0;
                                                                                                                                                                                             double upperBound = 2.0;
                                                                                                                                                                                             
                                                                                                                                                                                             double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                                                                                                                                                             
                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                             assertEquals(2, result.length);
                                                                                                                                                                                             assertTrue(result[0] >= lowerBound);
                                                                                                                                                                                             assertTrue(result[1] <= upperBound);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testBracket_SuccessfulBracketing() throws Exception {
                                                                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                             when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                             when(function.value(0.5)).thenReturn(-2.0);
                                                                                                                                                                                             when(function.value(3.0)).thenReturn(2.0);
                                                                                                                                                                                             
                                                                                                                                                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 4.0, 100);
                                                                                                                                                                                             
                                                                                                                                                                                             assertEquals(2, result.length);
                                                                                                                                                                                             assertTrue(result[0] < result[1]);
                                                                                                                                                                                             assertTrue(function.value(result[0]) * function.value(result[1]) <= 0.0);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testBracket_AlreadyBracketed() throws Exception {
                                                                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(function.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                             when(function.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                             
                                                                                                                                                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 2.0, 100);
                                                                                                                                                                                             
                                                                                                                                                                                             assertEquals(2, result.length);
                                                                                                                                                                                             assertEquals(1.0, result[0], 0.0001);
                                                                                                                                                                                             assertEquals(2.0, result[1], 0.0001);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testBracket_ExpandsToBounds() throws Exception {
                                                                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             when(function.value(0.0)).thenReturn(-1.0);
                                                                                                                                                                                             when(function.value(4.0)).thenReturn(1.0);
                                                                                                                                                                                             when(function.value(1.0)).thenReturn(-0.5);
                                                                                                                                                                                             when(function.value(3.0)).thenReturn(0.5);
                                                                                                                                                                                             
                                                                                                                                                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 4.0, 100);
                                                                                                                                                                                             
                                                                                                                                                                                             assertEquals(2, result.length);
                                                                                                                                                                                             assertTrue(result[0] == 0.0 || result[1] == 4.0);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testBracket_ReachesMaximumIterations() throws Exception {
                                                                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                             // Mock function to change sign just before max iterations
                                                                                                                                                                                             when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                                                                                                                                                                 double x = (Double)invocation.getArguments()[0];
                                                                                                                                                                                                 return x < 1.5 ? -1.0 : 1.0;
                                                                                                                                                                                             });
                                                                                                                                                                                             
                                                                                                                                                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 3.0, 2);
                                                                                                                                                                                             
                                                                                                                                                                                             assertEquals(2, result.length);
                                                                                                                                                                                             assertTrue(function.value(result[0]) * function.value(result[1]) <= 0.0);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                 public void testBracket_InvalidMaximumIterations() throws Exception {
                                                                                                                                                                                     // Setup
                                                                                                                                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                     
                                                                                                                                                                                     // Expect exception
                                                                                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                     exception.expectMessage("bad value for maximum iterations number: 0");
                                                                                                                                                                                     
                                                                                                                                                                                     // Test
                                                                                                                                                                                     UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 0);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testBracket_InvalidBracketingParameters() throws Exception {
                                                                                                                                                                                     // Setup Mockito
                                                                                                                                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                     
                                                                                                                                                                                     // Setup exception rule
                                                                                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                     
                                                                                                                                                                                     // Test initial < lowerBound
                                                                                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                     exception.expectMessage("invalid bracketing parameters");
                                                                                                                                                                                     UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 2.0, 100);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test initial > upperBound
                                                                                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                     exception.expectMessage("invalid bracketing parameters");
                                                                                                                                                                                     UnivariateRealSolverUtils.bracket(function, 3.0, 0.0, 2.0, 100);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test lowerBound >= upperBound
                                                                                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                     exception.expectMessage("invalid bracketing parameters");
                                                                                                                                                                                     UnivariateRealSolverUtils.bracket(function, 1.0, 2.0, 2.0, 100);
                                                                                                                                                                                 }

    @Test
                                                                                                                                         public void testBracket_InvalidBounds() throws Exception {
                                                                                                                                             // Setup mock
                                                                                                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                             
                                                                                                                                             // Test data - invalid bounds (upper < lower)
                                                                                                                                             double initial = 1.0;
                                                                                                                                             double lowerBound = 2.0;
                                                                                                                                             double upperBound = 0.0;
                                                                                                                                             
                                                                                                                                             // Expected exception
                                                                                                                                             
                                                                                                                                             // Method under test
                                                                                                                                             UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                                                                                                         }

    @Test
                                                                                                                                         public void testBracket_InitialOutsideBounds() throws Exception {
                                                                                                                                             // Setup
                                                                                                                                             UnivariateRealFunction function = new UnivariateRealFunction() {
                                                                                                                                                 public double value(double x) {
                                                                                                                                                     return 0;
                                                                                                                                                 }
                                                                                                                                             };
                                                                                                                                             
                                                                                                                                             // Test parameters
                                                                                                                                             double initial = -1.0;
                                                                                                                                             double lowerBound = 0.0;
                                                                                                                                             double upperBound = 2.0;
                                                                                                                                             
                                                                                                                                             // Expected exception
                                                                                                                                             try {
                                                                                                                                                 UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                                                                                                                 fail("Expected IllegalArgumentException");
                                                                                                                                             } catch (IllegalArgumentException e) {
                                                                                                                                                 assertEquals("initial value is not in [lowerBound, upperBound] range", e.getMessage());
                                                                                                                                             }
                                                                                                                                         }

    @Test
                                                                                                                                         public void testBracket_FunctionIsNull() throws Exception {
                                                                                                                                             try {
                                                                                                                                                 UnivariateRealSolverUtils.bracket(null, 1.0, 0.0, 2.0, 100);
                                                                                                                                                 fail("Expected IllegalArgumentException");
                                                                                                                                             } catch (IllegalArgumentException e) {
                                                                                                                                                 assertEquals("function is null", e.getMessage());
                                                                                                                                             }
                                                                                                                                         }

    @Test(expected = org.apache.commons.math.ConvergenceException.class)
                                                                                                 public void testBracket_NoBracketFound() throws Exception {
                                                                                                     // Setup Mockito
                                                                                                     org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                                                                         new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                             public double value(double x) {
                                                                                                                 return 1.0; // Function that never crosses zero
                                                                                                             }
                                                                                                         };
                                                                                                     
                                                                                                     // Define test parameters
                                                                                                     double initial = 0.5;
                                                                                                     double lowerBound = -1.0;
                                                                                                     double upperBound = 1.0;
                                                                                                     int maximumIterations = 100;
                                                                                                     
                                                                                                     // Execute test - should throw ConvergenceException when no bracket found
                                                                                                     org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(
                                                                                                         function, initial, lowerBound, upperBound, maximumIterations
                                                                                                     );
                                                                                                 }

    @Test
                                                                                                 public void testBracket_ConvergenceFailure() throws Exception {
                                                                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                     // Mock function to always return positive values
                                                                                                     when(function.value(anyDouble())).thenReturn(1.0);
                                                                                                     
                                                                                                     try {
                                                                                                         UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 4.0, 10);
                                                                                                         fail("Expected ConvergenceException");
                                                                                                     } catch (ConvergenceException e) {
                                                                                                         assertTrue(e.getMessage().contains("number of iterations"));
                                                                                                     }
                                                                                                 }

    @Test
                                                             public void testBracketWithFunctionHittingZero() throws Exception {
                                                                 // Create a mock function that returns 0 at x=2.0
                                                                 UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                 when(function.value(1.0)).thenReturn(1.0);
                                                                 when(function.value(2.0)).thenReturn(0.0);  // Function hits zero here
                                                                 when(function.value(3.0)).thenReturn(-1.0);
                                                                 
                                                                 // Test parameters
                                                                 double initial = 1.5;
                                                                 double lowerBound = 1.0;
                                                                 double upperBound = 3.0;
                                                                 int maxIterations = 100;
                                                                 
                                                                 // Call the method
                                                                 double[] result = UnivariateRealSolverUtils.bracket(
                                                                     function, initial, lowerBound, upperBound, maxIterations);
                                                                 
                                                                 // Verify the result contains the zero point (x=2.0)
                                                                 // The original implementation would include the zero point in the bracket
                                                                 // while the mutant might continue searching beyond it
                                                                 assertTrue("Result should include the zero point", 
                                                                     (result[0] == 2.0 || result[1] == 2.0));
                                                                 
                                                                 // Verify the bracket contains values with opposite signs
                                                                 double fa = function.value(result[0]);
                                                                 double fb = function.value(result[1]);
                                                                 assertTrue("Bracket should contain values with opposite signs", 
                                                                     fa * fb <= 0);
                                                             }

    @Test
                                                             public void testBracketWithFunctionZeroAtBoundary() throws Exception {
                                                                 // Create a mock function that returns zero at upper bound
                                                                 UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                 when(function.value(anyDouble())).thenReturn(1.0); // default return
                                                                 when(function.value(5.0)).thenReturn(0.0); // zero at upper bound
                                                                 
                                                                 double initial = 3.0;
                                                                 double lowerBound = 1.0;
                                                                 double upperBound = 5.0;
                                                                 int maxIterations = 100;
                                                                 
                                                                 // Call the method
                                                                 double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                                                 
                                                                 // Verify the loop would stop when hitting zero at boundary
                                                                 // Original would stop when fb=0 (fa*fb=0), mutant would continue
                                                                 // Assert the result is correct (should be [a,5.0] where f(a)>0 and f(5.0)=0)
                                                                 assertEquals(0.0, function.value(result[1]), 0.0001);
                                                                 assertTrue(function.value(result[0]) > 0);
                                                                 
                                                                 // Verify we didn't do unnecessary iterations
                                                                 // With the mutant, it would do more iterations than needed
                                                                 // We know it should find the zero in at most (upperBound - initial) iterations
                                                                 // since it expands by 1.0 each iteration
                                                                 assertTrue(Math.abs(result[1] - initial) <= maxIterations);
                                                             }

    @Test(expected = ConvergenceException.class)
                                                             public void testBracketThrowsWhenNoBracketFound() throws Exception {
                                                                 // Create a function that never crosses zero
                                                                 UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                 when(function.value(anyDouble())).thenReturn(1.0);
                                                                 
                                                                 double initial = 3.0;
                                                                 double lowerBound = 1.0;
                                                                 double upperBound = 5.0;
                                                                 int maxIterations = 10; // small number to force exception
                                                                 
                                                                 // This should throw as we'll hit max iterations before finding a bracket
                                                                 UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                                             }

    @Test
                                                        public void testBracketIterationLimit() throws Exception {
                                                            // Create a mock function that will require exactly maximum iterations
                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                            
                                                            // Setup function values to keep fa*fb > 0 until max iterations
                                                            when(function.value(anyDouble())).thenReturn(1.0); // Always positive
                                                            
                                                            double initial = 0.5;
                                                            double lowerBound = 0.0;
                                                            double upperBound = 1.0;
                                                            int maximumIterations = 3; // Small number for testing
                                                            
                                                            try {
                                                                // This should throw an exception when max iterations reached
                                                                UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maximumIterations);
                                                                fail("Expected exception not thrown");
                                                            } catch (Exception e) {
                                                                // Verify the exception message contains iteration limit info
                                                                assertTrue(e.getMessage().contains("maximum iterations"));
                                                                
                                                                // The mutant would have done one extra iteration before throwing
                                                                // Original would throw at exactly maximumIterations (3)
                                                                // Mutant would throw at maximumIterations+1 (4)
                                                                // We can't directly check iterations, but we can verify the exception
                                                                // message format which should show the correct iteration count
                                                                assertFalse(e.getMessage().contains(String.valueOf(maximumIterations + 1)));
                                                            }
                                                            
                                                            // Additional test to verify normal case doesn't throw
                                                            when(function.value(0.0)).thenReturn(-1.0); // Now fa*fb will be negative
                                                            double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maximumIterations);
                                                            assertNotNull(result);
                                                            assertEquals(2, result.length);
                                                        }

    @Test
                                                        public void testBracketLoopAtMaximumIterations() throws Exception {
                                                            // Create a mock function that always returns positive values
                                                            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                            when(function.value(anyDouble())).thenReturn(1.0);
                                                            
                                                            double initial = 5.0;
                                                            double lowerBound = 0.0;
                                                            double upperBound = 10.0;
                                                            int maximumIterations = 3;  // Small number to easily reach limit
                                                            
                                                            try {
                                                                UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maximumIterations);
                                                                fail("Expected ConvergenceException");
                                                            } catch (ConvergenceException e) {
                                                                // Verify the exception message contains the expected iteration count
                                                                assertTrue(e.getMessage().contains("number of iterations=3"));
                                                                // The mutated version would show iterations=4
                                                            }
                                                            
                                                            // Additional verification that we didn't exceed bounds
                                                            verify(function, times(6)).value(anyDouble()); // 3 iterations * 2 points per iteration
                                                            // Mutated version would call 8 times (4 iterations)
                                                        }

    @Test
                                                  public void testBracketWithInitialEqualsLowerBound() {
                                                      // Setup
                                                      UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                      double initial = 1.0;
                                                      double lowerBound = 1.0;  // Initial equals lower bound
                                                      double upperBound = 5.0;
                                                      
                                                      try {
                                                          // This should throw an exception in original version
                                                          UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                          
                                                          // If we get here, the mutant survived (bad)
                                                          fail("Expected IllegalArgumentException when initial equals lower bound");
                                                      } catch (FunctionEvaluationException e) {
                                                          fail("Unexpected FunctionEvaluationException occurred");
                                                      } catch (IllegalArgumentException e) {
                                                          // This is expected behavior for original version
                                                          assertTrue(e.getMessage().contains("invalid bounds"));
                                                      } catch (ConvergenceException e) {
                                                          fail("Unexpected ConvergenceException occurred");
                                                      }
                                                  }

    @Test
                                                  public void testBracketWhenAExactlyEqualsLowerBound() throws FunctionEvaluationException {
                                                      // Create a mock function that returns positive values when x >= 0
                                                      UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                      when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                          double x = invocation.getArgument(0);
                                                          return x >= 0 ? 1.0 : -1.0;
                                                      });
                                                      
                                                      // Set parameters where initial is at lower bound (0)
                                                      double initial = 0.0;
                                                      double lowerBound = 0.0;
                                                      double upperBound = 10.0;
                                                      int maxIterations = 100;
                                                      
                                                      try {
                                                          // Call the method - should throw ConvergenceException since all values are positive
                                                          UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                                          fail("Expected ConvergenceException");
                                                      } catch (ConvergenceException e) {
                                                          // Verify the final a value equals lowerBound (0)
                                                          String message = e.getMessage();
                                                          assertTrue(message.contains("final a value=0.0"));
                                                          
                                                          // Verify number of iterations is 1 (original behavior)
                                                          // Mutated version would do 2 iterations
                                                          assertTrue(message.contains("number of iterations=1"));
                                                      } catch (FunctionEvaluationException e) {
                                                          fail("Unexpected FunctionEvaluationException");
                                                      }
                                                      
                                                      // Additional verification for the case where it should succeed
                                                      // Change function to cross zero at x=1
                                                      when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                          double x = invocation.getArgument(0);
                                                          return x >= 1.0 ? 1.0 : -1.0;
                                                      });
                                                      
                                                      try {
                                                          double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                                          assertEquals(0.0, result[0], 0.0001);  // a should be 0
                                                          assertEquals(1.0, result[1], 0.0001);  // b should be 1 (first point where f changes sign)
                                                      } catch (ConvergenceException e) {
                                                          fail("Unexpected ConvergenceException");
                                                      } catch (FunctionEvaluationException e) {
                                                          fail("Unexpected FunctionEvaluationException");
                                                      }
                                                  }

    @Test
                                             public void testBracketWhenOnlyOneBoundCanExpand() throws FunctionEvaluationException {
                                                 // Create a mock function that always returns positive values
                                                 UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                 when(function.value(anyDouble())).thenReturn(1.0);
                                                 
                                                 // Set bounds where only upper bound can expand (initial at lower bound)
                                                 double initial = 0.0;
                                                 double lowerBound = 0.0;
                                                 double upperBound = 10.0;
                                                 int maxIterations = 100;
                                                 
                                                 try {
                                                     // This should throw ConvergenceException when loop completes
                                                     UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                                     fail("Expected ConvergenceException");
                                                 } catch (ConvergenceException e) {
                                                     // Verify the final bounds reached maximum expansion
                                                     String msg = e.getMessage();
                                                     assertTrue(msg.contains("final a value=0.0"));  // Couldn't expand lower bound
                                                     assertTrue(msg.contains("final b value=10.0")); // Should have expanded to upper bound
                                                     
                                                     // Verify iterations reached max (shows loop continued until max iterations)
                                                     assertTrue(msg.contains("number of iterations=100"));
                                                 } catch (FunctionEvaluationException fee) {
                                                     fail("Unexpected FunctionEvaluationException");
                                                 }
                                                 
                                                 // Test opposite case where only lower bound can expand
                                                 initial = 10.0;
                                                 lowerBound = 0.0;
                                                 upperBound = 10.0;
                                                 
                                                 try {
                                                     UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                                     fail("Expected ConvergenceException");
                                                 } catch (ConvergenceException e) {
                                                     String msg = e.getMessage();
                                                     assertTrue(msg.contains("final a value=0.0"));  // Should have expanded to lower bound
                                                     assertTrue(msg.contains("final b value=10.0")); // Couldn't expand upper bound
                                                     assertTrue(msg.contains("number of iterations=100"));
                                                 } catch (FunctionEvaluationException fee) {
                                                     fail("Unexpected FunctionEvaluationException");
                                                 }
                                             }

    @Test
                                         public void testBracketConditionWithOnlyRightConditionTrue() {
                                             // Setup
                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                             double initial = 1.0;
                                             double lowerBound = 0.0;
                                             double upperBound = 2.0;
                                             
                                             // Mock function behavior where a <= lowerBound but b < upperBound
                                             try {
                                                 when(function.value(anyDouble())).thenReturn(1.0, -1.0);
                                             } catch (FunctionEvaluationException e) {
                                                 fail("Mock setup should not throw FunctionEvaluationException");
                                             }
                                             
                                             try {
                                                 // This should work in original but fail in mutant
                                                 double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                                 
                                                 // Verify the result contains valid bracket
                                                 assertTrue("Left bracket should be <= right bracket", result[0] <= result[1]);
                                                 try {
                                                     assertTrue("Function values should have opposite signs", 
                                                               function.value(result[0]) * function.value(result[1]) <= 0);
                                                 } catch (FunctionEvaluationException e) {
                                                     fail("Function evaluation should not throw exception for test values");
                                                 }
                                             } catch (FunctionEvaluationException e) {
                                                 fail("Original implementation should not throw FunctionEvaluationException for this case");
                                             } catch (Exception e) {
                                                 fail("Original implementation should not throw exception for this case");
                                             }
                                         }

    @Test
                                     public void testBracketConditionWithOnlyLeftConditionTrue() throws FunctionEvaluationException {
                                         // Setup
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         double initial = 1.0;
                                         double lowerBound = 0.0;
                                         double upperBound = 2.0;
                                         
                                         // Mock function behavior where a > lowerBound but b >= upperBound
                                         when(function.value(anyDouble())).thenReturn(-1.0, 1.0);
                                         
                                         try {
                                             // This should work in original but fail in mutant
                                             double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                             
                                             // Verify the result contains valid bracket
                                             assertTrue("Left bracket should be <= right bracket", result[0] <= result[1]);
                                             assertTrue("Function values should have opposite signs", 
                                                        function.value(result[0]) * function.value(result[1]) <= 0);
                                         } catch (Exception e) {
                                             fail("Original implementation should not throw exception for this case");
                                         }
                                     }

    @Test
                                public void testBracketUpperBoundEquality() {
                                    // Create a mock function that returns negative at lower bound and positive at upper bound
                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                    try {
                                        when(function.value(anyDouble())).thenAnswer(invocation -> {
                                            double x = invocation.getArgument(0);
                                            return x < 5.0 ? -1.0 : 1.0;  // Root at exactly 5.0
                                        });
                                    } catch (FunctionEvaluationException e) {
                                        fail("Mock function threw unexpected exception: " + e.getMessage());
                                    }
                                    
                                    // Test parameters where upper bound would be exactly hit
                                    double initial = 4.0;
                                    double lowerBound = 0.0;
                                    double upperBound = 5.0;
                                    
                                    // Call the method (note: we need to access the private method via reflection)
                                    try {
                                        Method bracketMethod = UnivariateRealSolverUtils.class.getDeclaredMethod(
                                            "bracket", 
                                            UnivariateRealFunction.class, 
                                            double.class, 
                                            double.class, 
                                            double.class, 
                                            int.class
                                        );
                                        bracketMethod.setAccessible(true);
                                        
                                        double[] result = (double[]) bracketMethod.invoke(
                                            null, 
                                            function, 
                                            initial, 
                                            lowerBound, 
                                            upperBound, 
                                            100
                                        );
                                        
                                        // Verify the upper bound is not included in the bracket
                                        assertTrue("Upper bound should not be included in result", 
                                                 result[1] < upperBound);
                                    } catch (Exception e) {
                                        fail("Failed to test private bracket method: " + e.getMessage());
                                    }
                                }

    @Test
                                public void testBracketWhenBEqualsUpperBound() throws FunctionEvaluationException {
                                    // Setup a function that's always positive (so loop will run until bounds are hit)
                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                    when(function.value(anyDouble())).thenReturn(1.0);
                                    
                                    // Set bounds and initial value such that b will exactly hit upperBound
                                    double initial = 5.0;
                                    double lowerBound = 0.0;
                                    double upperBound = 10.0;
                                    int maxIterations = 100;
                                    
                                    try {
                                        double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                        fail("Expected ConvergenceException");
                                    } catch (ConvergenceException e) {
                                        // Verify the exception message contains the expected iteration count
                                        // Original would stop when b reaches 10.0 (upperBound)
                                        // Mutant would do one extra iteration when b equals upperBound
                                        String msg = e.getMessage();
                                        assertTrue(msg.contains("number of iterations=6")); // Expected iteration count for original
                                        // Mutant would show 7 iterations here
                                    }
                                    
                                    // Alternative verification by counting function.value() calls
                                    // Original would call value() 2*6=12 times (a and b each iteration)
                                    // Mutant would call 2*7=14 times
                                    verify(function, times(12)).value(anyDouble());
                                }

    @Test
                                public void testBracketWithOppositeSigns() throws Exception {
                                    // Create a mock function that returns opposite signs
                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                    when(function.value(0.0)).thenReturn(-1.0);
                                    when(function.value(1.0)).thenReturn(1.0);
                                    
                                    // Call the bracket method - should work in both original and mutant
                                    double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0);
                                    
                                    // Verify the result contains the expected bounds
                                    assertEquals(0.0, result[0], 0.0001);
                                    assertEquals(1.0, result[1], 0.0001);
                                }

    @Test(expected = ConvergenceException.class)
                                public void testBracketDetectsNegativeProduct() throws Exception {
                                    // Create a mock function that always returns negative values
                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                    when(function.value(anyDouble())).thenReturn(-1.0);
                                    
                                    // Test parameters
                                    double initial = 0.5;
                                    double lowerBound = 0.0;
                                    double upperBound = 1.0;
                                    int maxIterations = 100;
                                    
                                    // This should throw ConvergenceException in original code
                                    // But would pass in mutated code
                                    UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                }

    @Test(expected = ConvergenceException.class)
                                public void testBracketDetectsPositiveProduct() throws Exception {
                                    // Create a mock function that always returns positive values
                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                    when(function.value(anyDouble())).thenReturn(1.0);
                                    
                                    // Test parameters
                                    double initial = 0.5;
                                    double lowerBound = 0.0;
                                    double upperBound = 1.0;
                                    int maxIterations = 100;
                                    
                                    // This should throw ConvergenceException in both original and mutated code
                                    UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                                }

    @Test
                           public void testBracketWithPositiveFunctionValues() {
                               // Create a mock function that returns positive values
                               UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                               try {
                                   when(function.value(anyDouble())).thenReturn(1.0);
                               } catch (FunctionEvaluationException e) {
                                   fail("Mock setup failed");
                               }
                               
                               try {
                                   // Call the bracket method with parameters that would make fa and fb positive
                                   double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0);
                                   
                                   // Both original and mutant should throw exception here
                                   fail("Expected IllegalArgumentException when function values have same sign");
                               } catch (IllegalArgumentException e) {
                                   // Both versions should throw this
                                   assertEquals("Function values at endpoints do not have different signs.", e.getMessage());
                               } catch (ConvergenceException e) {
                                   fail("Unexpected ConvergenceException");
                               } catch (FunctionEvaluationException e) {
                                   fail("Unexpected FunctionEvaluationException");
                               }
                           }

    @Test
                   public void testBracketWithNegativeFunctionValues() {
                       // Create a mock function that returns negative values
                       UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                       try {
                           when(function.value(anyDouble())).thenReturn(-1.0);
                       } catch (FunctionEvaluationException e) {
                           fail("Unexpected exception during mock setup: " + e.getMessage());
                       }
                       
                       try {
                           // Call the bracket method with parameters that would make fa and fb negative
                           double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0);
                           
                           // In original code, this should throw exception since same signs mean no root bracketed
                           // But mutant would pass because it only checks for positive values
                           fail("Expected IllegalArgumentException when function values have same sign");
                       } catch (FunctionEvaluationException e) {
                           // This is unexpected for this test case
                           fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                       } catch (ConvergenceException e) {
                           // This is unexpected for this test case
                           fail("Unexpected ConvergenceException: " + e.getMessage());
                       } catch (IllegalArgumentException e) {
                           // This is expected for original code
                           assertEquals("Function values at endpoints do not have different signs.", e.getMessage());
                       }
                   }

    @Test
               public void testBracketDetectsSignChangeWithPositiveSum() throws Exception {
                   // Create a mock function that returns:
                   // - positive value at left bound (3.0)
                   // - negative value at right bound (-2.0)
                   // This creates a case where fa*fb < 0 (should stop) but fa+fb > 0 (mutant would continue)
                   UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                   when(function.value(anyDouble())).thenAnswer(invocation -> {
                       double x = invocation.getArgument(0);
                       if (x <= 1.0) return 3.0;  // left side positive
                       else return -2.0;          // right side negative
                   });
               
                   // Test parameters
                   double initial = 0.5;
                   double lowerBound = 0.0;
                   double upperBound = 2.0;
                   int maxIterations = 100;
               
                   // Call the method
                   double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
               
                   // Verify the result contains valid bounds
                   assertNotNull(result);
                   assertEquals(2, result.length);
                   
                   // Verify the function values have opposite signs
                   double fa = function.value(result[0]);
                   double fb = function.value(result[1]);
                   assertTrue(fa * fb <= 0.0);  // This would fail with the mutant
                   
                   // Additional verification that we didn't hit max iterations
                   assertTrue(Math.abs(fa) > 0 || Math.abs(fb) > 0);  // Not both zero
               }

    @Test
              public void testBracketDetectsSignChangeWhenSumPositive() throws FunctionEvaluationException, ConvergenceException {
                  // Create a mock function that returns:
                  // f(0) = 2.0 (positive)
                  // f(1) = -1.0 (negative)
                  // Sum is positive (1.0) but signs differ
                  UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                  when(function.value(0.0)).thenReturn(2.0);
                  when(function.value(1.0)).thenReturn(-1.0);
                  
                  // Test with bounds that would catch the mutant
                  double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0);
                  
                  // Original would continue searching since signs differ
                  // Mutant would continue searching since sum is positive
                  // We need to verify the method properly handles this case
                  assertNotNull(result);
                  assertEquals(2, result.length);
                  assertTrue("Lower bound function value should be positive", 
                      function.value(result[0]) > 0);
                  assertTrue("Upper bound function value should be negative",
                      function.value(result[1]) < 0);
              }

    @Test
              public void testBracketDetectsNegativeValuesWithPositiveSum() throws FunctionEvaluationException, ConvergenceException {
                  // Create a mock function that returns:
                  // f(0) = -1.0 (negative)
                  // f(1) = 2.0 (positive)
                  // Sum is positive (1.0) and signs differ
                  UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                  when(function.value(0.0)).thenReturn(-1.0);
                  when(function.value(1.0)).thenReturn(2.0);
                  
                  double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0);
                  
                  assertNotNull(result);
                  assertEquals(2, result.length);
                  assertTrue("Lower bound function value should be negative", 
                      function.value(result[0]) < 0);
                  assertTrue("Upper bound function value should be positive",
                      function.value(result[1]) > 0);
              }

    @Test
         public void testBracketConditionWhenAEqualsLowerBound() {
             // Create a mock function that doesn't bracket a root initially
             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
             try {
                 when(function.value(anyDouble())).thenReturn(1.0); // Always positive, no root
             } catch (FunctionEvaluationException e) {
                 fail("Unexpected FunctionEvaluationException during mock setup");
             }
             
             double initial = 2.0;
             double lowerBound = 2.0; // a will equal lower bound
             double upperBound = 5.0;
             
             try {
                 // Call the method that uses the bracket helper
                 double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                 
                 // If we get here, the mutant survived (continued when it should have stopped)
                 fail("Mutant survived - method continued when a equaled lower bound");
             } catch (Exception e) {
                 // Original should throw when it can't bracket a root
                 assertTrue(e instanceof IllegalArgumentException);
             }
         }

    @Test
         public void testBracketDetectsMutatedBoundaryCondition() throws FunctionEvaluationException {
             // Create a mock function that always returns positive values
             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
             when(function.value(anyDouble())).thenReturn(1.0);
             
             // Set parameters where initial equals lower bound
             double initial = 0.0;
             double lowerBound = 0.0;
             double upperBound = 10.0;
             int maxIterations = 100;
             
             try {
                 // This should throw ConvergenceException when bounds are exhausted
                 UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                 fail("Expected ConvergenceException");
             } catch (ConvergenceException e) {
                 // Verify the final values show we hit the lower bound exactly
                 String msg = e.getMessage();
                 assertTrue(msg.contains("final a value=0.0"));  // a should be exactly at lower bound
                 assertTrue(msg.contains("final b value="));     // b should have increased
             }
             
             // Verify the function was called with a=lowerBound exactly
             verify(function).value(lowerBound);
         }

    @Test
    public void testBracketUpperBoundViolation() {
        // Create a mock function that never crosses zero
        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
        try {
            when(function.value(anyDouble())).thenReturn(1.0); // Always positive
        } catch (FunctionEvaluationException e) {
            fail("Mock setup failed");
        }
        
        double initial = 0.5;
        double lowerBound = 0.0;
        double upperBound = 1.0;
        
        try {
            // This should throw an exception when it can't find a bracket
            UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
            fail("Expected exception not thrown");
        } catch (FunctionEvaluationException e) {
            fail("Unexpected FunctionEvaluationException");
        } catch (Exception e) {
            // Verify the exception message indicates the bounds were respected
            assertTrue(e.getMessage().contains("bracketing"));
        }
        
        // The mutant would continue searching beyond upperBound (b > upperBound)
        // So we need to verify no values beyond upperBound were evaluated
        try {
            verify(function, never()).value(argThat(x -> x > upperBound));
        } catch (FunctionEvaluationException e) {
            fail("Verification failed");
        }
    }

    @Test
    public void testBracketDetectsMutantWhenBReachesUpperBoundFirst() throws FunctionEvaluationException {
        // Create a mock function that always returns positive values
        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
        when(function.value(anyDouble())).thenReturn(1.0);
        
        double initial = 5.0;
        double lowerBound = 0.0;
        double upperBound = 10.0;
        int maxIterations = 100;
        
        try {
            // This should throw ConvergenceException when no bracket is found
            UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
            fail("Expected ConvergenceException");
        } catch (ConvergenceException e) {
            // Verify we got the expected exception
            String msg = e.getMessage();
            assertTrue(msg.contains("number of iterations"));
            
            // The key verification - check if 'b' reached upper bound
            assertTrue(msg.contains("final b value=10.0"));
            
            // Also verify 'a' was decreased (would be < initial)
            assertTrue(Double.parseDouble(
                msg.split("final a value=")[1].split(",")[0]) < initial);
        }
    }


}
