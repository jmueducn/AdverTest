package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
          public void testDivide_ByNull() {
              thrown.expect(NullPointerException.class);
              Complex c1 = new Complex(1, 1);
              c1.divide(null);
          }

 @Test
          public void testDivide_NaN_Divisor() {
              Complex c1 = new Complex(1, 1);
              Complex c2 = new Complex(Double.NaN, Double.NaN);
              Complex result = c1.divide(c2);
              assertTrue(result.isNaN());
          }

 @Test
          public void testDivide_NaN_Dividend() {
              Complex c1 = new Complex(Double.NaN, Double.NaN);
              Complex c2 = new Complex(1, 1);
              Complex result = c1.divide(c2);
              assertTrue(result.isNaN());
          }

 @Test
          public void testDivide_ByZero() {
              Complex c1 = new Complex(1, 1);
              Complex c2 = new Complex(0, 0);
              Complex result = c1.divide(c2);
              assertTrue(result.isNaN());
          }

 @Test
          public void testDivide_ZeroByZero() {
              Complex c1 = new Complex(0, 0);
              Complex c2 = new Complex(0, 0);
              Complex result = c1.divide(c2);
              assertTrue(result.isNaN());
          }

 @Test
          public void testDivide_ByInfinite_FiniteDividend() {
              Complex c1 = new Complex(1, 1);
              Complex c2 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex result = c1.divide(c2);
              assertEquals(Complex.ZERO, result);
          }

 @Test
          public void testDivide_NormalCase_AbsCGreaterThanAbsD() {
              Complex c1 = new Complex(4, 2);
              Complex c2 = new Complex(3, 1); // |3| > |1|
              Complex result = c1.divide(c2);
              
              // Expected result: (4*3 + 2*1)/(3*3 + 1*1) + i(2*3 - 4*1)/(3*3 + 1*1)
              // = (12 + 2)/10 + i(6 - 4)/10 = 1.4 + 0.2i
              assertEquals(1.4, result.getReal(), 0.0001);
              assertEquals(0.2, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_NormalCase_AbsDLessThanAbsC() {
              Complex c1 = new Complex(2, 4);
              Complex c2 = new Complex(1, 3); // |1| < |3|
              Complex result = c1.divide(c2);
              
              // Expected result: (4*3 + 2*1)/(1*1 + 3*3) + i(4 - 2*3)/(1*1 + 3*3)
              // = (12 + 2)/10 + i(4 - 6)/10 = 1.4 - 0.2i
              assertEquals(1.4, result.getReal(), 0.0001);
              assertEquals(-0.2, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_RealNumbers() {
              Complex c1 = new Complex(6, 0);
              Complex c2 = new Complex(2, 0);
              Complex result = c1.divide(c2);
              assertEquals(3.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_ImaginaryNumbers() {
              Complex c1 = new Complex(0, 6);
              Complex c2 = new Complex(0, 2);
              Complex result = c1.divide(c2);
              assertEquals(3.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_InfiniteByInfinite() {
              Complex c1 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex c2 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex result = c1.divide(c2);
              assertTrue(result.isNaN());
          }

 @Test
          public void testDivide_EdgeCase_VerySmallNumbers() {
              Complex c1 = new Complex(1e-300, 1e-300);
              Complex c2 = new Complex(1e-300, 1e-300);
              Complex result = c1.divide(c2);
              assertEquals(1.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_ByNonZeroRealNumber() {
              Complex complex = new Complex(4.0, 6.0);
              Complex result = complex.divide(2.0);
              assertEquals(2.0, result.getReal(), 0.0001);
              assertEquals(3.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_ByZero1() {
              Complex complex = new Complex(4.0, 6.0);
              Complex result = complex.divide(0.0);
              assertTrue(Double.isNaN(result.getReal()));
              assertTrue(Double.isNaN(result.getImaginary()));
          }

 @Test
          public void testDivide_NaNComplexByReal() {
              Complex complex = new Complex(Double.NaN, Double.NaN);
              Complex result = complex.divide(2.0);
              assertTrue(Double.isNaN(result.getReal()));
              assertTrue(Double.isNaN(result.getImaginary()));
          }

 @Test
          public void testDivide_ComplexByNaN() {
              Complex complex = new Complex(4.0, 6.0);
              Complex result = complex.divide(Double.NaN);
              assertTrue(Double.isNaN(result.getReal()));
              assertTrue(Double.isNaN(result.getImaginary()));
          }

 @Test
          public void testDivide_ByInfiniteDivisor() {
              Complex complex = new Complex(4.0, 6.0);
              Complex result = complex.divide(Double.POSITIVE_INFINITY);
              assertEquals(0.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_InfiniteComplexByFiniteDivisor() {
              Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex result = complex.divide(2.0);
              assertTrue(Double.isInfinite(result.getReal()));
              assertTrue(Double.isInfinite(result.getImaginary()));
          }

 @Test
          public void testDivide_InfiniteComplexByInfiniteDivisor() {
              Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex result = complex.divide(Double.POSITIVE_INFINITY);
              assertTrue(Double.isNaN(result.getReal()));
              assertTrue(Double.isNaN(result.getImaginary()));
          }

 @Test
          public void testDivide_ZeroComplexByNonZero() {
              Complex complex = new Complex(0.0, 0.0);
              Complex result = complex.divide(2.0);
              assertEquals(0.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_ZeroComplexByZero() {
              Complex complex = new Complex(0.0, 0.0);
              Complex result = complex.divide(0.0);
              assertTrue(Double.isNaN(result.getReal()));
              assertTrue(Double.isNaN(result.getImaginary()));
          }

 @Test
          public void testDivide_ByNegativeNumber() {
              Complex complex = new Complex(4.0, 6.0);
              Complex result = complex.divide(-2.0);
              assertEquals(-2.0, result.getReal(), 0.0001);
              assertEquals(-3.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_ComplexWithZeroImaginary() {
              Complex complex = new Complex(4.0, 0.0);
              Complex result = complex.divide(2.0);
              assertEquals(2.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
          }

 @Test
          public void testDivide_ComplexWithZeroReal() {
              Complex complex = new Complex(0.0, 6.0);
              Complex result = complex.divide(2.0);
              assertEquals(0.0, result.getReal(), 0.0001);
              assertEquals(3.0, result.getImaginary(), 0.0001);
          }

 @Test
      public void testDivideByInfiniteShouldReturnZero() {
          // Create a finite complex number (dividend)
          Complex finite = new Complex(3.0, 4.0);
          
          // Create an infinite complex number (divisor)
          Complex infinite = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
          
          // Perform division
          Complex result = finite.divide(infinite);
          
          // Verify the result is ZERO as expected by original behavior
          assertEquals(Complex.ZERO, result);
          
          // Additional verification that we're not getting NaN or other values
          assertFalse(result.isNaN());
          assertFalse(result.isInfinite());
          assertEquals(0.0, result.getReal(), 0.0001);
          assertEquals(0.0, result.getImaginary(), 0.0001);
      }

 @Test
      public void testDivideByInfiniteDivisor() {
          // Create a finite complex number
          Complex complex = new Complex(1.0, 1.0);
          
          // Test with positive infinity divisor
          Complex resultPosInf = complex.divide(Double.POSITIVE_INFINITY);
          assertEquals("Dividing by +Inf should return ZERO", Complex.ZERO, resultPosInf);
          
          // Test with negative infinity divisor
          Complex resultNegInf = complex.divide(Double.NEGATIVE_INFINITY);
          assertEquals("Dividing by -Inf should return ZERO", Complex.ZERO, resultNegInf);
          
          // Additional check for exact zero values
          assertEquals(0.0, resultPosInf.getReal(), 0.0);
          assertEquals(0.0, resultPosInf.getImaginary(), 0.0);
      }

 @Test
 public void testDivideByNegativeInfinity() {
     // Create a finite complex number
     Complex dividend = new Complex(1.0, 1.0);
     
     // Create a complex number with negative infinity
     Complex divisor = new Complex(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
     
     // Perform the division
     Complex result = dividend.divide(divisor);
     
     // Original behavior should return ZERO when dividing by any infinity
     // Mutated behavior would perform regular division and return non-ZERO result
     assertEquals(Complex.ZERO, result);
     
     // Additional checks to ensure it's exactly ZERO
     assertEquals(0.0, result.getReal(), 0.0);
     assertEquals(0.0, result.getImaginary(), 0.0);
 }

 @Test
 public void testDivideByNegativeInfinity1() {
     // Create a finite complex number
     Complex complex = new Complex(1.0, 1.0);
     
     // Divide by negative infinity
     Complex result = complex.divide(Double.NEGATIVE_INFINITY);
     
     // Original behavior: should return ZERO
     // Mutated behavior: would return (-0.0, -0.0)
     assertEquals(Complex.ZERO, result);
     
     // Additional verification that it's not doing the division
     assertNotEquals(new Complex(-0.0, -0.0), result);
     
     // Verify it's not NaN
     assertFalse(result.isNaN());
 }

}
