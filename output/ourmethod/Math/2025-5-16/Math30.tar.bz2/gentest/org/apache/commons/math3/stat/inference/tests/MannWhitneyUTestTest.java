package gentest.org.apache.commons.math3.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.stat.inference.*;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.stat.ranking.NaNStrategy;
import org.apache.commons.math3.stat.ranking.NaturalRanking;
import org.apache.commons.math3.stat.ranking.TiesStrategy;
import org.apache.commons.math3.util.FastMath;
 
public class MannWhitneyUTestTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testCalculateAsymptoticPValue_UminEqualsEU() throws Exception {
                // When Umin equals expected value (EU), z should be 0
                double Umin = 25;
                int n1 = 5;
                int n2 = 10;
                
                // n1n2prod = 50
                // EU = 25
                // z = (25 - 25) / ... = 0
                // p-value = 2 * Φ(0) = 2 * 0.5 = 1.0
                
                // Create instance of MannWhitneyUTest
                MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
                
                // Get the private method using reflection
                Method method = MannWhitneyUTest.class.getDeclaredMethod(
                    "calculateAsymptoticPValue", double.class, int.class, int.class);
                method.setAccessible(true);
                
                // Invoke the method
                double result = (double) method.invoke(mannWhitneyUTest, Umin, n1, n2);
                assertEquals(1.0, result, 0.0001);
            }

    @Test
            public void testCalculateAsymptoticPValue_extremeLowUmin() throws Exception {
                // Test with extremely low Umin value
                double Umin = 0;
                int n1 = 10;
                int n2 = 10;
                
                // n1n2prod = 100
                // EU = 50
                // VarU = 100 * 21 / 12 = 175
                // z = (0 - 50) / sqrt(175) ≈ -3.7796
                // p-value ≈ 2 * 0.00008 ≈ 0.00016
                
                // Create instance of MannWhitneyUTest
                MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
                
                // Get the private method using reflection
                Method method = MannWhitneyUTest.class.getDeclaredMethod(
                    "calculateAsymptoticPValue", double.class, int.class, int.class);
                method.setAccessible(true);
                
                // Invoke the method
                double result = (double) method.invoke(mannWhitneyUTest, Umin, n1, n2);
                assertEquals(0.00016, result, 0.00001);
            }

    @Test
            public void testCalculateAsymptoticPValue_zeroN() throws Exception {
                MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
                Method method = MannWhitneyUTest.class.getDeclaredMethod("calculateAsymptoticPValue", double.class, int.class, int.class);
                method.setAccessible(true);
                
                thrown.expect(IllegalArgumentException.class);
                method.invoke(mannWhitneyUTest, 0.0, 0, 5);
            }

    @Test
        public void testCalculateAsymptoticPValue_typicalCase() throws Exception {
            // Test with typical values
            double Umin = 10;
            int n1 = 5;
            int n2 = 7;
            
            // Create instance of test class
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            
            // Expected calculations:
            // n1n2prod = 5 * 7 = 35
            // EU = 35 / 2 = 17.5
            // VarU = 35 * (5 + 7 + 1) / 12 = 35 * 13 / 12 ≈ 37.9167
            // z = (10 - 17.5) / sqrt(37.9167) ≈ -7.5 / 6.1577 ≈ -1.218
            // p-value = 2 * Φ(z) ≈ 2 * 0.1116 ≈ 0.2232
            
            // Use reflection to access private method
            Method method = MannWhitneyUTest.class.getDeclaredMethod("calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            double result = (double) method.invoke(mannWhitneyUTest, Umin, n1, n2);
            
            assertEquals(0.2232, result, 0.0001);
        }

    @Test
        public void testCalculateAsymptoticPValue_extremeHighUmin() throws Exception {
            // Test with extremely high Umin value
            double Umin = 100;
            int n1 = 10;
            int n2 = 10;
            
            // n1n2prod = 100
            // EU = 50
            // VarU = 175 (same as above)
            // z = (100 - 50) / sqrt(175) ≈ 3.7796
            // p-value ≈ 2 * (1 - 0.99992) ≈ 0.00016
            
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            // Use reflection to access private method
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            double result = (double) method.invoke(mannWhitneyUTest, Umin, n1, n2);
            assertEquals(0.00016, result, 0.00001);
        }

    @Test
        public void testCalculateAsymptoticPValue_smallSampleSizes() throws Exception {
            // Create instance of the test class
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            
            // Get the private method using reflection
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            // Test with very small sample sizes
            double Umin = 2;
            int n1 = 2;
            int n2 = 3;
            
            // n1n2prod = 6
            // EU = 3
            // VarU = 6 * 6 / 12 = 3
            // z = (2 - 3) / sqrt(3) ≈ -0.5774
            // p-value ≈ 2 * 0.2819 ≈ 0.5638
            
            double result = (double) method.invoke(mannWhitneyUTest, Umin, n1, n2);
            assertEquals(0.5638, result, 0.0001);
        }

    @Test
        public void testCalculateAsymptoticPValue_largeSampleSizes() throws Exception {
            // Create instance of MannWhitneyUTest
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            
            // Test with large sample sizes
            double Umin = 5000;
            int n1 = 100;
            int n2 = 100;
            
            // n1n2prod = 10000
            // EU = 5000
            // VarU = 10000 * 201 / 12 = 167500
            // z = (5000 - 5000) / sqrt(167500) = 0
            // p-value = 1.0
            
            // Use reflection to access private method
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            double result = (Double) method.invoke(mannWhitneyUTest, Umin, n1, n2);
            
            assertEquals(1.0, result, 0.0001);
        }

    @Test
        public void testCalculateAsymptoticPValue_zeroN1() throws Exception {
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            try {
                Method method = MannWhitneyUTest.class.getDeclaredMethod("calculateAsymptoticPValue", double.class, int.class, int.class);
                method.setAccessible(true);
                method.invoke(mannWhitneyUTest, 0.0, 0, 5);
                fail("Expected IllegalArgumentException");
            } catch (InvocationTargetException e) {
                assertEquals(IllegalArgumentException.class, e.getCause().getClass());
            }
        }

    @Test
        public void testCalculateAsymptoticPValue_negativeN1() throws Exception {
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            ExpectedException thrown = ExpectedException.none();
            thrown.expect(IllegalArgumentException.class);
            
            method.invoke(mannWhitneyUTest, 0.0, 5, -1);
        }

    @Test
        public void testCalculateAsymptoticPValue_negativeUmin() throws Exception {
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            try {
                method.invoke(mannWhitneyUTest, -1.0, 5, 5);
                fail("Expected IllegalArgumentException");
            } catch (InvocationTargetException e) {
                assertEquals(IllegalArgumentException.class, e.getCause().getClass());
            }
        }

    @Test
        public void testCalculateAsymptoticPValue_UminLargerThanProduct() throws Exception {
            MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
            
            // Get the private method using reflection
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            
            // Invoke the method with test values (Umin=26, n1=5, n2=5)
            double result = (double) method.invoke(mannWhitneyUTest, 26.0, 5, 5);
            
            // Since we don't know the expected value, we'll just verify it returns a double
            // In a real test, we would compare against an expected value
            assertTrue(Double.isFinite(result));
        }

    @Test
    public void testCalculateAsymptoticPValue_negativeN() throws Exception {
        MannWhitneyUTest mannWhitneyUTest = new MannWhitneyUTest();
        
        try {
            // Use reflection to access private method
            Method method = MannWhitneyUTest.class.getDeclaredMethod(
                "calculateAsymptoticPValue", double.class, int.class, int.class);
            method.setAccessible(true);
            method.invoke(mannWhitneyUTest, 0.0, -1, 5);
            fail("Expected IllegalArgumentException");
        } catch (InvocationTargetException e) {
            assertEquals(IllegalArgumentException.class, e.getCause().getClass());
        }
    }


}
