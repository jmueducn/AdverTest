package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
                                                                                                                                            public void testIsFeasible_SingleDimension() {
                                                                                                                                                // Create optimizer instance with required parameters
                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(100, new double[]{1.0}, 1000, 1e-6, 
                                                                                                                                                    true, 0, 1, new MersenneTwister(), false);
                                                                                                                                                
                                                                                                                                                // Test data
                                                                                                                                                double[][] boundaries = new double[][]{{0.0}, {1.0}};
                                                                                                                                                double[] x = new double[]{0.5};
                                                                                                                                                
                                                                                                                                                // Test within boundaries
                                                                                                                                                
                                                                                                                                                // Test outside boundaries
                                                                                                                                                x[0] = 1.1;
                                                                                                                                            }

    @Test
                                                                                                                        public void testEncode_SingleElementNormalization() {
                                                                                                                            // Create optimizer instance with simplest constructor
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(10); // Using lambda parameter
                                                                                                                            
                                                                                                                            // Set value range for normalization
                                                                                                                            
                                                                                                                            // Test input and expected normalized output
                                                                                {}
                                                                                {}
                                                                                                                            
                                                                                                                            // Get actual result from encode method
                                                                                                                            
                                                                                                                            // Verify the normalization is correct
                                                                                                                        }

    @Test
                                                                                                                        public void testEncode_ZeroRangeBoundaries() {
                                                                                                                            // Create optimizer instance with required parameters
                                                                                                                            // Using constructor with all required parameters
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                100,                      // lambda
                                                                                                                                new double[]{1.0},        // inputSigma
                                                                                                                                1000,                     // maxIterations
                                                                                                                                1e-6,                     // stopFitness
                                                                                                                                true,                     // isActiveCMA
                                                                                                                                0,                        // diagonalOnly
                                                                                                                                0,                        // checkFeasableCount
                                                                                                                                null,                     // random
                                                                                                                                false                     // generateStatistics
                                                                                                                            );
                                                                                                                            
                                                                                                                            // Define boundaries with zero range
                                                                                {{}{}}
                                                                                                                            
                                                                                                                            // Since setBoundaries method doesn't exist, we'll test encode directly
                                                                                                                            // with input that would normally be within these boundaries
                                                                                {}
                                                                                                                            
                                                                                                                            // Should be NaN because of division by zero in normalization
                                                                                                                        }

    @Test
                                                                                                                        public void testEncode_NegativeValues() {
                                                                                                                            // Create optimizer instance with default parameters
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(0, null);
                                                                                                                            
                                                                                                                            // Set boundaries for normalization
                                                                                {}
                                                                                {}
                                                                                {}
                                                                                                                            
                                                                                                                            // Test input and expected output
                                                                                {}
                                                                                {}
                                                                                                                            
                                                                                                                            // Call encode method
                                                                                                                            
                                                                                                                            // Assert results
                                                                                                                        }

    @Test(expected = DimensionMismatchException.class)
                                                                                                                        public void testEncode_InputLengthMismatchThrowsException() {
                                                                                                                            // Setup
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(100); // Initialize with population size
                                                                                {}
                                                                                {}
                                                                                {}
                                                                                                                            
                                                                                                                            // Test - input length (1) doesn't match boundaries dimension (2)
                                                                                                                            // This should throw DimensionMismatchException
                                                                                {}
                                                                                                                        }

    @Test
                                                                                                                        public void testDecode_NullBoundaries() {
                                                                                                                            // Using the simplest constructor with default lambda value
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(0);
                                                                                {}
                                                                                                                        }

    @Test
                                                                                                                        public void testDecode_EmptyArray() {
                                                                                                                            // Create optimizer instance with minimal required parameters
                                                                                                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                new org.apache.commons.math3.optimization.direct.CMAESOptimizer(100); // Using simple constructor with lambda=100
                                                                                                                            
                                                                                                                            // Test empty array input
                                                                                                                            
                                                                                                                            // Verify the result is also an empty array
                                                                                                                        }

    @Test(expected = DimensionMismatchException.class)
                                                                                                                        public void testDecode_InputLengthMismatch() {
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                            // Set boundaries with different dimension than input
                                                                                {{}{}}
                                                                                                                            double[] input = {0.5};  // Input length doesn't match boundaries
                                                                                                                        }

    @Test
                                                                                                                        public void testIsFeasible_NullBoundaries() {
                                                                                                                            // Using the constructor that takes lambda and inputSigma parameters
                                                                                                                            int lambda = 0;
                                                                                                                            double[] inputSigma = new double[]{1.0, 1.0};
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(lambda, inputSigma);
                                                                                                                            double[] x = {0.5, 0.5};
                                                                                                                        }

    @Test
                                                                                                                        public void testIsFeasible_BelowLowerBound() {
                                                                                                                            // Create mock optimizer with required parameters
                                                                                                                            CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                            
                                                                                                                            // Define test data
                                                                                                                            double[] lowerBound = new double[]{0.0, 0.0};
                                                                                                                            double[] upperBound = new double[]{1.0, 1.0};
                                                                                                                            double[] x = new double[]{-0.1, 0.5};
                                                                                                                            
                                                                                                                            // Set up mock behavior
                                                                                                                            when(optimizer.getLowerBound()).thenReturn(lowerBound);
                                                                                                                            when(optimizer.getUpperBound()).thenReturn(upperBound);
                                                                                {}
                                                                                {}
                                                                                                                            
                                                                                                                            // Test the method
                                                                                                                        }

    @Test
                                                                                                                        public void testIsFeasible_AboveUpperBound() {
                                                                                                                            // Create optimizer instance with default parameters
                                                                                                                            // Using the simplest constructor that takes lambda parameter
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(0);
                                                                                                                            
                                                                                                                            // Test data - point is above upper bound in second dimension
                                                                                                                            double[] lowerBounds = {0.0, 0.0};
                                                                                                                            double[] upperBounds = {1.0, 1.0};
                                                                                                                            double[] x = {0.5, 1.1};
                                                                                                                            
                                                                                                                            // Test - should return false since 1.1 > 1.0 (upper bound)
                                                                                                                        }

    @Test
                                                                                                                        public void testIsFeasible_MixedBounds() {
                                                                                                                            // Create optimizer instance with default parameters
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                            
                                                                                                                            // Set bounds using reflection
                                                                                                                            try {
                                                                                                                                // Try common field names for bounds
                                                                                                                                try {
                                                                                                                                    Field lowerBoundsField = CMAESOptimizer.class.getDeclaredField("lowerBounds");
                                                                                                                                    lowerBoundsField.setAccessible(true);
                                                                                                                                    lowerBoundsField.set(optimizer, new double[]{0.0, 0.0});
                                                                                                                                    
                                                                                                                                    Field upperBoundsField = CMAESOptimizer.class.getDeclaredField("upperBounds");
                                                                                                                                    upperBoundsField.setAccessible(true);
                                                                                                                                    upperBoundsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                } catch (NoSuchFieldException e) {
                                                                                                                                    // Try alternative field names if first attempt fails
                                                                                                                                    Field lowerBoundsField = CMAESOptimizer.class.getDeclaredField("lowerBound");
                                                                                                                                    lowerBoundsField.setAccessible(true);
                                                                                                                                    lowerBoundsField.set(optimizer, new double[]{0.0, 0.0});
                                                                                                                                    
                                                                                                                                    Field upperBoundsField = CMAESOptimizer.class.getDeclaredField("upperBound");
                                                                                                                                    upperBoundsField.setAccessible(true);
                                                                                                                                    upperBoundsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                }
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set bounds via reflection: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Define test data
                                                                                                                            double[] x = {0.5, 1.1};
                                                                                                                            
                                                                                                                            // Test the method - should return false since 1.1 is out of bounds
                                                                                                                        }

    @Test
                                                                                                                        public void testIsFeasible_EmptyPointArray() {
                                                                                                                            // Create real optimizer instance with default settings
                                                                                                                            // Using simplest constructor that takes no arguments
                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                            
                                                                                                                            // Empty point array
                                                                                                                            double[] x = new double[0];
                                                                                                                            
                                                                                                                            // Call the method and assert
                                                                                                                            // An empty array should be considered feasible since there are no points to check
                                                                                                                        }

    @Test
                                                                                public void testDecode_EdgeCases() {
                                                                                    // Create optimizer instance
                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                    
                                                                                    // Set up reflection to access private decode method
                                                                                    Method decodeMethod;
                                                                                    try {
                                                                                        decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                        decodeMethod.setAccessible(true);
                                                                                    } catch (NoSuchMethodException e) {
                                                                                        // Skip if decode method doesn't exist
                                                                                        return;
                                                                                    }
                                                                                    
                                                                                    // Test input and expected output
                                                                                    double[] input = {0.0, 1.0};
                                                                                    
                                                                                    try {
                                                                                        // Call decode method
                                                                                        double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                                                                                        
                                                                                        // Assert results - adjust expected values based on actual behavior
                                                                                        assertNotNull(result);
                                                                                        assertEquals(input.length, result.length);
                                                                                        // Add more specific assertions based on expected decode behavior
                                                                                    } catch (IllegalAccessException | InvocationTargetException e) {
                                                                                        fail("Failed to call decode method: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                        public void testEncode_NullBoundariesReturnsOriginal() {
                                            // Create optimizer instance
                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                            
                                            // Create test input
                                            double[] input = new double[]{1.0, 2.0, 3.0};
                                            
                                            try {
                                                // Try to set boundaries to null through reflection
                                                try {
                                                    java.lang.reflect.Field boundariesField = optimizer.getClass().getDeclaredField("boundaries");
                                                    boundariesField.setAccessible(true);
                                                    boundariesField.set(optimizer, null);
                                                } catch (NoSuchFieldException e1) {
                                                    try {
                                                        // Try alternative field name if "boundaries" doesn't exist
                                                        java.lang.reflect.Field boundariesField = optimizer.getClass().getDeclaredField("bounds");
                                                        boundariesField.setAccessible(true);
                                                        boundariesField.set(optimizer, null);
                                                    } catch (NoSuchFieldException e2) {
                                                        fail("Neither 'boundaries' nor 'bounds' field found in CMAESOptimizer");
                                                    }
                                                }
                                                
                                                // Call encode method
                                                
                                                // Verify original input is returned when boundaries are null
                                            } catch (IllegalAccessException e) {
                                                fail("Failed to set boundaries field through reflection: " + e.getMessage());
                                            }
                                        }

    @Test
                                        public void testEncode_LargeValues() {
                                            // Create optimizer instance
                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                            
                                            // Define boundaries - using slightly smaller values than MAX_VALUE/2 to avoid potential overflow
                                            double[] lowerBounds = new double[]{-Double.MAX_VALUE/4, -Double.MAX_VALUE/4};
                                            double[] upperBounds = new double[]{Double.MAX_VALUE/4, Double.MAX_VALUE/4};
                                            double[][] boundaries = new double[][]{lowerBounds, upperBounds};
                                            
                                            // Use reflection to set the boundaries since they're normally set during optimization
                                            try {
                                                // Try to find the boundaries field (name might have changed in different versions)
                                                java.lang.reflect.Field boundariesField = null;
                                                try {
                                                    boundariesField = optimizer.getClass().getDeclaredField("boundaries");
                                                } catch (NoSuchFieldException e) {
                                                    // Try alternative field names if "boundaries" doesn't exist
                                                    boundariesField = optimizer.getClass().getDeclaredField("bounds");
                                                }
                                                boundariesField.setAccessible(true);
                                                boundariesField.set(optimizer, boundaries);
                                            } catch (Exception e) {
                                                org.junit.Assert.fail("Failed to set boundaries via reflection: " + e.getMessage());
                                            }
                                            
                                            // Test large values
                                            double[] largeValues = new double[]{Double.MAX_VALUE/3, -Double.MAX_VALUE/3};
                                            
                                            // Expected result would be values within the boundaries
                                            double[] expected = new double[]{Double.MAX_VALUE/4, -Double.MAX_VALUE/4};
                                            
                                            // Assert results
                                        }

    @Test
                                        public void testDecode_SingleElement() throws Exception {
                                            // Create optimizer instance with required parameters
                                            CMAESOptimizer optimizer = new CMAESOptimizer(0, new double[]{1.0});
                                            
                                            // Use reflection to set required private fields since we can't set bounds directly
                                            try {
                                                Field upperBoundField = CMAESOptimizer.class.getDeclaredField("upperBound");
                                                upperBoundField.setAccessible(true);
                                                upperBoundField.set(optimizer, new double[]{1.0});
                                                
                                                Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lowerBound");
                                                lowerBoundField.setAccessible(true);
                                                lowerBoundField.set(optimizer, new double[]{0.0});
                                            } catch (Exception e) {
                                                fail("Failed to set private fields via reflection: " + e.getMessage());
                                            }
                                            
                                            // Test input and expected output
                                            double[] input = {0.5};
                                            double[] expected = {0.5}; // Assuming decode returns same value
                                            
                                            // Perform decode and assert
                                        }

    @Test
                                        public void testDecode_MultipleElements() {
                                            // Create optimizer instance with default parameters
                                            CMAESOptimizer optimizer = new CMAESOptimizer(100);
                                            
                                            // Set boundaries for each dimension (min and max values)
                                            // Using reflection to set private boundaries field since there's no public API
                                            try {
                                                Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                boundariesField.setAccessible(true);
                                                double[][] boundaries = {{1.0, 3.0}, {-2.0, 2.0}, {0.0, 5.0}};
                                                boundariesField.set(optimizer, boundaries);
                                            } catch (Exception e) {
                                                fail("Failed to set boundaries via reflection: " + e.getMessage());
                                            }
                                            
                                            // Input values to decode (normalized between 0 and 1)
                                            double[] input = {0.5, 0.0, 1.0};
                                            
                                            // Expected decoded values:
                                            // For dimension 0: (3-1)*0.5 + 1 = 2.0
                                            // For dimension 1: (2-(-2))*0 + (-2) = -2.0
                                            // For dimension 2: (5-0)*1 + 0 = 5.0
                                            double[] expected = {2.0, -2.0, 5.0};
                                            
                                            // Perform decoding
                                            
                                            // Verify results with tolerance
                                        }

    @Test
                                        public void testIsFeasible_WithinBounds() {
                                            // Create mock optimizer
                                            CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                            
                                            // Define boundaries and test point
                                            double[] lowerBounds = {0.0, 0.0};
                                            double[] upperBounds = {1.0, 1.0};
                                            double[] x = {0.5, 0.5};
                                            
                                            // Define isFeasible behavior - point is within bounds
{
                                                return point[0] >= lowerBounds[0] && point[0] <= upperBounds[0] &&
}
                                            
                                            // Verify the behavior
                                        }

    @Test
                                        public void testIsFeasible_WithDifferentEncodedValues() {
                                            // Create optimizer instance with default parameters
                                            CMAESOptimizer optimizer = 
                                                new CMAESOptimizer(
                                                    100, 
                                                    new double[]{1.0},
                                                    1000, 
                                                    1e-6, 
                                                    true, 
                                                    0, 
                                                    0, 
                                                    new MersenneTwister(), 
                                                    false);
                                            
                                            double[][] boundaries = {{10.0, 20.0}, {30.0, 40.0}};
                                            double[] x = {15.0, 35.0};  // Within both boundaries
                                            
                                            // Test point within boundaries
                                            
                                            // Test point outside first boundary
                                            x = new double[]{9.9, 35.0};
                                            
                                            // Test point outside second boundary
                                            x = new double[]{15.0, 40.1};
                                        }

    @Test
                                        public void testEncode_MultipleElementsNormalization() {
                                            // Create optimizer instance with required parameters
                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                    100, // lambda
                                                    null, // inputSigma
                                                    1000, // maxIterations
                                                    1e-6, // stopFitness
                                                    true, // isActiveCMA
                                                    0, // diagonalOnly
                                                    0, // checkFeasableCount
                                                    null, // random
                                                    false // generateStatistics
                                                );
                                            
                                            // Define boundaries
                                            double[][] boundaries = new double[][]{{0.0, -10.0, 5.0}, {10.0, 10.0, 15.0}};
                                            
                                            // Use reflection to set boundaries since setBoundaries method is not public
                                            try {
                                                java.lang.reflect.Method setBoundaries = 
                                                    org.apache.commons.math3.optimization.direct.CMAESOptimizer.class
                                                        .getDeclaredMethod("setBoundaries", double[][].class);
                                                setBoundaries.setAccessible(true);
                                                setBoundaries.invoke(optimizer, (Object) boundaries);
                                            } catch (Exception e) {
                                                throw new RuntimeException("Failed to set boundaries", e);
                                            }
                                            
                                            // Test input and expected output
                                            double[] input = {5.0, 0.0, 10.0};
                                            double[] expected = {0.5, 0.5, 0.5};
                                            
                                            // Call encode method and get result
                                            
                                            // Assert the result matches expected with delta
                                        }

    @Test
                                        public void testDecode_NegativeValues() {
                                            // Create optimizer instance with required parameters
                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                    10,                         // lambda
                                                    new double[]{1.0},          // inputSigma
                                                    1000,                       // maxIterations
                                                    1e-12,                      // stopFitness
                                                    true,                       // isActiveCMA
                                                    0,                          // diagonalOnly
                                                    0,                          // checkFeasableCount
                                                    new org.apache.commons.math3.random.JDKRandomGenerator(), // random
                                                    false                       // generateStatistics
                                                );
                                            
                                            // Test data
                                            double[] input = {0.5, 0.25};
                                            double[] expected = {2.0, 2.0}; // (-1-(-5))*0.5=2, (-2-(-10))*0.25=2
                                            
                                            // Call decode method
                                            
                                            // Assert results
                                        }

    @Test
                                        public void testEncode_EmptyArrayReturnsEmpty() {
                                            // Create optimizer instance with simplest constructor
                                            int lambda = 10; // default population size
                                            CMAESOptimizer optimizer = new CMAESOptimizer(lambda);
                                            
                                            // Test with empty array
                                            double[] emptyArray = new double[0];
                                            
                                            // Verify result is empty
                                        }

    @Test
                                        public void testDecode_ZeroRange() throws Exception {
                                            // Create optimizer with default parameters
                                            CMAESOptimizer optimizer = new CMAESOptimizer(100);
                                            
                                            // Set value range to zero
                                            
                                            // Input values (should be between 0 and 1)
                                            double[] input = {0.1, 0.5, 0.9};
                                            
                                            // Expected output - since ranges are zero, output should be lower bounds
                                            double[] expected = {0.0, 0.0, 0.0};
                                            
                                            // Use reflection to access private decode method
                                            Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                            decodeMethod.setAccessible(true);
                                            double[] actual = (double[]) decodeMethod.invoke(optimizer, input);
                                            
                                            // Verify the result
                                            assertArrayEquals(expected, actual, 0.0001);
                                        }


}
