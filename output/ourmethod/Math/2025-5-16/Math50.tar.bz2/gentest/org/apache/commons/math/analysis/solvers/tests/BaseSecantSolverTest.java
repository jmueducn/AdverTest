package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.analysis.UnivariateRealFunction;
import org.apache.commons.math.exception.MathInternalError;
 
public class BaseSecantSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                               public void testDoSolve_ConvergesWithAbsoluteAccuracy() throws Exception {
                                                                                                                                                                                                                                                                                   // Create mock function
                                                                                                                                                                                                                                                                                   UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                   when(mockFunction.value(anyDouble())).thenReturn(-0.1, 0.1, 0.01);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use concrete implementation (PegasusSolver is a common concrete subclass)
                                                                                                                                                                                                                                                                                   BaseSecantSolver solver = new PegasusSolver(1e-6, 1e-6, 1e-10);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use public solve() method instead of protected doSolve()
                                                                                                                                                                                                                                                                                   double result = solver.solve(100, mockFunction, -1.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   assertEquals(0.0, result, 1e-6);
                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                                               public void testDoSolve_WithIllinoisMethod() throws Exception {
                                                                                                                                                                                                                                                                                   // Create solver with Illinois method
                                                                                                                                                                                                                                                                                   BaseSecantSolver solver = new IllinoisSolver(1e-6);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Create mock function
                                                                                                                                                                                                                                                                                   UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                   when(mockFunction.value(anyDouble())).thenReturn(-1.0, 1.0, -0.5, 0.25, -0.125);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use reflection to access protected doSolve() method
                                                                                                                                                                                                                                                                                   Method doSolveMethod = BaseSecantSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                                                                                                   doSolveMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Setup the solver properly
                                                                                                                                                                                                                                                                                   solver.solve(100, mockFunction, -1.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Call doSolve through reflection
                                                                                                                                                                                                                                                                                   double result = (double) doSolveMethod.invoke(solver);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Verify the result is within bounds
                                                                                                                                                                                                                                                                                   assertTrue(result > -1.0 && result < 1.0);
                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                                               public void testDoSolve_WithPegasusMethod() throws Exception {
                                                                                                                                                                                                                                                                                   // Import these at class level in actual implementation:
                                                                                                                                                                                                                                                                                   // import org.apache.commons.math.analysis.solvers.PegasusSolver;
                                                                                                                                                                                                                                                                                   // import org.apache.commons.math.analysis.solvers.BaseSecantSolver.Method;
                                                                                                                                                                                                                                                                                   // import org.apache.commons.math.analysis.UnivariateRealFunction;
                                                                                                                                                                                                                                                                                   // import static org.mockito.*;
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                   PegasusSolver solver = new PegasusSolver(1e-6);
                                                                                                                                                                                                                                                                                   when(mockFunction.value(anyDouble())).thenReturn(-1.0, 1.0, -0.5, 0.25, -0.125);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use solve() instead of setup() + doSolve()
                                                                                                                                                                                                                                                                                   double result = solver.solve(100, mockFunction, -1.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   assertTrue(result > -1.0 && result < 1.0);
                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                                               public void testDoSolve_ExactRootFoundDuringIteration() throws Exception {
                                                                                                                                                                                                                                                                                   // Create mock function
                                                                                                                                                                                                                                                                                   org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
                                                                                                                                                                                                                                                                                       mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                                   when(mockFunction.value(anyDouble())).thenReturn(-1.0, 1.0, 0.0);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use concrete implementation (IllinoisSolver is one such implementation)
                                                                                                                                                                                                                                                                                   org.apache.commons.math.analysis.solvers.BaseSecantSolver solver = 
                                                                                                                                                                                                                                                                                       new org.apache.commons.math.analysis.solvers.IllinoisSolver(1e-6);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Call public solve() method instead of protected doSolve()
                                                                                                                                                                                                                                                                                   double result = solver.solve(100, mockFunction, -1.0, 1.0, 
                                                                                                                                                                                                                                                                                       org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // The exact value would depend on the iteration, but we know it found a root
                                                                                                                                                                                                                                                                                   assertTrue(result >= -1.0 && result <= 1.0);
                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                   public void testDoSolve_InvalidMethodThrowsException() throws Exception {
                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                       org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
                                                                                                                                                                                                                                           mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Create concrete implementation since BaseSecantSolver is abstract
                                                                                                                                                                                                                                       org.apache.commons.math.analysis.solvers.IllinoisSolver solver = 
                                                                                                                                                                                                                                           new org.apache.commons.math.analysis.solvers.IllinoisSolver(1e-6);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Setup expected exception
                                                                                                                                                                                                                                       org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                       exception.expect(org.apache.commons.math.exception.MathIllegalStateException.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                                           // Use reflection to set an invalid method
                                                                                                                                                                                                                                           java.lang.reflect.Field methodField = 
                                                                                                                                                                                                                                               org.apache.commons.math.analysis.solvers.BaseSecantSolver.class.getDeclaredField("method");
                                                                                                                                                                                                                                           methodField.setAccessible(true);
                                                                                                                                                                                                                                           methodField.set(solver, null);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Mock function behavior
                                                                                                                                                                                                                                           when(mockFunction.value(anyDouble()))
                                                                                                                                                                                                                                               .thenReturn(-1.0, 1.0);
                                                                                                                                                                                                                                           solver.solve(100, mockFunction, -1.0, 1.0, 
                                                                                                                                                                                                                                               org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Use reflection to access protected doSolve method
                                                                                                                                                                                                                                           java.lang.reflect.Method doSolveMethod = 
                                                                                                                                                                                                                                               org.apache.commons.math.analysis.solvers.BaseSecantSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                                                           doSolveMethod.setAccessible(true);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Invoke method which should throw exception
                                                                                                                                                                                                                                           doSolveMethod.invoke(solver);
                                                                                                                                                                                                                                       } finally {
                                                                                                                                                                                                                                           // Reset accessibility to original state
                                                                                                                                                                                                                                           java.lang.reflect.Field methodField = 
                                                                                                                                                                                                                                               org.apache.commons.math.analysis.solvers.BaseSecantSolver.class.getDeclaredField("method");
                                                                                                                                                                                                                                           methodField.setAccessible(false);
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                               public void testDoSolve_ConvergesWithFunctionValueAccuracy() throws Exception {
                                                                                                                                                                                                                                   UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                   when(mockFunction.value(anyDouble()))
                                                                                                                                                                                                                                       .thenReturn(-0.1, 0.1, 1e-11);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create solver using IllinoisSolver which is public
                                                                                                                                                                                                                                   IllinoisSolver solver = new IllinoisSolver(
                                                                                                                                                                                                                                       1e-6,  // relative accuracy
                                                                                                                                                                                                                                       1e-6,  // absolute accuracy
                                                                                                                                                                                                                                       1e-10); // function value accuracy
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Use solve() with proper parameters
                                                                                                                                                                                                                                   double result = solver.solve(
                                                                                                                                                                                                                                       100, // max evaluations
                                                                                                                                                                                                                                       mockFunction, 
                                                                                                                                                                                                                                       -1.0, // min
                                                                                                                                                                                                                                       1.0,  // max
                                                                                                                                                                                                                                       AllowedSolution.ANY_SIDE);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   assertEquals(0.0, result, 1e-6);
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                           public void testDoSolve_RightSideSolution() throws Exception {
                                                                                                                                                                                                                               // Create concrete solver instance using RegulaFalsiSolver which extends BaseSecantSolver
                                                                                                                                                                                                                               RegulaFalsiSolver solver = new RegulaFalsiSolver(1e-6);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Create mock function
                                                                                                                                                                                                                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                               when(mockFunction.value(anyDouble())).thenReturn(-1.0, 1.0, -0.5, 0.25, -0.125);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Solve with RIGHT_SIDE constraint
                                                                                                                                                                                                                               double result = solver.solve(100, mockFunction, -1.0, 1.0, AllowedSolution.RIGHT_SIDE);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify solution is on the right side (positive)
                                                                                                                                                                                                                               assertTrue(result > 0.0);
                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testDoSolve_ExactRootAtUpperBound() throws Exception {
                                                                                                                                                                                                               // Create concrete implementation for testing
                                                                                                                                                                                                               class TestSolver extends org.apache.commons.math.analysis.solvers.BaseSecantSolver {
                                                                                                                                                                                                                   public TestSolver() {
                                                                                                                                                                                                                       super(1e-6, org.apache.commons.math.analysis.solvers.BaseSecantSolver.Method.REGULA_FALSI);
                                                                                                                                                                                                                   }
                                                                                                                                                                                                           
                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                   protected double computeObjectiveValue(double point) {
                                                                                                                                                                                                                       // Implement simple linear function f(x) = x - 1 (root at x=1)
                                                                                                                                                                                                                       return point - 1.0;
                                                                                                                                                                                                                   }
                                                                                                                                                                                                               }
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create solver instance
                                                                                                                                                                                                               TestSolver solver = new TestSolver();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Use reflection to set up protected fields needed by doSolve()
                                                                                                                                                                                                               java.lang.reflect.Field minField = org.apache.commons.math.analysis.solvers.BaseAbstractUnivariateRealSolver.class.getDeclaredField("min");
                                                                                                                                                                                                               minField.setAccessible(true);
                                                                                                                                                                                                               minField.set(solver, -1.0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               java.lang.reflect.Field maxField = org.apache.commons.math.analysis.solvers.BaseAbstractUnivariateRealSolver.class.getDeclaredField("max");
                                                                                                                                                                                                               maxField.setAccessible(true);
                                                                                                                                                                                                               maxField.set(solver, 1.0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Compute function values at bounds
                                                                                                                                                                                                               solver.computeObjectiveValue(-1.0);
                                                                                                                                                                                                               solver.computeObjectiveValue(1.0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Use reflection to access protected doSolve() method
                                                                                                                                                                                                               java.lang.reflect.Method doSolveMethod = org.apache.commons.math.analysis.solvers.BaseSecantSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                               doSolveMethod.setAccessible(true);
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   double result = (Double) doSolveMethod.invoke(solver);
                                                                                                                                                                                                                   assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                               } finally {
                                                                                                                                                                                                                   doSolveMethod.setAccessible(false);
                                                                                                                                                                                                                   minField.setAccessible(false);
                                                                                                                                                                                                                   maxField.setAccessible(false);
                                                                                                                                                                                                               }
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                   public void testDoSolve_LeftSideSolution() throws Exception {
                                                                                                                                                                                                       // Create mock function that crosses zero at x=0 (negative on left, positive on right)
                                                                                                                                                                                                       org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
                                                                                                                                                                                                           new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public double value(double x) {
                                                                                                                                                                                                                   return x; // Simple linear function f(x) = x
                                                                                                                                                                                                               }
                                                                                                                                                                                                           };
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create solver instance
                                                                                                                                                                                                       org.apache.commons.math.analysis.solvers.RegulaFalsiSolver solver = 
                                                                                                                                                                                                           new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1e-6);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Solve with LEFT_SIDE solution
                                                                                                                                                                                                       double result = solver.solve(100, mockFunction, -1.0, 1.0, 
                                                                                                                                                                                                           org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE);
                                                                                                                                                                                                       
                                                                                                                                                                                                       org.junit.Assert.assertTrue("Solution should be negative for LEFT_SIDE", result < 0.0);
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                   public void testDoSolve_AboveSideSolution() throws Exception {
                                                                                                                                                                                                       // Create mock function
                                                                                                                                                                                                       org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
                                                                                                                                                                                                           new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public double value(double x) {
                                                                                                                                                                                                                   // Simple linear function that crosses zero at x=0.5
                                                                                                                                                                                                                   return x - 0.5;
                                                                                                                                                                                                               }
                                                                                                                                                                                                           };
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create solver with ILLINOIS method
                                                                                                                                                                                                       org.apache.commons.math.analysis.solvers.IllinoisSolver solver = 
                                                                                                                                                                                                           new org.apache.commons.math.analysis.solvers.IllinoisSolver(1.0e-6);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                       java.lang.reflect.Method setupMethod = org.apache.commons.math.analysis.solvers.BaseSecantSolver.class
                                                                                                                                                                                                           .getDeclaredMethod("setup", 
                                                                                                                                                                                                               int.class, 
                                                                                                                                                                                                               org.apache.commons.math.analysis.UnivariateRealFunction.class, 
                                                                                                                                                                                                               double.class, 
                                                                                                                                                                                                               double.class, 
                                                                                                                                                                                                               double.class,
                                                                                                                                                                                                               org.apache.commons.math.analysis.solvers.AllowedSolution.class);
                                                                                                                                                                                                       setupMethod.setAccessible(true);
                                                                                                                                                                                                       setupMethod.invoke(solver, 
                                                                                                                                                                                                           100, 
                                                                                                                                                                                                           mockFunction, 
                                                                                                                                                                                                           -1.0, 
                                                                                                                                                                                                           1.0, 
                                                                                                                                                                                                           0.0, 
                                                                                                                                                                                                           org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to call protected doSolve()
                                                                                                                                                                                                       java.lang.reflect.Method doSolveMethod = org.apache.commons.math.analysis.solvers.BaseSecantSolver.class
                                                                                                                                                                                                           .getDeclaredMethod("doSolve");
                                                                                                                                                                                                       doSolveMethod.setAccessible(true);
                                                                                                                                                                                                       double result = (Double) doSolveMethod.invoke(solver);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify the solution meets the ABOVE_SIDE condition
                                                                                                                                                                                                       org.junit.Assert.assertTrue(mockFunction.value(result) >= 0.0);
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                           public void testDoSolve_ExactRootAtLowerBound() throws Exception {
                                                                                                                                                               // Import required classes through reflection
                                                                                                                                                               Class<?> solverClass = Class.forName("org.apache.commons.math.analysis.solvers.BaseSecantSolver");
                                                                                                                                                               Class<?> methodClass = Class.forName("org.apache.commons.math.analysis.solvers.BaseSecantSolver$Method");
                                                                                                                                                               java.lang.reflect.Field field = methodClass.getDeclaredField("REGULA_FALSI");
                                                                                                                                                               field.setAccessible(true);
                                                                                                                                                               Object regulaFalsi = field.get(null);
                                                                                                                                                               
                                                                                                                                                               // Create solver with REGULA_FALSI method using anonymous subclass
                                                                                                                                                               // Use reflection to create the solver since Method is protected
                                                                                                                                                               Constructor<?> constructor = solverClass.getDeclaredConstructor(
                                                                                                                                                                   double.class, double.class, methodClass);
                                                                                                                                                               constructor.setAccessible(true);
                                                                                                                                                               BaseSecantSolver solver = (BaseSecantSolver) constructor.newInstance(
                                                                                                                                                                   1.0e-6,  // relative accuracy
                                                                                                                                                                   1.0e-6,  // absolute accuracy
                                                                                                                                                                   regulaFalsi
                                                                                                                                                               );
                                                                                                                                                               
                                                                                                                                                               // Create and setup mock function
                                                                                                                                                               UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                                                                                   @Override
                                                                                                                                                                   public double value(double x) {
                                                                                                                                                                       // Function with root exactly at lower bound (0.0)
                                                                                                                                                                       return x;
                                                                                                                                                                   }
                                                                                                                                                               };
                                                                                                                                                               
                                                                                                                                                               // Test with root exactly at lower bound
                                                                                                                                                               double result = solver.solve(100, f, 0.0, 1.0,
                                                                                                                                                                   org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE);
                                                                                                                                                               assertEquals(0.0, result, 1.0e-6);
                                                                                                                                                           }

    @Test
                                                                                                                                   public void testDoSolve_WithRegulaFalsiMethod() throws Exception {
                                                                                                                                       // Use reflection to access the protected Method enum
                                                                                                                                       Class<?> solverClass = Class.forName("org.apache.commons.math.analysis.solvers.BaseSecantSolver");
                                                                                                                                       Class<?>[] declaredClasses = solverClass.getDeclaredClasses();
                                                                                                                                       Class<?> methodClass = null;
                                                                                                                                       for (Class<?> clazz : declaredClasses) {
                                                                                                                                           if (clazz.getSimpleName().equals("Method")) {
                                                                                                                                               methodClass = clazz;
                                                                                                                                               break;
                                                                                                                                           }
                                                                                                                                       }
                                                                                                                                       if (methodClass == null) {
                                                                                                                                           fail("Unable to find Method enum class");
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // Get the REGULA_FALSI enum constant
                                                                                                                                       Object[] enumConstants = methodClass.getEnumConstants();
                                                                                                                                       Object regulaFalsiConstant = null;
                                                                                                                                       for (Object constant : enumConstants) {
                                                                                                                                           if (constant.toString().equals("REGULA_FALSI")) {
                                                                                                                                               regulaFalsiConstant = constant;
                                                                                                                                               break;
                                                                                                                                           }
                                                                                                                                       }
                                                                                                                                       if (regulaFalsiConstant == null) {
                                                                                                                                           fail("Unable to find REGULA_FALSI enum constant");
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // Create a concrete implementation of BaseSecantSolver for testing using reflection
                                                                                                                                       Class<?>[] parameterTypes = {double.class, double.class, methodClass};
                                                                                                                                       java.lang.reflect.Constructor<?> constructor = solverClass.getDeclaredConstructor(parameterTypes);
                                                                                                                                       constructor.setAccessible(true);
                                                                                                                                       Object solver = constructor.newInstance(1.0e-6, 1.0e-6, regulaFalsiConstant);
                                                                                                                                       
                                                                                                                                       // Create anonymous subclass to implement computeObjectiveValue
                                                                                                                                       Object solverInstance = new Object() {
                                                                                                                                           protected double computeObjectiveValue(double x) {
                                                                                                                                               return x * x - 2;
                                                                                                                                           }
                                                                                                                                       };
                                                                                                                                       
                                                                                                                                       // Create mock function
                                                                                                                                       org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                                                                                                           new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                                                                               @Override
                                                                                                                                               public double value(double x) {
                                                                                                                                                   return x * x - 2;
                                                                                                                                               }
                                                                                                                                           };
                                                                                                                                       
                                                                                                                                       try {
                                                                                                                                           // Use reflection to access protected setup method
                                                                                                                                           java.lang.reflect.Method setupMethod = solverClass
                                                                                                                                               .getDeclaredMethod("setup", 
                                                                                                                                                   int.class, 
                                                                                                                                                   org.apache.commons.math.analysis.UnivariateRealFunction.class, 
                                                                                                                                                   double.class, 
                                                                                                                                                   double.class, 
                                                                                                                                                   double.class);
                                                                                                                                           setupMethod.setAccessible(true);
                                                                                                                                           setupMethod.invoke(solver, 100, function, 1.0, 2.0, 0.0);
                                                                                                                                           
                                                                                                                                           // Use reflection to access protected doSolve method
                                                                                                                                           java.lang.reflect.Method doSolveMethod = solverClass
                                                                                                                                               .getDeclaredMethod("doSolve");
                                                                                                                                           doSolveMethod.setAccessible(true);
                                                                                                                                           
                                                                                                                                           // Test the doSolve method
                                                                                                                                           double result = (double) doSolveMethod.invoke(solver);
                                                                                                                                           assertEquals(1.4142, result, 1.0e-4);
                                                                                                                                       } catch (Exception e) {
                                                                                                                                           fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                       }
                                                                                                                                   }

    @Test
                                                                                                                               public void testDoSolve_BelowSideSolution() throws Exception {
                                                                                                                                   // Create mock function
                                                                                                                                   UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                   when(mockFunction.value(anyDouble())).thenReturn(-1.0, 1.0, -0.5, 0.25, -0.125);
                                                                                                                                   
                                                                                                                                   // Create solver instance using PegasusSolver which internally uses REGULA_FALSI method
                                                                                                                                   // Using constructor with relativeAccuracy, absoluteAccuracy, and functionValueAccuracy
                                                                                                                                   PegasusSolver solver = new PegasusSolver(1.0e-6, 1.0e-6, 1.0e-6);
                                                                                                                                   
                                                                                                                                   // Call the public solve method with BELOW_SIDE solution constraint
                                                                                                                                   double result = solver.solve(5, mockFunction, 0.0, 1.0, 0.5, AllowedSolution.BELOW_SIDE);
                                                                                                                                   
                                                                                                                                   // Verify the result is on the below side of the midpoint (0.5)
                                                                                                                                   assertTrue("Solution should be on below side", result < 0.5);
                                                                                                                               }

    @Test
                                                                                                              public void testDoSolve_RegulaFalsiMethod_DetectsBreakToContinueMutant() throws Exception {
                                                                                                                  // Create a concrete subclass to access protected constructor
                                                                                                                  class TestSolver extends BaseSecantSolver {
                                                                                                                      TestSolver() {
                                                                                                                          super(1e-6, 1e-6, 1e-6, BaseSecantSolver.Method.REGULA_FALSI);
                                                                                                                      }
                                                                                                                      
                                                                                                                      @Override
                                                                                                                      public double computeObjectiveValue(double x) {
                                                                                                                          // Simple quadratic function with root at x=2
                                                                                                                          return (x - 2) * (x + 1);
                                                                                                                      }
                                                                                                                  }
                                                                                                                  
                                                                                                                  TestSolver solver = new TestSolver();
                                                                                                                  
                                                                                                                  // Use reflection to set allowed solution to ANY_SIDE
                                                                                                                  Field allowedField = BaseSecantSolver.class.getDeclaredField("allowed");
                                                                                                                  allowedField.setAccessible(true);
                                                                                                                  allowedField.set(solver, AllowedSolution.ANY_SIDE);
                                                                                                                  
                                                                                                                  // Use reflection to call protected doSolve method
                                                                                                                  Method doSolveMethod = BaseSecantSolver.class.getDeclaredMethod("doSolve");
                                                                                                                  doSolveMethod.setAccessible(true);
                                                                                                                  double result = (double) doSolveMethod.invoke(solver);
                                                                                                                  
                                                                                                                  // Verify the result is close to the actual root (x=2)
                                                                                                                  assertEquals(2.0, result, 1e-6);
                                                                                                              }

    @Test
                                                                                                     public void testRegulaFalsiDoesNotReturnEarly() throws Exception {
                                                                                                         // Create a public subclass to access protected members
                                                                                                         class TestSolver extends BaseSecantSolver {
                                                                                                             private int callCount = 0;
                                                                                                             
                                                                                                             TestSolver() {
                                                                                                                 super(1e-6, BaseSecantSolver.Method.REGULA_FALSI);
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             protected double computeObjectiveValue(double x) {
                                                                                                                 callCount++;
                                                                                                                 // First call (x0): positive
                                                                                                                 // Second call (x1): negative
                                                                                                                 // Subsequent calls: approach zero
                                                                                                                 if (callCount == 1) return 1.0;
                                                                                                                 if (callCount == 2) return -1.0;
                                                                                                                 return -0.1 * (callCount - 2); // Slowly approaching zero
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             public double getMin() {
                                                                                                                 return 0.0; // x0
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             public double getMax() {
                                                                                                                 return 1.0; // x1
                                                                                                             }
                                                                                                         }
                                                                                                         
                                                                                                         TestSolver solver = new TestSolver();
                                                                                                         
                                                                                                         // Use reflection to access protected doSolve() method
                                                                                                         Method doSolve = BaseSecantSolver.class.getDeclaredMethod("doSolve");
                                                                                                         doSolve.setAccessible(true);
                                                                                                         double result = (Double) doSolve.invoke(solver);
                                                                                                         
                                                                                                         // Verify - should not return x0 (0.0) but continue iterating
                                                                                                         // We expect result to be between 0 and 1
                                                                                                         assertTrue("Result should be greater than 0", result > 0.0);
                                                                                                         assertTrue("Result should be less than 1", result < 1.0);
                                                                                                         
                                                                                                         // Additional verification that we didn't return immediately
                                                                                                         // by checking the result is reasonably close to expected
                                                                                                         assertTrue("Result should be close to expected root", 
                                                                                                                    Math.abs(result - 0.5) < 0.4); // Wide tolerance since exact value depends on mock
                                                                                                     }

    @Test(expected = MathInternalError.class)
                                                                                            public void testDoSolveWithInvalidMethodThrowsException() throws Exception {
                                                                                                // Create a solver with invalid method
                                                                                                BaseSecantSolver solver = new BaseSecantSolver(1e-6, null) {
                                                                                                    @Override
                                                                                                    public double solve(int maxEval, UnivariateRealFunction f, double min, double max, AllowedSolution allowedSolution) {
                                                                                                        return 0.0;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public double solve(int maxEval, UnivariateRealFunction f, double min, double max, double startValue, AllowedSolution allowedSolution) {
                                                                                                        return 0.0;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public double solve(int maxEval, UnivariateRealFunction f, double min, double max, double startValue) {
                                                                                                        return 0.0;
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                // Use reflection to call doSolve
                                                                                                Method doSolve = BaseSecantSolver.class.getDeclaredMethod("doSolve");
                                                                                                doSolve.setAccessible(true);
                                                                                                doSolve.invoke(solver);
                                                                                            }

    @Test
                                                           public void testRegulaFalsiDoesNotReturnPrematurely() {
                                                               // Create a test subclass to access protected constructor
                                                               class TestSecantSolver extends BaseSecantSolver {
                                                                   TestSecantSolver(double absoluteAccuracy) throws Exception {
                                                                       super(absoluteAccuracy, BaseSecantSolver.Method.REGULA_FALSI);
                                                                   }
                                                               }
                                                               
                                                               // Create a solver with REGULA_FALSI method
                                                               BaseSecantSolver solver;
                                                               try {
                                                                   solver = new TestSecantSolver(1e-6);
                                                               } catch (Exception e) {
                                                                   fail("Failed to create solver: " + e.getMessage());
                                                                   return;
                                                               }
                                                               
                                                               // Define the function to solve (simple quadratic with root at 2.0)
                                                               UnivariateRealFunction func = new UnivariateRealFunction() {
                                                                   @Override
                                                                   public double value(double x) {
                                                                       return x * x - 4;
                                                                   }
                                                               };
                                                               
                                                               // Execute
                                                               double result = solver.solve(100, func, 1.0, 3.0, AllowedSolution.ANY_SIDE);
                                                               
                                                               // Verify - should converge to root at 2.0
                                                               assertEquals(2.0, result, 1e-6);
                                                               
                                                               // Additional verification that we didn't return prematurely
                                                               assertNotEquals(3.0, result, 1e-6);
                                                               assertNotEquals(1.0, result, 1e-6);
                                                           }

    @Test
                                                  public void testRegulaFalsiMethodUpdatesBounds() {
                                                      // Create solver instance using RegulaFalsiSolver which extends BaseSecantSolver
                                                      BaseSecantSolver solver = new RegulaFalsiSolver(1e-6) {
                                                          @Override
                                                          protected double computeObjectiveValue(double x) {
                                                              // Simple quadratic function with root at 2.0
                                                              return x * x - 4;
                                                          }
                                                          
                                                          @Override
                                                          protected void verifyBracketing(double x0, double x1) {
                                                              // No-op for test
                                                          }
                                                      };
                                                      
                                                      // Use reflection to set allowed solution
                                                      try {
                                                          Field allowedField = BaseSecantSolver.class.getDeclaredField("allowed");
                                                          allowedField.setAccessible(true);
                                                          allowedField.set(solver, AllowedSolution.ANY_SIDE);
                                                      } catch (Exception e) {
                                                          fail("Failed to set allowed solution via reflection");
                                                      }
                                                      
                                                      // Call solve() with min/max parameters instead of overriding getMin/getMax
                                                      double result = solver.solve(100, new UnivariateRealFunction() {
                                                          @Override
                                                          public double value(double x) {
                                                              return x * x - 4;
                                                          }
                                                      }, 1.0, 3.0, AllowedSolution.ANY_SIDE);
                                                      
                                                      // Verify we got the correct root
                                                      assertEquals(2.0, result, 1e-6);
                                                  }

    @Test
         public void testRegulaFalsiMethodDoesNotThrowException() throws Exception {
             // Create a simple linear function f(x) = x - 2 (root at x=2)
             UnivariateRealFunction f = x -> x - 2;
             
             // Create a local subclass to access protected constructor
             class TestSolver extends BaseSecantSolver {
                 private final UnivariateRealFunction function;
                 
                 TestSolver(double relativeAccuracy, double absoluteAccuracy, Object method, UnivariateRealFunction f) throws Exception {
                     super(relativeAccuracy, absoluteAccuracy, (Method) method);
                     this.function = f;
                 }
                 
                 @Override
                 protected double computeObjectiveValue(double x) {
                     return function.value(x);
                 }
             }
             
             // Get REGULA_FALSI method enum value through reflection
             Class<?>[] declaredClasses = BaseSecantSolver.class.getDeclaredClasses();
             Class<?> methodClass = null;
             for (Class<?> c : declaredClasses) {
                 if (c.getSimpleName().equals("Method")) {
                     methodClass = c;
                     break;
                 }
             }
             Field regulaFalsiField = methodClass.getDeclaredField("REGULA_FALSI");
             regulaFalsiField.setAccessible(true);
             Object regulaFalsi = regulaFalsiField.get(null);
             
             // Create solver with REGULA_FALSI method
             BaseSecantSolver solver = new TestSolver(1e-6, 1e-6, regulaFalsi, f);
             
             // Set allowed solution type using reflection
             Field allowedField = BaseSecantSolver.class.getDeclaredField("allowed");
             allowedField.setAccessible(true);
             allowedField.set(solver, AllowedSolution.ANY_SIDE);
             
             // Call doSolve() using reflection
             Method doSolveMethod = BaseSecantSolver.class.getDeclaredMethod("doSolve");
             doSolveMethod.setAccessible(true);
             double result = (double) doSolveMethod.invoke(solver);
             
             // Verify we got the correct root
             assertEquals(2.0, result, 1e-6);
         }

    @Test(expected = MathInternalError.class)
    public void testDoSolveWithInvalidMethodThrowsException1() {
        // Create a mock UnivariateRealFunction that returns simple values
        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
        when(mockFunction.value(anyDouble())).thenReturn(1.0);
        
        // Create test instance with invalid method (null)
        BaseSecantSolver solver = new BaseSecantSolver(1e-6, 1e-6, null) {
            @Override
            protected double computeObjectiveValue(double x) { 
                return mockFunction.value(x); 
            }
        };
        
        // Use reflection to call protected doSolve() method
        try {
            Method doSolveMethod = BaseSecantSolver.class.getDeclaredMethod("doSolve");
            doSolveMethod.setAccessible(true);
            doSolveMethod.invoke(solver);
        } catch (InvocationTargetException e) {
            // Unwrap the actual exception we expect
            throw (RuntimeException) e.getCause();
        } catch (Exception e) {
            throw new RuntimeException("Failed to invoke doSolve", e);
        }
    }


}
