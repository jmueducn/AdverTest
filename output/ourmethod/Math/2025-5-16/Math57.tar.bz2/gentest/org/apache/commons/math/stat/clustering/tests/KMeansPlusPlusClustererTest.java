package gentest.org.apache.commons.math.stat.clustering.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.clustering.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.Variance;
 
public class KMeansPlusPlusClustererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                                                                                                                public void testChooseInitialCenters_NullRandom() {
                                                                                                                                                                                                                                                                                                                    // Define a simple TestPoint class for testing
                                                                                                                                                                                                                                                                                                                    class TestPoint {
                                                                                                                                                                                                                                                                                                                        private final double value;
                                                                                                                                                                                                                                                                                                                        public TestPoint(double value) { this.value = value; }
                                                                                                                                                                                                                                                                                                                        public double distanceFrom(TestPoint p) { return Math.abs(value - p.value); }
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    java.util.List<TestPoint> points = new java.util.ArrayList<TestPoint>();
                                                                                                                                                                                                                                                                                                                    points.add(new TestPoint(1.0));
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                                                                                        // Get the KMeansPlusPlusClusterer class
                                                                                                                                                                                                                                                                                                                        Class<?> clustererClass = Class.forName("org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer");
                                                                                                                                                                                                                                                                                                                        // Get the private static chooseInitialCenters method
                                                                                                                                                                                                                                                                                                                        java.lang.reflect.Method method = clustererClass.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                            "chooseInitialCenters", 
                                                                                                                                                                                                                                                                                                                            java.util.Collection.class, 
                                                                                                                                                                                                                                                                                                                            int.class, 
                                                                                                                                                                                                                                                                                                                            java.util.Random.class);
                                                                                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                        // Invoke the method with null Random parameter
                                                                                                                                                                                                                                                                                                                        method.invoke(null, points, 1, null);
                                                                                                                                                                                                                                                                                                                    } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                                        throw (RuntimeException) e.getCause();
                                                                                                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                        throw new RuntimeException(e);
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                            public void testChooseInitialCenters_EmptyPoints() throws Exception {
                                                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                                                java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                                                                                                                java.util.Collection<Object> points = java.util.Collections.emptyList();
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Get the private static method via reflection
                                                                                                                                                                                                                                                                                                                java.lang.reflect.Method chooseInitialCenters = 
                                                                                                                                                                                                                                                                                                                    org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                        "chooseInitialCenters", 
                                                                                                                                                                                                                                                                                                                        java.util.Collection.class, 
                                                                                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                                                                                        java.util.Random.class);
                                                                                                                                                                                                                                                                                                                chooseInitialCenters.setAccessible(true);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Expected exception
                                                                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                                                                                                    chooseInitialCenters.invoke(null, points, 1, mockRandom);
                                                                                                                                                                                                                                                                                                                    fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                                                                                } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                                                                                                                    assertEquals(IllegalArgumentException.class, e.getCause().getClass());
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                            public void testChooseInitialCenters_KEqualsZero() throws Exception {
                                                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                                                java.util.List<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint> points = 
                                                                                                                                                                                                                                                                                                                    new java.util.ArrayList<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>();
                                                                                                                                                                                                                                                                                                                points.add(new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1}));
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Create mock Random
                                                                                                                                                                                                                                                                                                                java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Create clusterer instance
                                                                                                                                                                                                                                                                                                                org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint> clusterer = 
                                                                                                                                                                                                                                                                                                                    new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>(mockRandom);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Get the private method via reflection
                                                                                                                                                                                                                                                                                                                java.lang.reflect.Method method = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                                                                                                                                                    .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                                                                                                                                                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Act & Assert
                                                                                                                                                                                                                                                                                                                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                                                                                exception.expect(java.lang.IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                                method.invoke(clusterer, points, 0, mockRandom);
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                    public void testChooseInitialCenters_NullPoints() throws Exception {
                                                                                                                                                                                                                                                                                                        // Create mock Random
                                                                                                                                                                                                                                                                                                        java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Get the private method using reflection
                                                                                                                                                                                                                                                                                                        java.lang.reflect.Method chooseInitialCenters = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                                                                                                                                            .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                                                                                                                                                                                                                                                                                        chooseInitialCenters.setAccessible(true);
                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                        // Test for expected exception
                                                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                                                            chooseInitialCenters.invoke(null, null, 1, mockRandom);
                                                                                                                                                                                                                                                                                                            fail("Expected NullPointerException");
                                                                                                                                                                                                                                                                                                        } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                            assertTrue(e.getCause() instanceof NullPointerException);
                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                        public void testChooseInitialCenters_VerifyProbabilityDistribution() throws Exception {
                                                                                                                                                                                                                                                                                            // Define a simple TestPoint class for testing
                                                                                                                                                                                                                                                                                            class TestPoint {
                                                                                                                                                                                                                                                                                                private final double value;
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                public TestPoint(double value) {
                                                                                                                                                                                                                                                                                                    this.value = value;
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                public double getValue() {
                                                                                                                                                                                                                                                                                                    return value;
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                public double[] getPoint() {
                                                                                                                                                                                                                                                                                                    return new double[]{value};
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Define a simple Cluster class for testing
                                                                                                                                                                                                                                                                                            class Cluster<T> {
                                                                                                                                                                                                                                                                                                private T center;
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                public Cluster(T center) {
                                                                                                                                                                                                                                                                                                    this.center = center;
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                public T getCenter() {
                                                                                                                                                                                                                                                                                                    return center;
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // This test verifies that points are selected with probability proportional to D(x)^2
                                                                                                                                                                                                                                                                                            Random mockRandom = mock(Random.class);
                                                                                                                                                                                                                                                                                            when(mockRandom.nextInt(anyInt())).thenReturn(0); // Select first point initially
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Setup points where one is much farther than others
                                                                                                                                                                                                                                                                                            List<TestPoint> points = new ArrayList<>();
                                                                                                                                                                                                                                                                                            points.add(new TestPoint(1.0));  // Will be selected first
                                                                                                                                                                                                                                                                                            points.add(new TestPoint(1.1));  // Close to first
                                                                                                                                                                                                                                                                                            points.add(new TestPoint(100.0)); // Far from first
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Mock random to select the far point (sum of squares will be large for far point)
                                                                                                                                                                                                                                                                                            when(mockRandom.nextDouble()).thenReturn(0.99); // Will select the last point in probability distribution
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Create a clusterer instance to access the static method via reflection
                                                                                                                                                                                                                                                                                            Class<?> clustererClass = Class.forName("org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer");
                                                                                                                                                                                                                                                                                            Method chooseInitialCenters = clustererClass.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                                                                                                                                                                                                                            chooseInitialCenters.setAccessible(true);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            @SuppressWarnings({"unchecked", "rawtypes"})
                                                                                                                                                                                                                                                                                            List<Cluster> result = (List<Cluster>) chooseInitialCenters.invoke(
                                                                                                                                                                                                                                                                                                null, points, 2, mockRandom);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            assertEquals(100.0, ((TestPoint)result.get(1).getCenter()).getValue(), 0.001);
                                                                                                                                                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                            public void testChooseInitialCenters_KGreaterThanPointsSize() throws Exception {
                                                                                                                                                                                                                                                // Define a simple TestPoint class that just holds coordinates
                                                                                                                                                                                                                                                class TestPoint {
                                                                                                                                                                                                                                                    private final double[] points;
                                                                                                                                                                                                                                                    public TestPoint(double value) {
                                                                                                                                                                                                                                                        this.points = new double[]{value};
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    public double[] getPoint() {
                                                                                                                                                                                                                                                        return points;
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                                                java.util.List<TestPoint> points = new java.util.ArrayList<TestPoint>();
                                                                                                                                                                                                                                                points.add(new TestPoint(1.0));
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get the private method via reflection
                                                                                                                                                                                                                                                Class<?> clustererClass = Class.forName("org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer");
                                                                                                                                                                                                                                                Method chooseInitialCenters = clustererClass.getDeclaredMethod(
                                                                                                                                                                                                                                                    "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                                                                                                                                                                                chooseInitialCenters.setAccessible(true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test - call the method via reflection (should throw IllegalArgumentException)
                                                                                                                                                                                                                                                chooseInitialCenters.invoke(null, points, 2, mockRandom);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                               public void testChooseInitialCentersWithK1DetectsMutant() {
                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                   java.util.Random mockRandom = mock(java.util.Random.class);
                                                                                                                                                                                                                   when(mockRandom.nextInt(anyInt())).thenReturn(0); // Always pick first element
                                                                                                                                                                                                                   when(mockRandom.nextDouble()).thenReturn(0.5); // Fixed probability for deterministic test
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Create a simple point collection
                                                                                                                                                                                                                   java.util.List<double[]> pointValues = new java.util.ArrayList<double[]>();
                                                                                                                                                                                                                   pointValues.add(new double[]{1.0});
                                                                                                                                                                                                                   pointValues.add(new double[]{2.0});
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Convert to EuclideanDoublePoint list
                                                                                                                                                                                                                   java.util.List<Object> points = new java.util.ArrayList<Object>();
                                                                                                                                                                                                                   for (double[] values : pointValues) {
                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                           Class<?> pointClass = Class.forName("org.apache.commons.math.stat.clustering.EuclideanDoublePoint");
                                                                                                                                                                                                                           Object point = pointClass.getConstructor(double[].class).newInstance(values);
                                                                                                                                                                                                                           points.add(point);
                                                                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                                                                           fail("Failed to create EuclideanDoublePoint: " + e.getMessage());
                                                                                                                                                                                                                       }
                                                                                                                                                                                                                   }
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Test with k=1
                                                                                                                                                                                                                   java.util.List<?> result;
                                                                                                                                                                                                                   try {
                                                                                                                                                                                                                       Class<?> clustererClass = Class.forName("org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer");
                                                                                                                                                                                                                       java.lang.reflect.Method method = clustererClass.getDeclaredMethod(
                                                                                                                                                                                                                           "chooseInitialCenters", 
                                                                                                                                                                                                                           java.util.Collection.class, 
                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                           java.util.Random.class
                                                                                                                                                                                                                       );
                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                       result = (java.util.List<?>) method.invoke(null, points, 1, mockRandom);
                                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                                       fail("Failed to invoke chooseInitialCenters: " + e.getMessage());
                                                                                                                                                                                                                       return;
                                                                                                                                                                                                                   }
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Verify exactly 1 center is chosen (original behavior)
                                                                                                                                                                                                                   // Mutated version would potentially add a second center
                                                                                                                                                                                                                   assertEquals(1, result.size());
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Additional verification that we didn't modify input collection size
                                                                                                                                                                                                                   assertEquals(2, points.size());
                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                  public void testChooseInitialCenters_DetectsNegativeSumMutant() throws Exception {
                                                                                                                                                                                      // Create mock points with known distances
                                                                                                                                                                                      java.util.List<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint> points = new java.util.ArrayList<>();
                                                                                                                                                                                      org.apache.commons.math.stat.clustering.EuclideanIntegerPoint p1 = 
                                                                                                                                                                                          new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1});
                                                                                                                                                                                      org.apache.commons.math.stat.clustering.EuclideanIntegerPoint p2 = 
                                                                                                                                                                                          new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{2});
                                                                                                                                                                                      org.apache.commons.math.stat.clustering.EuclideanIntegerPoint p3 = 
                                                                                                                                                                                          new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{3});
                                                                                                                                                                                      
                                                                                                                                                                                      points.add(p1);
                                                                                                                                                                                      points.add(p2);
                                                                                                                                                                                      points.add(p3);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use fixed random for predictable selection
                                                                                                                                                                                      java.util.Random fixedRandom = new java.util.Random(12345) {
                                                                                                                                                                                          @Override
                                                                                                                                                                                          public double nextDouble() {
                                                                                                                                                                                              return 0.5; // Fixed value for testing probability selection
                                                                                                                                                                                          }
                                                                                                                                                                                      };
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to call the private static method
                                                                                                                                                                                      java.lang.reflect.Method chooseInitialCenters = 
                                                                                                                                                                                          org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                              .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                                                                                                                                                                      chooseInitialCenters.setAccessible(true);
                                                                                                                                                                                      
                                                                                                                                                                                      @SuppressWarnings("unchecked")
                                                                                                                                                                                      java.util.List<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>> clusters = 
                                                                                                                                                                                          (java.util.List<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>>)
                                                                                                                                                                                              chooseInitialCenters.invoke(null, points, 2, fixedRandom);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify results
                                                                                                                                                                                      org.junit.Assert.assertEquals(2, clusters.size());
                                                                                                                                                                                      
                                                                                                                                                                                      // The first center should be randomly selected (p1, p2 or p3)
                                                                                                                                                                                      org.apache.commons.math.stat.clustering.EuclideanIntegerPoint firstCenter = clusters.get(0).getCenter();
                                                                                                                                                                                      org.junit.Assert.assertTrue(points.contains(firstCenter));
                                                                                                                                                                                      
                                                                                                                                                                                      // The second center should be selected based on probability distribution
                                                                                                                                                                                      // With sum=-1 mutant, this selection would be incorrect
                                                                                                                                                                                      org.apache.commons.math.stat.clustering.EuclideanIntegerPoint secondCenter = clusters.get(1).getCenter();
                                                                                                                                                                                      org.junit.Assert.assertTrue(points.contains(secondCenter));
                                                                                                                                                                                      org.junit.Assert.assertNotEquals(firstCenter, secondCenter);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify the probability distribution was correctly calculated
                                                                                                                                                                                      // The mutant with sum=-1 would fail this check
                                                                                                                                                                                      org.junit.Assert.assertTrue(clusters.get(1).getCenter().distanceFrom(clusters.get(0).getCenter()) > 0);
                                                                                                                                                                                  }

    @Test
                                                                                                                                         public void testChooseInitialCentersProcessesAllPoints() throws Exception {
                                                                                                                                             // Create mock point objects that implement Clusterable
                                                                                                                                             class TestPoint implements org.apache.commons.math.stat.clustering.Clusterable<TestPoint> {
                                                                                                                                                 final double x;
                                                                                                                                                 TestPoint(double x) { this.x = x; }
                                                                                                                                                 public double distanceFrom(TestPoint p) { return Math.abs(x - p.x); }
                                                                                                                                                 public TestPoint centroidOf(Collection<TestPoint> points) {
                                                                                                                                                     double sum = 0;
                                                                                                                                                     for (TestPoint p : points) {
                                                                                                                                                         sum += p.x;
                                                                                                                                                     }
                                                                                                                                                     return new TestPoint(sum / points.size());
                                                                                                                                                 }
                                                                                                                                             }
                                                                                                                                             
                                                                                                                                             // Create test data - exactly 2 points that are far apart
                                                                                                                                             java.util.List<TestPoint> points = java.util.Arrays.asList(
                                                                                                                                                 new TestPoint(0.0),
                                                                                                                                                 new TestPoint(100.0)
                                                                                                                                             );
                                                                                                                                             
                                                                                                                                             // Use fixed random sequence:
                                                                                                                                             // First random selection will pick first point (index 0)
                                                                                                                                             // Second random selection should pick second point (sum will be large)
                                                                                                                                             java.util.Random fixedRandom = new java.util.Random() {
                                                                                                                                                 @Override
                                                                                                                                                 public int nextInt(int bound) {
                                                                                                                                                     return 0; // Always return first index for first center selection
                                                                                                                                                 }
                                                                                                                                                 @Override
                                                                                                                                                 public double nextDouble() {
                                                                                                                                                     return 0.5; // Midpoint selection for second center
                                                                                                                                                 }
                                                                                                                                             };
                                                                                                                                             
                                                                                                                                             // Use reflection to access private chooseInitialCenters method
                                                                                                                                             java.lang.reflect.Method method = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                 .getDeclaredMethod("chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                                                                             method.setAccessible(true);
                                                                                                                                             
                                                                                                                                             // Call method under test
                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                             java.util.List<org.apache.commons.math.stat.clustering.Cluster<TestPoint>> result = 
                                                                                                                                                 (java.util.List<org.apache.commons.math.stat.clustering.Cluster<TestPoint>>) 
                                                                                                                                                 method.invoke(null, points, 2, fixedRandom);
                                                                                                                                             
                                                                                                                                             // Verify both points were selected as centers
                                                                                                                                             assertEquals(2, result.size());
                                                                                                                                             // Original method would select both points (0.0 and 100.0)
                                                                                                                                             // Mutant would skip second point in distance calculation, leading to wrong selection
                                                                                                                                             boolean found0 = false;
                                                                                                                                             boolean found100 = false;
                                                                                                                                             for (org.apache.commons.math.stat.clustering.Cluster<TestPoint> c : result) {
                                                                                                                                                 if (c.getCenter().x == 0.0) found0 = true;
                                                                                                                                                 if (c.getCenter().x == 100.0) found100 = true;
                                                                                                                                             }
                                                                                                                                             assertTrue(found0);
                                                                                                                                             assertTrue(found100);
                                                                                                                                         }

    @Test
                                                                                                                    public void testChooseInitialCentersDetectsGetZeroMutant() {
                                                                                                                        // Define a simple TestPoint class for testing
                                                                                                                        class TestPoint {
                                                                                                                            private final double value;
                                                                                                                            
                                                                                                                            public TestPoint(double value) {
                                                                                                                                this.value = value;
                                                                                                                            }
                                                                                                                            
                                                                                                                            public double getValue() {
                                                                                                                                return value;
                                                                                                                            }
                                                                                                                            
                                                                                                                            public double distanceFrom(TestPoint other) {
                                                                                                                                return Math.abs(this.value - other.value);
                                                                                                                            }
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Create test points with controlled distances
                                                                                                                        List<TestPoint> points = new ArrayList<>();
                                                                                                                        points.add(new TestPoint(1)); // First point - distance will be 1
                                                                                                                        points.add(new TestPoint(10)); // Second point - distance will be 10
                                                                                                                        points.add(new TestPoint(100)); // Third point - distance will be 100
                                                                                                                        
                                                                                                                        // Mock Random to control selection
                                                                                                                        Random mockRandom = mock(Random.class);
                                                                                                                        // First selection (random)
                                                                                                                        when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                                                                                                        // Second selection (weighted) - return value that should pick point with distance 100
                                                                                                                        when(mockRandom.nextDouble()).thenReturn(0.99);
                                                                                                                        
                                                                                                                        try {
                                                                                                                            // Get the private static chooseInitialCenters method via reflection
                                                                                                                            Method chooseInitialCentersMethod = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                                                                "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                                                            chooseInitialCentersMethod.setAccessible(true);
                                                                                                                            
                                                                                                                            // Call the method with raw type and cast the result
                                                                                                                            @SuppressWarnings("rawtypes")
                                                                                                                            List result = (List) chooseInitialCentersMethod.invoke(
                                                                                                                                null, points, 2, mockRandom);
                                                                                                                            
                                                                                                                            // Get the first cluster and cast its center to TestPoint
                                                                                                                            @SuppressWarnings("unchecked")
                                                                                                                            Cluster<?> cluster = (Cluster<?>) result.get(1);
                                                                                                                            TestPoint center = (TestPoint) cluster.getCenter();
                                                                                                                            
                                                                                                                            // Verify the second center selected is the farthest point (distance 100)
                                                                                                                            // If mutant is present, it would incorrectly select based on first point's distance
                                                                                                                            assertEquals(100, center.getValue(), 0.001);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Reflection failed: " + e.getMessage());
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                       public void testChooseInitialCentersDetectsGetIMutation() throws Exception {
                                                                                                           // Define a simple TestPoint class for testing that implements Clusterable
                                                                                                           class TestPoint implements Clusterable<TestPoint> {
                                                                                                               private final double x;
                                                                                                               private final double y;
                                                                                                               
                                                                                                               public TestPoint(double x, double y) {
                                                                                                                   this.x = x;
                                                                                                                   this.y = y;
                                                                                                               }
                                                                                                               
                                                                                                               public double getX() { return x; }
                                                                                                               public double getY() { return y; }
                                                                                                               
                                                                                                               public double distanceFrom(TestPoint other) {
                                                                                                                   return Math.sqrt(Math.pow(x - other.x, 2) + Math.pow(y - other.y, 2));
                                                                                                               }
                                                                                                           
                                                                                                               public double[] getPoint() {
                                                                                                                   return new double[]{x, y};
                                                                                                               }
                                                                                                       
                                                                                                               public TestPoint centroidOf(Collection<TestPoint> points) {
                                                                                                                   double sumX = 0;
                                                                                                                   double sumY = 0;
                                                                                                                   for (TestPoint p : points) {
                                                                                                                       sumX += p.getX();
                                                                                                                       sumY += p.getY();
                                                                                                                   }
                                                                                                                   return new TestPoint(sumX / points.size(), sumY / points.size());
                                                                                                               }
                                                                                                           }
                                                                                                           
                                                                                                           // Create test points with distinct distances
                                                                                                           List<TestPoint> points = new ArrayList<TestPoint>();
                                                                                                           points.add(new TestPoint(1, 0));  // Close to origin
                                                                                                           points.add(new TestPoint(2, 0));  // Medium distance
                                                                                                           points.add(new TestPoint(10, 0)); // Far from origin
                                                                                                           
                                                                                                           // Mock Random to control selection
                                                                                                           Random mockRandom = mock(Random.class);
                                                                                                           // First selection (uniform random) - choose first point
                                                                                                           when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                                                                                           // Second selection (weighted) - return value that should select middle point
                                                                                                           when(mockRandom.nextDouble()).thenReturn(0.5);
                                                                                                           
                                                                                                           // Use reflection to access private chooseInitialCenters method
                                                                                                           Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                                               "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                                           chooseInitialCenters.setAccessible(true);
                                                                                                           
                                                                                                           // Call static method to select 2 centers
                                                                                                           @SuppressWarnings("unchecked")
                                                                                                           List<Cluster<TestPoint>> clusters = (List<Cluster<TestPoint>>) 
                                                                                                               chooseInitialCenters.invoke(null, points, 2, mockRandom);
                                                                                                           
                                                                                                           // Verify second center was selected properly
                                                                                                           // Original should select middle point (2,0) with 0.5 probability
                                                                                                           // Mutant will always use last point (10,0) distances and select it
                                                                                                           assertEquals(2, clusters.size());
                                                                                                           assertNotEquals(10.0, clusters.get(1).getCenter().getX()); // Should fail if mutant present
                                                                                                           
                                                                                                           // Additional verification - check we didn't select the same point twice
                                                                                                           assertNotEquals(clusters.get(0).getCenter(), clusters.get(1).getCenter());
                                                                                                       }

    @Test
                                                                                          public void testChooseInitialCenters_DetectsNearestClusterMutation() throws Exception {
                                                                                              // Define simple TestPoint implementation
                                                                                              class TestPoint implements Clusterable<TestPoint> {
                                                                                                  private final int id;
                                                                                                  private final double[] coordinates;
                                                                                                  
                                                                                                  public TestPoint(int id, double[] coordinates) {
                                                                                                      this.id = id;
                                                                                                      this.coordinates = coordinates;
                                                                                                  }
                                                                                                  
                                                                                                  public int getId() {
                                                                                                      return id;
                                                                                                  }
                                                                                                  
                                                                                                  public double[] getPoint() {
                                                                                                      return coordinates;
                                                                                                  }
                                                                                                  
                                                                                                  public double distanceFrom(TestPoint p) {
                                                                                                      double sum = 0;
                                                                                                      for (int i = 0; i < coordinates.length; i++) {
                                                                                                          double diff = coordinates[i] - p.coordinates[i];
                                                                                                          sum += diff * diff;
                                                                                                      }
                                                                                                      return Math.sqrt(sum);
                                                                                                  }
                                                                                                  
                                                                                                  public TestPoint centroidOf(Collection<TestPoint> points) {
                                                                                                      double[] centroid = new double[coordinates.length];
                                                                                                      for (TestPoint p : points) {
                                                                                                          for (int i = 0; i < centroid.length; i++) {
                                                                                                              centroid[i] += p.coordinates[i];
                                                                                                          }
                                                                                                      }
                                                                                                      for (int i = 0; i < centroid.length; i++) {
                                                                                                          centroid[i] /= points.size();
                                                                                                      }
                                                                                                      return new TestPoint(-1, centroid);
                                                                                                  }
                                                                                              }
                                                                                              
                                                                                              // Create test points with known distances
                                                                                              List<TestPoint> points = new ArrayList<>();
                                                                                              // Point 0 will be first center
                                                                                              points.add(new TestPoint(0, new double[]{0, 0}));
                                                                                              // Points closer to first center
                                                                                              points.add(new TestPoint(1, new double[]{1, 0}));
                                                                                              points.add(new TestPoint(2, new double[]{0, 1}));
                                                                                              // Points that would be closer to a potential second center at (5,0)
                                                                                              points.add(new TestPoint(3, new double[]{4, 0}));
                                                                                              points.add(new TestPoint(4, new double[]{6, 0}));
                                                                                              
                                                                                              // Mock random to control selection
                                                                                              Random mockRandom = mock(Random.class);
                                                                                              // First selection (index 0)
                                                                                              when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                                                                              // Second selection probability (will choose point 3 or 4)
                                                                                              when(mockRandom.nextDouble()).thenReturn(0.6);
                                                                                              
                                                                                              // Use reflection to access private method
                                                                                              Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                                  "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                              chooseInitialCenters.setAccessible(true);
                                                                                              
                                                                                              // Call method to select 2 centers
                                                                                              @SuppressWarnings("unchecked")
                                                                                              List<Cluster<TestPoint>> result = (List<Cluster<TestPoint>>) chooseInitialCenters.invoke(
                                                                                                  null, points, 2, mockRandom);
                                                                                              
                                                                                              // Verify we got 2 clusters
                                                                                              assertEquals(2, result.size());
                                                                                              
                                                                                              // The second center should be one of the points that would be misclassified by the mutant
                                                                                              // (points 3 or 4, which are closer to where the second center should be)
                                                                                              TestPoint secondCenter = result.get(1).getCenter();
                                                                                              assertTrue(secondCenter.getId() == 3 || secondCenter.getId() == 4);
                                                                                              
                                                                                              // With the mutant, it would likely choose point 1 or 2 as second center
                                                                                              // since it would incorrectly calculate distances only to first center
                                                                                          }

    @Test
                                                                         public void testChooseInitialCentersDetectsDistanceMutation() throws Exception {
                                                                             // Define a simple TestPoint class that implements Clusterable
                                                                             class TestPoint implements Clusterable<TestPoint> {
                                                                                 private final double x;
                                                                                 public TestPoint(double x) { this.x = x; }
                                                                                 public double distanceFrom(TestPoint p) { return Math.abs(this.x - p.x); }
                                                                                 public double[] getPoint() {
                                                                                     return new double[]{x};
                                                                                 }
                                                                                 public TestPoint centroidOf(Collection<TestPoint> points) {
                                                                                     double sum = 0;
                                                                                     for (TestPoint p : points) {
                                                                                         sum += p.x;
                                                                                     }
                                                                                     return new TestPoint(sum / points.size());
                                                                                 }
                                                                             }
                                                                             
                                                                             // Create test points with predictable distances
                                                                             List<TestPoint> points = new ArrayList<>();
                                                                             TestPoint p1 = new TestPoint(1.0);
                                                                             TestPoint p2 = new TestPoint(2.0);
                                                                             TestPoint p3 = new TestPoint(3.0);
                                                                             points.add(p1);
                                                                             points.add(p2);
                                                                             points.add(p3);
                                                                             
                                                                             // Mock random number generation to select first point
                                                                             Random mockRandom = mock(Random.class);
                                                                             when(mockRandom.nextInt(anyInt())).thenReturn(0); // select first point first
                                                                             when(mockRandom.nextDouble()).thenReturn(0.5); // middle value for probability selection
                                                                             
                                                                             // Create clusterer instance
                                                                             @SuppressWarnings("unchecked")
                                                                             KMeansPlusPlusClusterer<TestPoint> clusterer = new KMeansPlusPlusClusterer<>(mockRandom);
                                                                             
                                                                             // Get the private chooseInitialCenters method via reflection
                                                                             Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                 "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                             chooseInitialCenters.setAccessible(true);
                                                                             
                                                                             // Call the method
                                                                             @SuppressWarnings("unchecked")
                                                                             List<Cluster<TestPoint>> result = (List<Cluster<TestPoint>>) 
                                                                                 chooseInitialCenters.invoke(clusterer, points, 2, mockRandom);
                                                                             
                                                                             // Verify behavior
                                                                             // With original code, should select point with distance 2 (middle distance)
                                                                             // With mutated code (d=0), would select first remaining point (p2)
                                                                             // So we verify the second center isn't just the next point in sequence
                                                                             assertNotEquals(p2, result.get(1).getCenter());
                                                                             
                                                                             // Also verify distances were actually used in selection
                                                                             // In original code, sum of squared distances would be 1+4+9=14
                                                                             // With 0.5 probability, should select point where cumulative probability > 7
                                                                             // So should select p3 (cumulative 1+4+9=14 > 7)
                                                                             assertEquals(p3, result.get(1).getCenter());
                                                                         }

    @Test
                                                                    public void testChooseInitialCentersDetectsDistanceMutation1() {
                                                                        // Define a simple Point class for testing
                                                                        class Point {
                                                                            private final double x;
                                                                            private final double y;
                                                                            
                                                                            public Point(double x, double y) {
                                                                                this.x = x;
                                                                                this.y = y;
                                                                            }
                                                                            
                                                                            public double getX() { return x; }
                                                                            public double getY() { return y; }
                                                                            
                                                                            public double distanceFrom(Point other) {
                                                                                return Math.sqrt(Math.pow(x - other.x, 2) + Math.pow(y - other.y, 2));
                                                                            }
                                                                        }
                                                                        
                                                                        // Define a simple Cluster class for testing
                                                                        class Cluster<T> {
                                                                            private final T center;
                                                                            
                                                                            public Cluster(T center) {
                                                                                this.center = center;
                                                                            }
                                                                            
                                                                            public T getCenter() {
                                                                                return center;
                                                                            }
                                                                        }
                                                                        
                                                                        // Create test points with known distances
                                                                        List<Point> points = new ArrayList<>();
                                                                        points.add(new Point(0, 0));  // Center 1
                                                                        points.add(new Point(1, 0));  // Distance 1 from center
                                                                        points.add(new Point(2, 0));  // Distance 2 from center
                                                                        points.add(new Point(3, 0));  // Distance 3 from center
                                                                        
                                                                        // Mock Random to control selection
                                                                        Random mockRandom = mock(Random.class);
                                                                        // First selection (random)
                                                                        when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                                                        // Second selection (weighted by distance squared)
                                                                        when(mockRandom.nextDouble()).thenReturn(0.5); // Midpoint in probability distribution
                                                                        
                                                                        // Call method
                                                                        List<Cluster<Point>> clusters = new ArrayList<>();
                                                                        try {
                                                                            Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                            chooseInitialCenters.setAccessible(true);
                                                                            clusters = (List<Cluster<Point>>) chooseInitialCenters.invoke(null, points, 2, mockRandom);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to invoke chooseInitialCenters method");
                                                                        }
                                                                        
                                                                        // Verify behavior
                                                                        assertEquals(2, clusters.size());
                                                                        
                                                                        // The second center should be selected based on actual distances
                                                                        // With distances 1,2,3, squared distances are 1,4,9 (sum=14)
                                                                        // Probability thresholds would be at 1/14 (~0.07), 5/14 (~0.36), 14/14 (1.0)
                                                                        // Our random value 0.5 should select the third point (distance 2)
                                                                        Point secondCenter = clusters.get(1).getCenter();
                                                                        assertEquals(2.0, secondCenter.getX(), 0.0001);
                                                                        
                                                                        // If the mutant was active (all distances=1), all points would have equal probability
                                                                        // and the selection would be different (likely point at x=1)
                                                                    }

    @Test
                                                       public void testChooseInitialCentersWithSumMutation() {
                                                           // Define a simple Point class for testing
                                                           class Point implements Clusterable<Point> {
                                                               private final double x;
                                                               private final double y;
                                                               
                                                               public Point(double x, double y) {
                                                                   this.x = x;
                                                                   this.y = y;
                                                               }
                                                               
                                                               public double getX() { return x; }
                                                               public double getY() { return y; }
                                                               
                                                               public double distanceFrom(Point p) {
                                                                   return Math.abs(x - p.x);
                                                               }
                                                       
                                                               public double[] getPoint() {
                                                                   return new double[]{x, y};
                                                               }
                                                       
                                                               public Point centroidOf(Collection<Point> points) {
                                                                   double sumX = 0;
                                                                   double sumY = 0;
                                                                   for (Point p : points) {
                                                                       sumX += p.x;
                                                                       sumY += p.y;
                                                                   }
                                                                   return new Point(sumX / points.size(), sumY / points.size());
                                                               }
                                                           }
                                                           
                                                           // Create test points with known distances
                                                           List<Point> points = new ArrayList<Point>();
                                                           points.add(new Point(0, 0));  // Will be first center
                                                           points.add(new Point(1, 0));  // Distance 1 from first center
                                                           points.add(new Point(2, 0));  // Distance 2 from first center
                                                           
                                                           // Mock Random to control selections
                                                           Random mockRandom = mock(Random.class);
                                                           // First selection (index 0)
                                                           when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                                           // Second selection (r value in probability calculation)
                                                           when(mockRandom.nextDouble()).thenReturn(0.5);  // 0.5 * sum
                                                           
                                                           // Create clusterer with mocked random
                                                           KMeansPlusPlusClusterer<Point> clusterer = 
                                                               new KMeansPlusPlusClusterer<Point>(mockRandom);
                                                           
                                                           // Call method to test using reflection since chooseInitialCenters is private
                                                           try {
                                                               Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                   "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                               method.setAccessible(true);
                                                               
                                                               @SuppressWarnings("unchecked")
                                                               List<Cluster<Point>> clusters = (List<Cluster<Point>>) method.invoke(
                                                                   clusterer, points, 2, mockRandom);
                                                               
                                                               // Verify results - with sum=0, should select point at (1,0)
                                                               // With sum=1 mutation, would incorrectly select point at (2,0)
                                                               assertEquals(2, clusters.size());
                                                               assertEquals(1.0, clusters.get(1).getCenter().distanceFrom(clusters.get(0).getCenter()), 0.0001);
                                                               
                                                               // Additional verification that the correct point was selected
                                                               assertEquals(1.0, clusters.get(1).getCenter().getX(), 0.0001);
                                                           } catch (Exception e) {
                                                               fail("Reflection failed: " + e.getMessage());
                                                           }
                                                       }

    @Test
                                          public void testChooseInitialCentersSumCalculation() {
                                              // Define simple Point implementation for testing that implements Clusterable
                                              class Point implements org.apache.commons.math.stat.clustering.Clusterable<Point> {
                                                  private final double x;
                                                  private final double y;
                                                  
                                                  public Point(double x, double y) {
                                                      this.x = x;
                                                      this.y = y;
                                                  }
                                                  
                                                  public double getX() { return x; }
                                                  public double getY() { return y; }
                                                  
                                                  public double distanceFrom(Point other) {
                                                      return Math.abs(this.x - other.x);
                                                  }
                                                  
                                                  public Point centroidOf(Collection<Point> points) {
                                                      double sumX = 0;
                                                      double sumY = 0;
                                                      for (Point p : points) {
                                                          sumX += p.x;
                                                          sumY += p.y;
                                                      }
                                                      return new Point(sumX / points.size(), sumY / points.size());
                                                  }
                                              }
                                              
                                              // Setup test data with known distances
                                              List<Point> points = new ArrayList<Point>();
                                              points.add(new Point(0, 0));  // First center
                                              points.add(new Point(1, 0));  // Distance 1 from first center
                                              points.add(new Point(2, 0));  // Distance 2 from first center
                                              
                                              // Mock random behavior - first selection is index 0, then probability selection
                                              Random mockRandom = mock(Random.class);
                                              when(mockRandom.nextInt(anyInt())).thenReturn(0);  // First center selection
                                              when(mockRandom.nextDouble()).thenReturn(0.5);     // Middle probability
                                              
                                              // Create clusterer with mocked random
                                              org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer<Point> clusterer = 
                                                  new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer<Point>(mockRandom);
                                              
                                              // Use reflection to access private chooseInitialCenters method
                                              try {
                                                  Method chooseInitialCenters = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                      .getDeclaredMethod("chooseInitialCenters", Collection.class, int.class, Random.class);
                                                  chooseInitialCenters.setAccessible(true);
                                                  
                                                  @SuppressWarnings("unchecked")
                                                  List<org.apache.commons.math.stat.clustering.Cluster<Point>> result = 
                                                      (List<org.apache.commons.math.stat.clustering.Cluster<Point>>) 
                                                      chooseInitialCenters.invoke(clusterer, points, 2, mockRandom);
                                                  
                                                  // Verify correct number of centers
                                                  assertEquals(2, result.size());
                                                  
                                                  // Verify second center selection - should be point(2,0) with original code
                                                  assertEquals(2.0, result.get(1).getCenter().getX(), 0.0001);
                                              } catch (Exception e) {
                                                  fail("Reflection failed: " + e.getMessage());
                                              }
                                          }

    @Test
                         public void testChooseInitialCentersDetectsNearestClusterMutation() {
                             // Define a simple Point class for testing
                             class Point {
                                 final double x, y;
                                 Point(double x, double y) { this.x = x; this.y = y; }
                                 double distanceFrom(Point p) {
                                     double dx = x - p.x;
                                     double dy = y - p.y;
                                     return Math.sqrt(dx*dx + dy*dy);
                                 }
                                 @Override
                                 public boolean equals(Object o) {
                                     if (!(o instanceof Point)) return false;
                                     Point p = (Point)o;
                                     return x == p.x && y == p.y;
                                 }
                                 @Override
                                 public String toString() { return "(" + x + "," + y + ")"; }
                             }
                             
                             // Define a simple Cluster class for testing
                             class Cluster<T> {
                                 private final T center;
                                 Cluster(T center) { this.center = center; }
                                 T getCenter() { return center; }
                             }
                             
                             // Create test points with known distances
                             List<Point> points = new ArrayList<>();
                             points.add(new Point(0, 0));  // First center
                             points.add(new Point(1, 1));  // Closer to first center
                             points.add(new Point(10, 10)); // Far from first center
                             
                             // Mock random behavior - first select point 0, then select based on distances
                             Random fixedRandom = new Random(12345) {
                                 private int callCount = 0;
                                 @Override
                                 public int nextInt(int bound) {
                                     return 0; // Always pick first point initially
                                 }
                                 @Override
                                 public double nextDouble() {
                                     callCount++;
                                     // On second selection, force selection of point 2 (index 1 after removal)
                                     return callCount == 1 ? 0.6 : super.nextDouble();
                                 }
                             };
                             
                             // Use reflection to access the private static method
                             try {
                                 Class<?> clustererClass = Class.forName("org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer");
                                 Method chooseInitialCenters = clustererClass.getDeclaredMethod("chooseInitialCenters", 
                                     Collection.class, int.class, Random.class);
                                 chooseInitialCenters.setAccessible(true);
                                 
                                 // Test with k=2 clusters
                                 @SuppressWarnings("unchecked")
                                 List<Cluster<Point>> clusters = (List<Cluster<Point>>) chooseInitialCenters.invoke(
                                     null, points, 2, fixedRandom);
                                 
                                 // Verify the second center is point 2 (10,10) since it's farthest from first center
                                 // The mutant would incorrectly use first center as nearest for all points,
                                 // making the selection probabilities incorrect
                                 assertEquals(2, clusters.size());
                                 assertEquals(new Point(10, 10), clusters.get(1).getCenter());
                             } catch (Exception e) {
                                 fail("Failed to access chooseInitialCenters method: " + e.getMessage());
                             }
                         }

    @Test
    public void testChooseInitialCentersWithSumMutation1() {
        // Define TestPoint class as non-static
        class TestPoint {
            private final double x;
            private final double y;
            
            public TestPoint(double x, double y) {
                this.x = x;
                this.y = y;
            }
            
            public double getX() { return x; }
            public double getY() { return y; }
            
            public double distanceFrom(TestPoint p) {
                double dx = x - p.x;
                double dy = y - p.y;
                return Math.sqrt(dx*dx + dy*dy);
            }
        }
        
        // Create test points with very small distances
        List<TestPoint> points = new ArrayList<TestPoint>();
        points.add(new TestPoint(0.0, 0.0));  // point 1
        points.add(new TestPoint(0.001, 0.0));  // point 2 very close to point 1
        points.add(new TestPoint(0.002, 0.0));  // point 3 very close to point 1
        
        // Mock Random to control selections
        Random mockRandom = mock(Random.class);
        // First selection (random first point)
        when(mockRandom.nextInt(anyInt())).thenReturn(0);
        // Second selection (probability based)
        when(mockRandom.nextDouble()).thenReturn(0.0000001); // very small value
        
        try {
            // Use reflection to access the private static method
            Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                "chooseInitialCenters", Collection.class, int.class, Random.class);
            chooseInitialCenters.setAccessible(true);
            
            // Call the method with raw type
            @SuppressWarnings("rawtypes")
            List result = (List) chooseInitialCenters.invoke(null, points, 2, mockRandom);
            
            // Verify results
            assertEquals(2, result.size());
            // Get the first cluster's center using raw type and reflection
            Object cluster = result.get(1);
            Method getCenter = cluster.getClass().getMethod("getCenter");
            Object center = getCenter.invoke(cluster);
            Method getX = center.getClass().getMethod("getX");
            double x = (Double) getX.invoke(center);
            assertEquals(0.001, x, 0.000001);
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }


}
