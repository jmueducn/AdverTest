package gentest.org.apache.commons.math.stat.correlation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.correlation.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.distribution.TDistribution;
import org.apache.commons.math.distribution.TDistributionImpl;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.BlockRealMatrix;
import org.apache.commons.math.stat.regression.SimpleRegression;
 
public class PearsonsCorrelationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                     public void testGetCorrelationPValues_DiagonalElementsZero() throws MathException {
                                                                                         // Setup
                                                                                         RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                         when(mockMatrix.getColumnDimension()).thenReturn(3);
                                                                                         when(mockMatrix.getRowDimension()).thenReturn(10);
                                                                                         when(mockMatrix.getEntry(0, 1)).thenReturn(0.5);
                                                                                         when(mockMatrix.getEntry(0, 2)).thenReturn(-0.3);
                                                                                         when(mockMatrix.getEntry(1, 0)).thenReturn(0.5);
                                                                                         when(mockMatrix.getEntry(1, 2)).thenReturn(0.8);
                                                                                         when(mockMatrix.getEntry(2, 0)).thenReturn(-0.3);
                                                                                         when(mockMatrix.getEntry(2, 1)).thenReturn(0.8);
                                                                                         
                                                                                         PearsonsCorrelation pc = new PearsonsCorrelation(mockMatrix, 10);
                                                                                         
                                                                                         // Execute
                                                                                         RealMatrix result = pc.getCorrelationPValues();
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                                                         assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                                                         assertEquals(0.0, result.getEntry(2, 2), 0.0001);
                                                                                     }

    @Test
                                                                                     public void testGetCorrelationPValues_ValidCorrelations() throws MathException {
                                                                                         // Setup mock matrix with known correlations
                                                                                         RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                         when(mockMatrix.getColumnDimension()).thenReturn(2);
                                                                                         when(mockMatrix.getRowDimension()).thenReturn(10);
                                                                                         when(mockMatrix.getEntry(0, 1)).thenReturn(0.5);
                                                                                         when(mockMatrix.getEntry(1, 0)).thenReturn(0.5);
                                                                                         
                                                                                         PearsonsCorrelation pc = new PearsonsCorrelation(mockMatrix, 10);
                                                                                         
                                                                                         // Execute
                                                                                         RealMatrix result = pc.getCorrelationPValues();
                                                                                         
                                                                                         // Verify - expected values calculated manually for r=0.5, nObs=10
                                                                                         // t = 0.5 * sqrt(8/(1-0.25)) ≈ 1.63299
                                                                                         // p-value ≈ 2 * P(T ≤ -1.63299) ≈ 0.1419 (for df=8)
                                                                                         assertEquals(0.1419, result.getEntry(0, 1), 0.0005);
                                                                                         assertEquals(0.1419, result.getEntry(1, 0), 0.0005);
                                                                                     }

    @Test
                                                                                     public void testGetCorrelationPValues_PerfectCorrelation() throws MathException {
                                                                                         // Setup mock matrix with perfect correlation
                                                                                         RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                         when(mockMatrix.getColumnDimension()).thenReturn(2);
                                                                                         when(mockMatrix.getRowDimension()).thenReturn(10);
                                                                                         when(mockMatrix.getEntry(0, 1)).thenReturn(1.0);
                                                                                         when(mockMatrix.getEntry(1, 0)).thenReturn(1.0);
                                                                                         
                                                                                         PearsonsCorrelation pc = new PearsonsCorrelation(mockMatrix, 10);
                                                                                         
                                                                                         // Execute
                                                                                         RealMatrix result = pc.getCorrelationPValues();
                                                                                         
                                                                                         // Verify - perfect correlation should give p-value of 0
                                                                                         assertEquals(0.0, result.getEntry(0, 1), 0.0001);
                                                                                         assertEquals(0.0, result.getEntry(1, 0), 0.0001);
                                                                                     }

    @Test
                                                                                     public void testGetCorrelationPValues_NoCorrelation() throws MathException {
                                                                                         // Setup mock matrix with no correlation
                                                                                         RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                         when(mockMatrix.getColumnDimension()).thenReturn(2);
                                                                                         when(mockMatrix.getRowDimension()).thenReturn(10);
                                                                                         when(mockMatrix.getEntry(0, 1)).thenReturn(0.0);
                                                                                         when(mockMatrix.getEntry(1, 0)).thenReturn(0.0);
                                                                                         
                                                                                         PearsonsCorrelation pc = new PearsonsCorrelation(mockMatrix, 10);
                                                                                         
                                                                                         // Execute
                                                                                         RealMatrix result = pc.getCorrelationPValues();
                                                                                         
                                                                                         // Verify - no correlation should give maximum p-value (1.0)
                                                                                         assertEquals(1.0, result.getEntry(0, 1), 0.0001);
                                                                                         assertEquals(1.0, result.getEntry(1, 0), 0.0001);
                                                                                     }

    @Test
                                                                                     public void testGetCorrelationPValues_EdgeCaseMinimumObservations() throws MathException {
                                                                                         // Setup - minimum number of observations (nObs = 3)
                                                                                         RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                         when(mockMatrix.getColumnDimension()).thenReturn(2);
                                                                                         when(mockMatrix.getRowDimension()).thenReturn(3);
                                                                                         when(mockMatrix.getEntry(0, 1)).thenReturn(0.5);
                                                                                         when(mockMatrix.getEntry(1, 0)).thenReturn(0.5);
                                                                                         
                                                                                         PearsonsCorrelation pc = new PearsonsCorrelation(mockMatrix, 3);
                                                                                         
                                                                                         // Execute
                                                                                         RealMatrix result = pc.getCorrelationPValues();
                                                                                         
                                                                                         // Verify - with nObs=3, df=1
                                                                                         // t = 0.5 * sqrt(1/(1-0.25)) ≈ 0.57735
                                                                                         // p-value ≈ 2 * P(T ≤ -0.57735) ≈ 0.6694 (for df=1)
                                                                                         assertEquals(0.6694, result.getEntry(0, 1), 0.0005);
                                                                                     }

    @Test
                                                                                     public void testGetCorrelationPValues_WithActualMatrix() throws MathException {
                                                                                         // Setup with actual matrix data
                                                                                         double[][] data = {
                                                                                             {1.0, 0.5, -0.3},
                                                                                             {0.5, 1.0, 0.8},
                                                                                             {-0.3, 0.8, 1.0}
                                                                                         };
                                                                                         BlockRealMatrix matrix = new BlockRealMatrix(data);
                                                                                         PearsonsCorrelation pc = new PearsonsCorrelation(matrix, 100);
                                                                                         
                                                                                         // Execute
                                                                                         RealMatrix result = pc.getCorrelationPValues();
                                                                                         
                                                                                         // Verify diagonal is zero
                                                                                         assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                                                         assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                                                         assertEquals(0.0, result.getEntry(2, 2), 0.0001);
                                                                                         
                                                                                         // Verify symmetry
                                                                                         assertEquals(result.getEntry(0, 1), result.getEntry(1, 0), 0.0001);
                                                                                         assertEquals(result.getEntry(0, 2), result.getEntry(2, 0), 0.0001);
                                                                                         assertEquals(result.getEntry(1, 2), result.getEntry(2, 1), 0.0001);
                                                                                         
                                                                                         // Verify p-values are in valid range [0, 1]
                                                                                         assertTrue(result.getEntry(0, 1) >= 0 && result.getEntry(0, 1) <= 1);
                                                                                         assertTrue(result.getEntry(0, 2) >= 0 && result.getEntry(0, 2) <= 1);
                                                                                         assertTrue(result.getEntry(1, 2) >= 0 && result.getEntry(1, 2) <= 1);
                                                                                     }

    @Test
                                                    public void testGetCorrelationPValuesDetectsIndexSwapMutant() throws MathException {
                                                        // Create a non-symmetric test matrix (though correlation matrices should be symmetric)
                                                        // This is just for testing the mutant detection
                                                        double[][] testData = {
                                                            {1.0, 0.5, 0.3},
                                                            {0.7, 1.0, 0.2},  // Note: testData[1][0] != testData[0][1]
                                                            {0.4, 0.1, 1.0}   // testData[2][0] != testData[0][2], etc.
                                                        };
                                                        RealMatrix matrix = new BlockRealMatrix(testData);
                                                        
                                                        // Create PearsonsCorrelation with the test matrix
                                                        PearsonsCorrelation pc = new PearsonsCorrelation(matrix);
                                                        
                                                        // Get p-values matrix
                                                        RealMatrix pValues = pc.getCorrelationPValues();
                                                        
                                                        // Verify that the p-values were calculated using the correct matrix entries
                                                        // Check some asymmetric pairs to ensure indices weren't swapped
                                                        
                                                        // For (0,1) - should use 0.5 (testData[0][1])
                                                        double r01 = testData[0][1];
                                                        double expectedT01 = Math.abs(r01 * Math.sqrt((testData.length - 2)/(1 - r01 * r01)));
                                                        double expectedP01 = 2 * new TDistributionImpl(testData.length - 2).cumulativeProbability(-expectedT01);
                                                        assertEquals(expectedP01, pValues.getEntry(0, 1), 1e-10);
                                                        
                                                        // For (1,0) - should use 0.7 (testData[1][0])
                                                        double r10 = testData[1][0];
                                                        double expectedT10 = Math.abs(r10 * Math.sqrt((testData.length - 2)/(1 - r10 * r10)));
                                                        double expectedP10 = 2 * new TDistributionImpl(testData.length - 2).cumulativeProbability(-expectedT10);
                                                        assertEquals(expectedP10, pValues.getEntry(1, 0), 1e-10);
                                                        
                                                        // The mutant would calculate both using the same r value (swapped indices)
                                                        // So this test would fail if the mutant is present
                                                    }

    @Test
                                               public void testGetCorrelationPValuesDetectsMutant() throws MathException {
                                                   // Setup test data where mutation would be visible (small sample size)
                                                   double[][] corrData = {
                                                       {1.0, 0.5, 0.3},
                                                       {0.5, 1.0, -0.2},
                                                       {0.3, -0.2, 1.0}
                                                   };
                                                   RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                                   int nObs = 5;  // Small sample size to amplify the effect of the mutation
                                                   
                                                   // Create test instance
                                                   PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                                                   
                                                   // Calculate expected values manually with correct formula (nObs-2)
                                                   TDistribution tDist = new TDistributionImpl(nObs - 2);
                                                   double r = 0.5;  // Test one of the correlation values
                                                   double expectedT = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                                                   double expectedP = 2 * tDist.cumulativeProbability(-expectedT);
                                                   
                                                   // Get actual values from method
                                                   RealMatrix pValues = pc.getCorrelationPValues();
                                                   double actualP = pValues.getEntry(0, 1);
                                                   
                                                   // Assert with delta to account for floating point precision
                                                   // The difference should be significant enough to detect the mutant
                                                   assertEquals(expectedP, actualP, 0.0001);
                                                   
                                                   // Also test another value to be thorough
                                                   r = -0.2;
                                                   expectedT = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                                                   expectedP = 2 * tDist.cumulativeProbability(-expectedT);
                                                   actualP = pValues.getEntry(1, 2);
                                                   assertEquals(expectedP, actualP, 0.0001);
                                               }

    @Test
                                      public void testGetCorrelationPValuesDetectsDenominatorMutation() throws MathException {
                                          // Setup test data that will expose the mutation
                                          double[][] corrData = {
                                              {1.0, 0.5, 0.8},
                                              {0.5, 1.0, 0.3},
                                              {0.8, 0.3, 1.0}
                                          };
                                          int numObservations = 10;  // nObs-2 = 8 degrees of freedom
                                          
                                          // Create mock t-distribution that just passes through the input
                                          TDistribution tDistribution = mock(TDistribution.class);
                                          try {
                                              when(tDistribution.cumulativeProbability(anyDouble())).thenAnswer(inv -> {
                                                  double t = inv.getArgument(0);
                                                  return t; // Simple mock that returns input value for testing
                                              });
                                          } catch (MathException e) {
                                              fail("Mock setup failed with MathException");
                                          }
                                          
                                          // Create test instance
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(new BlockRealMatrix(corrData), numObservations);
                                          
                                          // Use reflection to inject our mock tDistribution
                                          try {
                                              Field tDistField = PearsonsCorrelation.class.getDeclaredField("tDistribution");
                                              tDistField.setAccessible(true);
                                              tDistField.set(pearsonsCorrelation, tDistribution);
                                          } catch (Exception e) {
                                              fail("Failed to inject mock tDistribution via reflection");
                                          }
                                          
                                          // Calculate expected and actual values for a specific correlation
                                          double r = 0.5;
                                          double expectedT = Math.abs(r * Math.sqrt((numObservations - 2)/(1 - r * r)));
                                          double mutatedT = Math.abs(r * Math.sqrt((numObservations - 2)/(2 - r * r)));
                                          
                                          // Verify they are different (which they should be for r != 0)
                                          assertNotEquals(expectedT, mutatedT, 0.0001);
                                          
                                          // Get the p-values matrix
                                          RealMatrix pValues = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Check that the calculation uses the correct formula by verifying a specific value
                                          // For r=0.5, the correct t-value should be ~1.63299, mutant would be ~1.1547
                                          double actualPValue = pValues.getEntry(0, 1);
                                          double expectedPValue = 2 * expectedT; // Because our mock returns t as-is
                                          
                                          // This assertion will fail if the mutant is present
                                          assertEquals("P-value calculation uses incorrect denominator in t-statistic",
                                              expectedPValue, actualPValue, 0.0001);
                                      }

    @Test
                                 public void testGetCorrelationPValuesDetectsDenominatorMutation1() throws MathException {
                                     // Setup test data
                                     int nObs = 10; // Enough degrees of freedom for meaningful test
                                     double[][] corrData = {
                                         {1.0, 0.5, -0.3},
                                         {0.5, 1.0, 0.8},
                                         {-0.3, 0.8, 1.0}
                                     };
                                     RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                     
                                     // Create PearsonsCorrelation instance
                                     PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                                     
                                     // Calculate p-values
                                     RealMatrix pValues = pc.getCorrelationPValues();
                                     
                                     // Test non-diagonal elements
                                     // For r=0.5, expected t = 0.5*sqrt(8/(1-0.25)) ≈ 1.632993
                                     // Expected p-value ≈ 2*P(T ≤ -1.632993) ≈ 0.141047
                                     assertEquals(0.141047, pValues.getEntry(0, 1), 0.0001);
                                     
                                     // For r=-0.3, expected t = 0.3*sqrt(8/(1-0.09)) ≈ 0.888819
                                     // Expected p-value ≈ 2*P(T ≤ -0.888819) ≈ 0.3996
                                     assertEquals(0.3996, pValues.getEntry(0, 2), 0.0001);
                                     
                                     // For r=0.8, expected t = 0.8*sqrt(8/(1-0.64)) ≈ 3.651484
                                     // Expected p-value ≈ 2*P(T ≤ -3.651484) ≈ 0.0062
                                     assertEquals(0.0062, pValues.getEntry(1, 2), 0.0001);
                                     
                                     // Test diagonal elements are zero
                                     assertEquals(0.0, pValues.getEntry(0, 0), 0.0);
                                     assertEquals(0.0, pValues.getEntry(1, 1), 0.0);
                                     assertEquals(0.0, pValues.getEntry(2, 2), 0.0);
                                 }

    @Test
                            public void testGetCorrelationPValuesDetectsDenominatorMutation2() throws MathException {
                                // Setup test data
                                double[][] corrData = {{1.0, 0.5}, {0.5, 1.0}}; // 2x2 correlation matrix
                                RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                int nObs = 10; // Sample size
                                
                                // Create test instance
                                PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                                
                                // Calculate expected t-value manually with correct formula
                                double r = 0.5;
                                double expectedT = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                                
                                // Mock t-distribution to verify correct t-value is used
                                TDistribution tDistribution = mock(TDistribution.class);
                                when(tDistribution.cumulativeProbability(anyDouble())).thenReturn(0.123); // dummy value
                                
                                // Replace t-distribution in the class (requires reflection or package-private access)
                                // This part may need adjustment based on actual class structure
                                try {
                                    Field field = PearsonsCorrelation.class.getDeclaredField("tDistribution");
                                    field.setAccessible(true);
                                    field.set(pc, tDistribution);
                                } catch (Exception e) {
                                    fail("Failed to set t-distribution mock");
                                }
                                
                                // Call method
                                RealMatrix result = pc.getCorrelationPValues();
                                
                                // Verify mock interaction - check correct t-value was used
                                verify(tDistribution).cumulativeProbability(-expectedT);
                                
                                // Additional verification - check p-value calculation
                                double expectedPValue = 2 * 0.123; // Based on our mock return
                                assertEquals(expectedPValue, result.getEntry(0, 1), 1e-10);
                                assertEquals(expectedPValue, result.getEntry(1, 0), 1e-10);
                            }

    @Test
                       public void testGetCorrelationPValues_DetectsTwoTailedMutation() throws MathException {
                           // Setup test data
                           double[][] corrData = {
                               {1.0, 0.5, -0.3},
                               {0.5, 1.0, 0.8},
                               {-0.3, 0.8, 1.0}
                           };
                           RealMatrix corrMatrix = new BlockRealMatrix(corrData);
                           int numObservations = 10; // nObs-2 = 8 degrees of freedom
                           
                           // Create test instance
                           PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix, numObservations);
                           
                           // Get p-values matrix
                           RealMatrix pValues = pc.getCorrelationPValues();
                           
                           // Verify diagonal elements are 0
                           assertEquals(0.0, pValues.getEntry(0, 0), 1e-10);
                           assertEquals(0.0, pValues.getEntry(1, 1), 1e-10);
                           assertEquals(0.0, pValues.getEntry(2, 2), 1e-10);
                           
                           // Verify off-diagonal elements are two-tailed
                           // For r=0.5, t=1.632993, two-tailed p should be ~0.1407
                           double expectedP = 0.1407;
                           assertEquals(expectedP, pValues.getEntry(0, 1), 0.001);
                           assertEquals(expectedP, pValues.getEntry(1, 0), 0.001);
                           
                           // For r=-0.3, t=0.92582, two-tailed p should be ~0.3837
                           expectedP = 0.3837;
                           assertEquals(expectedP, pValues.getEntry(0, 2), 0.001);
                           assertEquals(expectedP, pValues.getEntry(2, 0), 0.001);
                           
                           // For r=0.8, t=3.5777, two-tailed p should be ~0.0076
                           expectedP = 0.0076;
                           assertEquals(expectedP, pValues.getEntry(1, 2), 0.001);
                           assertEquals(expectedP, pValues.getEntry(2, 1), 0.001);
                           
                           // The mutant would produce values exactly half of these
                           // so these assertions would fail if the mutant is present
                       }

    @Test
              public void testGetCorrelationPValues_DetectsTwoTailedMutation1() throws MathException {
                  // Setup test data
                  int nObs = 10; // 10 observations
                  double[][] corrData = {{1.0, 0.5}, {0.5, 1.0}}; // 2x2 correlation matrix
                  RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                  
                  // Mock tDistribution to return predictable values
                  TDistribution tDistribution = mock(TDistribution.class);
                  // For r=0.5, nObs=10: t = 0.5*sqrt(8)/sqrt(1-0.25) ≈ 1.63299
                  // Mock cumulativeProbability(-1.63299) to return 0.1 for testing
                  when(tDistribution.cumulativeProbability(-1.63299)).thenReturn(0.1);
                  
                  // Create PearsonsCorrelation instance
                  PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                  
                  // Use reflection to inject our mock tDistribution
                  try {
                      Field tDistField = PearsonsCorrelation.class.getDeclaredField("tDistribution");
                      tDistField.setAccessible(true);
                      tDistField.set(pc, tDistribution);
                  } catch (Exception e) {
                      fail("Failed to inject mock tDistribution via reflection");
                  }
                  
                  // Call method under test
                  RealMatrix pValues = pc.getCorrelationPValues();
                  
                  // Verify results
                  // Diagonal should be 0
                  assertEquals(0.0, pValues.getEntry(0, 0), 1e-10);
                  assertEquals(0.0, pValues.getEntry(1, 1), 1e-10);
                  
                  // Off-diagonal should be 2 * 0.1 = 0.2 (two-tailed p-value)
                  assertEquals(0.2, pValues.getEntry(0, 1), 1e-10);
                  assertEquals(0.2, pValues.getEntry(1, 0), 1e-10);
                  
                  // Verify tDistribution was called with expected arguments
                  verify(tDistribution).cumulativeProbability(-1.63299);
              }

    @Test
         public void testGetCorrelationPValuesShouldReturnSymmetricMatrix() throws MathException {
             // Setup test data
             double[][] data = {
                 {1.0, 0.5, 0.3},
                 {0.5, 1.0, 0.2},
                 {0.3, 0.2, 1.0}
             };
             RealMatrix correlationMatrix = new BlockRealMatrix(data);
             int nObs = 100;  // Sufficiently large sample size
             
             // Create test instance
             PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
             
             // Get p-values matrix
             RealMatrix pValues = pc.getCorrelationPValues();
             
             // Verify matrix is symmetric
             int nVars = pValues.getRowDimension();
             for (int i = 0; i < nVars; i++) {
                 for (int j = i+1; j < nVars; j++) {
                     assertEquals("Matrix should be symmetric at ("+i+","+j+") vs ("+j+","+i+")",
                                  pValues.getEntry(i, j), 
                                  pValues.getEntry(j, i), 
                                  1e-10);
                 }
             }
             
             // Verify diagonal is zero
             for (int i = 0; i < nVars; i++) {
                 assertEquals(0.0, pValues.getEntry(i, i), 1e-10);
             }
         }

    @Test
    public void testGetCorrelationPValuesDetectsMutant1() {
        // Setup test data
        int nObs = 10; // 10 observations -> 8 degrees of freedom
        double[][] corrData = {
            {1.0, 0.9, 0.8},
            {0.9, 1.0, 0.7},
            {0.8, 0.7, 1.0}
        };
        RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
        
        // Mock TDistribution to return predictable values
        TDistribution tDistribution = mock(TDistribution.class);
        try {
            // For r=0.9, t ≈ 0.9*sqrt(8)/sqrt(1-0.81) ≈ 5.6568
            when(tDistribution.cumulativeProbability(-5.6568)).thenReturn(0.0002);
            when(tDistribution.cumulativeProbability(-2.8284)).thenReturn(0.011); // t/2 case
        } catch (MathException e) {
            // Mock won't actually throw this, but we need to handle it
        }
        
        // Create test instance using reflection to inject our mock and test data
        PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix);
        
        try {
            // Inject our mock TDistribution and nObs
            Field nObsField = PearsonsCorrelation.class.getDeclaredField("nObs");
            nObsField.setAccessible(true);
            nObsField.set(pc, nObs);
            
            // Replace TDistribution implementation with our mock
            Field tDistField = PearsonsCorrelation.class.getDeclaredField("tDistribution");
            tDistField.setAccessible(true);
            tDistField.set(pc, tDistribution);
            
            // Calculate expected p-value (2*0.0002 = 0.0004)
            double expectedPValue = 0.0004;
            
            // Get actual result
            RealMatrix result = pc.getCorrelationPValues();
            double actualPValue = result.getEntry(0, 1);
            
            // Assert - this will fail with the mutant (which would return 2*0.011 = 0.022)
            assertEquals("P-value calculation is incorrect", expectedPValue, actualPValue, 0.0001);
        } catch (Exception e) {
            fail("Test failed due to reflection error: " + e.getMessage());
        }
    }


}
