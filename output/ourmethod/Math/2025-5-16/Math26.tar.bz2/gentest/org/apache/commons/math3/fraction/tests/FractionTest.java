package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                       public void testConstructor_ZeroValue() {
                           Fraction fraction = new Fraction(0.0);
                           assertEquals(0, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructor_IntegerValue() {
                           Fraction fraction = new Fraction(5.0);
                           assertEquals(5, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructor_SimpleFraction() {
                           Fraction fraction = new Fraction(0.5);
                           assertEquals(1, fraction.getNumerator());
                           assertEquals(2, fraction.getDenominator());
                       }

 @Test
                       public void testConstructor_RecurringDecimal() {
                           Fraction fraction = new Fraction(0.3333333333);
                           assertEquals(1, fraction.getNumerator());
                           assertEquals(3, fraction.getDenominator());
                       }

 @Test
                       public void testConstructor_NegativeValue() {
                           Fraction fraction = new Fraction(-0.75);
                           assertEquals(-3, fraction.getNumerator());
                           assertEquals(4, fraction.getDenominator());
                       }

 @Test
                       public void testConstructor_PrecisionLimit() {
                           // Test a value that requires precision near the constructor's epsilon (1.0e-5)
                           Fraction fraction = new Fraction(0.00001);
                           assertEquals(1, fraction.getNumerator());
                           assertTrue(fraction.getDenominator() > 1); // Should find a reasonable approximation
                       }

 @Test
                       public void testConstructor_CommonFractions() {
                           // Test common fractions that have constants defined in the class
                           Fraction oneThird = new Fraction(1.0/3.0);
                           assertEquals(Fraction.ONE_THIRD.getNumerator(), oneThird.getNumerator());
                           assertEquals(Fraction.ONE_THIRD.getDenominator(), oneThird.getDenominator());
                   
                           Fraction threeQuarters = new Fraction(0.75);
                           assertEquals(Fraction.THREE_QUARTERS.getNumerator(), threeQuarters.getNumerator());
                           assertEquals(Fraction.THREE_QUARTERS.getDenominator(), threeQuarters.getDenominator());
                       }

 @Test
                       public void testConstructor_NaN() {
                           thrown.expect(IllegalArgumentException.class);
                           new Fraction(Double.NaN);
                       }

 @Test
                       public void testConstructor_PositiveInfinity() {
                           thrown.expect(IllegalArgumentException.class);
                           new Fraction(Double.POSITIVE_INFINITY);
                       }

 @Test
                       public void testConstructor_NegativeInfinity() {
                           thrown.expect(IllegalArgumentException.class);
                           new Fraction(Double.NEGATIVE_INFINITY);
                       }

 @Test
                       public void testConstructor_VerySmallValue() {
                           Fraction fraction = new Fraction(1.0e-10);
                           // Shouldn't throw exception, but might return 0/1 or a very small fraction
                           assertTrue(Math.abs(fraction.doubleValue() - 1.0e-10) < 1.0e-5);
                       }

 @Test
                       public void testConstructor_VeryLargeValue() {
                           Fraction fraction = new Fraction(1.0e10);
                           assertEquals(10000000000L, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructor_EquivalentToStaticConstants() {
                           assertEquals(Fraction.ONE, new Fraction(1.0));
                           assertEquals(Fraction.ZERO, new Fraction(0.0));
                           assertEquals(Fraction.MINUS_ONE, new Fraction(-1.0));
                           assertEquals(Fraction.ONE_HALF, new Fraction(0.5));
                       }

 @Test
                       public void testConstructor_ExactValues() {
                           // Test exact values that can be precisely represented as fractions
                           Fraction half = new Fraction(0.5, 0.00001, 100);
                           assertEquals(1, half.getNumerator());
                           assertEquals(2, half.getDenominator());
                   
                           Fraction third = new Fraction(1.0/3.0, 0.00001, 100);
                           assertEquals(1, third.getNumerator());
                           assertEquals(3, third.getDenominator());
                   
                           Fraction quarter = new Fraction(0.25, 0.00001, 100);
                           assertEquals(1, quarter.getNumerator());
                           assertEquals(4, quarter.getDenominator());
                       }

 @Test
                       public void testConstructor_ApproximateValues() {
                           // Test values that need approximation
                           Fraction piApprox = new Fraction(Math.PI, 0.0001, 100);
                           assertTrue(Math.abs(Math.PI - piApprox.doubleValue()) <= 0.0001);
                   
                           Fraction eApprox = new Fraction(Math.E, 0.00001, 100);
                           assertTrue(Math.abs(Math.E - eApprox.doubleValue()) <= 0.00001);
                       }

 @Test
                       public void testConstructor_EdgeCases() {
                           // Test zero
                           Fraction zero = new Fraction(0.0, 0.00001, 100);
                           assertEquals(0, zero.getNumerator());
                           assertEquals(1, zero.getDenominator());
                   
                           // Test one
                           Fraction one = new Fraction(1.0, 0.00001, 100);
                           assertEquals(1, one.getNumerator());
                           assertEquals(1, one.getDenominator());
                   
                           // Test negative value
                           Fraction negative = new Fraction(-0.5, 0.00001, 100);
                           assertEquals(-1, negative.getNumerator());
                           assertEquals(2, negative.getDenominator());
                       }

 @Test
                       public void testConstructor_LargeValues() {
                           // Test large values
                           Fraction large = new Fraction(123456.789, 0.001, 1000);
                           assertTrue(Math.abs(123456.789 - large.doubleValue()) <= 0.001);
                   
                           Fraction small = new Fraction(0.000123456, 0.0000001, 1000);
                           assertTrue(Math.abs(0.000123456 - small.doubleValue()) <= 0.0000001);
                       }

 @Test
                       public void testConstructor_WithDifferentEpsilon() {
                           // Test with different epsilon values
                           Fraction looseApprox = new Fraction(0.333333, 0.1, 100);
                           assertTrue(Math.abs(0.333333 - looseApprox.doubleValue()) <= 0.1);
                   
                           Fraction tightApprox = new Fraction(0.333333, 0.000001, 100);
                           assertTrue(Math.abs(0.333333 - tightApprox.doubleValue()) <= 0.000001);
                       }

 @Test
                       public void testConstructor_WithDifferentMaxIterations() {
                           // Test with different max iteration values
                           Fraction fewIterations = new Fraction(0.123456, 0.0001, 5);
                           assertTrue(Math.abs(0.123456 - fewIterations.doubleValue()) <= 0.0001);
                   
                           Fraction manyIterations = new Fraction(0.123456, 0.0000001, 1000);
                           assertTrue(Math.abs(0.123456 - manyIterations.doubleValue()) <= 0.0000001);
                       }

 @Test
                       public void testConstructor_InvalidMaxIterations() {
                           thrown.expect(IllegalArgumentException.class);
                           thrown.expectMessage("maximal count of iterations must be positive");
                           new Fraction(0.5, 0.0001, 0);
                       }

 @Test
                       public void testConstructor_InvalidEpsilon() {
                           thrown.expect(IllegalArgumentException.class);
                           thrown.expectMessage("epsilon must be positive");
                           new Fraction(0.5, 0.0, 100);
                       }

 @Test
                       public void testConstructor_NaNValue() {
                           thrown.expect(IllegalArgumentException.class);
                           thrown.expectMessage("value must be finite");
                           new Fraction(Double.NaN, 0.0001, 100);
                       }

 @Test
                       public void testConstructor_InfiniteValue() {
                           thrown.expect(IllegalArgumentException.class);
                           thrown.expectMessage("value must be finite");
                           new Fraction(Double.POSITIVE_INFINITY, 0.0001, 100);
                       }

 @Test
                       public void testConstructor_SimpleFractions() {
                           // Test simple fractions that can be exactly represented
                           Fraction half = new Fraction(0.5, 100);
                           assertEquals(1, half.getNumerator());
                           assertEquals(2, half.getDenominator());
                   
                           Fraction third = new Fraction(1.0/3, 100);
                           assertEquals(1, third.getNumerator());
                           assertEquals(3, third.getDenominator());
                   
                           Fraction twoThirds = new Fraction(2.0/3, 100);
                           assertEquals(2, twoThirds.getNumerator());
                           assertEquals(3, twoThirds.getDenominator());
                       }

 @Test
                       public void testConstructor_WholeNumbers() {
                           // Test whole numbers
                           Fraction five = new Fraction(5.0, 100);
                           assertEquals(5, five.getNumerator());
                           assertEquals(1, five.getDenominator());
                   
                           Fraction zero = new Fraction(0.0, 100);
                           assertEquals(0, zero.getNumerator());
                           assertEquals(1, zero.getDenominator());
                   
                           Fraction negativeTwo = new Fraction(-2.0, 100);
                           assertEquals(-2, negativeTwo.getNumerator());
                           assertEquals(1, negativeTwo.getDenominator());
                       }

 @Test
                       public void testConstructor_ApproximateFractions() {
                           // Test approximations with limited denominator
                           Fraction piApprox = new Fraction(Math.PI, 7);
                           assertEquals(22, piApprox.getNumerator());
                           assertEquals(7, piApprox.getDenominator());
                   
                           Fraction piBetterApprox = new Fraction(Math.PI, 113);
                           assertEquals(355, piBetterApprox.getNumerator());
                           assertEquals(113, piBetterApprox.getDenominator());
                   
                           Fraction eApprox = new Fraction(Math.E, 7);
                           assertEquals(19, eApprox.getNumerator());
                           assertEquals(7, eApprox.getDenominator());
                       }

 @Test
                       public void testConstructor_EdgeCases1() {
                           // Test very small denominator limit
                           Fraction smallDenominator = new Fraction(0.333, 1);
                           assertEquals(0, smallDenominator.getNumerator());
                           assertEquals(1, smallDenominator.getDenominator());
                   
                           // Test with maxDenominator equal to 0 (should use default 100)
                           Fraction defaultMax = new Fraction(0.12345, 0);
                           assertTrue(defaultMax.getDenominator() <= 100);
                   
                           // Test very small value
                           Fraction tinyValue = new Fraction(0.0001, 10000);
                           assertTrue(tinyValue.doubleValue() > 0);
                       }

 @Test
                       public void testConstructor_NegativeValues() {
                           // Test negative fractions
                           Fraction negativeHalf = new Fraction(-0.5, 100);
                           assertEquals(-1, negativeHalf.getNumerator());
                           assertEquals(2, negativeHalf.getDenominator());
                   
                           Fraction negativeApprox = new Fraction(-Math.PI, 7);
                           assertEquals(-22, negativeApprox.getNumerator());
                           assertEquals(7, negativeApprox.getDenominator());
                       }

 @Test
                       public void testConstructor_ExtremeValues() {
                           // Test very large values
                           Fraction largeValue = new Fraction(1.0e10, 100);
                           assertEquals((int)1.0e10, largeValue.getNumerator());
                           assertEquals(1, largeValue.getDenominator());
                   
                           // Test very small denominator
                           Fraction smallFraction = new Fraction(1.0/10000, 100);
                           assertEquals(1, smallFraction.getNumerator());
                           assertEquals(100, smallFraction.getDenominator());
                       }

 @Test
                       public void testConstructor_InvalidMaxDenominator() {
                           thrown.expect(IllegalArgumentException.class);
                           new Fraction(0.5, -1);
                       }

 @Test
                       public void testConstructor_Infinity() {
                           thrown.expect(IllegalArgumentException.class);
                           new Fraction(Double.POSITIVE_INFINITY, 100);
                       }

 @Test
                       public void testConstructor_NaN1() {
                           thrown.expect(IllegalArgumentException.class);
                           new Fraction(Double.NaN, 100);
                       }

 @Test
                       public void testConstructor_CompareWithStaticConstants() {
                           // Test that constructor matches static constants
                           Fraction half = new Fraction(0.5, 100);
                           assertEquals(Fraction.ONE_HALF.getNumerator(), half.getNumerator());
                           assertEquals(Fraction.ONE_HALF.getDenominator(), half.getDenominator());
                   
                           Fraction third = new Fraction(1.0/3, 100);
                           assertEquals(Fraction.ONE_THIRD.getNumerator(), third.getNumerator());
                           assertEquals(Fraction.ONE_THIRD.getDenominator(), third.getDenominator());
                       }

 @Test
                       public void testConstructorWithNumerator_PositiveValue() {
                           Fraction fraction = new Fraction(3);
                           assertEquals(3, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructorWithNumerator_NegativeValue() {
                           Fraction fraction = new Fraction(-5);
                           assertEquals(-5, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructorWithNumerator_ZeroValue() {
                           Fraction fraction = new Fraction(0);
                           assertEquals(0, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructorWithNumerator_MaxIntegerValue() {
                           Fraction fraction = new Fraction(Integer.MAX_VALUE);
                           assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructorWithNumerator_MinIntegerValue() {
                           Fraction fraction = new Fraction(Integer.MIN_VALUE);
                           assertEquals(Integer.MIN_VALUE, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructorWithNumerator_EqualsOne() {
                           Fraction fraction = new Fraction(1);
                           assertEquals(1, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                           assertEquals(Fraction.ONE, fraction); // Assuming equals() is properly implemented
                       }

 @Test
                       public void testConstructorWithNumerator_EqualsTwo() {
                           Fraction fraction = new Fraction(2);
                           assertEquals(2, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                           assertEquals(Fraction.TWO, fraction);
                       }

 @Test
                       public void testConstructorWithNumerator_EqualsMinusOne() {
                           Fraction fraction = new Fraction(-1);
                           assertEquals(-1, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                           assertEquals(Fraction.MINUS_ONE, fraction);
                       }

 @Test
                       public void testConstructorWithNumerator_ResultingFractionIsReduced() {
                           // Even though we're passing an int, the constructor might reduce it
                           // This test verifies that no reduction happens when denominator is 1
                           Fraction fraction = new Fraction(4);
                           assertEquals(4, fraction.getNumerator());
                           assertEquals(1, fraction.getDenominator());
                       }

 @Test
                       public void testConstructorWithNumerator_VerifyDoubleValue() {
                           Fraction fraction = new Fraction(3);
                           assertEquals(3.0, fraction.doubleValue(), 0.0001);
                       }

 @Test
                       public void testConstructorWithNumerator_VerifyFloatValue() {
                           Fraction fraction = new Fraction(3);
                           assertEquals(3.0f, fraction.floatValue(), 0.0001f);
                       }

 @Test
                       public void testConstructorWithNumerator_VerifyIntValue() {
                           Fraction fraction = new Fraction(3);
                           assertEquals(3, fraction.intValue());
                       }

 @Test
                       public void testConstructorWithNumerator_VerifyLongValue() {
                           Fraction fraction = new Fraction(3);
                           assertEquals(3L, fraction.longValue());
                       }

 @Test
                       public void testConstructor_NormalizesNegativeDenominator() {
                           Fraction f = new Fraction(1, -2);
                           assertEquals(-1, f.getNumerator());
                           assertEquals(2, f.getDenominator());
                       }

 @Test
                       public void testConstructor_SimplifiesFraction() {
                           Fraction f = new Fraction(2, 4);
                           assertEquals(1, f.getNumerator());
                           assertEquals(2, f.getDenominator());
                       }

 @Test
                       public void testConstructor_HandlesNegativeNumeratorAndDenominator() {
                           Fraction f = new Fraction(-2, -3);
                           assertEquals(2, f.getNumerator());
                           assertEquals(3, f.getDenominator());
                       }

 @Test
                       public void testConstructor_ZeroNumerator() {
                           Fraction f = new Fraction(0, 5);
                           assertEquals(0, f.getNumerator());
                           assertEquals(1, f.getDenominator()); // Should be simplified to 0/1
                       }

 @Test
                       public void testConstructor_AlreadySimplified() {
                           Fraction f = new Fraction(3, 5);
                           assertEquals(3, f.getNumerator());
                           assertEquals(5, f.getDenominator());
                       }

 @Test
                       public void testConstructor_LargeValues1() {
                           Fraction f = new Fraction(123456, 789012);
                           int gcd = ArithmeticUtils.gcd(123456, 789012);
                           assertEquals(123456/gcd, f.getNumerator());
                           assertEquals(789012/gcd, f.getDenominator());
                       }

 @Test
                       public void testConstructor_OneAsDenominator() {
                           Fraction f = new Fraction(5, 1);
                           assertEquals(5, f.getNumerator());
                           assertEquals(1, f.getDenominator());
                       }

 @Test
                       public void testConstructor_NegativeNumeratorPositiveDenominator() {
                           Fraction f = new Fraction(-3, 4);
                           assertEquals(-3, f.getNumerator());
                           assertEquals(4, f.getDenominator());
                       }

 @Test
               public void testIntegerValueExact() throws Exception {
                   // Get the private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   
                   // Create fraction using the private constructor
                   Fraction f = constructor.newInstance(5.0, 0.00001, 100, 10);
                   
                   assertEquals(5, f.getNumerator());
                   assertEquals(1, f.getDenominator());
               }

 @Test
               public void testSimpleFractionExact() throws Exception {
                   // Get the private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   
                   // Create fraction using the private constructor
                   Fraction f = constructor.newInstance(0.5, 0.00001, 100, 10);
                   
                   assertEquals(1, f.getNumerator());
                   assertEquals(2, f.getDenominator());
               }

 @Test
               public void testApproximateFraction() throws Exception {
                   // Get the private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   
                   // Create fraction instance with 0.33333333, epsilon=0.0001, maxDenominator=100, maxIterations=10
                   Fraction f = constructor.newInstance(0.33333333, 0.0001, 100, 10);
                   
                   assertEquals(1, f.getNumerator());
                   assertEquals(3, f.getDenominator());
               }

 @Test
               public void testPiApproximation() throws Exception {
                   // Use reflection to access private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   Fraction f = constructor.newInstance(Math.PI, 0.00001, 1000, 20);
                   
                   assertEquals(355, f.getNumerator());
                   assertEquals(113, f.getDenominator());
               }

 @Test
               public void testSmallEpsilon() throws Exception {
                   // Get the private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   
                   // Create fraction instance using the private constructor
                   Fraction f = constructor.newInstance(0.123456789, 1e-10, 100000, 20);
                   
                   assertEquals(10, f.getNumerator());
                   assertEquals(81, f.getDenominator());
               }

 @Test
               public void testZeroValue() throws Exception {
                   // Get the private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   
                   // Create fraction using the private constructor
                   Fraction f = constructor.newInstance(0.0, 0.00001, 100, 10);
                   
                   assertEquals(0, f.getNumerator());
                   assertEquals(1, f.getDenominator());
               }

 @Test
               public void testNegativeValue() {
                   try {
                       Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                           double.class, double.class, int.class, int.class);
                       constructor.setAccessible(true);
                       Fraction f = constructor.newInstance(-0.75, 0.00001, 100, 10);
                       assertEquals(-3, f.getNumerator());
                       assertEquals(4, f.getDenominator());
                   } catch (Exception e) {
                       fail("Failed to create Fraction instance: " + e.getMessage());
                   }
               }

 @Test
               public void testMaxDenominatorConstraint() {
                   Fraction f = new Fraction(0.333333, 10);
                   assertEquals(1, f.getNumerator());
                   assertEquals(3, f.getDenominator());
                   
                   f = new Fraction(0.123456, 10);
                   assertEquals(1, f.getNumerator());
                   assertEquals(8, f.getDenominator());
               }

 @Test
               public void testOverflowThrowsException() {
                   org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                   thrown.expect(org.apache.commons.math3.fraction.FractionConversionException.class);
                   new org.apache.commons.math3.fraction.Fraction(Double.MAX_VALUE, 0.00001, Integer.MAX_VALUE);
               }

 @Test
               public void testMaxIterationsThrowsException() {
                   org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                   thrown.expect(FractionConversionException.class);
                   new Fraction(0.123456789, 1e-10, 5);
               }

 @Test
               public void testVerySmallValue() throws Exception {
                   // Get the private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   
                   // Create fraction with very small value
                   Fraction f = constructor.newInstance(1e-10, 1e-8, 100000, 20);
                   
                   assertEquals(0, f.getNumerator());
                   assertEquals(1, f.getDenominator());
               }

 @Test
               public void testAlmostInteger() throws Exception {
                   // Use reflection to access private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   Fraction f = constructor.newInstance(3.0000001, 0.00001, 100, 10);
                   
                   assertEquals(3, f.getNumerator());
                   assertEquals(1, f.getDenominator());
               }

 @Test
               public void testGoldenRatioApproximation() throws Exception {
                   double phi = (1 + Math.sqrt(5)) / 2;
                   // Use reflection to access the private constructor
                   Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                       double.class, double.class, int.class, int.class);
                   constructor.setAccessible(true);
                   Fraction f = constructor.newInstance(phi, 0.0001, 100, 10);
                   assertEquals(89, f.getNumerator());
                   assertEquals(55, f.getDenominator());
               }

 @Test
               public void testConstructor_ZeroDenominator() {
                   thrown = ExpectedException.none();
                   thrown.expect(MathArithmeticException.class);
                   thrown.expectMessage(LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION.toString());
                   new Fraction(1, 0);
               }

 @Test
               public void testConstructor_DenominatorMinValue() {
                   ExpectedException thrown = ExpectedException.none();
                   thrown.expect(MathArithmeticException.class);
                   thrown.expectMessage("overflow in fraction");
                   new Fraction(1, Integer.MIN_VALUE);
               }

 @Test
               public void testConstructor_NumeratorMinValueWithNegativeDenominator() {
                   thrown.expect(MathArithmeticException.class);
                   thrown.expectMessage(LocalizedFormats.OVERFLOW_IN_FRACTION.getSourceString());
                   new Fraction(Integer.MIN_VALUE, -1);
               }

 @Test
         public void testConstructorOverflowConditionOrToAndMutant() throws Exception {
             // This value is carefully chosen to make p2 overflow while q2 doesn't
             // Original code (OR condition) would throw, mutant (AND condition) wouldn't
             
             // Get the private constructor
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // Invoke the constructor with test values
             constructor.newInstance(Double.MAX_VALUE, 1.0e-5, Integer.MAX_VALUE, 100);
         }

 @Test
         public void testConstructorOverflowConditionOrToAndMutant1() throws Exception {
             // This value is carefully chosen to make q2 overflow while p2 doesn't
             // Original code (OR condition) would throw, mutant (AND condition) wouldn't
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             constructor.newInstance(1.0/Double.MIN_VALUE, 1.0e-5, Integer.MAX_VALUE, 100);
         }

 @Test
         public void testConstructorOverflowConditionBothOverflow() throws Exception {
             // This case would throw in both original and mutant
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             constructor.newInstance(Double.MAX_VALUE, 1.0e-5, Integer.MAX_VALUE, 100);
         }

 @Test
         public void testConstructorOverflowConditionOrToAndMutant2() throws Exception {
             // This value is carefully chosen to make p2 overflow while q2 doesn't
             // The exact value depends on the continued fraction algorithm's behavior
             // We use a value very close to Integer.MAX_VALUE to trigger overflow
             double value = Integer.MAX_VALUE - 0.5;
             
             // Small epsilon to force the algorithm to continue
             double epsilon = 1.0e-10;
             
             // Large max denominator to allow the algorithm to proceed
             int maxDenominator = Integer.MAX_VALUE;
             
             // Sufficient iterations
             int maxIterations = 100;
             
             // Get the private constructor
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // This should throw in original code when either p2 OR q2 overflows
             // The mutant version would only throw when BOTH overflow
             // By making only p2 overflow, we can detect the mutant
             constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
         }

 @Test
         public void testConstructorOverflowConditionOrToAndMutant_Q2Overflow() {
             // This value is carefully chosen to make q2 overflow while p2 doesn't
             double value = 1.0 / (Integer.MAX_VALUE - 0.5);
             
             double epsilon = 1.0e-10;
             int maxIterations = 100;
             
             // This should throw in original code when either p2 OR q2 overflows
             // The mutant version would only throw when BOTH overflow
             // By making only q2 overflow, we can detect the mutant
             new Fraction(value, epsilon, maxIterations);
         }

 @Test
         public void testOverflowConditionWhenP2Overflows() throws Exception {
             // This value will cause p2 to overflow while q2 remains normal
             // Choose a value very close to Integer.MAX_VALUE to trigger overflow in p2
             double value = Integer.MAX_VALUE - 0.000001;
             double epsilon = 0;
             int maxDenominator = Integer.MAX_VALUE;
             int maxIterations = 100;
             
             // Get the private constructor using reflection
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // Create the fraction instance
             constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
         }

 @Test
         public void testNoOverflowCondition() {
             // This value should not cause any overflow
             Fraction f = new Fraction(0.5, Integer.MAX_VALUE);
             assertEquals(1, f.getNumerator());
             assertEquals(2, f.getDenominator());
         }

 @Test(expected = FractionConversionException.class)
         public void testOverflowCheckWithSingleValueOverflow() throws Exception {
             // This value is chosen to cause p2 to overflow while q2 remains within bounds
             // during the continued fraction computation
             double value = 1.0e16; // Large value that will cause overflow in numerator
             
             // Get the private constructor
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // We need to use the constructor that allows setting maxDenominator to a large value
             // so that the overflow happens before hitting denominator limit
             constructor.newInstance(value, 0.0, Integer.MAX_VALUE, 100);
             
             // The test will pass if FractionConversionException is thrown (original behavior)
             // and fail if no exception is thrown (mutant behavior)
         }

 @Test
         public void testOverflowCheckWithSingleOverflow() throws Exception {
             // This value is carefully chosen to cause only p2 to overflow during conversion
             // while q2 remains within bounds
             double value = 1.0e20;
             double epsilon = 1.0e-5;
             int maxDenominator = Integer.MAX_VALUE;
             int maxIterations = 100;
             
             // Get the private constructor
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // This should throw in original code because p2 overflows,
             // but would pass in mutated code (&& condition wouldn't trigger)
             constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
         }

 @Test
         public void testOverflowCheckWithOtherSingleOverflow() throws Exception {
             // This value is carefully chosen to cause only q2 to overflow during conversion
             // while p2 remains within bounds
             double value = 1.0 / 1.0e20;
             int maxDenominator = Integer.MAX_VALUE;
             double epsilon = 1.0e-5;
             int maxIterations = 100;
             
             // Get the private constructor
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // This should throw in original code because q2 overflows,
             // but would pass in mutated code (&& condition wouldn't trigger)
             constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
         }

 @Test
         public void testOverflowCheckWithBothOverflow() throws Exception {
             // This value causes both p2 and q2 to overflow
             double value = Double.MAX_VALUE;
             double epsilon = 1.0e-5;
             int maxDenominator = Integer.MAX_VALUE;
             int maxIterations = 100;
             
             // Get the private constructor
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             
             // This should throw in both original and mutated code
             constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
         }

 @Test
         public void testFractionConversionOverflowEitherValue() throws Exception {
             // This value will cause p2 to overflow but q2 won't
             // Original code should throw, mutant won't
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             constructor.newInstance(Double.MAX_VALUE, 0.0, Integer.MAX_VALUE, 100);
         }

 @Test
         public void testFractionConversionOverflowOtherValue() throws Exception {
             // This value will cause q2 to overflow but p2 won't
             // Original code should throw, mutant won't
             Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                 double.class, double.class, int.class, int.class);
             constructor.setAccessible(true);
             constructor.newInstance(1.0/Double.MAX_VALUE, 0.0, Integer.MAX_VALUE, 100);
         }

 @Test
         public void testFractionConversionNoOverflow() {
             // Normal case that shouldn't throw for either original or mutant
             Fraction f = new Fraction(0.5, 100);
             assertEquals(1, f.getNumerator());
             assertEquals(2, f.getDenominator());
         }

 @Test(expected = ArithmeticException.class)
         public void testFractionConversionBothOverflow() {
             // Case where both overflow - both original and mutant should throw
             new Fraction(Double.MAX_VALUE, 1);
         }

 @Test
     public void testOverflowConditionWhenQ2Overflows() throws Exception {
         // This value will cause q2 to overflow while p2 remains normal
         // Need a value whose continued fraction expansion leads to large denominator
         // 1/(very small number) will create large denominator
         
         // Use reflection to access the private constructor
         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
             double.class, double.class, int.class, int.class);
         constructor.setAccessible(true);
         
         // Create the fraction with parameters that will cause overflow
         constructor.newInstance(1.0e-10, 0.0, Integer.MAX_VALUE, 100);
     }

 @Test
     public void testBothP2AndQ2Overflow() throws Exception {
         // This value should cause both p2 and q2 to overflow
         // Need a value that causes both numerator and denominator to grow large
         Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
             double.class, double.class, int.class, int.class);
         constructor.setAccessible(true);
         constructor.newInstance(Double.MAX_VALUE, 0.0, Integer.MAX_VALUE, 100);
     }

 @Test(expected = ArithmeticException.class)
     public void testOverflowCheckWithDenominatorOverflow() {
         // This value is chosen to cause q2 to overflow while p2 remains within bounds
         // We need a value that creates a rapidly increasing denominator
         double value = 1.0 / (1.0e16); // Very small value that causes denominator to grow quickly
         int maxDenominator = Integer.MAX_VALUE;
         
         // Using public constructor that allows specifying max denominator
         new Fraction(value, maxDenominator);
         
         // Test passes if exception is thrown (original behavior)
         // and fails if no exception is thrown (mutant behavior)
     }

 @Test
 public void testFractionConversionWithPrecisionEdgeCase() {
     // This value is chosen because it's very close to an integer but not exactly,
     // and might expose differences between FastMath.floor and Math.floor
     double value = 9007199254740991.999999999999999;
     
     // Create fraction with standard epsilon and iterations
     Fraction fraction = new Fraction(value, 1.0e-5, 100);
     
     // Verify the conversion is correct by checking the double value
     // The exact expected values might need adjustment based on actual FastMath behavior
     double convertedValue = fraction.doubleValue();
     double delta = 1.0e-14; // Very tight delta to catch precision differences
     
     // This assertion will fail if the mutant is present because Math.floor
     // might handle the precision differently than FastMath.floor
     assertEquals(value, convertedValue, delta);
     
     // Additional verification of the fraction components
     // The exact expected numerator/denominator might need adjustment
     assertTrue(fraction.getNumerator() > 0);
     assertTrue(fraction.getDenominator() > 0);
     
     // Verify the fraction is reduced
     int gcd = ArithmeticUtils.gcd(
         Math.abs(fraction.getNumerator()), 
         fraction.getDenominator());
     assertEquals(1, gcd);
 }

 @Test
 public void testFractionConversionWithPrecisionBoundary() {
     // This value is chosen because it's very close to 0.5 but not exactly 0.5
     // and might expose differences between FastMath.floor and Math.floor
     double value = 0.49999999999999994; // Just below 0.5 in double precision
     
     // Test with default epsilon and iterations
     Fraction fraction = new Fraction(value);
     
     // The correct conversion should be 1/2 since it's within epsilon of 0.5
     // If the mutant uses Math.floor instead of FastMath.floor, the continued
     // fraction algorithm might produce a different result
     assertEquals(1, fraction.getNumerator());
     assertEquals(2, fraction.getDenominator());
     
     // Test with more precise settings
     Fraction preciseFraction = new Fraction(value, 1.0e-10, 1000);
     assertEquals(1, preciseFraction.getNumerator());
     assertEquals(2, preciseFraction.getDenominator());
     
     // Test another boundary case
     value = 1.9999999999999998; // Just below 2.0
     fraction = new Fraction(value);
     assertEquals(2, fraction.getNumerator());
     assertEquals(1, fraction.getDenominator());
     
     // Test with a value that would require multiple iterations
     // of the continued fraction algorithm
     value = 1.0/3.0;
     fraction = new Fraction(value, 1.0e-10, 100);
     assertEquals(1, fraction.getNumerator());
     assertEquals(3, fraction.getDenominator());
 }

 @Test
     public void testFractionConversionWithLargeValue() {
         // This value is chosen because it's large enough that FastMath.floor and Math.floor
         // might handle it differently due to precision differences
         double largeValue = 1.0e20 + 0.5;
         
         // Create fraction with max denominator that would force the continued fraction algorithm
         // to use the floor operation
         Fraction fraction = new Fraction(largeValue, 1.0e-5, Integer.MAX_VALUE);
         
         // Calculate expected value using FastMath (original behavior)
         double r1 = 1.0 / (largeValue - FastMath.floor(largeValue));
         long expectedA1 = (long)FastMath.floor(r1);
         
         // Calculate actual value (would use Math.floor in mutant)
         double actualR1 = 1.0 / (largeValue - Math.floor(largeValue));
         long actualA1 = (long)Math.floor(actualR1);
         
         // If FastMath and Math floor operations differ, this will fail for the mutant
         assertEquals("Floor operation should use FastMath for consistency", 
                     expectedA1, actualA1);
         
         // Additional verification - the resulting fraction should be correct
         double convertedValue = (double)fraction.getNumerator() / fraction.getDenominator();
         assertEquals("Converted fraction value should match original", 
                     largeValue, convertedValue, 1.0e-5);
     }

 @Test
     public void testFractionConversionWithPreciseFraction() {
         // This value has a precise fractional part that might be handled differently
         double preciseValue = 1.0 / 3.0;
         
         Fraction fraction = new Fraction(preciseValue, 1.0e-10, 100);
         
         // Verify the fraction is 1/3 (best approximation)
         assertEquals(1, fraction.getNumerator());
         assertEquals(3, fraction.getDenominator());
         
         // Verify the floor operations in the conversion process
         double r0 = preciseValue;
         long a0 = (long)FastMath.floor(r0);
         double r1 = 1.0 / (r0 - a0);
         long expectedA1 = (long)FastMath.floor(r1);
         
         // This would differ if Math.floor was used instead
         long actualA1 = (long)Math.floor(r1);
         assertEquals("Floor operation should use FastMath for precise fractions",
                     expectedA1, actualA1);
     }

 @Test
     public void testFloorDifferenceDetection() {
         // This value is carefully chosen because FastMath.floor and Math.floor 
         // can produce different results due to floating point precision handling
         double trickyValue = 9007199254740992.0 + 0.9999999999999999;
         
         // FastMath.floor would handle this precisely and return 9007199254740992
         // Math.floor might return 9007199254740993 due to floating point precision issues
         
         try {
             // Create fraction with standard epsilon and iterations
             Fraction fraction = new Fraction(trickyValue, 1.0e-5, 100);
             
             // Verify the conversion is correct
             double convertedValue = (double)fraction.getNumerator() / fraction.getDenominator();
             assertTrue("Conversion should be accurate", 
                       FastMath.abs(convertedValue - trickyValue) < 1.0e-5);
             
             // Additional check to ensure proper flooring was used
             // The exact expected values depend on FastMath's behavior
             long expectedNumerator = 9007199254740992L;
             long expectedDenominator = 1L;
             assertEquals("Numerator should match FastMath.floor result", 
                         expectedNumerator, fraction.getNumerator());
             assertEquals("Denominator should be 1 for near-integer value",
                         expectedDenominator, fraction.getDenominator());
         } catch (FractionConversionException e) {
             fail("Should not throw exception for this value");
         }
     }

 @Test
     public void testFloorOperationDifference() {
         // Test with a value where FastMath.floor and Math.floor might differ
         // This value is chosen because it's large enough that floating point
         // precision might cause differences between FastMath and Math implementations
         double testValue = 1.0 / (1.0e17 - 0.5);
         
         // Calculate what FastMath.floor would return
         long expectedA1 = (long)FastMath.floor(testValue);
         
         try {
             // Create fraction which will use floor operation internally
             Fraction fraction = new Fraction(1.0 / testValue, 1.0e-10, 100);
             
             // The actual test - we need to verify that the internal floor operation
             // used FastMath.floor rather than Math.floor
             // We can do this by checking the resulting fraction is what we'd expect
             // from using FastMath.floor
             
             // For this specific testValue, FastMath.floor and Math.floor should differ
             long mathFloorResult = (long)Math.floor(testValue);
             assertNotEquals("Test value should produce different floor results", 
                           mathFloorResult, expectedA1);
             
             // Verify the fraction was created using FastMath.floor result
             // This is indirect testing since we can't access private computation
             // The exact assertions would depend on the expected conversion
             assertTrue("Fraction should reflect FastMath.floor behavior",
                       fraction.doubleValue() == 1.0 / testValue);
             
         } catch (FractionConversionException e) {
             fail("Should not throw exception for this test case");
         }
     }

 @Test
 public void testFractionConversionWithPrecisionSensitiveValue() {
     // This value is chosen because it's very close to 1/3 but not exactly,
     // and the continued fraction algorithm will be sensitive to floor operations
     double value = 1.0/3.0 + 1.0e-10;
     
     // With FastMath.floor, this should convert to 1/3
     // With Math.floor, it might convert to a different fraction due to floating point precision
     Fraction fastMathResult = new Fraction(value, 1.0e-9, 100);
     assertEquals(1, fastMathResult.getNumerator());
     assertEquals(3, fastMathResult.getDenominator());
     
     // Test with a value that would stress the floor operation
     double edgeValue = 0.9999999999999999;
     Fraction edgeResult = new Fraction(edgeValue, 1.0e-16, 100);
     assertEquals(1, edgeResult.getNumerator());
     assertEquals(1, edgeResult.getDenominator());
     
     // Test with a very small fractional part
     double smallFracValue = 2.000000000000001;
     Fraction smallFracResult = new Fraction(smallFracValue, 1.0e-16, 100);
     assertEquals(2, smallFracResult.getNumerator());
     assertEquals(1, smallFracResult.getDenominator());
 }

}
