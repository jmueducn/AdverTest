package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math3.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                        public void testEbeDivide_WithZeroInNumerator() {
                            OpenMapRealVector numerator = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
                            OpenMapRealVector denominator = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                            
                            OpenMapRealVector result = numerator.ebeDivide(denominator);
                            
                            assertEquals(0.0, result.getEntry(0), 0.0001);
                            assertEquals(0.0, result.getEntry(1), 0.0001);
                            assertEquals(0.0, result.getEntry(2), 0.0001);
                        }

 @Test
                        public void testEbeDivide_WithZeroInDenominator() {
                            OpenMapRealVector numerator = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                            OpenMapRealVector denominator = new OpenMapRealVector(new double[]{1.0, 0.0, 3.0});
                            
                            OpenMapRealVector result = numerator.ebeDivide(denominator);
                            
                            assertEquals(1.0, result.getEntry(0), 0.0001);
                            assertTrue(Double.isNaN(result.getEntry(1)));
                            assertEquals(1.0, result.getEntry(2), 0.0001);
                        }

 @Test
                        public void testEbeDivide_WithBothZeros() {
                            OpenMapRealVector numerator = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
                            OpenMapRealVector denominator = new OpenMapRealVector(new double[]{1.0, 0.0, 0.0});
                            
                            OpenMapRealVector result = numerator.ebeDivide(denominator);
                            
                            assertEquals(0.0, result.getEntry(0), 0.0001);
                            assertTrue(Double.isNaN(result.getEntry(1)));
                            assertTrue(Double.isNaN(result.getEntry(2)));
                        }

 @Test
                        public void testEbeDivide_PreservesSparsity() {
                            OpenMapRealVector sparseVector1 = new OpenMapRealVector(5);
                            sparseVector1.setEntry(1, 2.0); // Only index 1 has value
                            OpenMapRealVector sparseVector2 = new OpenMapRealVector(5);
                            sparseVector2.setEntry(1, 4.0); // Only index 1 has value
                            
                            OpenMapRealVector result = sparseVector1.ebeDivide(sparseVector2);
                            
                            // Should be sparse with only index 1 having a value
                            assertEquals(0.0, result.getEntry(0), 0.0001);
                            assertEquals(0.5, result.getEntry(1), 0.0001);
                            assertEquals(0.0, result.getEntry(2), 0.0001);
                            assertEquals(0.0, result.getEntry(3), 0.0001);
                            assertEquals(0.0, result.getEntry(4), 0.0001);
                        }

 @Test
                        public void testEbeMultiply_TypicalValues() {
                            // Create two vectors with typical values
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{4.0, 5.0, 6.0});
                            
                            // Perform element-by-element multiplication
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            // Verify results
                            assertEquals(4.0, result.getEntry(0), 0.0001);
                            assertEquals(10.0, result.getEntry(1), 0.0001);
                            assertEquals(18.0, result.getEntry(2), 0.0001);
                        }

 @Test
                        public void testEbeMultiply_WithZeroValues() {
                            // Create vectors with zero values
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{0.0, 2.0, 0.0});
                            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{4.0, 0.0, 6.0});
                            
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            assertEquals(0.0, result.getEntry(0), 0.0001);
                            assertEquals(0.0, result.getEntry(1), 0.0001);
                            assertEquals(0.0, result.getEntry(2), 0.0001);
                        }

 @Test
                        public void testEbeMultiply_WithNaNValues() {
                            // Create vector with NaN values
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{4.0, Double.NaN, 6.0});
                            
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            assertEquals(4.0, result.getEntry(0), 0.0001);
                            assertTrue(Double.isNaN(result.getEntry(1)));
                            assertEquals(18.0, result.getEntry(2), 0.0001);
                        }

 @Test
                        public void testEbeMultiply_WithInfinityValues() {
                            // Create vector with Infinity values
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 0.0, -3.0});
                            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{4.0, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY});
                            
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            assertEquals(4.0, result.getEntry(0), 0.0001);
                            assertTrue(Double.isNaN(result.getEntry(1))); // 0 * Infinity = NaN
                            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0001);
                        }

 @Test
                        public void testEbeMultiply_WithDifferentDimensions() {
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                            
                            thrown.expect(IllegalArgumentException.class);
                            v1.ebeMultiply(v2);
                        }

 @Test
                        public void testEbeMultiply_WithSparseVectors() {
                            // Create sparse vectors (most values are 0)
                            OpenMapRealVector v1 = new OpenMapRealVector(100);
                            OpenMapRealVector v2 = new OpenMapRealVector(100);
                            
                            v1.setEntry(10, 5.0);
                            v1.setEntry(50, 3.0);
                            v2.setEntry(10, 2.0);
                            v2.setEntry(99, 4.0);
                            
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            assertEquals(10.0, result.getEntry(10), 0.0001);
                            assertEquals(0.0, result.getEntry(50), 0.0001); // Because v2[50] is 0
                            assertEquals(0.0, result.getEntry(99), 0.0001); // Because v1[99] is 0
                        }

 @Test
                        public void testEbeMultiply_WithRealVectorParameter() {
                            // Test with RealVector parameter (polymorphism)
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                            RealVector v2 = mock(RealVector.class);
                            when(v2.getDimension()).thenReturn(3);
                            when(v2.getEntry(0)).thenReturn(2.0);
                            when(v2.getEntry(1)).thenReturn(3.0);
                            when(v2.getEntry(2)).thenReturn(4.0);
                            
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            assertEquals(2.0, result.getEntry(0), 0.0001);
                            assertEquals(6.0, result.getEntry(1), 0.0001);
                            assertEquals(12.0, result.getEntry(2), 0.0001);
                        }

 @Test
                        public void testEbeMultiply_WithAllNaNVector() {
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{Double.NaN, Double.NaN, Double.NaN});
                            
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            assertTrue(Double.isNaN(result.getEntry(0)));
                            assertTrue(Double.isNaN(result.getEntry(1)));
                            assertTrue(Double.isNaN(result.getEntry(2)));
                        }

 @Test
                        public void testEbeMultiply_WithAllInfinityVector() {
                            OpenMapRealVector v1 = new OpenMapRealVector(new double[]{1.0, 0.0, -1.0});
                            OpenMapRealVector v2 = new OpenMapRealVector(new double[]{
                                Double.POSITIVE_INFINITY, 
                                Double.POSITIVE_INFINITY, 
                                Double.NEGATIVE_INFINITY
                            });
                            
                            OpenMapRealVector result = v1.ebeMultiply(v2);
                            
                            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0001);
                            assertTrue(Double.isNaN(result.getEntry(1))); // 0 * Infinity = NaN
                            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0001);
                        }

 @Test
                public void testEbeDivide_TypicalValues() {
                    // Create test vectors with values that will produce the expected results
                    double[] data1 = {1.0, 4.0, 0.0, 6.0};
                    double[] data2 = {2.0, 2.0, 3.0, 3.0};
                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                    
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    assertEquals(0.5, result.getEntry(0), 0.0001);
                    assertEquals(2.0, result.getEntry(1), 0.0001);
                    assertEquals(0.0, result.getEntry(2), 0.0001);
                    assertEquals(2.0, result.getEntry(3), 0.0001);
                }

 @Test(expected = IllegalArgumentException.class)
                public void testEbeDivide_DimensionMismatch() {
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                    OpenMapRealVector differentSizeVector = new OpenMapRealVector(new double[]{1.0, 2.0});
                    vector1.ebeDivide(differentSizeVector);
                }

 @Test
                public void testEbeDivide_WithRealVectorParameter() {
                    // Create and initialize vector1
                    OpenMapRealVector vector1 = new OpenMapRealVector(4);
                    vector1.setEntry(0, 1.0);
                    vector1.setEntry(1, 2.0);
                    vector1.setEntry(2, 0.0);
                    vector1.setEntry(3, 4.0);
                    
                    // Create mock vector
                    RealVector mockVector = mock(RealVector.class);
                    when(mockVector.getDimension()).thenReturn(4);
                    when(mockVector.getEntry(0)).thenReturn(2.0);
                    when(mockVector.getEntry(1)).thenReturn(1.0);
                    when(mockVector.getEntry(2)).thenReturn(3.0);
                    when(mockVector.getEntry(3)).thenReturn(2.0);
                    
                    // Perform operation and verify results
                    OpenMapRealVector result = vector1.ebeDivide(mockVector);
                    
                    assertEquals(0.5, result.getEntry(0), 0.0001);
                    assertEquals(2.0, result.getEntry(1), 0.0001);
                    assertEquals(0.0, result.getEntry(2), 0.0001);
                    assertEquals(2.0, result.getEntry(3), 0.0001);
                }

 @Test
                public void testEbeDivide_ResultIsNewInstance() {
                    // Create two test vectors
                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                    OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 2.0, 2.0});
                    
                    // Perform the operation
                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                    
                    // Verify the result is a new instance
                    assertNotSame(vector1, result);
                    assertNotSame(vector2, result);
                }

 @Test
                public void testEbeMultiply_ShouldNotProcessAllEntriesWhenNoNaNOrInfinite() {
                    // Create original vector with some zero and non-zero entries
                    OpenMapRealVector original = new OpenMapRealVector(3);
                    original.setEntry(0, 1.0);  // non-zero
                    original.setEntry(1, 0.0);  // zero
                    original.setEntry(2, 2.0);  // non-zero
                    
                    // Create input vector with no NaN/Infinite values
                    OpenMapRealVector input = new OpenMapRealVector(3);
                    input.setEntry(0, 3.0);
                    input.setEntry(1, 4.0);
                    input.setEntry(2, 5.0);
                    
                    // Mock isNaN() and isInfinite() to return false
                    OpenMapRealVector spyInput = spy(input);
                    when(spyInput.isNaN()).thenReturn(false);
                    when(spyInput.isInfinite()).thenReturn(false);
                    
                    // Perform multiplication
                    OpenMapRealVector result = original.ebeMultiply(spyInput);
                    
                    // Verify only non-zero entries were processed (0 and 2)
                    assertEquals(3.0, result.getEntry(0), 0.0001);  // 1.0 * 3.0
                    assertEquals(0.0, result.getEntry(1), 0.0001);  // should remain 0 (not processed)
                    assertEquals(10.0, result.getEntry(2), 0.0001); // 2.0 * 5.0
                    
                    // Verify isNaN() and isInfinite() were called
                    verify(spyInput).isNaN();
                    verify(spyInput).isInfinite();
                }

 @Test
           public void testEbeMultiplyWithNaNValuesShouldReturnNaN() {
               // Create original vector with some zero values
               OpenMapRealVector original = new OpenMapRealVector(new double[]{0.0, 0.0, 0.0});
               
               // Create input vector with NaN values
               OpenMapRealVector inputWithNaN = new OpenMapRealVector(new double[]{
                   Double.NaN,  // Should result in NaN
                   1.0,         // Regular multiplication (0 * 1 = 0)
                   Double.NaN    // Should result in NaN
               });
               
               // Perform multiplication
               OpenMapRealVector result = original.ebeMultiply(inputWithNaN);
               
               // Verify NaN handling
               assertTrue("First entry should be NaN", Double.isNaN(result.getEntry(0)));
               assertEquals("Second entry should be 0.0", 0.0, result.getEntry(1), 0.0);
               assertTrue("Third entry should be NaN", Double.isNaN(result.getEntry(2)));
               
               // Also verify the vector is not marked as NaN overall (since not all entries are NaN)
               assertFalse("Vector should not be NaN overall", result.isNaN());
           }

 @Test
              public void testEbeMultiply_HandlesBothNaNAndInfinite() {
                  // Create a test vector with both NaN and Infinite values
                  double[] testValues = {1.0, Double.NaN, Double.POSITIVE_INFINITY};
                  OpenMapRealVector vector = new OpenMapRealVector(testValues);
                  
                  // Create a mock vector that returns special values at specific indices
                  RealVector mockVector = mock(RealVector.class);
                  when(mockVector.getDimension()).thenReturn(3);
                  when(mockVector.getEntry(0)).thenReturn(1.0);
                  when(mockVector.getEntry(1)).thenReturn(Double.NaN);
                  when(mockVector.getEntry(2)).thenReturn(Double.POSITIVE_INFINITY);
                  when(mockVector.isNaN()).thenReturn(true);
                  when(mockVector.isInfinite()).thenReturn(true);
                  
                  // Perform the multiplication
                  OpenMapRealVector result = vector.ebeMultiply(mockVector);
                  
                  // Verify results
                  assertEquals(1.0, result.getEntry(0), 0.0001);  // Normal multiplication
                  assertTrue(Double.isNaN(result.getEntry(1)));    // Must be NaN
                  assertTrue(Double.isInfinite(result.getEntry(2))); // Must be Infinite
                  
                  // Critical assertion - entry 1 should remain NaN and not be overwritten
                  // This catches the mutant which might try to process Infinite after NaN
                  assertTrue(Double.isNaN(result.getEntry(1)));
              }

 @Test
         public void testEbeMultiplyWithNaNVector() {
             // Create a test vector with some NaN values
             double[] values = {1.0, 0.0, Double.NaN, 2.0};
             OpenMapRealVector vector = new OpenMapRealVector(values);
             
             // Create another vector to multiply with
             double[] otherValues = {2.0, 3.0, 4.0, 5.0};
             OpenMapRealVector otherVector = new OpenMapRealVector(otherValues);
             
             // Perform the multiplication
             OpenMapRealVector result = vector.ebeMultiply(otherVector);
             
             // Verify the results
             assertEquals(2.0, result.getEntry(0), 0.0);  // 1.0 * 2.0 = 2.0
             assertEquals(0.0, result.getEntry(1), 0.0);  // 0.0 * 3.0 = 0.0
             assertTrue(Double.isNaN(result.getEntry(2))); // NaN * 4.0 should be NaN
             assertEquals(10.0, result.getEntry(3), 0.0); // 2.0 * 5.0 = 10.0
             
             // Also test with zero vector containing NaN
             double[] zeroWithNaN = {0.0, 0.0, Double.NaN, 0.0};
             OpenMapRealVector zeroVector = new OpenMapRealVector(zeroWithNaN);
             result = zeroVector.ebeMultiply(otherVector);
             
             assertEquals(0.0, result.getEntry(0), 0.0);  // 0.0 * 2.0 = 0.0
             assertEquals(0.0, result.getEntry(1), 0.0);  // 0.0 * 3.0 = 0.0
             assertTrue(Double.isNaN(result.getEntry(2))); // NaN * 4.0 should be NaN
             assertEquals(0.0, result.getEntry(3), 0.0);  // 0.0 * 5.0 = 0.0
         }

 @Test
        public void testEbeMultiply_FirstElementNaN() {
            // Create main vector with some values
            double[] mainValues = {1.0, 2.0, 3.0};
            OpenMapRealVector mainVector = new OpenMapRealVector(mainValues);
            
            // Create test vector with NaN as first element
            double[] testValues = {Double.NaN, 4.0, 5.0};
            OpenMapRealVector testVector = new OpenMapRealVector(testValues);
            
            // Perform multiplication
            OpenMapRealVector result = mainVector.ebeMultiply(testVector);
            
            // Verify first element is properly handled (should be NaN)
            assertEquals(Double.NaN, result.getEntry(0), 0.0);
            // Verify other elements are handled normally
            assertEquals(8.0, result.getEntry(1), 0.0);
            assertEquals(15.0, result.getEntry(2), 0.0);
        }

 @Test
        public void testEbeMultiply_FirstElementInfinite() {
            // Create main vector with some values
            double[] mainValues = {1.0, 2.0, 3.0};
            OpenMapRealVector mainVector = new OpenMapRealVector(mainValues);
            
            // Create test vector with Infinite as first element
            double[] testValues = {Double.POSITIVE_INFINITY, 4.0, 5.0};
            OpenMapRealVector testVector = new OpenMapRealVector(testValues);
            
            // Perform multiplication
            OpenMapRealVector result = mainVector.ebeMultiply(testVector);
            
            // Verify first element is properly handled (should be Infinite)
            assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
            // Verify other elements are handled normally
            assertEquals(8.0, result.getEntry(1), 0.0);
            assertEquals(15.0, result.getEntry(2), 0.0);
        }

 @Test
           public void testEbeMultiplyWithNaNHandling() {
               // Create a vector with NaN values
               double[] nanValues = {1.0, Double.NaN, 3.0, Double.POSITIVE_INFINITY};
               OpenMapRealVector vectorWithNaN = new OpenMapRealVector(nanValues);
               
               // Create a test vector
               double[] testValues = {2.0, 4.0, 6.0, 8.0};
               OpenMapRealVector testVector = new OpenMapRealVector(testValues);
               
               // Perform multiplication
               OpenMapRealVector result = testVector.ebeMultiply(vectorWithNaN);
               
               // Verify all elements were processed correctly
               assertEquals(4, result.getDimension());
               assertEquals(2.0, result.getEntry(0), 0.0001);  // 1.0 * 2.0
               assertTrue(Double.isNaN(result.getEntry(1)));   // NaN * 4.0
               assertEquals(18.0, result.getEntry(2), 0.0001); // 3.0 * 6.0
               assertTrue(Double.isInfinite(result.getEntry(3))); // Infinity * 8.0
               
               // Verify the loop processed exactly 4 elements (would fail if ++i vs i++ had different behavior)
               assertEquals(4, result.getDimension());
           }

 @Test
           public void testEbeMultiplyWithAllNaN() {
               // Create a vector with all NaN values
               double[] allNaN = {Double.NaN, Double.NaN, Double.NaN};
               OpenMapRealVector nanVector = new OpenMapRealVector(allNaN);
               
               // Create a test vector
               double[] testValues = {1.0, 2.0, 3.0};
               OpenMapRealVector testVector = new OpenMapRealVector(testValues);
               
               // Perform multiplication
               OpenMapRealVector result = testVector.ebeMultiply(nanVector);
               
               // Verify all elements were processed and set to NaN
               assertEquals(3, result.getDimension());
               assertTrue(Double.isNaN(result.getEntry(0)));
               assertTrue(Double.isNaN(result.getEntry(1)));
               assertTrue(Double.isNaN(result.getEntry(2)));
           }

 @Test
          public void testEbeMultiplyWithNaNValuesDetectsFinalModifierRemoval() {
              // Create a vector with some NaN values
              double[] data1 = {1.0, 2.0, 0.0};
              double[] data2 = {3.0, Double.NaN, Double.POSITIVE_INFINITY};
              
              OpenMapRealVector v1 = new OpenMapRealVector(data1);
              OpenMapRealVector v2 = new OpenMapRealVector(data2);
              
              // Perform element-by-element multiplication
              OpenMapRealVector result = v1.ebeMultiply(v2);
              
              // Verify results
              assertEquals(3.0, result.getEntry(0), 0.0001);  // 1.0 * 3.0 = 3.0
              assertTrue(Double.isNaN(result.getEntry(1)));     // 2.0 * NaN = NaN
              assertTrue(Double.isInfinite(result.getEntry(2))); // 0.0 * Infinity = NaN (special case)
              
              // The key assertion - if 'final' was removed and y was modified,
              // this would potentially change the NaN handling behavior
              assertEquals(Double.NaN, result.getEntry(1), 0.0);
          }

 @Test
     public void testEbeMultiplyWithNaN() {
         // Create a vector with all zeros (default value)
         OpenMapRealVector vector1 = new OpenMapRealVector(3); // [0, 0, 0]
         
         // Create a vector with NaN at index 1
         OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, Double.NaN, 2.0});
         
         // Perform element-by-element multiplication
         OpenMapRealVector result = vector1.ebeMultiply(vector2);
         
         // Verify that index 1 is NaN (explicitly set, not just copied)
         assertTrue("Result at NaN position should be NaN", Double.isNaN(result.getEntry(1)));
         
         // Verify other positions are properly multiplied
         assertEquals("Position 0 should be 0 * 1.0 = 0", 0.0, result.getEntry(0), 0.0);
         assertEquals("Position 2 should be 0 * 2.0 = 0", 0.0, result.getEntry(2), 0.0);
         
         // Additional verification that the NaN was explicitly set, not just copied
         // This is the key assertion that catches the mutant
         assertNotSame("NaN should be explicitly set, not just copied", 
                      vector2.getEntry(1), result.getEntry(1));
     }

 @Test
    public void testEbeMultiplyWithNaNAndInfiniteValues() {
        // Create main vector with some zero entries
        double[] mainValues = {1.0, 0.0, 3.0, 0.0};
        OpenMapRealVector mainVector = new OpenMapRealVector(mainValues);
        
        // Create vector with NaN and Infinite values at zero positions
        double[] specialValues = {2.0, Double.NaN, 4.0, Double.POSITIVE_INFINITY};
        OpenMapRealVector specialVector = new OpenMapRealVector(specialValues);
        
        // Perform multiplication
        OpenMapRealVector result = mainVector.ebeMultiply(specialVector);
        
        // Verify results
        assertEquals(1.0 * 2.0, result.getEntry(0), 0.0); // Normal multiplication
        assertTrue(Double.isNaN(result.getEntry(1)));     // 0 * NaN should be NaN
        assertEquals(3.0 * 4.0, result.getEntry(2), 0.0); // Normal multiplication
        assertTrue(Double.isInfinite(result.getEntry(3))); // 0 * Infinity should be NaN (but actually 0*∞=NaN in IEEE)
        assertEquals(0.0, result.getEntry(3), 0.0);       // This will fail if x was modified
        
        // Note: The test will catch the mutant because:
        // 1. If x was modified (which removing final would allow), the 0*∞ calculation would be wrong
        // 2. The test explicitly checks the special case handling
        // 3. The assertion on entry 3 would fail if x was modified during processing
    }

 @Test
   public void testEbeMultiply_InfiniteValue_VerifiesComputationOrder() {
       // Create test vector with a non-zero value at index 0
       OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{2.0, 0.0});
       
       // Create a vector with positive infinity at index 0
       OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{Double.POSITIVE_INFINITY, 1.0});
       
       // Perform multiplication
       OpenMapRealVector result = vector1.ebeMultiply(vector2);
       
       // Verify the exact computation was performed (2.0 * Infinity)
       // This would catch if the order was reversed (Infinity * 2.0)
       assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
       
       // Additional verification for other entries
       assertEquals(0.0, result.getEntry(1), 0.0);
       
       // Verify the vector is marked as infinite
       assertTrue(result.isInfinite());
       assertFalse(result.isNaN());
   }

 @Test
  public void testEbeMultiplyWithNaNValuesShouldProcessAllDimensions() {
      // Create a vector with NaN values
      double[] values1 = {1.0, 2.0, 0.0};
      double[] values2 = {3.0, Double.NaN, Double.POSITIVE_INFINITY};
      
      OpenMapRealVector v1 = new OpenMapRealVector(values1);
      OpenMapRealVector v2 = new OpenMapRealVector(values2);
      
      // Perform multiplication
      OpenMapRealVector result = v1.ebeMultiply(v2);
      
      // Verify all dimensions were processed correctly
      assertEquals(3, result.getDimension());
      assertEquals(3.0, result.getEntry(0), 0.0001);  // 1.0 * 3.0
      assertTrue(Double.isNaN(result.getEntry(1)));   // 2.0 * NaN = NaN
      assertTrue(Double.isInfinite(result.getEntry(2))); // 0.0 * Infinity = NaN (but actually 0.0 * Infinity is NaN in math)
      
      // The key assertion - verify the NaN at index 1 was properly set
      // This ensures the loop processed all dimensions
      assertTrue(Double.isNaN(result.getEntry(1)));
      
      // Also verify the infinite case was handled
      assertTrue(Double.isNaN(result.getEntry(2))); // Because 0 * Infinity is NaN
  }

 @Test
     public void testEbeMultiplyWithNaNAndInfinityOrderSensitive() {
         // Create a test vector with specific NaN and Infinity values at known positions
         double[] thisValues = {0.0, 0.0, 0.0, 0.0};  // All zeros to trigger special case handling
         double[] otherValues = {Double.NaN, Double.POSITIVE_INFINITY, 1.0, Double.NEGATIVE_INFINITY};
         
         OpenMapRealVector vector1 = new OpenMapRealVector(thisValues);
         OpenMapRealVector vector2 = new OpenMapRealVector(otherValues);
         
         // Perform the multiplication
         OpenMapRealVector result = vector1.ebeMultiply(vector2);
         
         // Verify the results in order - this would fail if processed in reverse
         assertEquals("First element should be NaN", Double.NaN, result.getEntry(0), 0.0);
         assertEquals("Second element should be Infinity*0", Double.NaN, result.getEntry(1), 0.0);
         assertEquals("Third element should be 0*1", 0.0, result.getEntry(2), 0.0);
         assertEquals("Fourth element should be -Infinity*0", Double.NaN, result.getEntry(3), 0.0);
         
         // Additional check to ensure all positions were processed
         assertEquals("Vector dimension should remain unchanged", 4, result.getDimension());
     }

}
