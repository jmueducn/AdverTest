package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
               public void testFactorial_ValidValues() {
                   // Test typical valid values
                   assertEquals(1, MathUtils.factorial(0));  // 0! = 1
                   assertEquals(1, MathUtils.factorial(1));  // 1! = 1
                   assertEquals(2, MathUtils.factorial(2));  // 2! = 2
                   assertEquals(6, MathUtils.factorial(3));  // 3! = 6
                   assertEquals(24, MathUtils.factorial(4)); // 4! = 24
                   assertEquals(120, MathUtils.factorial(5)); // 5! = 120
                   
                   // Test boundary value (20 is the maximum allowed)
                   assertEquals(2432902008176640000L, MathUtils.factorial(20));
               }

 @Test
               public void testFactorial_NegativeInput() {
                   thrown.expect(IllegalArgumentException.class);
                   thrown.expectMessage("must have n >= 0 for n!");
                   MathUtils.factorial(-1);
               }

 @Test
               public void testFactorial_AboveMaximum() {
                   thrown.expect(ArithmeticException.class);
                   thrown.expectMessage("factorial value is too large to fit in a long");
                   MathUtils.factorial(21);  // Above the maximum allowed value of 20
               }

 @Test
               public void testFactorial_EdgeCases() {
                   // Test just below and at the boundary
                   assertEquals(109641728, MathUtils.factorial(14));  // 14! = 87178291200
                   assertEquals(1307674368000L, MathUtils.factorial(15)); // 15! = 1307674368000
                   
                   // Test values near the upper limit
                   assertEquals(6402373705728000L, MathUtils.factorial(18));
                   assertEquals(121645100408832000L, MathUtils.factorial(19));
               }

 @Test
               public void testFactorial_AllValidValues() {
                   // Test all valid values from 0 to 20
                   long[] expectedResults = {
                       1L,                   // 0!
                       1L,                   // 1!
                       2L,                   // 2!
                       6L,                   // 3!
                       24L,                  // 4!
                       120L,                 // 5!
                       720L,                 // 6!
                       5040L,                // 7!
                       40320L,               // 8!
                       362880L,              // 9!
                       3628800L,             // 10!
                       39916800L,            // 11!
                       479001600L,           // 12!
                       6227020800L,          // 13!
                       87178291200L,         // 14!
                       1307674368000L,       // 15!
                       20922789888000L,      // 16!
                       355687428096000L,     // 17!
                       6402373705728000L,    // 18!
                       121645100408832000L,  // 19!
                       2432902008176640000L   // 20!
                   };
                   
                   for (int i = 0; i <= 20; i++) {
                       assertEquals("Failed at n=" + i, expectedResults[i], MathUtils.factorial(i));
                   }
               }

 @Test
               public void testFactorialDouble_Zero() {
                   assertEquals(1.0, MathUtils.factorialDouble(0), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_SmallNumbers() {
                   // Test factorial for numbers 1-20 (using regular factorial calculation)
                   assertEquals(1.0, MathUtils.factorialDouble(1), MathUtils.EPSILON);
                   assertEquals(2.0, MathUtils.factorialDouble(2), MathUtils.EPSILON);
                   assertEquals(6.0, MathUtils.factorialDouble(3), MathUtils.EPSILON);
                   assertEquals(24.0, MathUtils.factorialDouble(4), MathUtils.EPSILON);
                   assertEquals(120.0, MathUtils.factorialDouble(5), MathUtils.EPSILON);
                   assertEquals(720.0, MathUtils.factorialDouble(6), MathUtils.EPSILON);
                   assertEquals(5040.0, MathUtils.factorialDouble(7), MathUtils.EPSILON);
                   assertEquals(40320.0, MathUtils.factorialDouble(8), MathUtils.EPSILON);
                   assertEquals(362880.0, MathUtils.factorialDouble(9), MathUtils.EPSILON);
                   assertEquals(3628800.0, MathUtils.factorialDouble(10), MathUtils.EPSILON);
                   assertEquals(39916800.0, MathUtils.factorialDouble(11), MathUtils.EPSILON);
                   assertEquals(479001600.0, MathUtils.factorialDouble(12), MathUtils.EPSILON);
                   assertEquals(6227020800.0, MathUtils.factorialDouble(13), MathUtils.EPSILON);
                   assertEquals(87178291200.0, MathUtils.factorialDouble(14), MathUtils.EPSILON);
                   assertEquals(1307674368000.0, MathUtils.factorialDouble(15), MathUtils.EPSILON);
                   assertEquals(20922789888000.0, MathUtils.factorialDouble(16), MathUtils.EPSILON);
                   assertEquals(355687428096000.0, MathUtils.factorialDouble(17), MathUtils.EPSILON);
                   assertEquals(6402373705728000.0, MathUtils.factorialDouble(18), MathUtils.EPSILON);
                   assertEquals(121645100408832000.0, MathUtils.factorialDouble(19), MathUtils.EPSILON);
                   assertEquals(2432902008176640000.0, MathUtils.factorialDouble(20), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_LargeNumbers() {
                   // Test factorial for numbers >=21 (using logarithmic approach)
                   // Using known factorial values for verification
                   assertEquals(5.109094217170944E19, MathUtils.factorialDouble(21), MathUtils.EPSILON);
                   assertEquals(1.1240007277776077E21, MathUtils.factorialDouble(22), MathUtils.EPSILON);
                   assertEquals(2.585201673888498E22, MathUtils.factorialDouble(23), MathUtils.EPSILON);
                   assertEquals(6.204484017332394E23, MathUtils.factorialDouble(24), MathUtils.EPSILON);
                   assertEquals(1.5511210043330986E25, MathUtils.factorialDouble(25), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_BoundaryCase() {
                   // Test the boundary between the two calculation methods (n=20 vs n=21)
                   double fact20 = MathUtils.factorialDouble(20);
                   double fact21 = MathUtils.factorialDouble(21);
                   assertEquals(21 * fact20, fact21, MathUtils.EPSILON * fact21);
               }

 @Test
               public void testFactorialLog_NegativeInput() {
                   thrown.expect(IllegalArgumentException.class);
                   thrown.expectMessage("must have n > 0 for n!");
                   MathUtils.factorialLog(-1);
               }

 @Test
               public void testFactorialLog_ZeroInput() {
                   // log(0!) = log(1) = 0
                   assertEquals(0.0, MathUtils.factorialLog(0), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_SmallValues() {
                   // Test values below 21 (uses factorial(n) directly)
                   assertEquals(Math.log(1), MathUtils.factorialLog(0), MathUtils.EPSILON);
                   assertEquals(Math.log(1), MathUtils.factorialLog(1), MathUtils.EPSILON);
                   assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
                   assertEquals(Math.log(6), MathUtils.factorialLog(3), MathUtils.EPSILON);
                   assertEquals(Math.log(24), MathUtils.factorialLog(4), MathUtils.EPSILON);
                   assertEquals(Math.log(120), MathUtils.factorialLog(5), MathUtils.EPSILON);
                   assertEquals(Math.log(2432902008176640000L), MathUtils.factorialLog(20), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_BoundaryValue() {
                   // Test boundary case where n = 20 (still uses factorial(n))
                   double expected = Math.log(2432902008176640000L);
                   assertEquals(expected, MathUtils.factorialLog(20), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_BoundaryValue1() {
                   // Test boundary case where n = 21 (switches to iterative log sum)
                   double expected = 0.0;
                   for (int i = 2; i <= 21; i++) {
                       expected += Math.log(i);
                   }
                   assertEquals(expected, MathUtils.factorialLog(21), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_LargeValues() {
                   // Test values above 20 (uses iterative log sum)
                   double expected30 = 0.0;
                   for (int i = 2; i <= 30; i++) {
                       expected30 += Math.log(i);
                   }
                   assertEquals(expected30, MathUtils.factorialLog(30), MathUtils.EPSILON);
                   
                   double expected50 = 0.0;
                   for (int i = 2; i <= 50; i++) {
                       expected50 += Math.log(i);
                   }
                   assertEquals(expected50, MathUtils.factorialLog(50), MathUtils.EPSILON);
                   
                   double expected100 = 0.0;
                   for (int i = 2; i <= 100; i++) {
                       expected100 += Math.log(i);
                   }
                   assertEquals(expected100, MathUtils.factorialLog(100), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_ConsistencyBetweenMethods() {
                   // Verify that for n < 21, factorialLog(n) equals log(factorial(n))
                   for (int n = 0; n < 21; n++) {
                       double expected = Math.log(MathUtils.factorial(n));
                       assertEquals(expected, MathUtils.factorialLog(n), MathUtils.EPSILON);
                   }
               }

 @Test
               public void testFactorialLog_MonotonicIncrease() {
                   // Verify that factorialLog(n) increases as n increases
                   double prev = MathUtils.factorialLog(0);
                   for (int n = 1; n <= 50; n++) {
                       double current = MathUtils.factorialLog(n);
                       assertTrue(current > prev);
                       prev = current;
                   }
               }

 @Test
       public void testFactorialDouble_NegativeInput() {
           ExpectedException exceptionRule = ExpectedException.none();
           exceptionRule.expect(IllegalArgumentException.class);
           exceptionRule.expectMessage("must have n >= 0 for n!");
           MathUtils.factorialDouble(-1);
       }

 @Test
       public void testFactorialLogBoundaryCondition() {
           // Test the boundary case where n=20
           // Original would use factorial(20), mutant would use summation
           // We need to verify both approaches give same result for n=20
           
           // Calculate expected value using both approaches
           double expectedFactorialApproach = Math.log(MathUtils.factorial(20));
           double expectedSummationApproach = 0.0;
           for (int i = 2; i <= 20; i++) {
               expectedSummationApproach += Math.log(i);
           }
           
           // Verify they're equal (should be for n=20)
           assertEquals(expectedFactorialApproach, expectedSummationApproach, 1e-10);
           
           // Now test the actual method - should match factorial approach
           double actual = MathUtils.factorialLog(20);
           assertEquals(expectedFactorialApproach, actual, 1e-10);
           
           // For the mutant (n < 20), the actual would use summation approach
           // and would differ from factorial approach due to floating point differences
           // This assertion would fail for the mutant
       }

 @Test
      public void testFactorialLogLoopStartsFrom() {
          // Test with n=1 (edge case)
          // Original: should return log(factorial(1)) = log(1) = 0
          // Mutant: would enter the loop and sum log(1) = 0 (same result but different path)
          
          // More effective test with n=2:
          // Original: sums log(2) (1 iteration)
          // Mutant: sums log(1) + log(2) (2 iterations)
          // Numerically same result but different computation path
          
          // To catch this, we need to verify the computation for n=21
          // where the original skips log(1) but mutant includes it
          double expected = Math.log(MathUtils.factorial(21));
          double actual = MathUtils.factorialLog(21);
          
          // The results will be numerically equal, so we need a different approach
          // We can verify that for n=1, the method doesn't enter the loop case
          assertEquals(0.0, MathUtils.factorialLog(1), 1e-10);
          
          // More precise test: verify that factorialLog(2) equals log(2)
          // This ensures the loop starts from 2 (not 1)
          assertEquals(Math.log(2), MathUtils.factorialLog(2), 1e-10);
          
          // Test with n=3 to ensure proper summation
          double expectedLog3 = Math.log(2) + Math.log(3);
          assertEquals(expectedLog3, MathUtils.factorialLog(3), 1e-10);
      }

 @Test
 public void testFactorialLogPrecisionForLargeN() {
     // Choose a value large enough to trigger the loop path (n >= 21)
     // and where float vs double precision would show difference
     int n = 100;
     
     // Calculate expected value by summing logs with double precision
     double expected = 0.0;
     for (int i = 2; i <= n; i++) {
         expected += Math.log((double)i);
     }
     
     // Get actual value from method
     double actual = MathUtils.factorialLog(n);
     
     // Verify the result matches expected value with high precision
     // Using a tight epsilon to catch float precision loss
     assertEquals(expected, actual, 1e-10);
     
     // Also verify the relative error is small
     double relativeError = Math.abs((actual - expected)/expected);
     assertTrue(relativeError < 1e-10);
 }

}
