package gentest.org.apache.commons.math.stat.descriptive.moment.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.moment.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.WeightedEvaluation;
import org.apache.commons.math.stat.descriptive.AbstractStorelessUnivariateStatistic;
import org.apache.commons.math.util.MathUtils;
 
public class VarianceTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                             public void testEvaluate_NullInput() {
                                 Variance variance = new Variance();
                                 thrown.expect(NullArgumentException.class);
                                 thrown.expectMessage(LocalizedFormats.INPUT_ARRAY.toString());
                                 variance.evaluate(null);
                             }

    @Test
                             public void testEvaluate_EmptyArray() {
                                 Variance variance = new Variance();
                                 double[] emptyArray = new double[0];
                                 assertEquals(Double.NaN, variance.evaluate(emptyArray), 0.0001);
                             }

    @Test
                             public void testEvaluate_SingleValueArray() {
                                 Variance variance = new Variance();
                                 double[] singleValue = {5.0};
                                 assertEquals(0.0, variance.evaluate(singleValue), 0.0001);
                             }

    @Test
                             public void testEvaluate_TypicalValues() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 // Expected variance for these values is 2.5 when bias corrected
                                 assertEquals(2.5, variance.evaluate(values), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithBiasCorrectionDisabled() {
                                 Variance variance = new Variance(false);
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 // Expected variance for these values is 2.0 when not bias corrected
                                 assertEquals(2.0, variance.evaluate(values), 0.0001);
                             }

    @Test
                             public void testEvaluate_IdenticalValues() {
                                 Variance variance = new Variance();
                                 double[] identicalValues = {3.0, 3.0, 3.0, 3.0};
                                 assertEquals(0.0, variance.evaluate(identicalValues), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithExternalSecondMoment() {
                                 SecondMoment mockMoment = mock(SecondMoment.class);
                                 when(mockMoment.getResult()).thenReturn(4.0);
                                 when(mockMoment.getN()).thenReturn(5L);
                                 
                                 Variance variance = new Variance(mockMoment);
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 
                                 // With bias correction: 4.0 * 5 / 4 = 5.0
                                 assertEquals(5.0, variance.evaluate(values), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithExternalSecondMomentAndNoBiasCorrection() {
                                 SecondMoment mockMoment = mock(SecondMoment.class);
                                 when(mockMoment.getResult()).thenReturn(4.0);
                                 when(mockMoment.getN()).thenReturn(5L);
                                 
                                 Variance variance = new Variance(false, mockMoment);
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 
                                 // Without bias correction: 4.0
                                 assertEquals(4.0, variance.evaluate(values), 0.0001);
                             }

    @Test
                             public void testEvaluate_ExtremeValues() {
                                 Variance variance = new Variance();
                                 double[] extremeValues = {Double.MAX_VALUE, Double.MAX_VALUE};
                                 assertEquals(0.0, variance.evaluate(extremeValues), 0.0001);
                                 
                                 double[] mixedExtremeValues = {Double.MAX_VALUE, -Double.MAX_VALUE};
                                 // Should be Double.POSITIVE_INFINITY due to overflow
                                 assertEquals(Double.POSITIVE_INFINITY, variance.evaluate(mixedExtremeValues), 0.0001);
                             }

    @Test
                             public void testEvaluate_NaNValues() {
                                 Variance variance = new Variance();
                                 double[] nanValues = {1.0, 2.0, Double.NaN, 4.0};
                                 assertEquals(Double.NaN, variance.evaluate(nanValues), 0.0001);
                             }

    @Test
                             public void testEvaluate_InfiniteValues() {
                                 Variance variance = new Variance();
                                 double[] infiniteValues = {1.0, 2.0, Double.POSITIVE_INFINITY, 4.0};
                                 assertEquals(Double.NaN, variance.evaluate(infiniteValues), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithBiasCorrection() {
                                 Variance biasedVariance = new Variance(true);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double result = biasedVariance.evaluate(values, 0, 4);
                                 assertEquals(1.25, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithoutBiasCorrection() {
                                 Variance unbiasedVariance = new Variance(false);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double result = unbiasedVariance.evaluate(values, 0, 4);
                                 assertEquals(1.666666, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithSecondMoment() {
                                 SecondMoment moment = mock(SecondMoment.class);
                                 when(moment.getResult()).thenReturn(2.0);
                                 when(moment.getN()).thenReturn(5L);
                                 
                                 Variance varianceWithMoment = new Variance(moment);
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double result = varianceWithMoment.evaluate(values, 0, 5);
                                 
                                 assertEquals(2.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithBiasCorrection1() {
                                 Variance correctedVariance = new Variance(true);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0};
                                 double result = correctedVariance.evaluate(values, weights, 0, 4);
                                 assertEquals(1.6666666666666667, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithoutBiasCorrection1() {
                                 Variance uncorrectedVariance = new Variance(false);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0};
                                 double result = uncorrectedVariance.evaluate(values, weights, 0, 4);
                                 assertEquals(1.25, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithMockedMean() {
                                 Mean mockMean = mock(Mean.class);
                                 when(mockMean.evaluate(any(double[].class), any(double[].class), anyInt(), anyInt()))
                                     .thenReturn(3.0);
                                 
                                 Variance varianceWithMock = new Variance();
                                 // This is a bit tricky since Mean is created internally, but shows the concept
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                 double result = varianceWithMock.evaluate(values, weights, 0, 5);
                                 // Actual calculation would use the real mean, but this shows how we might test with mocks
                                 assertEquals(2.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithValuesAndWeights() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {0.5, 0.5, 0.5, 0.5};
                                 
                                 double result = variance.evaluate(values, weights);
                                 
                                 // Verify the result is calculated correctly
                                 // Expected variance calculation with weights
                                 double expected = 1.25;
                                 assertEquals(expected, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithNullValuesArray() {
                                 Variance variance = new Variance();
                                 double[] weights = {0.5, 0.5};
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("input array");
                                 
                                 variance.evaluate(null, weights);
                             }

    @Test
                             public void testEvaluate_WithNullWeightsArray() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0};
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("weights array");
                                 
                                 variance.evaluate(values, null);
                             }

    @Test
                             public void testEvaluate_WithEmptyArrays() {
                                 Variance variance = new Variance();
                                 double[] values = {};
                                 double[] weights = {};
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("empty array");
                                 
                                 variance.evaluate(values, weights);
                             }

    @Test
                             public void testEvaluate_WithDifferentLengthArrays() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0};
                                 double[] weights = {0.5, 0.5};
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("same length");
                                 
                                 variance.evaluate(values, weights);
                             }

    @Test
                             public void testEvaluate_WithZeroWeights() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0};
                                 double[] weights = {0.0, 0.0, 0.0};
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("weights cannot contain 0");
                                 
                                 variance.evaluate(values, weights);
                             }

    @Test
                             public void testEvaluate_WithSingleValue() {
                                 Variance variance = new Variance();
                                 double[] values = {5.0};
                                 double[] weights = {1.0};
                                 
                                 double result = variance.evaluate(values, weights);
                                 
                                 // Variance of single value should be 0
                                 assertEquals(0.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithBiasCorrection2() {
                                 Variance variance = new Variance(true); // bias corrected
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0};
                                 
                                 double result = variance.evaluate(values, weights);
                                 
                                 // Expected sample variance (bias corrected)
                                 double expected = 1.6666666666666667;
                                 assertEquals(expected, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithoutBiasCorrection2() {
                                 Variance variance = new Variance(false); // not bias corrected
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0};
                                 
                                 double result = variance.evaluate(values, weights);
                                 
                                 // Expected population variance (not bias corrected)
                                 double expected = 1.25;
                                 assertEquals(expected, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithCustomSecondMoment() {
                                 SecondMoment mockMoment = mock(SecondMoment.class);
                                 when(mockMoment.getResult()).thenReturn(2.5);
                                 when(mockMoment.getN()).thenReturn(4L);
                                 
                                 Variance variance = new Variance(mockMoment);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0};
                                 
                                 double result = variance.evaluate(values, weights);
                                 
                                 // Verify the mock was used and result calculated correctly
                                 verify(mockMoment).increment(anyDouble());
                                 assertEquals(2.5, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_NoBiasCorrection() {
                                 Variance variance = new Variance(false); // disable bias correction
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double mean = 3.0; // mean of the values
                                 
                                 // Expected calculation:
                                 // sum of squared deviations = (1-3)² + (2-3)² + (3-3)² + (4-3)² + (5-3)² = 10
                                 // variance = 10 / 5 = 2.0
                                 double result = variance.evaluate(values, mean, 0, values.length);
                                 assertEquals(2.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithBiasCorrection3() {
                                 Variance variance = new Variance(true); // enable bias correction
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double mean = 3.0;
                                 
                                 // Expected calculation:
                                 // sum of squared deviations = 10 (same as above)
                                 // variance = 10 / (5-1) = 2.5
                                 double result = variance.evaluate(values, mean, 0, values.length);
                                 assertEquals(2.5, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_SingleElement() {
                                 Variance variance = new Variance();
                                 double[] values = {5.0};
                                 double mean = 5.0;
                                 
                                 // Should return 0.0 for single element
                                 double result = variance.evaluate(values, mean, 0, values.length);
                                 assertEquals(0.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_EmptyArray1() {
                                 Variance variance = new Variance();
                                 double[] values = {};
                                 double mean = 0.0;
                                 
                                 double result = variance.evaluate(values, mean, 0, values.length);
                                 assertTrue(Double.isNaN(result));
                             }

    @Test
                             public void testEvaluate_NullArray() {
                                 Variance variance = new Variance();
                                 thrown.expect(IllegalArgumentException.class);
                                 variance.evaluate(null, 0.0, 0, 0);
                             }

    @Test
                             public void testEvaluate_InvalidBeginIndex() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0};
                                 thrown.expect(IllegalArgumentException.class);
                                 variance.evaluate(values, 2.0, -1, values.length);
                             }

    @Test
                             public void testEvaluate_InvalidLength() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0};
                                 thrown.expect(IllegalArgumentException.class);
                                 variance.evaluate(values, 2.0, 0, values.length + 1);
                             }

    @Test
                             public void testEvaluate_ArraySubset() {
                                 Variance variance = new Variance(true);
                                 double[] values = {10.0, 20.0, 30.0, 40.0, 50.0};
                                 double mean = 30.0; // mean of subset [20,30,40]
                                 
                                 // Testing subset from index 1 to 3 (values 20,30,40)
                                 // sum of squared deviations = (20-30)² + (30-30)² + (40-30)² = 200
                                 // variance = 200 / (3-1) = 100
                                 double result = variance.evaluate(values, mean, 1, 3);
                                 assertEquals(100.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithNaNValues() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, Double.NaN, 3.0};
                                 double result = variance.evaluate(values, 2.0, 0, values.length);
                                 assertTrue(Double.isNaN(result));
                             }

    @Test
                             public void testEvaluate_WithInfiniteValues() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                 double result = variance.evaluate(values, 2.0, 0, values.length);
                                 assertTrue(Double.isInfinite(result) || Double.isNaN(result));
                             }

    @Test
                             public void testEvaluate_WithMean_EmptyArray() {
                                 Variance variance = new Variance();
                                 double[] values = {};
                                 double mean = 0.0;
                                 
                                 // Should return NaN for empty array
                                 assertTrue(Double.isNaN(variance.evaluate(values, mean)));
                             }

    @Test
                             public void testEvaluate_WithMean_SingleValue() {
                                 Variance variance = new Variance();
                                 double[] values = {5.0};
                                 double mean = 5.0;
                                 
                                 // Variance of single value should be 0
                                 assertEquals(0.0, variance.evaluate(values, mean), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithMean_TypicalValues() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double mean = 3.0;
                                 
                                 // Expected variance calculation
                                 double expected = 2.5; // sum of squared differences / n
                                 assertEquals(expected, variance.evaluate(values, mean), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithMean_BiasCorrected() {
                                 Variance variance = new Variance(true); // bias corrected
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double mean = 3.0;
                                 
                                 // Expected variance calculation with Bessel's correction
                                 double expected = 2.5 * (values.length / (values.length - 1.0));
                                 assertEquals(expected, variance.evaluate(values, mean), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithMean_NotBiasCorrected() {
                                 Variance variance = new Variance(false); // not bias corrected
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double mean = 3.0;
                                 
                                 // Expected variance calculation without Bessel's correction
                                 double expected = 2.5; // sum of squared differences / n
                                 assertEquals(expected, variance.evaluate(values, mean), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithMean_NullArray() {
                                 Variance variance = new Variance();
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("input array");
                                 
                                 variance.evaluate(null, 0.0);
                             }

    @Test
                             public void testEvaluate_WithMean_WithMockedMoment() {
                                 SecondMoment mockMoment = mock(SecondMoment.class);
                                 when(mockMoment.getResult()).thenReturn(4.0);
                                 when(mockMoment.getN()).thenReturn(5L);
                                 
                                 Variance variance = new Variance(mockMoment);
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double mean = 3.0;
                                 
                                 // Should use the SecondMoment's result
                                 double result = variance.evaluate(values, mean);
                                 
                                 verify(mockMoment).getResult();
                                 verify(mockMoment).getN();
                                 // Since we mocked the moment, we expect its result
                                 assertEquals(4.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithMean_ExtremeValues() {
                                 Variance variance = new Variance();
                                 double[] values = {Double.MAX_VALUE, Double.MAX_VALUE};
                                 double mean = Double.MAX_VALUE;
                                 
                                 // Variance of identical extreme values should be 0
                                 assertEquals(0.0, variance.evaluate(values, mean), 0.0001);
                             }

    @Test
                             public void testEvaluate_WithMean_NaNValues() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, Double.NaN, 3.0};
                                 double mean = Double.NaN;
                                 
                                 // Should return NaN if any value is NaN
                                 assertTrue(Double.isNaN(variance.evaluate(values, mean)));
                             }

    @Test
                             public void testEvaluate_WithMean_InfiniteValues() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                 double mean = Double.POSITIVE_INFINITY;
                                 
                                 // Should return infinity if any value is infinite
                                 assertTrue(Double.isInfinite(variance.evaluate(values, mean)));
                             }

    @Test
                             public void testEvaluate_LengthOne_ReturnsZero() {
                                 Variance variance = new Variance(true); // bias corrected
                                 double[] values = {5.0};
                                 double[] weights = {1.0};
                                 double result = variance.evaluate(values, weights, 0, 1);
                                 assertEquals(0.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_BiasCorrected_CalculatesCorrectVariance() {
                                 Variance variance = new Variance(true);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0};
                                 double mean = 2.5;
                                 double result = variance.evaluate(values, weights, mean, 0, values.length);
                                 assertEquals(1.6667, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_NotBiasCorrected_CalculatesCorrectVariance() {
                                 Variance variance = new Variance(false);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0};
                                 double mean = 2.5;
                                 double result = variance.evaluate(values, weights, mean, 0, values.length);
                                 assertEquals(1.25, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WeightedValues_CalculatesCorrectVariance() {
                                 Variance variance = new Variance(true);
                                 double[] values = {1.0, 2.0, 3.0, 4.0};
                                 double[] weights = {0.5, 0.5, 1.0, 1.0};
                                 double mean = 2.5;
                                 double result = variance.evaluate(values, weights, mean, 0, values.length);
                                 assertEquals(1.3571, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_SubsetOfArray_CalculatesCorrectVariance() {
                                 Variance variance = new Variance(true);
                                 double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
                                 double[] weights = {0.0, 1.0, 1.0, 1.0, 1.0, 0.0};
                                 double mean = 2.5;
                                 double result = variance.evaluate(values, weights, mean, 1, 4);
                                 assertEquals(1.6667, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_InvalidInput_ReturnsNaN() {
                                 Variance variance = new Variance(true);
                                 double[] values = {1.0};
                                 double[] weights = {1.0, 2.0}; // length mismatch
                                 double result = variance.evaluate(values, weights, 0, 0, values.length);
                                 assertTrue(Double.isNaN(result));
                             }

    @Test
                             public void testEvaluate_ZeroWeights_ReturnsNaN() {
                                 Variance variance = new Variance(true);
                                 double[] values = {1.0, 2.0};
                                 double[] weights = {0.0, 0.0};
                                 double result = variance.evaluate(values, weights, 1.5, 0, values.length);
                                 assertTrue(Double.isNaN(result));
                             }

    @Test
                             public void testEvaluate_NullValues_ThrowsException() {
                                 thrown.expect(IllegalArgumentException.class);
                                 Variance variance = new Variance(true);
                                 variance.evaluate(null, new double[1], 0.0, 0, 1);
                             }

    @Test
                             public void testEvaluate_NullWeights_ThrowsException() {
                                 thrown.expect(IllegalArgumentException.class);
                                 Variance variance = new Variance(true);
                                 variance.evaluate(new double[1], null, 0.0, 0, 1);
                             }

    @Test
                             public void testEvaluate_InvalidBegin_ThrowsException() {
                                 thrown.expect(IllegalArgumentException.class);
                                 Variance variance = new Variance(true);
                                 variance.evaluate(new double[5], new double[5], 0.0, -1, 1);
                             }

    @Test
                             public void testEvaluate_InvalidLength_ThrowsException() {
                                 thrown.expect(IllegalArgumentException.class);
                                 Variance variance = new Variance(true);
                                 variance.evaluate(new double[5], new double[5], 0.0, 0, -1);
                             }

    @Test
                             public void testEvaluate_InvalidRange_ThrowsException() {
                                 thrown.expect(IllegalArgumentException.class);
                                 Variance variance = new Variance(true);
                                 variance.evaluate(new double[5], new double[5], 0.0, 3, 3);
                             }

    @Test
                             public void testEvaluate_WithValidInputs() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                 double mean = 3.0;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // Expected variance calculation for unweighted data with known mean
                                 assertEquals(2.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithWeightedInputs() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double[] weights = {0.5, 0.5, 1.0, 1.0, 1.0};
                                 double mean = 3.0;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // Expected weighted variance calculation
                                 assertEquals(1.7142857142857142, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithEmptyArrays1() {
                                 Variance variance = new Variance();
                                 double[] values = {};
                                 double[] weights = {};
                                 double mean = 0.0;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 variance.evaluate(values, weights, mean);
                             }

    @Test
                             public void testEvaluate_WithNullValuesArray1() {
                                 Variance variance = new Variance();
                                 double[] weights = {1.0, 1.0};
                                 double mean = 0.0;
                                 
                                 thrown.expect(NullPointerException.class);
                                 variance.evaluate(null, weights, mean);
                             }

    @Test
                             public void testEvaluate_WithNullWeightsArray1() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0};
                                 double mean = 0.0;
                                 
                                 thrown.expect(NullPointerException.class);
                                 variance.evaluate(values, null, mean);
                             }

    @Test
                             public void testEvaluate_WithArraysOfDifferentLengths() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0};
                                 double[] weights = {1.0, 1.0};
                                 double mean = 0.0;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 variance.evaluate(values, weights, mean);
                             }

    @Test
                             public void testEvaluate_WithZeroWeights1() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0};
                                 double[] weights = {0.0, 0.0, 0.0};
                                 double mean = 2.0;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 variance.evaluate(values, weights, mean);
                             }

    @Test
                             public void testEvaluate_WithNegativeWeights() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, 2.0, 3.0};
                                 double[] weights = {1.0, -1.0, 1.0};
                                 double mean = 2.0;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 variance.evaluate(values, weights, mean);
                             }

    @Test
                             public void testEvaluate_WithSingleValue1() {
                                 Variance variance = new Variance();
                                 double[] values = {5.0};
                                 double[] weights = {1.0};
                                 double mean = 5.0;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // Variance of a single value should be 0
                                 assertEquals(0.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithBiasCorrection4() {
                                 Variance variance = new Variance(true); // bias corrected
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                 double mean = 3.0;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // With bias correction, the denominator is (n-1) instead of n
                                 assertEquals(2.5, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithoutBiasCorrection3() {
                                 Variance variance = new Variance(false); // not bias corrected
                                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                 double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                 double mean = 3.0;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // Without bias correction, the denominator is n
                                 assertEquals(2.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithExtremeValues() {
                                 Variance variance = new Variance();
                                 double[] values = {Double.MAX_VALUE, Double.MAX_VALUE};
                                 double[] weights = {1.0, 1.0};
                                 double mean = Double.MAX_VALUE;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // Variance of two identical extreme values should be 0
                                 assertEquals(0.0, result, 0.0001);
                             }

    @Test
                             public void testEvaluate_WithNaNValues1() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, Double.NaN, 3.0};
                                 double[] weights = {1.0, 1.0, 1.0};
                                 double mean = 2.0;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // Should propagate NaN
                                 assertTrue(Double.isNaN(result));
                             }

    @Test
                             public void testEvaluate_WithInfiniteValues1() {
                                 Variance variance = new Variance();
                                 double[] values = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                 double[] weights = {1.0, 1.0, 1.0};
                                 double mean = Double.POSITIVE_INFINITY;
                                 
                                 double result = variance.evaluate(values, weights, mean);
                                 
                                 // Should propagate infinity or NaN
                                 assertTrue(Double.isInfinite(result) || Double.isNaN(result));
                             }

    @Test
                 public void testEvaluate_LargeValues() {
                     Variance variance = new Variance(true);
                     // Scale down the values to avoid floating point overflow
                     double scaleFactor = 1.0e-100;
                     double[] values = {1.0e200 * scaleFactor, 2.0e200 * scaleFactor, 3.0e200 * scaleFactor};
                     double mean = 2.0e200 * scaleFactor;
                     
                     // Expected variance calculation:
                     // sum of squared deviations = (1e100-2e100)² + (2e100-2e100)² + (3e100-2e100)² = 2e200
                     // variance = 2e200 / (3-1) = 1e200
                     double result = variance.evaluate(values, mean, 0, values.length);
                     assertEquals(1.0e200, result, 1.0e185); // Using large delta due to floating point precision
                 }

    @Test
             public void testEvaluate_EmptyArray2() {
                 Variance variance = new Variance();
                 double[] values = {};
                 double result = variance.evaluate(values, 0, 0);
                 assertTrue(Double.isNaN(result));
             }

    @Test
             public void testEvaluate_SingleElement1() {
                 Variance variance = new Variance();
                 double[] values = {5.0};
                 double result = variance.evaluate(values, 0, 1);
                 assertEquals(0.0, result, 0.0001);
             }

    @Test
             public void testEvaluate_TwoElements() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 3.0};
                 double result = variance.evaluate(values, 0, 2);
                 assertEquals(1.0, result, 0.0001);
             }

    @Test
             public void testEvaluate_MultipleElements() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                 double result = variance.evaluate(values, 0, 5);
                 assertEquals(2.0, result, 0.0001);
             }

    @Test
             public void testEvaluate_SubsetOfArray() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                 double result = variance.evaluate(values, 1, 3);
                 assertEquals(0.666666, result, 0.0001);
             }

    @Test
             public void testEvaluate_WithNegativeValues() {
                 Variance variance = new Variance();
                 double[] values = {-2.0, -1.0, 0.0, 1.0, 2.0};
                 double result = variance.evaluate(values, 0, 5);
                 assertEquals(2.0, result, 0.0001);
             }

    @Test
             public void testEvaluate_InvalidBeginIndex1() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0};
                 double result = variance.evaluate(values, -1, 2);
                 assertTrue(Double.isNaN(result));
             }

    @Test
             public void testEvaluate_InvalidLength1() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0};
                 double result = variance.evaluate(values, 0, 4);
                 assertTrue(Double.isNaN(result));
             }

    @Test
             public void testEvaluate_WithNullArray() {
                 Variance variance = new Variance();
                 double result = variance.evaluate(null, 0, 1);
                 assertTrue(Double.isNaN(result));
             }

    @Test
             public void testEvaluate_LengthOneReturnsZero() {
                 Variance variance = new Variance();
                 double[] values = {5.0};
                 double[] weights = {1.0};
                 double result = variance.evaluate(values, weights, 0, 1);
                 assertEquals(0.0, result, 0.0001);
             }

    @Test
             public void testEvaluate_ValidInputCalculatesCorrectVariance() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                 double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                 double result = variance.evaluate(values, weights, 0, 5);
                 assertEquals(2.0, result, 0.0001);
             }

    @Test
             public void testEvaluate_WeightedInputCalculatesCorrectVariance() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0, 4.0};
                 double[] weights = {1.0, 2.0, 3.0, 4.0};
                 double result = variance.evaluate(values, weights, 0, 4);
                 assertEquals(1.6666666666666667, result, 0.0001);
             }

    @Test
             public void testEvaluate_SubsetOfArrayCalculatesCorrectVariance() {
                 Variance variance = new Variance();
                 double[] values = {10.0, 20.0, 30.0, 40.0, 50.0};
                 double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                 double result = variance.evaluate(values, weights, 1, 3);
                 assertEquals(66.66666666666667, result, 0.0001);
             }

    @Test
             public void testEvaluate_InvalidBeginOrLengthReturnsNaN() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0};
                 double[] weights = {1.0, 1.0, 1.0};
                 
                 // Begin index out of bounds
                 double result1 = variance.evaluate(values, weights, 5, 1);
                 assertTrue(Double.isNaN(result1));
                 
                 // Length too large
                 double result2 = variance.evaluate(values, weights, 0, 5);
                 assertTrue(Double.isNaN(result2));
                 
                 // Negative begin index
                 double result3 = variance.evaluate(values, weights, -1, 2);
                 assertTrue(Double.isNaN(result3));
                 
                 // Negative length
                 double result4 = variance.evaluate(values, weights, 0, -1);
                 assertTrue(Double.isNaN(result4));
             }

    @Test
             public void testEvaluate_NullInputReturnsNaN() {
                 Variance variance = new Variance();
                 assertTrue(Double.isNaN(variance.evaluate(null, null, 0, 0)));
             }

    @Test
             public void testEvaluate_EmptyArrayReturnsNaN() {
                 Variance variance = new Variance();
                 double[] emptyValues = {};
                 double[] emptyWeights = {};
                 assertTrue(Double.isNaN(variance.evaluate(emptyValues, emptyWeights, 0, 0)));
             }

    @Test
             public void testEvaluate_WeightsLengthMismatchReturnsNaN() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0};
                 double[] weights = {1.0, 1.0}; // One weight missing
                 assertTrue(Double.isNaN(variance.evaluate(values, weights, 0, 3)));
             }

    @Test
             public void testEvaluate_ZeroWeightsReturnsNaN() {
                 Variance variance = new Variance();
                 double[] values = {1.0, 2.0, 3.0};
                 double[] weights = {0.0, 0.0, 0.0};
                 assertTrue(Double.isNaN(variance.evaluate(values, weights, 0, 3)));
             }

    @Test
         public void testEvaluateWithVaryingWeights() {
             Variance variance = new Variance();
             double[] values = {1.0, 2.0, 3.0, 4.0};  // Test values
             double[] weights = {0.1, 0.2, 0.3, 0.4}; // Varying weights
             int begin = 1;  // Start from index 1
             int length = 3;  // Use 3 elements (indices 1-3)
             
             // Calculate expected weighted variance manually
             double sum = 0;
             double sumWeights = 0;
             double sumWeightedValues = 0;
             double sumWeightedSquares = 0;
             
             for (int i = begin; i < begin + length; i++) {
                 sum += values[i];
                 sumWeights += weights[i];
                 sumWeightedValues += values[i] * weights[i];
                 sumWeightedSquares += values[i] * values[i] * weights[i];
             }
             
             double weightedMean = sumWeightedValues / sumWeights;
             double expectedWeightedVariance = (sumWeightedSquares - sumWeightedValues * weightedMean) / sumWeights;
             
             // Test with weights
             double actualWeighted = variance.evaluate(values, weights, begin, length);
             
             // Test without weights (should be different)
             double actualUnweighted = variance.evaluate(values, begin, length);
             
             // Assert weighted calculation matches manual calculation
             assertEquals(expectedWeightedVariance, actualWeighted, 1e-10);
             
             // Assert weighted and unweighted results are different (would fail if weights aren't applied properly)
             assertNotEquals(actualUnweighted, actualWeighted, 1e-10);
         }

    @Test
         public void testEvaluateWithDifferentWeightsShouldDetectWeightSumMutation() {
             // Setup
             Variance variance = new Variance();
             double[] values = {1.0, 2.0, 3.0, 4.0};  // Any values will work
             double[] weights = {0.1, 0.2, 0.3, 0.4};  // Different weights to detect mutation
             int begin = 0;
             int length = values.length;
             
             // Calculate expected variance manually
             double sumWeights = 0.0;
             double sumWeightedValues = 0.0;
             double sumWeightedSquares = 0.0;
             
             for (int i = begin; i < begin + length; i++) {
                 sumWeights += weights[i];
                 sumWeightedValues += weights[i] * values[i];
                 sumWeightedSquares += weights[i] * values[i] * values[i];
             }
             
             double mean = sumWeightedValues / sumWeights;
             double expectedVariance = (sumWeightedSquares - sumWeightedValues * mean) / sumWeights;
             
             // Test
             double actualVariance = variance.evaluate(values, weights, begin, length);
             
             // Assert
             assertEquals("Variance calculation with different weights should be correct", 
                         expectedVariance, actualVariance, 1e-10);
         }

    @Test
         public void testEvaluateWithDifferentWeightsShouldDetectMutant() {
             // Create Variance instance
             Variance variance = new Variance();
             
             // Test data with different weights
             double[] values = {1.0, 2.0, 3.0, 4.0};
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
             
             // Calculate expected result manually
             // Original behavior would sum weights as 0.5 + 1.0 + 1.5 + 2.0 = 5.0
             // Mutated behavior would sum weights as 0.5 + 0.5 + 0.5 + 0.5 = 2.0 (incorrect)
             
             // Call the method
             double result = variance.evaluate(values, weights, 0, values.length);
             
             // Verify the result is calculated with correct weight summation
             // We can't predict exact variance value, but we know mutated version would give wrong result
             // So we'll use a known correct value from manual calculation
             
             // Manual calculation of weighted variance:
             double weightedSum = 0;
             double sumWeights = 0;
             double sumWeightedValues = 0;
             double sumWeightedValuesSquared = 0;
             
             for (int i = 0; i < values.length; i++) {
                 weightedSum += values[i] * weights[i];
                 sumWeights += weights[i];
                 sumWeightedValues += values[i] * weights[i];
                 sumWeightedValuesSquared += values[i] * values[i] * weights[i];
             }
             
             double mean = sumWeightedValues / sumWeights;
             double expectedVariance = (sumWeightedValuesSquared - sumWeights * mean * mean) / sumWeights;
             
             assertEquals(expectedVariance, result, 0.0001);
         }

    @Test
         public void testEvaluateWithVaryingWeights1() {
             // Setup
             Variance variance = new Variance(true); // bias corrected
             double[] values = {1.0, 2.0, 3.0, 4.0}; // test values
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // varying weights
             double mean = 2.5; // mean value
             int begin = 1;
             int length = 3; // test subset from index 1 to 3
             
             // Calculate expected result manually
             double accum = 0.0;
             double accum2 = 0.0;
             double sumWts = 0.0;
             for (int i = begin; i < begin + length; i++) {
                 double dev = values[i] - mean;
                 accum += weights[i] * dev * dev;
                 accum2 += weights[i] * dev;
                 sumWts += weights[i];
             }
             double expected = (accum - (accum2 * accum2 / sumWts)) / (sumWts - 1.0);
             
             // Test
             double actual = variance.evaluate(values, weights, mean, begin, length);
             
             // Assert
             assertEquals("Variance with varying weights should be calculated correctly", 
                         expected, actual, 1e-10);
         }

    @Test
         public void testEvaluateWithDifferentWeightsShouldDetectMutant1() {
             // Setup
             Variance variance = new Variance();
             double[] values = {1.0, 2.0, 3.0, 4.0};
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
             double mean = 2.5;
             int begin = 0;
             int length = 4;
             
             // Expected behavior: should properly accumulate different weights
             // Mutant behavior: will incorrectly use weights[0] for all elements
             
             // Calculate expected sum of weights manually
             double expectedSumWeights = 0.5 + 1.0 + 1.5 + 2.0;
             
             // Calculate expected weighted variance manually
             double expected = (0.5*Math.pow(1.0-2.5, 2) + 
                               1.0*Math.pow(2.0-2.5, 2) + 
                               1.5*Math.pow(3.0-2.5, 2) + 
                               2.0*Math.pow(4.0-2.5, 2)) / expectedSumWeights;
             
             // Test
             double result = variance.evaluate(values, weights, mean, begin, length);
             
             // Assert
             assertEquals("Weighted variance calculation should be correct", 
                         expected, result, 0.0001);
             
             // This will fail with the mutant since it would calculate:
             // sumWts = 0.5 + 0.5 + 0.5 + 0.5 = 2.0 (incorrect)
             // and the numerator would also be incorrect
         }

    @Test
         public void testEvaluateWithNonUniformWeightsDetectsSumWeightsMutant() {
             // Create variance calculator with bias correction
             Variance variance = new Variance(true);
             
             // Test data with non-uniform weights
             double[] values = {1.0, 2.0, 3.0, 4.0};  // Values don't matter much for this test
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights to expose the mutation
             double mean = 2.5; // Arbitrary mean for testing
             int begin = 1;
             int length = 3; // Will process weights[1], weights[2], weights[3]
             
             // Calculate expected sum of weights (1.0 + 1.5 + 2.0 = 4.5)
             // The mutation would calculate it as 3 * weights[1] = 3.0
             
             // Calculate expected variance manually:
             // For bias corrected case, denominator is (sumWts - 1) = 3.5
             // accum = 1.0*(2.0-2.5)^2 + 1.5*(3.0-2.5)^2 + 2.0*(4.0-2.5)^2 = 0.25 + 0.375 + 4.5 = 5.125
             // accum2 = 1.0*(-0.5) + 1.5*(0.5) + 2.0*(1.5) = -0.5 + 0.75 + 3.0 = 3.25
             // numerator = 5.125 - (3.25^2)/4.5 ≈ 5.125 - 2.347 ≈ 2.778
             // expected = 2.778 / 3.5 ≈ 0.7937
             
             double result = variance.evaluate(values, weights, mean, begin, length);
             
             // With the mutation, sumWts would be 3.0 instead of 4.5
             // numerator would be same (since accum and accum2 calculations are correct)
             // denominator would be 2.0 instead of 3.5
             // mutated result would be 2.778 / 2.0 ≈ 1.389
             
             // Assert with delta to account for floating point precision
             assertEquals(0.7937, result, 0.0001);
             
             // This assertion will fail if the mutation is present because:
             // - Correct calculation gives ≈0.7937
             // - Mutated calculation gives ≈1.389
             // The difference is large enough to be detected
         }

    @Test
        public void testEvaluateWithDifferentWeightsShouldDetectMutant2() {
            // Create test data with varying weights
            double[] values = {1.0, 2.0, 3.0, 4.0};
            double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights at each index
            double mean = 2.5;
            int begin = 1;
            int length = 3; // Test subset of the array
            
            Variance variance = new Variance();
            
            // Calculate expected result manually for first test case
            double sumSquaredDeviations = 0;
            double sumWeights = 0;
            for (int i = begin; i < begin + length; i++) {
                double deviation = values[i] - mean;
                sumSquaredDeviations += weights[i] * deviation * deviation;
                sumWeights += weights[i];
            }
            double expectedVariance = sumSquaredDeviations / sumWeights;
            
            double actualVariance = variance.evaluate(values, weights, mean, begin, length);
            
            assertEquals("Variance calculation with varying weights should be correct", 
                        expectedVariance, actualVariance, 0.0001);
            
            // Alternative test that would catch the mutant:
            // Use weights where weights[begin] is different from other weights
            double[] values2 = {1.0, 2.0, 3.0};
            double[] weights2 = {1.0, 2.0, 1.0}; // weights[1] is different
            begin = 1;
            length = 2;
            
            // Calculate expected result manually for second test case
            sumSquaredDeviations = 0;
            sumWeights = 0;
            for (int i = begin; i < begin + length; i++) {
                double deviation = values2[i] - mean;
                sumSquaredDeviations += weights2[i] * deviation * deviation;
                sumWeights += weights2[i];
            }
            double expected2 = sumSquaredDeviations / sumWeights;
            
            double actual2 = variance.evaluate(values2, weights2, mean, begin, length);
            
            assertEquals("Should properly handle different weights in subset", 
                        expected2, actual2, 0.0001);
        }

    @Test
    public void testEvaluateWithWeightsAndRangeShouldSumCorrectWeights() {
        // Setup
        Variance variance = new Variance();
        double[] values = {1.0, 2.0, 3.0, 4.0};
        double[] weights = {0.1, 0.2, 0.3, 0.4};
        
        // Test with subset of array (indices 1-2)
        double result = variance.evaluate(values, weights, 1, 2);
        
        // Verify correct weight sum (0.2 + 0.3 = 0.5)
        // The mutant would use weights[1] twice (0.2 + 0.2 = 0.4)
        double expectedWeightSum = 0.5;
        
        // Calculate expected variance manually
        double weightedSum = 2.0*0.2 + 3.0*0.3;
        double weightedMean = weightedSum / expectedWeightSum;
        double expectedVariance = (0.2*Math.pow(2.0-weightedMean, 2) + 
                                0.3*Math.pow(3.0-weightedMean, 2)) / expectedWeightSum;
        
        assertEquals(expectedVariance, result, 1e-10);
    }


}
