package gentest.org.apache.commons.math3.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testReciprocal_NaN() {
            Complex nan = new Complex(Double.NaN, Double.NaN);
            Complex result = nan.reciprocal();
            assertTrue(result.isNaN());
        }

    @Test
        public void testReciprocal_Zero() {
            Complex zero = new Complex(0.0, 0.0);
            Complex result = zero.reciprocal();
            assertTrue(result.isInfinite());
            assertEquals(Complex.INF, result);
        }

    @Test
        public void testReciprocal_Infinite() {
            Complex inf = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
            Complex result = inf.reciprocal();
            assertEquals(Complex.ZERO, result);
        }

    @Test
        public void testReciprocal_RealDominant() {
            // Case where |real| >= |imaginary|
            Complex c = new Complex(4.0, 2.0);
            Complex result = c.reciprocal();
            
            double expectedReal = 4.0 / (4.0*4.0 + 2.0*2.0);
            double expectedImaginary = -2.0 / (4.0*4.0 + 2.0*2.0);
            
            assertEquals(expectedReal, result.getReal(), 1e-10);
            assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_ImaginaryDominant() {
            // Case where |real| < |imaginary|
            Complex c = new Complex(2.0, 4.0);
            Complex result = c.reciprocal();
            
            double q = 2.0 / 4.0;
            double scale = 1.0 / (2.0 * q + 4.0);
            double expectedReal = scale * q;
            double expectedImaginary = -scale;
            
            assertEquals(expectedReal, result.getReal(), 1e-10);
            assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_RealOnly() {
            Complex c = new Complex(5.0, 0.0);
            Complex result = c.reciprocal();
            assertEquals(0.2, result.getReal(), 1e-10);
            assertEquals(0.0, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_ImaginaryOnly() {
            Complex c = new Complex(0.0, 5.0);
            Complex result = c.reciprocal();
            assertEquals(0.0, result.getReal(), 1e-10);
            assertEquals(-0.2, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_One() {
            Complex one = Complex.ONE;
            Complex result = one.reciprocal();
            assertEquals(1.0, result.getReal(), 1e-10);
            assertEquals(0.0, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_I() {
            Complex i = Complex.I;
            Complex result = i.reciprocal();
            assertEquals(0.0, result.getReal(), 1e-10);
            assertEquals(-1.0, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_NegativeValues() {
            Complex c = new Complex(-3.0, -4.0);
            Complex result = c.reciprocal();
            
            double expectedReal = -3.0 / (9.0 + 16.0);
            double expectedImaginary = 4.0 / (9.0 + 16.0);
            
            assertEquals(expectedReal, result.getReal(), 1e-10);
            assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
        }

    @Test
        public void testReciprocal_SmallValues() {
            Complex c = new Complex(1e-10, 1e-20);
            Complex result = c.reciprocal();
            
            // Should use real-dominant path
            double expectedReal = 1e-10 / (1e-20 + 1e-40);
            double expectedImaginary = -1e-20 / (1e-20 + 1e-40);
            
            assertEquals(expectedReal, result.getReal(), 1e-10);
            assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
        }

}
