package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                            public void testTan_NaNReal() {
                                                                                                                                                Complex complex = new Complex(Double.NaN, 1.0);
                                                                                                                                                assertEquals(Complex.NaN, complex.tan());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_NaNImaginary() {
                                                                                                                                                Complex complex = new Complex(1.0, Double.NaN);
                                                                                                                                                assertEquals(Complex.NaN, complex.tan());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_InfiniteReal() {
                                                                                                                                                Complex complex = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                                                                                                assertEquals(Complex.NaN, complex.tan());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_InfiniteImaginary() {
                                                                                                                                                Complex complex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                                                                                assertEquals(Complex.NaN, complex.tan());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_LargePositiveImaginary() {
                                                                                                                                                Complex complex = new Complex(1.0, 25.0);
                                                                                                                                                Complex expected = new Complex(0.0, 1.0);
                                                                                                                                                assertEquals(expected, complex.tan());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_LargeNegativeImaginary() {
                                                                                                                                                Complex complex = new Complex(1.0, -25.0);
                                                                                                                                                Complex expected = new Complex(0.0, -1.0);
                                                                                                                                                assertEquals(expected, complex.tan());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_ZeroValues() {
                                                                                                                                                Complex complex = new Complex(0.0, 0.0);
                                                                                                                                                Complex expected = new Complex(0.0, 0.0);
                                                                                                                                                assertEquals(expected, complex.tan());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_RealOnly() {
                                                                                                                                                Complex complex = new Complex(Math.PI/4, 0.0);
                                                                                                                                                Complex expected = new Complex(1.0, 0.0);
                                                                                                                                                assertEquals(expected.getReal(), complex.tan().getReal(), 1e-10);
                                                                                                                                                assertEquals(expected.getImaginary(), complex.tan().getImaginary(), 1e-10);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_ImaginaryOnly() {
                                                                                                                                                Complex complex = new Complex(0.0, 1.0);
                                                                                                                                                Complex result = complex.tan();
                                                                                                                                                assertEquals(0.0, result.getReal(), 1e-10);
                                                                                                                                                assertEquals(Math.tanh(1.0), result.getImaginary(), 1e-10);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_NormalCase() {
                                                                                                                                                Complex complex = new Complex(1.0, 1.0);
                                                                                                                                                Complex result = complex.tan();
                                                                                                                                                
                                                                                                                                                // Calculate expected values using the formula
                                                                                                                                                double real2 = 2.0 * complex.getReal();
                                                                                                                                                double imaginary2 = 2.0 * complex.getImaginary();
                                                                                                                                                double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                                                                                                                                double expectedReal = FastMath.sin(real2) / d;
                                                                                                                                                double expectedImaginary = FastMath.sinh(imaginary2) / d;
                                                                                                                                                
                                                                                                                                                assertEquals(expectedReal, result.getReal(), 1e-10);
                                                                                                                                                assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_BoundaryValuePositiveImaginary() {
                                                                                                                                                Complex complex = new Complex(1.0, 20.0);
                                                                                                                                                Complex result = complex.tan();
                                                                                                                                                // Not exactly (0,1) but very close
                                                                                                                                                assertEquals(0.0, result.getReal(), 1e-10);
                                                                                                                                                assertEquals(1.0, result.getImaginary(), 1e-10);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTan_BoundaryValueNegativeImaginary() {
                                                                                                                                                Complex complex = new Complex(1.0, -20.0);
                                                                                                                                                Complex result = complex.tan();
                                                                                                                                                // Not exactly (0,-1) but very close
                                                                                                                                                assertEquals(0.0, result.getReal(), 1e-10);
                                                                                                                                                assertEquals(-1.0, result.getImaginary(), 1e-10);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTanh_NaNValues() {
                                                                                                                                                Complex nanComplex1 = new Complex(Double.NaN, 1.0);
                                                                                                                                                assertTrue(nanComplex1.tanh().isNaN());
                                                                                                                                                
                                                                                                                                                Complex nanComplex2 = new Complex(1.0, Double.NaN);
                                                                                                                                                assertTrue(nanComplex2.tanh().isNaN());
                                                                                                                                                
                                                                                                                                                Complex nanComplex3 = new Complex(Double.NaN, Double.NaN);
                                                                                                                                                assertTrue(nanComplex3.tanh().isNaN());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTanh_InfiniteValues() {
                                                                                                                                                Complex infComplex1 = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                                                                                                assertTrue(infComplex1.tanh().isNaN());
                                                                                                                                                
                                                                                                                                                Complex infComplex2 = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                                                                                assertTrue(infComplex2.tanh().isNaN());
                                                                                                                                                
                                                                                                                                                Complex infComplex3 = new Complex(Double.NEGATIVE_INFINITY, 1.0);
                                                                                                                                                assertTrue(infComplex3.tanh().isNaN());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTanh_LargePositiveReal() {
                                                                                                                                                Complex complex = new Complex(25.0, 3.0);
                                                                                                                                                Complex result = complex.tanh();
                                                                                                                                                assertEquals(1.0, result.getReal(), 0.0001);
                                                                                                                                                assertEquals(0.0, result.getImaginary(), 0.0001);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTanh_LargeNegativeReal() {
                                                                                                                                                Complex complex = new Complex(-25.0, 3.0);
                                                                                                                                                Complex result = complex.tanh();
                                                                                                                                                assertEquals(-1.0, result.getReal(), 0.0001);
                                                                                                                                                assertEquals(0.0, result.getImaginary(), 0.0001);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTanh_NormalValues() {
                                                                                                                                                // Test case with real and imaginary parts
                                                                                                                                                Complex complex1 = new Complex(2.0, 3.0);
                                                                                                                                                Complex result1 = complex1.tanh();
                                                                                                                                                
                                                                                                                                                // Expected values calculated using reference implementation
                                                                                                                                                double expectedReal1 = FastMath.sinh(4.0) / (FastMath.cosh(4.0) + FastMath.cos(6.0));
                                                                                                                                                double expectedImaginary1 = FastMath.sin(6.0) / (FastMath.cosh(4.0) + FastMath.cos(6.0));
                                                                                                                                                
                                                                                                                                                assertEquals(expectedReal1, result1.getReal(), 0.0001);
                                                                                                                                                assertEquals(expectedImaginary1, result1.getImaginary(), 0.0001);
                                                                                                                                        
                                                                                                                                                // Test case with zero imaginary part
                                                                                                                                                Complex complex2 = new Complex(1.5, 0.0);
                                                                                                                                                Complex result2 = complex2.tanh();
                                                                                                                                                assertEquals(Math.tanh(1.5), result2.getReal(), 0.0001);
                                                                                                                                                assertEquals(0.0, result2.getImaginary(), 0.0001);
                                                                                                                                        
                                                                                                                                                // Test case with zero real part
                                                                                                                                                Complex complex3 = new Complex(0.0, 2.0);
                                                                                                                                                Complex result3 = complex3.tanh();
                                                                                                                                                
                                                                                                                                                double expectedReal3 = 0.0;
                                                                                                                                                double expectedImaginary3 = FastMath.sin(4.0) / (FastMath.cosh(0.0) + FastMath.cos(4.0));
                                                                                                                                                
                                                                                                                                                assertEquals(expectedReal3, result3.getReal(), 0.0001);
                                                                                                                                                assertEquals(expectedImaginary3, result3.getImaginary(), 0.0001);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testTanh_BoundaryValues() {
                                                                                                                                                // Just above positive threshold
                                                                                                                                                Complex complex1 = new Complex(20.1, 0.0);
                                                                                                                                                Complex result1 = complex1.tanh();
                                                                                                                                                assertEquals(1.0, result1.getReal(), 0.0001);
                                                                                                                                                assertEquals(0.0, result1.getImaginary(), 0.0001);
                                                                                                                                        
                                                                                                                                                // Just below positive threshold
                                                                                                                                                Complex complex2 = new Complex(19.9, 0.0);
                                                                                                                                                Complex result2 = complex2.tanh();
                                                                                                                                                assertNotEquals(1.0, result2.getReal(), 0.0001);
                                                                                                                                                assertEquals(0.0, result2.getImaginary(), 0.0001);
                                                                                                                                        
                                                                                                                                                // Just above negative threshold
                                                                                                                                                Complex complex3 = new Complex(-20.1, 0.0);
                                                                                                                                                Complex result3 = complex3.tanh();
                                                                                                                                                assertEquals(-1.0, result3.getReal(), 0.0001);
                                                                                                                                                assertEquals(0.0, result3.getImaginary(), 0.0001);
                                                                                                                                        
                                                                                                                                                // Just below negative threshold
                                                                                                                                                Complex complex4 = new Complex(-19.9, 0.0);
                                                                                                                                                Complex result4 = complex4.tanh();
                                                                                                                                                assertNotEquals(-1.0, result4.getReal(), 0.0001);
                                                                                                                                                assertEquals(0.0, result4.getImaginary(), 0.0001);
                                                                                                                                            }

    @Test
                                                                                                                                        public void testAbsWithNaNAndFiniteImaginary() {
                                                                                                                                            // Create a complex number that is NaN (real part is NaN) but with finite imaginary
                                                                                                                                            Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                                                                                                            
                                                                                                                                            // Original should return NaN, mutant might not
                                                                                                                                            assertEquals(Double.NaN, nanComplex.abs(), 0.0);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testAbsWithInfiniteImaginaryAndNotNaN() {
                                                                                                                                            // Create a complex number with infinite imaginary but not NaN
                                                                                                                                            Complex infiniteImaginaryComplex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                                                                            
                                                                                                                                            // Original should return POSITIVE_INFINITY, mutant might return NaN
                                                                                                                                            assertEquals(Double.POSITIVE_INFINITY, infiniteImaginaryComplex.abs(), 0.0);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testAbsWithBothNaNAndInfiniteImaginary() {
                                                                                                                                            // Create a complex number that is both NaN and has infinite imaginary
                                                                                                                                            Complex bothCaseComplex = new Complex(Double.NaN, Double.POSITIVE_INFINITY);
                                                                                                                                            
                                                                                                                                            // Both original and mutant should return NaN in this case
                                                                                                                                            assertEquals(Double.NaN, bothCaseComplex.abs(), 0.0);
                                                                                                                                        }

    @Test
                                                                                                                                    public void testAbsWithNaNRealPart() {
                                                                                                                                        // Create complex number with NaN real part and finite imaginary
                                                                                                                                        Complex complex = new Complex(Double.NaN, 1.0);
                                                                                                                                        
                                                                                                                                        // Original should return NaN, mutant would try to calculate
                                                                                                                                        double result = complex.abs();
                                                                                                                                        
                                                                                                                                        // Verify correct handling of NaN
                                                                                                                                        assertTrue(Double.isNaN(result));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testAbsWithNaNImaginaryPart() {
                                                                                                                                        // Create complex number with finite real part and NaN imaginary
                                                                                                                                        Complex complex = new Complex(1.0, Double.NaN);
                                                                                                                                        
                                                                                                                                        // Should return NaN in both original and mutant
                                                                                                                                        double result = complex.abs();
                                                                                                                                        
                                                                                                                                        // Verify correct handling of NaN
                                                                                                                                        assertTrue(Double.isNaN(result));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testAbsWithBothNaN() {
                                                                                                                                        // Create complex number with both parts NaN
                                                                                                                                        Complex complex = new Complex(Double.NaN, Double.NaN);
                                                                                                                                        
                                                                                                                                        // Should return NaN
                                                                                                                                        double result = complex.abs();
                                                                                                                                        
                                                                                                                                        // Verify correct handling of NaN
                                                                                                                                        assertTrue(Double.isNaN(result));
                                                                                                                                    }

    @Test
                                                                                                                                public void testAbsWithRealExactly() {
                                                                                                                                    // Create complex number with real exactly 20.0 and imaginary 0.0
                                                                                                                                    Complex complex = new Complex(20.0, 0.0);
                                                                                                                                    
                                                                                                                                    // Calculate expected value - should use real component as base
                                                                                                                                    double expected = FastMath.abs(20.0);
                                                                                                                                    
                                                                                                                                    // Verify the actual result matches expected
                                                                                                                                    assertEquals(expected, complex.abs(), 0.0001);
                                                                                                                                    
                                                                                                                                    // Now test with real exactly 20.0 and non-zero imaginary
                                                                                                                                    Complex complex2 = new Complex(20.0, 15.0);
                                                                                                                                    double q = 15.0 / 20.0;
                                                                                                                                    expected = FastMath.abs(20.0) * FastMath.sqrt(1 + q * q);
                                                                                                                                    assertEquals(expected, complex2.abs(), 0.0001);
                                                                                                                                    
                                                                                                                                    // Test edge case where real is just below 20.0 (19.999999)
                                                                                                                                    Complex complex3 = new Complex(19.999999, 15.0);
                                                                                                                                    double q3 = 15.0 / 19.999999;
                                                                                                                                    expected = FastMath.abs(19.999999) * FastMath.sqrt(1 + q3 * q3);
                                                                                                                                    assertEquals(expected, complex3.abs(), 0.0001);
                                                                                                                                }

    @Test
                                                                                                                            public void testAbs() {
                                                                                                                                // Test NaN case
                                                                                                                                Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                                                                                                assertEquals(Double.NaN, nanComplex.abs(), 0.0);
                                                                                                                        
                                                                                                                                // Test infinite case
                                                                                                                                Complex infComplex = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                                                                                                                assertEquals(Double.POSITIVE_INFINITY, infComplex.abs(), 0.0);
                                                                                                                        
                                                                                                                                // Test case where real > imaginary
                                                                                                                                Complex realLarger = new Complex(3.0, 4.0);
                                                                                                                                assertEquals(5.0, realLarger.abs(), 1e-10);  // 3² + 4² = 5²
                                                                                                                        
                                                                                                                                // Test case where real < imaginary
                                                                                                                                Complex imagLarger = new Complex(4.0, 3.0);
                                                                                                                                assertEquals(5.0, imagLarger.abs(), 1e-10);  // Should be same as above
                                                                                                                        
                                                                                                                                // Test case where real == imaginary
                                                                                                                                Complex equalParts = new Complex(5.0, 5.0);
                                                                                                                                assertEquals(5.0 * Math.sqrt(2), equalParts.abs(), 1e-10);
                                                                                                                        
                                                                                                                                // Test case where real is 0
                                                                                                                                Complex zeroReal = new Complex(0.0, 5.0);
                                                                                                                                assertEquals(5.0, zeroReal.abs(), 0.0);
                                                                                                                        
                                                                                                                                // Test case where imaginary is 0
                                                                                                                                Complex zeroImag = new Complex(5.0, 0.0);
                                                                                                                                assertEquals(5.0, zeroImag.abs(), 0.0);
                                                                                                                        
                                                                                                                                // Test with very large values
                                                                                                                                Complex largeReal = new Complex(1e300, 1e200);
                                                                                                                                assertEquals(1e300, largeReal.abs(), 1e285);  // Should be approx 1e300
                                                                                                                        
                                                                                                                                Complex largeImag = new Complex(1e200, 1e300);
                                                                                                                                assertEquals(1e300, largeImag.abs(), 1e285);  // Should be approx 1e300
                                                                                                                            }

    @Test
                                                                                                                        public void testAbsBoundaryConditionForNegative() {
                                                                                                                            // Test case where real is exactly -20.0
                                                                                                                            Complex complex1 = new Complex(-20.0, 0.0);
                                                                                                                            double expected1 = 20.0; // Expected abs value for -20 + 0i
                                                                                                                            assertEquals(expected1, complex1.abs(), 0.0001);
                                                                                                                            
                                                                                                                            // Test case where real is just below -20.0
                                                                                                                            Complex complex2 = new Complex(-20.1, 0.0);
                                                                                                                            double expected2 = 20.1; // Expected abs value for -20.1 + 0i
                                                                                                                            assertEquals(expected2, complex2.abs(), 0.0001);
                                                                                                                            
                                                                                                                            // Test case where real is just above -20.0
                                                                                                                            Complex complex3 = new Complex(-19.9, 0.0);
                                                                                                                            double expected3 = 19.9; // Expected abs value for -19.9 + 0i
                                                                                                                            assertEquals(expected3, complex3.abs(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                    public void testAbsWithLargeNegativeRealBetweenThresholds() {
                                                                                                                        // Test with real value between -20.0 and -10.0 to catch the mutant
                                                                                                                        double real = -15.0;
                                                                                                                        double imaginary = 3.0;
                                                                                                                        Complex complex = new Complex(real, imaginary);
                                                                                                                        
                                                                                                                        // Calculate expected value using stable algorithm
                                                                                                                        double q = imaginary / real;
                                                                                                                        double expected = FastMath.abs(real) * FastMath.sqrt(1 + q * q);
                                                                                                                        
                                                                                                                        // The mutant would use the other branch (imaginary/real instead of real/imaginary)
                                                                                                                        // so the result would be different
                                                                                                                        double actual = complex.abs();
                                                                                                                        
                                                                                                                        assertEquals("abs() should handle large negative real values correctly", 
                                                                                                                                    expected, actual, 1e-10);
                                                                                                                        
                                                                                                                        // Additional test case near the original boundary
                                                                                                                        real = -19.0;
                                                                                                                        imaginary = 4.0;
                                                                                                                        complex = new Complex(real, imaginary);
                                                                                                                        q = imaginary / real;
                                                                                                                        expected = FastMath.abs(real) * FastMath.sqrt(1 + q * q);
                                                                                                                        actual = complex.abs();
                                                                                                                        assertEquals("abs() should handle values near -20.0 correctly",
                                                                                                                                    expected, actual, 1e-10);
                                                                                                                    }

    @Test
                                                                                                            public void testAbsWithInfiniteImaginary() {
                                                                                                                // Create a complex number with finite real and infinite imaginary part
                                                                                                                Complex complex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                                                
                                                                                                                // The original method should return POSITIVE_INFINITY
                                                                                                                // The mutant will try to calculate the magnitude instead
                                                                                                                double result = complex.abs();
                                                                                                                
                                                                                                                // Verify the correct handling of infinite imaginary part
                                                                                                                assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                                                                                
                                                                                                                // Additional test with negative infinity
                                                                                                                Complex complexNeg = new Complex(1.0, Double.NEGATIVE_INFINITY);
                                                                                                                assertEquals(Double.POSITIVE_INFINITY, complexNeg.abs(), 0.0);
                                                                                                                
                                                                                                                // Test with both parts infinite for completeness
                                                                                                                Complex complexBoth = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                                                                                assertEquals(Double.POSITIVE_INFINITY, complexBoth.abs(), 0.0);
                                                                                                            }

    @Test
                                                                                                            public void testAbsWithRealGreaterThan20AndImaginaryLessThanOrEqualTo() {
                                                                                                                // Test case where real > 20.0 but imaginary <= 0
                                                                                                                // This should detect the mutant since original and mutant behave differently
                                                                                                                
                                                                                                                // Create complex number with real > 20 and imaginary <= 0
                                                                                                                Complex c = new Complex(25.0, -3.0);
                                                                                                                
                                                                                                                // Expected value: sqrt(25^2 + (-3)^2) = sqrt(625 + 9) = sqrt(634) ≈ 25.1793566
                                                                                                                double expected = Math.sqrt(25.0*25.0 + (-3.0)*(-3.0));
                                                                                                                double actual = c.abs();
                                                                                                                
                                                                                                                assertEquals("Magnitude calculation incorrect for real > 20 && imaginary <= 0", 
                                                                                                                            expected, actual, 1e-10);
                                                                                                                
                                                                                                                // Another test case with imaginary = 0
                                                                                                                Complex c2 = new Complex(21.0, 0.0);
                                                                                                                double expected2 = 21.0; // sqrt(21^2 + 0^2) = 21
                                                                                                                double actual2 = c2.abs();
                                                                                                                
                                                                                                                assertEquals("Magnitude calculation incorrect for real > 20 && imaginary = 0",
                                                                                                                            expected2, actual2, 1e-10);
                                                                                                            }

    @Test
                                                                                                            public void testAbsWithRealGreaterThan20AndImaginaryGreaterThan() {
                                                                                                                // Test case where both real > 20.0 and imaginary > 0
                                                                                                                // Both original and mutant should behave the same here
                                                                                                                
                                                                                                                Complex c = new Complex(25.0, 3.0);
                                                                                                                double expected = Math.sqrt(25.0*25.0 + 3.0*3.0); // same as above
                                                                                                                double actual = c.abs();
                                                                                                                
                                                                                                                assertEquals(expected, actual, 1e-10);
                                                                                                            }

    @Test
                                                                                                        public void testAbsWithLargeNegativeRealAndPositiveImaginary() {
                                                                                                            // This test should detect the mutant
                                                                                                            double real = -25.0;      // < -20.0
                                                                                                            double imaginary = 5.0;   // > 0
                                                                                                            Complex complex = new Complex(real, imaginary);
                                                                                                            
                                                                                                            // Calculate expected value using standard formula
                                                                                                            double expected = Math.sqrt(real*real + imaginary*imaginary);
                                                                                                            
                                                                                                            // The mutant would behave differently here because it wouldn't take the special path
                                                                                                            assertEquals(expected, complex.abs(), 1e-10);
                                                                                                        }

    @Test
                                                                                                        public void testAbsWithLargeNegativeRealAndNegativeImaginary() {
                                                                                                            // This test case would pass for both original and mutant
                                                                                                            double real = -25.0;      // < -20.0
                                                                                                            double imaginary = -5.0;  // < 0
                                                                                                            Complex complex = new Complex(real, imaginary);
                                                                                                            
                                                                                                            // Calculate expected value using standard formula
                                                                                                            double expected = Math.sqrt(real*real + imaginary*imaginary);
                                                                                                            
                                                                                                            assertEquals(expected, complex.abs(), 1e-10);
                                                                                                        }

    @Test
                                                                                                    public void testAbsWithLargeNumbers() {
                                                                                                        // Test with very large numbers where multiplication and addition might differ
                                                                                                        double largeValue = Double.MAX_VALUE / 2;
                                                                                                        Complex c = new Complex(largeValue, largeValue);
                                                                                                        
                                                                                                        // Calculate expected value using the mathematical formula
                                                                                                        double expected = Math.sqrt(largeValue * largeValue + largeValue * largeValue);
                                                                                                        
                                                                                                        // The mutation would produce a slightly different result due to floating point arithmetic
                                                                                                        double actual = c.abs();
                                                                                                        
                                                                                                        // Verify the result is exactly as expected (should fail if mutation is present)
                                                                                                        assertEquals("Absolute value calculation for large numbers is incorrect", 
                                                                                                                    expected, actual, 0.0);
                                                                                                    }

    @Test
                                                                                                    public void testAbsWithSmallNumbers() {
                                                                                                        // Test with very small numbers where precision differences might appear
                                                                                                        double smallValue = Double.MIN_VALUE * 2;
                                                                                                        Complex c = new Complex(smallValue, smallValue);
                                                                                                        
                                                                                                        // Calculate expected value using the mathematical formula
                                                                                                        double expected = Math.sqrt(smallValue * smallValue + smallValue * smallValue);
                                                                                                        
                                                                                                        // The mutation would produce a slightly different result due to floating point arithmetic
                                                                                                        double actual = c.abs();
                                                                                                        
                                                                                                        // Verify the result is exactly as expected (should fail if mutation is present)
                                                                                                        assertEquals("Absolute value calculation for small numbers is incorrect", 
                                                                                                                    expected, actual, 0.0);
                                                                                                    }

    @Test
                                                                                                public void testAbsWithLargeImaginaryValue() {
                                                                                                    // Test with a very large imaginary value where addition might produce different results than multiplication
                                                                                                    double largeValue = Double.MAX_VALUE / 2;
                                                                                                    Complex c = new Complex(1.0, largeValue);
                                                                                                    
                                                                                                    // Calculate expected value using the mathematical formula
                                                                                                    double expected = Math.sqrt(1.0 + largeValue * largeValue);
                                                                                                    
                                                                                                    // The mutant might produce slightly different results due to floating-point arithmetic differences
                                                                                                    // between addition and multiplication
                                                                                                    double result = c.abs();
                                                                                                    
                                                                                                    // Verify the result is exactly as expected (should fail if the mutant is present)
                                                                                                    assertEquals(expected, result, 0.0);
                                                                                                    
                                                                                                    // Also verify with the inverse case where real is larger
                                                                                                    Complex c2 = new Complex(largeValue, 1.0);
                                                                                                    double expected2 = Math.sqrt(largeValue * largeValue + 1.0);
                                                                                                    double result2 = c2.abs();
                                                                                                    assertEquals(expected2, result2, 0.0);
                                                                                                }

    @Test
                                                                                                public void testAbsWithSmallImaginaryValue() {
                                                                                                    // Test with a very small imaginary value where floating-point precision might differ
                                                                                                    double smallValue = Double.MIN_VALUE * 2;
                                                                                                    Complex c = new Complex(1.0, smallValue);
                                                                                                    
                                                                                                    // Calculate expected value
                                                                                                    double expected = Math.sqrt(1.0 + smallValue * smallValue);
                                                                                                    
                                                                                                    double result = c.abs();
                                                                                                    
                                                                                                    // Verify with strict equality (should fail if the mutant is present)
                                                                                                    assertEquals(expected, result, 0.0);
                                                                                                    
                                                                                                    // Inverse case
                                                                                                    Complex c2 = new Complex(smallValue, 1.0);
                                                                                                    double expected2 = Math.sqrt(smallValue * smallValue + 1.0);
                                                                                                    double result2 = c2.abs();
                                                                                                    assertEquals(expected2, result2, 0.0);
                                                                                                }

    @Test
                                                                                        public void testAbsWithNaNOrInfiniteImaginary() {
                                                                                            // Case 1: isNaN true but imaginary finite - should return NaN
                                                                                            Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                                                            assertEquals(Double.NaN, nanComplex.abs(), 0.0);
                                                                                            
                                                                                            // Case 2: imaginary infinite but isNaN false - should return POSITIVE_INFINITY
                                                                                            Complex infiniteImaginaryComplex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                                            assertEquals(Double.POSITIVE_INFINITY, infiniteImaginaryComplex.abs(), 0.0);
                                                                                            
                                                                                            // Case 3: Both isNaN true and imaginary infinite - should return NaN
                                                                                            Complex bothCaseComplex = new Complex(Double.NaN, Double.POSITIVE_INFINITY);
                                                                                            assertEquals(Double.NaN, bothCaseComplex.abs(), 0.0);
                                                                                            
                                                                                            // Case 4: Neither case - normal complex number
                                                                                            Complex normalComplex = new Complex(3.0, 4.0);
                                                                                            assertEquals(5.0, normalComplex.abs(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testAbsWithNaNRealShouldReturnNaN() {
                                                                                            // Create a complex number with NaN real part and finite imaginary
                                                                                            double nanReal = Double.NaN;
                                                                                            double finiteImaginary = 1.0;
                                                                                            Complex complex = new Complex(nanReal, finiteImaginary);
                                                                                            
                                                                                            // Verify the result is NaN
                                                                                            assertTrue(Double.isNaN(complex.abs()));
                                                                                            
                                                                                            // This test will fail if the mutant is present because:
                                                                                            // - Original code: isNaN=true → returns NaN immediately
                                                                                            // - Mutant code: skips NaN check → proceeds with calculation
                                                                                        }

    @Test
                                                                                        public void testAbsWithNaNImaginaryShouldReturnNaN() {
                                                                                            // Create a complex number with finite real part and NaN imaginary
                                                                                            double finiteReal = 1.0;
                                                                                            double nanImaginary = Double.NaN;
                                                                                            Complex complex = new Complex(finiteReal, nanImaginary);
                                                                                            
                                                                                            // Verify the result is NaN
                                                                                            assertTrue(Double.isNaN(complex.abs()));
                                                                                            
                                                                                            // This test would pass for both original and mutant because:
                                                                                            // The constructor sets isNaN=true when either part is NaN
                                                                                            // But we include it for completeness
                                                                                        }

    @Test
                                                                                    public void testAbsWithRealExactly1() {
                                                                                        // This test is specifically designed to catch the mutant where 
                                                                                        // condition changed from > to >= for real value 20.0
                                                                                        Complex c = new Complex(20.0, 21.0);
                                                                                        
                                                                                        // Expected calculation when real >= 20.0:
                                                                                        // Uses real as the larger component
                                                                                        double q = 21.0 / 20.0;
                                                                                        double expected = Math.abs(20.0) * Math.sqrt(1 + q * q);
                                                                                        
                                                                                        assertEquals(expected, c.abs(), 1e-10);
                                                                                    }

    @Test
                                                                                    public void testAbsWithRealJustAbove() {
                                                                                        // Verify original behavior for value just above 20
                                                                                        Complex c = new Complex(20.0001, 21.0);
                                                                                        
                                                                                        // Expected calculation when real > 20.0:
                                                                                        // Uses real as the larger component
                                                                                        double q = 21.0 / 20.0001;
                                                                                        double expected = Math.abs(20.0001) * Math.sqrt(1 + q * q);
                                                                                        
                                                                                        assertEquals(expected, c.abs(), 1e-10);
                                                                                    }

    @Test
                                                                                    public void testAbsWithRealJustBelow() {
                                                                                        // Verify behavior for value just below 20
                                                                                        Complex c = new Complex(19.9999, 21.0);
                                                                                        
                                                                                        // Expected calculation when real < 20.0:
                                                                                        // Uses imaginary as the larger component
                                                                                        double q = 19.9999 / 21.0;
                                                                                        double expected = Math.abs(21.0) * Math.sqrt(1 + q * q);
                                                                                        
                                                                                        assertEquals(expected, c.abs(), 1e-10);
                                                                                    }

    @Test
                                                                                public void testAbsBoundaryConditions() {
                                                                                    // Test case where real is exactly 10.0
                                                                                    Complex c1 = new Complex(10.0, 3.0);
                                                                                    double expected1 = Math.sqrt(10.0 * 10.0 + 3.0 * 3.0);
                                                                                    assertEquals("Magnitude for real=10.0", expected1, c1.abs(), 1e-10);
                                                                                    
                                                                                    // Test case where real is exactly 20.0
                                                                                    Complex c2 = new Complex(20.0, 3.0);
                                                                                    double expected2 = Math.sqrt(20.0 * 20.0 + 3.0 * 3.0);
                                                                                    assertEquals("Magnitude for real=20.0", expected2, c2.abs(), 1e-10);
                                                                                    
                                                                                    // Test case where real is between boundaries (15.0)
                                                                                    Complex c3 = new Complex(15.0, 3.0);
                                                                                    double expected3 = Math.sqrt(15.0 * 15.0 + 3.0 * 3.0);
                                                                                    assertEquals("Magnitude for real=15.0", expected3, c3.abs(), 1e-10);
                                                                                    
                                                                                    // Test case where real is just above original boundary (21.0)
                                                                                    Complex c4 = new Complex(21.0, 3.0);
                                                                                    double expected4 = Math.sqrt(21.0 * 21.0 + 3.0 * 3.0);
                                                                                    assertEquals("Magnitude for real=21.0", expected4, c4.abs(), 1e-10);
                                                                                }

    @Test
                                                                            public void testAbsBoundaryCaseNegative() {
                                                                                // Test with real exactly -20.0 to catch the mutant
                                                                                double real = -20.0;
                                                                                double imaginary = 5.0;
                                                                                Complex complex = new Complex(real, imaginary);
                                                                                
                                                                                // Calculate expected value manually
                                                                                double q = imaginary / real;  // Should use else branch in original
                                                                                double expected = Math.abs(real) * Math.sqrt(1 + q * q);
                                                                                
                                                                                // Verify the actual result matches expected
                                                                                assertEquals(expected, complex.abs(), 1e-10);
                                                                                
                                                                                // Also test with real slightly less than -20.0 to ensure both branches are covered
                                                                                Complex complexJustBelow = new Complex(-20.0001, imaginary);
                                                                                double qJustBelow = (-20.0001) / imaginary;  // Should use if branch
                                                                                double expectedJustBelow = Math.abs(imaginary) * Math.sqrt(1 + qJustBelow * qJustBelow);
                                                                                assertEquals(expectedJustBelow, complexJustBelow.abs(), 1e-10);
                                                                            }

    @Test
                                                                        public void testAbsWithRealBetweenMinus20AndMinus() {
                                                                            // Test case where real is between -20.0 and -10.0
                                                                            // This should detect the mutant that changed the threshold from -20.0 to -10.0
                                                                            Complex c1 = new Complex(-15.0, 3.0);
                                                                            Complex c2 = new Complex(-5.0, 3.0);
                                                                            
                                                                            // Expected value calculated using standard formula: sqrt(real² + imaginary²)
                                                                            double expected1 = Math.sqrt(15.0*15.0 + 3.0*3.0);
                                                                            double expected2 = Math.sqrt(5.0*5.0 + 3.0*3.0);
                                                                            
                                                                            // The mutant would treat these cases differently
                                                                            assertEquals("Abs value for real=-15.0", expected1, c1.abs(), 1e-10);
                                                                            assertEquals("Abs value for real=-5.0", expected2, c2.abs(), 1e-10);
                                                                            
                                                                            // Additional edge cases around the threshold
                                                                            Complex c3 = new Complex(-10.1, 2.0);
                                                                            Complex c4 = new Complex(-9.9, 2.0);
                                                                            double expected3 = Math.sqrt(10.1*10.1 + 2.0*2.0);
                                                                            double expected4 = Math.sqrt(9.9*9.9 + 2.0*2.0);
                                                                            
                                                                            assertEquals("Abs value just below -10 threshold", expected3, c3.abs(), 1e-10);
                                                                            assertEquals("Abs value just above -10 threshold", expected4, c4.abs(), 1e-10);
                                                                        }

    @Test
                                                                    public void testAbsWithInfiniteImaginary1() {
                                                                        // Test case where imaginary is POSITIVE_INFINITY
                                                                        Complex c1 = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                                        // Should return NaN for original code, but mutant will return POSITIVE_INFINITY
                                                                        assertTrue(Double.isNaN(c1.abs()));
                                                                        
                                                                        // Test case where imaginary is NEGATIVE_INFINITY
                                                                        Complex c2 = new Complex(1.0, Double.NEGATIVE_INFINITY);
                                                                        assertTrue(Double.isNaN(c2.abs()));
                                                                        
                                                                        // Test case where both real and imaginary are infinite
                                                                        Complex c3 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                                        assertTrue(Double.isNaN(c3.abs()));
                                                                        
                                                                        // Test case where real is zero and imaginary is infinite
                                                                        Complex c4 = new Complex(0.0, Double.POSITIVE_INFINITY);
                                                                        assertTrue(Double.isNaN(c4.abs()));
                                                                    }

    @Test
                                                                public void testAbsWithRealGreaterThan20AndImaginaryLessOrEqualZero() {
                                                                    // Test case where real > 20.0 but imaginary <= 0
                                                                    // This should detect the mutant since original and mutant behave differently
                                                                    
                                                                    // Case 1: real > 20.0, imaginary = 0
                                                                    Complex c1 = new Complex(25.0, 0.0);
                                                                    double expected1 = 25.0; // sqrt(25² + 0²) = 25
                                                                    assertEquals(expected1, c1.abs(), 0.0001);
                                                                    
                                                                    // Case 2: real > 20.0, imaginary < 0
                                                                    Complex c2 = new Complex(30.0, -5.0);
                                                                    double expected2 = Math.sqrt(30.0*30.0 + 5.0*5.0); // ~30.4138
                                                                    assertEquals(expected2, c2.abs(), 0.0001);
                                                                    
                                                                    // Case 3: real > 20.0, imaginary > 0 (both conditions true)
                                                                    Complex c3 = new Complex(25.0, 10.0);
                                                                    double expected3 = Math.sqrt(25.0*25.0 + 10.0*10.0); // ~26.9258
                                                                    assertEquals(expected3, c3.abs(), 0.0001);
                                                                    
                                                                    // Case 4: real <= 20.0 (should behave same in both original and mutant)
                                                                    Complex c4 = new Complex(15.0, -8.0);
                                                                    double expected4 = Math.sqrt(15.0*15.0 + 8.0*8.0); // ~17.0
                                                                    assertEquals(expected4, c4.abs(), 0.0001);
                                                                }

    @Test
                                                            public void testAbsWithLargeNegativeRealAndPositiveImaginary1() {
                                                                // This test case should detect the mutant
                                                                // real < -20.0 (true) && imaginary < 0 (false)
                                                                // Original would take this branch, mutant would not
                                                                Complex c = new Complex(-21.0, 1.0);
                                                                double expected = Math.sqrt(21.0*21.0 + 1.0*1.0); // Expected correct calculation
                                                                double actual = c.abs();
                                                                
                                                                assertEquals("Absolute value calculation incorrect for large negative real and positive imaginary",
                                                                            expected, actual, 1e-10);
                                                            }

    @Test
                                                            public void testAbsWithLargeNegativeRealAndNegativeImaginary1() {
                                                                // This case should behave the same in both original and mutant
                                                                // real < -20.0 (true) && imaginary < 0 (true)
                                                                Complex c = new Complex(-21.0, -1.0);
                                                                double expected = Math.sqrt(21.0*21.0 + 1.0*1.0);
                                                                double actual = c.abs();
                                                                
                                                                assertEquals("Absolute value calculation incorrect for large negative real and negative imaginary",
                                                                            expected, actual, 1e-10);
                                                            }

    @Test
                                                            public void testAbsWithSmallNegativeReal() {
                                                                // Control case - real not < -20
                                                                Complex c = new Complex(-19.0, 1.0);
                                                                double expected = Math.sqrt(19.0*19.0 + 1.0*1.0);
                                                                double actual = c.abs();
                                                                
                                                                assertEquals("Absolute value calculation incorrect for small negative real",
                                                                            expected, actual, 1e-10);
                                                            }

    @Test
                                                        public void testAbsWithLargeRealValue() {
                                                            // Use a value near the maximum double precision where addition might differ from multiplication
                                                            double largeValue = Double.MAX_VALUE / 2;
                                                            Complex c = new Complex(largeValue, 1.0);
                                                            
                                                            // Calculate expected value using the mathematical formula
                                                            double expected = largeValue * Math.sqrt(1 + (1.0/largeValue)*(1.0/largeValue));
                                                            
                                                            // The mutant would compute real2 = real + real which might have different rounding
                                                            // than real2 = 2.0 * real for extreme values
                                                            double actual = c.abs();
                                                            
                                                            // Verify the result is exactly as expected (should fail if mutation is present)
                                                            assertEquals("Absolute value calculation for large real component", 
                                                                        expected, actual, 0.0);
                                                            
                                                            // Also test with negative large value
                                                            Complex c2 = new Complex(-largeValue, 1.0);
                                                            assertEquals("Absolute value calculation for negative large real component",
                                                                        expected, c2.abs(), 0.0);
                                                        }

    @Test
                                                    public void testAbsWithSmallImaginaryValue1() {
                                                        // Use a value where 2.0*imaginary might differ slightly from imaginary+imaginary
                                                        double real = 1.0;
                                                        double imaginary = Double.MIN_VALUE * 0.5; // Very small value
                                                        
                                                        Complex complex = new Complex(real, imaginary);
                                                        
                                                        // Calculate expected value using original implementation logic
                                                        double q = imaginary / real;
                                                        double expected = FastMath.abs(real) * FastMath.sqrt(1 + q * q);
                                                        
                                                        // The mutation would produce a slightly different result due to rounding differences
                                                        double actual = complex.abs();
                                                        
                                                        // Verify the result matches the expected value with high precision
                                                        assertEquals("Absolute value calculation should be precise", 
                                                                    expected, actual, 0.0);
                                                        
                                                        // Additionally test with negative small value
                                                        imaginary = -Double.MIN_VALUE * 0.5;
                                                        complex = new Complex(real, imaginary);
                                                        q = imaginary / real;
                                                        expected = FastMath.abs(real) * FastMath.sqrt(1 + q * q);
                                                        actual = complex.abs();
                                                        assertEquals("Absolute value calculation should handle negative small values precisely",
                                                                    expected, actual, 0.0);
                                                    }

    @Test
                                                public void testAbsWithNaNAndFiniteImaginary1() {
                                                    // Create a complex number that is NaN (real part NaN) but with finite imaginary
                                                    Complex nanComplex = new Complex(Double.NaN, 1.0);
                                                    
                                                    // Should return NaN since isNaN is true, regardless of imaginary
                                                    assertEquals(Double.NaN, nanComplex.abs(), 0.0);
                                                }

    @Test
                                                public void testAbsWithInfiniteImaginaryAndNotNaN1() {
                                                    // Create a complex number with infinite imaginary but not NaN
                                                    Complex infiniteImaginaryComplex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                                    
                                                    // Should return NaN since imaginary is infinite, regardless of isNaN
                                                    assertEquals(Double.NaN, infiniteImaginaryComplex.abs(), 0.0);
                                                }

    @Test
                                                public void testAbsWithBothNaNAndInfiniteImaginary1() {
                                                    // Create a complex number that is both NaN and has infinite imaginary
                                                    Complex nanInfiniteComplex = new Complex(Double.NaN, Double.POSITIVE_INFINITY);
                                                    
                                                    // Should return NaN in both original and mutant
                                                    assertEquals(Double.NaN, nanInfiniteComplex.abs(), 0.0);
                                                }

    @Test
                                            public void testAbsWithNaNRealPart1() {
                                                // Create a complex number with NaN real part and finite imaginary part
                                                double nanReal = Double.NaN;
                                                double finiteImaginary = 1.0;
                                                Complex complex = new Complex(nanReal, finiteImaginary);
                                                
                                                // The original implementation should return NaN
                                                // The mutant will not return NaN since it only checks imaginary part
                                                double result = complex.abs();
                                                
                                                // Verify the result is NaN
                                                assertTrue("Absolute value should be NaN when real part is NaN", 
                                                          Double.isNaN(result));
                                            }

    @Test
                                            public void testAbsWithNaNImaginaryPart1() {
                                                // Create a complex number with finite real part and NaN imaginary part
                                                double finiteReal = 1.0;
                                                double nanImaginary = Double.NaN;
                                                Complex complex = new Complex(finiteReal, nanImaginary);
                                                
                                                // Both original and mutant should return NaN
                                                double result = complex.abs();
                                                
                                                // Verify the result is NaN
                                                assertTrue("Absolute value should be NaN when imaginary part is NaN", 
                                                          Double.isNaN(result));
                                            }

    @Test
                                            public void testAbsWithBothNaN1() {
                                                // Create a complex number with both parts NaN
                                                double nanReal = Double.NaN;
                                                double nanImaginary = Double.NaN;
                                                Complex complex = new Complex(nanReal, nanImaginary);
                                                
                                                // Both original and mutant should return NaN
                                                double result = complex.abs();
                                                
                                                // Verify the result is NaN
                                                assertTrue("Absolute value should be NaN when both parts are NaN", 
                                                          Double.isNaN(result));
                                            }

    @Test
                                    public void testAbsBoundaryCaseForReal() {
                                        // Create complex number with real exactly 20.0
                                        double real = 20.0;
                                        double imaginary = 5.0; // arbitrary value
                                        
                                        // Create complex number
                                        Complex complex = new Complex(real, imaginary);
                                        
                                        // Calculate expected result manually using original logic (real >= imaginary case)
                                        // Since real > imaginary, we use the else branch in original code
                                        double q = imaginary / real;
                                        double expected = FastMath.abs(real) * FastMath.sqrt(1 + q * q);
                                        
                                        // Get actual result
                                        double actual = complex.abs();
                                        
                                        // Verify
                                        assertEquals("Absolute value calculation for real=20.0 should use correct branch", 
                                                    expected, actual, 1e-10);
                                        
                                        // Also test with real slightly above and below 20.0 to ensure full coverage
                                        Complex complexJustAbove = new Complex(20.000001, imaginary);
                                        Complex complexJustBelow = new Complex(19.999999, imaginary);
                                        
                                        assertEquals(complexJustAbove.abs(), expected, 1e-10);
                                        assertEquals(complexJustBelow.abs(), expected, 1e-10);
                                    }

    @Test
                                    public void testAbsBoundaryConditions1() {
                                        // Test case where real and imaginary are nearly equal
                                        Complex c1 = new Complex(10.0, 10.0000001);
                                        double expected1 = Math.sqrt(10.0*10.0 + 10.0000001*10.0000001);
                                        assertEquals(expected1, c1.abs(), 1e-10);
                                        
                                        Complex c2 = new Complex(10.0000001, 10.0);
                                        double expected2 = Math.sqrt(10.0000001*10.0000001 + 10.0*10.0);
                                        assertEquals(expected2, c2.abs(), 1e-10);
                                        
                                        // Test case where real is slightly larger than imaginary
                                        Complex c3 = new Complex(15.0, 10.0);
                                        double expected3 = Math.sqrt(15.0*15.0 + 10.0*10.0);
                                        assertEquals(expected3, c3.abs(), 1e-10);
                                        
                                        // Test case where imaginary is slightly larger than real
                                        Complex c4 = new Complex(10.0, 15.0);
                                        double expected4 = Math.sqrt(10.0*10.0 + 15.0*15.0);
                                        assertEquals(expected4, c4.abs(), 1e-10);
                                        
                                        // Test edge case where one component is zero
                                        Complex c5 = new Complex(0.0, 10.0);
                                        assertEquals(10.0, c5.abs(), 1e-10);
                                        
                                        Complex c6 = new Complex(10.0, 0.0);
                                        assertEquals(10.0, c6.abs(), 1e-10);
                                    }

    @Test
                                    public void testAbsSpecialCases() {
                                        // Test NaN case
                                        Complex c1 = new Complex(Double.NaN, 10.0);
                                        assertTrue(Double.isNaN(c1.abs()));
                                        
                                        // Test Infinite case
                                        Complex c2 = new Complex(Double.POSITIVE_INFINITY, 10.0);
                                        assertEquals(Double.POSITIVE_INFINITY, c2.abs(), 0.0);
                                    }

    @Test
                            public void testAbsWithRealExactlyNegative() {
                                // Create complex number with real = -20.0 (boundary case)
                                double real = -20.0;
                                double imaginary = 5.0;  // arbitrary value
                                Complex complex = new Complex(real, imaginary);
                                
                                // Calculate expected value using standard formula
                                // Since |real| (20) > |imaginary| (5), it should use the else branch:
                                // |real| * sqrt(1 + (imaginary/real)^2)
                                double q = imaginary / real;
                                double expected = FastMath.abs(real) * FastMath.sqrt(1 + q * q);
                                
                                // Verify the actual result matches expected
                                assertEquals(expected, complex.abs(), 1e-10);
                                
                                // Also verify the calculation path by checking with different imaginary values
                                // where |real| would be compared with |imaginary|
                                Complex complex2 = new Complex(-20.0, 25.0);  // |imaginary| > |real|
                                double q2 = real / 25.0;
                                double expected2 = FastMath.abs(25.0) * FastMath.sqrt(1 + q2 * q2);
                                assertEquals(expected2, complex2.abs(), 1e-10);
                            }

    @Test
                            public void testAbsWithLargeNegativeRealBetweenBoundaries() {
                                // This test should detect the mutant by using a real value between -20 and -10
                                // where the original and mutant behave differently
                                double real = -15.0;
                                double imaginary = 3.0;
                                Complex complex = new Complex(real, imaginary);
                                
                                // Expected calculation without special case handling:
                                // q = imaginary/real = 3/-15 = -0.2
                                // magnitude = abs(real) * sqrt(1 + q²) = 15 * sqrt(1 + 0.04) ≈ 15 * 1.0198 ≈ 15.297
                                double expected = Math.abs(real) * Math.sqrt(1 + Math.pow(imaginary/real, 2));
                                
                                // The mutant would apply special handling here (since -15 < -10)
                                // while original wouldn't (since -15 > -20)
                                double actual = complex.abs();
                                
                                // Verify the calculation matches expected non-special-case behavior
                                assertEquals(expected, actual, 1e-10);
                            }

    @Test
                            public void testAbsWithVeryLargeNegativeReal() {
                                // Test with value below both boundaries (-20 and -10)
                                double real = -25.0;
                                double imaginary = 5.0;
                                Complex complex = new Complex(real, imaginary);
                                
                                // Both original and mutant should apply special handling here
                                double expected = Math.abs(real) * Math.sqrt(1 + Math.pow(imaginary/real, 2));
                                double actual = complex.abs();
                                
                                assertEquals(expected, actual, 1e-10);
                            }

    @Test
                            public void testAbsWithSmallNegativeReal1() {
                                // Test with value above both boundaries (> -10)
                                double real = -5.0;
                                double imaginary = 2.0;
                                Complex complex = new Complex(real, imaginary);
                                
                                // Neither original nor mutant should apply special handling here
                                double expected = Math.abs(real) * Math.sqrt(1 + Math.pow(imaginary/real, 2));
                                double actual = complex.abs();
                                
                                assertEquals(expected, actual, 1e-10);
                            }

    @Test
                    public void testAbsWithInfiniteImaginary2() {
                        // Create a complex number with finite real but infinite imaginary part
                        Complex complex = new Complex(1.0, Double.POSITIVE_INFINITY);
                        
                        // Verify the complex is not NaN (since only imaginary is infinite)
                        assertFalse(complex.isNaN());
                        
                        // Verify the complex is infinite (since imaginary is infinite)
                        assertTrue(complex.isInfinite());
                        
                        // Test the abs() method - should return NaN in original implementation
                        // but mutant may return incorrect value
                        double result = complex.abs();
                        
                        // Original would return NaN since imaginary is infinite
                        // Mutant would return Double.POSITIVE_INFINITY due to missing check
                        assertTrue(Double.isNaN(result));
                    }

    @Test
                    public void testAbsWithNegativeInfiniteImaginary() {
                        // Test with negative infinity case
                        Complex complex = new Complex(1.0, Double.NEGATIVE_INFINITY);
                        
                        assertFalse(complex.isNaN());
                        assertTrue(complex.isInfinite());
                        
                        double result = complex.abs();
                        assertTrue(Double.isNaN(result));
                    }

    @Test
                    public void testAbsWithBothInfinite() {
                        // Test case where both parts are infinite
                        Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                        
                        assertFalse(complex.isNaN());
                        assertTrue(complex.isInfinite());
                        
                        double result = complex.abs();
                        // Original would return POSITIVE_INFINITY from the isInfinite() check
                        // Not directly related to this mutant, but good to verify
                        assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                    }

    @Test
                    public void testAbsWithLargeRealAndNonPositiveImaginary() {
                        // Test case where real > 20.0 and imaginary <= 0
                        // This should detect the mutant that added && imaginary > 0 condition
                        
                        // Case 1: real > 20.0 and imaginary == 0
                        Complex c1 = new Complex(25.0, 0.0);
                        double expected1 = 25.0;  // sqrt(25^2 + 0^2) = 25
                        assertEquals(expected1, c1.abs(), 0.0001);
                        
                        // Case 2: real > 20.0 and imaginary < 0
                        Complex c2 = new Complex(30.0, -5.0);
                        double q = 5.0 / 30.0;  // imaginary / real
                        double expected2 = 30.0 * Math.sqrt(1 + q * q);  // should use real as base
                        assertEquals(expected2, c2.abs(), 0.0001);
                        
                        // Case 3: real > 20.0 and imaginary is negative with larger magnitude
                        Complex c3 = new Complex(25.0, -30.0);
                        double q3 = 25.0 / 30.0;  // real / imaginary
                        double expected3 = 30.0 * Math.sqrt(1 + q3 * q3);  // should use imaginary as base
                        assertEquals(expected3, c3.abs(), 0.0001);
                    }

    @Test
                public void testAbsWithLargeNegativeRealAndPositiveImaginary2() {
                    // This test case should detect the mutant
                    // real < -20.0 (true) but imaginary > 0 (false)
                    // Original would take special path, mutant wouldn't
                    Complex c = new Complex(-21.0, 5.0);
                    
                    // Calculate expected value using standard formula
                    double expected = Math.sqrt(-21.0 * -21.0 + 5.0 * 5.0);
                    
                    // The mutant would give a different result because it wouldn't take the special path
                    assertEquals(expected, c.abs(), 1e-10);
                }

    @Test
                public void testAbsWithLargeNegativeRealAndNegativeImaginary2() {
                    // Both conditions true - both original and mutant would take same path
                    Complex c = new Complex(-21.0, -5.0);
                    
                    // Expected value should be same for both
                    double expected = Math.sqrt(-21.0 * -21.0 + -5.0 * -5.0);
                    
                    assertEquals(expected, c.abs(), 1e-10);
                }

    @Test
                public void testAbsWithSmallNegativeReal2() {
                    // Neither condition true - both should behave same
                    Complex c = new Complex(-10.0, 5.0);
                    double expected = Math.sqrt(-10.0 * -10.0 + 5.0 * 5.0);
                    assertEquals(expected, c.abs(), 1e-10);
                }

    @Test
            public void testAbsWithLargeNumberToDetectMultiplicationMutation() {
                // Use a very large number where 2.0*real might differ from real+real due to floating point precision
                double largeValue = Double.MAX_VALUE / 2;
                Complex c = new Complex(largeValue, 0.0);
                
                // Calculate expected value using original implementation (2.0 * real)
                double expected = largeValue;  // Since imaginary is 0, abs should return real
                
                // The mutated version (real + real) would give same result in this case,
                // so we need a more subtle test case
                double verySmallValue = Double.MIN_VALUE * 2;
                Complex c2 = new Complex(verySmallValue, verySmallValue);
                
                // For very small numbers, the order of operations affects floating point precision
                double expected2 = Math.sqrt(2) * verySmallValue;
                double actual2 = c2.abs();
                
                // The test will fail if the mutation affects the floating point precision
                assertEquals("Small value test should detect multiplication mutation", 
                            expected2, actual2, 0.0);
                
                // Additional test with numbers where 2.0*x and x+x might differ
                double trickyValue = 1.0000000000000001;
                Complex c3 = new Complex(trickyValue, 0.0);
                double expected3 = trickyValue;
                double actual3 = c3.abs();
                
                assertEquals("Tricky value test should detect multiplication mutation",
                            expected3, actual3, 0.0);
            }

    @Test
        public void testAbsToDetectMultiplicationMutation() {
            // Use a value where 2.0*real might be optimized differently than real+real
            double value = 0.1; // 0.1 cannot be represented exactly in binary floating point
            Complex c = new Complex(value, value);
            
            // The exact calculation might differ between 2.0*real and real+real
            // due to intermediate rounding steps
            double expected = Math.sqrt(value * value + value * value);
            double actual = c.abs();
            
            // The test will fail if the mutation affects the floating point precision
            assertEquals("Should detect difference between 2.0*real and real+real", 
                        expected, actual, 0.0000000000000001);
        }

    @Test
        public void testAbsWithLargeImaginaryValue1() {
            // This test is designed to catch the mutation where 2.0*imaginary was changed to imaginary+imaginary
            // Using a value very close to Double.MAX_VALUE/2 to test potential overflow differences
            double largeValue = Double.MAX_VALUE / 2.1;
            Complex c = new Complex(1.0, largeValue);
            
            // Calculate expected value using standard formula
            double expected = Math.sqrt(1.0 + largeValue * largeValue);
            
            // The mutation might cause different behavior due to:
            // 1. Different rounding in intermediate steps
            // 2. Potential overflow differences
            double result = c.abs();
            
            // Verify the result is finite and correct
            assertFalse(Double.isInfinite(result));
            assertFalse(Double.isNaN(result));
            
            // Allow for some floating point error tolerance
            assertEquals(expected, result, expected * 1e-15);
            
            // Additional check with slightly larger value
            double largerValue = Double.MAX_VALUE / 2.0;
            Complex c2 = new Complex(1.0, largerValue);
            double result2 = c2.abs();
            assertTrue(Double.isInfinite(result2) || result2 == Double.POSITIVE_INFINITY);
        }

    @Test
        public void testAbsWithPrecisionSensitiveValue() {
            // This test uses a value where multiplication and addition might produce different rounding
            double preciseValue = 1.0000000000000001;
            Complex c = new Complex(1.0, preciseValue);
            
            // The mutation might cause different rounding in intermediate calculations
            double expected = Math.sqrt(1.0 + preciseValue * preciseValue);
            double result = c.abs();
            
            assertEquals(expected, result, 0.0); // Strict equality check
        }

}
