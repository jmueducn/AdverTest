package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import org.apache.commons.math3.util.FastMath;
 
public class RectangularCholeskyDecompositionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                        public void testConstructorWithPositiveDefiniteMatrix() {
                            // Create a simple positive definite matrix (2x2)
                            double[][] data = {{4, 12}, {12, 37}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            RectangularCholeskyDecomposition decomposition = 
                                new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                            
                            // Verify rank is full (2 for 2x2 matrix)
                            assertEquals(2, decomposition.getRank());
                            
                            // Verify root matrix
                            RealMatrix root = decomposition.getRootMatrix();
                            assertEquals(2, root.getRowDimension());
                            assertEquals(2, root.getColumnDimension());
                            
                            // Verify decomposition (should satisfy A ≈ R*R^T)
                            RealMatrix reconstructed = root.multiply(root.transpose());
                            assertArrayEquals(data[0], reconstructed.getRow(0), 1.0e-10);
                            assertArrayEquals(data[1], reconstructed.getRow(1), 1.0e-10);
                        }

    @Test
                        public void testConstructorWithPositiveSemidefiniteMatrix() {
                            // Create a positive semidefinite matrix with rank 1
                            double[][] data = {{1, 2}, {2, 4}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            RectangularCholeskyDecomposition decomposition = 
                                new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                            
                            // Verify rank is 1 (since matrix is rank deficient)
                            assertEquals(1, decomposition.getRank());
                            
                            // Verify root matrix dimensions
                            RealMatrix root = decomposition.getRootMatrix();
                            assertEquals(2, root.getRowDimension());
                            assertEquals(1, root.getColumnDimension());
                        }

    @Test
                        public void testConstructorWithNonPositiveDefiniteMatrix() {
                            // Create a matrix that's not positive definite
                            double[][] data = {{1, 2}, {2, 1}};  // Negative eigenvalues
                            
                            thrown.expect(NonPositiveDefiniteMatrixException.class);
                            new RectangularCholeskyDecomposition(MatrixUtils.createRealMatrix(data), 1.0e-10);
                        }

    @Test
                        public void testConstructorWithSmallDiagonalElement() {
                            // Create a matrix with a very small diagonal element
                            double[][] data = {{1.0e-20, 0}, {0, 1}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            // With small threshold, should throw exception
                            thrown.expect(NonPositiveDefiniteMatrixException.class);
                            new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                        }

    @Test
                        public void testConstructorWithNegativeDiagonalElement() {
                            // Create a matrix with a negative diagonal element
                            double[][] data = {{1, 0}, {0, -1}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            thrown.expect(NonPositiveDefiniteMatrixException.class);
                            thrown.expectMessage("not positive definite");
                            new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                        }

    @Test
                        public void testConstructorWithZeroMatrix() {
                            // Create a zero matrix
                            double[][] data = {{0, 0}, {0, 0}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            RectangularCholeskyDecomposition decomposition = 
                                new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                            
                            // Verify rank is 0
                            assertEquals(0, decomposition.getRank());
                            
                            // Verify root matrix is empty
                            RealMatrix root = decomposition.getRootMatrix();
                            assertEquals(2, root.getRowDimension());
                            assertEquals(0, root.getColumnDimension());
                        }

    @Test
                        public void testConstructorWithDifferentSmallThreshold() {
                            // Create a matrix with a small but acceptable diagonal element
                            double smallValue = 1.0e-5;
                            double[][] data = {{smallValue, 0}, {0, 1}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            // With appropriate threshold, should accept the matrix
                            RectangularCholeskyDecomposition decomposition = 
                                new RectangularCholeskyDecomposition(matrix, 1.0e-6);
                            
                            assertEquals(2, decomposition.getRank());
                        }

    @Test
                        public void testConstructorWithSwappedRows() {
                            // Create a matrix where rows need to be swapped during decomposition
                            double[][] data = {{1, 0.5}, {0.5, 2}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            RectangularCholeskyDecomposition decomposition = 
                                new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                            
                            // Verify decomposition is correct regardless of internal swapping
                            RealMatrix root = decomposition.getRootMatrix();
                            RealMatrix reconstructed = root.multiply(root.transpose());
                            assertArrayEquals(data[0], reconstructed.getRow(0), 1.0e-10);
                            assertArrayEquals(data[1], reconstructed.getRow(1), 1.0e-10);
                        }

    @Test
                        public void testConstructorWithLargerMatrix() {
                            // Test with a 3x3 positive definite matrix
                            double[][] data = {{4, 12, -16}, {12, 37, -43}, {-16, -43, 98}};
                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                            
                            RectangularCholeskyDecomposition decomposition = 
                                new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                            
                            assertEquals(3, decomposition.getRank());
                            
                            RealMatrix root = decomposition.getRootMatrix();
                            RealMatrix reconstructed = root.multiply(root.transpose());
                            for (int i = 0; i < 3; i++) {
                                assertArrayEquals(data[i], reconstructed.getRow(i), 1.0e-10);
                            }
                        }

    @Test
                    public void testGetRootMatrixDetectsLoopMutation() {
                        // Create a test matrix where diagonal elements are in descending order
                        // This will make the first element always the maximal one
                        double[][] testData = {
                            {4.0, 1.0, 1.0},
                            {1.0, 3.0, 0.0},
                            {1.0, 0.0, 2.0}
                        };
                        RealMatrix matrix = MatrixUtils.createRealMatrix(testData);
                        double small = 1e-10;
                        
                        // The mutation would cause unnecessary comparison of row r with itself
                        // In this case, with descending diagonal elements, it shouldn't affect the result
                        // So we need a case where the diagonal isn't strictly descending
                        
                        // Create a matrix where the maximal element is not at position r
                        double[][] testData2 = {
                            {2.0, 1.0, 1.0},
                            {1.0, 4.0, 0.0},  // Maximal element at row 1
                            {1.0, 0.0, 3.0}
                        };
                        RealMatrix matrix2 = MatrixUtils.createRealMatrix(testData2);
                        
                        // Original code would skip comparing row 0 with itself (i starts at r+1=1)
                        // Mutated code would compare row 0 with itself (i starts at r=0)
                        // Both would find row 1 as maximal, but mutated code does extra comparison
                        
                        RectangularCholeskyDecomposition original = new RectangularCholeskyDecomposition(matrix2, small);
                        RealMatrix originalRoot = original.getRootMatrix();
                        
                        // The mutation would be detected if we can verify the swap behavior
                        // We need to check if the decomposition is correct
                        // The root matrix should satisfy A ≈ R.Rᵀ
                        
                        RealMatrix reconstructed = originalRoot.multiply(originalRoot.transpose());
                        for (int i = 0; i < matrix2.getRowDimension(); i++) {
                            for (int j = 0; j < matrix2.getColumnDimension(); j++) {
                                assertEquals("Matrix reconstruction failed at ["+i+"]["+j+"]", 
                                             matrix2.getEntry(i, j), 
                                             reconstructed.getEntry(i, j), 
                                             1e-10);
                            }
                        }
                        
                        // Additional check for rank
                        assertEquals("Rank should be full for positive definite matrix", 
                                     matrix2.getRowDimension(), 
                                     original.getRank());
                    }

    @Test
                public void testGetRootMatrixDetectsLoopMutation1() throws Exception {
                    // Create a test matrix that will exercise the loop in question
                    // Need at least 3x3 matrix to ensure the inner loop executes
                    double[][] testData = {
                        {4, 1, 1},
                        {1, 5, 2},
                        {1, 2, 6}
                    };
                    RealMatrix matrix = MatrixUtils.createRealMatrix(testData);
                    double small = 1e-10;
                    
                    // Create decomposition
                    RectangularCholeskyDecomposition decomposition = 
                        new RectangularCholeskyDecomposition(matrix, small);
                    
                    // Get the root matrix
                    RealMatrix root = decomposition.getRootMatrix();
                    
                    // Verify specific values that would be affected by the mutation
                    // The mutation would affect the computation of c[ii][ij] and c[ij][ii]
                    // Check values that are computed in the inner loop
                    assertEquals(2.0, root.getEntry(0, 0), 1e-10);
                    assertEquals(0.5, root.getEntry(1, 0), 1e-10);
                    assertEquals(0.5, root.getEntry(2, 0), 1e-10);
                    
                    // These values would be different if the loop started at j=r instead of j=r+1
                    double expectedValue21 = (testData[2][1] - testData[2][0] * testData[1][0] / testData[0][0]) / 
                                            Math.sqrt(testData[1][1] - testData[1][0] * testData[1][0] / testData[0][0]);
                    assertEquals(expectedValue21, root.getEntry(2, 1), 1e-10);
                    
                    // Verify rank is correct
                    assertEquals(3, decomposition.getRank());
                }

    @Test
            public void testGetRootMatrixWithSwappedIndices() {
                // Create a test matrix that will trigger row swaps during decomposition
                double[][] testData = {
                    {4, 2, 1},
                    {2, 3, 1},  // This will need to be swapped with row 0
                    {1, 1, 2}
                };
                RealMatrix matrix = MatrixUtils.createRealMatrix(testData);
                double small = 1e-10;
                
                // Create decomposition
                RectangularCholeskyDecomposition decomposition = 
                    new RectangularCholeskyDecomposition(matrix, small);
                
                // Get the root matrix
                RealMatrix root = decomposition.getRootMatrix();
                
                // Verify the root matrix values
                // Expected values based on correct Cholesky decomposition with pivoting
                assertEquals(2.0, root.getEntry(0, 0), 1e-10);
                assertEquals(1.0, root.getEntry(0, 1), 1e-10);
                assertEquals(1.0, root.getEntry(1, 0), 1e-10);
                assertEquals(1.4142135623730951, root.getEntry(1, 1), 1e-10);
                assertEquals(0.5, root.getEntry(2, 0), 1e-10);
                assertEquals(0.7071067811865475, root.getEntry(2, 1), 1e-10);
                
                // Also verify rank
                assertEquals(2, decomposition.getRank());
            }

    @Test
        public void testGetRootMatrixWithPositiveDefiniteMatrix() {
            // Create a positive definite matrix
            double[][] data = {
                {4, 12, -16},
                {12, 37, -43},
                {-16, -43, 98}
            };
            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
            double small = 1.0e-10;
            
            // Perform decomposition
            RectangularCholeskyDecomposition decomposition = 
                new RectangularCholeskyDecomposition(matrix, small);
            
            // Get root matrix
            RealMatrix root = decomposition.getRootMatrix();
            
            // Verify properties
            assertEquals(3, root.getRowDimension()); // original matrix size
            assertEquals(3, root.getColumnDimension()); // full rank
            
            // Verify root matrix is correct by checking L*L^T ≈ original matrix
            RealMatrix reconstructed = root.multiply(root.transpose());
            assertArrayEquals(data[0], reconstructed.getRow(0), small);
            assertArrayEquals(data[1], reconstructed.getRow(1), small);
            assertArrayEquals(data[2], reconstructed.getRow(2), small);
            
            // Verify rank
            assertEquals(3, decomposition.getRank());
        }

    @Test(expected = NonPositiveDefiniteMatrixException.class)
        public void testGetRootMatrixWithNonPositiveDefiniteMatrix() {
            // Create a non-positive definite matrix
            double[][] data = {
                {1, 2},
                {2, 1}  // This matrix is not positive definite
            };
            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
            double small = 1.0e-10;
            
            // This should throw an exception
            new RectangularCholeskyDecomposition(matrix, small);
        }

    @Test
        public void testGetRootMatrixWithRankDeficientMatrix() {
            // Create a rank-deficient positive semidefinite matrix
            double[][] data = {
                {1, 2, 3},
                {2, 4, 6},
                {3, 6, 9}
            };
            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
            double small = 1.0e-10;
            
            // Perform decomposition
            RectangularCholeskyDecomposition decomposition = 
                new RectangularCholeskyDecomposition(matrix, small);
            
            // Get root matrix
            RealMatrix root = decomposition.getRootMatrix();
            
            // Verify properties
            assertEquals(3, root.getRowDimension());
            assertEquals(1, root.getColumnDimension()); // rank should be 1
            
            // Verify rank
            assertEquals(1, decomposition.getRank());
        }

}
