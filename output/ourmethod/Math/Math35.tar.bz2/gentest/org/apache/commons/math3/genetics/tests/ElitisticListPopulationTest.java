package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.Collections;
import java.util.List;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
 
public class ElitisticListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testConstructor_NullChromosomesList() {
                                                                                            // Arrange
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("List of chromosomes cannot be null");
                                                                                    
                                                                                            // Act & Assert
                                                                                            new ElitisticListPopulation(null, 10, 0.2);
                                                                                        }

    @Test
                                                                                        public void testConstructor_ZeroElitismRate() {
                                                                                            // Test with zero elitism rate (valid edge case)
                                                                                            int populationLimit = 50;
                                                                                            double elitismRate = 0.0;
                                                                                            
                                                                                            ElitisticListPopulation population = new ElitisticListPopulation(populationLimit, elitismRate);
                                                                                            
                                                                                            assertEquals(0.0, population.getElitismRate(), 0.0001);
                                                                                        }

    @Test
                                                                                        public void testConstructor_MaxElitismRate() {
                                                                                            // Test with maximum elitism rate (1.0)
                                                                                            int populationLimit = 50;
                                                                                            double elitismRate = 1.0;
                                                                                            
                                                                                            ElitisticListPopulation population = new ElitisticListPopulation(populationLimit, elitismRate);
                                                                                            
                                                                                            assertEquals(1.0, population.getElitismRate(), 0.0001);
                                                                                        }

    @Test
                                                                                public void testConstructor_EmptyChromosomesList() {
                                                                                    // Arrange
                                                                                    org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                    thrown.expectMessage("List of chromosomes cannot be empty");
                                                                                    java.util.List<org.apache.commons.math3.genetics.Chromosome> emptyList = java.util.Arrays.asList();
                                                                                
                                                                                    // Act & Assert
                                                                                    new org.apache.commons.math3.genetics.ElitisticListPopulation(emptyList, 10, 0.2);
                                                                                }

    @Test
                                                                                public void testConstructor_NegativeElitismRate() {
                                                                                    // Test with negative elitism rate (should throw exception)
                                                                                    int populationLimit = 100;
                                                                                    double elitismRate = -0.1;
                                                                                    
                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                    exception.expectMessage("elitism rate (-0.1)");
                                                                                    
                                                                                    new ElitisticListPopulation(populationLimit, elitismRate);
                                                                                }

    @Test
                                                                                public void testConstructor_ElitismRateAboveOne() {
                                                                                    // Test with elitism rate > 1.0 (should throw exception)
                                                                                    int populationLimit = 100;
                                                                                    double elitismRate = 1.1;
                                                                                    
                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                    exception.expectMessage("elitism rate (1.1)");
                                                                                    
                                                                                    new ElitisticListPopulation(populationLimit, elitismRate);
                                                                                }

    @Test
                                                                                public void testConstructor_ZeroPopulationLimit() {
                                                                                    // Test with zero population limit (should throw exception)
                                                                                    int populationLimit = 0;
                                                                                    double elitismRate = 0.5;
                                                                                    
                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                    exception.expectMessage("population limit (0)");
                                                                                    
                                                                                    new ElitisticListPopulation(populationLimit, elitismRate);
                                                                                }

    @Test
                                                                            public void testConstructor_NanElitismRate() {
                                                                                // Test with NaN elitism rate (should throw exception)
                                                                                int populationLimit = 100;
                                                                                double elitismRate = Double.NaN;
                                                                                
                                                                                try {
                                                                                    new ElitisticListPopulation(populationLimit, elitismRate);
                                                                                    fail("Expected an IllegalArgumentException to be thrown");
                                                                                } catch (IllegalArgumentException e) {
                                                                                    org.hamcrest.MatcherAssert.assertThat(e.getMessage(), 
                                                                                        org.hamcrest.CoreMatchers.containsString("elitism rate (NaN)"));
                                                                                }
                                                                            }

    @Test
                                                                        public void testConstructor_NegativePopulationLimit() {
                                                                            // Test with negative population limit (should throw exception)
                                                                            int populationLimit = -10;
                                                                            double elitismRate = 0.3;
                                                                            
                                                                            try {
                                                                                new ElitisticListPopulation(populationLimit, elitismRate);
                                                                                fail("Expected an IllegalArgumentException to be thrown");
                                                                            } catch (IllegalArgumentException e) {
                                                                                assertTrue(e.getMessage().contains("population limit (-10)"));
                                                                            }
                                                                        }

    @Test
                                                                    public void testSetElitismRate_ValidValues() {
                                                                        // Arrange
                                                                        org.apache.commons.math3.genetics.Chromosome chromosome = new org.apache.commons.math3.genetics.Chromosome() {
                                                                            @Override
                                                                            public double fitness() {
                                                                                return 0;
                                                                            }
                                                                        };
                                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = java.util.Arrays.asList(chromosome);
                                                                        org.apache.commons.math3.genetics.ElitisticListPopulation population = 
                                                                            new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 10, 0.2);
                                                                        
                                                                        // Act & Assert for various valid values
                                                                        population.setElitismRate(0.0);
                                                                        org.junit.Assert.assertEquals(0.0, population.getElitismRate(), 0.0001);
                                                                        
                                                                        population.setElitismRate(0.5);
                                                                        org.junit.Assert.assertEquals(0.5, population.getElitismRate(), 0.0001);
                                                                        
                                                                        population.setElitismRate(1.0);
                                                                        org.junit.Assert.assertEquals(1.0, population.getElitismRate(), 0.0001);
                                                                    }

    @Test
                                                                    public void testSetElitismRate_InvalidHighValue() {
                                                                        // Arrange
                                                                        org.apache.commons.math3.genetics.Chromosome chromosome = 
                                                                            new org.apache.commons.math3.genetics.Chromosome() {
                                                                                @Override
                                                                                public double fitness() {
                                                                                    return 0;
                                                                                }
                                                                            };
                                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                                            java.util.Arrays.asList(chromosome);
                                                                        org.apache.commons.math3.genetics.ElitisticListPopulation population = 
                                                                            new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 10, 0.2);
                                                                        
                                                                        try {
                                                                            // Act
                                                                            population.setElitismRate(1.1);
                                                                            org.junit.Assert.fail("Expected an IllegalArgumentException to be thrown");
                                                                        } catch (IllegalArgumentException e) {
                                                                            // Assert
                                                                            org.junit.Assert.assertEquals("Elitism rate has to be in [0,1]", e.getMessage());
                                                                        }
                                                                    }

    @Test
                                                    public void testConstructor_ElitismRateTooHigh() {
                                                        // Arrange
                                                        org.apache.commons.math3.genetics.Chromosome chromosome = 
                                                            new org.apache.commons.math3.genetics.Chromosome() {
                                                                @Override
                                                                public double fitness() {
                                                                    return 0;
                                                                }
                                                            };
                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                            java.util.Arrays.asList(chromosome);
                                                        
                                                        try {
                                                            // Act
                                                            new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 10, 1.1);
                                                            org.junit.Assert.fail("Expected an IllegalArgumentException to be thrown");
                                                        } catch (IllegalArgumentException e) {
                                                            // Assert
                                                            org.junit.Assert.assertEquals("Elitism rate has to be in [0,1]", e.getMessage());
                                                        }
                                                    }

    @Test
                                                    public void testSetElitismRate_InvalidValues() {
                                                        // Arrange
                                                        org.apache.commons.math3.genetics.Chromosome chromosome = 
                                                            new org.apache.commons.math3.genetics.Chromosome() {
                                                                @Override
                                                                public double fitness() {
                                                                    return 0;
                                                                }
                                                            };
                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                            java.util.Arrays.asList(chromosome);
                                                        org.apache.commons.math3.genetics.ElitisticListPopulation population = 
                                                            new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 10, 0.2);
                                                        
                                                        // Test for value too low
                                                        try {
                                                            population.setElitismRate(-0.1);
                                                            org.junit.Assert.fail("Expected IllegalArgumentException");
                                                        } catch (IllegalArgumentException e) {
                                                            org.junit.Assert.assertEquals("Elitism rate has to be in [0,1]", e.getMessage());
                                                        }
                                                        
                                                        // Test for value too high
                                                        try {
                                                            population.setElitismRate(1.1);
                                                            org.junit.Assert.fail("Expected IllegalArgumentException");
                                                        } catch (IllegalArgumentException e) {
                                                            org.junit.Assert.assertEquals("Elitism rate has to be in [0,1]", e.getMessage());
                                                        }
                                                    }

    @Test
                                                    public void testConstructor_ElitismRateTooLow() {
                                                        // Arrange
                                                        org.apache.commons.math3.genetics.Chromosome chromosome = 
                                                            new org.apache.commons.math3.genetics.Chromosome() {
                                                                @Override
                                                                public double fitness() {
                                                                    return 0;
                                                                }
                                                            };
                                                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                            java.util.Arrays.asList(chromosome);
                                                        
                                                        // Set up exception expectation
                                                        org.junit.rules.ExpectedException expectedException = 
                                                            org.junit.rules.ExpectedException.none();
                                                        expectedException.expect(IllegalArgumentException.class);
                                                        expectedException.expectMessage("Elitism rate has to be in [0,1]");
                                                        
                                                        // Act & Assert
                                                        new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 10, -0.1);
                                                    }

    @Test
                                            public void testConstructor_InvalidPopulationLimit() {
                                                // Arrange
                                                org.apache.commons.math3.genetics.Chromosome chromosome = 
                                                    new org.apache.commons.math3.genetics.Chromosome() {
                                                        @Override
                                                        public double fitness() {
                                                            return 0;
                                                        }
                                                    };
                                                java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                                                    java.util.Arrays.asList(chromosome);
                                                
                                                // Set up expected exception
                                                org.junit.rules.ExpectedException exceptionRule = 
                                                    org.junit.rules.ExpectedException.none();
                                                exceptionRule.expect(org.apache.commons.math3.exception.NotPositiveException.class);
                                                exceptionRule.expectMessage("population limit has to be positive");
                                                
                                                // Act & Assert
                                                new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, 0, 0.2);
                                            }

    @Test
                    public void testConstructor_ValidParameters() {
                        // Arrange
                        org.apache.commons.math3.genetics.Chromosome chromosome1 = new org.apache.commons.math3.genetics.BinaryChromosome(java.util.Arrays.asList(0, 1)) {
                            @Override
                            public double fitness() {
                                return 0;
                            }
                            @Override
                            public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(java.util.List<Integer> chromosomeRepresentation) {
                                return new org.apache.commons.math3.genetics.BinaryChromosome(chromosomeRepresentation) {
                                    @Override
                                    public double fitness() {
                                        return 0;
                                    }
                                    @Override
                                    public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(List<Integer> chromosomeRepresentation) {
                                        return new org.apache.commons.math3.genetics.BinaryChromosome(chromosomeRepresentation) {
                                            @Override
                                            public double fitness() {
                                                return 0;
                                            }
                                            @Override
                                            public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(List<Integer> chromosomeRepresentation) {
                                                return new org.apache.commons.math3.genetics.BinaryChromosome(chromosomeRepresentation) {
                                                    @Override
                                                    public double fitness() {
                                                        return 0;
                                                    }
                                                    @Override
                                                    public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(List<Integer> chromosomeRepresentation) {
                                                        return null;
                                                    }
                                                };
                                            }
                                        };
                                    }
                                };
                            }
                        };
                        org.apache.commons.math3.genetics.Chromosome chromosome2 = new org.apache.commons.math3.genetics.BinaryChromosome(java.util.Arrays.asList(1, 0)) {
                            @Override
                            public double fitness() {
                                return 0;
                            }
                            @Override
                            public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(java.util.List<Integer> chromosomeRepresentation) {
                                return new org.apache.commons.math3.genetics.BinaryChromosome(chromosomeRepresentation) {
                                    @Override
                                    public double fitness() {
                                        return 0;
                                    }
                                    @Override
                                    public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(List<Integer> chromosomeRepresentation) {
                                        return new org.apache.commons.math3.genetics.BinaryChromosome(chromosomeRepresentation) {
                                            @Override
                                            public double fitness() {
                                                return 0;
                                            }
                                            @Override
                                            public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(List<Integer> chromosomeRepresentation) {
                                                return new org.apache.commons.math3.genetics.BinaryChromosome(chromosomeRepresentation) {
                                                    @Override
                                                    public double fitness() {
                                                        return 0;
                                                    }
                                                    @Override
                                                    public org.apache.commons.math3.genetics.AbstractListChromosome<Integer> newFixedLengthChromosome(List<Integer> chromosomeRepresentation) {
                                                        return null;
                                                    }
                                                };
                                            }
                                        };
                                    }
                                };
                            }
                        };
                        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomes = 
                            java.util.Arrays.asList(chromosome1, chromosome2);
                        int populationLimit = 10;
                        double elitismRate = 0.2;
                        
                        // Act
                        org.apache.commons.math3.genetics.ElitisticListPopulation population = 
                            new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomes, populationLimit, elitismRate);
                        
                        // Assert
                        org.junit.Assert.assertEquals(2, population.getPopulationSize());
                        org.junit.Assert.assertEquals(10, population.getPopulationLimit());
                        org.junit.Assert.assertEquals(0.2, population.getElitismRate(), 0.0001);
                    }

    @Test
                public void testConstructor_ValidParameters1() {
                    // Arrange
                    // Define required classes
                    class Chromosome {}
                    class ElitisticListPopulation {
                        private List<Chromosome> chromosomes;
                        private int populationLimit;
                        private double elitismRate;
                        
                        public ElitisticListPopulation(List<Chromosome> chromosomes, int populationLimit, double elitismRate) {
                            this.chromosomes = chromosomes;
                            this.populationLimit = populationLimit;
                            this.elitismRate = elitismRate;
                        }
                        
                        public int getPopulationSize() { return chromosomes.size(); }
                        public int getPopulationLimit() { return populationLimit; }
                        public double getElitismRate() { return elitismRate; }
                    }
                    
                    // Create test objects
                    Chromosome chromosome1 = new Chromosome();
                    Chromosome chromosome2 = new Chromosome();
                    List<Chromosome> chromosomes = new java.util.ArrayList<Chromosome>();
                    chromosomes.add(chromosome1);
                    chromosomes.add(chromosome2);
                    int populationLimit = 10;
                    double elitismRate = 0.2;
                    
                    // Act
                    ElitisticListPopulation population = new ElitisticListPopulation(chromosomes, populationLimit, elitismRate);
                    
                    // Assert
                    org.junit.Assert.assertEquals(2, population.getPopulationSize());
                    org.junit.Assert.assertEquals(10, population.getPopulationLimit());
                    org.junit.Assert.assertEquals(0.2, population.getElitismRate(), 0.0001);
                }

    @Test
                public void testConstructorSetsElitismRate() {
                    // Test the constructor that takes populationLimit and elitismRate
                    double testRate = 0.2;
                    int testLimit = 100;
                    
                    ElitisticListPopulation population = new ElitisticListPopulation(testLimit, testRate);
                    
                    // Verify the elitism rate was properly set
                    assertEquals(testRate, population.getElitismRate(), 0.0001);
                }

    @Test
        public void testNextGenerationPreservesElitismRate() {
            // Setup test data
            double originalRate = 0.3;
            int populationLimit = 10;
            List<Chromosome> chromosomes = new ArrayList<Chromosome>();
            chromosomes.add(new Chromosome() {
                @Override
                public double fitness() {
                    return 0;
                }
            });
            chromosomes.add(new Chromosome() {
                @Override
                public double fitness() {
                    return 0;
                }
            });
            
            // Create original population
            ElitisticListPopulation original = new ElitisticListPopulation(chromosomes, populationLimit, originalRate);
            
            // Generate next generation
            Population nextGenPopulation = original.nextGeneration();
            ElitisticListPopulation nextGen = (ElitisticListPopulation) nextGenPopulation;
            
            // Verify the elitism rate was preserved
            assertEquals(originalRate, nextGen.getElitismRate(), 0.0001);
        }

    @Test
    public void testNextGenerationWithDifferentElitismRates() {
        // Test with different elitism rates to ensure they're properly passed
        double[] testRates = {0.0, 0.1, 0.5, 0.9, 1.0};
        int populationLimit = 10;
        Chromosome chromosome1 = new Chromosome() {
            @Override
            public double fitness() {
                return 0;
            }
        };
        Chromosome chromosome2 = new Chromosome() {
            @Override
            public double fitness() {
                return 0;
            }
        };
        java.util.List<Chromosome> chromosomes = java.util.Arrays.asList(chromosome1, chromosome2);
        
        for (double rate : testRates) {
            ElitisticListPopulation original = new ElitisticListPopulation(chromosomes, populationLimit, rate);
            Population nextGenPopulation = original.nextGeneration();
            ElitisticListPopulation nextGen = (ElitisticListPopulation) nextGenPopulation;
            assertEquals(rate, nextGen.getElitismRate(), 0.0001);
        }
    }


}
