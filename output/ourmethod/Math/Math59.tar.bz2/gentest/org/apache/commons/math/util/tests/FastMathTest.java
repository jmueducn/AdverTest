package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
 
public class FastMathTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                public void testMaxInt() {
                    // Typical cases
                    assertEquals(5, FastMath.max(3, 5));
                    assertEquals(5, FastMath.max(5, 3));
                    assertEquals(-3, FastMath.max(-3, -5));
                    assertEquals(-3, FastMath.max(-5, -3));
                    
                    // Edge cases
                    assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
                    assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MAX_VALUE));
                    assertEquals(0, FastMath.max(0, 0));
                    assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MAX_VALUE));
                    assertEquals(Integer.MIN_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MIN_VALUE));
                    
                    // Equal values
                    assertEquals(10, FastMath.max(10, 10));
                }

    @Test
                public void testMaxLong() {
                    // Typical cases
                    assertEquals(500L, FastMath.max(300L, 500L));
                    assertEquals(500L, FastMath.max(500L, 300L));
                    assertEquals(-300L, FastMath.max(-300L, -500L));
                    assertEquals(-300L, FastMath.max(-500L, -300L));
                    
                    // Edge cases
                    assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
                    assertEquals(Long.MAX_VALUE, FastMath.max(Long.MIN_VALUE, Long.MAX_VALUE));
                    assertEquals(0L, FastMath.max(0L, 0L));
                    assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MAX_VALUE));
                    assertEquals(Long.MIN_VALUE, FastMath.max(Long.MIN_VALUE, Long.MIN_VALUE));
                    
                    // Equal values
                    assertEquals(1000L, FastMath.max(1000L, 1000L));
                }

    @Test
                public void testMaxFloat() {
                    // Typical cases
                    assertEquals(5.5f, FastMath.max(3.2f, 5.5f), 0.0001f);
                    assertEquals(5.5f, FastMath.max(5.5f, 3.2f), 0.0001f);
                    assertEquals(-3.2f, FastMath.max(-3.2f, -5.5f), 0.0001f);
                    assertEquals(-3.2f, FastMath.max(-5.5f, -3.2f), 0.0001f);
                    
                    // Edge cases
                    assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY), 0.0f);
                    assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY), 0.0f);
                    assertEquals(Float.MAX_VALUE, FastMath.max(Float.MAX_VALUE, Float.MIN_VALUE), 0.0f);
                    assertEquals(Float.MAX_VALUE, FastMath.max(Float.MIN_VALUE, Float.MAX_VALUE), 0.0f);
                    assertEquals(0.0f, FastMath.max(0.0f, 0.0f), 0.0f);
                    assertEquals(Float.NaN, FastMath.max(Float.NaN, 5.0f), 0.0f);
                    assertEquals(Float.NaN, FastMath.max(5.0f, Float.NaN), 0.0f);
                    assertEquals(Float.NaN, FastMath.max(Float.NaN, Float.NaN), 0.0f);
                    
                    // Equal values
                    assertEquals(7.7f, FastMath.max(7.7f, 7.7f), 0.0001f);
                }

    @Test
                public void testMaxDouble() {
                    // Typical cases
                    assertEquals(5.5, FastMath.max(3.2, 5.5), 0.0001);
                    assertEquals(5.5, FastMath.max(5.5, 3.2), 0.0001);
                    assertEquals(-3.2, FastMath.max(-3.2, -5.5), 0.0001);
                    assertEquals(-3.2, FastMath.max(-5.5, -3.2), 0.0001);
                    
                    // Edge cases
                    assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY), 0.0);
                    assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY), 0.0);
                    assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.MIN_VALUE), 0.0);
                    assertEquals(Double.MAX_VALUE, FastMath.max(Double.MIN_VALUE, Double.MAX_VALUE), 0.0);
                    assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0);
                    assertEquals(Double.NaN, FastMath.max(Double.NaN, 5.0), 0.0);
                    assertEquals(Double.NaN, FastMath.max(5.0, Double.NaN), 0.0);
                    assertEquals(Double.NaN, FastMath.max(Double.NaN, Double.NaN), 0.0);
                    
                    // Equal values
                    assertEquals(7.7, FastMath.max(7.7, 7.7), 0.0001);
                }

    @Test
                public void testMaxInt1() {
                    // Typical cases
                    assertEquals(5, FastMath.max(3, 5));
                    assertEquals(5, FastMath.max(5, 3));
                    assertEquals(-1, FastMath.max(-1, -5));
                    assertEquals(-1, FastMath.max(-5, -1));
                    
                    // Edge cases
                    assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, 0));
                    assertEquals(0, FastMath.max(Integer.MIN_VALUE, 0));
                    assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
                    
                    // Equal values
                    assertEquals(10, FastMath.max(10, 10));
                    assertEquals(0, FastMath.max(0, 0));
                    assertEquals(-1, FastMath.max(-1, -1));
                }

    @Test
                public void testMaxLong1() {
                    // Typical cases
                    assertEquals(500L, FastMath.max(300L, 500L));
                    assertEquals(500L, FastMath.max(500L, 300L));
                    assertEquals(-100L, FastMath.max(-100L, -500L));
                    assertEquals(-100L, FastMath.max(-500L, -100L));
                    
                    // Edge cases
                    assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, 0L));
                    assertEquals(0L, FastMath.max(Long.MIN_VALUE, 0L));
                    assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
                    
                    // Equal values
                    assertEquals(1000L, FastMath.max(1000L, 1000L));
                    assertEquals(0L, FastMath.max(0L, 0L));
                    assertEquals(-1L, FastMath.max(-1L, -1L));
                }

    @Test
                public void testMaxFloat1() {
                    // Typical cases
                    assertEquals(5.5f, FastMath.max(3.2f, 5.5f), 0.0001f);
                    assertEquals(5.5f, FastMath.max(5.5f, 3.2f), 0.0001f);
                    assertEquals(-1.1f, FastMath.max(-1.1f, -5.5f), 0.0001f);
                    assertEquals(-1.1f, FastMath.max(-5.5f, -1.1f), 0.0001f);
                    
                    // Edge cases
                    assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, 0f), 0.0001f);
                    assertEquals(0f, FastMath.max(Float.NEGATIVE_INFINITY, 0f), 0.0001f);
                    assertEquals(Float.MAX_VALUE, FastMath.max(Float.MAX_VALUE, Float.MIN_VALUE), 0.0001f);
                    assertEquals(Float.NaN, FastMath.max(Float.NaN, 5f), 0.0001f);
                    assertEquals(Float.NaN, FastMath.max(5f, Float.NaN), 0.0001f);
                    
                    // Equal values
                    assertEquals(10.1f, FastMath.max(10.1f, 10.1f), 0.0001f);
                    assertEquals(0f, FastMath.max(0f, 0f), 0.0001f);
                    assertEquals(-1.5f, FastMath.max(-1.5f, -1.5f), 0.0001f);
                }

    @Test
                public void testMaxDouble1() {
                    // Typical cases
                    assertEquals(5.5, FastMath.max(3.2, 5.5), 0.0001);
                    assertEquals(5.5, FastMath.max(5.5, 3.2), 0.0001);
                    assertEquals(-1.1, FastMath.max(-1.1, -5.5), 0.0001);
                    assertEquals(-1.1, FastMath.max(-5.5, -1.1), 0.0001);
                    
                    // Edge cases
                    assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, 0), 0.0001);
                    assertEquals(0, FastMath.max(Double.NEGATIVE_INFINITY, 0), 0.0001);
                    assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.MIN_VALUE), 0.0001);
                    assertEquals(Double.NaN, FastMath.max(Double.NaN, 5), 0.0001);
                    assertEquals(Double.NaN, FastMath.max(5, Double.NaN), 0.0001);
                    
                    // Equal values
                    assertEquals(10.1, FastMath.max(10.1, 10.1), 0.0001);
                    assertEquals(0, FastMath.max(0, 0), 0.0001);
                    assertEquals(-1.5, FastMath.max(-1.5, -1.5), 0.0001);
                }

    @Test
                public void testMax_FirstArgumentGreater() {
                    float result = FastMath.max(5.0f, 3.0f);
                    assertEquals(5.0f, result, 0.0f);
                }

    @Test
                public void testMax_SecondArgumentGreater() {
                    float result = FastMath.max(2.0f, 4.0f);
                    assertEquals(4.0f, result, 0.0f);
                }

    @Test
                public void testMax_EqualArguments() {
                    float result = FastMath.max(3.5f, 3.5f);
                    assertEquals(3.5f, result, 0.0f);
                }

    @Test
                public void testMax_FirstArgumentNaN() {
                    float result = FastMath.max(Float.NaN, 5.0f);
                    assertTrue(Float.isNaN(result));
                }

    @Test
                public void testMax_SecondArgumentNaN() {
                    float result = FastMath.max(5.0f, Float.NaN);
                    assertTrue(Float.isNaN(result));
                }

    @Test
                public void testMax_BothArgumentsNaN() {
                    float result = FastMath.max(Float.NaN, Float.NaN);
                    assertTrue(Float.isNaN(result));
                }

    @Test
                public void testMax_NegativeNumbers() {
                    float result = FastMath.max(-3.0f, -1.0f);
                    assertEquals(-1.0f, result, 0.0f);
                }

    @Test
                public void testMax_PositiveAndNegative() {
                    float result = FastMath.max(-5.0f, 5.0f);
                    assertEquals(5.0f, result, 0.0f);
                }

    @Test
                public void testMax_ZeroAndPositive() {
                    float result = FastMath.max(0.0f, 2.0f);
                    assertEquals(2.0f, result, 0.0f);
                }

    @Test
                public void testMax_ZeroAndNegative() {
                    float result = FastMath.max(0.0f, -2.0f);
                    assertEquals(0.0f, result, 0.0f);
                }

    @Test
                public void testMax_MaxFloatValue() {
                    float result = FastMath.max(Float.MAX_VALUE, Float.MAX_VALUE / 2);
                    assertEquals(Float.MAX_VALUE, result, 0.0f);
                }

    @Test
                public void testMax_MinFloatValue() {
                    float result = FastMath.max(Float.MIN_VALUE, -Float.MIN_VALUE);
                    assertEquals(Float.MIN_VALUE, result, 0.0f);
                }

    @Test
                public void testMax_PositiveInfinity() {
                    float result = FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE);
                    assertEquals(Float.POSITIVE_INFINITY, result, 0.0f);
                }

    @Test
                public void testMax_NegativeInfinity() {
                    float result = FastMath.max(Float.NEGATIVE_INFINITY, -Float.MAX_VALUE);
                    assertEquals(-Float.MAX_VALUE, result, 0.0f);
                }

    @Test
                public void testMax_InfinityAndNaN() {
                    float result = FastMath.max(Float.POSITIVE_INFINITY, Float.NaN);
                    assertTrue(Float.isNaN(result));
                }

    @Test
                public void testMax_TypicalValues() {
                    // Test typical cases where a < b and a > b
                    assertEquals(5.0, FastMath.max(3.0, 5.0), 0.0001);
                    assertEquals(5.0, FastMath.max(5.0, 3.0), 0.0001);
                    assertEquals(-3.0, FastMath.max(-3.0, -5.0), 0.0001);
                    assertEquals(-3.0, FastMath.max(-5.0, -3.0), 0.0001);
                }

    @Test
                public void testMax_EqualValues() {
                    // Test when values are equal
                    assertEquals(4.0, FastMath.max(4.0, 4.0), 0.0001);
                    assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0001);
                    assertEquals(-7.0, FastMath.max(-7.0, -7.0), 0.0001);
                }

    @Test
                public void testMax_InfinityCases() {
                    // Test with infinity values
                    assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, 1000.0), 0.0001);
                    assertEquals(Double.POSITIVE_INFINITY, FastMath.max(1000.0, Double.POSITIVE_INFINITY), 0.0001);
                    assertEquals(1000.0, FastMath.max(Double.NEGATIVE_INFINITY, 1000.0), 0.0001);
                    assertEquals(1000.0, FastMath.max(1000.0, Double.NEGATIVE_INFINITY), 0.0001);
                    assertEquals(Double.POSITIVE_INFINITY, 
                                FastMath.max(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY), 0.0001);
                }

    @Test
                public void testMax_NaNHandling() {
                    // Test NaN cases - should return NaN if either argument is NaN
                    assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
                    assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
                    assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
                    assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.POSITIVE_INFINITY)));
                    assertTrue(Double.isNaN(FastMath.max(Double.NEGATIVE_INFINITY, Double.NaN)));
                }

    @Test
                public void testMax_ZeroCases() {
                    // Test with positive and negative zero
                    assertEquals(0.0, FastMath.max(0.0, -0.0), 0.0001);
                    assertEquals(0.0, FastMath.max(-0.0, 0.0), 0.0001);
                    assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0001);
                    assertEquals(-0.0, FastMath.max(-0.0, -0.0), 0.0001);
                }

    @Test
                public void testMax_SubnormalNumbers() {
                    // Test with subnormal numbers
                    double smallest = Double.MIN_VALUE;
                    assertEquals(smallest, FastMath.max(smallest, 0.0), 0.0001);
                    assertEquals(smallest, FastMath.max(0.0, smallest), 0.0001);
                    assertEquals(smallest*2, FastMath.max(smallest, smallest*2), 0.0001);
                }

    @Test
                public void testMax_LargeNumbers() {
                    // Test with very large numbers
                    double large = Double.MAX_VALUE;
                    double larger = large - 1.0;
                    assertEquals(large, FastMath.max(large, larger), 0.0001);
                    assertEquals(large, FastMath.max(larger, large), 0.0001);
                }

    @Test
            public void testSqrtBoundaryCondition() {
                // Test case where a equals b (boundary condition)
                double a = 4.0;
                double b = 4.0;
                
                // Original behavior should return b when a <= b
                double expected = b;
                
                // Mutated behavior would take the other branch
                double actual = FastMath.sqrt(a);
                
                // Assert that we get the correct behavior (should be b)
                assertEquals("Square root should return b when a equals b", 
                            expected, actual, 0.0);
                
                // Additional test case where a is less than b
                a = 3.0;
                b = 4.0;
                expected = b;
                actual = FastMath.sqrt(a);
                assertEquals("Square root should return b when a < b",
                            expected, actual, 0.0);
                
                // Test case where a is greater than b
                a = 5.0;
                b = 4.0;
                expected = a;  // Assuming original behavior would return a in this case
                actual = FastMath.sqrt(a);
                assertEquals("Square root should return a when a > b",
                            expected, actual, 0.0);
            }

    @Test
        public void testSqrt() {
            double input = 4.0;
            double expected = 2.0;
            double actual = FastMath.sqrt(input);
            assertEquals(expected, actual, 0.0001);
            
            input = 2.0;
            expected = Math.sqrt(2.0);
            actual = FastMath.sqrt(input);
            assertEquals(expected, actual, 0.0001);
            
            input = -1.0;
            expected = Double.NaN;
            actual = FastMath.sqrt(input);
            assertEquals(expected, actual, 0.0);
        }

    @Test
        public void testSqrtWithNaNValues() {
            // Test case where a is NaN and b is normal
            double a = Double.NaN;
            double b = 5.0;
            double expected = Double.NaN;
            double actual = FastMath.sqrt(a);
            assertTrue("Should return NaN when a is NaN", Double.isNaN(actual));
            
            // Test case where a is normal and b is NaN
            a = 4.0;
            b = Double.NaN;
            actual = FastMath.sqrt(a);
            assertFalse("Should not return NaN when only b is NaN", Double.isNaN(actual));
            assertEquals(2.0, actual, 0.0001);
            
            // Test case where both are NaN
            a = Double.NaN;
            b = Double.NaN;
            actual = FastMath.sqrt(a);
            assertTrue("Should return NaN when both a and b are NaN", Double.isNaN(actual));
            
            // Test case with normal numbers
            a = 9.0;
            b = 2.0;
            actual = FastMath.sqrt(a);
            assertEquals(3.0, actual, 0.0001);
        }

}
