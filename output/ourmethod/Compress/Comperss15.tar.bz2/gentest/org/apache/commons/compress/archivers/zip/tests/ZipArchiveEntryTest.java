package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testEquals_Reflexive() {
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    assertTrue(entry.equals(entry));
                                                }

    @Test
                                                public void testEquals_NullComparison() {
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    assertFalse(entry.equals(null));
                                                }

    @Test
                                                public void testEquals_DifferentClass() {
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    assertFalse(entry.equals("string object"));
                                                }

    @Test
                                                public void testEquals_DifferentName() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentTime() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    entry1.setTime(1000L);
                                                    entry2.setTime(2000L);
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentComment() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    entry1.setComment("comment1");
                                                    entry2.setComment("comment2");
                                                    assertFalse(entry1.equals(entry2));
                                            
                                                    // Test null comments
                                                    entry1.setComment(null);
                                                    entry2.setComment("");
                                                    assertTrue(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentInternalAttributes() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    entry1.setInternalAttributes(1);
                                                    entry2.setInternalAttributes(2);
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentExternalAttributes() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    entry1.setExternalAttributes(1L);
                                                    entry2.setExternalAttributes(2L);
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentMethod() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    entry1.setMethod(1);
                                                    entry2.setMethod(2);
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentSize() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    entry1.setSize(100L);
                                                    entry2.setSize(200L);
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentCrc() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    // Need to mock or find a way to set CRC
                                                    // This might require reflection since there's no setCrc method
                                                    // For demonstration, we'll assume we can set it
                                                    try {
                                                        java.lang.reflect.Field crcField = ZipArchiveEntry.class.getDeclaredField("crc");
                                                        crcField.setAccessible(true);
                                                        crcField.set(entry1, 100L);
                                                        crcField.set(entry2, 200L);
                                                        assertFalse(entry1.equals(entry2));
                                                    } catch (Exception e) {
                                                        fail("Failed to test CRC comparison due to reflection error");
                                                    }
                                                }

    @Test
                                                public void testEquals_DifferentCompressedSize() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    // Similar to CRC, might need reflection to set compressedSize
                                                    try {
                                                        java.lang.reflect.Field sizeField = ZipArchiveEntry.class.getDeclaredField("compressedSize");
                                                        sizeField.setAccessible(true);
                                                        sizeField.set(entry1, 100L);
                                                        sizeField.set(entry2, 200L);
                                                        assertFalse(entry1.equals(entry2));
                                                    } catch (Exception e) {
                                                        fail("Failed to test compressedSize comparison due to reflection error");
                                                    }
                                                }

    @Test
                                                public void testEquals_DifferentExtraFields() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    entry1.setCentralDirectoryExtra(new byte[]{1, 2, 3});
                                                    entry2.setCentralDirectoryExtra(new byte[]{4, 5, 6});
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                                public void testEquals_DifferentGPB() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                    GeneralPurposeBit gpb1 = mock(GeneralPurposeBit.class);
                                                    GeneralPurposeBit gpb2 = mock(GeneralPurposeBit.class);
                                                    when(gpb1.equals(gpb2)).thenReturn(false);
                                                    
                                                    entry1.setGeneralPurposeBit(gpb1);
                                                    entry2.setGeneralPurposeBit(gpb2);
                                                    assertFalse(entry1.equals(entry2));
                                                }

    @Test
                                        public void testEquals_NullName() {
                                            ZipArchiveEntry entry1 = new ZipArchiveEntry((String) null);
                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                            assertFalse(entry1.equals(entry2));
                                            
                                            ZipArchiveEntry entry3 = new ZipArchiveEntry((String) null);
                                            assertTrue(entry1.equals(entry3));
                                        }

    @Test
                                        public void testEquals_DifferentPlatform() throws Exception {
                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                            
                                            // Use reflection to access protected setPlatform method
                                            Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                            setPlatform.setAccessible(true);
                                            setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_UNIX);
                                            setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                            
                                            assertFalse(entry1.equals(entry2));
                                        }

    @Test
                                        public void testEquals_AllAttributesSame() {
                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                            
                                            // Set all attributes to the same values
                                            entry1.setTime(1000L);
                                            entry2.setTime(1000L);
                                            entry1.setComment("comment");
                                            entry2.setComment("comment");
                                            entry1.setInternalAttributes(1);
                                            entry2.setInternalAttributes(1);
                                            // Using setUnixMode() instead of setPlatform() since it's public
                                            entry1.setUnixMode(0);
                                            entry2.setUnixMode(0);
                                            entry1.setExternalAttributes(1L);
                                            entry2.setExternalAttributes(1L);
                                            entry1.setMethod(1);
                                            entry2.setMethod(1);
                                            entry1.setSize(100L);
                                            entry2.setSize(100L);
                                            entry1.setCentralDirectoryExtra(new byte[]{1, 2, 3});
                                            entry2.setCentralDirectoryExtra(new byte[]{1, 2, 3});
                                            
                                            GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                            when(gpb.equals(gpb)).thenReturn(true);
                                            entry1.setGeneralPurposeBit(gpb);
                                            entry2.setGeneralPurposeBit(gpb);
                                            
                                            assertTrue(entry1.equals(entry2));
                                        }

    @Test
                                   public void testEqualsWithCommentsShouldDetectCommentMutation() {
                                       // Create two entries that should be equal in all aspects including comments
                                       ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                       
                                       // Set matching comments (non-null)
                                       entry1.setComment("comment");
                                       entry2.setComment("comment");
                                       
                                       // Set all other attributes to be equal
                                       entry1.setTime(12345L);
                                       entry2.setTime(12345L);
                                       entry1.setInternalAttributes(1);
                                       entry2.setInternalAttributes(1);
                                       
                                       // Use reflection to set protected platform field
                                       try {
                                           Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                           setPlatform.setAccessible(true);
                                           setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                                           setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                       } catch (Exception e) {
                                           fail("Failed to set platform via reflection: " + e.getMessage());
                                       }
                                       
                                       entry1.setExternalAttributes(2L);
                                       entry2.setExternalAttributes(2L);
                                       entry1.setMethod(3);
                                       entry2.setMethod(3);
                                       entry1.setSize(100L);
                                       entry2.setSize(100L);
                                       entry1.setCrc(123L);
                                       entry2.setCrc(123L);
                                       entry1.setCompressedSize(80L);
                                       entry2.setCompressedSize(80L);
                                       entry1.setExtra(new byte[]{1,2,3});
                                       entry2.setExtra(new byte[]{1,2,3});
                                       
                                       // Create mock GeneralPurposeBit that will return true for equals
                                       GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                       when(gpb.equals(any(GeneralPurposeBit.class))).thenReturn(true);
                                       entry1.setGeneralPurposeBit(gpb);
                                       entry2.setGeneralPurposeBit(gpb);
                                       
                                       // Test - should be equal with original code, but mutant will fail
                                       assertTrue("Entries with matching comments should be equal", entry1.equals(entry2));
                                   }

    @Test
                              public void testEqualsWithDifferentCommentsShouldReturnFalse() {
                                  // Create two entries with same attributes but different comments
                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                  
                                  // Set all other relevant fields to be equal
                                  entry1.setTime(12345L);
                                  entry2.setTime(12345L);
                                  entry1.setInternalAttributes(1);
                                  entry2.setInternalAttributes(1);
                                  
                                  // Use reflection to set protected platform field
                                  try {
                                      Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                      setPlatform.setAccessible(true);
                                      setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                                      setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                  } catch (Exception e) {
                                      fail("Failed to set platform via reflection: " + e.getMessage());
                                  }
                                  
                                  entry1.setExternalAttributes(100L);
                                  entry2.setExternalAttributes(100L);
                                  entry1.setMethod(8);
                                  entry2.setMethod(8);
                                  entry1.setSize(1000L);
                                  entry2.setSize(1000L);
                                  entry1.setGeneralPurposeBit(new GeneralPurposeBit());
                                  entry2.setGeneralPurposeBit(new GeneralPurposeBit());
                                  
                                  // Set different comments
                                  entry1.setComment("comment1");
                                  entry2.setComment("comment2");
                                  
                                  // Should return false because comments are different
                                  assertFalse(entry1.equals(entry2));
                                  
                                  // Also test with one null comment
                                  entry1.setComment(null);
                                  assertFalse(entry1.equals(entry2));
                                  
                                  // And both non-null but different
                                  entry1.setComment("commentA");
                                  entry2.setComment("commentB");
                                  assertFalse(entry1.equals(entry2));
                              }

    @Test
                         public void testEqualsWithDifferentCommentsShouldReturnFalse1() {
                             // Create first entry with a comment
                             ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                             entry1.setComment("comment1");
                             
                             // Create second entry with a different comment
                             ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
                             entry2.setComment("comment2");
                             
                             // Set all other fields to be equal
                             long time = System.currentTimeMillis();
                             entry1.setTime(time);
                             entry2.setTime(time);
                             entry1.setInternalAttributes(1);
                             entry2.setInternalAttributes(1);
                             
                             // Use reflection to set protected platform field
                             try {
                                 Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                 setPlatform.setAccessible(true);
                                 setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                                 setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                             } catch (Exception e) {
                                 fail("Failed to set platform via reflection");
                             }
                             
                             entry1.setExternalAttributes(123L);
                             entry2.setExternalAttributes(123L);
                             entry1.setMethod(8);
                             entry2.setMethod(8);
                             entry1.setSize(100L);
                             entry2.setSize(100L);
                             entry1.setCrc(12345L);
                             entry2.setCrc(12345L);
                             entry1.setCompressedSize(80L);
                             entry2.setCompressedSize(80L);
                             entry1.setCentralDirectoryExtra(new byte[0]);
                             entry2.setCentralDirectoryExtra(new byte[0]);
                             
                             // The entries should not be equal because comments are different
                             assertFalse(entry1.equals(entry2));
                             
                             // Also test with one comment null and one non-null
                             entry1.setComment(null);
                             entry2.setComment("non-null");
                             assertFalse(entry1.equals(entry2));
                             
                             entry1.setComment("non-null");
                             entry2.setComment(null);
                             assertFalse(entry1.equals(entry2));
                         }

    @Test
                    public void testEqualsWithDifferentCommentsShouldNotBeEqual() {
                        // Create first entry with a comment
                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                        entry1.setComment("comment1");
                        
                        // Create second entry with different comment
                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
                        entry2.setComment("comment2");
                        
                        // Set all other fields to be equal
                        long time = System.currentTimeMillis();
                        entry1.setTime(time);
                        entry2.setTime(time);
                        entry1.setMethod(8);
                        entry2.setMethod(8);
                        entry1.setSize(100);
                        entry2.setSize(100);
                        entry1.setInternalAttributes(0);
                        entry2.setInternalAttributes(0);
                        
                        // Use reflection to set platform since it's protected
                        try {
                            Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                            setPlatform.setAccessible(true);
                            setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                            setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                        } catch (Exception e) {
                            fail("Failed to set platform via reflection: " + e.getMessage());
                        }
                        
                        // Original should return false since comments are different
                        // Mutated version would return true since it compares against empty string
                        assertFalse("Entries with different comments should not be equal", 
                                   entry1.equals(entry2));
                        
                        // Also test with one null comment and one non-null
                        entry1.setComment(null);
                        entry2.setComment("comment");
                        assertFalse("Null comment vs non-null comment should not be equal",
                                   entry1.equals(entry2));
                    }

    @Test
               public void testEqualsWithCommentHandling() throws Exception {
                   // Create two entries with same properties but null comments
                   ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                   ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
                   
                   // Set all other fields to be equal
                   entry1.setTime(12345L);
                   entry2.setTime(12345L);
                   entry1.setInternalAttributes(1);
                   entry2.setInternalAttributes(1);
                   
                   // Use reflection to set protected platform field
                   Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                   setPlatformMethod.setAccessible(true);
                   setPlatformMethod.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                   setPlatformMethod.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                   
                   entry1.setExternalAttributes(100L);
                   entry2.setExternalAttributes(100L);
                   entry1.setMethod(8);
                   entry2.setMethod(8);
                   entry1.setSize(1024L);
                   entry2.setSize(1024L);
                   entry1.setGeneralPurposeBit(new GeneralPurposeBit());
                   entry2.setGeneralPurposeBit(new GeneralPurposeBit());
                   
                   // Test case 1: Both comments are null - should be equal
                   assertTrue("Entries with null comments should be equal", entry1.equals(entry2));
                   
                   // Test case 2: One null comment, one empty string - should be equal
                   entry2.setComment("");
                   assertTrue("Null comment should equal empty string", entry1.equals(entry2));
                   
                   // Test case 3: Both have same non-null comments
                   entry1.setComment("same");
                   entry2.setComment("same");
                   assertTrue("Entries with same comments should be equal", entry1.equals(entry2));
                   
                   // Test case 4: Different comments
                   entry2.setComment("different");
                   assertFalse("Entries with different comments should not be equal", entry1.equals(entry2));
               }

    @Test
          public void testEqualsWithNullComment() throws Exception {
              // Create first entry with null comment (will be converted to empty string)
              ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
              entry1.setComment(null);
              
              // Create second entry with null comment (not converted yet)
              ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
              // Need to set all other fields to be equal
              entry2.setTime(entry1.getTime());
              entry2.setInternalAttributes(entry1.getInternalAttributes());
              
              // Use reflection to set platform since it's protected
              Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
              setPlatformMethod.setAccessible(true);
              setPlatformMethod.invoke(entry2, entry1.getPlatform());
              
              entry2.setExternalAttributes(entry1.getExternalAttributes());
              entry2.setMethod(entry1.getMethod());
              entry2.setSize(entry1.getSize());
              entry2.setGeneralPurposeBit(entry1.getGeneralPurposeBit());
              
              // The original should return false (empty string vs null)
              // The mutant would throw NullPointerException
              assertFalse("Entries with empty vs null comments should not be equal", 
                         entry1.equals(entry2));
          }

    @Test
      public void testEqualsWithDifferentStringComments() {
          // Create two entries with same content but different String objects for comments
          ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
          ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
          
          // Set comments that are equal in content but different objects
          String comment1 = "comment";
          String comment2 = new String("comment"); // Force new String object with same content
          
          // Use reflection to set the comments since there's no setComment method
          try {
              Field commentField = ZipArchiveEntry.class.getDeclaredField("comment");
              commentField.setAccessible(true);
              commentField.set(entry1, comment1);
              commentField.set(entry2, comment2);
          } catch (Exception e) {
              fail("Failed to set comment fields via reflection");
          }
          
          // Set all other fields to be equal
          entry1.setTime(1000L);
          entry2.setTime(1000L);
          entry1.setSize(100L);
          entry2.setSize(100L);
          // ... set other fields as needed for equality
          
          // The entries should be considered equal
          assertTrue("Entries with equal but different String comments should be equal", 
                     entry1.equals(entry2));
          
          // Also test the reverse comparison
          assertTrue("Equals should be symmetric", 
                     entry2.equals(entry1));
      }

    @Test
    public void testEqualsDetectsTimeComparisonMutation() {
        // Create two entries that are identical except for time
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
        
        // Set all other fields to be equal
        entry1.setMethod(8);
        entry2.setMethod(8);
        entry1.setSize(100L);
        entry2.setSize(100L);
        entry1.setInternalAttributes(1);
        entry2.setInternalAttributes(1);
        // Using setUnixMode to indirectly set platform to PLATFORM_FAT
        entry1.setUnixMode(0);
        entry2.setUnixMode(0);
        entry1.setExternalAttributes(123L);
        entry2.setExternalAttributes(123L);
        entry1.setComment("comment");
        entry2.setComment("comment");
        entry1.setGeneralPurposeBit(new GeneralPurposeBit());
        entry2.setGeneralPurposeBit(new GeneralPurposeBit());
        
        // Set different times
        entry1.setTime(1000L);
        entry2.setTime(2000L);
        
        // Verify they are not equal due to time difference
        assertFalse(entry1.equals(entry2));
        
        // Now set times to be equal and verify equality
        entry2.setTime(1000L);
        assertTrue(entry1.equals(entry2));
    }


}
