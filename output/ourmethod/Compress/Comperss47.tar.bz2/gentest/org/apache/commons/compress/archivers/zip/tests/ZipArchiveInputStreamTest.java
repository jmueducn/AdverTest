package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.deflate64.Deflate64CompressorInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testCanReadEntryData_WithNonZipArchiveEntry_ReturnsFalse() {
                                                                                            // Arrange
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                            ArchiveEntry nonZipEntry = mock(ArchiveEntry.class);
                                                                                            
                                                                                            // Act
                                                                                            boolean result = zais.canReadEntryData(nonZipEntry);
                                                                                            
                                                                                            // Assert
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testCanReadEntryData_WithNullEntry_ReturnsFalse() {
                                                                                            // Arrange
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                            
                                                                                            // Act
                                                                                            boolean result = zais.canReadEntryData(null);
                                                                                            
                                                                                            // Assert
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testRead_WhenCurrentEntryIsNull_ReturnsMinusOne() throws Exception {
                                                                                            // Arrange
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                            byte[] buffer = new byte[10];
                                                                                            
                                                                                            // Act
                                                                                            int result = zais.read(buffer, 0, 10);
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals(-1, result);
                                                                                        }

    @Test
                                                                                        public void testReadByteArray_NormalCase() throws IOException {
                                                                                            // Setup
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                .thenReturn(5); // simulate reading 5 bytes
                                                                                            
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                            byte[] buffer = new byte[1024];
                                                                                    
                                                                                            // Execute
                                                                                            int bytesRead = zais.read(buffer);
                                                                                    
                                                                                            // Verify
                                                                                            assertEquals(5, bytesRead);
                                                                                            verify(mockInputStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                                                        }

    @Test
                                                                                        public void testReadByteArray_EmptyBuffer() throws IOException {
                                                                                            // Setup
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                .thenReturn(0); // simulate reading 0 bytes
                                                                                            
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                            byte[] buffer = new byte[0]; // empty buffer
                                                                                    
                                                                                            // Execute
                                                                                            int bytesRead = zais.read(buffer);
                                                                                    
                                                                                            // Verify
                                                                                            assertEquals(0, bytesRead);
                                                                                            verify(mockInputStream).read(eq(buffer), eq(0), eq(0));
                                                                                        }

    @Test
                                                                                        public void testReadByteArray_EndOfStream() throws IOException {
                                                                                            // Setup
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                .thenReturn(-1); // simulate end of stream
                                                                                            
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                            byte[] buffer = new byte[1024];
                                                                                    
                                                                                            // Execute
                                                                                            int bytesRead = zais.read(buffer);
                                                                                    
                                                                                            // Verify
                                                                                            assertEquals(-1, bytesRead);
                                                                                            verify(mockInputStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                                                        }

    @Test
                                                                                        public void testReadByteArray_PartialRead() throws IOException {
                                                                                            // Setup
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                .thenReturn(100) // first read returns 100 bytes
                                                                                                .thenReturn(50)   // second read returns 50 bytes
                                                                                                .thenReturn(-1); // then end of stream
                                                                                            
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                            byte[] buffer = new byte[1024];
                                                                                    
                                                                                            // First read
                                                                                            int bytesRead1 = zais.read(buffer);
                                                                                            assertEquals(100, bytesRead1);
                                                                                    
                                                                                            // Second read
                                                                                            int bytesRead2 = zais.read(buffer);
                                                                                            assertEquals(50, bytesRead2);
                                                                                    
                                                                                            // Third read (end of stream)
                                                                                            int bytesRead3 = zais.read(buffer);
                                                                                            assertEquals(-1, bytesRead3);
                                                                                    
                                                                                            verify(mockInputStream, times(3)).read(eq(buffer), eq(0), eq(buffer.length));
                                                                                        }

    @Test
                                                                                public void testCanReadEntryData_WithZipArchiveEntry_AllConditionsTrue_ReturnsTrue() throws Exception {
                                                                                    // Arrange
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                                    
                                                                                    // Use reflection to access private methods
                                                                                    Method supportsDataDescriptorFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                                                                    supportsDataDescriptorFor.setAccessible(true);
                                                                                    Method supportsCompressedSizeFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    supportsCompressedSizeFor.setAccessible(true);
                                                                                    
                                                                                    // Mock the private method calls
                                                                                    when(supportsDataDescriptorFor.invoke(zais, zipEntry)).thenReturn(true);
                                                                                    when(supportsCompressedSizeFor.invoke(zais, zipEntry)).thenReturn(true);
                                                                                    
                                                                                    // Act
                                                                                    boolean result = zais.canReadEntryData(zipEntry);
                                                                                    
                                                                                    // Assert
                                                                                    assertTrue(result);
                                                                                }

    @Test
                                                                                public void testCanReadEntryData_WithZipArchiveEntry_CannotHandleEntryData_ReturnsFalse() throws Exception {
                                                                                    // Arrange
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                                    
                                                                                    // Use reflection to set up private method mocks
                                                                                    Method supportsDataDescriptor = ZipArchiveInputStream.class
                                                                                        .getDeclaredMethod("supportsDataDescriptorFor", ZipArchiveEntry.class);
                                                                                    supportsDataDescriptor.setAccessible(true);
                                                                                    when(supportsDataDescriptor.invoke(zais, zipEntry)).thenReturn(true);
                                                                                    
                                                                                    Method supportsCompressedSize = ZipArchiveInputStream.class
                                                                                        .getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    supportsCompressedSize.setAccessible(true);
                                                                                    when(supportsCompressedSize.invoke(zais, zipEntry)).thenReturn(true);
                                                                                    
                                                                                    // Act
                                                                                    boolean result = zais.canReadEntryData(zipEntry);
                                                                                    
                                                                                    // Assert
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testCanReadEntryData_WithZipArchiveEntry_NoDataDescriptorSupport_ReturnsFalse() throws Exception {
                                                                                    // Arrange
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                                    
                                                                                    // Use reflection to access private methods
                                                                                    Method supportsDataDescriptorFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                                                                    supportsDataDescriptorFor.setAccessible(true);
                                                                                    
                                                                                    Method supportsCompressedSizeFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    supportsCompressedSizeFor.setAccessible(true);
                                                                                    
                                                                                    // Mock the behavior of private methods
                                                                                    when(supportsDataDescriptorFor.invoke(zais, zipEntry)).thenReturn(false);
                                                                                    when(supportsCompressedSizeFor.invoke(zais, zipEntry)).thenReturn(true);
                                                                                    
                                                                                    // Act
                                                                                    boolean result = zais.canReadEntryData(zipEntry);
                                                                                    
                                                                                    // Assert
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testCanReadEntryData_WithZipArchiveEntry_NoCompressedSizeSupport_ReturnsFalse() throws Exception {
                                                                                    // Arrange
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                                    
                                                                                    // Use reflection to access private methods
                                                                                    Method supportsDataDescriptorFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                                                                    supportsDataDescriptorFor.setAccessible(true);
                                                                                    
                                                                                    Method supportsCompressedSizeFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    supportsCompressedSizeFor.setAccessible(true);
                                                                                    
                                                                                    // Mock the behavior of private methods
                                                                                    when(supportsDataDescriptorFor.invoke(zais, zipEntry)).thenReturn(true);
                                                                                    when(supportsCompressedSizeFor.invoke(zais, zipEntry)).thenReturn(false);
                                                                                    
                                                                                    // Act
                                                                                    boolean result = zais.canReadEntryData(zipEntry);
                                                                                    
                                                                                    // Assert
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testRead_WhenStreamClosed_ThrowsIOException() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    zais.close();
                                                                                    byte[] buffer = new byte[10];
                                                                                    
                                                                                    // Expected exception setup
                                                                                    ExpectedException expectedException = ExpectedException.none();
                                                                                    expectedException.expect(IOException.class);
                                                                                    expectedException.expectMessage("The stream is closed");
                                                                                    
                                                                                    // Act
                                                                                    zais.read(buffer, 0, 10);
                                                                                }

    @Test
                                                                                public void testRead_WithSupportedMethod_CallsInputStreamRead() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Create mock entry using reflection since CurrentEntry is likely an inner class
                                                                                    Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                                                                    Object mockEntry = mock(currentEntryClass);
                                                                                    
                                                                                    ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                                    
                                                                                    // Get method references for setting up mocks
                                                                                    Method entryGetter = currentEntryClass.getDeclaredMethod("getEntry");
                                                                                    Method inGetter = currentEntryClass.getDeclaredMethod("getIn");
                                                                                    
                                                                                    when(entryGetter.invoke(mockEntry)).thenReturn(mockZipEntry);
                                                                                    when(inGetter.invoke(mockEntry)).thenReturn(mockInputStream);
                                                                                    when(mockZipEntry.getMethod()).thenReturn(ZipArchiveEntry.DEFLATED); // Using standard ZIP method
                                                                                    
                                                                                    // Set current entry via reflection
                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                    currentField.setAccessible(true);
                                                                                    currentField.set(zais, mockEntry);
                                                                                    
                                                                                    byte[] buffer = new byte[10];
                                                                                    when(mockInputStream.read(buffer, 0, 10)).thenReturn(5);
                                                                                    
                                                                                    // Act
                                                                                    int result = zais.read(buffer, 0, 10);
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(5, result);
                                                                                    verify(mockInputStream).read(buffer, 0, 10);
                                                                                }

    @Test
                                                                                public void testRead_WithPositiveRead_UpdatesCRC() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Create mock objects
                                                                                    ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                                    CRC32 mockCrc = mock(CRC32.class);
                                                                                    
                                                                                    // Create and setup current entry via reflection
                                                                                    Object mockEntry = new Object() {
                                                                                        public ZipArchiveEntry entry = mockZipEntry;
                                                                                        public InputStream in = mockInputStream;
                                                                                        public CRC32 crc = mockCrc;
                                                                                    };
                                                                                    
                                                                                    when(mockZipEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                    
                                                                                    // Set current entry via reflection
                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                    currentField.setAccessible(true);
                                                                                    currentField.set(zais, mockEntry);
                                                                                    
                                                                                    byte[] buffer = new byte[10];
                                                                                    when(mockInputStream.read(buffer, 0, 10)).thenReturn(5);
                                                                                    
                                                                                    // Act
                                                                                    int result = zais.read(buffer, 0, 10);
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(5, result);
                                                                                    verify(mockCrc).update(buffer, 0, 5);
                                                                                }

    @Test
                                                                                public void testSupportsCompressedSizeFor_KnownCompressedSize() throws Exception {
                                                                                    // Setup
                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                    when(entry.getCompressedSize()).thenReturn(100L); // Known size
                                                                                    when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                                                                    
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    
                                                                                    // Get private method via reflection
                                                                                    Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    // Test & Verify
                                                                                    assertTrue((Boolean) method.invoke(zais, entry));
                                                                                }

    @Test
                                                                                public void testSupportsCompressedSizeFor_DeflatedMethod() throws Exception {
                                                                                    // Setup
                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                    when(entry.getCompressedSize()).thenReturn(ArchiveEntry.SIZE_UNKNOWN);
                                                                                    when(entry.getMethod()).thenReturn(ZipEntry.DEFLATED);
                                                                                    
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    
                                                                                    // Get private method via reflection
                                                                                    Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    // Test & Verify
                                                                                    assertTrue((Boolean) method.invoke(zais, entry));
                                                                                }

    @Test
                                                                                public void testSupportsCompressedSizeFor_EnhancedDeflatedMethod() throws Exception {
                                                                                    // Setup
                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                    when(entry.getCompressedSize()).thenReturn(ArchiveEntry.SIZE_UNKNOWN);
                                                                                    when(entry.getMethod()).thenReturn(ZipMethod.ENHANCED_DEFLATED.getCode());
                                                                                    
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    
                                                                                    // Get private method via reflection
                                                                                    Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    // Test & Verify
                                                                                    assertTrue((Boolean) method.invoke(zais, entry));
                                                                                }

    @Test
                                                                                public void testSupportsCompressedSizeFor_StoredWithDataDescriptorAllowed() throws Exception {
                                                                                    // Setup
                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                    GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                                                                    
                                                                                    when(entry.getCompressedSize()).thenReturn(ArchiveEntry.SIZE_UNKNOWN);
                                                                                    when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                                                                    when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                                                                    when(gpb.usesDataDescriptor()).thenReturn(true);
                                                                                    
                                                                                    // Create stream with allowStoredEntriesWithDataDescriptor = true
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(
                                                                                        mock(InputStream.class), "UTF-8", true, true);
                                                                                    
                                                                                    // Get private method via reflection
                                                                                    Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    // Test & Verify
                                                                                    assertTrue((Boolean)method.invoke(zais, entry));
                                                                                }

    @Test
                                                                                public void testSupportsCompressedSizeFor_StoredWithDataDescriptorNotAllowed() throws Exception {
                                                                                    // Setup
                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                    GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                                                                    
                                                                                    when(entry.getCompressedSize()).thenReturn(ArchiveEntry.SIZE_UNKNOWN);
                                                                                    when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                                                                    when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                                                                    when(gpb.usesDataDescriptor()).thenReturn(true);
                                                                                    
                                                                                    // Create stream with allowStoredEntriesWithDataDescriptor = false (default)
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    
                                                                                    // Get private method via reflection
                                                                                    Method supportsCompressedSizeFor = ZipArchiveInputStream.class
                                                                                            .getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    supportsCompressedSizeFor.setAccessible(true);
                                                                                    
                                                                                    // Test & Verify
                                                                                    boolean result = (boolean) supportsCompressedSizeFor.invoke(zais, entry);
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testSupportsCompressedSizeFor_StoredWithoutDataDescriptor() throws Exception {
                                                                                    // Setup
                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                    GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                                                                    
                                                                                    when(entry.getCompressedSize()).thenReturn(ArchiveEntry.SIZE_UNKNOWN);
                                                                                    when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                                                                    when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                                                                    when(gpb.usesDataDescriptor()).thenReturn(false);
                                                                                    
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                    
                                                                                    // Get private method via reflection
                                                                                    Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    // Test & Verify
                                                                                    assertFalse((Boolean)method.invoke(zais, entry));
                                                                                }

    @Test
                                                                                public void testRead_WhenMaxReached_ReturnsNegativeOne() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.setInt(zais, 10);
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.setInt(zais, 10); // pos equals max
                                                                                
                                                                                    // Act
                                                                                    int result = zais.read();
                                                                                
                                                                                    // Assert
                                                                                    assertEquals(-1, result);
                                                                                    verify(mockInputStream, never()).read();
                                                                                }

    @Test
                                                                                public void testRead_WhenPosExceedsMax_ReturnsNegativeOne() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.set(zais, 10);
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.set(zais, 11); // pos exceeds max
                                                                                
                                                                                    // Act
                                                                                    int result = zais.read();
                                                                                
                                                                                    // Assert
                                                                                    assertEquals(-1, result);
                                                                                    verify(mockInputStream, never()).read();
                                                                                }

    @Test
                                                                                public void testRead_NormalRead_IncrementsPositionAndCount() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    when(mockInputStream.read()).thenReturn(65); // 'A'
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.set(zais, -1L); // no max limit
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.set(zais, 0L);
                                                                                
                                                                                    // Act
                                                                                    int result = zais.read();
                                                                                
                                                                                    // Assert
                                                                                    assertEquals(65, result);
                                                                                    assertEquals(1L, posField.get(zais));
                                                                                    verify(mockInputStream).read();
                                                                                }

    @Test
                                                                                public void testRead_WhenInputStreamReturnsNegativeOne_ReturnsNegativeOne() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    when(mockInputStream.read()).thenReturn(-1); // EOF
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Use reflection to access private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.set(zais, -1L); // no max limit
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.set(zais, 0L);
                                                                                
                                                                                    // Act
                                                                                    int result = zais.read();
                                                                                
                                                                                    // Assert
                                                                                    assertEquals(-1, result);
                                                                                    assertEquals(1L, posField.get(zais)); // pos still increments
                                                                                    verify(mockInputStream).read();
                                                                                }

    @Test
                                                                                public void testRead_MultipleReads_TracksPositionCorrectly() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    when(mockInputStream.read())
                                                                                        .thenReturn(65)  // First read
                                                                                        .thenReturn(66)  // Second read
                                                                                        .thenReturn(67); // Third read
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.set(zais, -1L); // no max limit
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.set(zais, 0L);
                                                                                
                                                                                    // Act & Assert
                                                                                    assertEquals(65, zais.read());
                                                                                    assertEquals(1L, posField.getLong(zais));
                                                                                    
                                                                                    assertEquals(66, zais.read());
                                                                                    assertEquals(2L, posField.getLong(zais));
                                                                                    
                                                                                    assertEquals(67, zais.read());
                                                                                    assertEquals(3L, posField.getLong(zais));
                                                                                    
                                                                                    verify(mockInputStream, times(3)).read();
                                                                                }

    @Test
                                                                                public void testReadByteArray_NullBuffer() throws IOException {
                                                                                    // Setup
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    
                                                                                    // Declare expected exception rule
                                                                                    ExpectedException expectedException = ExpectedException.none();
                                                                                    expectedException.expect(NullPointerException.class);
                                                                                    expectedException.expectMessage("buffer");
                                                                                    
                                                                                    // Execute
                                                                                    zais.read(null);
                                                                                }

    @Test
                                                                                public void testReadByteArray_IOException() throws IOException {
                                                                                    // Setup
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                        .thenThrow(new IOException("Test IO Exception"));
                                                                                    
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                    byte[] buffer = new byte[1024];
                                                                                
                                                                                    try {
                                                                                        zais.read(buffer);
                                                                                        fail("Expected IOException to be thrown");
                                                                                    } catch (IOException e) {
                                                                                        assertEquals("Test IO Exception", e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testRead_PositionAtOrBeyondMax_ReturnsNegativeOne() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                    
                                                                                    // Use reflection to access private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    
                                                                                    // Set max and pos values
                                                                                    maxField.setLong(zais, 100);
                                                                                    posField.setLong(zais, 100);  // equal to max
                                                                                    
                                                                                    byte[] buffer = new byte[10];
                                                                                
                                                                                    // Act & Assert
                                                                                    assertEquals(-1, zais.read(buffer, 0, 10));
                                                                                
                                                                                    // Test with pos > max
                                                                                    posField.setLong(zais, 101);
                                                                                    assertEquals(-1, zais.read(buffer, 0, 10));
                                                                                }

    @Test
                                                                                public void testRead_NormalOperationWithinBounds() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                    when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.set(zais, 100L);
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.set(zais, 50L);
                                                                                    
                                                                                    byte[] buffer = new byte[20];
                                                                                
                                                                                    // Act
                                                                                    int bytesRead = zais.read(buffer, 0, 20);
                                                                                
                                                                                    // Assert
                                                                                    assertEquals(5, bytesRead);
                                                                                    assertEquals(55L, posField.getLong(zais));
                                                                                    verify(mockIn).read(eq(buffer), eq(0), eq(20));
                                                                                }

    @Test
                                                                                public void testRead_LengthExceedsMaxRemaining_AdjustsReadLength() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                    // Arrange
                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                    when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(3);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                    
                                                                                    // Use reflection to access private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.setLong(zais, 100);
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.setLong(zais, 98);  // only 2 bytes remaining before max
                                                                                    
                                                                                    byte[] buffer = new byte[10];
                                                                                
                                                                                    // Act
                                                                                    int bytesRead = zais.read(buffer, 0, 10);
                                                                                
                                                                                    // Assert
                                                                                    assertEquals(3, bytesRead);
                                                                                    assertEquals(101, posField.getLong(zais));
                                                                                    verify(mockIn).read(eq(buffer), eq(0), eq(2));  // should only try to read remaining bytes
                                                                                }

    @Test
                                                                                public void testRead_UnderlyingStreamReturnsNegativeOne_ReturnsNegativeOne() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                    when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.set(zais, 100);
                                                                                    
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.set(zais, 50);
                                                                                    
                                                                                    byte[] buffer = new byte[10];
                                                                                
                                                                                    // Act & Assert
                                                                                    assertEquals(-1, zais.read(buffer, 0, 10));
                                                                                    assertEquals(50, posField.getInt(zais));  // position shouldn't change
                                                                                }

    @Test
                                                                                public void testRead_NoMaxLimit_ReadsFullLength() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                    when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                    
                                                                                    // Set private max field using reflection
                                                                                    Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                    maxField.setAccessible(true);
                                                                                    maxField.set(zais, -1L);  // no max limit
                                                                                    
                                                                                    // Set private pos field using reflection
                                                                                    Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                    posField.setAccessible(true);
                                                                                    posField.set(zais, 0L);
                                                                                    
                                                                                    byte[] buffer = new byte[20];
                                                                                
                                                                                    // Act
                                                                                    int bytesRead = zais.read(buffer, 0, 20);
                                                                                
                                                                                    // Assert
                                                                                    assertEquals(10, bytesRead);
                                                                                    assertEquals(10L, posField.get(zais));
                                                                                    verify(mockIn).read(eq(buffer), eq(0), eq(20));
                                                                                }

    @Test
                                                                                public void testRead_NullBuffer_ThrowsNullPointerException() throws IOException {
                                                                                    // Arrange
                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                    
                                                                                    // Define exception expectation rule
                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                    exception.expect(NullPointerException.class);
                                                                                
                                                                                    // Act
                                                                                    zais.read(null, 0, 10);
                                                                                }

    @Test
                                                                            public void testRead_InvalidOffsetOrLength_ThrowsIndexOutOfBoundsException() throws IOException {
                                                                                // Arrange
                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                byte[] buffer = new byte[10];
                                                                                ExpectedException exception = ExpectedException.none();
                                                                            
                                                                                // Test negative offset
                                                                                exception.expect(IndexOutOfBoundsException.class);
                                                                                zais.read(buffer, -1, 5);
                                                                            
                                                                                // Test negative length
                                                                                exception.expect(IndexOutOfBoundsException.class);
                                                                                zais.read(buffer, 0, -1);
                                                                            
                                                                                // Test offset + length > buffer size
                                                                                exception.expect(IndexOutOfBoundsException.class);
                                                                                zais.read(buffer, 8, 5);
                                                                            }

    @Test
                                                                            public void testRead_WithStoredMethod_CallsReadStored() throws Exception {
                                                                                // Arrange
                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                
                                                                                // Create mock entry using reflection since CurrentEntry is likely an inner class
                                                                                Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                                                                Object mockEntry = mock(currentEntryClass);
                                                                                ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                                
                                                                                // Set up mocks
                                                                                Field entryField = currentEntryClass.getDeclaredField("entry");
                                                                                entryField.setAccessible(true);
                                                                                entryField.set(mockEntry, mockZipEntry);
                                                                                when(mockZipEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                
                                                                                // Set current entry via reflection
                                                                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                currentField.setAccessible(true);
                                                                                currentField.set(zais, mockEntry);
                                                                                
                                                                                byte[] buffer = new byte[10];
                                                                                
                                                                                // Create spy and mock the behavior using reflection
                                                                                ZipArchiveInputStream spyZais = spy(zais);
                                                                                Method readStoredMethod = ZipArchiveInputStream.class.getDeclaredMethod("readStored", byte[].class, int.class, int.class);
                                                                                readStoredMethod.setAccessible(true);
                                                                                
                                                                                // Mock the behavior by intercepting the call to readStored
                                                                                doAnswer(invocation -> {
                                                                                    Object[] args = invocation.getArguments();
                                                                                    return readStoredMethod.invoke(spyZais, args[0], args[1], args[2]);
                                                                                }).when(spyZais).read(any(byte[].class), anyInt(), anyInt());
                                                                                
                                                                                // Set up the expected return value
                                                                                when(readStoredMethod.invoke(spyZais, buffer, 0, 10)).thenReturn(5);
                                                                                
                                                                                // Act
                                                                                int result = spyZais.read(buffer, 0, 10);
                                                                                
                                                                                // Assert
                                                                                assertEquals(5, result);
                                                                                verify(spyZais).read(buffer, 0, 10);
                                                                            }

    @Test
                                                                            public void testSupportsCompressedSizeFor_NullEntry() throws Exception {
                                                                                // Setup
                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                
                                                                                // Get the private method using reflection
                                                                                Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                    "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                // Test
                                                                                try {
                                                                                    method.invoke(zais, (ZipArchiveEntry) null);
                                                                                    fail("Expected NullPointerException");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertTrue(e.getCause() instanceof NullPointerException);
                                                                                }
                                                                            }

    @Test
                                                                            public void testRead_IOExceptionFromUnderlyingStream_PropagatesException() throws Exception {
                                                                                // Arrange
                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenThrow(new IOException("Test exception"));
                                                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                
                                                                                // Use reflection to set private fields
                                                                                Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                maxField.setAccessible(true);
                                                                                maxField.set(zais, 100);
                                                                                
                                                                                Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                posField.setAccessible(true);
                                                                                posField.set(zais, 0);
                                                                                
                                                                                byte[] buffer = new byte[10];
                                                                            
                                                                                try {
                                                                                    // Act
                                                                                    zais.read(buffer, 0, 10);
                                                                                    fail("Expected IOException to be thrown");
                                                                                } catch (IOException e) {
                                                                                    // Assert
                                                                                    assertEquals("Test exception", e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                        public void testRead_WithInvalidBufferParameters_ThrowsArrayIndexOutOfBounds() throws Exception {
                                                                            // Arrange
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                            
                                                                            // Create mock objects for CurrentEntry and ZipArchiveEntry
                                                                            Object mockEntry = mock(Object.class);
                                                                            ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                            
                                                                            // Use reflection to set up the mock entry structure
                                                                            Field entryField = mockEntry.getClass().getDeclaredField("entry");
                                                                            entryField.setAccessible(true);
                                                                            entryField.set(mockEntry, mockZipEntry);
                                                                            
                                                                            when(mockZipEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                            
                                                                            // Set current entry via reflection since it's private
                                                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                            currentField.setAccessible(true);
                                                                            currentField.set(zais, mockEntry);
                                                                            
                                                                            byte[] buffer = new byte[10];
                                                                            
                                                                            // Set up exception expectation
                                                                            try {
                                                                                // Act
                                                                                zais.read(buffer, 11, 5); // offset > buffer length
                                                                                fail("Expected ArrayIndexOutOfBoundsException");
                                                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                                                // Expected exception
                                                                            }
                                                                        }

    @Test
                                                                        public void testRead_WithDeflatedMethod_CallsReadDeflated() throws Exception {
                                                                            // Arrange
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                            
                                                                            // Create mock entry using reflection since CurrentEntry is likely an inner class
                                                                            Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                                                            Object mockEntry = mock(currentEntryClass);
                                                                            ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                            
                                                                            // Set up mocks
                                                                            Field entryField = currentEntryClass.getDeclaredField("entry");
                                                                            entryField.setAccessible(true);
                                                                            entryField.set(mockEntry, mockZipEntry);
                                                                            when(mockZipEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                            
                                                                            // Set current entry via reflection
                                                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                            currentField.setAccessible(true);
                                                                            currentField.set(zais, mockEntry);
                                                                            
                                                                            byte[] buffer = new byte[10];
                                                                            
                                                                            // Spy on the zais to verify behavior
                                                                            ZipArchiveInputStream spyZais = spy(zais);
                                                                            
                                                                            // Get the private readDeflated method
                                                                            Method readDeflatedMethod = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                "readDeflated", byte[].class, int.class, int.class);
                                                                            readDeflatedMethod.setAccessible(true);
                                                                            
                                                                            // Mock the behavior of readDeflated using reflection
                                                                            doAnswer(invocation -> {
                                                                                Object[] args = invocation.getArguments();
                                                                                return readDeflatedMethod.invoke(spyZais, args[0], args[1], args[2]);
                                                                            }).when(spyZais).read(any(byte[].class), anyInt(), anyInt());
                                                                            
                                                                            // Set up the expected return value
                                                                            when(readDeflatedMethod.invoke(spyZais, buffer, 0, 10)).thenReturn(5);
                                                                            
                                                                            // Act
                                                                            int result = spyZais.read(buffer, 0, 10);
                                                                            
                                                                            // Assert
                                                                            assertEquals(5, result);
                                                                            verify(spyZais, times(1)).read(buffer, 0, 10);
                                                                        }

    @Test
                                                                        public void testRead_WithDataDescriptorNotSupported_ThrowsUnsupportedZipFeatureException() throws Exception {
                                                                            // Arrange
                                                                            ExpectedException expectedException = ExpectedException.none();
                                                                            
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                            
                                                                            // Create mock entry and zip entry
                                                                            Object mockEntry = mock(Object.class); // CurrentEntry is likely an inner class
                                                                            ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                            
                                                                            // Use reflection to set up the mock entry
                                                                            Field entryField = mockEntry.getClass().getDeclaredField("entry");
                                                                            entryField.setAccessible(true);
                                                                            entryField.set(mockEntry, mockZipEntry);
                                                                            
                                                                            when(mockZipEntry.getMethod()).thenReturn(ZipMethod.STORED.getCode());
                                                                            
                                                                            // Set current entry via reflection
                                                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                            currentField.setAccessible(true);
                                                                            currentField.set(zais, mockEntry);
                                                                            
                                                                            // Mock supportsDataDescriptorFor via reflection since it's private
                                                                            Method supportsMethod = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                                                            supportsMethod.setAccessible(true);
                                                                            
                                                                            // Create spy after setting up the current entry
                                                                            ZipArchiveInputStream spyZais = spy(zais);
                                                                            when(supportsMethod.invoke(spyZais, mockZipEntry)).thenReturn(false);
                                                                            
                                                                            byte[] buffer = new byte[10];
                                                                            
                                                                            // Setup expected exception
                                                                            expectedException.expect(UnsupportedZipFeatureException.class);
                                                                            expectedException.expectMessage(UnsupportedZipFeatureException.Feature.DATA_DESCRIPTOR.toString());
                                                                            
                                                                            // Act
                                                                            spyZais.read(buffer, 0, 10);
                                                                        }

    @Test
                                                                        public void testRead_WhenIOExceptionOccurs_ThrowsIOException() throws Exception {
                                                                            // Arrange
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            when(mockInputStream.read()).thenThrow(new IOException("Test exception"));
                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                            
                                                                            // Set private fields using reflection
                                                                            Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                            maxField.setAccessible(true);
                                                                            maxField.set(zais, -1); // no max limit
                                                                            
                                                                            Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                            posField.setAccessible(true);
                                                                            posField.set(zais, 0);
                                                                        
                                                                            // Set up exception expectation
                                                                            try {
                                                                                zais.read();
                                                                                fail("Expected IOException to be thrown");
                                                                            } catch (IOException e) {
                                                                                assertEquals("Test exception", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                    public void testRead_WithUnsupportedMethod_ThrowsUnsupportedZipFeatureException() throws Exception {
                                                                        // Arrange
                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                        
                                                                        // Create mock entry
                                                                        ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                        
                                                                        // Set up mocks
                                                                        when(mockZipEntry.getMethod()).thenReturn(999); // Unsupported method code
                                                                        
                                                                        // Set current entry via reflection
                                                                        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                        currentField.setAccessible(true);
                                                                        currentField.set(zais, mockZipEntry);
                                                                        
                                                                        byte[] buffer = new byte[10];
                                                                        
                                                                        // Act & Assert
                                                                        try {
                                                                            zais.read(buffer, 0, 10);
                                                                            fail("Expected UnsupportedZipFeatureException");
                                                                        } catch (UnsupportedZipFeatureException e) {
                                                                            // Expected exception
                                                                        }
                                                                    }

    @Test
                                                                public void testRead_WithCompressedSizeNotSupported_ThrowsUnsupportedZipFeatureException() throws Exception {
                                                                    // Arrange
                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                    
                                                                    // Create mock entry using reflection since CurrentEntry is likely an inner class
                                                                    Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                                                    Object mockEntry = mock(currentEntryClass);
                                                                    ZipArchiveEntry mockZipEntry = mock(ZipArchiveEntry.class);
                                                                    
                                                                    // Set up mock behavior
                                                                    Field entryField = currentEntryClass.getDeclaredField("entry");
                                                                    entryField.setAccessible(true);
                                                                    entryField.set(mockEntry, mockZipEntry);
                                                                    when(mockZipEntry.getMethod()).thenReturn(ZipMethod.STORED.getCode());
                                                                    
                                                                    // Set current entry via reflection
                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                    currentField.setAccessible(true);
                                                                    currentField.set(zais, mockEntry);
                                                                    
                                                                    // Mock private methods using reflection
                                                                    Method supportsDataDescriptorFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                        "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                                                    supportsDataDescriptorFor.setAccessible(true);
                                                                    Method supportsCompressedSizeFor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                    supportsCompressedSizeFor.setAccessible(true);
                                                                    
                                                                    // Create spy and mock private method behavior
                                                                    ZipArchiveInputStream spyZais = spy(zais);
                                                                    when(supportsDataDescriptorFor.invoke(spyZais, mockZipEntry)).thenReturn(true);
                                                                    when(supportsCompressedSizeFor.invoke(spyZais, mockZipEntry)).thenReturn(false);
                                                                    
                                                                    byte[] buffer = new byte[10];
                                                                    
                                                                    // Act & Assert
                                                                    try {
                                                                        spyZais.read(buffer, 0, 10);
                                                                        fail("Expected UnsupportedZipFeatureException");
                                                                    } catch (UnsupportedZipFeatureException e) {
                                                                        assertEquals(UnsupportedZipFeatureException.Feature.UNKNOWN_COMPRESSED_SIZE, e.getFeature());
                                                                    }
                                                                }

    @Test
                                        public void testCanReadEntryData_WithClosedStream_ThrowsIllegalStateException() {
                                            // Arrange
                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                            try {
                                                zais.close();
                                            } catch (IOException e) {
                                                fail("Unexpected IOException during close");
                                            }
                                            ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                            
                                            try {
                                                // Act
                                                zais.canReadEntryData(zipEntry);
                                                fail("Expected IllegalStateException to be thrown");
                                            } catch (IllegalStateException e) {
                                                // Assert
                                                assertEquals("Stream closed", e.getMessage());
                                            }
                                        }


}
