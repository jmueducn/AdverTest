package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                        public void testParseOctal_ValidOctalNumber() {
                                                            byte[] buffer = {' ', '1', '2', '3', '4', ' ', ' '};
                                                            long result = TarUtils.parseOctal(buffer, 0, 7);
                                                            assertEquals(668, result); // 1234 in octal is 668 in decimal
                                                        }

 @Test
                                                        public void testParseOctal_LeadingZeroReturnsZero() {
                                                            byte[] buffer = {'0', '1', '2', '3'};
                                                            long result = TarUtils.parseOctal(buffer, 0, 4);
                                                            assertEquals(0L, result);
                                                        }

 @Test
                                                        public void testParseOctal_LeadingAndTrailingSpaces() {
                                                            byte[] buffer = {' ', ' ', '7', '5', ' ', ' '};
                                                            long result = TarUtils.parseOctal(buffer, 0, 6);
                                                            assertEquals(61, result); // 75 in octal is 61 in decimal
                                                        }

 @Test
                                                        public void testParseOctal_TrailingNullsAndSpaces() {
                                                            byte[] buffer = {'1', '2', '0', '\0', '\0', ' '};
                                                            long result = TarUtils.parseOctal(buffer, 0, 6);
                                                            assertEquals(10, result); // 12 in octal is 10 in decimal
                                                        }

 @Test
                                                        public void testParseOctal_MinimumLength() {
                                                            byte[] buffer = {'1', '2'};
                                                            long result = TarUtils.parseOctal(buffer, 0, 2);
                                                            assertEquals(10, result); // 12 in octal is 10 in decimal
                                                        }

 @Test
                                                        public void testParseOctal_AllSpacesThrowsException() {
                                                            byte[] buffer = {' ', ' ', ' ', ' '};
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("buffer");
                                                            TarUtils.parseOctal(buffer, 0, 4);
                                                        }

 @Test
                                                        public void testParseOctal_InvalidOctalDigitThrowsException() {
                                                            byte[] buffer = {'1', '2', '8', '4'};
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("buffer");
                                                            TarUtils.parseOctal(buffer, 0, 4);
                                                        }

 @Test
                                                        public void testParseOctal_LengthLessThan2ThrowsException() {
                                                            byte[] buffer = {'1'};
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("Length 1 must be at least 2");
                                                            TarUtils.parseOctal(buffer, 0, 1);
                                                        }

 @Test
                                                        public void testParseOctal_EmptyAfterTrimmingThrowsException() {
                                                            byte[] buffer = {' ', '\0', ' '};
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("buffer");
                                                            TarUtils.parseOctal(buffer, 0, 3);
                                                        }

 @Test
                                                        public void testParseOctal_MaxValidOctalNumber() {
                                                            byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7'};
                                                            long result = TarUtils.parseOctal(buffer, 0, 11);
                                                            assertEquals(8589934591L, result); // 77777777777 in octal is 8589934591 in decimal
                                                        }

 @Test
                                                        public void testParseOctal_WithOffset() {
                                                            byte[] buffer = {'X', 'X', '1', '2', '3', 'X', 'X'};
                                                            long result = TarUtils.parseOctal(buffer, 2, 3);
                                                            assertEquals(83, result); // 123 in octal is 83 in decimal
                                                        }

 @Test
                                                        public void testParseOctal_SingleDigitAfterTrimming() {
                                                            byte[] buffer = {' ', '7', ' ', '\0'};
                                                            long result = TarUtils.parseOctal(buffer, 0, 4);
                                                            assertEquals(7, result);
                                                        }

 @Test
        public void testParseOctalWithTrailingSpacesShouldTrimThem() {
            // Setup test data with trailing spaces that should be trimmed
            byte[] buffer = {
                ' ', ' ', '1', '2', '3', ' ', ' '  // "  123  " - should parse as 123
            };
            int offset = 0;
            int length = buffer.length;
            
            // Expected behavior: trailing spaces should be trimmed and parse as octal 123
            long expected = 0123L; // octal 123 = decimal 83
            
            // Test the original behavior
            long actual = TarUtils.parseOctal(buffer, offset, length);
            
            // Verify the result
            assertEquals("Should properly parse octal number with trailing spaces", 
                         expected, actual);
            
            // This test will fail with the mutant because:
            // - Mutant checks buffer[offset] (first space) instead of last character
            // - Won't trim the trailing spaces properly
            // - May throw exception or return wrong value
        }

 @Test
           public void testParseOctalTrailingSpaceEdgeCase() {
               // This test will catch the mutant by having exactly one trailing space
               // where start would equal end during trimming
               byte[] buffer = new byte[] {'1', '2', '3', ' '};
               
               // With original code: start=0, end=4 -> trims to end=3 (start < end)
               // With mutant: start=0, end=4 -> would try to access buffer[4] (ArrayIndexOutOfBounds)
               try {
                   long result = TarUtils.parseOctal(buffer, 0, 4);
                   assertEquals(83L, result); // 123 in octal is 83 in decimal
               } catch (ArrayIndexOutOfBoundsException e) {
                   fail("Mutant detected: ArrayIndexOutOfBoundsException thrown");
               }
           }

 @Test
           public void testParseOctalMultipleTrailingSpaces() {
               // Test with multiple trailing spaces to ensure proper trimming
               byte[] buffer = new byte[] {'1', ' ', '2', ' ', ' '};
               
               long result = TarUtils.parseOctal(buffer, 0, 5);
               assertEquals(1L, result); // Only '1' should be parsed after trimming
           }

 @Test
           public void testParseOctalNoTrailingSpaces() {
               // Test with no trailing spaces to ensure no trimming occurs
               byte[] buffer = new byte[] {'1', '2', '3'};
               
               long result = TarUtils.parseOctal(buffer, 0, 3);
               assertEquals(83L, result); // 123 in octal is 83 in decimal
           }

 @Test(expected = IllegalArgumentException.class)
           public void testParseOctalAllSpaces() {
               // Test with all spaces to ensure proper exception
               byte[] buffer = new byte[] {' ', ' ', ' '};
               
               TarUtils.parseOctal(buffer, 0, 3);
           }

 @Test(expected = IllegalArgumentException.class)
      public void testParseOctal_StartGreaterThanEnd_ShouldThrowException() {
          // Arrange
          byte[] buffer = new byte[] {' ', ' ', 0, 0}; // All spaces and nulls
          int offset = 0;
          int length = 4; // Length covers all bytes
          
          // Act
          TarUtils.parseOctal(buffer, offset, length);
          
          // Assert - exception expected
          // The test will pass if exception is thrown (mutant detected)
          // and fail if no exception (original behavior)
      }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctal_AllSpacesShouldThrow() throws Exception {
         // Arrange
         byte[] buffer = {' ', ' ', ' ', ' '}; // All spaces
         int offset = 0;
         int length = buffer.length;
         
         // Act
         TarUtils.parseOctal(buffer, offset, length);
         
         // Assert - exception expected
     }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctal_AllNullsShouldThrow() throws Exception {
         // Arrange
         byte[] buffer = {0, 0, 0, 0}; // All null bytes
         int offset = 0;
         int length = buffer.length;
         
         // Act
         TarUtils.parseOctal(buffer, offset, length);
         
         // Assert - exception expected
     }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctal_SpacesAndNullsShouldThrow() throws Exception {
         // Arrange
         byte[] buffer = {' ', 0, ' ', 0}; // Mixed spaces and nulls
         int offset = 0;
         int length = buffer.length;
         
         // Act
         TarUtils.parseOctal(buffer, offset, length);
         
         // Assert - exception expected
     }

 @Test
        public void testParseOctalThrowsIllegalArgumentExceptionForShortLength() {
            byte[] buffer = {'0', '1'};
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("Length 1 must be at least 2");
            TarUtils.parseOctal(buffer, 0, 1);
        }

 @Test
        public void testParseOctalThrowsIllegalArgumentExceptionForInvalidDigits() {
            byte[] buffer = {' ', '8', ' '}; // '8' is invalid for octal
            thrown.expect(IllegalArgumentException.class);
            // The exact message isn't specified but we know it should be IllegalArgumentException
            TarUtils.parseOctal(buffer, 0, 3);
        }

 @Test
        public void testParseOctalThrowsIllegalArgumentExceptionForAllSpaces() {
            byte[] buffer = {' ', ' ', ' '};
            thrown.expect(IllegalArgumentException.class);
            TarUtils.parseOctal(buffer, 0, 3);
        }

 @Test
       public void testParseOctalThrowsIllegalArgumentExceptionForShortLength1() {
           byte[] buffer = new byte[] {'1', '2'};
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("Length 1 must be at least 2");
           TarUtils.parseOctal(buffer, 0, 1); // Length < 2 should throw IllegalArgumentException
       }

 @Test
       public void testParseOctalThrowsIllegalArgumentExceptionForInvalidDigits1() {
           byte[] buffer = new byte[] {' ', '8', ' '}; // '8' is invalid octal digit
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("Invalid octal digit"); // Partial message match
           TarUtils.parseOctal(buffer, 0, 3);
       }

 @Test
       public void testParseOctalThrowsIllegalArgumentExceptionForAllSpaces1() {
           byte[] buffer = new byte[] {' ', ' ', ' '};
           thrown.expect(IllegalArgumentException.class);
           TarUtils.parseOctal(buffer, 0, 3);
       }

 @Test
  public void testParseOctalThrowsExceptionWithDetailedMessageWhenAllSpaces() {
      // Arrange
      byte[] buffer = new byte[] {' ', ' ', ' ', ' '}; // All spaces
      int offset = 0;
      int length = 4;
      
      try {
          // Act
          TarUtils.parseOctal(buffer, offset, length);
          fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
          // Assert
          // Original behavior would include detailed message from exceptionMessage()
          // Mutant would just return "Invalid octal number"
          assertFalse("Exception message should not be just 'Invalid octal number'", 
                     "Invalid octal number".equals(e.getMessage()));
          assertTrue("Exception message should contain detailed information",
                    e.getMessage().contains("offset"));
          assertTrue("Exception message should contain detailed information",
                    e.getMessage().contains("length"));
      }
  }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctal_AllSpacesAfterTrimming_ReportsCorrectPosition() {
     // Arrange
     byte[] buffer = new byte[] {' ', ' ', ' ', ' ', ' '}; // All spaces
     int offset = 0;
     int length = buffer.length;
     
     // Act & Assert
     try {
         TarUtils.parseOctal(buffer, offset, length);
         fail("Expected IllegalArgumentException");
     } catch (IllegalArgumentException e) {
         // Verify the exception message contains the correct position (start=0)
         // The mutated version would report end=5 instead
         assertTrue("Exception message should contain position 0", 
                   e.getMessage().contains("0]"));
         throw e;
     }
 }

}
