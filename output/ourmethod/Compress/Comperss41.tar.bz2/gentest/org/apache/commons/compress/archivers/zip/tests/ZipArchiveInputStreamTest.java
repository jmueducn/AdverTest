package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                               public void testGetNextZipEntry_WhenClosed_ReturnsNull() throws Exception {
                                                                                                   // Arrange
                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                   zais.close();
                                                                                                   
                                                                                                   // Act
                                                                                                   ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                                   
                                                                                                   // Assert
                                                                                                   assertNull(result);
                                                                                               }

 @Test
                                                                                               public void testGetNextZipEntry_FirstEntryWithEOF_ReturnsNull() throws Exception {
                                                                                                   // Arrange
                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                   when(mockInputStream.read(any(byte[].class))).thenThrow(new EOFException());
                                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                   
                                                                                                   // Act
                                                                                                   ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                                   
                                                                                                   // Assert
                                                                                                   assertNull(result);
                                                                                               }

 @Test
                                                                                       public void testGetNextZipEntry_WhenHitCentralDirectory_ReturnsNull() throws Exception {
                                                                                           // Arrange
                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                           
                                                                                           // Use reflection to set private field hitCentralDirectory
                                                                                           Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                                                                                           hitCentralDirectoryField.setAccessible(true);
                                                                                           hitCentralDirectoryField.setBoolean(zais, true);
                                                                                           
                                                                                           // Act
                                                                                           ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                           
                                                                                           // Assert
                                                                                           assertNull(result);
                                                                                       }

 @Test
                                                                                   public void testGetNextZipEntry_WithUTF8Flag_UsesUTF8Encoding() throws Exception {
                                                                                       // Arrange
                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                       // Use a reasonable buffer size instead of accessing private LFH_BUF
                                                                                       byte[] lfhBuf = new byte[30]; // Minimum size needed for local file header
                                                                                       
                                                                                       System.arraycopy(ZipLong.LFH_SIG.getBytes(), 0, lfhBuf, 0, 4);
                                                                                       
                                                                                       // Set GP flag (UTF-8 names)
                                                                                       ZipShort.putShort(1 << 11, lfhBuf, 6); // Bit 11 set for UTF-8
                                                                                       
                                                                                       // Set filename length (6) and extra length (0)
                                                                                       ZipShort.putShort(6, lfhBuf, 26);
                                                                                       ZipShort.putShort(0, lfhBuf, 28);
                                                                                       
                                                                                       when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                           byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                           System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                                                                           return lfhBuf.length;
                                                                                       });
                                                                                       
                                                                                       // Mock filename read (UTF-8 bytes for "tést3")
                                                                                       byte[] utf8Name = new byte[]{(byte)'t', (byte)0xC3, (byte)0xA9, (byte)'s', (byte)'t', (byte)'3'};
                                                                                       when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                           byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                           int off = (Integer) invocation.getArguments()[1];
                                                                                           System.arraycopy(utf8Name, 0, buf, off, utf8Name.length);
                                                                                           return utf8Name.length;
                                                                                       });
                                                                                       
                                                                                       ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream, "ISO-8859-1");
                                                                                       
                                                                                       // Act
                                                                                       ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                       
                                                                                       // Assert
                                                                                       assertNotNull(result);
                                                                                       assertEquals("tést3", result.getName());
                                                                                   }

 @Test
                                                                               public void testGetNextZipEntry_WithDataDescriptor_CreatesEntryWithoutSizes() throws Exception {
                                                                                   // Arrange
                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                   // Use standard LFH size instead of private LFH_BUF
                                                                                   byte[] lfhBuf = new byte[30]; // Minimum size needed for local file header
                                                                                   
                                                                                   System.arraycopy(ZipLong.LFH_SIG.getBytes(), 0, lfhBuf, 0, 4);
                                                                                   
                                                                                   // Set GP flag (uses data descriptor)
                                                                                   ZipShort.putShort(8, lfhBuf, 6); // Bit 3 set for data descriptor
                                                                                   
                                                                                   // Set filename length (5) and extra length (0)
                                                                                   ZipShort.putShort(5, lfhBuf, 26);
                                                                                   ZipShort.putShort(0, lfhBuf, 28);
                                                                                   
                                                                                   when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                       byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                       System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                                                                       return lfhBuf.length;
                                                                                   });
                                                                                   
                                                                                   // Mock filename read
                                                                                   when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                       byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                       byte[] filename = "test2".getBytes();
                                                                                       System.arraycopy(filename, 0, buf, 0, filename.length);
                                                                                       return filename.length;
                                                                                   });
                                                                                   
                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                   
                                                                                   // Act
                                                                                   ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                   
                                                                                   // Assert
                                                                                   assertNotNull(result);
                                                                                   assertEquals("test2", result.getName());
                                                                                   assertEquals(ArchiveEntry.SIZE_UNKNOWN, result.getSize());
                                                                                   assertEquals(ArchiveEntry.SIZE_UNKNOWN, result.getCompressedSize());
                                                                                   assertEquals(-1L, result.getCrc());
                                                                                   
                                                                                   // Use reflection to check private field hasDataDescriptor
                                                                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                   currentField.setAccessible(true);
                                                                                   Object currentEntry = currentField.get(zais);
                                                                                   
                                                                                   Field hasDataDescriptorField = currentEntry.getClass().getDeclaredField("hasDataDescriptor");
                                                                                   hasDataDescriptorField.setAccessible(true);
                                                                                   boolean hasDataDescriptor = hasDataDescriptorField.getBoolean(currentEntry);
                                                                                   
                                                                                   assertTrue(hasDataDescriptor);
                                                                               }

 @Test
                                                                           public void testGetNextZipEntry_WithCurrentEntry_ClosesCurrentEntry() throws Exception {
                                                                               // Arrange
                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                               
                                                                               // Use reflection to set private current field
                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                               currentField.setAccessible(true);
                                                                               ZipArchiveEntry mockCurrentEntry = mock(ZipArchiveEntry.class);
                                                                               currentField.set(zais, mockCurrentEntry);
                                                                               
                                                                               // Mock the closed field
                                                                               Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                               closedField.setAccessible(true);
                                                                               closedField.set(zais, false);
                                                                               
                                                                               // Mock the input stream that would be closed
                                                                               InputStream mockEntryStream = mock(InputStream.class);
                                                                               Field entryStreamField = ZipArchiveInputStream.class.getDeclaredField("entryStream");
                                                                               entryStreamField.setAccessible(true);
                                                                               entryStreamField.set(zais, mockEntryStream);
                                                                               
                                                                               // Act
                                                                               zais.getNextZipEntry();
                                                                               
                                                                               // Assert
                                                                               verify(mockEntryStream).close();
                                                                           }

 @Test
                                                                           public void testGetNextZipEntry_WithValidLocalFileHeader_ReturnsEntry() throws Exception {
                                                                               // Arrange
                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                               // Local file header buffer size is typically 30 bytes (4+2+2+2+4+4+4+4+2+2)
                                                                               byte[] lfhBuf = new byte[30];
                                                                               
                                                                               // Create mock ZipLong and ZipShort instances
                                                                               byte[] lfhSig = new byte[] {0x50, 0x4b, 0x03, 0x04};  // PK.. signature
                                                                               System.arraycopy(lfhSig, 0, lfhBuf, 0, 4);
                                                                               
                                                                               // Set version made by (platform)
                                                                               lfhBuf[4] = 0;
                                                                               lfhBuf[5] = 0;
                                                                               
                                                                               // Set GP flag (no UTF-8)
                                                                               lfhBuf[6] = 0;
                                                                               lfhBuf[7] = 0;
                                                                               
                                                                               // Set compression method (STORED)
                                                                               lfhBuf[8] = 0;  // STORED method code
                                                                               lfhBuf[9] = 0;
                                                                               
                                                                               // Set time (simplified)
                                                                               for (int i = 10; i < 14; i++) {
                                                                                   lfhBuf[i] = 0;
                                                                               }
                                                                               
                                                                               // Set CRC, compressed size, uncompressed size (no data descriptor)
                                                                               // CRC = 1234
                                                                               lfhBuf[14] = (byte)(1234 & 0xFF);
                                                                               lfhBuf[15] = (byte)((1234 >> 8) & 0xFF);
                                                                               lfhBuf[16] = (byte)((1234 >> 16) & 0xFF);
                                                                               lfhBuf[17] = (byte)((1234 >> 24) & 0xFF);
                                                                               
                                                                               // Size = 100
                                                                               for (int i = 18; i < 26; i++) {
                                                                                   lfhBuf[i] = (i < 22) ? (byte)(100 & 0xFF) : 0;
                                                                               }
                                                                               
                                                                               // Set filename length (5) and extra length (0)
                                                                               lfhBuf[26] = 5;
                                                                               lfhBuf[27] = 0;
                                                                               lfhBuf[28] = 0;
                                                                               lfhBuf[29] = 0;
                                                                               
                                                                               when(mockInputStream.read(any(byte[].class))).thenAnswer(inv -> {
                                                                                   byte[] buf = (byte[]) inv.getArguments()[0];
                                                                                   System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                                                                   return lfhBuf.length;
                                                                               });
                                                                               
                                                                               // Mock filename read
                                                                               when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(inv -> {
                                                                                   byte[] buf = (byte[]) inv.getArguments()[0];
                                                                                   byte[] filename = "test1".getBytes();
                                                                                   System.arraycopy(filename, 0, buf, 0, filename.length);
                                                                                   return filename.length;
                                                                               });
                                                                               
                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                               
                                                                               // Act
                                                                               ZipArchiveEntry result = zais.getNextZipEntry();
                                                                               
                                                                               // Assert
                                                                               assertNotNull(result);
                                                                               assertEquals("test1", result.getName());
                                                                               assertEquals(100L, result.getSize());
                                                                               assertEquals(100L, result.getCompressedSize());
                                                                               assertEquals(1234L, result.getCrc());
                                                                               assertEquals(0, result.getMethod());  // STORED method code is 0
                                                                           }

 @Test
                                           public void testGetNextZipEntry_WithCentralFileHeaderSig_ReturnsNull() throws Exception {
                                               // Arrange
                                               InputStream mockInputStream = mock(InputStream.class);
                                               // Get LFH_BUF length via reflection
                                               Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("LFH_BUF");
                                               lfhBufField.setAccessible(true);
                                               byte[] lfhBuf = new byte[((byte[]) lfhBufField.get(null)).length];
                                               // Create CFH_SIG bytes (0x02014b50 in little-endian)
                                               byte[] cfhSig = new byte[] {0x50, 0x4b, 0x01, 0x02};
                                               System.arraycopy(cfhSig, 0, lfhBuf, 0, 4);
                                               
                                               // Create a buffer to be used in the mock
                                               final byte[] buf = new byte[lfhBuf.length];
                                               
                                               when(mockInputStream.read(any(byte[].class))).thenAnswer(inv -> {
                                                   System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                                   return lfhBuf.length;
                                               });
                                               
                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                               
                                               // Act
                                               ZipArchiveEntry result = zais.getNextZipEntry();
                                               
                                               // Assert
                                               assertNull(result);
                                               // Check hitCentralDirectory via reflection
                                               Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                                               hitCentralDirectoryField.setAccessible(true);
                                               assertTrue((boolean) hitCentralDirectoryField.get(zais));
                                           }

 @Test
                               public void testGetNextZipEntry_WithInvalidSignature_ThrowsZipException() throws Exception {
                                   // Arrange
                                   byte[] invalidSig = new byte[]{0x12, 0x34, 0x56, 0x78};
                                   java.io.InputStream mockInputStream = mock(java.io.InputStream.class);
                                   org.mockito.stubbing.Answer<Integer> answer = new org.mockito.stubbing.Answer<Integer>() {
                                       @Override
                                       public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                           byte[] buf = (byte[]) invocation.getArguments()[0];
                                           System.arraycopy(invalidSig, 0, buf, 0, invalidSig.length);
                                           return invalidSig.length;
                                       }
                                   };
                                   when(mockInputStream.read(any(byte[].class))).thenAnswer(answer);
                                   org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zais = 
                                       new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(mockInputStream);
                                   
                                   // Expected exception setup
                                   Exception exception = null;
                                   
                                   // Act
                                   try {
                                       zais.getNextZipEntry();
                                       org.junit.Assert.fail("Expected ZipException to be thrown");
                                   } catch (Exception e) {
                                       exception = e;
                                   }
                                   
                                   // Assert
                                   org.junit.Assert.assertNotNull("Expected ZipException to be thrown", exception);
                                   org.junit.Assert.assertEquals("Unexpected record signature: 0X12345678", exception.getMessage());
                               }

 @Test
       public void testGetNextZipEntry_ShouldDetectCentralDirectorySignature() throws Exception {
           // Setup test with CFH signature
           byte[] cfhSignature = ZipLong.CFH_SIG.getBytes();
           InputStream inputStream = new ByteArrayInputStream(cfhSignature);
           ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
           
           // Set up reflection to check hitCentralDirectory
           Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
           hitCentralDirectoryField.setAccessible(true);
           
           // Call method - should detect CFH signature and set hitCentralDirectory
           zis.getNextZipEntry();
           
           // Verify hitCentralDirectory was set to true
           assertTrue((boolean)hitCentralDirectoryField.get(zis));
           
           // Verify null was returned (as expected for central directory)
           assertNull(zis.getNextZipEntry());
       }

 @Test
       public void testGetNextZipEntry_ShouldDetectArchiveExtraDataSignature() throws Exception {
           // Setup test with AED signature
           byte[] aedSignature = ZipLong.AED_SIG.getBytes();
           InputStream inputStream = new ByteArrayInputStream(aedSignature);
           ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
           
           // Set up reflection to check hitCentralDirectory
           Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
           hitCentralDirectoryField.setAccessible(true);
           
           // Call method - should detect AED signature and set hitCentralDirectory
           zis.getNextZipEntry();
           
           // Verify hitCentralDirectory was set to true
           assertTrue((boolean)hitCentralDirectoryField.get(zis));
           
           // Verify null was returned (as expected for archive extra data)
           assertNull(zis.getNextZipEntry());
       }

 @Test
      public void testGetNextZipEntry_ShouldHandleCentralDirectorySignature() throws Exception {
          // Setup test data with CFH signature
          byte[] cfhSignature = ZipLong.CFH_SIG.getBytes();
          InputStream inputStream = new ByteArrayInputStream(cfhSignature);
          ZipArchiveInputStream zais = new ZipArchiveInputStream(inputStream);
          
          // Set up the LFH_BUF with CFH signature through reflection since it's private
          Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("LFH_BUF");
          lfhBufField.setAccessible(true);
          byte[] lfhBuf = (byte[]) lfhBufField.get(zais);
          System.arraycopy(cfhSignature, 0, lfhBuf, 0, cfhSignature.length);
          
          // Call the method - should return null for CFH signature
          ZipArchiveEntry entry = zais.getNextZipEntry();
          
          // Verify it handled the CFH signature correctly
          assertNull("Should return null for CFH signature", entry);
          
          // Verify hitCentralDirectory was set to true
          Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
          hitCentralDirectoryField.setAccessible(true);
          boolean hitCentralDirectory = hitCentralDirectoryField.getBoolean(zais);
          assertTrue("hitCentralDirectory should be true for CFH signature", hitCentralDirectory);
          
          // Clean up
          lfhBufField.setAccessible(false);
          hitCentralDirectoryField.setAccessible(false);
      }

 @Test
     public void testGetNextZipEntry_ReturnsNullWhenClosedOrHitCentralDirectory() throws Exception {
         // Create test objects
         InputStream mockInputStream = mock(InputStream.class);
         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
         
         // Test case 1: When closed is true
         zais.close(); // This should set closed = true
         assertNull("Should return null when closed", zais.getNextZipEntry());
         
         // Reset for next test case (since we can't create new instance after close)
         // Need to use reflection to reset closed flag since it's private
         Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
         closedField.setAccessible(true);
         closedField.set(zais, false);
         
         // Test case 2: When hitCentralDirectory is true
         Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
         hitCentralDirectoryField.setAccessible(true);
         hitCentralDirectoryField.set(zais, true);
         
         assertNull("Should return null when hit central directory", zais.getNextZipEntry());
         
         // Test case 3: When both are true
         closedField.set(zais, true);
         hitCentralDirectoryField.set(zais, true);
         assertNull("Should return null when both closed and hit central directory", zais.getNextZipEntry());
     }

 @Test
    public void testGetNextZipEntry_OffsetCalculation() throws Exception {
        // Setup test data with known values at specific offsets
        byte[] testData = new byte[100];
        
        // Set LFH signature (first 4 bytes)
        System.arraycopy(ZipLong.LFH_SIG.getBytes(), 0, testData, 0, 4);
        
        // Set known values at WORD (4) offset:
        // versionMadeBy at offset 4 (2 bytes)
        byte[] versionMadeBy = new ZipShort(1234).getBytes();
        System.arraycopy(versionMadeBy, 0, testData, 4, 2);
        
        // gpFlag at offset 6 (2 bytes)
        byte[] gpFlagBytes = new byte[]{0, 8}; // UTF-8 flag set
        System.arraycopy(gpFlagBytes, 0, testData, 6, 2);
        
        // method at offset 8 (2 bytes)
        byte[] methodBytes = new ZipShort(ZipMethod.DEFLATED.getCode()).getBytes();
        System.arraycopy(methodBytes, 0, testData, 8, 2);
        
        // time at offset 10 (4 bytes)
        byte[] timeBytes = new ZipLong(12345678).getBytes();
        System.arraycopy(timeBytes, 0, testData, 10, 4);
        
        // Create mock input stream
        InputStream mockInput = new ByteArrayInputStream(testData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput, "UTF-8");
        
        // Call method under test
        ZipArchiveEntry entry = zis.getNextZipEntry();
        
        // Verify offset calculations were correct by checking values read from expected positions
        assertEquals(1234, entry.getPlatform()); // Would fail if offset was WORD-1
        assertTrue(entry.getGeneralPurposeBit().usesUTF8ForNames()); // Would fail if offset was WORD-1
        assertEquals(ZipMethod.DEFLATED.getCode(), entry.getMethod()); // Would fail if offset was WORD-1
        assertEquals(ZipUtil.dosToJavaTime(12345678), entry.getTime()); // Would fail if offset was WORD-1
    }

 @Test
   public void testGetNextZipEntry_DetectsCentralDirectory() throws Exception {
       // Create a mock input stream with CFH signature (central directory header)
       byte[] cfhSignature = ZipLong.CFH_SIG.getBytes();
       InputStream mockInput = new ByteArrayInputStream(cfhSignature);
       
       // Create ZipArchiveInputStream with mock input
       ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput, "UTF-8");
       
       // Use reflection to access private field for verification
       Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
       hitCentralDirectoryField.setAccessible(true);
       
       // Call getNextZipEntry which should process the CFH signature
       ZipArchiveEntry entry = zis.getNextZipEntry();
       
       // Verify:
       // 1. No entry should be returned when hitting central directory
       assertNull("Should return null when hitting central directory", entry);
       
       // 2. hitCentralDirectory should be set to true (mutant would fail this)
       boolean hitCentralDirectory = hitCentralDirectoryField.getBoolean(zis);
       assertTrue("hitCentralDirectory should be true after CFH signature", hitCentralDirectory);
       
       // 3. Subsequent call should also return null
       assertNull("Subsequent call should return null", zis.getNextZipEntry());
       
       // Clean up
       zis.close();
   }

 @Test
  public void testGetNextZipEntry_DetectsCentralDirectory1() throws Exception {
      // Create a mock input stream that returns CFH signature (central directory header)
      byte[] cfhSig = ZipLong.CFH_SIG.getBytes();
      InputStream mockInput = new ByteArrayInputStream(cfhSig);
      ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
      
      // First call should detect central directory and set hitCentralDirectory flag
      assertNull(zis.getNextZipEntry());
      
      // Verify hitCentralDirectory was set (original behavior)
      // This would fail if the mutation is present
      Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
      hitCentralDirectoryField.setAccessible(true);
      boolean hitCentralDirectory = hitCentralDirectoryField.getBoolean(zis);
      assertTrue("hitCentralDirectory should be true after encountering CFH signature", hitCentralDirectory);
      
      // Subsequent calls should return null
      assertNull(zis.getNextZipEntry());
      
      zis.close();
  }

 @Test
 public void testGetNextZipEntryReturnsNullWhenClosedOrHitCentralDirectory() throws Exception {
     // Create a mock input stream
     InputStream mockInputStream = mock(InputStream.class);
     
     // Test case 1: closed = true
     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
     zais.close(); // sets closed = true
     
     assertNull("Should return null when stream is closed", zais.getNextZipEntry());
     
     // Test case 2: hitCentralDirectory = true
     zais = new ZipArchiveInputStream(mockInputStream);
     Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
     hitCentralDirectoryField.setAccessible(true);
     hitCentralDirectoryField.set(zais, true);
     
     assertNull("Should return null when hit central directory", zais.getNextZipEntry());
     
     // Test case 3: both closed and hitCentralDirectory true
     zais = new ZipArchiveInputStream(mockInputStream);
     zais.close();
     hitCentralDirectoryField.set(zais, true);
     
     assertNull("Should return null when both closed and hit central directory", zais.getNextZipEntry());
 }

}
