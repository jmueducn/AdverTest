package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;
import java.util.zip.ZipException;
 
public class ZipFileTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                    public void testResolveLocalFileHeaderData_EntryWithLargeExtraData() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                        // Setup test data
                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("large.txt");
                                                                        
                                                                        // Create mock OffsetEntry class since it's not available
                                                                        class OffsetEntry {
                                                                            long headerOffset;
                                                                            long dataOffset;
                                                                        }
                                                                        
                                                                        OffsetEntry offsetEntry = new OffsetEntry();
                                                                        offsetEntry.headerOffset = 500;
                                                                        
                                                                        Map<ZipArchiveEntry, OffsetEntry> entries = new LinkedHashMap<>();
                                                                        entries.put(entry, offsetEntry);
                                                                        
                                                                        // Create mock archive
                                                                        RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                                                                        
                                                                        // Mock archive behavior with large extra data
                                                                        doAnswer(invocation -> {
                                                                            byte[] b = (byte[]) invocation.getArguments()[0];
                                                                            if (b.length == 2) {
                                                                                b[0] = 5; // filename length = 5
                                                                                b[1] = 0;
                                                                                b[0] = (byte) 0xFF; // extra field length = 65535
                                                                                b[1] = (byte) 0xFF;
                                                                            } else if (b.length == 65535) {
                                                                                // Fill with dummy data
                                                                                Arrays.fill(b, (byte) 1);
                                                                            }
                                                                            return null;
                                                                        }).when(mockArchive).readFully(any(byte[].class));
                                                                        when(mockArchive.skipBytes(anyInt())).thenReturn(5); // skip filename
                                                                        
                                                                        // Create test ZipFile instance
                                                                        ZipFile zipFile = new ZipFile(new File("test.zip"));
                                                                        
                                                                        // Use reflection to access private field
                                                                        Field archiveField = ZipFile.class.getDeclaredField("archive");
                                                                        archiveField.setAccessible(true);
                                                                        archiveField.set(zipFile, mockArchive);
                                                                        
                                                                        Field entriesField = ZipFile.class.getDeclaredField("entries");
                                                                        entriesField.setAccessible(true);
                                                                        entriesField.set(zipFile, entries);
                                                                        
                                                                        // Get LFH_OFFSET_FOR_FILENAME_LENGTH via reflection
                                                                        Field lfhOffsetField = ZipFile.class.getDeclaredField("LFH_OFFSET_FOR_FILENAME_LENGTH");
                                                                        lfhOffsetField.setAccessible(true);
                                                                        int lfhOffset = lfhOffsetField.getInt(zipFile);
                                                                        
                                                                        // Get NameAndComment class from ZipFile via reflection
                                                                        Class<?> nameAndCommentClass = null;
                                                                        for (Class<?> clazz : ZipFile.class.getDeclaredClasses()) {
                                                                            if (clazz.getSimpleName().equals("NameAndComment")) {
                                                                                nameAndCommentClass = clazz;
                                                                                break;
                                                                            }
                                                                        }
                                                                        
                                                                        // Create empty map for entriesWithoutUTF8Flag using the proper NameAndComment class
                                                                        Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new HashMap<>();
                                                                        
                                                                        // Call method
                                                                        
                                                                        // Verify results
                                                                        assertEquals(1, entries.size());
                                                                        assertTrue(entries.containsKey(entry));
                                                                        assertEquals(500 + lfhOffset + 2 + 2 + 5 + 65535, 
                                                                                    entries.get(entry).dataOffset);
                                                                        assertNotNull(entry.getExtra());
                                                                        assertEquals(65535, entry.getExtra().length);
                                                                    }

    @Test
                                                            public void testResolveLocalFileHeaderData_EmptyInput() throws IOException {
                                                                // Setup test data
                                                                Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new HashMap<ZipArchiveEntry, Object>();
                                                                Map<ZipArchiveEntry, Object> entries = new HashMap<ZipArchiveEntry, Object>();
                                                                RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                                                                
                                                                // Create ZipFile instance using reflection to inject mock
                                                                ZipFile zipFile = new ZipFile(new File("test.zip"));
                                                                try {
                                                                    Field archiveField = ZipFile.class.getDeclaredField("archive");
                                                                    archiveField.setAccessible(true);
                                                                    archiveField.set(zipFile, mockArchive);
                                                                    
                                                                    Field entriesField = ZipFile.class.getDeclaredField("entries");
                                                                    entriesField.setAccessible(true);
                                                                    entriesField.set(zipFile, entries);
                                                                } catch (Exception e) {
                                                                    fail("Failed to setup test due to reflection error: " + e.getMessage());
                                                                }
                                                                
                                                                // Call method with empty map
                                                                
                                                                // Verify nothing was processed
                                                                assertTrue(entries.isEmpty());
                                                                verify(mockArchive, never()).readFully(any(byte[].class));
                                                                verify(mockArchive, never()).skipBytes(anyInt());
                                                            }

    @Test
                                                    public void testResolveLocalFileHeaderData_MultipleEntries() throws Exception {
                                                        // Setup test data
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("file1.txt");
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("file2.txt");
                                                        
                                                        // Get OffsetEntry class via reflection
                                                        Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
                                                        Object offset1 = offsetEntryClass.getDeclaredConstructor().newInstance();
                                                        Object offset2 = offsetEntryClass.getDeclaredConstructor().newInstance();
                                                        
                                                        // Set headerOffset via reflection
                                                        Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
                                                        headerOffsetField.setAccessible(true);
                                                        headerOffsetField.set(offset1, 100L);
                                                        headerOffsetField.set(offset2, 200L);
                                                        
                                                        // Create entries map
                                                        Map<ZipArchiveEntry, Object> entries = new LinkedHashMap<ZipArchiveEntry, Object>();
                                                        entries.put(entry1, offset1);
                                                        entries.put(entry2, offset2);
                                                        
                                                        // Create empty entriesWithoutUTF8Flag map
                                                        Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new HashMap<ZipArchiveEntry, Object>();
                                                        
                                                        // Create mock archive
                                                        RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                                                        
                                                        // Mock archive behavior
                                                        doAnswer(invocation -> {
                                                            byte[] b = (byte[]) invocation.getArguments()[0];
                                                            if (b.length == 2) {
                                                                b[0] = 8; // filename length = 8
                                                                b[1] = 0;
                                                                b[0] = 5; // extra field length = 5
                                                                b[1] = 0;
                                                            }
                                                            return null;
                                                        }).when(mockArchive).readFully(any(byte[].class));
                                                        
                                                        when(mockArchive.skipBytes(anyInt())).thenReturn(8); // skip filename
                                                        
                                                        // Create ZipFile instance using reflection to set private fields
                                                        File testFile = File.createTempFile("test", ".zip");
                                                        testFile.deleteOnExit();
                                                        ZipFile zipFile = new ZipFile(testFile);
                                                        Field archiveField = ZipFile.class.getDeclaredField("archive");
                                                        archiveField.setAccessible(true);
                                                        archiveField.set(zipFile, mockArchive);
                                                        
                                                        Field entriesField = ZipFile.class.getDeclaredField("entries");
                                                        entriesField.setAccessible(true);
                                                        entriesField.set(zipFile, entries);
                                                        
                                                        // Get private constant using reflection
                                                        Field lfhOffsetField = ZipFile.class.getDeclaredField("LFH_OFFSET_FOR_FILENAME_LENGTH");
                                                        lfhOffsetField.setAccessible(true);
                                                        int lfhOffset = lfhOffsetField.getInt(zipFile);
                                                        
                                                        // Call method
                                                        Method resolveMethod = ZipFile.class.getDeclaredMethod("resolveLocalFileHeaderData", Map.class);
                                                        resolveMethod.setAccessible(true);
                                                        resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
                                                        
                                                        // Verify results
                                                        assertEquals(2, entries.size());
                                                        assertTrue(entries.containsKey(entry1));
                                                        assertTrue(entries.containsKey(entry2));
                                                        
                                                        // Get dataOffset via reflection
                                                        Field dataOffsetField = offsetEntryClass.getDeclaredField("dataOffset");
                                                        dataOffsetField.setAccessible(true);
                                                        assertEquals(100 + lfhOffset + 2 + 2 + 8 + 5, 
                                                                    dataOffsetField.getLong(entries.get(entry1)));
                                                        assertEquals(200 + lfhOffset + 2 + 2 + 8 + 5, 
                                                                    dataOffsetField.getLong(entries.get(entry2)));
                                                    }

    @Test
                    public void testResolveLocalFileHeaderData_SkipFileNameFailure() throws Exception {
                        // Setup test data
                        ZipArchiveEntry entry = new ZipArchiveEntry("fail.txt");
                        
                        // Create OffsetEntry via reflection since it's private
                        Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
                        Constructor<?> constructor = offsetEntryClass.getDeclaredConstructor();
                        constructor.setAccessible(true);
                        Object offsetEntry = constructor.newInstance();
                        Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
                        headerOffsetField.setAccessible(true);
                        headerOffsetField.set(offsetEntry, 300L);
                        
                        // Create original map
                        Map<ZipArchiveEntry, Object> origMap = new LinkedHashMap<>();
                        origMap.put(entry, offsetEntry);
                        
                        // Create mock archive
                        RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                        
                        // Mock archive behavior to fail skipping
                        doAnswer(new org.mockito.stubbing.Answer<Void>() {
                            @Override
                            public Void answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                byte[] b = (byte[]) invocation.getArguments()[0];
                                if (b.length == 2) {
                                    b[0] = 10; // filename length = 10
                                    b[1] = 0;
                                }
                                return null;
                            }
                        }).when(mockArchive).read(any(byte[].class));
                        when(mockArchive.skipBytes(anyInt())).thenReturn(0); // simulate skip failure
                        
                        // Create test instance and set private field via reflection
                        ZipFile zipFile = new ZipFile("test.zip");
                        Field archiveField = ZipFile.class.getDeclaredField("archive");
                        archiveField.setAccessible(true);
                        archiveField.set(zipFile, mockArchive);
                        
                        // Create entries map (using reflection for NameAndComment)
                        Class<?> nameAndCommentClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$NameAndComment");
                        Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new HashMap<>();
                        
                        // Setup expected exception
                        try {
                            // Call method via reflection
                            Method resolveMethod = ZipFile.class.getDeclaredMethod("resolveLocalFileHeaderData", Map.class);
                            resolveMethod.setAccessible(true);
                            resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
                            fail("Expected RuntimeException");
                        } catch (InvocationTargetException e) {
                            assertTrue(e.getCause() instanceof RuntimeException);
                            assertEquals("failed to skip file name in local file header", e.getCause().getMessage());
                        }
                    }

    @Test
                public void testResolveLocalFileHeaderData_EntryWithUTF8Flag() throws Exception {
                    // Setup test data
                    ZipArchiveEntry entry = new ZipArchiveEntry("original.txt");
                    
                    // Create OffsetEntry via reflection
                    Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
                    Object offsetEntry = offsetEntryClass.getDeclaredConstructor().newInstance();
                    Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
                    headerOffsetField.setAccessible(true);
                    headerOffsetField.set(offsetEntry, 200L);
                    
                    // Initialize required maps
                    Class<?> nameAndCommentClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$NameAndComment");
                    Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new HashMap<ZipArchiveEntry, Object>();
                    Map<String, ZipArchiveEntry> nameMap = new HashMap<String, ZipArchiveEntry>();
                    
                    Object nc = nameAndCommentClass.getDeclaredConstructor(String.class, String.class)
                                                  .newInstance("modified.txt", null);
                    entriesWithoutUTF8Flag.put(entry, nc);
                    nameMap.put("original.txt", entry);
                    
                    Map<ZipArchiveEntry, Object> entries = new LinkedHashMap<ZipArchiveEntry, Object>();
                    entries.put(entry, offsetEntry);
                    
                    // Create mock archive
                    RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                    doAnswer(invocation -> {
                        byte[] b = (byte[]) invocation.getArguments()[0];
                        if (b.length == 2) {
                            b[0] = 12; // filename length = 12
                            b[1] = 0;
                            b[0] = 5; // extra field length = 5
                            b[1] = 0;
                        }
                        return null;
                    }).when(mockArchive).read(any(byte[].class));
                    when(mockArchive.skipBytes(anyInt())).thenReturn(12); // skip filename
                    
                    // Create ZipFile instance and inject dependencies via reflection
                    ZipFile zipFile = new ZipFile("test.zip");
                    try {
                        Field archiveField = ZipFile.class.getDeclaredField("archive");
                        archiveField.setAccessible(true);
                        archiveField.set(zipFile, mockArchive);
                        
                        Field nameMapField = ZipFile.class.getDeclaredField("nameMap");
                        nameMapField.setAccessible(true);
                        nameMapField.set(zipFile, nameMap);
                        
                        Field entriesField = ZipFile.class.getDeclaredField("entries");
                        entriesField.setAccessible(true);
                        entriesField.set(zipFile, entries);
                        
                        Field entriesWithoutUTF8FlagField = ZipFile.class.getDeclaredField("entriesWithoutUTF8Flag");
                        entriesWithoutUTF8FlagField.setAccessible(true);
                        entriesWithoutUTF8FlagField.set(zipFile, entriesWithoutUTF8Flag);
                    } catch (Exception e) {
                        fail("Failed to set up test via reflection: " + e.getMessage());
                    }
                    
                    // Call method via reflection since it's private
                    try {
                        Method resolveMethod = ZipFile.class.getDeclaredMethod("resolveLocalFileHeaderData", Map.class);
                        resolveMethod.setAccessible(true);
                        resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
                    } catch (Exception e) {
                        fail("Failed to invoke resolveLocalFileHeaderData: " + e.getMessage());
                    }
                    
                    // Verify results
                    assertEquals("modified.txt", entry.getName());
                    assertFalse(nameMap.containsKey("original.txt"));
                    assertTrue(nameMap.containsKey("modified.txt"));
                }

    @Test
            public void testResolveLocalFileHeaderData_StandardEntry() throws Exception {
                // Setup test data
                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                
                // Create OffsetEntry instance using reflection
                Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
                Constructor<?> offsetEntryConstructor = offsetEntryClass.getDeclaredConstructor(ZipFile.class, long.class);
                offsetEntryConstructor.setAccessible(true);
                Object offsetEntry = offsetEntryConstructor.newInstance(null, 100L);
                Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
                headerOffsetField.setAccessible(true);
                
                // Create mock archive
                RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                
                // Create zipFile instance and inject mock archive using reflection
                ZipFile zipFile = new ZipFile(new File("test.zip"));
                Field archiveField = ZipFile.class.getDeclaredField("archive");
                archiveField.setAccessible(true);
                archiveField.set(zipFile, mockArchive);
                
                // Get private constant using reflection
                Field lfhOffsetField = ZipFile.class.getDeclaredField("LFH_OFFSET_FOR_FILENAME_LENGTH");
                lfhOffsetField.setAccessible(true);
                int lfhOffset = lfhOffsetField.getInt(zipFile);
                
                // Mock archive behavior
                doAnswer(invocation -> {
                    byte[] b = (byte[]) invocation.getArguments()[0];
                    // Simulate reading filename length (2 bytes) and extra field length (2 bytes)
                    if (b.length == 2) {
                        b[0] = 8; // filename length = 8
                        b[1] = 0;
                        return null;
                    }
                    if (b.length == 4) {
                        b[0] = 10; // extra field length = 10
                        b[1] = 0;
                        return null;
                    }
                    return null;
                }).when(mockArchive).readFully(any(byte[].class));
                
                when(mockArchive.skipBytes(anyInt())).thenReturn(8); // skip filename
                
                // Setup entriesWithoutUTF8Flag map
                Class<?> nameAndCommentClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$NameAndComment");
                Constructor<?> nameAndCommentConstructor = nameAndCommentClass.getDeclaredConstructor(ZipFile.class, byte[].class, byte[].class);
                nameAndCommentConstructor.setAccessible(true);
                Object nameAndComment = nameAndCommentConstructor.newInstance(zipFile, new byte[0], new byte[0]);
                Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new LinkedHashMap<ZipArchiveEntry, Object>();
                entriesWithoutUTF8Flag.put(entry, nameAndComment);
                
                // Get resolveLocalFileHeaderData method using reflection
                Method resolveMethod = ZipFile.class.getDeclaredMethod(
                    "resolveLocalFileHeaderData", Map.class);
                resolveMethod.setAccessible(true);
                resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
                
                // Verify results
                Map<ZipArchiveEntry, Object> entries = new LinkedHashMap<ZipArchiveEntry, Object>();
                entries.put(entry, offsetEntry);
                assertEquals(1, entries.size());
                assertTrue(entries.containsKey(entry));
                assertEquals(100L + lfhOffset + 2 + 2 + 8 + 10, 
                            headerOffsetField.getLong(offsetEntry));
                assertNotNull(entry.getExtra());
                assertEquals(10, entry.getExtra().length);
            }


}
