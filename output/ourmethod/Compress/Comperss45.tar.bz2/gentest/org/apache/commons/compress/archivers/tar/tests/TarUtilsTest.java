package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                   public void testFormatLongOctalOrBinaryBytes_PositiveWithinOctalRange_UID() throws Exception {
                                                       byte[] buf = new byte[20];
                                                       int offset = 0;
                                                       int length = 8; // Assuming UIDLEN is 8 (standard for tar UID fields)
                                                       long value = 2097151L; // Assuming MAXID is 2097152 (2^21 - 1)
                                                       
                                                       // Use reflection to access the private constructor
                                                       Constructor<TarUtils> constructor = TarUtils.class.getDeclaredConstructor();
                                                       constructor.setAccessible(true);
                                                       TarUtils utils = constructor.newInstance();
                                                       
                                                       // Create spy using the instance we created via reflection
                                                       TarUtils spyUtils = spy(utils);
                                                       doReturn(offset + length).when(spyUtils).formatLongOctalBytes(value, buf, offset, length);
                                                       
                                                       int result = spyUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       assertEquals(offset + length, result);
                                                       verify(spyUtils).formatLongOctalBytes(value, buf, offset, length);
                                                   }

 @Test
                                                   public void testFormatLongOctalOrBinaryBytes_PositiveWithinOctalRange_NonUID() {
                                                       byte[] buf = new byte[20];
                                                       int offset = 5;
                                                       int length = 10;
                                                       long value = TarConstants.MAXSIZE - 1; // Just below max
                                                       
                                                       // Since all methods are static, we can't mock them directly. 
                                                       // Instead, we'll test the actual implementation.
                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       assertEquals(offset + length, result);
                                                       
                                                       // Verify the octal format was used by checking the buffer contents
                                                       // (since we can't verify static method calls)
                                                       assertEquals('0', buf[offset]); // First character should be '0' for octal
                                                   }

 @Test
                                                   public void testFormatLongOctalOrBinaryBytes_PositiveExceedsOctalRange_ShortLength() {
                                                       byte[] buf = new byte[20];
                                                       int offset = 3;
                                                       int length = 8; // < 9
                                                       long value = TarConstants.MAXSIZE + 1;
                                                       
                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       
                                                       assertEquals(offset + length, result);
                                                       assertEquals((byte)0x80, buf[offset]); // Should be marked as positive binary
                                                   }

 @Test
                                                   public void testFormatLongOctalOrBinaryBytes_PositiveExceedsOctalRange_LongLength() {
                                                       byte[] buf = new byte[20];
                                                       int offset = 2;
                                                       int length = 9; // >= 9
                                                       long value = TarConstants.MAXSIZE + 1;
                                                       
                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       
                                                       assertEquals(offset + length, result);
                                                       assertEquals((byte)0x80, buf[offset]); // Should be marked as positive binary
                                                   }

 @Test
                                                   public void testFormatLongOctalOrBinaryBytes_NegativeValue_ShortLength() {
                                                       byte[] buf = new byte[20];
                                                       int offset = 4;
                                                       int length = 7; // < 9
                                                       long value = -12345;
                                                       
                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       
                                                       assertEquals(offset + length, result);
                                                       assertEquals((byte)0xff, buf[offset]); // Should be marked as negative binary
                                                   }

 @Test
                                                   public void testFormatLongOctalOrBinaryBytes_NegativeValue_LongLength() {
                                                       byte[] buf = new byte[20];
                                                       int offset = 1;
                                                       int length = 10; // >= 9
                                                       long value = -987654321;
                                                       
                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       
                                                       assertEquals(offset + length, result);
                                                       assertEquals((byte)0xff, buf[offset]); // Should be marked as negative binary
                                                   }

 @Test
                                                   public void testFormatLongOctalOrBinaryBytes_MaxLongValue() {
                                                       byte[] buf = new byte[20];
                                                       int offset = 5;
                                                       int length = 9;
                                                       long value = Long.MAX_VALUE;
                                                       
                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       
                                                       assertEquals(offset + length, result);
                                                       assertEquals((byte)0x80, buf[offset]); // Should be marked as positive binary
                                                   }

 @Test
                                                   public void testFormatLongOctalOrBinaryBytes_MinLongValue() {
                                                       byte[] buf = new byte[20];
                                                       int offset = 3;
                                                       int length = 10;
                                                       long value = Long.MIN_VALUE;
                                                       
                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                       
                                                       assertEquals(offset + length, result);
                                                       assertEquals((byte)0xff, buf[offset]); // Should be marked as negative binary
                                                   }

 @Test
                                               public void testFormatLongOctalOrBinaryBytes_ZeroValue() {
                                                   byte[] buf = new byte[20];
                                                   int offset = 0;
                                                   int length = 12; // Assuming UIDLEN is 12 (common value for TAR UID fields)
                                                   long value = 0;
                                                   
                                                   int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                   assertEquals(offset + length, result);
                                                   
                                                   // Verify the buffer contains the expected octal representation of 0
                                                   byte[] expected = new byte[length];
                                                   java.util.Arrays.fill(expected, (byte) '0');
                                                   expected[length - 1] = ' '; // TAR format ends with space or null
                                                   org.junit.Assert.assertArrayEquals(expected, java.util.Arrays.copyOfRange(buf, offset, offset + length));
                                               }

 @Test
           public void testFormatLongOctalOrBinaryBytes_DetectsBinaryFormatMutation() {
               // Setup test case that would go through binary path with length < 9
               long value = -12345L; // Negative forces binary path
               byte[] buf = new byte[8]; // Length < 9
               int offset = 0;
               int length = 8;
               
               // Call the method
               int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
               
               // Verify the marker byte is set correctly
               assertEquals((byte)0xff, buf[offset]); // Negative marker
               
               // The key assertion - verify the buffer was modified (would differ between formats)
               // In original, formatLongBinary would have written specific bytes
               // In mutant, formatBigIntegerBinary would write different bytes
               boolean bufferModified = false;
               for (int i = offset + 1; i < offset + length; i++) {
                   if (buf[i] != 0) {
                       bufferModified = true;
                       break;
                   }
               }
               assertTrue("Buffer should have been modified by binary formatting", bufferModified);
               
               // Verify return value
               assertEquals(offset + length, result);
           }

 @Test
          public void testFormatLongOctalOrBinaryBytes_DetectNegativeFlagMutation() {
              // Setup
              long positiveValue = 100L;
              long negativeValue = -100L;
              int length = 8; // less than 9 to trigger formatLongBinary
              byte[] buf = new byte[length];
              int offset = 0;
              
              // Test positive value
              TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
              // First byte should be 0x80 for positive in binary format
              assertEquals((byte) 0x80, buf[offset]);
              
              // Test negative value
              buf = new byte[length]; // reset buffer
              TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
              // First byte should be 0xff for negative in binary format
              assertEquals((byte) 0xff, buf[offset]);
              
              // Additional check: verify the rest of the buffer isn't all zeros
              // (indicating some actual binary representation was written)
              boolean nonZeroFound = false;
              for (int i = offset + 1; i < offset + length; i++) {
                  if (buf[i] != 0) {
                      nonZeroFound = true;
                      break;
                  }
              }
              assertTrue("Binary representation should be written to buffer", nonZeroFound);
          }

 @Test
         public void testFormatLongOctalOrBinaryBytes_PositiveValueShortLength_ShouldFormatAsPositiveBinary() {
             // Setup
             long value = 12345L; // Positive value
             byte[] buf = new byte[8]; // Length < 9
             int offset = 0;
             int length = 8;
             
             // Call the method
             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
             
             // Verify
             assertEquals(offset + length, result);
             
             // The key assertion - first byte should indicate positive number (0x80)
             // Mutant would set it to 0xff (negative) instead
             assertEquals((byte) 0x80, buf[offset]);
             
             // Additional checks to ensure proper formatting
             // The rest of the buffer should contain the binary representation
             // We can't know exact binary format without seeing formatLongBinary implementation,
             // but we can at least verify it's not all zeros
             boolean nonZeroFound = false;
             for (int i = offset + 1; i < offset + length; i++) {
                 if (buf[i] != 0) {
                     nonZeroFound = true;
                     break;
                 }
             }
             assertTrue("Binary representation should contain non-zero bytes", nonZeroFound);
         }

 @Test
        public void testFormatLongOctalOrBinaryBytes_NegativeValueWithShortLength() {
            // Setup
            long value = -12345L;  // Negative value
            byte[] buf = new byte[8];  // Length < 9
            int offset = 0;
            int length = 8;
            
            // Execute
            int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
            
            // Verify
            // The mutant would set the first byte to 0x80 (false) instead of 0xff (true)
            assertEquals("First byte should indicate negative number", (byte) 0xff, buf[offset]);
            assertEquals("Should return offset + length", offset + length, result);
            
            // Additional verification that the binary representation is correct
            // For negative numbers, the first byte should be 0xff and the rest should contain the value
            // This is implementation-dependent but important to verify the negative flag was properly passed
            boolean isNegativeRepresentation = (buf[offset] & 0x80) != 0;
            assertTrue("Binary representation should indicate negative number", isNegativeRepresentation);
        }

 @Test
       public void testFormatLongOctalOrBinaryBytes_BigIntegerNegativeSignHandling() {
           // Setup
           long negativeValue = -123456789L;
           long positiveValue = 123456789L;
           int length = 9; // Triggers BigInteger path
           byte[] buf = new byte[20];
           int offset = 5;
           
           // Test negative value
           int resultOffset = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
           
           // Verify negative handling
           assertEquals(offset + length, resultOffset);
           assertEquals((byte) 0xff, buf[offset]); // Should mark as negative
           
           // The actual binary representation would be checked here if we could access formatBigIntegerBinary
           // Since we can't, we'll verify the buffer was modified (not all zeros)
           boolean bufferModified = false;
           for (int i = offset + 1; i < offset + length; i++) {
               if (buf[i] != 0) {
                   bufferModified = true;
                   break;
               }
           }
           assertTrue("Buffer should contain binary data", bufferModified);
           
           // Test positive value
           buf = new byte[20]; // Reset buffer
           resultOffset = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
           
           // Verify positive handling
           assertEquals(offset + length, resultOffset);
           assertEquals((byte) 0x80, buf[offset]); // Should mark as positive
           
           // Verify buffer was modified
           bufferModified = false;
           for (int i = offset + 1; i < offset + length; i++) {
               if (buf[i] != 0) {
                   bufferModified = true;
                   break;
               }
           }
           assertTrue("Buffer should contain binary data", bufferModified);
       }

 @Test
      public void testFormatLongOctalOrBinaryBytes_NegativeValueWithLongLength() {
          // Setup
          long value = -123456789L; // Negative value
          byte[] buf = new byte[20];
          int offset = 0;
          int length = 10; // Length >= 9 to trigger formatBigIntegerBinary
          
          // Mock the behavior of formatBigIntegerBinary to verify negative flag
          // Since we can't directly verify the call, we'll check the buffer output
          // which should reflect proper negative number handling
          
          // Execute
          int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
          
          // Verify
          // The first byte should indicate negative number (0xff)
          assertEquals((byte) 0xff, buf[offset]);
          
          // The result should be offset + length
          assertEquals(offset + length, result);
          
          // Additional verification that the buffer contains proper binary representation
          // (This depends on formatBigIntegerBinary implementation, but we know it should
          // handle negative numbers differently than positive ones)
          boolean allFF = true;
          for (int i = offset + 1; i < offset + length; i++) {
              if (buf[i] != (byte) 0xff) {
                  allFF = false;
                  break;
              }
          }
          assertFalse("Buffer should contain proper binary representation of negative number", allFF);
      }

 @Test
     public void testFormatLongOctalOrBinaryBytes_NegativeValueWithShortLength_ShouldPassCorrectNegativeFlag() {
         // Setup
         long negativeValue = -12345L;
         byte[] buf = new byte[8];
         int offset = 0;
         int length = 8; // less than 9 to trigger formatLongBinary
         
         // Execute
         int result = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
         
         // Verify
         // The mutated version would pass false for negative flag, resulting in incorrect binary format
         // We can verify the marker byte which should be 0xff for negative values
         assertEquals((byte) 0xff, buf[offset]);
         assertEquals(offset + length, result);
         
         // Also test with positive value to ensure negative flag is false when it should be
         long positiveValue = 12345L;
         buf = new byte[8];
         result = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
         assertEquals((byte) 0x80, buf[offset]);
         assertEquals(offset + length, result);
     }

 @Test
    public void testFormatLongOctalOrBinaryBytes_NegativeValueWithShortLength1() {
        // Setup
        long value = -12345L;  // Negative value
        byte[] buf = new byte[8];  // Length < 9
        int offset = 0;
        int length = 8;
        
        // Call the method
        int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
        
        // Verify the result offset
        assertEquals(offset + length, result);
        
        // Verify the first byte is marked as negative (0xff)
        assertEquals((byte) 0xff, buf[offset]);
        
        // Additional verification that the negative flag was properly passed
        // We can check if the remaining bytes contain the correct binary representation
        // Since we can't directly observe formatLongBinary's behavior, we check the buffer
        // content is not all zeros (which would suggest incorrect handling of negative)
        boolean nonZeroFound = false;
        for (int i = offset + 1; i < offset + length; i++) {
            if (buf[i] != 0) {
                nonZeroFound = true;
                break;
            }
        }
        assertTrue("Buffer should contain non-zero values for negative number", nonZeroFound);
    }

 @Test
   public void testFormatLongOctalOrBinaryBytes_NegativeValueShortLength_ShouldPassCorrectNegativeFlag() {
       // Setup
       long negativeValue = -12345L;
       byte[] buf = new byte[8]; // length < 9 to trigger formatLongBinary
       int offset = 0;
       int length = 8;
       
       // Execute
       int result = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
       
       // Verify
       // The mutated version would pass false instead of true for negative flag,
       // which would cause buf[offset] to be set to 0x80 instead of 0xff
       assertEquals((byte)0xff, buf[offset]);
       assertEquals(offset + length, result);
   }

 @Test
   public void testFormatLongOctalOrBinaryBytes_PositiveValueShortLength_ShouldPassCorrectNegativeFlag() {
       // Setup
       long positiveValue = 12345L;
       byte[] buf = new byte[8]; // length < 9 to trigger formatLongBinary
       int offset = 0;
       int length = 8;
       
       // Execute
       int result = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
       
       // Verify
       // The mutated version would pass true instead of false for negative flag,
       // which would cause buf[offset] to be set to 0xff instead of 0x80
       assertEquals((byte)0x80, buf[offset]);
       assertEquals(offset + length, result);
   }

 @Test
  public void testFormatLongOctalOrBinaryBytes_PositiveValueShortLength_ShouldFormatAsPositiveBinary1() {
      // Arrange
      long value = 12345L; // positive value
      byte[] buf = new byte[20];
      int offset = 0;
      int length = 8; // length < 9 to trigger formatLongBinary
      
      // Act
      int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
      
      // Assert
      // The first byte should indicate positive (0x80)
      assertEquals("First byte should indicate positive number", (byte) 0x80, buf[offset]);
      // Verify the method returns correct new offset
      assertEquals(offset + length, result);
      
      // Additional check: verify the rest of the buffer is not all zeros
      boolean nonZeroFound = false;
      for (int i = offset + 1; i < offset + length; i++) {
          if (buf[i] != 0) {
              nonZeroFound = true;
              break;
          }
      }
      assertTrue("Binary representation should contain non-zero bytes", nonZeroFound);
  }

 @Test
 public void testFormatLongOctalOrBinaryBytes_NegativeValueWithShortLength_ShouldFormatAsNegativeBinary() {
     // Setup
     long value = -12345L;  // Negative value
     byte[] buf = new byte[20];
     int offset = 5;
     int length = 8;  // Less than 9 to trigger formatLongBinary
     
     // Execute
     int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
     
     // Verify
     // The first byte at offset should indicate negative (0xff)
     assertEquals((byte) 0xff, buf[offset]);
     // Should return offset + length
     assertEquals(offset + length, result);
     
     // Additional verification that the negative flag was properly passed
     // We can check that the remaining bytes were properly formatted
     // (though the exact binary format depends on formatLongBinary implementation)
     boolean allZerosAfterFirstByte = true;
     for (int i = offset + 1; i < offset + length; i++) {
         if (buf[i] != 0) {
             allZerosAfterFirstByte = false;
             break;
         }
     }
     assertFalse("Binary representation should not be all zeros after sign byte", 
                allZerosAfterFirstByte);
 }

}
